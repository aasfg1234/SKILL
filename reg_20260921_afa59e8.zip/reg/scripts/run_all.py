# -*- coding: utf-8 -*-
r"""
reg 總入口：把「切條」與「改內規」兩條線串成一條。

    py run_all.py check    舊版.docx 發布根目錄
    py run_all.py compare  舊版.docx 草稿.docx --baseline-release R --outdir O
    py run_all.py apply    草稿.docx 連帶決定表.csv --outdir O
    py run_all.py finalize 舊版.docx 乾淨版.docx --baseline-release R --decisions 表 --outdir O
    py run_all.py semantic 連帶決定表.csv 語意候選.csv
    py run_all.py cut      工作區 --source 原檔 [--inherit 舊發布根目錄] [--decisions 表 ...]

設計守則（SPADE 實測得來）：
- 工作資料夾每次都換，所以每個子命令先把輸入檔複製進 <outdir>/系統檔案/輸入/。
- 畫面會截斷（留尾巴切開頭），所以完整報告寫檔，摘要印在最後。
- 沒有鍵盤輸入；失敗一律 exit 1。
- 不寫死磁碟路徑，不碰家目錄。
"""

import argparse
import datetime
import hashlib
import importlib.util
import io
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.dirname(HERE)
DIFFCUT = os.path.join(HERE, "diffcut")
REGDIFF = os.path.join(HERE, "regdiff")
SETTINGS_PATH = os.path.join(REG, "設定.json")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

# 產出檔的去向只有一張表（_common.FILE_HOMES）：寫檔走 place、讀檔走 locate。
# 不要在這支自己 os.path.join(outdir, "連帶決定表.csv")——那樣去向表改了這裡不會跟著動。
from _common import place, locate, warn_legacy_layout  # noqa: E402


def setup_stdout():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def say(text=""):
    print(text, flush=True)


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_settings():
    if not os.path.isfile(SETTINGS_PATH):
        return {}
    try:
        with io.open(SETTINGS_PATH, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError) as exc:
        # notice_pending 而不是 notice：這一則在任何一次 compare／apply 開始之前
        # 就發生了，run_compare 開頭的 reset() 會把它清掉。pending 的那幾則
        # reset() 不碰，等第一次 write_notices 寫進檔案才算交付。
        import notices as nt
        nt.notice_pending(nt.REMINDER,
                          "設定.json 讀不出來（%s），工作區根目錄、語意模型路徑等"
                          "全部用預設值" % exc, "設定檔")
        return {}


def resolve_outdir(args, settings):
    """--outdir 優先；其次 --workspace 或設定檔的工作區根目錄；都沒有就用目前目錄。"""
    if getattr(args, "outdir", ""):
        return os.path.abspath(args.outdir)
    root = getattr(args, "workspace", "") or settings.get("工作區根目錄", "")
    if not root:
        return os.path.abspath("reg_產出")
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    return os.path.join(os.path.abspath(root), "reg_產出_" + stamp)


ROLE_PREFIXES = ("舊版", "新版")
ROLE_KEY = "角色"


PROBE_NAME = ".reg_寫入測試"


def check_outdir_writable(outdir):
    """產出資料夾前置檢查：不是既有檔案、建得起來、而且真的寫得進去。

    為什麼要「真的寫一個檔再刪掉」而不是看權限位元：Windows 的唯讀屬性、
    網路磁碟機（UNC）掉線、OneDrive 的「僅線上」資料夾，用 os.access 全都
    看起來沒問題，真的寫下去才會噴 OSError——而那時候 輸入/ 已經建好、
    原始檔也複製進去了（no 10）。

    失敗一律丟 _common.InputError，由呼叫端統一印「[中止]」。
    """
    from _common import InputError
    if os.path.isfile(outdir):
        raise InputError("產出資料夾指到一個既有檔案：%s；請把 --outdir 改成資料夾路徑" % outdir)
    try:
        os.makedirs(outdir, exist_ok=True)
    except OSError as exc:
        raise InputError("產出資料夾建不起來：%s（%s）" % (outdir, exc))
    probe = os.path.join(outdir, PROBE_NAME)
    try:
        with io.open(probe, "w", encoding="utf-8") as f:
            f.write("x")
    except OSError as exc:
        raise InputError("產出資料夾不能寫入：%s（%s）；請改用別的 --outdir 或關掉開著的檔案"
                         % (outdir, exc))
    finally:
        try:
            os.remove(probe)
        except OSError:
            pass


# 「這個產出資料夾是舊排法嗎」看哪幾個檔：compare 一定會寫這兩個，
# 而且一個在 填寫表單/、一個在 系統檔案/，兩格都驗到。
_LAYOUT_PROBES = ("連帶決定表.csv", "異動清單.json")


def warn_if_legacy_outdir(outdir):
    """產出資料夾是舊排法（檔案平鋪、沒分三格）就提醒一次；回傳有沒有提醒。

    讀端照舊讀得到（locate 會退回平鋪），**寫端仍然寫進新格**——把新檔寫回平鋪
    等於把舊排法一直養下去，而且同一個資料夾會半新半舊，人更分不出哪個是這一輪的。

    單本子命令（review-pack／review-import／apply／finalize／semantic）直接接這一支；
    批次那幾支接下面的 warn_if_legacy_books（批次的產出是一本一個子資料夾，
    要驗的是每一本，不是產出根目錄——根目錄底下只有批次自己那幾個檔，
    沒有 _LAYOUT_PROBES 這兩個探針）。
    """
    if not outdir or not os.path.isdir(outdir):
        return False
    if any(locate(outdir, name)[1] for name in _LAYOUT_PROBES):
        warn_legacy_layout(outdir)
        return True
    return False


def warn_if_legacy_books(outdir, names):
    """批次版：逐本驗一次舊排法，回傳有幾本是舊排法。

    每本各發一則（warn_legacy_layout 自己用 outdir 去重），因為一批裡很可能只有
    幾本是上一個版本跑的；只講「這個產出根目錄是舊排法」的話，人不知道要回頭
    重跑哪幾本。
    """
    return sum(1 for name in names if warn_if_legacy_outdir(os.path.join(outdir, name)))


def outdir_of_table(table_path):
    """從一張表的路徑回推它的產出資料夾：在三格裡就是上一層，平鋪就是同一層。

    多剝一層 系統檔案/輸入/：留底資料夾裡也會有一份決定表（stage_inputs 複製的），
    人拿那一份去跑 semantic／finalize 時，只剝一層會停在「系統檔案/輸入」，
    接著 locate 在那裡找到平鋪的表，於是提醒會說「…系統檔案/輸入 是舊排法的產出
    資料夾」——那是留底資料夾，本來就該平鋪，這句是假警報。
    """
    folder = os.path.dirname(os.path.abspath(table_path))
    from _common import REVIEW_DIR, FILL_DIR, SYSTEM_DIR
    parent = os.path.dirname(folder)
    if os.path.basename(folder) == "輸入" and os.path.basename(parent) == SYSTEM_DIR:
        return os.path.dirname(parent)
    if os.path.basename(folder) in (REVIEW_DIR, FILL_DIR, SYSTEM_DIR):
        return parent
    return folder


def precheck(outdir, doc_paths=(), other_paths=(), docx_only=()):
    """動任何檔案之前先驗一輪：輸入檔存在＋格式白名單，再驗產出資料夾可寫。

    回傳 None 代表過關；否則回傳要印在「[中止]」後面的那句話。

    順序不能反（no 10）：輸入檔先驗，過了才 makedirs——不然「草稿路徑打錯」
    這種最常見的手誤會留下一個空的產出資料夾，下一輪的過期檢查、歸檔都要
    跟這些殘骸打架。同理，docx_only 也要排在 check_outdir_writable 之前。

    doc_paths   要當內規全文讀的檔（走 SUPPORTED_EXTS 白名單）
    other_paths 只要求存在的檔（決定表 .csv、sidecar .json 這類）
    docx_only   除了白名單以外還必須是 .docx 的檔（M5：apply 的草稿）
    """
    from _common import InputError, check_input_file
    for path in doc_paths:
        if not path:
            continue
        try:
            check_input_file(path)
        except InputError as exc:
            return str(exc)
    for path in docx_only:
        # M5：apply 是把決定表的修改寫成 Word 追蹤修訂再存回 .docx——.txt／.md
        # 根本沒有修訂記號這種東西，硬跑只會產出一份「看起來成功但沒有任何
        # 修訂痕跡」的檔。compare 吃得下不代表 apply 吃得下，這一步要講清楚。
        if path and os.path.splitext(path)[1].lower() != ".docx":
            return ("apply 的草稿必須是 .docx（目前：%s）；.txt/.md 只能用來 compare"
                    % os.path.basename(path))
    for path in other_paths:
        if path and not os.path.isfile(path):
            return ("錯誤：找不到檔案 %s\n"
                    "請確認路徑有沒有打錯，含空白的路徑要用雙引號括起來。" % path)
    try:
        check_outdir_writable(outdir)
    except InputError as exc:
        return str(exc)
    return None


def stage_inputs(outdir, paths, roles=None, overwrite_level=None):
    """輸入檔複製進 <outdir>/輸入/ 並記 SHA-256。SPADE 的上傳檔跑完就不見，這是唯一留底。
    同一個產出資料夾可能被多個子命令接力使用，所以指紋檔採合併寫入，不覆蓋既有項目。

    overwrite_level（選填）：同一角色留底被不同內容覆寫時要用的提醒等級。預設「警告」；
    compare 會整套重算下游產出，換草稿重跑是正常流程，所以 compare 傳「提醒」就好。
    roles（選填）：跟 paths 等長的角色清單，或 {路徑: 角色} 對照表。角色是「舊版」
    或「新版」時，留底檔名變成 `舊版_<原檔名>`／`新版_<原檔名>`，指紋鍵同名，並在
    指紋檔多記一個「角色」對照。

    為什麼要分：法遵手上的舊版與新版常常就是同一個檔名（放在「匯入/舊版」「匯入/新版」
    兩個資料夾裡）。照原檔名留底的話，後複製的新版會直接蓋掉舊版，指紋檔也只剩一筆——
    留底看起來有兩個檔其實只有一個，而 review-pack 會把草稿當成舊版讀，刪除段的前後文
    整段對錯人。角色清單不能用單純的 dict 由呼叫端組（沒有草稿的那一本，舊版與新版
    是同一個路徑，當鍵會撞在一起），所以這裡也接受跟 paths 等長的清單。
    """
    import notices as nt
    # 留底是「程式接力用」的東西，進 系統檔案/輸入/（見 _common.FILE_HOMES）。
    # 舊排法的資料夾已經有平鋪的 輸入/（裡面有 舊版_／新版_ 與帶「角色」的指紋）時
    # 沿用它：另開 系統檔案/輸入/ 會把舊的那份遮掉，review-pack 從此找不到舊版檔，
    # 只能用檔名猜、把草稿當舊版（全波審查發現）。
    target, is_legacy = locate(outdir, "輸入")
    if not is_legacy:
        target = place(outdir, "輸入")
    os.makedirs(target, exist_ok=True)
    record_path = os.path.join(target, "輸入指紋.json")
    record = {}
    if os.path.isfile(record_path):
        try:
            with io.open(record_path, encoding="utf-8-sig") as f:
                record = json.load(f)
        except (OSError, ValueError) as exc:
            # 靜默清空是最糟的處理：檔案壞掉（磁碟滿了寫到一半、被人手動編輯過）
            # 之後，前面幾個子命令留下的指紋全部消失，而「輸入指紋.json 存在且
            # 看起來完整」正是之後回答「這份產出是拿哪幾個檔跑的」的唯一依據。
            # 重建可以，但一定要有人知道舊紀錄不見了。
            nt.notice(nt.WARNING,
                      "輸入指紋.json 讀不出來（%s），已重建；"
                      "之前的留底紀錄遺失，這個產出資料夾先前留底過哪些檔要另外查" % exc,
                      "留底")
            record = {}
    role_map = dict(record.get(ROLE_KEY) or {})
    for index, path in enumerate(paths):
        if not path or not os.path.isfile(path):
            continue
        if isinstance(roles, dict):
            role = roles.get(path) or ""
        elif roles is not None and index < len(roles):
            role = roles[index] or ""
        else:
            role = ""
        name = os.path.basename(path)
        if role in ROLE_PREFIXES:
            name = "%s_%s" % (role, name)
            role_map[role] = name
        dest = os.path.join(target, name)
        digest = file_sha256(path)
        previous = record.get(name)
        if previous and previous != digest:
            # 同一個產出資料夾被多個子命令接力使用，留底檔名一樣但內容不一樣，
            # 代表「同一個角色的檔案中途換過」（草稿又改了一版、舊版拿錯檔）。
            # 直接覆寫的話，留底剩下最後那一份，而決定表、指紋、段次全是前一份
            # 算出來的——回頭稽核時對不起來，卻沒有任何一行講過這件事。
            nt.notice(overwrite_level or nt.WARNING,
                      "留底 %s 被不同內容覆寫（SHA %s → %s）："
                      "同一個產出資料夾這個角色前後拿到兩個不同的檔，"
                      "先前步驟的產出是用舊的那一份算的，請確認是不是拿錯檔"
                      % (name, previous[:8], digest[:8]), "留底")
        if os.path.abspath(path) != os.path.abspath(dest):
            shutil.copy2(path, dest)
        record[name] = digest
    if role_map:
        record[ROLE_KEY] = role_map
    with io.open(record_path, "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return record


def load_regdiff_runner():
    """regdiff/run_all.py 跟這支同名，不能直接 import，改用檔案路徑載入。"""
    path = os.path.join(REGDIFF, "run_all.py")
    spec = importlib.util.spec_from_file_location("regdiff_run_all", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------------------
# check
# ---------------------------------------------------------------------------

def cmd_check(args, settings):
    from baseline_release import BaselineReleaseError, load_baseline_release
    from _common import read_paragraphs
    say("=" * 60)
    say("第 0 步　核對舊版 Word 與規格包")
    say("=" * 60)
    try:
        paragraphs = read_paragraphs(args.old_file)
        baseline = load_baseline_release(args.release_root, args.old_file,
                                         old_paragraphs=paragraphs)
    except BaselineReleaseError as exc:
        say("[不過] %s" % exc)
        return 1
    say("[過] 正式基準 %s：條文 %d 筆，內容定位 %d，無法定位 %d"
        % (baseline.version, len(baseline.items),
           baseline.binding_stats["已定位"], baseline.binding_stats["無法定位"]))
    return 0


# ---------------------------------------------------------------------------
# apply
# ---------------------------------------------------------------------------

def cmd_apply(args, settings):
    import apply_changes as ac
    import decision_table as dt
    import notices as nt
    outdir = resolve_outdir(args, settings)
    # I1：算出來的產出資料夾要寫回 args——沒有 --outdir 的時候 args.outdir 一直是空的，
    # main() 的 _abort_notice 就找不到資料夾可以接寫 提醒.txt，中止原因只剩畫面上
    # 那一行。_compare_core 早就這樣做了，apply 這邊漏了。
    args.outdir = outdir
    # no 10／11：先驗草稿格式、決定表存在、產出資料夾可寫，過了才動檔案。
    # sidecar 不列進 other_paths：它由 dt 自己容錯（舊的決定表可能根本沒有）。
    problem = precheck(outdir, doc_paths=[args.draft], other_paths=[args.decisions],
                       docx_only=[args.draft])
    if problem:
        say("[中止] %s" % problem)
        return 1
    # 舊排法的產出資料夾照舊讀得到，但要講一聲；三件套仍寫進 審閱文件/。
    # 這一則走 notice_pending（見 _common.warn_legacy_layout），ac.apply 開頭的
    # nt.reset() 清不掉它，提醒.txt 裡才留得住。
    warn_if_legacy_outdir(outdir)
    stage_inputs(outdir, [args.draft, args.decisions, dt.sidecar_path_for(args.decisions)])
    try:
        summary = ac.apply(args.draft, args.decisions, outdir)
    except (ac.ApplyError, dt.DecisionTableError) as exc:
        say("[中止] %s" % exc)
        # 中止時 apply 沒有寫任何產出檔，但「為什麼中止」一定要留下來：
        # 畫面上的這一行是唯一的線索，而畫面留不住。
        # 先記成一則警告再寫檔——有些中止（例如草稿指紋不符）是在 apply 發任何
        # 提醒之前就丟出來的，不記的話 提醒.txt 會寫著「本次沒有提醒」，
        # 那份檔案等於在說「這次沒事」。
        nt.notice(nt.WARNING, "apply 中止：%s" % exc, "套用")
        # 跟成功路徑一樣接寫：中止也不可以把 compare 那一段洗掉。
        say("提醒留底：%s" % nt.write_notices(outdir, append=True,
                                             title="apply（第 3 步　套用，中止）"))
        return 1
    say("=" * 60)
    say("第 3 步　套用完成")
    say("=" * 60)
    tally = summary["統計"]
    for key, value in sorted(tally.items()):
        say("  %-14s %d 列" % (key, value))
    # 跳過有兩類，畫面上長得一樣，人要分得出來（no 35）：
    #   程式做不到的（SKIP_BLOCKING）＝真的沒改到，finalize 第一問會擋；
    #   人自己填了「改」但填的字等於原文＝人決定不改，不擋。
    # 警告那一則 ac.apply 已經記進 提醒.txt 與 套用報告.txt，這裡印的是同一句。
    blocked = ac.blocked_rows(tally)
    chosen = tally.get(ac.SAME_TEXT_STATUS, 0)
    if blocked:
        say("[警告] " + ac.blocked_message(tally))
    if chosen:
        say("[提醒] 有 %d 列填了改但等於原文，視為不改，不擋驗收" % chosen)
    say("定稿：%s" % summary["定稿"])
    say("乾淨版：%s" % summary["乾淨版"])
    say("報告：%s" % summary["報告"])
    say("提醒留底：%s（%d 則）" % (summary["提醒"], len(nt.collected())))
    if blocked:
        say("下一步：先處理上面 %d 列，再拿乾淨版跑 finalize。"
            "定稿請在有 Word 的電腦開一次確認。最終仍需人工複核。" % blocked)
    else:
        say("下一步：拿乾淨版跑 finalize。定稿請在有 Word 的電腦開一次確認。最終仍需人工複核。")
    return 0


# ---------------------------------------------------------------------------
# compare / finalize 共用
# ---------------------------------------------------------------------------

# Step 2 四個門檻旗標：終比對（finalize／batch-finalize）沒有在命令列另外指定時，
# 要沿用初比對指紋檔記的「比對參數」，不是悄悄退回這裡的硬預設。
_COMPARE_PARAM_KEYS = ("threshold", "top", "changed_top", "sentence_threshold")


def _compare_param_fallbacks(runner):
    """真的什麼都沒有時（指紋檔是這個功能之前產生的、或根本沒有 recorded）才用的
    最後一層預設值，跟 regdiff 自己的常數一致。"""
    return {"threshold": runner.fuzzy.DEFAULT_THRESHOLD, "top": runner.fuzzy.DEFAULT_TOP,
           "changed_top": 8, "sentence_threshold": runner.fuzzy.DEFAULT_SENTENCE_THRESHOLD}


def _compare_params_with_fallback(runner, recorded=None):
    """recorded（通常是某本指紋檔的「比對參數」）有記的鍵就用它，沒記的鍵（或整個
    沒給）退回 _compare_param_fallbacks。回傳四個鍵都有值的完整 dict。"""
    out = _compare_param_fallbacks(runner)
    if recorded:
        for key in _COMPARE_PARAM_KEYS:
            if key in recorded:
                out[key] = recorded[key]
    return out


def _fill_compare_defaults(args, runner, recorded=None):
    """把 args 上這四個旗標裡使用者命令列沒給的（build_parser 把它們 default 設
    None）補上值：recorded 有記就沿用，沒記就退回 regdiff 的硬預設。回傳「這次
    真的是從 recorded 沿用過來」的那幾個鍵值（呼叫端拿這個判斷要不要印「沿用」
    訊息——使用者自己在命令列指定的、或 recorded 根本沒有記錄的，都不算沿用）。"""
    resolved = _compare_params_with_fallback(runner, recorded)
    inherited = {}
    for key in _COMPARE_PARAM_KEYS:
        if getattr(args, key, None) is None:
            setattr(args, key, resolved[key])
            if recorded and key in recorded:
                inherited[key] = resolved[key]
    return inherited


def _compare_params_from_args(args):
    return dict((key, getattr(args, key)) for key in _COMPARE_PARAM_KEYS)


def _say_inherited_params(prefix, params):
    say("%s：相似 %g、前幾筆 %d、改動文字前 %d 筆、句 %g"
        % (prefix, params["threshold"], params["top"], params["changed_top"],
           params["sentence_threshold"]))


def _compare_core(args, settings, final, write_table=True):
    """跑 regdiff 的 Step 0.5→1→1.2→1.6→2，再合成連帶決定表。回傳 (rc, outcome, rows, outdir)。

    write_table=False 時只算不寫表：batch 要等所有本的第 0、1 步都過了才寫，
    中途中止才不會在產出資料夾留下前幾本的決定表。"""
    import decision_table as dt
    runner = load_regdiff_runner()
    outdir = resolve_outdir(args, settings)
    # no 10／11：舊版、新版的存在與格式，還有產出資料夾能不能寫，全部在
    # makedirs／stage_inputs 之前驗完。以前這幾件事要等 read_paragraphs
    # （比對跑到一半）才發現，那時候殘骸已經留在硬碟上了。
    problem = precheck(outdir, doc_paths=[args.old_file, args.new_file])
    if problem:
        say("[中止] %s" % problem)
        return 1, None, [], outdir
    # 舊版與新版常常同檔名，一定要帶角色留底，不然後複製的會蓋掉先複製的
    # compare 換檔重跑會整套重算，覆寫留底是正常流程，只用「提醒」不用「警告」。
    import notices as nt
    stage_inputs(outdir, [args.old_file, args.new_file], roles=["舊版", "新版"],
                 overwrite_level=nt.REMINDER)
    args.outdir = outdir
    if final:
        args.prefix = "最終版"
        # 終比對比的是「原始草稿 → 套用後的乾淨版」：決定表一列都沒填時 0 異動是
        # 正常結果，不是「拿錯檔」，這裡不發零異動提醒（裁定 7 只講單本 compare）。
        args.zero_change_level = None
    try:
        outcome = runner.run_compare(args)
    except runner.BaselineReleaseError as exc:
        say("[中止] 正式基準驗證失敗：%s" % exc)
        return 1, None, [], outdir
    except runner.CompareAbort as exc:
        # 讀檔防呆沒過（例如任一邊 0 段）。這裡就收掉，不能讓後面的步驟
        # 拿著空的一邊產出一份「整本條文全部刪除」的正式對照表還 exit 0。
        say("[中止] %s" % exc)
        return 1, None, [], outdir

    results = outcome["results"]
    baseline = outcome["baseline"]
    new_line_ids = baseline.annotate_results(results) if baseline else {}
    semantic_rows = []
    if getattr(args, "semantic", None):
        import semantic_candidates as sc
        try:
            semantic_rows = sc.read_results(args.semantic, expected_sha=file_sha256(args.new_file))
        except sc.SemanticError as exc:
            say("[中止] 語意候選檔不能用：%s" % exc)
            return 1, None, [], outdir
    rows = dt.build_rows(outcome["csv_rows"], outcome["changed_rows"],
                         outcome["review_rows"], new_line_ids,
                         outcome["new_paragraphs"], semantic_rows,
                         sentence_rows=outcome.get("sentence_rows"),
                         change_types=dt.change_type_map(results, baseline),
                         change_positions=dt.change_position_map(results, baseline))
    if write_table:
        changed_texts = [r["new_text"] for r in results if r["type"] in ("added", "modified")]
        if final:
            # 終比對候選表是「人只要看」的表（三問的佐證），不回頭被程式讀 → 審閱文件/、
            # 而且改出 xlsx（欄寬、換行、粗體標題列留得住）。指紋檔照舊是中繼檔 →
            # 系統檔案/（sidecar_path_for 會從 審閱文件/ 往上找一層）。
            table_path = place(outdir, "終比對候選表.xlsx")
            json_path = dt.sidecar_path_for(table_path)
            fmt = "xlsx"
        else:
            # 連帶決定表是「人要填、程式回頭讀」的表 → 填寫表單/，格式不能變（csv）；
            # 它的指紋檔是程式接力用的中繼檔 → 系統檔案/（不放在表旁邊）。
            table_path = place(outdir, "連帶決定表.csv")
            json_path = place(outdir, "連帶決定表.json")
            fmt = "csv"
        written = []
        dt.write_table(rows, table_path, json_path, args.new_file, changed_texts,
                       params=_compare_params_from_args(args), fmt=fmt, written=written)
        # 產出清單印的是**真的寫出來的**那幾個檔：xlsx 寫不出來時退成 csv，
        # 檔名跟 table_path 不一樣，印 table_path 會叫人去找一個不存在的檔。
        outcome["produced"].extend(written)
        # 指紋檔跟 異動清單.json／語意輸入.json 一樣是系統檔案，清單也列出來（全波審查：
        # 三份 json 只列兩份沒道理）。
        if os.path.isfile(json_path):
            outcome["produced"].append(json_path)
        if not final:
            # finalize（final=True）的新舊版是「原始草稿→套用後的乾淨版」，跟第 1 步初比對
            # 記的「異動清單.json」是完全不同的一組異動；finalize 若也覆寫它，review-pack／
            # review-import 已經做過的第 1.5 步就對不上了（表和 AI 判斷指的是舊的異動清單）。
            # 這裡只在初比對時寫，finalize 沿用同一個 outdir 時異動清單.json 維持原樣。
            change_list_path = place(outdir, "異動清單.json")
            dt.write_change_list(results, change_list_path)
            outcome["produced"].append(change_list_path)
    return 0, outcome, rows, outdir


def source_distribution(rows):
    """{來源組合: 列數}。**一列只算一次**（小瑕疵 13）。

    以前是把每一列的「來源」用「；」拆開、每個標籤各記一次，於是同時被相似度與
    語意抓到的那一列會在兩個桶子裡各算一遍，括號裡的數字加起來大於「候選 N 列」。
    人看到「候選 12 列（相似 9、語意 6）」會以為自己數錯，或以為表上少了幾列。
    改成一列只進一個桶子，桶名就是它的來源組合（相似＋語意），加起來剛好是列數。
    """
    dist = {}
    for row in rows:
        labels = [s for s in (row.get("來源") or "").split("；") if s]
        key = "＋".join(labels) if labels else "無來源"
        dist[key] = dist.get(key, 0) + 1
    return dist


def under_outdir(outdir, path):
    """產出檔印給人看的位置：產出資料夾底下的相對路徑，例如 審閱文件/修正對照表.xlsx。

    以前印 os.path.basename(path)，那是檔案平鋪時代的寫法——現在檔案分在三格裡，
    只印檔名的話人拿著「修正對照表.xlsx」在產出資料夾第一層翻不到。
    分隔符一律印「/」：這幾行是「在哪一格」的指路，不是要人複製貼上的完整路徑
    （完整路徑另外有一行「產出資料夾：」）。
    """
    try:
        rel = os.path.relpath(path, outdir)
    except ValueError:      # Windows 跨磁碟機
        return path
    if rel.startswith(".."):
        return path
    return rel.replace(os.sep, "/")


def _print_compare_summary(title, outcome, rows, outdir):
    counts = {}
    for r in outcome["results"]:
        counts[r["type"]] = counts.get(r["type"], 0) + 1
    sources = source_distribution(rows)
    say("")
    say("=" * 60)
    say(title)
    say("=" * 60)
    # 「僅字形／空白差異」要單獨報一個數：它不是實質異動、也不是編號調整，
    # 併進任何一邊都會讓人以為有東西真的改了。
    say("實質異動 %d 處（新增 %d、刪除 %d、修改 %d），編號調整 %d 處，僅字形／空白差異 %d 處"
        % (counts.get("added", 0) + counts.get("deleted", 0) + counts.get("modified", 0),
           counts.get("added", 0), counts.get("deleted", 0), counts.get("modified", 0),
           counts.get("renumbered", 0), counts.get("cosmetic", 0)))
    say("候選 %d 列（%s）" % (len(rows), "、".join("%s %d" % kv for kv in sorted(sources.items())) or "無"))
    say("產出資料夾：%s" % outdir)
    for path in outcome["produced"]:
        say("  " + under_outdir(outdir, path))


def cmd_compare(args, settings):
    import decision_table as dt
    runner = load_regdiff_runner()
    _fill_compare_defaults(args, runner)  # 初比對沒有可沿用的來源，沒給的旗標一律用硬預設
    rc, outcome, rows, outdir = _compare_core(args, settings, final=False)
    if rc:
        return rc
    semantic_rows = _write_semantic_input(args, outcome, outdir, settings)
    if semantic_rows:
        rows = dt.add_semantic(rows, semantic_rows)
        csv_path = place(outdir, "連帶決定表.csv")
        changed_texts = [r["new_text"] for r in outcome["results"] if r["type"] in ("added", "modified")]
        dt.write_table(rows, csv_path, place(outdir, "連帶決定表.json"),
                       args.new_file, changed_texts,
                       params=_compare_params_from_args(args))
    _print_compare_summary("第 1 步　初比對完成", outcome, rows, outdir)
    if outcome.get("零異動"):
        # 0 異動時叫人去填一張空表是最糟的收尾：他會以為是自己看不懂。
        # 警告在上面（run_compare 裡）已經發過、也留了底，這裡只把下一步換掉。
        say("下一步：確認檔案沒拿錯；若確實沒改，這本不需要處理。")
    else:
        # 檔名要帶格子：產出資料夾第一層只有三個資料夾，光講「連帶決定表.csv」
        # 人會在第一層翻不到。
        say("下一步：用 Excel 開「填寫表單/連帶決定表.csv」，填「要改嗎」「改成什麼」。最終仍需人工複核。")
    return 0


def _semantic_recall_top(settings):
    """設定檔的「語意粗篩」：留空（null／""）就全排名；填數字 N 就只對純語意前 N 名算三種分數。"""
    value = settings.get("語意粗篩")
    if value in (None, "", 0, "0"):
        return None
    return int(value)


def _semantic_threshold(settings):
    """設定檔的「語意門檻」：留空（null／""）就交給分數器用自己的預設
    （三分數合併 0.70、只有 dense 0.75，見 semantic_candidates）。"""
    value = settings.get("語意門檻")
    if value in (None, ""):
        return None
    return float(value)


def _write_semantic_input(args, outcome, outdir, settings):
    """一律寫語意輸入.json；模型載得起就當場算並併入，否則印手動指令。回傳語意列。"""
    import semantic_candidates as sc
    # 「舊全文」給語意那邊找「改到的那幾句」用（沒有就整段去比）。
    changes = [{"段次": r["new_index"], "全文": r["new_text"], "舊全文": r.get("old_text") or "",
                "條文ID": "、".join(r.get("spec_ids") or [])}
               for r in outcome["results"]
               if r["type"] in ("added", "modified") and r.get("new_index")]
    draft_sha = file_sha256(args.new_file)
    input_path = place(outdir, "語意輸入.json")
    sc.write_input(input_path, args.new_file, draft_sha, changes, outcome["new_paragraphs"])
    outcome["produced"].append(input_path)
    if getattr(args, "semantic", None):
        return []      # 使用者已經給了算好的檔，_compare_core 併過了
    model_path = settings.get("語意模型路徑", "")
    if not model_path:
        say("")
        say("語意候選（BGE-M3）：這台電腦沒設定模型，跳過。要用的話在有模型的電腦跑：")
        say("  python semantic_candidates.py \"%s\" \"%s\" --model <模型資料夾>"
            % (input_path, place(outdir, "語意候選.csv")))
        say("  python run_all.py semantic \"%s\" \"%s\""
            % (place(outdir, "連帶決定表.csv"), place(outdir, "語意候選.csv")))
        return []
    say("語意候選（BGE-M3）：載入 %s" % model_path)
    embed = sc.load_model(model_path, recall_top=_semantic_recall_top(settings))
    if embed is None:
        say("  載不起模型，改手動：見上面兩行指令的用法（語意輸入.json 已寫好）。")
        return []
    rows = sc.find_candidates(embed, changes, outcome["new_paragraphs"],
                              _semantic_threshold(settings),
                              int(settings.get("語意最多幾筆", sc.DEFAULT_TOP)))
    result_path = place(outdir, "語意候選.csv")
    sc.write_results(result_path, rows, draft_sha)
    outcome["produced"].append(result_path)
    return rows


def _warn_if_clean_has_revisions(path):
    """終比對的「新版」是定稿乾淨版。它還帶著追蹤修訂就是出事了。

    乾淨版的定義就是「修訂全部接受過」。還有修訂記號代表這份檔不是 apply 產的，
    或是有人在 apply 之後又在 Word 裡改過——而本程式一律以「已接受修訂」的內容
    比對，三問會全部是零、結論寫「改好」，那份帶著修訂記號的檔卻會直接被拿去切條。
    只提醒不擋：確實有人需要拿別的檔跑終比對。
    """
    import notices as nt
    if not str(path or "").lower().endswith(".docx") or not os.path.isfile(path):
        return
    import xml.etree.ElementTree as ET
    import zipfile
    from _common import count_tracked_changes, describe_tracked_changes
    try:
        with zipfile.ZipFile(path) as archive:
            root = ET.fromstring(archive.read("word/document.xml"))
    except (OSError, KeyError, zipfile.BadZipFile, ET.ParseError) as exc:
        # 「沒印警告」跟「檢查過、沒有修訂」在畫面上長得一模一樣。讀不動的時候
        # 什麼都不說，等於默默把這一項降級成「沒問題」——而這一項要擋的正是
        # 「一份還帶著追蹤修訂的定稿被直接送出」。所以改印「未檢查」。
        nt.notice(nt.REMINDER,
                  "定稿追蹤修訂檢查：未檢查（讀不到 %s：%s）；"
                  "這一項沒跑到，不代表定稿沒有追蹤修訂"
                  % (os.path.basename(str(path)), exc), "第 4 步")
        return
    counts = count_tracked_changes(root)
    if any(counts.values()):
        nt.notice(nt.WARNING,
                  "定稿仍含追蹤修訂（%s）：終比對是以「已接受修訂」的內容比對的，"
                  "三問的結論不涵蓋這些還沒被接受或拒絕的修訂；"
                  "請在 Word 裡處理掉再另存乾淨版" % describe_tracked_changes(counts),
                  "第 4 步")


def _finalize_core(args, settings, extra=None):
    """第 4 步核心。回傳 (rc, answers, report_path, outdir)；rc 非 0 時其餘為 None。

    extra 給 dict 時，把這一本的中間結果填進去：「outcome」（比對結果，含
    results／new_paragraphs／baseline）、「final_rows」（終比對候選列）、
    「decision_rows」「sidecar」（初比對決定表與它的指紋檔）、「report_path」。
    batch-finalize 要等所有本都終比對完才算得出跨本連帶（來源是別本的定稿），
    那時候這些東西已經被這一支算過一次了，不給呼叫端拿就只能整本重跑一次比對。
    回傳值不動：單本 finalize 不必知道有這回事。"""
    import decision_table as dt
    import finalize_check as fc
    try:
        decision_rows = dt.read_table(args.decisions)
        sidecar = dt.read_sidecar(dt.sidecar_path_for(args.decisions))
    except dt.DecisionTableError as exc:
        say("[中止] %s" % exc)
        return 1, None, None, None
    # Step 2 四個門檻旗標：命令列沒給的（build_parser 把 compare／finalize 這幾個旗標
    # default 設 None）沿用初比對指紋檔記的「比對參數」，不是悄悄退回程式的硬預設——
    # 不然終比對候選表列出的候選會跟初比對兜不起來（見 decision_table.write_table）。
    runner = load_regdiff_runner()
    inherited = _fill_compare_defaults(args, runner, sidecar.get("比對參數"))
    if inherited:
        _say_inherited_params("終比對沿用初比對門檻", _compare_params_from_args(args))
    rc, outcome, final_rows, outdir = _compare_core(args, settings, final=True)
    if rc:
        return rc, None, None, outdir
    stage_inputs(outdir, [args.decisions, dt.sidecar_path_for(args.decisions)])
    import notices as nt
    # 這一則要在 _compare_core 之後才發：run_compare 開頭會清空提醒清單。
    _warn_if_clean_has_revisions(args.new_file)
    # 決定表所在的那個產出資料夾（多半是初比對那一輪）是不是舊排法。
    # 終比對自己的產出（--outdir）一律寫進新格。
    warn_if_legacy_outdir(outdir_of_table(args.decisions))
    answers = fc.three_questions(decision_rows, sidecar, outcome["new_paragraphs"], final_rows)
    same_text = answers.get(fc.SAME_TEXT_KEY) or []
    if same_text:
        # 不擋結論，但一定要留底：這幾列在定稿上看不到任何修訂記號，
        # 只有這一則提醒說得出「它們是被人選成不改的，不是漏改」。
        nt.notice(nt.REMINDER,
                  "有 %d 列填了「改」但「改成什麼」跟原文一字不差（段次 %s），"
                  "定稿上沒有修訂記號，視為不改；真的要改請回決定表把「改成什麼」寫成改完的樣子"
                  % (len(same_text),
                     "、".join((r.get("候選段次") or "-") for r in same_text)),
                  "終比對")
    report_path = place(outdir, "終比對驗收報告.txt")
    # 這一輪的提醒整段抄進驗收報告：三問都是零、結論寫「改好」時，那個「改好」的
    # 前提（有幾處標不上去、有幾列跳過）一定要在同一張紙上看得到。
    fc.write_report(answers, report_path, notices=nt.collected())
    # 重寫一次 最終版_提醒.txt：run_compare 在比對結束時寫過一份，但「定稿仍含
    # 追蹤修訂」是比對之後才判的，那一份還沒有它。
    nt.write_notices(outdir, "最終版")
    outcome["produced"].append(report_path)
    if extra is not None:
        extra.update({"outcome": outcome, "final_rows": final_rows,
                      "decision_rows": decision_rows, "sidecar": sidecar,
                      "report_path": report_path})
    _print_compare_summary("第 4 步　終比對完成", outcome, final_rows, outdir)
    say("三問：未改到 %d、未決定 %d、新候選 %d" % (
        len(answers["未改到"]), len(answers["未決定"]), len(answers["新候選"])))
    say("填了但等於原文 %d 列（視為不改）" % len(same_text))
    if nt.collected():
        say("本輪提醒 %d 則，見 終比對驗收報告.txt 的提醒段與 最終版_提醒.txt" % len(nt.collected()))
    return 0, answers, report_path, outdir


def cmd_finalize(args, settings):
    import finalize_check as fc
    import notices as nt
    rc, answers, report_path, _ = _finalize_core(args, settings)
    if rc:
        return rc
    total = fc.blocking_total(answers)
    # 結論那一行跟報告檔共用 fc.verdict：三問皆零但有警告時不准只寫「改好」。
    # 路徑先印、結論擺最後：畫面被截斷時留在最後的要是結論。
    if total or nt.warnings():
        say("詳見 %s" % report_path)
    say(fc.verdict(total, nt.collected()))
    return 0


def cmd_semantic(args, settings):
    """把手動算好的語意候選併進既有的連帶決定表；表裡已填的決定不動。"""
    import decision_table as dt
    import semantic_candidates as sc
    # 決定表是就地改寫（人填到一半的欄不能動），所以這一步不會把表搬進新格；
    # 資料夾是舊排法就講一聲，讓人知道整個產出資料夾該重跑一次 compare。
    warn_if_legacy_outdir(outdir_of_table(args.decisions))
    try:
        rows = dt.read_table(args.decisions)
        sidecar = dt.read_sidecar(dt.sidecar_path_for(args.decisions))
        semantic_rows = sc.read_results(args.semantic, expected_sha=sidecar["草稿"]["SHA256"])
    except (dt.DecisionTableError, sc.SemanticError) as exc:
        say("[中止] %s" % exc)
        return 1
    before = len(rows)
    rows = dt.add_semantic(rows, semantic_rows)
    # 重寫表與指紋檔；草稿指紋與異動段落指紋沿用原值。
    # 先寫 .tmp 再 os.replace：中途被中斷也不會把人填了一半的表洗掉。
    dt.write_rows_csv(args.decisions, rows)
    sidecar["列"] = [{"候選段次": dt.line_of(r["候選段次"]),
                     "候選全文SHA256": dt.text_sha256(r["候選全文"])} for r in rows]
    side_path = dt.sidecar_path_for(args.decisions)
    tmp = side_path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(sidecar, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, side_path)
    say("語意候選併入完成：原 %d 列 → %d 列（語意 %d 筆）" % (before, len(rows), len(semantic_rows)))
    say("表：%s" % args.decisions)
    return 0


def cmd_review_pack(args, settings):
    """第 1.5 步：把候選與異動打包成給 AI 看的審查包。"""
    import notices as nt
    import review_pack as rp
    nt.reset()
    warn_if_legacy_outdir(args.outdir)
    try:
        info = rp.write_pack(args.outdir, args.per_file,
                             max_chars=getattr(args, "max_chars", rp.DEFAULT_MAX_CHARS))
    except rp.ReviewPackError as exc:
        say("[中止] %s" % exc)
        # 中止的理由與這一步發過的提醒（例如舊式留底、舊版是猜的）都要留底：
        # 畫面留不住，產出資料夾裡的那一份才是。
        nt.notice(nt.WARNING, "review-pack 中止：%s" % exc, "審查包")
        say("提醒留底：%s" % nt.write_notices(args.outdir, "審查包",
                                              title="review-pack（第 1.5 步）"))
        return 1
    say("提醒留底：%s（%d 則）"
        % (nt.write_notices(args.outdir, "審查包", title="review-pack（第 1.5 步）"),
           len(nt.collected())))
    # 路徑一律帶格子名：光講檔名的話，人在產出資料夾第一層翻不到任何一個檔
    # （審查包在 系統檔案/、要填的兩張表在 填寫表單/）。
    say("下一步：讀 系統檔案/LLM審查包_*.md 與 系統檔案/LLM異動清單.md，"
        "填 填寫表單/AI候選判斷.csv、填寫表單/AI異動審查.csv，再跑 review-import。")
    return 0


def cmd_review_import(args, settings):
    """第 1.5 步：驗證 AI 判斷檔、寫回連帶決定表、產出審查報告。"""
    import notices as nt
    import review_import as ri
    import review_pack as rp
    nt.reset()
    warn_if_legacy_outdir(args.outdir)

    def keep_notices():
        # 驗原文的警告（有幾列候選全文被手改過、沒有匯入）一定要留底：
        # 畫面會被後面的統計與「下一步」洗掉，這份檔案才留得住。
        say("提醒留底：%s（%d 則）"
            % (nt.write_notices(args.outdir, "審查匯入",
                                title="review-import（第 1.5 步）"),
               len(nt.collected())))

    try:
        result = ri.import_review(args.outdir)
    except ri.ReviewError as exc:
        say("[中止] AI 判斷檔有問題，什麼都沒寫：")
        for line in str(exc).splitlines():
            say("  " + line)
        return 1
    except rp.ReviewPackError as exc:
        # import_review 一開始就靠 review_pack.load_book 讀連帶決定表／異動清單／輸入指紋，
        # 這三個檔缺一不可；缺檔是 review_pack.ReviewPackError，不是 ri.ReviewError，
        # 沒接住就會直接噴 traceback，跟其他子命令的「[中止]」風格不一致。
        say("[中止] %s" % exc)
        return 1
    except OSError as exc:
        # import_review 先把 AI 三欄寫回連帶決定表.csv，才產 LLM審查報告.xlsx；
        # 報告那一步常見失敗是檔案還開在 Excel 裡（Windows 鎖檔）——這是 OSError，
        # 不是 ri.ReviewError／rp.ReviewPackError，沒接住就直接噴 traceback。
        say("[中止] 報告寫入失敗：%s" % exc)
        say("連帶決定表已寫回；報告未產生（可能開在 Excel），關掉後重跑 review-import")
        keep_notices()
        return 1
    cand, change = result["候選"], result["異動"]
    say("候選：%s" % "、".join("%s %d 筆" % (v, cand[v]) for v in ri.CAND_VERDICTS))
    say("異動：%s" % "、".join("%s %d 筆" % (v, change[v]) for v in ri.CHANGE_VERDICTS))
    if result.get("原文不符"):
        say("原文不符 %d 列未匯入（列ID %s）；見報告的「%s」表"
            % (len(result["原文不符"]), "、".join(result["原文不符"]), ri.MISMATCH_SHEET))
    # 報告只出一種格式：xlsx 寫得出來就只有 xlsx，寫不出來才退成幾份 csv
    # （write_report 會發一則「已改出 csv」的提醒）。印實際寫出來的那個檔名就好，
    # 不要再叫人去找一堆不存在的 _候選.csv。
    say("報告：%s" % result["報告"])
    keep_notices()
    say("下一步：用 Excel 開 填寫表單/連帶決定表.csv，參考 AI 三欄填「要改嗎」「改成什麼」。"
        "AI 只是建議，最終仍需人工複核。")
    return 0


# ---------------------------------------------------------------------------
# batch：多本一起改
# ---------------------------------------------------------------------------

def _apply_workspace_defaults(args, settings):
    """batch、batch-apply、batch-finalize、batch-review-pack、batch-review-import
    共用：manifest／outdir（review 類是 outdir 那個位置參數）沒給時，退回工作區的
    固定路徑（匯入/規章清單.csv、產出/，見 workspace.paths）；有給就照給的，只補成
    絕對路徑。回傳這次解出來的 workspace.paths() 字典，呼叫端通常用不到，但「開始」
    要沿用同一份 p 印下一步指令，就不用自己再算一次。"""
    import workspace as ws
    root = ws.resolve_root(getattr(args, "workspace", ""), settings)
    p = ws.paths(root)
    if not getattr(args, "manifest", None):
        args.manifest = p["清單"]
    if not getattr(args, "outdir", None):
        args.outdir = p["產出"]
    else:
        args.outdir = os.path.abspath(args.outdir)
    return p


def _add_workspace_flag(p):
    """讓 --workspace 也能接在子命令名稱後面，不是只能放在最前面（配對／開始／批次類
    子命令印出的下一步指令都是「子命令 --workspace 根」這種順序）。預設用
    argparse.SUPPRESS：子命令自己的解析器如果沒吃到 --workspace，就不要去蓋掉最前面
    （頂層 parser）已經解出來的值——頂層與子解析器共用同一個 Namespace，子解析器
    自己的一般預設值（例如 ""）原本會在沒給的時候覆蓋掉頂層已經設好的值。"""
    p.add_argument("--workspace", default=argparse.SUPPRESS,
                   help="工作區根目錄；沒給就看設定.json（可放在子命令名稱前或後）")


def _add_max_chars_flag(p):
    """review-pack／batch-review-pack 的 --max-chars：一份審查包的字元數上限。

    只數區塊數（--per-file）切不住檔案大小：一個候選掛十幾處異動時，單一區塊就
    好幾萬字（實測單檔 13.7 萬字），貼進 AI 直接爆脈絡長度。0 表示不看字數。"""
    import review_pack as rp
    p.add_argument("--max-chars", dest="max_chars", type=int, default=rp.DEFAULT_MAX_CHARS,
                   help="一份 LLM審查包_NN.md 的字元數上限，預設 %d（0＝不限）"
                        % rp.DEFAULT_MAX_CHARS)


def _add_batch_flags(p, runner):
    """batch、開始 共用的旗標（跨本連帶門檻）；同一份定義兩邊都掛，避免以後改一邊
    漏改另一邊。"""
    p.add_argument("--semantic-dir", dest="semantic_dir", default=None,
                   help="放 <規章名>.csv 的資料夾（手動算好的語意候選）")
    p.add_argument("--threshold", type=float, default=None)
    p.add_argument("--top", type=int, default=None)
    p.add_argument("--changed-top", dest="changed_top", type=int, default=8)
    p.add_argument("--sentence-threshold", dest="sentence_threshold", type=float,
                   default=runner.fuzzy.DEFAULT_SENTENCE_THRESHOLD)


def _doc_args(runner, doc, outdir_doc, extra_argv=(), **overrides):
    """用 regdiff 的參數定義做一個 Namespace，跟單本 compare／finalize 同一套預設值。"""
    parser = argparse.ArgumentParser()
    runner.add_compare_arguments(parser)
    argv = [doc["舊版"], doc["草稿"], "--outdir", outdir_doc]
    if doc["發布根目錄"]:
        argv += ["--baseline-release", doc["發布根目錄"]]
    ns = parser.parse_args(argv + list(extra_argv))
    ns.semantic = None
    ns.workspace = ""
    for key, value in overrides.items():
        setattr(ns, key, value)
    return ns


def _batch_semantic(target, all_changes, tname, settings, args, outdir_doc):
    """每本寫語意輸入.json（異動＝所有本）；依序試 --semantic-dir 交回檔、本機模型。

    回傳 (rows, needs_manual)。needs_manual 只有在「沒用到 --semantic-dir 的檔，
    而且這台電腦沒設模型路徑或模型載不起來」時才是真；模型跑過但一筆都沒中不算。"""
    import semantic_candidates as sc
    draft = target["doc"]["草稿"]
    draft_sha = file_sha256(draft)
    # 語意輸入／語意候選是程式接力用的中繼檔 → 系統檔案/（跟單本 compare 一致）
    input_path = place(outdir_doc, "語意輸入.json")
    sc.write_input(input_path, draft, draft_sha, all_changes, target["outcome"]["new_paragraphs"], target_name=tname)
    if getattr(args, "semantic_dir", None):
        path = os.path.join(args.semantic_dir, tname + ".csv")
        if os.path.isfile(path):
            try:
                rows = sc.read_results(path, expected_sha=draft_sha)
                say("  語意候選：讀入 %s（%d 筆）" % (path, len(rows)))
                return rows, False
            except sc.SemanticError as exc:
                say("  [中止] 語意候選檔不能用：%s" % exc)
                raise
    model_path = settings.get("語意模型路徑", "")
    if not model_path:
        return [], True
    embed = sc.load_model(model_path, recall_top=_semantic_recall_top(settings))
    if embed is None:
        return [], True
    rows = sc.find_candidates(embed, all_changes, target["outcome"]["new_paragraphs"],
                              _semantic_threshold(settings),
                              int(settings.get("語意最多幾筆", sc.DEFAULT_TOP)), target_name=tname)
    sc.write_results(place(outdir_doc, "語意候選.csv"), rows, draft_sha)
    return rows, False


def cmd_batch(args, settings):
    import batch as bt
    import decision_table as dt
    import fuzzy_duplicate_finder as fuzzy
    import notices as nt
    import semantic_candidates as sc
    import workspace as ws
    from _common import load_synonyms
    # item3：outdir 是不是「呼叫端明給的」，要在 _apply_workspace_defaults 把它補成
    # 工作區預設值*之前*判斷——判斷完才能補。cmd_start 呼叫這裡之前已經自己歸檔過
    # 一次（archive_previous），且會把 ns.outdir 明確設成 p["產出"]（見 cmd_start），
    # 所以從 cmd_start 進來時 outdir_was_explicit 一定是 True，不會落進下面「省略
    # outdir」的分支、不會歸檔第二次；只有使用者直接跑 `batch`（不給 --outdir）
    # 才會落到這裡幫忙歸檔上一輪，不然直接跑 batch 會把上一輪的產出整個蓋掉。
    outdir_was_explicit = bool(getattr(args, "outdir", ""))
    p = _apply_workspace_defaults(args, settings)
    try:
        docs = bt.read_manifest(args.manifest)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    outdir = args.outdir
    # no 10：批次的每一本輸入檔由 bt.read_manifest 驗過了，產出根目錄這裡驗一次
    # 就夠——不然歸檔完、第一本跑到一半才發現整個產出根目錄寫不進去。
    problem = precheck(outdir)
    if problem:
        say("[中止] %s" % problem)
        return 1
    if not outdir_was_explicit:
        names = [doc["規章名"] for doc in docs]
        try:
            moved = ws.archive_previous(p["根"], names)
        except ws.WorkspaceError as exc:
            say("[中止] %s" % exc)
            return 1
        if moved:
            stamp = os.path.basename(moved[0])
            say("已歸檔上一輪：%s（搬了 %d 處：%s）" % (stamp, len(moved), "，".join(moved)))
    stage_inputs(outdir, [args.manifest])
    # batch.list_books（batch-review-pack／batch-review-import 用）固定讀
    # <outdir>/系統檔案/輸入/規章清單.csv；stage_inputs 只是把使用者的原始檔複製進去，
    # 檔名照抄。使用者的清單如果不叫這個名字，後面兩支子命令會直接找不到檔案。
    # 這裡另存一份固定檔名，來源檔名本來就是它就不用再複製一次。
    manifest_name = os.path.basename(args.manifest)
    if manifest_name != "規章清單.csv":
        staged = place(outdir, "輸入")
        shutil.copy2(os.path.join(staged, manifest_name),
                     os.path.join(staged, "規章清單.csv"))
    runner = load_regdiff_runner()
    synonyms = load_synonyms()
    threshold = args.threshold if args.threshold is not None else fuzzy.DEFAULT_THRESHOLD
    top = args.top if args.top is not None else fuzzy.DEFAULT_TOP

    state = {}
    for doc in docs:
        name = doc["規章名"]
        say("=" * 60)
        say("批次　%s" % name + ("" if doc["有草稿"] else "（沒有草稿，用舊版當草稿）"))
        say("=" * 60)
        outdir_doc = os.path.join(outdir, name)
        ns = _doc_args(runner, doc, outdir_doc, ["--threshold", str(threshold), "--top", str(top),
                                                 "--changed-top", str(args.changed_top),
                                                 "--sentence-threshold", str(args.sentence_threshold)])
        # 裁定 7：批次裡沒改的本用「提醒」不用「警告」——十本裡有兩本這次沒動很正常，
        # 用警告會讓整批的結論被一件正常的事翻掉。沒有草稿的本另外講清楚原因，
        # 不然那則提醒會寫成「可能拿錯檔」，但它其實是照設計拿舊版當草稿在跑。
        ns.zero_change_level = nt.REMINDER
        if not doc["有草稿"]:
            ns.zero_change_text = ("這本沒有草稿，照設定拿舊版當草稿比對，所以不會有任何"
                                   "實質異動；草稿出來之後要再跑一次 batch")
        # 這裡先不寫表：整批任何一本的第 0、1 步沒過就中止，不留半套決定表。
        rc, outcome, rows, _ = _compare_core(ns, settings, final=False, write_table=False)
        if rc:
            say("[中止] %s 初比對失敗，整批停止。" % name)
            return 1
        baseline = outcome["baseline"]
        results = outcome["results"]
        new_line_ids = baseline.annotate_results(results) if baseline else {}
        changes = []
        for r in results:
            if r["type"] in ("added", "modified") and r.get("new_text"):
                ids = r.get("spec_ids") or []
                changes.append({"條文ID": "、".join(ids), "ref": r.get("ref") or "",
                                "old_text": r.get("old_text") or "", "new_text": r["new_text"],
                                "段次": r.get("new_index") or 0,
                                "positions": [baseline._position(i) for i in ids] if baseline else []})
        # 這一本的提醒收走（各本的 提醒.txt 已經由 run_compare 寫進各自的子資料夾）。
        # 不收走的話下一本的提醒會連著前一本一起算，批次摘要的數字就對不上。
        state[name] = {"doc": doc, "outdir": outdir_doc, "outcome": outcome, "rows": rows,
                       "baseline": baseline, "new_line_ids": new_line_ids, "changes": changes,
                       "跨本來自": set(), "提醒": nt.drain()}

    for tname, t in state.items():
        cross = []
        for sname, s in state.items():
            if sname == tname or not s["changes"]:
                continue
            found = bt.cross_candidates(sname, s["changes"], t["outcome"]["new_paragraphs"],
                                        synonyms, threshold, top, args.changed_top,
                                        sentence_threshold=args.sentence_threshold,
                                        target_kinds=t["outcome"].get("new_kinds"))
            if t["baseline"]:
                found += bt.citation_links(sname, s["changes"], t["baseline"], t["new_line_ids"],
                                           t["outcome"]["new_paragraphs"])
            if found:
                t["跨本來自"].add(sname)
            cross += found
        t["rows"] = dt.add_cross(t["rows"], cross)

    all_changes = [{"段次": c["段次"], "全文": c["new_text"], "舊全文": c.get("old_text") or "",
                    "條文ID": c["條文ID"], "規章": name}
                   for name, s in state.items() for c in s["changes"]]
    manual = []
    stats = []
    for tname, t in state.items():
        try:
            sem_rows, needs_manual = _batch_semantic(t, all_changes, tname, settings, args, t["outdir"])
        except sc.SemanticError:
            return 1
        if sem_rows:
            t["rows"] = dt.add_semantic(t["rows"], sem_rows)
        if needs_manual and all_changes:
            manual.append(tname)
        changed_texts = [r["new_text"] for r in t["outcome"]["results"] if r["type"] in ("added", "modified")]
        # 各本的產出跟單本 compare 走同一套去向：決定表 → 填寫表單/，
        # 指紋與異動清單 → 系統檔案/。（批次自己那幾個根層級的檔留給 Task 4。）
        csv_path = place(t["outdir"], "連帶決定表.csv")
        dt.write_table(t["rows"], csv_path, dt.sidecar_path_for(csv_path), t["doc"]["草稿"],
                       changed_texts, extra={"規章": tname},
                       params={"threshold": threshold, "top": top,
                              "changed_top": args.changed_top,
                              "sentence_threshold": args.sentence_threshold})
        dt.write_change_list(t["outcome"]["results"], place(t["outdir"], "異動清單.json"))
        # 一列只算一次（小瑕疵 13）：跟單本 compare 共用 source_distribution，
        # 批次摘要與畫面上那一行括號內的數字加起來才等於候選列數。
        # 以前這裡是「每列的來源逐個標籤各記一次」，同時被相似度與語意抓到的列
        # 會被算兩遍，總和大於候選數，人會以為表上少了幾列。
        dist = source_distribution(t["rows"])
        stats.append({"規章名": tname, "有草稿": t["doc"]["有草稿"], "實質異動": len(t["changes"]),
                      "候選": len(t["rows"]), "來源分佈": dist, "跨本來自": sorted(t["跨本來自"]),
                      # t["changes"] 只收 added／modified（跨本比對要新文），刪除型不在裡面，
                      # 拿它判「這本有沒有改」會把「整本只刪了幾條」誤報成沒改。
                      # 零異動一律用 run_compare 自己算的那一個旗標。
                      "零異動": bool(t["outcome"].get("零異動")),
                      "提醒": t["提醒"]})

    # 批次摘要是「人要看」的那一份 → 產出根目錄的 審閱文件/（見 _common.FILE_HOMES）。
    # write_batch_summary 的簽名不變（呼叫端給路徑），去向一律由 place 決定。
    summary_path = bt.write_batch_summary(place(outdir, "批次摘要.txt"), stats)
    # 手動語意指令放在數字前面印：畫面截斷時留在最後的是每本的數字。
    if manual:
        say("")
        say("語意候選（BGE-M3）：這台電腦沒模型。各本的 語意輸入.json 已寫好；在有模型的電腦逐本跑")
        say("  python semantic_candidates.py <產出>/<規章名>/系統檔案/語意輸入.json "
            "<某資料夾>/<規章名>.csv --model <模型資料夾>")
        say("  算好後逐本併入（不會洗掉已填的決定）："
            "python run_all.py semantic <產出>/<規章名>/填寫表單/連帶決定表.csv <某資料夾>/<規章名>.csv")
        say("  （--semantic-dir 只在還沒開始填表時使用：重跑 batch 會整份重建決定表。）")
        say("  要算的本：%s" % "、".join(manual))
    say("")
    say("=" * 60)
    say("批次初比對完成")
    say("=" * 60)
    for s in stats:
        say("%s：實質異動 %d、候選 %d（%s）%s，提醒 %d 則" % (
            s["規章名"], s["實質異動"], s["候選"],
            "、".join("%s %d" % kv for kv in sorted(s["來源分佈"].items())) or "無",
            "，跨本來自 " + "、".join(s["跨本來自"]) if s["跨本來自"] else "",
            len(s.get("提醒") or [])))
    zero_books = [s["規章名"] for s in stats if s.get("零異動")]
    say("無異動 %d 本：%s" % (len(zero_books), "、".join(zero_books) or "無"))
    say("摘要：%s（含各本提醒彙整）" % summary_path)
    say("下一步：逐本用 Excel 開 <產出>/<規章名>/填寫表單/連帶決定表.csv 填決定，再跑 batch-apply。"
        "最終仍需人工複核。")
    return 0


def cmd_batch_apply(args, settings):
    import notices as nt
    import apply_changes as ac
    import batch as bt
    import decision_table as dt
    _apply_workspace_defaults(args, settings)
    try:
        docs = bt.read_manifest(args.manifest)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    outdir = args.outdir
    ok, failed = [], []
    blocked_books = []        # [(規章名, 程式做不到的跳過列數)]
    for doc in docs:
        name = doc["規章名"]
        outdir_doc = os.path.join(outdir, name)
        # 這一則要在這本的 ac.apply 之前發：apply 一開頭 nt.reset()，結束時
        # nt.write_notices(outdir_doc) 才會把它寫進**這一本**的 提醒.txt。
        # 放在迴圈外的話，第二本的那一則會被寫進第一本的檔案裡。
        warn_if_legacy_books(outdir, [name])
        csv_path = locate(outdir_doc, "連帶決定表.csv")[0]
        say("=" * 60)
        say("batch-apply　%s" % name)
        say("=" * 60)
        # 跳過與失敗的兩條路都沒有走到 ac.apply 的 write_notices：上面那一則
        # 舊排法提醒會留在 pending 裡，被下一本的 apply 寫進**下一本**的 提醒.txt
        # （審查發現）。所以這兩條路要自己把這一本的提醒寫掉再 continue。
        if not os.path.isfile(csv_path):
            say("[跳過] 找不到 %s" % csv_path)
            failed.append(name)
            # entries=nt.drain()：連 apply 失敗時已經收進清單的那幾則一起帶走並清空，
            # 不然下一本被跳過時（沒有 apply 來 reset）會把上一本的警告寫進自己的檔案。
            nt.write_notices(outdir_doc, append=True, title="batch-apply（跳過）",
                             entries=nt.drain())
            continue
        try:
            summary = ac.apply(doc["草稿"], csv_path, outdir_doc)
        except (ac.ApplyError, dt.DecisionTableError) as exc:
            say("[失敗] %s" % exc)
            failed.append(name)
            nt.write_notices(outdir_doc, append=True, title="batch-apply（失敗）",
                             entries=nt.drain())
            continue
        for key, value in sorted(summary["統計"].items()):
            say("  %-14s %d 列" % (key, value))
        blocked = ac.blocked_rows(summary["統計"])
        if blocked:
            say("[警告] " + ac.blocked_message(summary["統計"]))
            blocked_books.append((name, blocked))
        ok.append(name)
    say("")
    say("batch-apply 完成：成功 %s；失敗 %s" % ("、".join(ok) or "無", "、".join(failed) or "無"))
    # 「成功」是指 apply 跑完沒例外，不是「每一列都改到了」。哪幾本有程式沒改到的
    # 列要在結尾再列一次：一次十幾本，中間那一行 [警告] 早就被捲走了（no 35）。
    if blocked_books:
        say("程式沒改到：%s（finalize 會算成未改到）"
            % "、".join("%s %d 列" % (name, count) for name, count in blocked_books))
    say("定稿請在有 Word 的電腦開一次確認。最終仍需人工複核。")
    return 1 if failed else 0


def cmd_batch_finalize(args, settings):
    """批次第 4 步。兩階段：先逐本終比對，全部跑完再拿各本定稿重算跨本連帶。

    為什麼一定要有第 2 階段：batch 第 1 步算過一次跨本連帶，但那是拿各本**草稿**
    算的。定稿是套用決定之後的東西——改掉的字跟草稿不一樣，也可能整段是新增的；
    草稿那一輪的跨本候選在定稿上不一定還成立，定稿之間也可能撞出新的一組。
    不重算的話，第三問「新候選」在批次這條產線上永遠不含跨本，而三問全部是零
    會被讀成「跨本也沒事」——那正是這一步要擋的誤會。
    """
    import batch as bt
    import decision_table as dt
    import notices as nt
    _apply_workspace_defaults(args, settings)
    try:
        docs = bt.read_manifest(args.manifest)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    runner = load_regdiff_runner()
    outdir = args.outdir
    # 這裡不用另外接舊排法提醒：每一本都走 _finalize_core，那一支已經用
    # outdir_of_table(決定表) 驗過這本的產出資料夾，各本的提醒也寫在各本的檔裡。
    failed = []
    stopped = {}       # 規章名 -> 摘要那一行（跳過／失敗的本，第 2 階段不參與）
    state = {}
    for doc in docs:
        name = doc["規章名"]
        outdir_doc = os.path.join(outdir, name)
        clean = locate(outdir_doc, "新版_定稿_乾淨版.docx")[0]
        csv_path = locate(outdir_doc, "連帶決定表.csv")[0]
        say("=" * 60)
        say("batch-finalize　%s" % name)
        say("=" * 60)
        if not os.path.isfile(clean) or not os.path.isfile(csv_path):
            say("[跳過] 缺乾淨版或決定表：%s" % outdir_doc)
            failed.append(name)
            stopped[name] = "%s：跳過（缺乾淨版或決定表）" % name
            continue
        # batch-finalize 的 CLI 沒開放 --threshold／--top／--changed-top／
        # --sentence-threshold 這幾個旗標（跟單本 finalize 不一樣），一律讀這本自己
        # 初比對指紋檔的「比對參數」沿用；指紋檔是這個功能之前產生的、沒記這個鍵，
        # 才退回 regdiff 的硬預設（_compare_params_with_fallback 處理）。
        try:
            init_sidecar = dt.read_sidecar(dt.sidecar_path_for(csv_path))
        except dt.DecisionTableError as exc:
            say("[跳過] %s" % exc)
            failed.append(name)
            stopped[name] = "%s：跳過（指紋檔讀不出來）" % name
            continue
        recorded_params = init_sidecar.get("比對參數")
        params = _compare_params_with_fallback(runner, recorded_params)
        if recorded_params:
            _say_inherited_params("終比對沿用初比對門檻", params)
        extra_argv = ["--threshold", str(params["threshold"]), "--top", str(params["top"]),
                     "--changed-top", str(params["changed_top"]),
                     "--sentence-threshold", str(params["sentence_threshold"])]
        ns = _doc_args(runner, dict(doc, 草稿=clean), outdir_doc, extra_argv, decisions=csv_path)
        info = {}
        rc, answers, report_path, _ = _finalize_core(ns, settings, extra=info)
        if rc:
            failed.append(name)
            stopped[name] = "%s：失敗" % name
            continue
        # 這一本的提醒收走再算下一本，數字才不會累加（run_compare 會 reset，
        # 但 _warn_if_clean_has_revisions 是比對之後才發的，要在這裡收）。
        state[name] = {"doc": doc, "outdir": outdir_doc, "clean": clean, "info": info,
                       "answers": answers, "report_path": report_path,
                       "提醒": nt.drain(), "params": params}

    _batch_finalize_cross(state)

    lines = ["批次驗收摘要", "",
             "跨本連帶已用各本定稿重算：每一本第三問的「新候選」都含跨本候選"
             "（括號裡是其中幾列來自跨本）。", ""]
    for doc in docs:
        name = doc["規章名"]
        lines.append(state[name]["摘要行"] if name in state else stopped[name])
    path = place(outdir, "批次驗收摘要.txt")
    with io.open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")
    # 各本的提醒寫在各自子資料夾（run_compare 寫的 最終版_提醒.txt）；各本的提醒在
    # 第 1 階段就 drain 走了，這裡剩下的是跨本那一階段自己發的（正常情況一則都沒有，
    # 照樣寫一份空的：「這次沒有提醒」跟「這個功能沒跑到」要看得出差別）。
    # 檔名不能跟各本的 提醒.txt 撞名，不然人分不出這一份講的是哪一個範圍。
    nt.write_notices(outdir, "批次", title="batch-finalize（批次驗收）", entries=nt.drain())
    say("")
    for line in lines[2:]:
        say(line)
    say("摘要：%s" % path)
    say("最終仍需人工複核後才能送出。")
    return 1 if failed else 0


def _batch_finalize_cross(state):
    """batch-finalize 第 2 階段：拿各本定稿重算跨本連帶，補進各本的第三問。

    每一本補完之後要重寫兩份已經寫過的產出，不能只改畫面上的數字：
    終比對驗收報告.txt（那是「可不可以送出」的那張紙）與 終比對候選表.xlsx
    （報告說第三問有幾列，表上就要找得到那幾列）。

    一本都沒成功、或只剩一本成功時，這裡自然湊不出來源本，每本照樣寫「含跨本 0」。
    """
    import batch as bt
    import decision_table as dt
    import finalize_check as fc
    import notices as nt
    from _common import load_synonyms
    synonyms = load_synonyms()
    for book in state.values():
        outcome = book["info"]["outcome"]
        results = outcome["results"]
        baseline = outcome["baseline"]
        book["baseline"] = baseline
        # annotate_results 在 _compare_core 裡已經對同一份 results 跑過一次，
        # 這裡再叫一次只是為了拿 new_line_ids（引用連帶要用），跟 cmd_batch 一樣。
        book["new_line_ids"] = baseline.annotate_results(results) if baseline else {}
        # 跨本比對要的是「改成什麼樣子」，所以只收 added／modified 且有新文的；
        # 欄位與 cmd_batch 第 1 步組 changes 的那一段一模一樣。
        changes = []
        for r in results:
            if r["type"] in ("added", "modified") and r.get("new_text"):
                ids = r.get("spec_ids") or []
                changes.append({"條文ID": "、".join(ids), "ref": r.get("ref") or "",
                                "old_text": r.get("old_text") or "", "new_text": r["new_text"],
                                "段次": r.get("new_index") or 0,
                                "positions": [baseline._position(i) for i in ids] if baseline else []})
        book["changes"] = changes

    for tname, t in state.items():
        outcome = t["info"]["outcome"]
        params = t["params"]
        cross = []
        sources = set()
        for sname, s in state.items():
            if sname == tname or not s["changes"]:
                continue
            found = bt.cross_candidates(sname, s["changes"], outcome["new_paragraphs"],
                                        synonyms, params["threshold"], params["top"],
                                        params["changed_top"],
                                        sentence_threshold=params["sentence_threshold"],
                                        target_kinds=outcome.get("new_kinds"))
            if t["baseline"]:
                found += bt.citation_links(sname, s["changes"], t["baseline"],
                                           t["new_line_ids"], outcome["new_paragraphs"])
            if found:
                sources.add(sname)
            cross += found
        info = t["info"]
        # 跨本列也要過第三問那把尺（fc.fresh_rows）：初比對決定表列過的、初比對的
        # 異動段落、人填「改」時指定的「改成什麼」，都不算「定稿冒出來的新候選」。
        # 兩邊共用同一支，才不會同一列在單本報告算新候選、在批次不算。
        fresh_cross = fc.fresh_rows(info["decision_rows"], info["sidecar"],
                                    dt.add_cross([], cross))
        answers = t["answers"]
        # 同一段在第一階段已經是「新候選」（這本自己的終比對抓到的）時不再加一次：
        # 候選表那邊 add_cross 是併進同一列，第三問這邊不去重就會同一段算兩筆。
        seen_lines = {(r.get("候選段次") or "").strip() for r in answers["新候選"]}
        fresh_cross = [r for r in fresh_cross
                       if (r.get("候選段次") or "").strip() not in seen_lines]
        answers["新候選"] = list(answers["新候選"]) + fresh_cross
        # 新鍵，只給摘要那一行用；不在 fc.BLOCKING_KEYS 裡，不會被重複計入結論。
        answers["跨本新候選數"] = len(fresh_cross)
        info["final_rows"] = dt.add_cross(info["final_rows"], cross)
        # 跟單本終比對（_compare_core 的 final=True）走同一條路：表進 審閱文件/ 的
        # 終比對候選表.xlsx，指紋 .json 進 系統檔案/。兩邊寫法不一樣的話，
        # batch-finalize 補完跨本列會在同一個資料夾裡多長出一張舊格式的 csv。
        table_path = place(t["outdir"], "終比對候選表.xlsx")
        changed_texts = [r["new_text"] for r in outcome["results"]
                         if r["type"] in ("added", "modified")]
        try:
            dt.write_table(info["final_rows"], table_path, dt.sidecar_path_for(table_path),
                           t["clean"], changed_texts, params=params, fmt="xlsx")
        except OSError as exc:
            # 表寫不進去（最常見是還開在 Excel 裡）不能就這樣算了：報告會說第三問有
            # 幾列跨本，表上卻找不到那幾列。降級成警告留底，結論也會跟著保留。
            nt.notice(nt.WARNING,
                      "%s 的 終比對候選表 補跨本列時寫不進去（%s）；報告的第三問已含跨本，"
                      "但這張表還是補跨本之前的版本，關掉檔案後重跑 batch-finalize"
                      % (tname, exc), "batch-finalize")
        # 成功也要收：write_table 內部退成 csv 時（xlsx 被鎖住）會自己發一則
        # 「xlsx 寫不出來…已改出 csv」，那一則屬於**這一本**。不收走的話它會留在
        # 全域清單裡，被下一本的收提醒動作掃進下一本的報告，或一路漏到最後的
        # 批次_提醒.txt——講的是甲的表，卻寫在乙的那張紙上。
        t["提醒"] = t["提醒"] + nt.drain()
        # 報告要在表之後才重寫：上面那幾則也要出現在這一本的報告裡。
        fc.write_report(answers, info["report_path"], notices=t["提醒"])
        total = fc.blocking_total(answers)
        alerts = nt.warnings(t["提醒"])
        if total == 0 and alerts:
            verdict = "三問皆零但有警告，請先看提醒再決定是否送出"
        elif total == 0:
            verdict = "改好"
        else:
            verdict = "還有 %d 處要看，請勿送出" % total
        t["摘要行"] = ("%s：%s（未改到 %d、未決定 %d、新候選 %d（含跨本 %d）、填了但等於原文 %d）"
                      "／提醒 %d 則／警告 %d 則%s" % (
                          tname, verdict, len(answers["未改到"]), len(answers["未決定"]),
                          len(answers["新候選"]), len(fresh_cross),
                          len(answers.get(fc.SAME_TEXT_KEY) or []),
                          len(t["提醒"]), len(alerts),
                          "／跨本來自 " + "、".join(sorted(sources)) if sources else ""))


def cmd_batch_review_pack(args, settings):
    """批次第 1.5 步：逐本把候選與異動打包成審查包；loaded 讓跨本候選（異動條文ID
    是「A名：ref」那種）能到來源本查到異動全文，不用只看自己這本。

    兩階段：先逐本 rp.load_book 收集錯誤，任何一本讀不出來就整批「[中止]」、
    一個字都不寫；全部讀成功才逐本 write_pack。這樣「某本半路才發現壞掉」不會
    連累前面已經成功寫出的審查包（write_pack 是覆寫，半路中止會留下新舊混雜的
    產出）。loaded_books 傳給 write_pack 後，每本只在這裡 load_book 一次
    （不管是當自己還是被別本拿去跨本引用），不再是 N 本 N² 次讀檔。"""
    import batch as bt
    import notices as nt
    import review_pack as rp
    _apply_workspace_defaults(args, settings)
    nt.reset()
    outdir = args.outdir
    try:
        book_list = bt.list_books(outdir)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    warn_if_legacy_books(outdir, [name for name, _ in book_list])

    all_errors = []
    loaded = {}
    for name, outdir_doc in book_list:
        try:
            loaded[name] = rp.load_book(outdir_doc)
        except rp.ReviewPackError as exc:
            all_errors.append("%s：%s" % (name, exc))
    if all_errors:
        say("[中止] 有本讀不到，整批沒寫：")
        for line in all_errors:
            say("  " + line)
        return 1

    # load_book 那一輪與底下 write_pack 那一輪都可能發提醒（某本是舊式留底、
    # 舊版是用檔名猜的、AI CSV 已有填答沒覆寫……）。畫面上印過了，但批次的畫面
    # 特別長，一定要同時留一份在產出根目錄——所以留底要等 write_pack 跑完才寫，
    # 中途中止也要先寫再走。
    def keep_notices():
        say("提醒留底：%s（%d 則）"
            % (nt.write_notices(outdir, "批次審查包",
                                title="batch-review-pack（批次第 1.5 步）"),
               len(nt.collected())))

    # 第二階段一本失敗就整批停在那裡：前面幾本的審查包已經是新的、後面幾本還沒動，
    # 一定要講清楚是哪幾本更新了（實測 no 25：舊寫法沒有 try，直接噴 traceback，
    # 人看不出前面幾本到底寫了沒）。
    done = []
    for name, outdir_doc in book_list:
        try:
            info = rp.write_pack(outdir_doc, args.per_file, loaded_books=loaded, quiet=True,
                                 max_chars=getattr(args, "max_chars", rp.DEFAULT_MAX_CHARS))
        except (rp.ReviewPackError, OSError) as exc:
            say("[中止] %s 寫審查包失敗：%s；已完成 %d 本（%s），"
                "這幾本的審查包已更新，其餘 %d 本沒動"
                % (name, exc, len(done), "、".join(done),
                   len(book_list) - len(done) - 1))
            keep_notices()
            return 1
        done.append(name)
        line = ("%s：候選 %d 筆、異動 %d 處、審查包 %d 份"
                % (name, info["候選數"], info["異動數"], len(info["包"])))
        if info.get("保留填答"):
            line += "（已保留既有填答：%s）" % "、".join(info["保留填答"])
        say(line)
    keep_notices()
    say("下一步：逐本讀 <產出根目錄>/<規章名>/系統檔案/LLM審查包_*.md 與 "
        "<產出根目錄>/<規章名>/系統檔案/LLM異動清單.md，填 <產出根目錄>/<規章名>/"
        "填寫表單/AI候選判斷.csv、填寫表單/AI異動審查.csv，再跑 batch-review-import。")
    return 0


def cmd_batch_review_import(args, settings):
    """批次第 1.5 步：先逐本只驗證兩張 AI CSV，任何一本有錯就整批中止、什麼都不寫；
    全部過了才逐本把三欄寫回連帶決定表、產各本報告，最後把三張表跨本併成
    LLM審查總表.xlsx（每列都帶「規章」欄，看得出是哪一本）。"""
    import batch as bt
    import notices as nt
    import review_import as ri
    import review_pack as rp
    _apply_workspace_defaults(args, settings)
    nt.reset()
    outdir = args.outdir

    def keep_notices():
        # 驗原文的警告（哪幾本的哪幾列候選全文被手改過）一定要留底：批次的畫面
        # 特別長，這幾則最容易被後面的逐本統計洗掉。
        say("提醒留底：%s（%d 則）"
            % (nt.write_notices(outdir, "批次審查匯入",
                                title="batch-review-import（批次第 1.5 步）"),
               len(nt.collected())))

    try:
        book_list = bt.list_books(outdir)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    warn_if_legacy_books(outdir, [name for name, _ in book_list])

    all_errors = []
    loaded = {}
    for name, outdir_doc in book_list:
        try:
            book = rp.load_book(outdir_doc)
            ai_cand, ai_change, ai_meta = ri.load_ai_files(outdir_doc)
        except (rp.ReviewPackError, ri.ReviewError) as exc:
            all_errors.append("%s：%s" % (name, exc))
            continue
        loaded[name] = book
        errors = ri.validate(book["rows"], book["changes"], ai_cand, ai_change, ai_meta)
        all_errors += ["%s：%s" % (name, e) for e in errors]
    if all_errors:
        say("[中止] AI 判斷檔有問題，整批沒寫：")
        for line in all_errors:
            say("  " + line)
        return 1

    # 「原文已修改未匯入」只有在某本真的驗到不符時才會出現，所以工作表清單不能寫死
    # 三張：用 sheet_order 記實際出現過的順序，rows_by_sheet 也跟著 setdefault。
    # （寫死三張時，某本多出第四張表會讓總表這一段 KeyError 噴 traceback。）
    sheet_order = []
    headers = {}
    rows_by_sheet = {}
    mismatch_total = 0
    done_count = 0
    name = None
    try:
        for name, outdir_doc in book_list:
            # book=loaded[name]：這本第一階段（驗證）已經 load_book 過一次，
            # 這裡不用再重讀一次連帶決定表／異動清單／docx。
            result = ri.import_review(outdir_doc, book_name=name, books=loaded, book=loaded[name])
            for sheet, header, rows in result["表"]:
                if sheet in headers and headers[sheet] != header:
                    raise bt.BatchError("總表欄位不一致：%s" % sheet)
                if sheet not in headers:
                    sheet_order.append(sheet)
                headers.setdefault(sheet, header)
                rows_by_sheet.setdefault(sheet, []).extend(rows)
            cand, change = result["候選"], result["異動"]
            line = ("%s：候選 %s；異動 %s" % (
                name, "、".join("%s %d 筆" % (v, cand[v]) for v in ri.CAND_VERDICTS),
                "、".join("%s %d 筆" % (v, change[v]) for v in ri.CHANGE_VERDICTS)))
            if result.get("原文不符"):
                line += "；原文不符 %d 列未匯入（列ID %s）" % (
                    len(result["原文不符"]), "、".join(result["原文不符"]))
                mismatch_total += len(result["原文不符"])
            say(line)
            done_count += 1
    except (ri.ReviewError, rp.ReviewPackError, OSError, bt.BatchError) as exc:
        # 這本已經在第一階段驗證過，理論上不會再失敗；防禦式地照樣中止，別讓
        # traceback 洩出去。前面成功匯入的本，決定表與各本報告已經真的寫了
        # （import_review 一本一本各自獨立寫），總表沒寫出來，整批視為沒完成，
        # 下次重跑 batch-review-import 會照 import_review 的寫回邏輯整批重寫。
        say("[中止] %s 寫入失敗：%s" % (name, exc))
        say("前面 %d 本已寫入（AI 三欄與各本報告），總表未產生；修正後重跑 batch-review-import 會整批重寫。"
            % done_count)
        keep_notices()
        return 1

    # 逐本迴圈與總表寫入分開接：迴圈跑完 name 還留著最後一本的值，如果總表寫入
    # （迴圈外）本身失敗，跟上面那段共用同一個 except 會把總表的失敗講成是最後
    # 一本的失敗——但那本其實已經成功寫完了，錯的是總表這一步，要單獨講清楚。
    tables_all = [(sheet, headers[sheet], rows_by_sheet[sheet]) for sheet in sheet_order]
    try:
        # 總表跟各本的 LLM審查報告 一樣是人要看的 → 審閱文件/。place 回傳帶副檔名的
        # 路徑，write_report 要的是不帶副檔名的 base（它自己決定寫 xlsx 還是退 csv）。
        xlsx_path = ri.write_report(
            os.path.splitext(place(outdir, "LLM審查總表.xlsx"))[0], tables_all)
    except OSError as exc:
        say("[中止] 總表寫入失敗：%s" % exc)
        say("各本已寫入（%d 本）；只有總表沒產生，關掉 LLM審查總表.xlsx 再重跑" % done_count)
        keep_notices()
        return 1
    if mismatch_total:
        say("原文不符 %d 列未匯入（跨 %d 本合計）；見總表的「%s」表"
            % (mismatch_total, done_count, ri.MISMATCH_SHEET))
    say("總表：%s" % xlsx_path)
    keep_notices()
    say("下一步：逐本用 Excel 開 <產出根目錄>/<規章名>/填寫表單/連帶決定表.csv，參考 AI 三欄填"
        "「要改嗎」「改成什麼」。AI 只是建議，最終仍需人工複核。")
    return 0


# ---------------------------------------------------------------------------
# 工作區：配對／開始
# ---------------------------------------------------------------------------

def cmd_pair(args, settings):
    """配對：把 匯入/舊版、匯入/新版 的檔名配對，寫 匯入/規章清單.csv 給人確認。

    寫清單前先讀既有清單（有的話），把「手動」列蓋回這次重算的結果
    （workspace.merge_manual），人填過的舊版／新版草稿／發布根目錄／備註才不會
    被自動配對整份覆蓋。"""
    import batch as bt
    import notices as nt
    import workspace as ws
    from _common import SUPPORTED_EXTS
    root = ws.resolve_root(args.workspace, settings)
    created = ws.ensure_layout(root)
    if created:
        say("已建立工作區：%s" % root)
    p = ws.paths(root)
    old_names, old_skipped = ws.list_inputs(p["舊版"])
    new_names, new_skipped = ws.list_inputs(p["新版"])
    # no 14：不支援的副檔名以前是安靜跳過的——使用者丟十本進來，畫面寫「配對 8 本」，
    # 少的那兩本（.doc、.pdf）連一行字都沒有。走 notices 才會同時上畫面與留底。
    skipped = ["舊版/%s" % n for n in old_skipped] + ["新版/%s" % n for n in new_skipped]
    if skipped:
        nt.notice(nt.REMINDER,
                  "略過 %d 個不支援的檔：%s（只認 %s）"
                  % (len(skipped), "、".join(skipped), "/".join(SUPPORTED_EXTS)), "配對")
    # M3：白名單放寬之後，匯入夾裡的 .txt／.md 會變成一本規章——這對「草稿就是
    # 純文字」的人是對的，對「放了一張備忘或說明檔」的人是驚嚇（清單突然多一本、
    # 過期檢查還會要求把它列進去）。所以只要真的收了 .txt／.md 就講一聲。
    texts = (["舊版/%s" % n for n in old_names if not n.lower().endswith(".docx")]
             + ["新版/%s" % n for n in new_names if not n.lower().endswith(".docx")])
    if texts:
        nt.notice(nt.REMINDER,
                  "匯入/ 有 %d 個 .txt/.md 檔已當成規章：%s；若是備忘或說明檔請移走"
                  % (len(texts), "、".join(texts)), "配對")
    spec_names = ws.list_spec_names(p["規格包"])
    auto_rows = ws.match(old_names, new_names, spec_names)
    try:
        old_rows = ws.read_manifest_rows(p["清單"]) if os.path.isfile(p["清單"]) else []
    except ws.WorkspaceError as exc:
        # item5：既有清單本身壞掉（缺欄位、配對方式亂填）不該噴 traceback——跟其他
        # 子命令一致，印「[中止]」、exit 1，讓人去看清單哪裡壞了。
        say("[中止] %s" % exc)
        return 1
    rows, kept_names, dropped_names, draft_missing = ws.merge_manual(auto_rows, old_rows, root)
    try:
        ws.write_manifest(rows, p["清單"])
    except OSError as exc:
        # item5：清單常見的失敗是檔案開在 Excel 裡（Windows 鎖檔）——這是 OSError，
        # 沒接住會直接噴 traceback。寫檔失敗這裡就中止，不要再往下印「請確認
        # 匯入/規章清單.csv」之類的下一步提示，因為這次根本沒寫成。
        say("[中止] 規章清單寫入失敗：%s（可能開在 Excel）；請關掉後重跑 配對" % exc)
        return 1
    ws.print_table(rows)
    if kept_names:
        say("沿用手動列 %d 筆：%s" % (len(kept_names), "、".join(kept_names)))
    if dropped_names:
        say("手動列 %s 的檔不存在，已改回自動配對" % "、".join(dropped_names))
    if draft_missing:
        # no 16：手動列的草稿被刪掉時，以前整列原樣寫回去，要跑到「開始」的過期檢查
        # 才被擋；欄位已經清空了，這裡得講一聲，不然人只會看到草稿欄莫名其妙變空。
        nt.notice(nt.WARNING,
                  "%d 個手動列的新版草稿不存在，已清空草稿欄並標「%s」：%s"
                  % (len(draft_missing), ws.DRAFT_MISSING_NOTE,
                     "、".join("%s（%s）" % (name, rel) for name, rel in draft_missing)),
                  "配對")
    need_human = [r for r in rows if not r["舊版"]]
    # 修正回合 1（I1）：草稿不存在的手動列跟「未配對／多個候選」是同一級的「還沒配好」。
    # 只發警告不擋的話，使用者照畫面跑「開始」，那一列草稿欄是空的，整條流程會把它
    # 當成「這本沒改」安靜跳過——人明明改過這本，對照表卻一個字都沒有。判斷看的是
    # 清單裡留下來的備註（不是這一輪才偵測到的 draft_missing），所以重跑配對還是會擋，
    # 直到人真的去補檔或把那一列改回一般的「沒改」列。
    draft_rows = [r for r in rows
                  if r["舊版"] and r.get("備註") == ws.DRAFT_MISSING_NOTE]
    if not need_human:
        # no 15：清單寫出去了，但「開始」還會再跑一次 batch.read_manifest——規章名重複、
        # 同一份舊版／草稿被兩列引用，這三件事以前要等使用者照畫面指示跑「開始」才會
        # 被擋（畫面上剛剛還寫著「對了就跑 開始」）。同一套驗證在這裡先跑一次，錯就
        # 中止並把列號原樣印出來。未配對／多個候選走原本那條路（read_manifest 也會擋，
        # 但它的訊息沒有下面那句「請改檔名或補舊版」的指引）。
        try:
            bt.read_manifest(p["清單"])
        except bt.BatchError as exc:
            say("[中止] 清單有問題：%s" % exc)
            return 1
    say(ws.summarize(rows, skipped=len(skipped)) + "。請確認 匯入/規章清單.csv，對了就跑 開始")
    todo = need_human + draft_rows
    if todo:
        text = ("有 %d 本要人處理：未配對的請改檔名或補舊版；多個候選的請在清單填「舊版」"
                "並把「配對方式」寫「手動」" % len(todo))
        if draft_rows:
            text += ("；草稿不存在的（%s）請補檔或清掉草稿欄並把「配對方式」改回空白"
                     % "、".join(r["規章名"] for r in draft_rows))
        say(text)
    return 1 if todo else 0


def cmd_start(args, settings):
    """開始：讀清單 → 過期檢查 → 清單本身可用（未配對就先擋，不能歸檔）→
    歸檔上一輪 → 一律走批次機制（等同 batch，路徑固定）。"""
    import batch as bt
    import workspace as ws
    root = ws.resolve_root(args.workspace, settings)
    p = ws.paths(root)
    if not os.path.isfile(p["清單"]):
        say("請先跑 配對")
        return 1
    try:
        rows = ws.read_manifest_rows(p["清單"])
    except ws.WorkspaceError as exc:
        say("[中止] %s" % exc)
        return 1

    reasons = ws.stale_reasons(rows, root)
    if reasons:
        say("清單過期：")
        for reason in reasons:
            say("  " + reason)
        say("請重跑 配對")
        return 1

    # C1：清單本身要能用（沒有「未配對」列）才可以歸檔上一輪——bt.read_manifest
    # 就是 cmd_batch 稍後會跑的同一道檢查，這裡先跑一次是為了在歸檔（搬動
    # 產出/、批次摘要.txt）之前就擋下來；不然「未配對」列讓 cmd_batch 中止時，
    # 上一輪的產出已經被搬進 歷次/，沒東西可看也退不回去。
    try:
        bt.read_manifest(p["清單"])
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1

    names = [r["規章名"] for r in rows if r["舊版"]]
    try:
        moved = ws.archive_previous(root, names)
    except ws.WorkspaceError as exc:
        say("[中止] %s" % exc)
        return 1
    if moved:
        stamp = os.path.basename(moved[0])
        say("已歸檔上一輪：%s（搬了 %d 處：%s）" % (stamp, len(moved), "，".join(moved)))

    ns = argparse.Namespace(**vars(args))
    ns.manifest = p["清單"]
    # item3：這裡已經自己歸檔過一次（上面那段），cmd_batch 不能再歸檔一次，不然
    # 同一輪「開始」會把剛歸檔好的東西又搬進 歷次/ 一次。cmd_batch 用
    # `bool(args.outdir)`（在它補上工作區預設值之前）判斷 outdir 是不是「呼叫端
    # 明給的」；這裡明確把 ns.outdir 設成 p["產出"]，讓它看起來就是明給的，
    # 自然跳過歸檔那一段——不需要另外加旗標。
    ns.outdir = p["產出"]
    rc = cmd_batch(ns, settings)
    if rc:
        return rc

    # I1：根路徑可能含空白，印出來給人複製貼上的指令要加雙引號才不會被拆成兩段。
    suffix = ' --workspace "%s"' % root if args.workspace else ""
    say("")
    say("下一步：")
    say("  python scripts/run_all.py batch-review-pack%s" % suffix)
    say("  python scripts/run_all.py batch-review-import%s" % suffix)
    say("  python scripts/run_all.py batch-apply%s" % suffix)
    say("  python scripts/run_all.py batch-finalize%s" % suffix)
    return 0


# ---------------------------------------------------------------------------
# cut：切條產線 S2 → S12
# ---------------------------------------------------------------------------

STAGES_FIRST = ["S2_驗收.py", "S3_切條.py", "S4_二次切分.py", "QA_法遵稽核.py", "S5_品質旗標.py"]
GATES = {"S2_驗收.py", "QA_法遵稽核.py", "S6_套用決定.py", "S10_還原對帳.py", "S12_發布版本.py"}


def run_script(name, argv, log_dir):
    """跑一支 diffcut 腳本。完整輸出寫 logs/，畫面只印最後 12 行。"""
    import subprocess
    path = os.path.join(DIFFCUT, name)
    result = subprocess.run([sys.executable, path] + list(argv), capture_output=True,
                            text=True, encoding="utf-8", errors="replace")
    os.makedirs(log_dir, exist_ok=True)
    with io.open(os.path.join(log_dir, name[:-3] + ".log"), "w", encoding="utf-8") as f:
        f.write(result.stdout or "")
        if result.stderr:
            f.write("\n--- stderr ---\n" + result.stderr)
    for line in (result.stdout or "").strip().splitlines()[-12:]:
        say("  " + line)
    say("--- %s：%s ---" % (name, "過" if result.returncode == 0 else "沒過（exit %d）" % result.returncode))
    return result.returncode


def check_source_alignment(folder, source):
    """01_paragraphs.csv 的全文對上 --source 讀出的段落，回傳對齊比例（以 01 的列數為分母）。"""
    import csv as _csv
    import difflib
    from _common import read_paragraphs
    import decision_table as dt
    with io.open(os.path.join(folder, "01_paragraphs.csv"), encoding="utf-8-sig", newline="") as f:
        reader = _csv.DictReader(f)
        if "全文" not in (reader.fieldnames or []):
            return None      # 01 不是 S1 的格式，讓呼叫端印中文提示，不要噴 KeyError
        exported = [dt.normalize(row["全文"]) for row in reader]
    actual = [dt.normalize(p) for p in read_paragraphs(source)]
    if not exported:
        return 0.0
    matcher = difflib.SequenceMatcher(None, exported, actual, autojunk=False)
    matched = sum(block.size for block in matcher.get_matching_blocks())
    return matched / float(len(exported))


def cmd_cut(args, settings, runner=None):
    folder = os.path.abspath(args.folder)
    log_dir = os.path.join(folder, "logs")
    runner = runner or (lambda name, argv: run_script(name, argv, log_dir))
    say("=" * 60)
    say("第 5 步　切條產線　資料夾：%s" % folder)
    say("=" * 60)
    if not os.path.isfile(os.path.join(folder, "01_paragraphs.csv")):
        say("[中止] 找不到 01_paragraphs.csv。先在有 Word 的電腦跑 S1 巨集，把產出放進這個資料夾。")
        return 1
    if not args.source or not os.path.isfile(args.source):
        say("[中止] --source 必須指向 S1 切的那份原檔（定稿乾淨版）。")
        return 1
    ratio = check_source_alignment(folder, args.source)
    if ratio is None:
        say("[中止] 01_paragraphs.csv 沒有「全文」欄，不是 S1 巨集匯出的格式。請用最新版 S1_匯出全文.bas 重新匯出。")
        return 1
    say("來源核對：01_paragraphs.csv 與 %s 對齊 %.1f%%" % (os.path.basename(args.source), ratio * 100))
    if ratio < args.min_align:
        say("[中止] 對齊低於 %.0f%%。S1 切的不是這個檔。切條一定要用定稿乾淨版，不能用草稿。" % (args.min_align * 100))
        return 1

    for name in STAGES_FIRST:
        if runner(name, [folder]):
            say("[停] %s 沒過。%s" % (name, "這是關卡，請看 logs 裡的完整報告。" if name in GATES else ""))
            return 1

    review = os.path.join(folder, "06_複核表.csv")
    if not args.decisions:
        if args.inherit:
            rc = runner("S6_沿用決定.py", [folder, args.inherit, review])
        else:
            rc = runner("S6_產生複核表.py", [folder, review])
        if rc:
            return 1
        say("")
        say("停：把 %s 交給使用者填「決定」欄。" % review)
        say("填完再跑：run_all.py cut %s --source <同一份原檔> --decisions <填好的表> --version <版號> --name <規章名> --release-root <發布根目錄>" % folder)
        return 0

    if runner("S6_套用決定.py", [folder, args.decisions]):
        say("[停] S6 沒過。每一筆需人工看的都要有明確決定，程式不代填。")
        return 1
    for name in ("S7_找重複.py", "S8_抓引用.py", "S9_連帶清單.py"):
        if runner(name, [folder]):
            return 1
    s10_source = args.source
    if not args.source.lower().endswith(".txt"):
        # 逐字對帳是切條線最強的一道保險。來源是 docx 時，用 read_paragraphs 把段落抽成一行一段的 txt
        # 交給 S10（它是逐行點名，順序無關），關卡才不會因為檔案格式而整個跳過。
        from _common import read_paragraphs
        s10_source = os.path.join(folder, "來源全文_由docx產生.txt")
        lines = []
        for para in read_paragraphs(args.source):
            lines.extend(x for x in para.split("\n") if x.strip())
        with io.open(s10_source, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        say("S10：來源是 .docx，已由 docx 抽出 %d 行文字做逐字對帳（%s）。" % (len(lines), os.path.basename(s10_source)))
        say("     目錄區若被點名找不到，用 --toc 起-迄 行號排除。")
    s10_args = [folder, s10_source]
    if args.toc:
        s10_args += ["--toc", args.toc]
    if runner("S10_還原對帳.py", s10_args):
        say("[停] S10 逐字對帳沒過。")
        return 1
    missing = [flag for flag, value in (("--version", args.version), ("--name", args.name)) if not value]
    if missing:
        say("[中止] 正式發布還缺參數：%s。09_規章總表.csv 只是中間產物，不是正式版。" % "、".join(missing))
        return 1
    release_root = args.release_root or os.path.join(folder, "releases")
    release_args = [folder, release_root, "--version", args.version, "--source", args.source,
                    "--name", args.name]
    if args.org:
        release_args += ["--org", args.org]
    if args.ver:
        release_args += ["--ver", args.ver]
    if runner("S12_發布版本.py", release_args):
        say("[停] S12 沒過，沒有正式版本。")
        return 1
    say("")
    say("正式發布完成。唯一入口：%s" % os.path.join(release_root, "LATEST.json"))
    say("下一輪改內規時，舊版 Word ＝ 這次的 --source，舊版規格包 ＝ 這個發布根目錄。")
    return 0


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------

def build_parser():
    parser = argparse.ArgumentParser(description="reg 總入口")
    parser.add_argument("--workspace", default="",
                        help="工作區根目錄；沒給就看設定.json。批次類、配對、開始 可放在子命令前或後；"
                             "單本指令請放在子命令前")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("check", help="第 0 步：核對舊版 Word 與規格包")
    p.add_argument("old_file")
    p.add_argument("release_root")
    p.set_defaults(func=cmd_check)

    runner = load_regdiff_runner()
    p = sub.add_parser("compare", help="第 1 步：初比對，產連帶決定表")
    runner.add_compare_arguments(p)
    p.add_argument("--semantic", default=None, help="已算好的語意候選.csv，直接併入")
    # 這四個門檻改成 None：跟「使用者沒給、用哪個預設」分開看，finalize 才能判斷
    # 要不要沿用初比對指紋（見 _fill_compare_defaults）；cmd_compare 自己沒有可沿用
    # 的來源，None 一律補回 regdiff 的硬預設，行為跟改之前一樣。
    p.set_defaults(func=cmd_compare, threshold=None, top=None, changed_top=None,
                   sentence_threshold=None)

    p = sub.add_parser("review-pack", help="第 1.5 步：把候選與異動打包給 AI 審查")
    p.add_argument("outdir")
    p.add_argument("--per-file", dest="per_file", type=int, default=40)
    _add_max_chars_flag(p)
    p.set_defaults(func=cmd_review_pack)

    p = sub.add_parser("review-import", help="第 1.5 步：驗證 AI 判斷、寫回決定表、產報告")
    p.add_argument("outdir")
    p.set_defaults(func=cmd_review_import)

    p = sub.add_parser("semantic", help="把手動算好的語意候選併進連帶決定表")
    p.add_argument("decisions")
    p.add_argument("semantic")
    p.set_defaults(func=cmd_semantic)

    p = sub.add_parser("apply", help="第 3 步：把決定表寫進草稿，開追蹤修訂")
    p.add_argument("draft")
    p.add_argument("decisions")
    p.add_argument("--outdir", default="")
    p.set_defaults(func=cmd_apply)

    p = sub.add_parser("finalize", help="第 4 步：終比對與三問")
    runner.add_compare_arguments(p)
    p.add_argument("--decisions", required=True, help="第 2 步填好的連帶決定表.csv")
    p.add_argument("--semantic", default=None, help="對乾淨版算好的語意候選.csv")
    # None：命令列沒給就沿用初比對指紋檔的「比對參數」，見 _finalize_core／
    # _fill_compare_defaults；使用者自己指定的旗標仍然優先。
    p.set_defaults(func=cmd_finalize, threshold=None, top=None, changed_top=None,
                   sentence_threshold=None)

    p = sub.add_parser("batch", help="多本一起改：逐本初比對＋跨本連帶")
    p.add_argument("manifest", nargs="?", default=None,
                   help="規章清單.csv；省略時用工作區的 匯入/規章清單.csv")
    p.add_argument("--outdir", default="", help="省略時用工作區的 產出/")
    _add_batch_flags(p, runner)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch)

    p = sub.add_parser("batch-apply", help="逐本套用連帶決定表")
    p.add_argument("manifest", nargs="?", default=None,
                   help="規章清單.csv；省略時用工作區的 匯入/規章清單.csv")
    p.add_argument("--outdir", default="", help="省略時用工作區的 產出/")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_apply)

    p = sub.add_parser("batch-finalize", help="逐本終比對，彙整三問")
    p.add_argument("manifest", nargs="?", default=None,
                   help="規章清單.csv；省略時用工作區的 匯入/規章清單.csv")
    p.add_argument("--outdir", default="", help="省略時用工作區的 產出/")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_finalize)

    p = sub.add_parser("batch-review-pack", help="批次第 1.5 步：逐本打包審查包給 AI 看")
    p.add_argument("outdir", nargs="?", default=None, help="省略時用工作區的 產出/")
    p.add_argument("--per-file", dest="per_file", type=int, default=40)
    _add_max_chars_flag(p)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_review_pack)

    p = sub.add_parser("batch-review-import", help="批次第 1.5 步：逐本驗證匯入、彙整 LLM 審查總表")
    p.add_argument("outdir", nargs="?", default=None, help="省略時用工作區的 產出/")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_review_import)

    p = sub.add_parser("配對", help="配對 匯入/舊版、匯入/新版 的檔名，寫 匯入/規章清單.csv")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_pair)

    p = sub.add_parser("開始", help="讀 規章清單.csv → 過期檢查 → 歸檔上一輪 → 批次初比對")
    _add_batch_flags(p, runner)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_start)

    p = sub.add_parser("cut", help="第 5 步／情況一：切條產線 S2 → S12")
    p.add_argument("folder", help="工作區，裡面要有 S1 產出的 01_paragraphs.csv 等")
    p.add_argument("--source", required=True, help="S1 切的那份原檔（定稿乾淨版 .docx 或 .txt）")
    p.add_argument("--inherit", default=None, help="舊發布根目錄；給了就沿用上一版人工決定")
    p.add_argument("--decisions", default=None, help="填好的複核表；給了就跑第二趟到正式發布")
    p.add_argument("--version", default=None)
    p.add_argument("--name", default=None)
    p.add_argument("--release-root", dest="release_root", default=None)
    p.add_argument("--org", default="")
    p.add_argument("--ver", default="")
    p.add_argument("--min-align", dest="min_align", type=float, default=0.95)
    p.add_argument("--toc", default=None, help="S10 逐字對帳要排除的目錄區行號，例如 3-40")
    p.set_defaults(func=cmd_cut)
    return parser


DEBUG_ENV = "REG_DEBUG"


def debug_mode():
    """REG_DEBUG=1 時 main() 不收例外，直接讓 traceback 噴出來。

    「[中止] 一行字」對使用者是對的，對要修 bug 的人是災難——堆疊、哪一行、
    哪個檔全部被吃掉。留一個環境變數當逃生門，請使用者回報問題時重跑一次。
    """
    return (os.environ.get(DEBUG_ENV, "") or "").strip() not in ("", "0", "false", "False")


def _command_label(args):
    """從 args.func 反推子命令名（cmd_apply → apply），純粹是為了提醒文字好讀。"""
    name = getattr(getattr(args, "func", None), "__name__", "") or ""
    if name.startswith("cmd_"):
        name = name[4:]
    return name.replace("_", "-") or "執行"


def _abort_notice(args, text):
    """中止時把「為什麼中止」留下來：畫面那一行留不住（no 11）。

    只在產出資料夾*已經存在*的時候才接寫 提醒.txt——前置驗證擋下來的中止本來
    就沒建任何東西，為了寫一則提醒反而生出一個空資料夾，等於把剛擋掉的殘骸
    自己補回去。資料夾還不存在時就只有畫面那一行，跟以前一樣。
    """
    label = _command_label(args)
    try:
        import notices as nt
        nt.notice(nt.WARNING, "%s 中止：%s" % (label, text), label)
        outdir = getattr(args, "outdir", "") or ""
        if outdir and os.path.isdir(outdir):
            say("提醒留底：%s" % nt.write_notices(outdir, append=True,
                                                title="%s（中止）" % label))
    except Exception:
        # 留底失敗不能蓋掉「[中止]」那一行——那是使用者唯一看得到的線索。
        pass


def main(argv=None):
    setup_stdout()
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 1
    from _common import InputError
    try:
        return args.func(args, load_settings())
    except KeyboardInterrupt:
        # Ctrl+C 不是程式壞了，照原樣往上丟，不要偽裝成「[中止]」。
        raise
    except (OSError, UnicodeDecodeError, InputError) as exc:
        # no 11：以前這裡只有 return args.func(...)。檔案開在 Word 裡（Windows 鎖檔）、
        # outdir 指到檔案、UNC 掉線、唯讀磁碟、編碼猜錯——使用者看到的一律是
        # 一坨 Python traceback，跟專案其他地方的「[中止] …」完全不同調，
        # 根本分不出是自己弄錯還是程式有 bug。
        if debug_mode():
            # I2：要修 bug 的人自己開的逃生門，原樣噴 traceback。
            raise
        # I2：例外類別名一定要印出來。「[中止] [Errno 13] 拒絕存取」看不出是權限
        # 問題還是檔案被鎖，寫成「PermissionError：…」回報的人不用附 traceback
        # 就講得清楚是哪一類。
        say("[中止] %s：%s（要看完整錯誤請設 %s=1 重跑）"
            % (type(exc).__name__, exc, DEBUG_ENV))
        _abort_notice(args, "%s：%s" % (type(exc).__name__, exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
