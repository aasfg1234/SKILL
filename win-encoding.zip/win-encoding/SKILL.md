---
name: win-encoding
description: Windows 繁中環境腳本檔編碼守則 — 當要產生、修改或除錯任何會在 Windows 上執行的檔案時使用，包含 .bas .cls .frm（VBA 模組）、.vbs .wsf（WSH 腳本）、.ps1（PowerShell）、.bat .cmd（批次檔）、.csv（給 Excel 開啟）。也適用於使用者回報「匯入的資料是亂碼」「中文變成問號」「匯入 VBE 後中文壞掉」「Excel 開啟 CSV 亂碼」「cscript 說無效的資料」「PowerShell 中文亂碼」「執行批次檔說不是內部或外部命令」，或要求「產生 VBA 模組」「寫 Excel 巨集」「寫 PowerShell 腳本」「輸出 CSV 給 Excel」時。此 skill 提供：(1) 經實測驗證的「副檔名→編碼」規則表，說明為什麼沒有任何一種編碼能通吃 (2) 純標準函式庫的 winenc.py，依副檔名自動用正確編碼寫檔並在寫入後驗證 (3) Big5 字集缺口的嚴格檢查，遇到無法表示的字元明確報錯而非靜默替換成問號 (4) 亂碼反推診斷，從亂碼長相判斷是哪一段編碼弄錯 (5) 為什麼多數亂碼是不可逆的、必須以預防為主。
---

# Windows 繁中環境腳本檔編碼守則

**一句話：AI 產生的檔案預設是 UTF-8 無 BOM，而 Windows 繁中環境的原生工具幾乎沒有一個吃這種格式。**

這是「腳本明明寫對了、跑起來卻全是亂碼」最常見的單一原因。

---

## 一、絕對不要做的兩件事

### 1. 不要一律用 UTF-8

**沒有任何一種編碼能通吃所有檔案類型。** 這是本 skill 存在的理由。

以下為實測結果（Windows 11 繁體中文、Office LTSC、PowerShell 5.1）。
測試內容為 `測試中文顯示正常`，判定標準是執行後輸出是否與原文一致：

| 檔案用途 | UTF-8 無BOM | UTF-8 有BOM | Big5 (cp950) | UTF-16LE+BOM |
|---|---|---|---|---|
| `.bas` 匯入 VBE | ✗ 全亂碼 | ✗ BOM 混入程式碼，行結構跑掉 | **✓** | 未測 |
| `.vbs` 用 cscript 執行 | ✗ 全亂碼 | ✗ 編譯階段錯誤：無效的資料 | ✓ | **✓** |
| `.ps1` PowerShell 5.1 | ✗ 全亂碼 | **✓** | ✓ | ✓ |
| `.bat` cmd.exe | ✗ 全亂碼 | ✗ BOM 被當指令，`@echo off` 變 `嚜濃echo off` | **✓** | 未測 |
| `.csv` Excel 雙擊開啟 | ✗ 亂碼且欄位錯位 | **✓** | ✓ | 未測 |

粗體 = 建議值。注意 **UTF-8+BOM 對 `.ps1` / `.csv` 是正確答案，卻會直接弄壞 `.vbs` 和 `.bat`**。

### 2. 不要用 `errors='replace'` 或 `errors='ignore'`

Big5 的字集比 Unicode 小很多。`⚠ ★ ［ ］ →`（部分）這類符號轉不過去。

用 `replace` 會靜默換成 `?`，於是：
- 執行時不會報錯，但輸出裡莫名其妙多了問號
- 你事後**完全無法得知原本是什麼字、也不知道哪一行出問題**

一律用 `errors='strict'`（Python 預設），讓它當場炸給你看。
`winenc.py` 會回報「第幾行、第幾欄、什麼字、Unicode 碼位」。

---

## 二、標準做法：用 `scripts/winenc.py`

純標準函式庫，不需要 pip。SPADE 每次執行都是全新暫存目錄，所以請
**跟你的產出腳本放在同一次執行、同一個目錄**。

```python
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import winenc

# 依副檔名自動挑編碼 -> 檢查字元 -> 寫檔 -> 讀回驗證，任一步不對就丟例外
winenc.write_script("out/匯出郵件.bas", bas_code)
winenc.write_script("out/build.vbs",   vbs_code)
winenc.write_script("out/deploy.ps1",  ps_code)
winenc.write_script("out/名單.csv",    csv_text)
```

`write_script` 做完的事：

1. 依副檔名查規則表決定 編碼 / BOM / 換行
2. 換行正規化成該類型要求的形式
3. **逐字檢查能否用該編碼表示**，不行就丟 `UnencodableError`（附行號欄號碼位）
4. 用 `errors='strict'` 編碼、視需要加 BOM、寫入
5. **讀回來跟原文逐字比對**，不一致就丟 `IOError`

### 只想檢查、不寫檔

```python
bad = winenc.check_encodable(text, "cp950")
if bad:
    print(winenc.format_bad_chars(bad))
    # 第 67 行 第 12 欄：'⚠' (U+26A0 WARNING SIGN)
```

### 命令列

```bash
python winenc.py rules              # 印出完整規則表
python winenc.py check 檔案.bas      # 檢查能否用該類型的編碼表示
python winenc.py sniff 檔案.vbs      # 偵測檔案目前是什麼編碼
python winenc.py diagnose "皜祈岫"   # 從亂碼反推成因
```

### 驗證 winenc 本身

```bash
python selftest.py     # 28 項檢查，涵蓋規則表、位元組層級 BOM、字集缺口、偵測、診斷
```

---

## 三、不用 winenc 時的等價寫法

若因故必須自己寫，對照這張表：

```python
# .bas / .cls / .frm / .bat / .cmd  -> Big5，無 BOM，CRLF
open(p, "w", encoding="cp950", newline="\r\n", errors="strict")

# .vbs / .wsf  -> UTF-16LE + BOM，CRLF
with open(p, "wb") as f:
    f.write(b"\xff\xfe")
    f.write(text.replace("\n", "\r\n").encode("utf-16-le"))

# .ps1 / .csv  -> UTF-8 + BOM，CRLF
open(p, "w", encoding="utf-8-sig", newline="\r\n")   # utf-8-sig 會自動加 BOM

# .py / .json / .md  -> UTF-8 無 BOM，LF
open(p, "w", encoding="utf-8", newline="\n")
```

---

## 四、亂碼診斷：從長相反推病因

先用 `python winenc.py diagnose "貼上亂碼"`。它會把亂碼用各種「當初可能誤用的編碼」
反推回位元組再重新解碼，看哪一組還原出合理比例的中文。

常見指紋：

| 亂碼長相 | 病因 |
|---|---|
| `皜祈岫銝剜?憿舐內` | **UTF-8 檔案被當 Big5 讀**（最常見；AI 產檔的預設狀況） |
| `¬Õ À Ñ Õ à À` | Big5 檔案被當 Latin-1 讀 |
| `ä¸­æ–‡` | UTF-8 被當 Latin-1 / cp1252 讀 |
| `中 文` 字間有空格或 NUL | UTF-16 檔案被當單位元組編碼讀 |
| `�` 替換字元 | 解碼失敗，**原始位元組已遺失、救不回來** |
| `嚜濃echo off` | .bat 帶了 UTF-8 BOM，BOM 被當成指令的一部分 |

### ⚠ 多數亂碼是不可逆的

實測：`測試中文顯示正常` 轉成 UTF-8 位元組後，**不是合法的 cp950 序列**。
Windows 讀到非法序列會直接替換掉，那些位元組就永久消失了。

只有少數字串（例如剛好全部落在合法 cp950 雙位元組範圍的「測試」）能完整還原。

**結論：不要指望事後搶救，要在產出當下就用對編碼。**

---

## 五、其他容易連帶踩到的坑

- **`.bat` 含中文時檔頭要加 `chcp 950 >nul`**，否則主控台仍會用錯字碼頁。
  更保險的做法：讓 `.bat` 只當啟動器、內容全部用 ASCII，中文訊息交給它呼叫的
  `.ps1`（UTF-8+BOM）去印。
- **把 UTF-16 檔案當 UTF-8 讀會造成不可逆損毀。** 讀檔前先用 `winenc.sniff()`
  看 BOM，不要無條件 `open(p, encoding="utf-8")`。
- **ZIP 打包時路徑要用正斜線。** Windows 的 `Compress-Archive` 會寫反斜線，
  不符 ZIP 規範，Linux/macOS 解壓時不會建資料夾。用
  `ZipFile.CreateEntryFromFile` 並自行把 `\` 換成 `/`。
- **Python 的 `print()` 也會踩雷。** Windows 主控台是 cp950，印出 Big5 沒有的字
  會直接丟 `UnicodeEncodeError` 讓腳本中斷。輸出訊息前先過濾
  （`selftest.py` 的 `_safe()` 是現成範例）。

---

## 六、給使用者的檢查清單

產出檔案後，請對方確認：

1. 用**記事本**開啟 → 「另存新檔」對話框右下角會顯示目前編碼，對照第一節的表
2. `.bas` 匯入 VBE 後，隨便找一行中文註解看有沒有亂碼
3. `.csv` 直接雙擊用 Excel 開，看第一欄標題與中文欄位
4. `.vbs` 用 `cscript //nologo 檔名.vbs` 執行（不要雙擊，雙擊是 wscript 會跳對話框）
