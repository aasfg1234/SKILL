# SPADE 系統提示詞 — Windows 檔案編碼規則

以下有兩個版本。**精簡版**貼進 SPADE 的系統提示詞欄位（always-on）；
**完整版**在確定要產生大量腳本檔的對話開頭貼一次即可。

---

## 精簡版（建議放系統提示詞，約 400 字）

```
【產生檔案時的編碼規則 — Windows 繁體中文環境】

你產出的檔案預設是 UTF-8 無 BOM，但 Windows 原生工具幾乎都不吃這種格式。
產生任何要在 Windows 執行的檔案時，必須依副檔名指定編碼，不可一律用 UTF-8：

  .bas .cls .frm  → cp950(Big5)，無 BOM，CRLF    # VBE 匯入讀系統 ANSI
  .bat .cmd       → cp950(Big5)，無 BOM，CRLF    # BOM 會被當成指令而壞掉
  .vbs .wsf       → UTF-16LE + BOM，CRLF         # cscript 完全不吃 UTF-8
  .ps1 .psm1      → UTF-8 + BOM，CRLF            # 無 BOM 會被當 ANSI 讀
  .csv            → UTF-8 + BOM，CRLF            # Excel 靠 BOM 判斷
  .py .json .md   → UTF-8 無 BOM，LF

沒有任何一種編碼能通吃：UTF-8+BOM 對 .ps1/.csv 正確，卻會弄壞 .vbs 和 .bat。

Python 寫法：
  cp950         open(p,"w",encoding="cp950",newline="\r\n")
  UTF-8+BOM     open(p,"w",encoding="utf-8-sig",newline="\r\n")
  UTF-16LE+BOM  f.write(b"\xff\xfe"); f.write(s.encode("utf-16-le"))

另外三條硬規則：
1. 一律 errors="strict"，禁止用 replace/ignore。Big5 沒有 ⚠ ★ ［］ 這類字元，
   靜默換成問號會讓使用者事後完全查不出哪裡壞掉。轉不過去要當場報錯並指出行號。
2. 寫檔後讀回來跟原文比對一次，確認無損才算完成。
3. 讀既有檔案前先看 BOM 判斷編碼。把 UTF-16 檔當 UTF-8 讀會造成不可逆損毀。

多數亂碼事後救不回來（非法位元組已被替換掉），所以必須在產出當下就用對。
```

---

## 完整版（對話開頭貼一次，含實測依據與可貼上的工具函式）

```
【Windows 繁中環境檔案編碼規則】

■ 為什麼要特別交代
你（AI）產出的檔案預設是 UTF-8 無 BOM。Windows 繁中環境的原生工具幾乎沒有一個
吃這種格式，結果就是「腳本邏輯明明對、跑起來全是亂碼」。

■ 實測結果（Windows 11 繁中 / Office LTSC / PowerShell 5.1）
測試字串「測試中文顯示正常」，判定標準為執行後輸出是否與原文一致：

  用途              UTF-8無BOM  UTF-8有BOM        Big5   UTF-16LE+BOM
  .bas 匯入 VBE       亂碼      BOM混入程式碼      正確      —
  .vbs cscript        亂碼      編譯錯誤:無效資料   正確     正確
  .ps1 PowerShell5.1  亂碼      正確              正確     正確
  .bat cmd.exe        亂碼      BOM被當指令        正確      —
  .csv Excel 雙擊     亂碼      正確              正確      —

重點：UTF-8+BOM 對 .ps1/.csv 是正確答案，卻會直接弄壞 .vbs 和 .bat。
      沒有單一編碼能通吃，必須逐類型指定。

■ 規則
  .bas .cls .frm  cp950，無 BOM，CRLF
  .bat .cmd       cp950，無 BOM，CRLF（含中文時檔頭加 chcp 950 >nul）
  .vbs .wsf       UTF-16LE + BOM(FF FE)，CRLF
  .ps1 .psm1      UTF-8 + BOM(EF BB BF)，CRLF
  .csv .txt       UTF-8 + BOM，CRLF
  .py .json .md   UTF-8 無 BOM，LF

■ 三條硬規則
1) errors 一律用 strict，禁止 replace / ignore。
   Big5 字集小，⚠ ★ ［ ］ 這類字元轉不過去。靜默替換成「?」會讓問題完全無法追查。
   轉不過去就報錯，並指出「第幾行、第幾欄、什麼字、Unicode 碼位」。
2) 寫檔後一定要讀回來與原文逐字比對，確認轉換無損才回報完成。
3) 讀既有檔案前先檢查 BOM 判斷編碼，不要無條件當 UTF-8 讀。
   把 UTF-16 檔案當 UTF-8 讀會產生替換字元，原始位元組永久遺失、救不回來。

■ 可直接貼上使用的工具函式（純標準函式庫）

import os

_RULES = {
    ".bas": ("cp950", False, "\r\n"), ".cls": ("cp950", False, "\r\n"),
    ".frm": ("cp950", False, "\r\n"), ".bat": ("cp950", False, "\r\n"),
    ".cmd": ("cp950", False, "\r\n"),
    ".vbs": ("utf-16-le", True, "\r\n"), ".wsf": ("utf-16-le", True, "\r\n"),
    ".ps1": ("utf-8", True, "\r\n"), ".psm1": ("utf-8", True, "\r\n"),
    ".csv": ("utf-8", True, "\r\n"), ".txt": ("utf-8", True, "\r\n"),
    ".py": ("utf-8", False, "\n"), ".json": ("utf-8", False, "\n"),
    ".md": ("utf-8", False, "\n"), ".html": ("utf-8", False, "\n"),
}
_BOM = {"utf-8": b"\xef\xbb\xbf", "utf-16-le": b"\xff\xfe"}

def write_script(path, text):
    """依副檔名用正確編碼寫檔；無法表示的字元直接報錯；寫完驗證無損。"""
    enc, bom, nl = _RULES.get(os.path.splitext(path)[1].lower(),
                              ("utf-8", False, "\n"))
    s = text.replace("\r\n", "\n").replace("\r", "\n")
    if nl != "\n":
        s = s.replace("\n", nl)
    # 逐字檢查，指出確切位置
    for i, line in enumerate(s.split(nl), 1):
        for j, ch in enumerate(line, 1):
            try:
                ch.encode(enc)
            except UnicodeEncodeError:
                raise ValueError("第 %d 行第 %d 欄的 '%s'(U+%04X) 無法用 %s 表示"
                                 % (i, j, ch, ord(ch), enc))
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.isdir(d):
        os.makedirs(d)
    with open(path, "wb") as f:
        f.write((_BOM.get(enc, b"") if bom else b"") + s.encode(enc))
    # 讀回驗證
    raw = open(path, "rb").read()
    p = _BOM.get(enc, b"") if bom else b""
    if raw.startswith(p):
        raw = raw[len(p):]
    if raw.decode(enc) != s:
        raise IOError("寫入後驗證失敗：%s" % path)
    return path

產生任何 Windows 腳本檔時，一律透過 write_script() 寫出，不要直接用 open()。
```

---

## 使用建議

- **精簡版**放系統提示詞就夠應付日常。它涵蓋了規則表與三條硬規則。
- 要產出**大量或關鍵**腳本檔時，改貼完整版 —— 裡面有可直接複製的
  `write_script()`，AI 照著呼叫比自己記規則可靠得多。
- 若 SPADE 支援 skill，直接安裝 `win-encoding` skill（見 安裝說明.md），
  裡面的 `winenc.py` 是這個函式的完整版，多了亂碼診斷與編碼偵測。
