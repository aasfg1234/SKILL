# -*- coding: utf-8 -*-
"""
winenc — Windows 繁中環境的腳本檔編碼寫入器 / 檢查器 / 亂碼診斷器

只用 Python 標準函式庫，不依賴任何第三方套件（SPADE 沒有 pip）。
所有規則都在 Windows 10/11 繁體中文環境實測驗證過，見 SKILL.md 的實測表。

典型用法：

    import winenc

    # 依副檔名自動挑編碼寫檔，寫完自動驗證，有問題直接丟例外
    winenc.write_script("out/匯出郵件.bas", code)
    winenc.write_script("out/build.vbs", vbs_code)
    winenc.write_script("out/report.csv", csv_text)

    # 只想先檢查文字能不能用 Big5 表示
    bad = winenc.check_encodable(code, "cp950")
    if bad:
        print(winenc.format_bad_chars(bad))

命令列：

    python winenc.py rules                     # 印出規則表
    python winenc.py check <檔案> [編碼]        # 檢查檔案能否用該編碼表示
    python winenc.py sniff <檔案>              # 偵測檔案目前的編碼
    python winenc.py diagnose "亂碼字串"        # 反推亂碼成因
"""

import io
import os
import sys
import unicodedata

__all__ = [
    "RULES", "rule_for", "write_script", "write_text",
    "check_encodable", "format_bad_chars", "verify_file",
    "sniff", "diagnose", "UnencodableError",
]

# ---------------------------------------------------------------------------
# 規則表
# ---------------------------------------------------------------------------
# encoding : Python 編碼名稱
# bom      : 是否要寫入 BOM
# newline  : 換行符
# note     : 為什麼是這個組合（實測依據）
#
# ⚠ 沒有任何一種編碼能通吃所有類型：
#   UTF-8+BOM 對 .ps1/.csv 正確，但會讓 .vbs 編譯失敗、讓 .bat 的第一行指令壞掉。

RULES = {
    # --- VBA ---
    ".bas": dict(encoding="cp950", bom=False, newline="\r\n",
                 note="VBE「匯入檔案」讀系統 ANSI。UTF-8 會整份亂碼；加了 BOM 會讓 BOM 變成程式碼內容，破壞行結構。"),
    ".cls": dict(encoding="cp950", bom=False, newline="\r\n",
                 note="同 .bas"),
    ".frm": dict(encoding="cp950", bom=False, newline="\r\n",
                 note="同 .bas"),

    # --- Windows Script Host ---
    ".vbs": dict(encoding="utf-16-le", bom=True, newline="\r\n",
                 note="cscript 不吃 UTF-8：無 BOM 會亂碼，有 BOM 會直接『編譯階段錯誤：無效的資料』。cp950 也可行但字集受限。"),
    ".wsf": dict(encoding="utf-16-le", bom=True, newline="\r\n",
                 note="同 .vbs"),
    ".js":  dict(encoding="utf-16-le", bom=True, newline="\r\n",
                 note="由 cscript 執行時同 .vbs；若是網頁用途請改用 utf-8 無 BOM"),

    # --- PowerShell ---
    ".ps1":  dict(encoding="utf-8", bom=True, newline="\r\n",
                  note="PowerShell 5.1 沒有 BOM 就當系統 ANSI 讀 -> 中文亂碼。加 BOM 對 PS 5.1 與 7+ 都正確。"),
    ".psm1": dict(encoding="utf-8", bom=True, newline="\r\n", note="同 .ps1"),
    ".psd1": dict(encoding="utf-8", bom=True, newline="\r\n", note="同 .ps1"),

    # --- 批次檔 ---
    ".bat": dict(encoding="cp950", bom=False, newline="\r\n",
                 note="cmd.exe 讀系統 ANSI。BOM 會被當成指令的一部分（@echo off 變成 嚜濃echo off）而整個壞掉。含中文時檔頭要加 chcp 950。"),
    ".cmd": dict(encoding="cp950", bom=False, newline="\r\n", note="同 .bat"),

    # --- 資料檔 ---
    ".csv": dict(encoding="utf-8", bom=True, newline="\r\n",
                 note="Excel 雙擊開啟時靠 BOM 判斷 UTF-8；沒 BOM 會當 ANSI 讀而亂碼、欄位也可能錯位。cp950 亦可但字集受限。"),
    ".txt": dict(encoding="utf-8", bom=True, newline="\r\n",
                 note="給 Windows 記事本/Excel 匯入用。若確定只給程式讀，改 utf-8 無 BOM 較單純。"),

    # --- 跨平台/開發用（不要加 BOM） ---
    ".py":   dict(encoding="utf-8", bom=False, newline="\n", note="Python 原生 UTF-8；BOM 會造成部分工具解析問題"),
    ".json": dict(encoding="utf-8", bom=False, newline="\n", note="JSON 規範為 UTF-8 且不應有 BOM"),
    ".md":   dict(encoding="utf-8", bom=False, newline="\n", note=""),
    ".html": dict(encoding="utf-8", bom=False, newline="\n", note="以 <meta charset=\"utf-8\"> 宣告"),
    ".xml":  dict(encoding="utf-8", bom=False, newline="\n", note="以 XML 宣告指定編碼"),
    ".sql":  dict(encoding="utf-8", bom=True,  newline="\r\n", note="SSMS 開啟時靠 BOM 判斷；若給其他工具請確認"),
}

BOM_BYTES = {
    "utf-8": b"\xef\xbb\xbf",
    "utf-16-le": b"\xff\xfe",
    "utf-16-be": b"\xfe\xff",
}


class UnencodableError(ValueError):
    """文字中含有目標編碼無法表示的字元。"""

    def __init__(self, encoding, bad):
        self.encoding = encoding
        self.bad = bad
        super().__init__(
            "有 %d 個字元無法用 %s 表示：\n%s" % (len(bad), encoding, format_bad_chars(bad))
        )


def rule_for(path):
    """依副檔名取得規則；未知副檔名回傳 None。"""
    ext = os.path.splitext(str(path))[1].lower()
    return RULES.get(ext)


# ---------------------------------------------------------------------------
# 檢查
# ---------------------------------------------------------------------------
def check_encodable(text, encoding):
    """
    找出 text 中無法用 encoding 表示的字元。
    回傳 [(行號, 欄號, 字元, 'U+XXXX', 字元名稱), ...]，行號欄號皆從 1 起算。

    ⚠ 一定要用這個而不是 errors='replace'：
       靜默替換成 '?' 之後，你事後完全無法得知原本是什麼、也不知道哪裡壞了。
    """
    bad = []
    seen = set()
    for lineno, line in enumerate(text.replace("\r\n", "\n").split("\n"), start=1):
        for colno, ch in enumerate(line, start=1):
            if ch in seen:
                continue
            try:
                ch.encode(encoding)
            except (UnicodeEncodeError, LookupError):
                seen.add(ch)
                try:
                    name = unicodedata.name(ch)
                except ValueError:
                    name = "(無名稱)"
                bad.append((lineno, colno, ch, "U+%04X" % ord(ch), name))
    return bad


def format_bad_chars(bad):
    return "\n".join(
        "    第 %d 行 第 %d 欄：'%s' (%s %s)" % (ln, cn, ch, cp, nm)
        for ln, cn, ch, cp, nm in bad
    )


# ---------------------------------------------------------------------------
# 寫入
# ---------------------------------------------------------------------------
def write_text(path, text, encoding, bom=False, newline="\r\n", verify=True):
    """用指定編碼寫檔。無法表示的字元一律丟 UnencodableError，絕不靜默替換。"""
    norm = text.replace("\r\n", "\n").replace("\r", "\n")
    if newline != "\n":
        norm = norm.replace("\n", newline)

    bad = check_encodable(norm, encoding)
    if bad:
        raise UnencodableError(encoding, bad)

    data = norm.encode(encoding)          # 預設 errors='strict'
    prefix = BOM_BYTES.get(encoding, b"") if bom else b""

    d = os.path.dirname(os.path.abspath(str(path)))
    if d and not os.path.isdir(d):
        os.makedirs(d)
    with open(path, "wb") as f:
        f.write(prefix + data)

    if verify and not verify_file(path, norm, encoding, bom):
        raise IOError("寫入後驗證失敗（讀回內容與原文不符）：%s" % path)
    return path


def write_script(path, text, verify=True, encoding=None, bom=None, newline=None):
    """
    依副檔名自動套用正確編碼寫檔（推薦用法）。
    未知副檔名時預設 utf-8 無 BOM + LF，並在 stderr 提示。
    """
    rule = rule_for(path)
    if rule is None:
        sys.stderr.write(
            "[winenc] 未知副檔名 %s，改用預設 utf-8 無 BOM。"
            "若目標程式是 Windows 原生工具請明確指定編碼。\n"
            % os.path.splitext(str(path))[1]
        )
        rule = dict(encoding="utf-8", bom=False, newline="\n")
    return write_text(
        path, text,
        encoding=encoding if encoding is not None else rule["encoding"],
        bom=rule["bom"] if bom is None else bom,
        newline=rule["newline"] if newline is None else newline,
        verify=verify,
    )


def verify_file(path, expected_text, encoding, bom=False):
    """讀回檔案並與原文逐字比對，確認轉換無損。"""
    with open(path, "rb") as f:
        raw = f.read()
    prefix = BOM_BYTES.get(encoding, b"") if bom else b""
    if prefix and raw.startswith(prefix):
        raw = raw[len(prefix):]
    try:
        return raw.decode(encoding) == expected_text
    except UnicodeDecodeError:
        return False


# ---------------------------------------------------------------------------
# 偵測
# ---------------------------------------------------------------------------
def sniff(path):
    """
    偵測檔案編碼。回傳 dict(encoding, bom, confidence, why)。
    先看 BOM（確定），沒有 BOM 就試解碼（推測）。
    """
    with open(path, "rb") as f:
        raw = f.read()

    if raw.startswith(b"\xff\xfe"):
        return dict(encoding="utf-16-le", bom=True, confidence="確定", why="開頭是 FF FE")
    if raw.startswith(b"\xfe\xff"):
        return dict(encoding="utf-16-be", bom=True, confidence="確定", why="開頭是 FE FF")
    if raw.startswith(b"\xef\xbb\xbf"):
        return dict(encoding="utf-8", bom=True, confidence="確定", why="開頭是 EF BB BF")

    if not any(b > 127 for b in bytearray(raw)):
        return dict(encoding="ascii", bom=False, confidence="確定", why="全部都是 ASCII，任何編碼都相容")

    try:
        raw.decode("utf-8")
        return dict(encoding="utf-8", bom=False, confidence="高",
                    why="可用 UTF-8 完整解碼（UTF-8 有嚴格結構，誤判機率低）")
    except UnicodeDecodeError:
        pass
    try:
        raw.decode("cp950")
        return dict(encoding="cp950", bom=False, confidence="中",
                    why="無法用 UTF-8 解碼但可用 cp950 解碼")
    except UnicodeDecodeError:
        pass
    return dict(encoding=None, bom=False, confidence="無",
                why="UTF-8 與 cp950 都無法解碼，可能是 UTF-16 無 BOM 或二進位檔")


# ---------------------------------------------------------------------------
# 亂碼診斷
# ---------------------------------------------------------------------------
_CANDIDATES = [
    # (實際位元組編碼, 被誤當成的編碼, 說明)
    ("utf-8",   "cp950",     "檔案是 UTF-8，但被當成 Big5/系統ANSI 讀"),
    ("utf-8",   "latin-1",   "檔案是 UTF-8，但被當成 Latin-1 讀"),
    ("utf-8",   "cp1252",    "檔案是 UTF-8，但被當成 cp1252 讀"),
    ("cp950",   "utf-8",     "檔案是 Big5，但被當成 UTF-8 讀"),
    ("cp950",   "latin-1",   "檔案是 Big5，但被當成 Latin-1 讀"),
    ("utf-16-le", "cp950",   "檔案是 UTF-16，但被當成 Big5 讀"),
    ("utf-16-le", "utf-8",   "檔案是 UTF-16，但被當成 UTF-8 讀"),
]


def _cjk_ratio(s):
    if not s:
        return 0.0
    n = sum(1 for ch in s if "一" <= ch <= "鿿")
    return n / len(s)


def diagnose(garbled, top=3):
    """
    輸入一段亂碼，反推可能的成因。
    做法：把亂碼用「當初誤用的編碼」encode 回位元組，再用「正確編碼」decode，
    看哪一組能還原出合理比例的中文字。

    回傳 [(分數, 還原結果, 說明), ...]，分數高者在前。
    """
    results = []
    for real_enc, wrong_enc, desc in _CANDIDATES:
        try:
            restored = garbled.encode(wrong_enc, errors="strict").decode(real_enc, errors="strict")
        except (UnicodeEncodeError, UnicodeDecodeError, LookupError):
            continue
        score = _cjk_ratio(restored)
        if score > 0:
            results.append((score, restored, desc))
    results.sort(key=lambda x: -x[0])
    return results[:top]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def _main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 0
    cmd = argv[1]

    if cmd == "rules":
        print("%-8s %-12s %-6s %-8s %s" % ("副檔名", "編碼", "BOM", "換行", "說明"))
        print("-" * 100)
        for ext in sorted(RULES):
            r = RULES[ext]
            print("%-8s %-12s %-6s %-8s %s" % (
                ext, r["encoding"], "要" if r["bom"] else "不要",
                r["newline"].replace("\r", "CR").replace("\n", "LF"), r["note"]))
        return 0

    if cmd == "check" and len(argv) >= 3:
        path = argv[2]
        enc = argv[3] if len(argv) > 3 else (rule_for(path) or {}).get("encoding", "cp950")
        info = sniff(path)
        with open(path, "rb") as f:
            raw = f.read()
        src = info["encoding"] or "utf-8"
        text = raw.decode(src, errors="replace")
        bad = check_encodable(text, enc)
        print("檔案目前編碼推測：%s（%s，%s）" % (info["encoding"], info["confidence"], info["why"]))
        if bad:
            print("無法用 %s 表示的字元共 %d 個：" % (enc, len(bad)))
            print(format_bad_chars(bad))
            return 1
        print("全部字元都能用 %s 表示。" % enc)
        return 0

    if cmd == "sniff" and len(argv) >= 3:
        info = sniff(argv[2])
        print("編碼=%s  BOM=%s  可信度=%s\n理由：%s"
              % (info["encoding"], info["bom"], info["confidence"], info["why"]))
        return 0

    if cmd == "diagnose" and len(argv) >= 3:
        for score, restored, desc in diagnose(argv[2]):
            print("[中文比例 %.0f%%] %s\n    還原結果：%s\n" % (score * 100, desc, restored))
        return 0

    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
