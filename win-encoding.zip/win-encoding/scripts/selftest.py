# -*- coding: utf-8 -*-
"""
winenc 自我測試 —— 不需要 Windows、不需要 Excel，純粹驗證編碼邏輯。
在 SPADE 上直接跑：python selftest.py
"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import winenc  # noqa: E402

PASS = 0
FAIL = 0


def _safe(s):
    """主控台在 Windows 上是 cp950，遇到 Big5 沒有的字會直接丟例外。
    測試訊息本身就常含這種字（那正是我們在測的東西），先換成碼位再印。"""
    enc = getattr(sys.stdout, "encoding", None) or "utf-8"
    out = []
    for ch in str(s):
        try:
            ch.encode(enc)
            out.append(ch)
        except (UnicodeEncodeError, LookupError):
            out.append("<U+%04X>" % ord(ch))
    return "".join(out)


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(_safe("  [OK]   %s" % name))
    else:
        FAIL += 1
        print(_safe("  [FAIL] %s  %s" % (name, detail)))


def main():
    tmp = tempfile.mkdtemp(prefix="winenc_")
    zh = "測試中文顯示正常"

    print("1) 規則表：每種檔案都拿到預期的編碼組合")
    check(".bas -> cp950 無BOM",
          winenc.rule_for("a.bas")["encoding"] == "cp950" and not winenc.rule_for("a.bas")["bom"])
    check(".vbs -> utf-16-le 有BOM",
          winenc.rule_for("a.vbs")["encoding"] == "utf-16-le" and winenc.rule_for("a.vbs")["bom"])
    check(".ps1 -> utf-8 有BOM",
          winenc.rule_for("a.ps1")["encoding"] == "utf-8" and winenc.rule_for("a.ps1")["bom"])
    check(".bat -> cp950 無BOM",
          winenc.rule_for("a.bat")["encoding"] == "cp950" and not winenc.rule_for("a.bat")["bom"])
    check(".csv -> utf-8 有BOM",
          winenc.rule_for("a.csv")["encoding"] == "utf-8" and winenc.rule_for("a.csv")["bom"])
    check(".py  -> utf-8 無BOM",
          winenc.rule_for("a.py")["encoding"] == "utf-8" and not winenc.rule_for("a.py")["bom"])

    print("\n2) 實際寫檔：位元組層級檢查 BOM 與編碼")
    p = os.path.join(tmp, "t.bas")
    winenc.write_script(p, 'Public Function T()\n    T = "%s"\nEnd Function' % zh)
    raw = open(p, "rb").read()
    check(".bas 沒有 BOM", not raw.startswith(b"\xef\xbb\xbf"))
    check(".bas 是 cp950 且能還原", zh in raw.decode("cp950"))
    check(".bas 換行是 CRLF（沒有裸 LF）",
          b"\r\n" in raw and b"\n" not in raw.replace(b"\r\n", b""))

    p = os.path.join(tmp, "t.vbs")
    winenc.write_script(p, 'WScript.Echo "%s"' % zh)
    raw = open(p, "rb").read()
    check(".vbs 開頭是 FF FE", raw.startswith(b"\xff\xfe"))
    check(".vbs 內容為 UTF-16LE 且能還原", zh in raw[2:].decode("utf-16-le"))

    p = os.path.join(tmp, "t.ps1")
    winenc.write_script(p, 'Write-Output "%s"' % zh)
    raw = open(p, "rb").read()
    check(".ps1 開頭是 EF BB BF", raw.startswith(b"\xef\xbb\xbf"))
    check(".ps1 內容為 UTF-8 且能還原", zh in raw[3:].decode("utf-8"))

    p = os.path.join(tmp, "t.bat")
    winenc.write_script(p, "@echo off\nchcp 950 >nul\necho %s" % zh)
    raw = open(p, "rb").read()
    check(".bat 沒有 BOM（BOM 會讓第一行指令壞掉）", not raw.startswith(b"\xef\xbb\xbf"))
    check(".bat 第一個位元組是 @", raw[:1] == b"@")

    p = os.path.join(tmp, "t.csv")
    winenc.write_script(p, "姓名,分行\n王小明,台北分行")
    raw = open(p, "rb").read()
    check(".csv 開頭是 EF BB BF", raw.startswith(b"\xef\xbb\xbf"))

    print("\n3) Big5 字集缺口：必須明確報錯，不可靜默替換")
    bad = winenc.check_encodable("警告 ⚠ 注意", "cp950")
    check("偵測到 ⚠ 無法用 cp950 表示", len(bad) == 1 and bad[0][3] == "U+26A0",
          "實得 %r" % (bad,))
    bad2 = winenc.check_encodable("全形括號 ［ ］", "cp950")
    check("偵測到 ［］ 無法用 cp950 表示", len(bad2) == 2)
    try:
        winenc.write_script(os.path.join(tmp, "bad.bas"), "T = \"⚠\"")
        check("寫入含 ⚠ 的 .bas 應丟例外", False, "竟然沒有丟例外")
    except winenc.UnencodableError as e:
        check("寫入含 ⚠ 的 .bas 有丟例外", "U+26A0" in str(e))
    check("純 ASCII 與常用中文可通過 cp950", winenc.check_encodable("測試 abc 123", "cp950") == [])

    print("\n4) 編碼偵測")
    check("偵測 UTF-16LE BOM", winenc.sniff(os.path.join(tmp, "t.vbs"))["encoding"] == "utf-16-le")
    check("偵測 UTF-8 BOM", winenc.sniff(os.path.join(tmp, "t.ps1"))["encoding"] == "utf-8"
          and winenc.sniff(os.path.join(tmp, "t.ps1"))["bom"] is True)
    check("偵測 cp950 無 BOM", winenc.sniff(os.path.join(tmp, "t.bas"))["encoding"] == "cp950")

    print("\n5) 亂碼診斷：能反推成因")
    # 注意：並非所有 UTF-8 位元組序列都是合法 cp950。真實世界中 Windows 讀到
    # 非法序列會直接替換掉，那些位元組就永久遺失了 —— 這種亂碼救不回來。
    # 這裡用「測試」二字，它的 UTF-8 位元組剛好是合法 cp950，可完整往返。
    recoverable = "測試"
    garbled = recoverable.encode("utf-8").decode("cp950")   # UTF-8 被當 Big5 讀
    res = winenc.diagnose(garbled)
    check("能還原『UTF-8 被當 Big5 讀』的亂碼",
          bool(res) and res[0][1] == recoverable, "實得 %r" % (res[:1],))

    garbled2 = zh.encode("cp950").decode("latin-1")         # Big5 被當 Latin-1 讀
    res2 = winenc.diagnose(garbled2)
    check("能還原『Big5 被當 Latin-1 讀』的亂碼",
          bool(res2) and res2[0][1] == zh, "實得 %r" % (res2[:1],))

    # 不可逆的情況：要能「安靜地無解」，不可以亂猜一個結果出來
    lossy = zh.encode("utf-8").decode("cp950", errors="replace")
    res3 = winenc.diagnose(lossy)
    check("對不可逆的亂碼不會謊報成功還原",
          all(r[1] != zh for r in res3), "實得 %r" % (res3[:1],))

    print("\n6) 寫入後驗證會攔截不一致")
    p = os.path.join(tmp, "v.bas")
    winenc.write_script(p, "T = \"%s\"" % zh)
    check("verify_file 對正確內容回 True",
          winenc.verify_file(p, "T = \"%s\"" % zh, "cp950", False))
    check("verify_file 對錯誤內容回 False",
          not winenc.verify_file(p, "完全不同的內容", "cp950", False))

    print("\n" + "=" * 60)
    print("通過 %d 項，失敗 %d 項" % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
