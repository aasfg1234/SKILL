﻿# =====================================================================
# 電訪工具 — 從 電訪工具.xlsm 把 VBA 程式碼匯回 vba_source/
#
# 用途：你在 VBE 裡直接改了程式碼（除錯、加中斷點、順手修一行），
#       想把改動保留下來時跑這支，否則下次 重建.bat 會把它蓋掉。
#
# ⚠ 只會匯出「程式碼」。表單上控制項的位置/大小/新增刪除是寫在
#   BuildProject.vbs 裡的，不會被匯出，也不會被這支覆蓋。
#
# 用法：雙擊 匯出.bat，或
#   powershell -NoProfile -ExecutionPolicy Bypass -File ExportVba.ps1
# =====================================================================
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

$xlsm    = Join-Path $root '電訪工具.xlsm'
$srcDir  = Join-Path $root 'vba_source'
$formDir = Join-Path $srcDir 'form_code'
$clsDir  = Join-Path $srcDir 'class_code'
$tmpDir  = Join-Path $root '_export_tmp'

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Write-Step([string]$m) { Write-Host ""; Write-Host $m -ForegroundColor Cyan }
function Write-Ok([string]$m)   { Write-Host "    OK  $m" -ForegroundColor Green }

try {
    Write-Host "=== 從 電訪工具.xlsm 匯出 VBA 程式碼 ===" -ForegroundColor White

    if (-not (Test-Path $xlsm)) { throw "找不到 $xlsm" }
    try {
        $fh = [System.IO.File]::Open($xlsm, 'Open', 'Read', 'None')
        $fh.Close()
    } catch {
        throw "電訪工具.xlsm 目前被開啟中。請先在 Excel 關閉它再匯出。"
    }

    if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force }
    New-Item -ItemType Directory -Path $tmpDir | Out-Null

    # -----------------------------------------------------------------
    # 用 VBScript 走 Excel COM 把每個元件的程式碼倒成 UTF-16 暫存檔。
    # （這台環境的 .NET COM interop 對 Excel 有問題，VBScript 走純
    #   late-bound IDispatch 比較穩，跟 BuildProject.vbs 同一條路。）
    # -----------------------------------------------------------------
    Write-Step "[1] 讀取 .xlsm 內的 VBA 元件"
    $vbsPath = Join-Path $tmpDir '_dump.vbs'
    $vbs = @"
Option Explicit
Dim excel, wb, comp, cm, code, ts, fso, kind, outDir
Set fso = CreateObject("Scripting.FileSystemObject")
outDir = "$tmpDir"
Set excel = CreateObject("Excel.Application")
excel.Visible = False
excel.DisplayAlerts = False
excel.EnableEvents = False
Set wb = excel.Workbooks.Open("$xlsm", 0, True)
For Each comp In wb.VBProject.VBComponents
    kind = ""
    If comp.Type = 1 Then kind = "bas"
    If comp.Type = 2 Then kind = "cls"
    If comp.Type = 3 Then kind = "frm"
    If kind <> "" Then
        Set cm = comp.CodeModule
        code = ""
        If cm.CountOfLines > 0 Then code = cm.Lines(1, cm.CountOfLines)
        Set ts = fso.CreateTextFile(outDir & "\" & kind & "__" & comp.Name & ".txt", True, True)
        ts.Write code
        ts.Close
        WScript.Echo "    " & kind & "  " & comp.Name
    End If
Next
wb.Close False
excel.Quit
Set excel = Nothing
"@
    $u16 = New-Object System.Text.UnicodeEncoding($false, $true)
    [System.IO.File]::WriteAllText($vbsPath, $vbs, $u16)

    & cscript.exe //nologo $vbsPath
    if ($LASTEXITCODE -ne 0) { throw "讀取 VBA 元件失敗（cscript 結束碼 $LASTEXITCODE）" }

    $dumped = @(Get-ChildItem -Path $tmpDir -Filter '*__*.txt' -File)
    if ($dumped.Count -eq 0) { throw "沒有匯出任何元件，請確認已勾選『信任存取 VBA 專案物件模型』。" }
    Write-Ok "$($dumped.Count) 個元件"

    # -----------------------------------------------------------------
    Write-Step "[2] 轉成 UTF-8 寫回 vba_source/"
    $changed = @()
    $same = 0
    foreach ($f in $dumped) {
        $parts = $f.BaseName -split '__', 2
        $kind = $parts[0]
        $name = $parts[1]

        $code = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::Unicode)
        $code = $code.Replace("`r`n", "`n").TrimEnd("`n") + "`n"

        switch ($kind) {
            'bas' {
                # .bas 需要 Attribute VB_Name 這行（CodeModule.Lines 不含它），
                # BuildProject.vbs 是靠 Import 這個檔，模組名稱就來自這一行。
                $dst = Join-Path $srcDir "$name.bas"
                $text = "Attribute VB_Name = ""$name""`n" + $code
            }
            'cls' { $dst = Join-Path $clsDir  "$name.txt"; $text = $code }
            'frm' { $dst = Join-Path $formDir "$name.txt"; $text = $code }
        }

        $old = if (Test-Path $dst) { [System.IO.File]::ReadAllText($dst, $Utf8NoBom) } else { $null }
        if ($old -ceq $text) {
            $same++
        } else {
            [System.IO.File]::WriteAllText($dst, $text, $Utf8NoBom)
            $changed += (Split-Path $dst -Leaf)
        }
    }

    Remove-Item $tmpDir -Recurse -Force

    if ($changed.Count -eq 0) {
        Write-Ok "全部 $same 個檔案與 vba_source/ 相同，沒有需要更新的內容"
    } else {
        Write-Host "    已更新 $($changed.Count) 個檔案（其餘 $same 個未變動）：" -ForegroundColor Yellow
        foreach ($c in $changed) { Write-Host "      $c" -ForegroundColor Yellow }
    }

    Write-Host ""
    Write-Host "=== 匯出完成 ===" -ForegroundColor Green
    Write-Host "    注意：表單控制項的位置/大小/增刪不在匯出範圍內，" -ForegroundColor DarkYellow
    Write-Host "          那些是寫在 BuildProject.vbs 裡的版面程式碼。" -ForegroundColor DarkYellow
    exit 0

} catch {
    Write-Host ""
    Write-Host "=== 匯出失敗 ===" -ForegroundColor Red
    Write-Host "    $($_.Exception.Message)" -ForegroundColor Red
    if (Test-Path $tmpDir) { Remove-Item $tmpDir -Recurse -Force -ErrorAction SilentlyContinue }
    exit 1
}
