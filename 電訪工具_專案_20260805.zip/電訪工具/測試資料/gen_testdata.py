# -*- coding: utf-8 -*-
"""
依 modConstants.MasterHeaders() 產生測試用主資料表，以及配套的
IC 清單 / 通路人員清單（欄位位置依 modRecipientService 實際讀取的欄位排）。

欄位順序一律從 modConstants.bas 直接解析，不手動謄寫，避免兩邊不一致。
"""
import io
import os
import re
import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

HERE = os.path.dirname(os.path.abspath(__file__))
CONST = os.path.join(HERE, "..", "vba_source", "modConstants.bas")

FONT = "Arial"


def vba_list(func_name):
    """從 modConstants.bas 解析出某個 List 函式回傳的欄位陣列。"""
    text = io.open(CONST, encoding="utf-8").read()
    m = re.search(
        r"Public Function %s\(\) As Variant\n((?:.*\n)*?)End Function" % func_name, text
    )
    if not m:
        raise SystemExit("找不到函式 %s" % func_name)
    return "".join(re.findall(r'"([^"]*)"', m.group(1))).split("|")


MASTER = vba_list("MasterHeaders")
BASE = vba_list("RegistrationBaseFields")
ABNORMAL = vba_list("AbnormalItems")
SYSCHK = vba_list("RegistrationSystemCheckFields")
REPORTF = vba_list("RegistrationReportFields")

assert MASTER[:35] == BASE, "前 35 欄應與 RegistrationBaseFields 相同"
assert len(MASTER) == 102, "MasterHeaders 應為 102 欄，實際 %d" % len(MASTER)

HDR_STYLE = dict(
    font=Font(name=FONT, bold=True, size=9, color="FFFFFF"),
    fill=PatternFill("solid", fgColor="4472C4"),
    align=Alignment(horizontal="center", vertical="center", wrap_text=True),
)


def style_header(ws, ncols, row=1):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = HDR_STYLE["font"]
        cell.fill = HDR_STYLE["fill"]
        cell.alignment = HDR_STYLE["align"]
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    ws.row_dimensions[row].height = 46


def blank_case():
    return {h: "" for h in MASTER}


# ---------------------------------------------------------------
# 主資料表測試資料
# ---------------------------------------------------------------
# 情境設計（序號 = 查詢電訪結果時輸入的鍵）
#   1  已完成、無異常
#   2  已完成、有異常（3 項）＋異常敘述        ← 測異常通知寄信
#   3  與序號 2 同一受理編號的另一位電訪對象   ← 測「其他電訪紀錄摘要」
#   4  待電訪（電訪結果欄位全空）              ← 測電訪結果登錄
#   5  待電訪、高齡電訪案件
#   6  待電訪、銷售人員欄直接放 email          ← 測 ResolveSalesPerson 的 email 分支
#   7  待電訪、證券通路（分公司）              ← 測不同通路的分行比對
#   8  已完成、退件（E 類異常）

CASES = [
    dict(seq=1, acc="NB20260701001", branch="台北分行", sales="王小明",
         company="國泰人壽", channel="銀行", region="北一區部",
         holder="趙大同", holder_age=42, insured="趙大同", insured_age=42,
         payer="趙大同", payer_age=42, target="要保人", elderly="",
         interviewer="陳貞君", staff="郭子安", nth="1",
         syschk=[], reportf=[],
         done=True, abnormal=[], desc="",
         date="2026-07-03", time="10:15", review="V", reject="V"),

    dict(seq=2, acc="NB20260701002", branch="板橋分行", sales="李美華",
         company="富邦人壽", channel="銀行", region="北二區部",
         holder="孫小美", holder_age=68, insured="孫小美", insured_age=68,
         payer="孫大偉", payer_age=45, target="要保人", elderly="Y",
         syschk=["系統核3個月內有辦定存解約", "系統檢核3個月內有辦保單借款"],
         reportf=["業報書資金來源定存解約"],
         interviewer="呂美芸", staff="林明儒", nth="1",
         done=True,
         abnormal=["A11投保經驗與高齡評估量表不一致",
                   "B11不清楚定存解約相關風險",
                   "B12不清楚保險與定存是不同的商品"],
         desc="客戶為 68 歲高齡，對於以定存解約支付保費之相關風險說明不清楚，"
              "且無法完整複述商品類型，建議重新對保並補充說明。",
         date="2026-07-04", time="14:30", review="V", reject=""),

    dict(seq=3, acc="NB20260701002", branch="板橋分行", sales="李美華",
         company="富邦人壽", channel="銀行", region="北二區部",
         holder="孫小美", holder_age=68, insured="孫小美", insured_age=68,
         payer="孫大偉", payer_age=45, target="付款人", elderly="Y",
         syschk=["系統核3個月內有辦定存解約"], reportf=["業報書資金來源定存解約"],
         interviewer="呂美芸", staff="林明儒", nth="1",
         done=True, abnormal=["D5繳費之人不同意支付保費"],
         desc="付款人表示並未同意支付本張保單保費，需釐清資金來源。",
         date="2026-07-04", time="15:05", review="V", reject=""),

    dict(seq=4, acc="NB20260702001", branch="台中分行", sales="張志豪",
         company="南山人壽", channel="銀行", region="中一區部",
         holder="周文彬", holder_age=35, insured="周文彬", insured_age=35,
         payer="周文彬", payer_age=35, target="要保人", elderly="",
         syschk=[], reportf=[], interviewer="林明儒", staff="", nth="1",
         done=False, abnormal=[], desc="", date="", time="", review="", reject=""),

    dict(seq=5, acc="NB20260702002", branch="高雄分行", sales="陳雅婷",
         company="新光人壽", channel="銀行", region="南一區部",
         holder="吳阿嬤", holder_age=75, insured="吳阿嬤", insured_age=75,
         payer="吳志明", payer_age=48, target="要保人", elderly="Y",
         syschk=["系統檢核一年內有申辦中貸款記錄",
                 "系統檢核3個月內有撥貸或核准透支額度"],
         reportf=["業報書資金來源貸款", "業報書3個月內有辦貸款"],
         interviewer="謝幸宸", staff="", nth="1",
         done=False, abnormal=[], desc="", date="", time="", review="", reject=""),

    dict(seq=6, acc="NB20260703001", branch="新竹分行",
         sales="林建宏 <lin.chienhung@example.com.tw>",
         company="國泰人壽", channel="銀行", region="北三區部",
         holder="鄭淑芬", holder_age=52, insured="鄭小寶", insured_age=12,
         payer="鄭淑芬", payer_age=52, target="要保人", elderly="",
         syschk=[], reportf=[], interviewer="陳貞君", staff="", nth="1",
         done=False, abnormal=[], desc="", date="", time="", review="", reject=""),

    dict(seq=7, acc="NB20260703002", branch="台北分公司", sales="黃士豪",
         company="富邦人壽", channel="證券", region="證券北區",
         holder="劉建國", holder_age=58, insured="劉建國", insured_age=58,
         payer="劉建國", payer_age=58, target="要保人", elderly="",
         syschk=["系統檢核3個月內有RS債券合約"], reportf=[],
         interviewer="郭子安", staff="", nth="1",
         done=False, abnormal=[], desc="", date="", time="", review="", reject=""),

    dict(seq=8, acc="NB20260704001", branch="台北分行", sales="王小明",
         company="國泰人壽", channel="銀行", region="北一區部",
         holder="蔡怡君", holder_age=29, insured="蔡怡君", insured_age=29,
         payer="蔡怡君", payer_age=29, target="要保人", elderly="",
         syschk=[], reportf=[], interviewer="陳貞君", staff="謝幸宸", nth="2",
         done=True, abnormal=["A2拒訪", "E2退件不續訪"],
         desc="客戶明確表示拒絕接受電訪，經二次聯繫仍拒訪，予以退件不續訪。",
         date="2026-07-05", time="09:40", review="V", reject="X"),
]


def build_row(c):
    d = blank_case()
    d["序號"] = c["seq"]
    d["建檔年月"] = "2026-07"
    d["新契約受理編號"] = c["acc"]
    d["電訪受理人員"] = c["interviewer"]
    d["電訪組受理案件日"] = datetime.date(2026, 7, 2)
    d["保險公司"] = c["company"]
    d["通路"] = c["channel"]
    d["區部"] = c["region"]
    d["銷售分行/分公司"] = c["branch"]
    d["銷售人員"] = c["sales"]
    d["要保人"] = c["holder"]
    d["要保人年齡"] = c["holder_age"]
    d["被保人"] = c["insured"]
    d["被保人年齡"] = c["insured_age"]
    d["付款人"] = c["payer"]
    d["付款人年齡"] = c["payer_age"]
    d["電訪對象"] = c["target"]
    d["是否需進行高齡電訪"] = c["elderly"]
    d["電訪專員"] = c["staff"]
    d["電訪對象第幾次電訪"] = c["nth"]

    # 系統檢核 / 業報書：勾選 Y、未勾選 N（與案件登記畫面寫入規則一致）
    for f in SYSCHK + REPORTF:
        d[f] = "Y" if f in (c["syschk"] + c["reportf"]) else "N"

    if c["done"]:
        d["電訪日期"] = datetime.date(*map(int, c["date"].split("-")))
        d["電訪時間"] = c["time"]
        d["電訪是否完成"] = "V"
        d["電訪過程是否發現異常"] = "V" if c["abnormal"] else ""
        d["電訪單覆核"] = c["review"]
        d["退件查核備註(有電訪無問題V)(未電訪誤送保險公司X)"] = c["reject"]
        d["電訪異常敘述"] = c["desc"]
        # 應訪問項：依系統檢核結果決定要問哪些
        if c["elderly"] == "Y":
            d["電訪應訪問項高齡"] = "V"
        if "業報書資金來源貸款" in c["reportf"] or "業報書3個月內有辦貸款" in c["reportf"]:
            d["電訪應訪問項貸款"] = "V"
        if "系統核3個月內有辦定存解約" in c["syschk"]:
            d["電訪應訪問項定存解約"] = "V"
        if "系統檢核3個月內有辦保險解約" in c["syschk"]:
            d["電訪應訪問項保單解約"] = "V"
        if "系統檢核3個月內有辦保單借款" in c["syschk"]:
            d["電訪應訪問項保單借款"] = "V"
        if "系統檢核3個月內有辦繳清／展期" in c["syschk"]:
            d["電訪應訪問項繳清／展期"] = "V"
        for a in c["abnormal"]:
            assert a in ABNORMAL, "異常項目名稱不存在：%s" % a
            d[a] = "V"
    return d


wb = Workbook()
ws = wb.active
ws.title = "電訪明細"

for i, h in enumerate(MASTER, start=1):
    ws.cell(row=1, column=i, value=h)
style_header(ws, len(MASTER))

for r, c in enumerate(CASES, start=2):
    row = build_row(c)
    for i, h in enumerate(MASTER, start=1):
        v = row[h]
        if v != "":
            cell = ws.cell(row=r, column=i, value=v)
            cell.font = Font(name=FONT, size=9)
            if isinstance(v, datetime.date):
                cell.number_format = "yyyy-mm-dd"

# 欄寬：前 35 欄依內容給寬一點，異常項目欄窄一點（只放 V）
for i, h in enumerate(MASTER, start=1):
    col = get_column_letter(i)
    if i <= 35:
        ws.column_dimensions[col].width = max(10, min(22, len(h) * 1.6))
    elif h in ("電訪異常敘述",):
        ws.column_dimensions[col].width = 50
    elif i >= 46 and i <= 99:
        ws.column_dimensions[col].width = 5.5
    else:
        ws.column_dimensions[col].width = 12

out = os.path.join(HERE, "測試主資料表.xlsx")
wb.save(out)
print("已產生 %s（%d 欄 x %d 筆）" % (os.path.basename(out), len(MASTER), len(CASES)))


# ---------------------------------------------------------------
# IC 清單（欄位位置依 modRecipientService.FindICByBranch：D=分行 E=IC G=IC組長）
# ---------------------------------------------------------------
wb2 = Workbook()
w2 = wb2.active
w2.title = "IC清單"
ic_hdr = ["業務區", "單位代號", "單位名稱", "分行/分公司", "IC", "IC分機", "IC組長"]
for i, h in enumerate(ic_hdr, start=1):
    w2.cell(row=1, column=i, value=h)
style_header(w2, len(ic_hdr))

ic_rows = [
    ["北一區", "0011", "台北分行", "台北分行", "ic.taipei@example.com.tw", "2101", "iclead.north@example.com.tw"],
    ["北二區", "0025", "板橋分行", "板橋分行", "ic.banqiao@example.com.tw", "2205", "iclead.north@example.com.tw"],
    ["北三區", "0037", "新竹分行", "新竹分行", "ic.hsinchu@example.com.tw", "2307", "iclead.north@example.com.tw"],
    ["中一區", "0042", "台中分行", "台中分行", "ic.taichung@example.com.tw", "4102", "iclead.central@example.com.tw"],
    ["南一區", "0058", "高雄分行", "高雄分行", "ic.kaohsiung@example.com.tw", "7108", "iclead.south@example.com.tw"],
    ["證券北區", "9001", "台北分公司", "台北分公司", "ic.sec.taipei@example.com.tw", "9101", "iclead.sec@example.com.tw"],
]
for r, row in enumerate(ic_rows, start=2):
    for i, v in enumerate(row, start=1):
        cell = w2.cell(row=r, column=i, value=v)
        cell.font = Font(name=FONT, size=9)
for i, h in enumerate(ic_hdr, start=1):
    w2.column_dimensions[get_column_letter(i)].width = max(12, len(h) * 2 + 6)
w2.column_dimensions["E"].width = 32
w2.column_dimensions["G"].width = 32

out2 = os.path.join(HERE, "測試IC清單.xlsx")
wb2.save(out2)
print("已產生 %s（%d 筆）" % (os.path.basename(out2), len(ic_rows)))


# ---------------------------------------------------------------
# 通路人員清單
# 欄位位置依 modRecipientService.FindStaffByBranchAndRole：
#   A=員工編號(判斷最後一列) B=姓名 E=單位名稱 G=部級單位名稱 I=職稱 J=工作地點
#   email 是掃整列找 @，放在 K
# ---------------------------------------------------------------
wb3 = Workbook()
w3 = wb3.active
w3.title = "通路人員"
st_hdr = ["員工編號", "姓名", "分機", "部門代號", "單位名稱", "職級",
          "部級單位名稱", "到職日", "職稱", "工作地點", "Email"]
for i, h in enumerate(st_hdr, start=1):
    w3.cell(row=1, column=i, value=h)
style_header(w3, len(st_hdr))

# 每個分行給：銷售人員 1 位、分行經理 1 位、理財業務主管 1 位
staff_rows = []
branches = [
    ("台北分行", "王小明", "wang.hsiaoming", "陳國棟", "chen.kuotung", "劉淑貞", "liu.shuchen"),
    ("板橋分行", "李美華", "li.meihua", "楊承翰", "yang.chenghan", "許雅琳", "hsu.yalin"),
    ("台中分行", "張志豪", "chang.chihhao", "洪明德", "hung.mingteh", "曾嘉玲", "tseng.chialing"),
    ("高雄分行", "陳雅婷", "chen.yating", "邱志偉", "chiu.chihwei", "潘美惠", "pan.meihui"),
    ("新竹分行", "林建宏", "lin.chienhung", "徐文昌", "hsu.wenchang", "范曉薇", "fan.hsiaowei"),
    ("台北分公司", "黃士豪", "huang.shihhao", "簡文龍", "chien.wenlung", "馮怡安", "feng.yian"),
]
emp = 10001
for br, sales, sales_id, mgr, mgr_id, sup, sup_id in branches:
    unit = br + ("理財部" if "分行" in br else "業務部")
    staff_rows.append([str(emp), sales, "1001", "D01", br, "專員",
                       unit, "2020-03-01", "理財專員", br,
                       "%s@example.com.tw" % sales_id])
    emp += 1
    staff_rows.append([str(emp), mgr, "1002", "D01", br, "經理",
                       br + "營運部", "2015-06-15", "分行經理", br,
                       "%s@example.com.tw" % mgr_id])
    emp += 1
    staff_rows.append([str(emp), sup, "1003", "D01", br, "副理",
                       unit, "2017-09-01", "理財業務主管", br,
                       "%s@example.com.tw" % sup_id])
    emp += 1

# 幾筆「條件過寬」會誤中的干擾資料：職稱含「主管」但不是理財業務主管
noise = [
    ["20001", "吳建誠", "1010", "D02", "台北分行", "副理", "台北分行授信部",
     "2016-01-05", "授信主管", "台北分行", "wu.chiencheng@example.com.tw"],
    ["20002", "郭婉婷", "1011", "D03", "台北分行", "副理", "台北分行作業部",
     "2018-04-11", "作業主管", "台北分行", "kuo.wanting@example.com.tw"],
    ["20003", "沈冠宇", "1012", "D04", "板橋分行", "襄理", "板橋分行存匯部",
     "2019-08-20", "存匯主管", "板橋分行", "shen.kuanyu@example.com.tw"],
]
staff_rows.extend(noise)

for r, row in enumerate(staff_rows, start=2):
    for i, v in enumerate(row, start=1):
        cell = w3.cell(row=r, column=i, value=v)
        cell.font = Font(name=FONT, size=9)
for i, h in enumerate(st_hdr, start=1):
    w3.column_dimensions[get_column_letter(i)].width = max(12, len(h) * 2 + 4)
w3.column_dimensions["K"].width = 34
w3.column_dimensions["G"].width = 20

out3 = os.path.join(HERE, "測試通路人員清單.xlsx")
wb3.save(out3)
print("已產生 %s（%d 筆，含 3 筆職稱含「主管」的干擾資料）" % (os.path.basename(out3), len(staff_rows)))
