﻿# =====================================================================
# 電訪工具 — 一鍵重建
#
# 把 vba_source/（UTF-8，平常編輯用）同步成 vba_source_big5/（Big5+CRLF，
# 匯入 VBE 用），再執行 BuildProject.vbs 產生 電訪工具.xlsm。
#
# 只依賴 Windows 內建的 PowerShell 與 cscript，不需要 iconv、Python、
# 也不使用 ADODB。
#
# 用法：雙擊 重建.bat，或直接
#   powershell -NoProfile -ExecutionPolicy Bypass -File Rebuild.ps1
# =====================================================================
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

$srcDir   = Join-Path $root 'vba_source'
$dstDir   = Join-Path $root 'vba_source_big5'
$buildVbs = Join-Path $root 'BuildProject.vbs'
$outXlsm  = Join-Path $root '電訪工具.xlsm'

# UTF-8（不含 BOM，遇到非法位元組直接丟例外，不要靜默替換）
$Utf8Strict = New-Object System.Text.UTF8Encoding($false, $true)
# Big5 = 代碼頁 950。用 Exception fallback，遇到 Big5 沒有的字會丟例外，
# 而不是偷偷換成「?」——本專案就踩過這個坑（全形方括號被換掉）。
$Big5Strict = [System.Text.Encoding]::GetEncoding(
    950,
    (New-Object System.Text.EncoderExceptionFallback),
    (New-Object System.Text.DecoderExceptionFallback))

$step = 0
function Write-Step([string]$msg) {
    $script:step++
    Write-Host ""
    Write-Host "[$script:step] $msg" -ForegroundColor Cyan
}
function Write-Ok([string]$msg)   { Write-Host "    OK  $msg" -ForegroundColor Green }
function Write-Warn2([string]$msg) { Write-Host "    !!  $msg" -ForegroundColor Yellow }

function Read-TextAuto([string]$path) {
    # 依 BOM 判斷編碼；沒有 BOM 先試 UTF-8，失敗再試 Big5。
    # 不能無條件當 UTF-8 讀——把 UTF-16 檔當 UTF-8 讀會讓中文變成替換字元，
    # 而且救不回來（本專案踩過）。
    $bytes = [System.IO.File]::ReadAllBytes($path)
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return @{ Text = [System.Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2); Encoding = 'UTF-16LE' }
    }
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return @{ Text = $Utf8Strict.GetString($bytes, 3, $bytes.Length - 3); Encoding = 'UTF-8(BOM)' }
    }
    try {
        return @{ Text = $Utf8Strict.GetString($bytes); Encoding = 'UTF-8' }
    } catch {
        return @{ Text = [System.Text.Encoding]::GetEncoding(950).GetString($bytes); Encoding = 'Big5' }
    }
}

function Get-UnmappableChars([string]$text) {
    # 找出 Big5 無法表示的字元，連同所在行號回報
    $bad = New-Object System.Collections.ArrayList
    $seen = @{}
    $lines = $text -split "`n"
    for ($i = 0; $i -lt $lines.Count; $i++) {
        foreach ($ch in $lines[$i].ToCharArray()) {
            if ([int]$ch -lt 128) { continue }
            if ($seen.ContainsKey($ch)) { continue }
            try {
                $null = $Big5Strict.GetBytes([string]$ch)
            } catch {
                $seen[$ch] = $true
                [void]$bad.Add(("第 {0} 行：'{1}' (U+{2:X4})" -f ($i + 1), $ch, [int]$ch))
            }
        }
    }
    return $bad
}

try {
    Write-Host "=== 電訪工具 一鍵重建 ===" -ForegroundColor White
    Write-Host "    工作目錄：$root"

    # -----------------------------------------------------------------
    Write-Step "檢查來源資料夾"
    if (-not (Test-Path $srcDir))   { throw "找不到來源資料夾：$srcDir" }
    if (-not (Test-Path $buildVbs)) { throw "找不到建置腳本：$buildVbs" }
    $basFiles   = @(Get-ChildItem -Path $srcDir -Filter '*.bas' -File)
    $formFiles  = @(Get-ChildItem -Path (Join-Path $srcDir 'form_code')  -Filter '*.txt' -File -ErrorAction SilentlyContinue)
    $classFiles = @(Get-ChildItem -Path (Join-Path $srcDir 'class_code') -Filter '*.txt' -File -ErrorAction SilentlyContinue)
    if ($basFiles.Count -eq 0) { throw "$srcDir 底下沒有任何 .bas 模組" }
    Write-Ok "模組 $($basFiles.Count) 支、表單程式碼 $($formFiles.Count) 份、類別模組 $($classFiles.Count) 份"

    # -----------------------------------------------------------------
    Write-Step "確認 BuildProject.vbs 編碼（cscript 讀中文必須是 UTF-16LE）"
    $bp = Read-TextAuto $buildVbs
    if ($bp.Encoding -eq 'UTF-16LE') {
        Write-Ok "已是 UTF-16LE，不需轉換"
    } else {
        if ($bp.Text.IndexOf([char]0xFFFD) -ge 0) {
            throw "BuildProject.vbs 內含替換字元，來源已損毀，無法自動修復。請還原這個檔案。"
        }
        $bytes = [System.Text.Encoding]::Unicode.GetBytes($bp.Text)
        $out = New-Object byte[] ($bytes.Length + 2)
        $out[0] = 0xFF; $out[1] = 0xFE
        [System.Array]::Copy($bytes, 0, $out, 2, $bytes.Length)
        [System.IO.File]::WriteAllBytes($buildVbs, $out)
        Write-Warn2 "偵測到 $($bp.Encoding)，已自動轉成 UTF-16LE"
    }

    # -----------------------------------------------------------------
    Write-Step "同步 vba_source → vba_source_big5（Big5 + CRLF，含無損檢查）"
    if (-not (Test-Path $dstDir)) { New-Item -ItemType Directory -Path $dstDir | Out-Null }
    $formDst = Join-Path $dstDir 'form_code'
    if (-not (Test-Path $formDst)) { New-Item -ItemType Directory -Path $formDst | Out-Null }
    $classDst = Join-Path $dstDir 'class_code'
    if (-not (Test-Path $classDst)) { New-Item -ItemType Directory -Path $classDst | Out-Null }

    $jobs = @()
    foreach ($f in $basFiles)   { $jobs += @{ Src = $f.FullName; Dst = (Join-Path $dstDir $f.Name) } }
    foreach ($f in $formFiles)  { $jobs += @{ Src = $f.FullName; Dst = (Join-Path $formDst $f.Name) } }
    foreach ($f in $classFiles) { $jobs += @{ Src = $f.FullName; Dst = (Join-Path $classDst $f.Name) } }

    $converted = 0
    foreach ($j in $jobs) {
        $info = Read-TextAuto $j.Src
        if ($info.Encoding -eq 'UTF-16LE') {
            throw "$(Split-Path $j.Src -Leaf) 是 UTF-16，vba_source 底下應一律為 UTF-8。請先轉回 UTF-8。"
        }
        # 一律正規化成 CRLF（VBE 匯入與 AddFromString 都吃 CRLF）
        $text = $info.Text.Replace("`r`n", "`n").Replace("`r", "`n").Replace("`n", "`r`n")

        try {
            $bytes = $Big5Strict.GetBytes($text)
        } catch {
            $bad = Get-UnmappableChars $text
            $msg = "$(Split-Path $j.Src -Leaf) 含有 Big5 無法表示的字元：`n      " + ($bad -join "`n      ")
            throw "$msg`n    請改用 Big5 有的字元（例如把全形【】改成半角，或換成其他中文標點）。"
        }

        # 無損驗證：Big5 轉回來必須與原文完全相同
        $back = $Big5Strict.GetString($bytes)
        if ($back -cne $text) {
            throw "$(Split-Path $j.Src -Leaf) 轉 Big5 後內容不一致（轉換有損），已中止。"
        }

        [System.IO.File]::WriteAllBytes($j.Dst, $bytes)
        $converted++
    }
    Write-Ok "$converted 個檔案轉換完成，全部無損"

    # -----------------------------------------------------------------
    Write-Step "檢查輸出檔沒有被佔用"
    if (Test-Path $outXlsm) {
        try {
            $fsCheck = [System.IO.File]::Open($outXlsm, 'Open', 'ReadWrite', 'None')
            $fsCheck.Close()
            Write-Ok "電訪工具.xlsm 可覆寫"
        } catch {
            throw "電訪工具.xlsm 目前被開啟中，無法覆寫。請先在 Excel 關閉它再重跑。"
        }
    } else {
        Write-Ok "尚無舊檔，將建立新檔"
    }

    # -----------------------------------------------------------------
    Write-Step "執行 BuildProject.vbs（會開啟 Excel，過程中請勿點它）"
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    & cscript.exe //nologo $buildVbs
    $code = $LASTEXITCODE
    $sw.Stop()
    if ($code -ne 0) { throw "BuildProject.vbs 結束代碼 $code，建置失敗。" }
    if (-not (Test-Path $outXlsm)) { throw "建置指令跑完但找不到 電訪工具.xlsm。" }

    Write-Host ""
    Write-Host "=== 重建完成（耗時 $([math]::Round($sw.Elapsed.TotalSeconds,1)) 秒）===" -ForegroundColor Green
    Write-Host "    $outXlsm"
    Write-Host "    大小 $([math]::Round((Get-Item $outXlsm).Length/1KB,1)) KB"
    exit 0

} catch {
    Write-Host ""
    Write-Host "=== 重建失敗 ===" -ForegroundColor Red
    Write-Host "    $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
