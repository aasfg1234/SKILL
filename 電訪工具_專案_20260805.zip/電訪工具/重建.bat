@echo off
REM =====================================================================
REM  Telemarketing tool - one click rebuild
REM  This launcher is intentionally pure ASCII so it is codepage-safe.
REM  All logic and all Chinese messages live in Rebuild.ps1.
REM =====================================================================
chcp 950 >nul 2>&1
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Rebuild.ps1"
set RC=%ERRORLEVEL%

echo.
if "%RC%"=="0" (
    echo [OK] done
) else (
    echo [FAIL] exit code %RC%
)
echo.
pause
exit /b %RC%
