@echo off
REM =====================================================================
REM  Export VBA code from the built .xlsm back into vba_source/
REM  Pure ASCII launcher; all logic and Chinese output live in ExportVba.ps1
REM =====================================================================
chcp 950 >nul 2>&1
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ExportVba.ps1"
set RC=%ERRORLEVEL%

echo.
if "%RC%"=="0" (
    echo [OK] done
) else (
    echo [FAIL] exit code %RC%
)
echo.
pause
exit /b %RC%
