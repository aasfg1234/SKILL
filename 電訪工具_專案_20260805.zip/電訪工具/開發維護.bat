@echo off
REM =====================================================================
REM  Open the tool workbook in maintenance mode (macros/events suppressed)
REM  so Excel stays visible and you can press Alt+F11 to reach the VBE.
REM  Pure ASCII launcher; Chinese output lives in OpenForEdit.vbs
REM =====================================================================
chcp 950 >nul 2>&1
cd /d "%~dp0"

cscript.exe //nologo "%~dp0OpenForEdit.vbs"
set RC=%ERRORLEVEL%

echo.
if not "%RC%"=="0" (
    echo [FAIL] exit code %RC%
    pause
)
exit /b %RC%
