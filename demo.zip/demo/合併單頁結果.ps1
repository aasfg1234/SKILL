﻿# 這支程式用來做「AI 生成單頁」的最後一步：
# 把剛剛下載的 single-slide-ai-package.zip 裡的任務編號，
# 貼到我準備好的投影片內容上，做出可以匯入的 single-slide-result.json。
#
# 用法：雙擊這個檔案，或在終端機打：
#   powershell -ExecutionPolicy Bypass -File "合併單頁結果.ps1"
#
# 前提：已經在編輯器按過「下載單頁 AI 壓縮檔」，
#       而且 single-slide-ai-package.zip 已經在「下載」資料夾裡。

$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$downloads = Join-Path $env:USERPROFILE 'Downloads'
$templatePath = Join-Path $scriptDir 'demo-single-slide-template.json'

Write-Host '正在找最新的 single-slide-ai-package.zip ...'
$zip = Get-ChildItem -Path $downloads -Filter 'single-slide-ai-package*.zip' -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1

if (-not $zip) {
    Write-Host ''
    Write-Host '找不到 single-slide-ai-package.zip。' -ForegroundColor Red
    Write-Host '請先在編輯器的「AI 生成單頁」畫面按「下載單頁 AI 壓縮檔」，再重新執行這支程式。'
    try { Read-Host '按 Enter 關閉視窗' } catch {}
    exit 1
}

Write-Host "找到：$($zip.Name)"

$extractDir = Join-Path $env:TEMP ('slideforge-single-slide-' + [guid]::NewGuid())
New-Item -ItemType Directory -Path $extractDir -Force | Out-Null
Expand-Archive -Path $zip.FullName -DestinationPath $extractDir -Force

$requestPath = Get-ChildItem -Path $extractDir -Filter 'request.json' -Recurse | Select-Object -First 1
if (-not $requestPath) {
    Write-Host ''
    Write-Host '壓縮檔裡沒有 request.json，檔案可能壞了。' -ForegroundColor Red
    try { Read-Host '按 Enter 關閉視窗' } catch {}
    exit 1
}

$request = Get-Content -Path $requestPath.FullName -Raw -Encoding UTF8 | ConvertFrom-Json

if (-not (Test-Path $templatePath)) {
    Write-Host ''
    Write-Host "找不到範本檔：$templatePath" -ForegroundColor Red
    Write-Host '這支程式要跟 demo-single-slide-template.json 放在同一個資料夾。'
    try { Read-Host '按 Enter 關閉視窗' } catch {}
    exit 1
}

$template = Get-Content -Path $templatePath -Raw -Encoding UTF8 | ConvertFrom-Json

$result = [ordered]@{
    protocol             = 'ai-presentation-single-slide/v1'
    requestId            = $request.requestId
    sourcePresentationId = $request.sourcePresentationId
    insertAfterSlideId   = $request.context.insertAfterSlideId
    slide                = $template.slide
}

$outPath = Join-Path $downloads 'single-slide-result.json'
$json = $result | ConvertTo-Json -Depth 30
[System.IO.File]::WriteAllText($outPath, $json, [System.Text.UTF8Encoding]::new($false))

Write-Host ''
Write-Host '做好了！' -ForegroundColor Green
Write-Host "檔案在：$outPath"
Write-Host '回到編輯器，按「匯入 AI 單頁結果」，選這個檔案就可以了。'
Write-Host ''
try { Read-Host '按 Enter 關閉視窗' } catch {}
