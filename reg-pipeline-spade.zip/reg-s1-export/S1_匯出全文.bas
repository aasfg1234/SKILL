Option Explicit

'==========================================================
' S1�GWord ����ץX�]��Ū�A���|�ק���^
'
' ���X�T�تF��G
'   01_paragraphs.csv   ����A�@�q�@�C�A�t����P�ϧμаO
'   02_shapes.csv       �ϧθ̪���r
'   tables\T001.md ...  �@�i���@����
'
' �w�B�z�GWord �۰ʽs���B�����Ÿ��B�ؿ��˦��B�X���x�s��B�s�չϧ�
'
' �ϥΤ覡�G
'   1. Word �}�ҭ�l�ɨæs��
'   2. Alt + F11 �}�� VBA �s�边
'   3. ���J -> �ҲաA�⥻�ɤ��e����K�W
'   4. ����I�b Sub S1_�ץX����() �̭��A�� F5
'==========================================================

' �q�����
Private pStart() As Long
Private pStyle() As String
Private pInTbl() As Boolean
Private pList() As String
Private pText() As String
Private pChap() As String
Private pSect() As String
Private pCount As Long

' �ϧμȦs
Private shBuf As String
Private shCount As Long


'==========================================================
' �D�{���G�]�o�@��N�n
'==========================================================
' Silent = True �ɤ��������T���A���۰ʤƥΡC
' �H�ۤv�b Word �̰���ɤ��n�a�ѼơC
Sub S1_�ץX����(Optional ByVal Silent As Boolean = False)

    Dim doc As Document
    Set doc = ActiveDocument

    If doc.Path = "" Then
        MsgBox "�Х���o�����s�ɡA�A����@���C", vbExclamation
        Exit Sub
    End If

    Application.ScreenUpdating = False

    Dim outDir As String
    outDir = doc.Path & Application.PathSeparator

    Dim tblDir As String
    tblDir = outDir & "tables"
    If Dir(tblDir, vbDirectory) = "" Then MkDir tblDir

    '===== �Ĥ@�B�G���y�Ҧ��q�� =====
    ScanAllParagraphs doc

    '===== �ĤG�B�G���������m =====
    Dim nT As Long
    nT = doc.Tables.Count

    Dim tPos() As Long
    If nT > 0 Then
        ReDim tPos(1 To nT)
        Dim ti As Long
        For ti = 1 To nT
            tPos(ti) = doc.Tables(ti).Range.Start
        Next ti
    End If

    '===== �ĤT�B�G�����ϧΦ�m =====
    Dim nS As Long
    Dim sPos() As Long
    Dim sIdx() As Long
    CollectShapePositions doc, nS, sPos, sIdx

    '===== �ĥ|�B�G��X 01_paragraphs.csv =====
    Dim sb As String
    sb = "�Ǹ�,��m,����,�Ҧb��,�Ҧb�`,�˦�,�b���椺,�۰ʽs��,����,�r��" & vbCrLf

    Dim rowNo As Long
    Dim i As Long
    Dim tp As Long, sp As Long
    Dim kind As String
    Dim markerText As String
    Dim cChap As String, cSect As String

    tp = 1
    sp = 1
    rowNo = 0

    For i = 1 To pCount

        ' ���ɤW��m�b�o�@�q���e������аO
        Do While nT > 0 And tp <= nT
            If tPos(tp) <= pStart(i) Then
                rowNo = rowNo + 1
                LookupAnchor tPos(tp), cChap, cSect
                markerText = "[[TABLE:" & Format$(tp, "000") & "]]"
                sb = sb & rowNo & "," & tPos(tp) & "," & _
                     CsvF("����аO") & "," & CsvF(cChap) & "," & CsvF(cSect) & "," & _
                     CsvF("") & "," & CsvF("N") & "," & CsvF("") & "," & _
                     CsvF(markerText) & "," & Len(markerText) & vbCrLf
                tp = tp + 1
            Else
                Exit Do
            End If
        Loop

        ' �A�ɤW��m�b�o�@�q���e���ϧμаO
        Do While nS > 0 And sp <= nS
            If sPos(sp) <= pStart(i) Then
                rowNo = rowNo + 1
                LookupAnchor sPos(sp), cChap, cSect
                markerText = "[[SHAPE:" & Format$(sp, "000") & "]]"
                sb = sb & rowNo & "," & sPos(sp) & "," & _
                     CsvF("�ϧμаO") & "," & CsvF(cChap) & "," & CsvF(cSect) & "," & _
                     CsvF("") & "," & CsvF("N") & "," & CsvF("") & "," & _
                     CsvF(markerText) & "," & Len(markerText) & vbCrLf
                sp = sp + 1
            Else
                Exit Do
            End If
        Loop

        ' �q������
        If IsToc(pStyle(i)) Then
            kind = "�ؿ�"
        ElseIf pInTbl(i) Then
            kind = "���椺"
        ElseIf IsChapter(pText(i)) Then
            kind = "��"
        ElseIf IsSection(pText(i)) Then
            kind = "�`"
        Else
            kind = "����"
        End If

        rowNo = rowNo + 1
        sb = sb & rowNo & "," & pStart(i) & "," & _
             CsvF(kind) & "," & CsvF(pChap(i)) & "," & CsvF(pSect(i)) & "," & _
             CsvF(pStyle(i)) & "," & CsvF(IIf(pInTbl(i), "Y", "N")) & "," & _
             CsvF(pList(i)) & "," & CsvF(pText(i)) & "," & Len(pText(i)) & vbCrLf
    Next i

    ' �����G�٨S��X���аO�ɦb�̫�
    Do While nT > 0 And tp <= nT
        rowNo = rowNo + 1
        LookupAnchor tPos(tp), cChap, cSect
        markerText = "[[TABLE:" & Format$(tp, "000") & "]]"
        sb = sb & rowNo & "," & tPos(tp) & "," & CsvF("����аO") & "," & _
             CsvF(cChap) & "," & CsvF(cSect) & "," & CsvF("") & "," & CsvF("N") & "," & _
             CsvF("") & "," & CsvF(markerText) & "," & Len(markerText) & vbCrLf
        tp = tp + 1
    Loop

    Do While nS > 0 And sp <= nS
        rowNo = rowNo + 1
        LookupAnchor sPos(sp), cChap, cSect
        markerText = "[[SHAPE:" & Format$(sp, "000") & "]]"
        sb = sb & rowNo & "," & sPos(sp) & "," & CsvF("�ϧμаO") & "," & _
             CsvF(cChap) & "," & CsvF(cSect) & "," & CsvF("") & "," & CsvF("N") & "," & _
             CsvF("") & "," & CsvF(markerText) & "," & Len(markerText) & vbCrLf
        sp = sp + 1
    Loop

    WriteUtf8 outDir & "01_paragraphs.csv", sb

    '===== �Ĥ��B�G��X 02_shapes.csv =====
    shBuf = "�ϧνs��,�l��,���I��m,�Ҧb��,�Ҧb�`,�ϧΦW��,��,�W,�e,��,��r,�r��" & vbCrLf
    shCount = 0

    Dim k As Long
    For k = 1 To nS
        DumpShape doc.Shapes(sIdx(k)), Format$(k, "000"), 0, sPos(k)
    Next k

    WriteUtf8 outDir & "02_shapes.csv", shBuf

    '===== �Ĥ��B�G��X���� =====
    Dim tblDone As Long
    For ti = 1 To nT
        DumpTable doc, doc.Tables(ti), ti, tblDir
        tblDone = tblDone + 1
    Next ti

    '===== �έp =====
    Dim cChapN As Long, cSectN As Long, cEmpty As Long
    For i = 1 To pCount
        If Not pInTbl(i) And Not IsToc(pStyle(i)) Then
            If IsChapter(pText(i)) Then cChapN = cChapN + 1
            If IsSection(pText(i)) Then cSectN = cSectN + 1
            If Len(pText(i)) = 0 Then cEmpty = cEmpty + 1
        End If
    Next i

    Application.ScreenUpdating = True

    If Not Silent Then
        MsgBox "S1 �ץX�����C" & vbCrLf & vbCrLf & _
               "���G" & cChapN & "   �]���ӬO 12�^" & vbCrLf & _
               "�`�G" & cSectN & vbCrLf & _
               "����G" & nT & "   �]���ӬO 18�^" & vbCrLf & _
               "�ϧΡG" & nS & vbCrLf & _
               "�ϧΤ�r���ơG" & shCount & vbCrLf & _
               "�`�C�ơG" & rowNo & vbCrLf & vbCrLf & _
               "�ɮצ�m�G" & vbCrLf & outDir, vbInformation
    End If

End Sub


'==========================================================
' ���y�Ҧ��q���A�ú�X�C�@�q���ݪ����P�`
'==========================================================
Private Sub ScanAllParagraphs(ByVal doc As Document)

    Dim cap As Long
    cap = 6000
    ReDim pStart(1 To cap)
    ReDim pStyle(1 To cap)
    ReDim pInTbl(1 To cap)
    ReDim pList(1 To cap)
    ReDim pText(1 To cap)
    ReDim pChap(1 To cap)
    ReDim pSect(1 To cap)
    pCount = 0

    Dim p As Paragraph
    Dim sty As String
    Dim lead As String
    Dim body As String
    Dim full As String
    Dim curChap As String, curSect As String

    curChap = ""
    curSect = ""

    For Each p In doc.Paragraphs

        sty = ""
        On Error Resume Next
        sty = p.Style
        On Error GoTo 0

        lead = ""
        On Error Resume Next
        lead = p.Range.ListFormat.ListString
        On Error GoTo 0
        lead = CleanText(lead)

        body = CleanText(p.Range.Text)

        If Len(lead) > 0 And Len(body) > 0 Then
            full = lead & " " & body
        ElseIf Len(lead) > 0 Then
            full = lead
        Else
            full = body
        End If

        pCount = pCount + 1
        If pCount > cap Then
            cap = cap * 2
            ReDim Preserve pStart(1 To cap)
            ReDim Preserve pStyle(1 To cap)
            ReDim Preserve pInTbl(1 To cap)
            ReDim Preserve pList(1 To cap)
            ReDim Preserve pText(1 To cap)
            ReDim Preserve pChap(1 To cap)
            ReDim Preserve pSect(1 To cap)
        End If

        pStart(pCount) = p.Range.Start
        pStyle(pCount) = sty
        pInTbl(pCount) = p.Range.Information(wdWithInTable)
        pList(pCount) = lead
        pText(pCount) = full

        ' �u���D����B�D�ؿ����q���~�|���ܥثe�����`
        If Not pInTbl(pCount) And Not IsToc(sty) Then
            If IsChapter(full) Then
                curChap = full
                curSect = ""
            ElseIf IsSection(full) Then
                curSect = full
            End If
        End If

        pChap(pCount) = curChap
        pSect(pCount) = curSect
    Next p

End Sub


'==========================================================
' �d�Y�Ӧ�m���ݪ����P�`
'==========================================================
Private Sub LookupAnchor(ByVal pos As Long, ByRef oChap As String, ByRef oSect As String)

    Dim i As Long
    oChap = ""
    oSect = ""

    For i = 1 To pCount
        If pStart(i) < pos Then
            oChap = pChap(i)
            oSect = pSect(i)
        Else
            Exit For
        End If
    Next i

End Sub


'==========================================================
' �����ϧΦ�m�A�÷Ӥ�󶶧ǱƦn
'==========================================================
Private Sub CollectShapePositions(ByVal doc As Document, _
                                  ByRef n As Long, _
                                  ByRef posArr() As Long, _
                                  ByRef idxArr() As Long)

    n = doc.Shapes.Count
    If n = 0 Then Exit Sub

    ReDim posArr(1 To n)
    ReDim idxArr(1 To n)

    Dim i As Long
    Dim ap As Long

    For i = 1 To n
        ap = 0
        On Error Resume Next
        ap = doc.Shapes(i).Anchor.Start
        On Error GoTo 0
        posArr(i) = ap
        idxArr(i) = i
    Next i

    ' �̦�m�Ѥp��j�Ƨ�
    Dim j As Long
    Dim tv As Long
    For i = 1 To n - 1
        For j = 1 To n - i
            If posArr(j) > posArr(j + 1) Then
                tv = posArr(j): posArr(j) = posArr(j + 1): posArr(j + 1) = tv
                tv = idxArr(j): idxArr(j) = idxArr(j + 1): idxArr(j + 1) = tv
            End If
        Next j
    Next i

End Sub


'==========================================================
' ��X�@�ӹϧΪ���r�A�s�շ|���U��
'==========================================================
Private Sub DumpShape(ByVal shp As Shape, _
                      ByVal gid As String, _
                      ByVal sub_ As Long, _
                      ByVal anchorPos As Long)

    Dim isGroup As Boolean
    isGroup = False
    On Error Resume Next
    isGroup = (shp.Type = msoGroup)
    On Error GoTo 0

    If isGroup Then
        Dim m As Long
        Dim cnt As Long
        cnt = 0
        On Error Resume Next
        cnt = shp.GroupItems.Count
        On Error GoTo 0
        For m = 1 To cnt
            DumpShape shp.GroupItems(m), gid, m, anchorPos
        Next m
        Exit Sub
    End If

    Dim txt As String
    txt = ""
    On Error Resume Next
    If shp.TextFrame.HasText Then txt = shp.TextFrame.TextRange.Text
    On Error GoTo 0
    txt = CleanText(txt)

    If Len(txt) = 0 Then Exit Sub

    Dim cChap As String, cSect As String
    LookupAnchor anchorPos, cChap, cSect

    Dim nm As String, L As Single, T As Single, W As Single, H As Single
    nm = "": L = 0: T = 0: W = 0: H = 0
    On Error Resume Next
    nm = shp.Name
    L = shp.Left
    T = shp.Top
    W = shp.Width
    H = shp.Height
    On Error GoTo 0

    shCount = shCount + 1

    shBuf = shBuf & CsvF(gid) & "," & sub_ & "," & anchorPos & "," & _
            CsvF(cChap) & "," & CsvF(cSect) & "," & CsvF(nm) & "," & _
            Format$(L, "0") & "," & Format$(T, "0") & "," & _
            Format$(W, "0") & "," & Format$(H, "0") & "," & _
            CsvF(txt) & "," & Len(txt) & vbCrLf

End Sub


'==========================================================
' ��X�@�i���榨 Markdown
'==========================================================
Private Sub DumpTable(ByVal doc As Document, _
                      ByVal tbl As Table, _
                      ByVal tno As Long, _
                      ByVal folder As String)

    Dim tid As String
    tid = "T" & Format$(tno, "000")

    Dim cChap As String, cSect As String
    LookupAnchor tbl.Range.Start, cChap, cSect

    Dim maxR As Long, maxC As Long
    Dim nonEmpty As Long, totChars As Long
    Dim c As Cell
    Dim s As String

    maxR = 0: maxC = 0: nonEmpty = 0: totChars = 0

    On Error Resume Next
    For Each c In tbl.Range.Cells
        If c.RowIndex > maxR Then maxR = c.RowIndex
        If c.ColumnIndex > maxC Then maxC = c.ColumnIndex
        s = CleanText(c.Range.Text)
        If Len(s) > 0 Then
            nonEmpty = nonEmpty + 1
            totChars = totChars + Len(s)
        End If
    Next c
    On Error GoTo 0

    Dim md As String
    md = "# " & tid & vbCrLf & vbCrLf
    md = md & "- �ӷ����G" & doc.Name & vbCrLf
    md = md & "- �Ҧb���G" & IIf(cChap = "", "�]�L�^", cChap) & vbCrLf
    md = md & "- �Ҧb�`�G" & IIf(cSect = "", "�]�L�^", cSect) & vbCrLf
    md = md & "- �W�ҡG" & maxR & " �C x " & maxC & " ��" & vbCrLf
    md = md & "- �D�ťծ�G" & nonEmpty & "   �`�r�ơG" & totChars & vbCrLf

    If tbl.Uniform Then
        md = md & "- �X���x�s��G�L" & vbCrLf
    Else
        md = md & "- �X���x�s��G���C�Ů�w�ѤW��ȩ��U�񺡡C" & vbCrLf
    End If

    md = md & vbCrLf & BuildMarkdown(tbl, maxR, maxC) & vbCrLf

    WriteUtf8 folder & Application.PathSeparator & tid & ".md", md

End Sub


'==========================================================
' �����զ� Markdown�A�óB�z�X���x�s��
'==========================================================
Private Function BuildMarkdown(ByVal tbl As Table, _
                               ByVal maxR As Long, _
                               ByVal maxC As Long) As String

    If maxR < 1 Or maxC < 1 Then
        BuildMarkdown = "�]�����S���iŪ�������e�^"
        Exit Function
    End If

    Dim grid() As String
    Dim filled() As Boolean
    ReDim grid(1 To maxR, 1 To maxC)
    ReDim filled(1 To maxR, 1 To maxC)

    Dim c As Cell
    Dim r As Long, k As Long

    On Error Resume Next
    For Each c In tbl.Range.Cells
        r = c.RowIndex
        k = c.ColumnIndex
        If r >= 1 And r <= maxR And k >= 1 And k <= maxC Then
            grid(r, k) = Replace(CleanText(c.Range.Text), "|", "\|")
            filled(r, k) = True
        End If
    Next c
    On Error GoTo 0

    For r = 2 To maxR
        For k = 1 To maxC
            If Not filled(r, k) Then grid(r, k) = grid(r - 1, k)
        Next k
    Next r

    Dim outStr As String
    Dim line As String

    line = "|"
    For k = 1 To maxC
        line = line & " " & grid(1, k) & " |"
    Next k
    outStr = line & vbCrLf

    line = "|"
    For k = 1 To maxC
        line = line & " --- |"
    Next k
    outStr = outStr & line & vbCrLf

    For r = 2 To maxR
        line = "|"
        For k = 1 To maxC
            line = line & " " & grid(r, k) & " |"
        Next k
        outStr = outStr & line & vbCrLf
    Next r

    BuildMarkdown = outStr

End Function


'==========================================================
' �p�u��
'==========================================================

Private Function CleanText(ByVal s As String) As String
    s = Replace(s, Chr(7), " ")
    s = Replace(s, Chr(9), " ")
    s = Replace(s, Chr(10), " ")
    s = Replace(s, Chr(11), " ")
    s = Replace(s, Chr(12), " ")
    s = Replace(s, Chr(13), " ")
    s = Replace(s, Chr(30), " ")
    s = Replace(s, Chr(31), " ")
    s = Replace(s, ChrW(&HA0), " ")
    s = Replace(s, ChrW(&H3000), " ")
    s = Replace(s, ChrW(&HFEFF), "")
    s = Replace(s, ChrW(&H200B), "")
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    CleanText = Trim$(s)
End Function

Private Function CsvF(ByVal s As String) As String
    CsvF = """" & Replace(s, """", """""") & """"
End Function

Private Function IsToc(ByVal sty As String) As Boolean
    IsToc = (InStr(sty, "�ؿ�") > 0 Or InStr(sty, "TOC") > 0)
End Function

Private Function IsChapter(ByVal s As String) As Boolean
    IsChapter = False
    If Left$(s, 1) = "��" And InStr(Left$(s, 8), "��") > 0 Then IsChapter = True
End Function

Private Function IsSection(ByVal s As String) As Boolean
    IsSection = False
    If Left$(s, 1) = "��" And InStr(Left$(s, 8), "�`") > 0 Then IsSection = True
End Function

Private Sub WriteUtf8(ByVal path As String, ByVal content As String)
    Dim st As Object
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2
    st.Charset = "UTF-8"
    st.Open
    st.WriteText content
    st.SaveToFile path, 2
    st.Close
    Set st = Nothing
End Sub
