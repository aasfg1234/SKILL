# -*- coding: utf-8 -*-
r"""
S4：依編號層級把條文切到最小可辨識單位

用法：
    py S4_二次切分.py <資料夾>

輸入：<資料夾>\03_items.csv
輸出：<資料夾>\04_items2.csv
      <資料夾>\S4_二次切分報告.txt

規則照 S4_二次切分_prompt_v3.md：
  - 全文沒有換行，絕對不靠「行開頭」判斷
  - 只排除「前面是第」與「後面是條款項目章節點」
  - 第一個切點之前的文字獨立成 00 母文，不跟第一項合併
  - 每層都繼續辨識 B / C / D / E，不以字數決定是否停止
無損驗證沒過就不寫檔。
"""

import csv
import os
import re
import sys

LIMIT = 800          # 僅供報告與「仍過長」品質提示使用
MAX_ROUND = 4        # 最多切四層：B / C / D / E
FIRST_ROUND_ALL = True   # 保留相容欄位；目前每一輪都會嘗試辨識下一層

CN_MAP = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5,
          "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}

STOP_AFTER = "條款項目章節點"

NEW_COLS = ["切分輪次", "父ID", "切分狀態", "切點符號", "是否前言",
            "款標題", "第一層", "第二層", "第三層", "第四層", "第五層",
            "階層路徑", "階層", "階層深度", "上層ID"]

LEVEL_COLS = ["第一層", "第二層", "第三層", "第四層", "第五層"]

lines = []


def say(s=""):
    lines.append(s)


def cn2int(s):
    s = s.strip()
    if not s:
        return None
    if "十" in s:
        left, _, right = s.partition("十")
        n = (CN_MAP.get(left, 1) if left else 1) * 10
        if right:
            n += CN_MAP.get(right, 0)
        return n
    return CN_MAP.get(s)


# ------------------------------------------------------------------
# 候選符號。括號類要先找，才不會被 A、C 搶走
# ------------------------------------------------------------------
FINDERS = [
    ("B", re.compile(r"[（(]\s*([一二三四五六七八九十]{1,3})\s*[）)]")),
    ("D", re.compile(r"[（(]\s*(\d{1,3})\s*[）)]")),
    ("A", re.compile(r"([一二三四五六七八九十]{1,3})\s*[、，,]")),
    ("C", re.compile(r"(\d{1,3})\s*[、.．]")),
    ("E", re.compile(r"([A-Za-z])\s*[.．]")),
]


PAIRS = [("《", "》"), ("「", "」"), ("『", "』"), ("【", "】"), ("〈", "〉")]


def quoted_spans(text):
    """找出被書名號、引號括起來的區段。

    那裡面的「一、」是在引用別的文件的條次，不是本條的編號。
    例如：依《…一、財產保險商品一般進件作業程序》之(二)至(八)辦理
    """
    spans = []
    for op, cl in PAIRS:
        start = 0
        while True:
            i = text.find(op, start)
            if i < 0:
                break
            j = text.find(cl, i + 1)
            if j < 0:
                break
            spans.append((i, j + 1))
            start = j + 1
    return spans


def candidates(text):
    """回傳 {符號類型: [(位置, 數值, 符號原文), ...]}，已排除引用。"""
    found = {}
    taken = []          # 被括號類佔走的區段，避免 A、C 重複認
    quoted = quoted_spans(text)

    for kind, pat in FINDERS:
        hits = []
        for m in pat.finditer(text):
            a, b = m.span()

            if kind in ("A", "C") and any(x <= a < y for x, y in taken):
                continue

            # 排除一：符號前面緊鄰的字是「第」，那是引用
            if a > 0 and text[a - 1] == "第":
                continue
            # 排除一之二：前面是「分之」，那是百分之／千分之，是數量詞
            #   A 型收逗號之後才會撞到「百分之二十五，」，真檔實測兩處。
            #   只擋「分之」，不能擋整個「之」——「方式為之1、 使用憑證…」
            #   那個 1、 是真的編號，擋掉會讓整串 1、2、3、 都切不出來。
            if a >= 2 and text[a - 2:a] == "分之":
                continue
            # 排除三：前面緊鄰的是英文字母或數字，那是代號不是編號
            #         例如「IR1、IR2、IR3」是三個風險等級的名字，不是三條規定
            if a > 0 and (text[a - 1].isascii() and text[a - 1].isalnum()):
                continue
            # 排除四：在書名號或引號裡面，那是在引用別份文件的條次
            if any(x <= a < y for x, y in quoted):
                continue
            # 排除二：符號後面緊鄰的字是 條款項目章節點
            if b < len(text) and text[b] in STOP_AFTER:
                continue

            raw = m.group(1)
            val = int(raw) if raw.isdigit() else (
                1 if kind == "E" else cn2int(raw))
            if kind == "E":
                val = ord(raw.upper()) - 64
            if val is None:
                continue
            hits.append((a, val, m.group(0)))

        if kind in ("B", "D"):
            taken.extend((m.span() for m in pat.finditer(text)))
        found[kind] = hits
    return found


def longest_run(hits, starts=(1,)):
    """沿著位置往後走，串出最長的一條編號序列。

    收的條件有兩種：
      一、數值剛好是上一個加 1
      二、數值是 1，代表換一段重新編號（同一條底下有兩組 1.2.3.）

    起點預設要是 1。如果這一段本身從「2.」開頭（母條文被切開留下的
    下半段），就額外允許從它自己的號碼起頭。
    """
    best = []
    for i, (pos0, val0, raw0) in enumerate(hits):
        if val0 not in starts:
            continue
        chain = [(pos0, val0, raw0)]
        want = val0 + 1
        for pos2, val2, raw2 in hits[i + 1:]:
            if pos2 <= chain[-1][0]:
                continue
            if val2 == want:
                chain.append((pos2, val2, raw2))
                want += 1
            elif val2 == 1:
                # 換一段，重新從 1 編
                chain.append((pos2, val2, raw2))
                want = 2
        if len(chain) > len(best):
            best = chain
    return best


def outer_between(cands, win_kind, run):
    """勝出的那一串中途重新從 1 編，中間夾著的另一類才是真正的外層。

    「同一條底下有兩組 1.2.3.」這種形狀，多半不是真的重新編號，
    而是中間有一個更外層的編號沒被認出來。

    實例：006-001-008
        2. 檢核人員：…  3. 檢核方式：…  4. 檢核結果…。
        (四) 保險代理部針對異常減額繳清…          <- 夾在這裡
        1. 執行時間：…  2. 檢視標準：…  …5.
    C 類串成 2,3,4,1,2,3,4,5，中間重新從 1 編。那個 1 之前夾著 (四)，
    所以 B 才是外層。原本的規則會選 C，(四) 就被併進上一條。

    找不到夾在中間的就回 None，維持原本的選法。
    """
    reset = None
    for i in range(1, len(run)):
        if run[i][1] == 1:
            reset = (run[i - 1][0], run[i][0])
            break

    # 勝出串有時因起點規則只收到重編後的 1,2,3；重編前的 2,3,4
    # 仍在候選裡，但不在 run 裡。不要放寬 pick() 的 starts（會造成其他
    # 誤切），改從同類型完整候選找「非 1 → 1」的邊界。
    if reset is None:
        all_hits = cands.get(win_kind, [])
        for i in range(1, len(all_hits)):
            if all_hits[i][1] == 1 and all_hits[i - 1][1] > 1:
                reset = (all_hits[i - 1][0], all_hits[i][0])
                break
    if reset is None:
        return None

    pp, rp = reset
    for kind, hits in cands.items():
        if kind == win_kind:
            continue
        inside = [h for h in hits if pp < h[0] < rp]
        if not inside:
            continue
        r2 = longest_run(hits, (1, inside[0][1]))
        if len(r2) >= 2 and any(pp < p < rp for p, _, _ in r2):
            return kind, r2
    return None


def pick(text):
    """選出這一筆要用哪一種符號切。回傳 (符號類型, 切點串)。"""
    head_k, head_raw = head_sym(text)
    head_v = None
    if head_raw:
        m = re.search(r"([一二三四五六七八九十]{1,3}|\d{1,3}|[A-Za-z])", head_raw)
        if m:
            t = m.group(1)
            head_v = (int(t) if t.isdigit()
                      else (ord(t.upper()) - 64 if re.match(r"^[A-Za-z]$", t)
                            else cn2int(t)))
    cands = candidates(text)
    runs = []
    for kind, hits in cands.items():
        starts = (1,)
        if kind == head_k and head_v and head_v != 1:
            starts = (1, head_v)
        run = longest_run(hits, starts)
        if len(run) >= 2:
            runs.append((run[0][0], -len(run), kind, run))
    if not runs:
        return None, []

    # 選「最先出現」的那一種，不是「串最長」的那一種。
    # 最外層一定先出現。串最長的常常是最內層，例如
    #   三、商品篩選(一) 保險商品1、…(1)…(2)…(二)…(1)…(2)…
    # 這裡 (1)(2) 出現 21 次最長，但正確的切點是 (一)(二)(三)(四)。
    # 位置一樣才比長度。
    runs.sort(key=lambda x: (x[0], x[1]))

    # 勝出的那一串中途重新從 1 編的話，中間可能夾著沒被認出來的外層
    alt = outer_between(cands, runs[0][2], runs[0][3])
    if alt:
        return alt

    return runs[0][2], runs[0][3]


def cut(text):
    """切一輪。回傳 (符號類型, [(子序號, 符號原文, 文字), ...])。"""
    kind, run = pick(text)
    if not kind:
        return None, []

    parts = []
    head = text[:run[0][0]]
    if head.strip():
        parts.append(("00", "", head))

    for i, (pos, val, raw) in enumerate(run):
        end = run[i + 1][0] if i + 1 < len(run) else len(text)
        parts.append(("%02d" % (i + 1), raw, text[pos:end]))

    # 這一筆自己的無損驗證
    if "".join(p[2] for p in parts) != text:
        return None, []
    return kind, parts


# ------------------------------------------------------------------
HEAD_PATS = [
    ("B", re.compile(r"^[（(]\s*[一二三四五六七八九十]{1,3}\s*[）)]")),
    ("D", re.compile(r"^[（(]\s*\d{1,3}\s*[）)]")),
    ("A", re.compile(r"^[一二三四五六七八九十]{1,3}\s*[、，,]")),
    ("C", re.compile(r"^\d{1,3}\s*[、.．]")),
    ("E", re.compile(r"^[A-Za-z]\s*[.．]")),
]


def head_sym(text):
    """認出一段文字開頭的編號。00 子項常常帶著母條文自己的編號。"""
    t = re.sub(r"^(?:\s*\[\[(?:TABLE|SHAPE):\d{3}\]\])+", "", text or "").lstrip()
    for kind, pat in HEAD_PATS:
        m = pat.match(t)
        if m:
            return kind, m.group(0).strip()
    return None, ""


def sym_of(raw, text=""):
    """從符號原文反推它是哪一類。00 子項沒有 raw，就從內文開頭認。"""
    if not raw:
        kind, got = head_sym(text)
        if kind:
            return kind, got          # 這是母條文本文，不是無編號的前言
        return "前言", ""
    for kind, pat in FINDERS:
        if pat.fullmatch(raw.strip()):
            return kind, raw
    return "無符號", raw


def level_name(d):
    return "第%d層" % d


def seed_level(row):
    """S3 進來的那一層，定好階層與深度。款標題另外由 mark_kuan 算。"""
    cid = row["條文ID"]
    if cid.endswith("-000"):
        row["階層"] = "章" if row.get("節序號") == "000" else "節"
        row["階層深度"] = 0
    else:
        row["階層"] = level_name(1)
        row["階層深度"] = 1
    for c in LEVEL_COLS:
        row[c] = ""
    if row["階層深度"] == 1:
        row["第一層"] = row.get("符號原文", "")
        # 表格、圖形與被附件打斷後的接續文字沒有自己的第一層符號，
        # 但仍屬於前面的款；路徑需從該款開始，不能從第二層憑空出現。
        if (not row["第一層"] and
                row.get("符號類型") in ("表格", "圖形", "接續")):
            row["第一層"] = row.get("款標題", "")
    row["階層路徑"] = row.get("第一層", "")
    row["上層ID"] = ""
    return row


def mark_kuan(rows):
    """標款標題。

    規則：
      一、每個章／節範圍裡，第一層編號就是款標題
      二、下層子項沿用所屬的款標題
      三、第九、十二章沒有「一、」，第一層是「1、」，那就用它當款
      四、每一列自己的符號類型、符號原文都不動

    第一層是誰，S3 已經算在「本範圍層級」欄，這裡直接用。
    """
    cur_key = None
    kuan = ""
    for r in rows:
        key = (r.get("章序號"), r.get("節序號"))
        if key != cur_key:
            cur_key, kuan = key, ""
        if r["條文ID"].endswith("-000"):
            r["款標題"] = ""
            continue
        try:
            lv = int(r.get("本範圍層級") or 0)
        except ValueError:
            lv = 0
        if lv == 1 and r.get("符號原文"):
            kuan = r["符號原文"]
        r["款標題"] = kuan
    return rows


def expand(row, out, rounds, fail_log):
    """遞迴切。row 是輸入的一列（dict）。

    每一輪都嘗試辨識下一層，不以字數決定是否繼續。

    字數不能代表結構：短段落仍可能包含 1、／(1)／A. 等完整子層。
    若只對超過 LIMIT 的段落再切，先以 (一)～(四) 修正外層後，內層
    會因各段不足 800 字而整批黏回同一列。
    """
    text = row["全文"]
    if rounds >= MAX_ROUND:
        rec = dict(row)
        rec["字數"] = len(text)
        rec["切分輪次"] = rounds
        rec.setdefault("父ID", "")
        rec["切分狀態"] = "仍過長" if len(text) > LIMIT else rec.get("切分狀態", "正常")
        rec.setdefault("切點符號", "")
        rec["是否前言"] = "Y" if rec.get("符號類型") == "前言" else rec.get("是否前言", "N")
        out.append(rec)
        return

    kind, parts = cut(text)
    if not parts:
        rec = dict(row)
        rec["字數"] = len(text)
        rec["切分輪次"] = rounds
        rec.setdefault("父ID", "")
        # 找不到下一層就是葉節點；只有仍過長才需要人工注意。
        rec["切分狀態"] = ("沒有子項" if len(text) <= LIMIT else "無法切分")
        rec.setdefault("切點符號", "")
        rec["是否前言"] = "Y" if rec.get("符號類型") == "前言" else rec.get("是否前言", "N")
        out.append(rec)
        if rec["切分狀態"] == "無法切分":
            fail_log.append((row["條文ID"], len(text)))
        return

    offset = 0
    for sub, raw, chunk in parts:
        child = dict(row)
        child["條文ID"] = row["條文ID"] + "-" + sub
        child["父ID"] = row["條文ID"]
        child["全文"] = chunk
        child["字數"] = len(chunk)
        child["含表格標記"] = ";".join(re.findall(r"\[\[TABLE:(\d{3})\]\]", chunk))
        child["含圖形標記"] = ";".join(re.findall(r"\[\[SHAPE:(\d{3})\]\]", chunk))
        if not child["含表格標記"] and not child["含圖形標記"]:
            child["附件全文"] = ""
            child["附件字數"] = 0
        st, sraw = sym_of(raw, chunk)
        child["符號類型"] = st
        child["符號原文"] = sraw
        child["切分輪次"] = rounds + 1
        child["切分狀態"] = "正常"
        child["切點符號"] = kind
        child["是否前言"] = "Y" if sub == "00" else "N"
        # 00 是母條文自己的本文，層級不變；其餘往下一層
        pd = int(row.get("階層深度") or 1)
        if sub == "00":
            child["階層深度"] = pd
            child["階層"] = row.get("階層") or level_name(pd)
            child["上層ID"] = row.get("上層ID") or ""
        else:
            child["階層深度"] = pd + 1
            child["階層"] = level_name(pd + 1)
            child["上層ID"] = row["條文ID"]
            if pd < len(LEVEL_COLS):
                child[LEVEL_COLS[pd]] = sraw
        child["階層路徑"] = " > ".join(
            child.get(c, "") for c in LEVEL_COLS if child.get(c, ""))
        child["款標題"] = row.get("款標題", "")
        f, l = locate(row, offset, len(chunk))
        child["起始序號"], child["結束序號"] = f, l
        offset += len(chunk)
        expand(child, out, rounds + 1, fail_log)


def pct(vals, p):
    if not vals:
        return 0
    vals = sorted(vals)
    k = (len(vals) - 1) * p
    lo = int(k)
    hi = min(lo + 1, len(vals) - 1)
    return round(vals[lo] + (vals[hi] - vals[lo]) * (k - lo), 1)


KEEP_TYPES = ("章", "節", "內文", "表格標記", "圖形標記")
PARA = {}          # 序號 -> 全文


def load_paragraphs(folder):
    p = os.path.join(folder, "01_paragraphs.csv")
    if not os.path.isfile(p):
        return
    with open(p, "r", encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            if r["類型"] in KEEP_TYPES:
                PARA[int(r["序號"])] = r["全文"]


def locate(row, offset, length):
    """算出子項落在原檔哪幾列。算不出來就沿用父項的範圍。"""
    a, b = row.get("起始序號", ""), row.get("結束序號", "")
    if not PARA or not str(a).isdigit() or not str(b).isdigit():
        return a, b
    pos = 0
    first = last = ""
    for no in range(int(a), int(b) + 1):
        t = PARA.get(no)
        if t is None:
            continue
        s0, s1 = pos, pos + len(t)
        pos = s1
        if s1 <= offset or s0 >= offset + length:
            continue
        if first == "":
            first = no
        last = no
    if first == "":
        return a, b
    return first, last


def main(folder):
    load_paragraphs(folder)
    src = os.path.join(folder, "03_items.csv")
    if not os.path.isfile(src):
        say("找不到 " + src)
        return None, False, None

    with open(src, "r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    say("=" * 60)
    say("S4 二次切分報告")
    say("資料夾：" + folder)
    say("=" * 60)
    say()
    say("每一輪：不看字數，依編號層級繼續切到沒有子項")
    say("最多 %d 輪；超過 %d 字但無法再切才列人工檢查" % (MAX_ROUND, LIMIT))

    out = []
    fail_log = []
    rows = mark_kuan([dict(x) for x in rows])
    for r in rows:
        base = seed_level(dict(r))
        base["父ID"] = ""
        base["切分狀態"] = "正常"
        base["切點符號"] = ""
        base["是否前言"] = "N"
        expand(base, out, 0, fail_log)

    # ---------- 無損驗證 ----------
    a = "".join(r["全文"] for r in rows)
    b = "".join(r["全文"] for r in out)
    passed = (a == b)

    say()
    say("1. 整份無損驗證：" + ("過" if passed else "沒過"))
    if not passed:
        at = next((i for i in range(min(len(a), len(b))) if a[i] != b[i]),
                  min(len(a), len(b)))
        say("   第一個不一致在第 %d 個字元" % (at + 1))
        say("   切前：" + a[max(0, at - 50):at + 50])
        say("   切後：" + b[max(0, at - 50):at + 50])
        return out, False, rows

    say()
    say("2. 處理前 %d 筆，處理後 %d 筆" % (len(rows), len(out)))

    cut_parents = {}
    for r in out:
        if r["父ID"]:
            cut_parents.setdefault(r["父ID"], []).append(r)
    top_cut = [k for k in cut_parents if "-" in k and k.count("-") == 2]
    say()
    say("3. 被切 %d 筆（含再切的層），共切出 %d 個子項"
        % (len(cut_parents), sum(len(v) for v in cut_parents.values())))
    say("   第一輪被切的原始筆：%d 筆" % len(top_cut))

    say()
    say("4. 每一筆被切的情形")
    for k in sorted(cut_parents):
        kids = cut_parents[k]
        say("   %-22s 用 %s 切成 %d 個" % (k, kids[0]["切點符號"], len(kids)))

    say()
    nosub = [r for r in out if r["切分狀態"] == "沒有子項"]
    say("   （另有 %d 筆本來就沒有子項，屬正常）" % len(nosub))
    nofit = [r for r in out if r["切分狀態"] == "無法切分"]
    say("5. 無法切分 %d 筆" % len(nofit))
    for r in nofit:
        say("   %s  %s 字" % (r["條文ID"], r["字數"]))

    say()
    toolong = [r for r in out if r["切分狀態"] == "仍過長"]
    say("6. 仍過長 %d 筆" % len(toolong))
    for r in toolong:
        say("   %s  %s 字" % (r["條文ID"], r["字數"]))

    say()
    sizes = [int(r["字數"]) for r in out]
    say("7. 字數分布：最小 %d / 25%% %s / 中位數 %s / 75%% %s / 最大 %d"
        % (min(sizes), pct(sizes, .25), pct(sizes, .5), pct(sizes, .75),
           max(sizes)))

    for target in ("005-004-002", "006-001-001"):
        say()
        say("   %s 的切分結果" % target)
        kids = [r for r in out if r["條文ID"].startswith(target)]
        if not kids:
            say("      找不到")
        for r in kids[:24]:
            say("      %-26s %4s 字  %s"
                % (r["條文ID"], r["字數"], r["全文"][:30]))
        if len(kids) > 24:
            say("      （還有 %d 個子項）" % (len(kids) - 24))

    return out, True, rows


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S4_二次切分.py <資料夾>")
        sys.exit(1)

    target_dir = sys.argv[1]
    result, ok, srcrows = main(target_dir)

    if ok:
        cols = list(srcrows[0].keys()) + NEW_COLS
        out_path = os.path.join(target_dir, "04_items2.csv")
        with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols, quoting=csv.QUOTE_ALL)
            w.writeheader()
            for r in result:
                w.writerow(dict((c, r.get(c, "")) for c in cols))
        say()
        say("=" * 60)
        say("結論：S4 過。已寫出 04_items2.csv")
        say("=" * 60)
    else:
        say()
        say("=" * 60)
        say("結論：驗證沒過，沒有寫出 04_items2.csv")
        say("=" * 60)

    report = "\n".join(lines)
    with open(os.path.join(target_dir, "S4_二次切分報告.txt"), "w",
              encoding="utf-8-sig") as f:
        f.write(report + "\n")

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if ok else 1)
