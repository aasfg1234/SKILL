# 內規切條產線　SPADE版

把一份 Word 內規變成 51 欄的規章總表。

## 怎麼裝

把 `reg-*` 這些資料夾整包放進 SPADE 的 skill 目錄。
架構 skill 是 `reg-pipeline`，其餘是它會呼叫的階段 skill。

## 怎麼用

跟它說「幫我跑內規切條產線」，或直接指定階段，例如「跑 S3」。

## 十三個階段

| 階段 | skill | 誰做 | 性質 |
|---|---|---|---|
| S1 | `reg-s1-export` | VBA，在有 Word 的電腦 | — |
| S1T | `reg-s1t-fromtxt` | 只在拿不到 Word 時 | — |
| S2 | `reg-s2-verify` | Python | 關卡 |
| S3 | `reg-s3-split` | Python | — |
| S4 | `reg-s4-deepen` | Python | — |
| QA | `reg-qa-audit` | Python | 關卡 |
| S5 | `reg-s5-flag` | Python | — |
| S6 | `reg-s6-review` | 人填 Excel ＋ Python | 人工 |
| S7 | `reg-s7-duplicate` | Python | — |
| S8 | `reg-s8-citation` | Python | — |
| S9 | `reg-s9-master` | Python | 交付 |
| S10 | `reg-s10-restore` | Python | 關卡 |
| S11 | `reg-s11-specpack` | Python | — |

## 三道關卡

S2 驗收、QA 法遵稽核、S10 還原對帳。**沒過不准往下走。**

## 一個人工步驟

S6 第二步：人填複核表。程式不代填。

## 要維護的兩個表

- `reg-s7-duplicate/scripts/S7_同義詞表.csv`
- `reg-s8-citation/scripts/S8_外部規章表.csv`

換一本規章只要改這兩個，其餘程式不用動。

## SPADE 專屬

**中間檔不跨執行存活**，所以走 `reg-pipeline/scripts/run_all.py`，
在同一次執行裡跑完多個階段。分兩趟，因為中間卡著人工複核。

核心邏輯全部只用標準函式庫。只有 S10 需要 `python-docx`，
沒有的話會少掉 .docx，txt 對帳照樣做。

**不要碰 `Path.home()`**，會直接 RuntimeError。

