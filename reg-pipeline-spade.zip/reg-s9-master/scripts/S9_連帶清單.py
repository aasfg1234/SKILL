# -*- coding: utf-8 -*-
r"""
S9：改這一條，要連帶看哪些

用法：
    py S9_連帶清單.py <資料夾>

輸入：<資料夾>\06_final.csv       條文本體
      <資料夾>\07_relations.csv   S7 找出來的重複與相似
      <資料夾>\08_citations.csv   S8 抓出來的引用
輸出：<資料夾>\09_impact.csv        一條一列，總表
      <資料夾>\09_impact_明細.csv   一個連帶關係一列，可篩選
      <資料夾>\S9_連帶報告.txt

它回答一個問題
    「我要改第五章第四節這一條，還有哪裡要跟著改？」

四種連帶關係
    重複    另一條跟它一字不差。改一處一定要改另一處
    相似    另一條是同一規定的不同版本，用字略有差異
    被引用  別的條文寫「依本節第三條」，指的就是它
    我引用  它自己引用了別條或外部法規

風險分級
    高   有重複條文，或被三條以上引用
    中   有相似條文，或有被引用
    低   只引用別人，或只引用外部法規
    無   沒有任何連帶
"""

import csv
import io
import os
import sys
import collections

# 最終輸出的欄位，順序由使用者指定，共 51 欄。
#
# 後半段的連帶分析區，刻意再放一次條文本身的五個欄位，
# 這樣看連帶分析的時候不用捲回左邊。那是使用者要的，不是寫錯。
#
# 但欄名不可以重複。實測後果：
#   PowerShell Import-Csv   直接失敗「章標題 欄位已經存在」
#   csv.DictReader          51 欄只剩 46 個鍵，前面那個被靜靜蓋掉
#   pandas                  自動改名成「章標題.1」
#   Excel                   開得起來
# 所以後半那五欄加「（對照）」後綴。值跟前半完全一樣，只是名字要分得開。
MAIN_COLS = [
    "條文ID", "章序號", "章標題", "節序號", "節標題", "款標題",
    "第一層", "第二層", "第三層", "第四層", "第五層", "階層路徑",
    "符號類型", "符號原文", "本範圍層級", "起始序號", "結束序號",
    "全文", "字數", "含表格標記", "含圖形標記", "附件全文", "附件字數",
    "切分輪次", "父ID", "切分狀態", "切點符號", "是否前言",
    "旗標", "旗標數", "階層", "階層深度", "上層ID",
    "風險", "連帶總數", "章標題（對照）", "節標題（對照）", "符號原文（對照）",
    "重複數", "重複條文", "相似數", "相似條文",
    "被引用數", "被誰引用", "我引用數", "我引用誰",
    "外部規章", "條號", "一句話說明", "字數（對照）", "全文（對照）",
]

# 對照欄要去哪一個來源欄取值
SRC_OF = {
    "章標題（對照）": "章標題",
    "節標題（對照）": "節標題",
    "符號原文（對照）": "符號原文",
    "字數（對照）": "字數",
    "全文（對照）": "全文",
}


def cell(r, col):
    """照輸出欄名取值。對照欄要換回原本的來源欄名。"""
    return r.get(SRC_OF.get(col, col), "")

DET_COLS = ["條文ID", "本條款標題", "關係", "對象", "對象款標題",
            "對象位置", "依據", "對象內容"]

lines = []


def say(s=""):
    lines.append(s)


def load(folder, name):
    p = os.path.join(folder, name)
    if not os.path.isfile(p):
        return None
    with io.open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def main(folder):
    base = load(folder, "06_final.csv") or load(folder, "05_flagged.csv")
    rel = load(folder, "07_relations.csv")
    cit = load(folder, "08_citations.csv")

    if not base:
        say("找不到 06_final.csv，先跑 S6")
        return None
    if rel is None:
        say("找不到 07_relations.csv，先跑 S7")
        return None
    if cit is None:
        say("找不到 08_citations.csv，先跑 S8")
        return None

    say("=" * 64)
    say("S9 連帶清單")
    say("資料夾：" + folder)
    say("=" * 64)
    say()
    say("條文 %d 筆、關聯 %d 組、引用資料 %d 筆"
        % (len(base), len(rel), len(cit)))

    info = dict((r["條文ID"], r) for r in base)

    def where(cid):
        r = info.get(cid)
        if not r:
            return ""
        return (r["章標題"][:14] +
                (" / " + r["節標題"][:14] if r["節標題"] else "")).strip()

    def peek(cid):
        r = info.get(cid)
        return (r["全文"][:50] if r else "")

    def kuan(cid):
        r = info.get(cid)
        return (r.get("款標題", "") if r else "")

    dup = collections.defaultdict(list)      # 一字不差
    sim = collections.defaultdict(list)      # 高度相似
    detail = []

    for p in rel:
        a, b = p["條文A"], p["條文B"]
        v = p["關係判定"]
        if v not in ("完全相同", "高度相似"):
            continue
        score = max(float(p["原文相似度"] or 0), float(p["換詞後相似度"] or 0))
        basis = "%s %.3f" % (v, score)
        if p.get("差在哪裡") and p["差在哪裡"] != "完全一樣":
            basis += "｜差在：" + p["差在哪裡"][:40]
        if p.get("命中同義詞組"):
            basis += "｜同義詞：" + p["命中同義詞組"][:30]
        for x, y in ((a, b), (b, a)):
            (dup if v == "完全相同" else sim)[x].append(y)
            detail.append({"條文ID": x, "本條款標題": kuan(x),
                           "關係": "重複" if v == "完全相同" else "相似",
                           "對象": y, "對象款標題": kuan(y),
                           "對象位置": where(y),
                           "依據": basis, "對象內容": peek(y)})

    cites = collections.defaultdict(list)    # 我引用誰
    cited_by = collections.defaultdict(list)  # 被誰引用
    ext = {}

    for r in cit:
        cid = r["條文ID"]
        if r.get("規章名"):
            ext[cid] = (r["規章名"], r.get("條號", ""))
        for tgt in (r.get("引用ID") or "").split(";"):
            tgt = tgt.strip()
            if not tgt or tgt == cid:
                continue
            cites[cid].append(tgt)
            if tgt.startswith("（"):
                continue
            cited_by[tgt].append(cid)
            detail.append({"條文ID": cid, "本條款標題": kuan(cid), "關係": "我引用",
                           "對象": tgt, "對象款標題": kuan(tgt),
                           "對象位置": where(tgt),
                           "依據": r.get("內引用原文", ""),
                           "對象內容": peek(tgt)})
            detail.append({"條文ID": tgt, "本條款標題": kuan(tgt), "關係": "被引用",
                           "對象": cid, "對象款標題": kuan(cid),
                           "對象位置": where(cid),
                           "依據": r.get("內引用原文", ""),
                           "對象內容": peek(cid)})
        if r.get("規章名"):
            detail.append({"條文ID": cid, "本條款標題": kuan(cid),
                           "關係": "外部規章",
                           "對象": r["規章名"], "對象款標題": "", "對象位置": "",
                           "依據": r.get("條號", ""),
                           "對象內容": r.get("外引用原文", "")[:50]})

    def uniq(seq):
        return list(dict.fromkeys(seq))

    out = []
    for r in base:
        cid = r["條文ID"]
        d = uniq(dup.get(cid, []))
        s = uniq([x for x in sim.get(cid, []) if x not in d])
        cb = uniq(cited_by.get(cid, []))
        cs = uniq([x for x in cites.get(cid, []) if not x.startswith("（")])
        e_name, e_art = ext.get(cid, ("", ""))
        total = len(d) + len(s) + len(cb) + len(cs) + (1 if e_name else 0)

        if d or len(cb) >= 3:
            risk = "高"
        elif s or cb:
            risk = "中"
        elif cs or e_name:
            risk = "低"
        else:
            risk = "無"

        bits = []
        if d:
            bits.append("有 %d 條一字不差" % len(d))
        if s:
            bits.append("有 %d 條寫法相近" % len(s))
        if cb:
            bits.append("被 %d 條引用" % len(cb))
        if cs:
            bits.append("引用了 %d 條" % len(cs))
        if e_name:
            ext_note = e_name
            if e_art and any(x.strip() not in ("", "-") for x in e_art.split(";")):
                ext_note += " " + e_art
            bits.append("引用外部：" + ext_note)
        note = "；".join(bits) or "沒有連帶"

        rec = dict(r)          # 先把 06_final 的欄位整包帶進來
        rec.update({
            "條文ID": cid,
            "風險": risk, "連帶總數": total,
            "重複數": len(d), "重複條文": ";".join(d),
            "相似數": len(s), "相似條文": ";".join(s),
            "被引用數": len(cb), "被誰引用": ";".join(cb),
            "我引用數": len(cs), "我引用誰": ";".join(cs),
            "外部規章": e_name, "條號": e_art,
            "一句話說明": note,
        })
        out.append(rec)

    rank = {"高": 0, "中": 1, "低": 2, "無": 3}
    out.sort(key=lambda x: (rank[x["風險"]], -x["連帶總數"], x["條文ID"]))

    # ---------- 報告 ----------
    say()
    say("1. 風險分布")
    c = collections.Counter(r["風險"] for r in out)
    for k in ("高", "中", "低", "無"):
        say("   %s  %d 筆" % (k, c.get(k, 0)))

    say()
    say("2. 連帶最多的 15 條（改這些最危險）")
    for r in out[:15]:
        say("   [%s] %-22s 款%-5s %-5s 連帶 %d  %s"
            % (r["風險"], r["條文ID"], r["款標題"] or "-", r["階層"],
               r["連帶總數"], r["一句話說明"]))
        say("        %s" % r["全文"][:44])

    say()
    say("3. 被引用最多的條文（動它影響最大）")
    top = sorted(out, key=lambda x: -x["被引用數"])[:10]
    for r in top:
        if not r["被引用數"]:
            break
        say("   %-22s 被 %d 條引用：%s"
            % (r["條文ID"], r["被引用數"], r["被誰引用"][:60]))

    say()
    say("4. 一字不差的重複（改一處一定要改另一處）")
    seen = set()
    n = 0
    for r in out:
        for t in (r["重複條文"].split(";") if r["重複條文"] else []):
            key = tuple(sorted([r["條文ID"], t]))
            if key in seen:
                continue
            seen.add(key)
            n += 1
            say("   %s ↔ %s" % (key[0], key[1]))
            say("      %s" % peek(key[0])[:52])
    say("   共 %d 組" % n)

    return out, detail


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S9_連帶清單.py <資料夾>")
        sys.exit(1)

    folder = sys.argv[1]
    res = main(folder)

    if res is not None:
        out, detail = res
        # 09_impact.csv：照風險排，先看最危險的
        with io.open(os.path.join(folder, "09_impact.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, quoting=csv.QUOTE_ALL)
            w.writerow(MAIN_COLS)
            for r in out:
                w.writerow([cell(r, c) for c in MAIN_COLS])

        # 09_規章總表.csv：同樣欄位，改照條文順序排，從頭讀到尾就是整本規章
        with io.open(os.path.join(folder, "09_規章總表.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, quoting=csv.QUOTE_ALL)
            w.writerow(MAIN_COLS)
            for r in sorted(out, key=lambda x: x["條文ID"]):
                w.writerow([cell(r, c) for c in MAIN_COLS])

        detail.sort(key=lambda x: (x["條文ID"], x["關係"], x["對象"]))
        with io.open(os.path.join(folder, "09_impact_明細.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=DET_COLS, quoting=csv.QUOTE_ALL)
            w.writeheader()
            for r in detail:
                w.writerow(dict((c, r.get(c, "")) for c in DET_COLS))
        say()
        say("=" * 64)
        say("結論：S9 完成。")
        say("   09_impact.csv     %d 筆（照風險排）" % len(out))
        say("   09_規章總表.csv    %d 筆（照條文順序排）" % len(out))
        say("   09_impact_明細.csv %d 筆" % len(detail))
        say("=" * 64)

    report = "\n".join(lines)
    with io.open(os.path.join(folder, "S9_連帶報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if res is not None else 1)
