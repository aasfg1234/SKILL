# -*- coding: utf-8 -*-
r"""
S2：驗收 S1 的匯出結果

用法：
    py S2_驗收.py <資料夾>

資料夾裡要有：
    01_paragraphs.csv
    02_shapes.csv
    tables\T001.md ... T018.md

只讀不改。跑完會在同一個資料夾產生 S2_驗收報告.txt。
"""

import csv
import os
import re
import sys
import unicodedata

# 這兩個是「這份文件應該有幾章、幾張表」。
# 換一份文件就不一樣，所以改成執行時才給：
#     py S2_驗收.py <資料夾> --chapters 12 --tables 18
# 不給的話不會判不合格，只做內部一致性檢查（表格記號 vs 表格檔數等）。
EXPECT_CHAPTERS = None
EXPECT_TABLES = None

COLS = ["序號", "位置", "類型", "所在章", "所在節",
        "樣式", "在表格內", "自動編號", "全文", "字數"]

CN_NUM = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6,
          "七": 7, "八": 8, "九": 9, "十": 10}

lines = []
fails = []
warns = []


def say(s=""):
    lines.append(s)


def fail(s):
    fails.append(s)
    say("  [不合格] " + s)


def warn(s):
    warns.append(s)
    say("  [注意] " + s)


def ok(s):
    say("  [過] " + s)


def cn2int(s):
    """把「十一」這種中文數字轉成 11。認到 99。"""
    s = s.strip()
    if not s:
        return None
    total = 0
    if "十" in s:
        left, _, right = s.partition("十")
        total = (CN_NUM.get(left, 1) if left else 1) * 10
        total += CN_NUM.get(right, 0) if right else 0
        return total
    return CN_NUM.get(s)


def chapter_no(text):
    m = re.match(r"^第([一二三四五六七八九十]{1,3})章", text)
    return cn2int(m.group(1)) if m else None


def section_no(text):
    m = re.match(r"^第([一二三四五六七八九十]{1,3})節", text)
    return cn2int(m.group(1)) if m else None


def read_csv(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def main(folder):
    say("=" * 60)
    say("S2 驗收報告")
    say("資料夾：" + folder)
    say("=" * 60)

    p_csv = os.path.join(folder, "01_paragraphs.csv")
    s_csv = os.path.join(folder, "02_shapes.csv")
    t_dir = os.path.join(folder, "tables")

    # ---------- 1 檔案在不在 ----------
    say()
    say("1. 檔案存在")
    for path in (p_csv, s_csv):
        if os.path.isfile(path):
            ok(os.path.basename(path) + "  " + str(os.path.getsize(path)) + " 位元組")
        else:
            fail("找不到 " + os.path.basename(path))
    if os.path.isdir(t_dir):
        ok("tables 資料夾")
    else:
        fail("找不到 tables 資料夾")

    if fails:
        say()
        say("=" * 60)
        say("結論：不合格。S1 的產出檔還沒放進來。")
        say("請把公司電腦跑完 S1 產生的這三樣，複製到上面那個資料夾：")
        say("  01_paragraphs.csv")
        say("  02_shapes.csv")
        say("  tables 資料夾（整個複製，裡面有 18 個 .md）")
        say("=" * 60)
        return

    rows = read_csv(p_csv)
    shapes = read_csv(s_csv)

    # ---------- 2 欄位 ----------
    say()
    say("2. 欄位名稱")
    got = list(rows[0].keys()) if rows else []
    if got == COLS:
        ok("10 欄，順序正確")
    else:
        fail("欄位不對。讀到：" + ",".join(got))
        return

    # ---------- 3 列數與序號 ----------
    say()
    say("3. 列數與序號")
    say("  總列數：" + str(len(rows)))
    bad_seq = [i for i, r in enumerate(rows, 1) if r["序號"] != str(i)]
    if bad_seq:
        fail("序號不連續，第一個斷點在第 " + str(bad_seq[0]) + " 列")
    else:
        ok("序號 1 到 " + str(len(rows)) + " 連續")

    pos = [int(r["位置"]) for r in rows]
    drops = sum(1 for a, b in zip(pos, pos[1:]) if b < a)
    if drops:
        warn("位置有 " + str(drops) + " 處往回跳（表格或圖形錨點插隊，通常正常）")
    else:
        ok("位置由小到大")

    # ---------- 4 類型分布 ----------
    say()
    say("4. 類型分布")
    kinds = {}
    for r in rows:
        kinds[r["類型"]] = kinds.get(r["類型"], 0) + 1
    for k in ("目錄", "表格內", "章", "節", "表格標記", "圖形標記", "內文"):
        say("  " + k.ljust(6) + str(kinds.get(k, 0)))
    unknown = set(kinds) - {"目錄", "表格內", "章", "節", "表格標記", "圖形標記", "內文"}
    if unknown:
        fail("出現預期外的類型：" + "、".join(sorted(unknown)))

    # ---------- 5 章 ----------
    say()
    say("5. 章" + ("（應該是 %d 章）" % EXPECT_CHAPTERS
                  if EXPECT_CHAPTERS else "（沒指定應有章數，只檢查編號連不連續）"))
    chaps = [r for r in rows if r["類型"] == "章"]
    say("  抓到 " + str(len(chaps)) + " 章")
    seen = []
    for r in chaps:
        n = chapter_no(r["全文"])
        seen.append(n)
        say("    " + str(r["序號"]).rjust(5) + "  " + r["全文"][:40])
    if EXPECT_CHAPTERS and len(chaps) != EXPECT_CHAPTERS:
        fail("章數不是 " + str(EXPECT_CHAPTERS))
    top = EXPECT_CHAPTERS or (max([x for x in seen if x] or [0]))
    missing = [n for n in range(1, top + 1) if n not in seen]
    if missing:
        fail("章號不連續，缺第 " + "、".join(str(m) for m in missing) + " 章")
    elif top:
        ok("第一章到第%d章連號齊全" % top)
    if len(set(x for x in seen if x)) != len([x for x in seen if x]):
        fail("有章序號重複")

    # ---------- 6 節 ----------
    say()
    say("6. 節")
    sects = [r for r in rows if r["類型"] == "節"]
    say("  抓到 " + str(len(sects)) + " 節")
    per = {}
    for r in sects:
        per[r["所在章"]] = per.get(r["所在章"], 0) + 1
    for r in chaps:
        title = r["全文"][:20]
        say("    " + title.ljust(24) + str(per.get(r["全文"], per.get(title, 0))) + " 節")
    for r in sects:
        if section_no(r["全文"]) is None:
            warn("節標題認不出節序號：" + r["全文"][:30])

    # ---------- 7 表格標記 ----------
    say()
    n_md = len([f for f in os.listdir(t_dir) if f.lower().endswith(".md")])
    want_t = EXPECT_TABLES or n_md
    say("7. 表格標記（比對對象：%s）"
        % ("指定的 %d 張" % EXPECT_TABLES if EXPECT_TABLES
           else "tables 資料夾裡的 %d 個檔" % n_md))
    marks = []
    for r in rows:
        marks += re.findall(r"\[\[TABLE:(\d{3})\]\]", r["全文"])
    say("  找到 " + str(len(marks)) + " 個")
    dup = [m for m in set(marks) if marks.count(m) > 1]
    if dup:
        fail("表格標記重複：" + "、".join(sorted(dup)))
    want = set("%03d" % i for i in range(1, want_t + 1))
    if set(marks) != want:
        miss = sorted(want - set(marks))
        extra = sorted(set(marks) - want)
        if miss:
            fail("正文缺表格標記：" + "、".join(miss))
        if extra:
            fail("多出表格標記：" + "、".join(extra))
    else:
        ok("T001 到 T%03d 各出現一次" % want_t)

    # ---------- 8 表格檔 ----------
    say()
    say("8. tables 資料夾")
    mds = sorted(f for f in os.listdir(t_dir) if f.lower().endswith(".md"))
    say("  檔案數：" + str(len(mds)))
    if EXPECT_TABLES and len(mds) != EXPECT_TABLES:
        fail("表格檔不是 " + str(EXPECT_TABLES) + " 個")
    for f in mds:
        n = os.path.getsize(os.path.join(t_dir, f))
        if n < 10:
            fail(f + " 是空的")
    sizes = []
    for f in mds:
        with open(os.path.join(t_dir, f), "r", encoding="utf-8-sig") as fh:
            body = fh.read()
        sizes.append((f, len(body)))
        say("    " + f.ljust(12) + str(len(body)).rjust(6) + " 字")

    # F16 / F17：兩個已知的判定
    t1 = dict(sizes).get("T001.md", 0)
    if t1:
        say("  T001 是導讀表，S3 之後要丟掉（F16）")
    t2 = dict(sizes).get("T002.md", 0)
    if t2 and t2 < 100:
        warn("T002 只有 " + str(t2) + " 字，但它應該有上架審核六步驟，不能當空表丟（F17）")

    # ---------- 9 圖形 ----------
    say()
    say("9. 圖形")
    smarks = []
    for r in rows:
        smarks += re.findall(r"\[\[SHAPE:(\d{3})\]\]", r["全文"])
    ids = set(s["圖形編號"] for s in shapes) if shapes else set()
    say("  正文圖形標記：" + str(len(smarks)))
    say("  02_shapes.csv 文字筆數：" + str(len(shapes)))
    say("  02_shapes.csv 不同圖形：" + str(len(ids)))
    if set(smarks) - ids:
        warn("有圖形標記在 02_shapes.csv 裡找不到文字：" + "、".join(sorted(set(smarks) - ids)))
    if len(shapes) == 0:
        fail("02_shapes.csv 沒有任何文字。兩張流程圖的字沒撈到（F18）")
    else:
        ok("圖形文字有撈到")

    # ---------- 10 全文欄體質 ----------
    say()
    say("10. 全文欄體質")
    nl = [r["序號"] for r in rows if "\n" in r["全文"] or "\r" in r["全文"]]
    if nl:
        warn("有 " + str(len(nl)) + " 列的全文含換行。S3、S4 的規則假設沒有換行（F23）")
    else:
        ok("全文欄沒有換行，符合 F23")

    ctrl = []
    for r in rows:
        for ch in r["全文"]:
            if unicodedata.category(ch) == "Cc":
                ctrl.append((r["序號"], ord(ch)))
                break
    if ctrl:
        fail("有 " + str(len(ctrl)) + " 列殘留控制字元，例如第 " +
             str(ctrl[0][0]) + " 列的字元碼 " + str(ctrl[0][1]))
    else:
        ok("沒有控制字元，分頁符號已清掉（F4）")

    badlen = [r["序號"] for r in rows if str(len(r["全文"])) != r["字數"]]
    if badlen:
        fail("有 " + str(len(badlen)) + " 列的字數欄跟全文長度對不上，第一個在第 " + badlen[0] + " 列")
    else:
        ok("字數欄正確")

    body = [r for r in rows if r["類型"] == "內文"]
    empty = [r["序號"] for r in body if r["全文"].strip() == ""]
    say("  內文空白列：" + str(len(empty)) + " 列（S3 會跳過，正常）")

    total = sum(len(r["全文"]) for r in rows if r["類型"] not in ("目錄", "表格內"))
    say("  參與切分的總字數：" + str(total))

    # ---------- 結論 ----------
    say()
    say("=" * 60)
    if fails:
        say("結論：不合格。要修 " + str(len(fails)) + " 項，不要進 S3。")
        for s in fails:
            say("  - " + s)
    else:
        say("結論：S2 過。可以進 S3。")
    if warns:
        say()
        say("另外有 " + str(len(warns)) + " 項要看一下：")
        for s in warns:
            say("  - " + s)
    say("=" * 60)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S2_驗收.py <資料夾> [--chapters N] [--tables N]")
        sys.exit(1)

    target = sys.argv[1]
    for i, a in enumerate(sys.argv):
        if a == "--chapters" and i + 1 < len(sys.argv):
            EXPECT_CHAPTERS = int(sys.argv[i + 1])
        if a == "--tables" and i + 1 < len(sys.argv):
            EXPECT_TABLES = int(sys.argv[i + 1])
    if not os.path.isdir(target):
        print("找不到資料夾：" + target)
        sys.exit(1)

    try:
        main(target)
    except Exception as e:
        lines.append("")
        lines.append("程式中斷：" + repr(e))
        fails.append(repr(e))

    report = "\n".join(lines)
    out = os.path.join(target, "S2_驗收報告.txt")
    with open(out, "w", encoding="utf-8-sig") as f:
        f.write(report + "\n")

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    print()
    print("報告已存到：" + out)
    sys.exit(1 if fails else 0)
