---
name: vba-reference
description: Use whenever writing, editing, reviewing, or debugging VBA (Visual Basic for Applications) code — Excel/Word/Access/PowerPoint/Outlook macros, VBA modules, UserForms, or any ".bas"/".cls"/".frm" file. Also trigger on requests to "write a macro", "automate Excel", "VBA script", "run something in Word/Outlook" even if the user never says "VBA" explicitly. Looks up the correct statement/function/object/constant in a bundled categorized index before writing code, and fetches the official Microsoft Learn page for exact syntax when needed — this avoids guessing at parameter order, constant names, or object members and reduces hallucinated VBA syntax.
---

# VBA Reference Lookup

VBA's syntax has a lot of easy-to-confuse details — argument order that differs from similar-sounding
functions, constant names that must be spelled exactly, statements that look like functions (`Mid` as
both), and behavior that quietly changed between 32-bit and 64-bit Office. Guessing from general
knowledge produces code that "looks right" but throws a compile error or runs incorrectly. Before
writing or editing VBA code, ground yourself using the bundled index instead of relying purely on memory.

## The bundled index

This skill ships with a categorized reference index in its own `references/` folder (paths below are
relative to this skill's directory — resolve them from wherever this SKILL.md itself lives, not from the
user's project directory).

Start at `references/00_總覽.md` for the map, then open the specific category file you need:

| File | Covers |
| --- | --- |
| `references/01_陳述式_Statements.md` | Statements — `Dim`, `If...Then...Else`, `For...Next`, `Open`, `On Error`, etc. |
| `references/02_函式_Functions.md` | Built-in functions — string, date, math, financial, array, conversion, etc. |
| `references/03_物件_Objects.md` | Built-in objects — `Collection`, `Dictionary`, `Err`, `FileSystemObject` family, `UserForm` |
| `references/04_資料類型_DataTypes.md` | Data types and type-declaration characters |
| `references/05_常數_Constants.md` | Built-in constant groups (`vbKey*`, `MsgBox` constants, etc.) |
| `references/06_運算子_Operators.md` | Operators |
| `references/07_事件_Events.md` | Form/module-level events |
| `references/08_指示詞_Directives.md` | Compiler directives (`#Const`, `#If`) |
| `references/09_字元集_CharacterSets.md` | ASCII character set reference |

Each entry has a one-line description plus an official Microsoft Learn URL. Grep or read the relevant
file to find the item name and its link — don't skim from memory alone if you're not fully certain of
exact syntax.

### Application object models (Excel, Word, Access, PowerPoint, Outlook...)

The core-language files above cover only VBA itself — statements, functions, and types that exist
regardless of which Office app is hosting VBA. Code that touches `Range`, `Worksheet`, `Workbook`,
`Document`, `DoCmd`, `Recordset`, `Slide`, etc. belongs to a specific application's own object model,
which is indexed separately (each app's model has hundreds of objects — too large to fold into the core
files):

| Folder | Covers |
| --- | --- |
| `references/Excel物件模型/00_物件總覽.md` | All 306 Excel objects. For each: every method/property/event **name** + official link (no descriptions — see below) |
| `references/Outlook物件模型/00_物件總覽.md` | All 162 Outlook objects, same format |

Word/Access/PowerPoint aren't built yet. If a task needs one, you can generate it yourself — see
"Extending the index" below; it's a quick, mechanical step, not a research project.

**How to use an object index:** it's a name+link index only, not a description index — Microsoft's own
pages don't carry one-line member descriptions at that level either, so getting the actual behavior
always requires opening the specific member's page. The workflow is:
1. Open the app's `00_物件總覽.md`, find the object (e.g. `Range` in Excel, `MailItem` in Outlook), note
   which `物件_XX.md` file and anchor it's in.
2. Open that file at the anchor to confirm the *exact* member name exists on that object (catches typos
   like assuming a member exists when it's actually on a different but similar object).
3. `WebFetch` the member's URL to get the real signature/behavior before writing a nontrivial call.

## Workflow

1. **Identify what the task touches.** e.g. "loop over files in a folder and rename them" touches
   `FileSystemObject`/`Folder`/`Files` (objects), `Dir` or `Name` (statements/functions), `For Each`
   (statement). "highlight cells above the column average in Excel" touches `Range`/`FormatConditions`
   (Excel object model, not core language).
2. **Check the bundled index first.** Read the relevant category file(s) above — core language files for
   language constructs, `references/Excel物件模型/` / `references/Outlook物件模型/` for those apps'
   objects — to confirm the item exists, its exact name/capitalization, and grab its official URL. This
   is fast and free — always do this before writing code that uses a statement, function, object member,
   or constant you're not 100% certain about.
3. **Fetch the official page when you need exact details.** The core-language index gives a one-line
   description; the app object indexes give only names. Neither substitutes for the real parameter list,
   argument order, return-type edge cases, or code examples. When correctness matters — you're about to
   write a call with several parameters, an easily-confused constant, or anything where a mistake would
   silently misbehave rather than throw an obvious error — use `WebFetch` on the URL from the index to
   pull the real signature and example before writing the line. Don't fetch pages for things you're
   already certain about (e.g. `MsgBox "hello"`); reserve fetching for where it actually removes risk.
4. **If something isn't in any index, say so — don't fabricate it.** For applications without a built
   index yet (Word, Access, PowerPoint), or for anything not found in the Excel/Outlook indexes, don't
   guess property/method names from memory if unsure — use `WebFetch` against
   `https://learn.microsoft.com/office/vba/api/<application>.<object>` (e.g. `excel.range.autofilter`)
   or do a quick search, and say plainly when you're relying on general knowledge rather than a verified
   source.
5. **Write the code**, matching the confirmed syntax exactly (capitalization of named arguments,
   parameter order, correct statement vs. function form).

## When to skip the lookup

For trivial, unambiguous code you're highly confident about (a basic `If`, a `Dim x As Long`, a `MsgBox`
with one string argument), just write it — don't burn a fetch on things with no real risk of error. The
index and WebFetch are there for the cases where a wrong guess would actually cost the user (wrong
argument order, deprecated constant, a function that behaves differently than its name suggests).

## If the bundled index is missing or looks stale

If `references/00_總覽.md` doesn't exist under this skill (e.g. it got stripped out during install), fall
back to fetching directly from `https://learn.microsoft.com/office/vba/language/reference/` and its
subpages — the core language reference has been stable for years, so staleness is unlikely to matter for
the core statements/functions, but always prefer a fetched, verified page over an unverified guess when
precision matters.

## Extending the index to another application

To build an object-model index for Word, Access, or PowerPoint (or regenerate Excel/Outlook), use
`scripts/gen_object_index.py`, which is bundled with this skill:

1. From the skill's `scripts/` folder, fetch a fresh copy of the shared Office VBA TOC (one JSON file
   covers every application, so this step is only needed once even if you generate several apps):
   ```
   curl -s "https://learn.microsoft.com/zh-tw/office/vba/api/toc.json" -o toc_raw.json
   ```
2. Open `scripts/gen_object_index.py` and set `APP_TITLE_CONTAINS`, `APP_LABEL`, and `OUT_DIR` at the top
   for the target application (comments in the script show the pattern).
3. Run the script. It parses the TOC's object → method/property/event → name+link structure directly, so
   it never needs to fetch hundreds of individual object pages — just the one TOC file.

Note the TOC only carries names and links (no descriptions), which is exactly why the resulting index has
none either — that's a structural fact of the source (Microsoft's own object pages don't carry per-member
descriptions at that level), not something to work around by inventing descriptions.
