# -*- coding: utf-8 -*-
# Reusable generator: parses the shared VBA API TOC (a JSON file covering Access/Excel/Outlook/
# PowerPoint/Word/etc. in one tree) and builds a name+link object-model index for one application,
# without needing to fetch hundreds of individual object pages.
#
# This repo doesn't ship the TOC JSON (it's a large, frequently-changing cache of Microsoft's site
# navigation, not something worth bundling stale). Fetch a fresh copy first:
#
#   curl -s "https://learn.microsoft.com/zh-tw/office/vba/api/toc.json" -o toc_raw.json
#
# Run that from this scripts/ folder, then set APP_TITLE_CONTAINS / APP_LABEL / OUT_DIR below for
# the application you want (e.g. "Word", "Access", "PowerPoint") and run this script.
import json
import os
import re

BASE = "https://learn.microsoft.com/zh-tw/office/vba/api/"
APP_TITLE_CONTAINS = "Word"       # substring matched against the TOC's top-level app titles
APP_LABEL = "Word"                 # display label used in generated headers
OUT_DIR = "../references/Word物件模型"  # where the generated index files are written

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
toc_path = os.path.join(SCRIPT_DIR, 'toc_raw.json')
if not os.path.exists(toc_path):
    raise SystemExit(
        "toc_raw.json not found next to this script. Fetch it first:\n"
        '  curl -s "https://learn.microsoft.com/zh-tw/office/vba/api/toc.json" -o toc_raw.json'
    )
with open(toc_path, encoding='utf-8') as f:
    data = json.load(f)

def find_top(items, title_contains):
    for it in items:
        if title_contains in it.get('toc_title', ''):
            return it
    return None

root = data['items'][0]
app = find_top(root['children'], APP_TITLE_CONTAINS)
objmodel = find_top(app['children'], '物件模型')
overview_href = objmodel['children'][0].get('href') if objmodel['children'] else None
overview_url = (BASE + overview_href) if overview_href else ''

all_children = [c for c in objmodel['children'] if c.get('href') and c.get('href') != overview_href]
enumerations_entry = None
objects = []
for c in all_children:
    # The "Enumerations" catch-all entry is identified by title, not href — its href varies
    # per app ('excel(enumerations)', bare 'outlook', etc.) so href-pattern matching is unreliable.
    if c.get('toc_title') == '列舉':
        enumerations_entry = c
    else:
        objects.append(c)
print(f"Total objects: {len(objects)}")

def url_for(href):
    return BASE + href

def slug(name):
    # filesystem-safe anchor slug
    s = re.sub(r'[^\w\-]', '', name, flags=re.UNICODE)
    return s

out_dir = os.path.join(SCRIPT_DIR, OUT_DIR)
os.makedirs(out_dir, exist_ok=True)

# Sort objects alphabetically by toc_title (using the object href as tiebreaker/primary sort key
# since titles mix Chinese-translated names and English names inconsistently; href is stable English)
def sort_key(o):
    return o.get('href', '').lower()

objects_sorted = sorted(objects, key=sort_key)

# Chunk into files of ~35 objects each
CHUNK = 35
chunks = [objects_sorted[i:i+CHUNK] for i in range(0, len(objects_sorted), CHUNK)]

index_lines = []
index_lines.append(f"# {APP_LABEL} 物件模型 - 完整物件總覽\n")
index_lines.append(f"來源：TOC 結構解析自 {overview_url} ，共 {len(objects_sorted)} 個物件。\n")
index_lines.append("> 本索引只列出物件名稱、成員（方法/屬性/事件）名稱與官方連結，不含說明文字（官方頁面本身在該層級也未提供逐一成員的說明，需點進個別成員頁面才有完整語法）。\n")
if enumerations_entry is not None:
    enum_url = url_for(enumerations_entry.get('href'))
    index_lines.append(f"**列舉常數總覽（相當於 {APP_LABEL} 版的 Constants）**：[{enum_url}]({enum_url})\n")
index_lines.append("| # | 物件 | 方法數 | 屬性數 | 事件數 | 詳細內容檔案 |")
index_lines.append("| --- | --- | --- | --- | --- | --- |")

file_names = []
for idx, chunk in enumerate(chunks):
    first = chunk[0].get('toc_title', chunk[0].get('href'))
    last = chunk[-1].get('toc_title', chunk[-1].get('href'))
    fname = f"物件_{idx+1:02d}.md"
    file_names.append(fname)

counter = 1
for idx, chunk in enumerate(chunks):
    fname = file_names[idx]
    lines = []
    lines.append(f"# {APP_LABEL} 物件模型 ({idx+1}/{len(chunks)})\n")
    lines.append("[回總覽](00_物件總覽.md)\n")
    for obj in chunk:
        name = obj.get('toc_title', '(未命名)')
        href = obj.get('href')
        obj_url = url_for(href) if href else ''
        anchor = slug(name) + str(counter)
        lines.append(f"## {name} {{#{anchor}}}\n")
        if obj_url:
            lines.append(f"物件總覽頁：[{obj_url}]({obj_url})\n")

        methods_count = props_count = events_count = 0
        groups = obj.get('children', [])
        for g in groups:
            gname = g.get('toc_title', '')
            members = g.get('children', [])
            if not members:
                continue
            if '方法' in gname:
                methods_count = len(members)
            elif '屬性' in gname:
                props_count = len(members)
            elif 'Event' in gname or '事件' in gname:
                events_count = len(members)

            lines.append(f"**{gname}** ({len(members)})")
            member_links = []
            for m in members:
                mname = m.get('toc_title', '')
                mhref = m.get('href')
                if mhref:
                    murl = url_for(mhref)
                    member_links.append(f"[{mname}]({murl})")
                else:
                    member_links.append(mname)
            lines.append("、".join(member_links) + "\n")

        index_lines.append(f"| {counter} | [{name}]({fname}#{anchor}) | {methods_count} | {props_count} | {events_count} | {fname} |")
        counter += 1

    with open(os.path.join(out_dir, fname), 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))

with open(os.path.join(out_dir, "00_物件總覽.md"), 'w', encoding='utf-8') as f:
    f.write("\n".join(index_lines))

print("Generated", len(chunks), "detail files +  index")
print("Total member entries:", counter - 1)
