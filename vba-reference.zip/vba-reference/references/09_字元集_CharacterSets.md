# 字元集 (Character Sets)

來源分類頁：https://learn.microsoft.com/zh-tw/office/vba/language/reference/character-sets

base URL：`https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/`

VBA 使用的字元編碼對照表，常搭配 [Asc / Chr 函式](02_函式_Functions.md)在字元與其數值代碼之間互相轉換。

| 範圍 | 說明 | 連結 |
| --- | --- | --- |
| 字元集 (0-127) | 標準 ASCII 範圍，包含控制字元、數字、英文字母、常用符號 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/character-set-0127) |
| 字元集 (128-255) | 延伸 ASCII 範圍，內容依系統的字碼頁 (code page) 而異 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/character-set-128255) |

實用對照：`Asc("A")` = 65、`Chr(65)` = `"A"`；數字 `"0"`~`"9"` 對應碼位 48~57。
