# 資料類型 (Data Types)

來源：https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/data-type-summary

base URL：`https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/`

## 內建資料型別

| 型別 | 儲存大小(概略) | 說明 | 連結 |
| --- | --- | --- | --- |
| Boolean | 2 位元組 | 布林值，僅 True 或 False | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/boolean-data-type) |
| Byte | 1 位元組 | 0~255 的無符號整數，常用於處理二進位資料 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/byte-data-type) |
| Integer | 2 位元組 | 短整數，範圍約 ±32767 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/integer-data-type) |
| Long | 4 位元組 | 長整數，範圍約 ±21 億 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/long-data-type) |
| LongLong | 8 位元組 | 64 位元整數，僅在 64 位元平台上有效 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/longlong-data-type) |
| LongPtr | 依平台而定 | 用來相容表示指標／控制代碼，32 位元環境等同 Long，64 位元環境等同 LongLong | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/longptr-data-type) |
| Single | 4 位元組 | 單精度浮點數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/single-data-type) |
| Double | 8 位元組 | 雙精度浮點數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/double-data-type) |
| Currency | 8 位元組 | 高精度定點數，適合金額運算避免浮點誤差 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/currency-data-type) |
| Decimal | 14 位元組 | 極高精度數值型別，只能存放於 Variant 中（無法直接 Dim 為 Decimal） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/decimal-data-type) |
| Date | 8 位元組 | 日期時間型別 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/date-data-type) |
| String | 依長度而定 | 文字字串，分為可變長度與固定長度兩種 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/string-data-type) |
| Object | 4 位元組 | 通用物件參考型別 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/object-data-type) |
| Variant | 16~22+ 位元組 | 可存放任何型別資料的萬用型別，未宣告型別的變數預設即為此型別 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/variant-data-type) |
| 使用者自訂型別 | 依成員而定 | 以 Type...End Type 定義，把多個欄位組成一個複合結構 | [連結](https://learn.microsoft.com/zh-tw/office/vba/how-to/user-defined-data-type) |

補充：Collection、Dictionary 也可視為特殊的資料型別（詳見[物件分類](03_物件_Objects.md)）。

## 識別碼類型字元（宣告時可用符號代替型別名稱）

| 符號 | 對應型別 | 範例 |
| --- | --- | --- |
| `%` | Integer | `Dim L%` |
| `&` | Long | `Dim M&` |
| `^` | LongLong | `Dim N^` |
| `@` | Currency | `Const W@ = 37.5` |
| `!` | Single | `Dim Q!` |
| `#` | Double | `Dim X#` |
| `$` | String | `Dim V$ = "text"` |

注意：Boolean、Byte、Date、Decimal、LongPtr、Object、Variant 以及陣列/集合/字典/結構等複合型別沒有對應的識別碼類型字元。

## 型別轉換

- 強制轉型函式（CBool、CByte、CCur、CDate、CDbl、CDec、CInt、CLng、CLngLng、CLngPtr、CSng、CStr、CVar）詳見 [函式分類 > 型別轉換函式](02_函式_Functions.md)
- 型別驗證函式（IsArray、IsDate、IsEmpty、IsError、IsMissing、IsNull、IsNumeric、IsObject）詳見 [函式分類 > 陣列與型別檢查函式](02_函式_Functions.md)
