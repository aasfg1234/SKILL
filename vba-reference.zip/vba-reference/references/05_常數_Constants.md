# 常數 (Constants)

來源分類頁：https://learn.microsoft.com/zh-tw/office/vba/language/reference/constants-visual-basic-for-applications

base URL：`https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/`

以下每個群組都是一組相關的內建常數，通常搭配對應的函式或陳述式使用，方便寫程式時用有意義的名稱取代魔術數字。

| 常數群組 | 用途 | 連結 |
| --- | --- | --- |
| Calendar | 指定使用哪種曆法（西曆/回曆），常搭配日期函式使用 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/calendar-constants) |
| CallType | 描述 CallByName 呼叫的類型（方法/取得屬性/設定屬性） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/calltype-constants) |
| Color | 常用色彩代碼常數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/color-constants) |
| Comparison | 字串比較模式常數（Binary/Text/Database），用於 Option Compare 或 StrComp | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/comparison-constants) |
| Date | 一般日期相關常數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/date-constants) |
| Date Format | 指定日期格式化樣式的常數，供 Format 系列函式使用 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/date-format-constants) |
| Dir、GetAttr 及 SetAttr | 檔案屬性旗標常數（唯讀、隱藏、系統、目錄等），供對應的檔案函式/陳述式使用 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/dir-getattr-and-setattr-constants) |
| DriveType | 磁碟機類型代碼（可移除式、固定式、網路、光碟機等），供 FileSystemObject 使用 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/drivetype-constants) |
| 檔案屬性 | 檔案系統物件（FSO）用的檔案屬性常數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/file-attribute-constants) |
| 檔案輸入/輸出 | Open 陳述式的存取模式常數（Input/Output/Random/Append/Binary 等） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/file-input-output-constants) |
| Form | UserForm 相關的常數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/form-constants) |
| IMEStatus | 輸入法編輯器狀態常數，供 IMEStatus 函式使用 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/imestatus-constants) |
| Keycode | 鍵盤按鍵代碼常數（vbKeyA、vbKeyEnter 等），常用於鍵盤事件處理 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/keycode-constants) |
| Miscellaneous | 未歸類於其他群組的雜項常數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/miscellaneous-constants) |
| MsgBox | MsgBox 的按鈕組合、圖示、預設按鈕與回傳值常數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/msgbox-constants) |
| QueryClose | UserForm QueryClose 事件中，用於判斷關閉來源的常數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/queryclose-constants) |
| Shell | Shell 函式視窗顯示樣式常數（正常、最小化、最大化等） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/shell-constants) |
| SpecialFolder | 系統特殊資料夾代碼常數（Windows 目錄、系統目錄、暫存目錄），供 FSO 使用 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/specialfolder-constants) |
| StrConv | StrConv 函式的轉換模式常數（大小寫、片假名、全形半形等） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/strconv-constants) |
| System Color | 對應 Windows 系統色彩配置的常數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/system-color-constants) |
| Tristate | 三態旗標常數（True/False/UseDefault），常見於 FSO 的 TextStream 讀寫方法 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/tristate-constants) |
