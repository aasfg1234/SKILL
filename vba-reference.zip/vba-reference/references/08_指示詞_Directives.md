# 指示詞 (Directives)

來源分類頁：https://learn.microsoft.com/zh-tw/office/vba/language/reference/directives

base URL：`https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/`

編譯器指示詞在編譯階段就會被處理，用來決定哪些程式碼要被實際編譯進去，而不是在執行時期判斷。

| 指示詞 | 說明 | 連結 |
| --- | --- | --- |
| `#Const` | 定義只在編譯階段存在的條件式編譯常數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/const-directive) |
| `#If...Then...#Else` | 依編譯常數的值，選擇性地編譯不同區塊的程式碼（常用於區分 32/64 位元或 Windows/Mac） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ifthenelse-directive) |
