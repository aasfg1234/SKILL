# 運算子 (Operators)

來源分類頁：https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/operator-summary

base URL：`https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/`

## 算術運算子

| 運算子 | 說明 | 連結 |
| --- | --- | --- |
| `^` | 次方運算 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/caret-operator) |
| `*` | 乘法 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/operator) |
| `/` | 除法（結果為浮點數） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/forwardslash-operator) |
| `\` | 整數除法（結果無條件捨去小數） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/backslash-operator) |
| `Mod` | 取餘數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/mod-operator) |
| `+` | 加法 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/plus-operator) |
| `-` | 減法 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/minus-operator) |

## 比較運算子

| 運算子 | 說明 | 連結 |
| --- | --- | --- |
| `=` | 相等比較 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/equals-operator) |
| `Is` | 比較兩個物件變數是否指向同一個物件實例 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/is-operator) |
| `Like` | 依萬用字元樣式比對字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/like-operator) |
| 其他關係運算子（`<`、`>`、`<=`、`>=`、`<>`） | 大於、小於、不等於等比較 | 見 [比較運算子總覽](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/comparison-operators) |

## 串連運算子

| 運算子 | 說明 | 連結 |
| --- | --- | --- |
| `&` | 字串串接（建議優先使用，型別轉換較穩定） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ampersand-operator) |
| `+` | 也可用於字串串接，但與數值加法共用符號，容易造成型別混淆 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/plus-operator) |

## 邏輯運算子

| 運算子 | 說明 | 連結 |
| --- | --- | --- |
| `And` | 邏輯且 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/and-operator) |
| `Or` | 邏輯或 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/or-operator) |
| `Not` | 邏輯反 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/not-operator) |
| `Xor` | 互斥或 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/xor-operator) |
| `Eqv` | 邏輯等價 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/eqv-operator) |
| `Imp` | 邏輯蘊含 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/imp-operator) |

## 其他

- [運算子優先順序](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/operator-precedence)：說明多個運算子同時出現在同一運算式中時的計算順序規則。
