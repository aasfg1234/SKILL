# 事件 (Events)

來源分類頁：https://learn.microsoft.com/zh-tw/office/vba/language/reference/events-visual-basic-for-applications

base URL：`https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/`

以下是 VBA UserForm／模組層級可用的內建事件，寫在對應物件的程式碼模組中即會自動被觸發。

| 事件 | 說明 | 連結 |
| --- | --- | --- |
| Activate、Deactivate | 當表單成為/失去作用中視窗時觸發 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/activate-deactivate-events) |
| Initialize | 在物件（如 UserForm）建立時觸發一次，適合放初始化程式碼 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/initialize-event) |
| QueryClose | 在物件即將關閉前觸發，可用來取消關閉或判斷關閉來源 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/queryclose-event) |
| Resize | 當表單大小變更時觸發 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/resize-event) |
| Terminate | 在物件從記憶體卸載時觸發，適合放清理程式碼 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/terminate-event-visual-basic-for-applications) |

補充：自訂事件可用 [Event 陳述式](01_陳述式_Statements.md)宣告、[RaiseEvent 陳述式](01_陳述式_Statements.md)觸發。
