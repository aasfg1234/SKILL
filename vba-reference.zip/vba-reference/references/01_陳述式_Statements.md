# 陳述式 (Statements)

來源分類頁：https://learn.microsoft.com/zh-tw/office/vba/language/reference/statements

base URL：`https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/`（除特別標註外）

## 程式流程控制

| 陳述式 | 說明 | 連結 |
| --- | --- | --- |
| If...Then...Else | 條件式分支，依條件執行不同區塊 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ifthenelse-statement) |
| Select Case | 依單一運算式的值在多個分支中選擇執行 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/select-case-statement) |
| For...Next | 迴圈，依計數器從起始值跑到結束值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/fornext-statement) |
| For Each...Next | 迴圈，走訪集合或陣列中的每個元素 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/for-eachnext-statement) |
| Do...Loop | 依條件重複執行區塊（前測或後測） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/doloop-statement) |
| While...Wend | 條件為真時重複執行（較舊式寫法，建議改用 Do...Loop） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/whilewend-statement) |
| GoTo | 無條件跳躍至程式中的標籤 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/goto-statement) |
| GoSub...Return | 跳至子程序區塊執行後返回（舊式寫法） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/gosubreturn-statement) |
| On...GoSub、On...GoTo | 依運算式值跳至對應的行號/標籤（舊式寫法） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ongosub-ongoto-statements) |
| On Error | 設定錯誤發生時的處理方式（跳轉、略過、恢復） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/on-error-statement) |
| Exit | 提前跳出 Sub、Function、For、Do 等區塊 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/exit-statement) |
| Stop | 暫停程式執行（除錯用，類似中斷點） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/stop-statement) |
| End | 結束程序、區塊或整個程式執行 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/end-statement) |
| With | 對同一物件重複存取多個成員時省略物件名稱前綴 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/with-statement) |
| RaiseEvent | 觸發自訂事件，通知已註冊的事件處理程序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/raiseevent-statement) |

## 宣告與範圍

| 陳述式 | 說明 | 連結 |
| --- | --- | --- |
| Dim | 宣告變數並配置儲存空間 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/dim-statement) |
| Const | 宣告常數（編譯時期固定值） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/const-statement) |
| Public | 在模組層級宣告專案內所有模組可存取的變數/程序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/public-statement) |
| Private | 在模組層級宣告僅該模組可存取的變數/程序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/private-statement) |
| Static | 宣告程序層級變數，其值在多次呼叫間保留 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/static-statement) |
| ReDim | 重新配置動態陣列的大小（可搭配 Preserve 保留資料） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/redim-statement) |
| Erase | 釋放陣列記憶體或重新初始化陣列元素 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/erase-statement) |
| Type | 定義使用者自訂資料型別（多個欄位組成的結構） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/type-statement) |
| Enum | 定義列舉常數集合 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/enum-statement) |
| Deftype 系列（DefBool、DefInt…） | 設定模組中未明確宣告型別的變數之預設資料型別 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/concepts/getting-started/deftype-statements) |
| Option Base | 設定陣列預設下界為 0 或 1 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/option-base-statement) |
| Option Compare | 設定字串比較方式（Binary/Text/Database） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/option-compare-statement) |
| Option Explicit | 強制要求所有變數須先宣告才能使用 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/option-explicit-statement) |
| Option Private | 將模組標記為私有，不對其他專案公開 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/option-private-statement) |
| Declare | 宣告對外部 DLL（如 Windows API）函式的參考 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/declare-statement) |
| Implements | 讓類別模組實作某個介面/類別所定義的成員 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/implements-statement) |
| Event | 在類別模組中宣告自訂事件 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/event-statement) |

## 程序定義

| 陳述式 | 說明 | 連結 |
| --- | --- | --- |
| Sub | 定義不回傳值的程序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/sub-statement) |
| Function | 定義有回傳值的程序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/function-statement) |
| Property Get | 定義讀取物件屬性值的程序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/property-get-statement) |
| Property Let | 定義設定物件屬性值（一般型別）的程序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/property-let-statement) |
| Property Set | 定義設定物件屬性值（物件型別）的程序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/property-set-statement) |
| Call | 明確呼叫 Sub 或 Function 程序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/call-statement) |

## 賦值

| 陳述式 | 說明 | 連結 |
| --- | --- | --- |
| Let | 將值指派給變數（一般可省略，隱含使用） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/let-statement) |
| Set | 將物件參考指派給物件變數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/set-statement) |
| LSet | 將字串靠左對齊複製到另一字串，或複製不同型別的自訂型別變數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/lset-statement) |
| RSet | 將字串靠右對齊複製到另一字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/rset-statement) |
| Mid（陳述式） | 取代字串中指定位置、長度的子字串內容 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/mid-statement) |

## 檔案輸入/輸出

| 陳述式 | 說明 | 連結 |
| --- | --- | --- |
| Open | 開啟檔案以供讀寫（循序、隨機、二進位模式） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/open-statement) |
| Close | 關閉以 Open 開啟的檔案 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/close-statement) |
| Reset | 關閉所有以 Open 開啟的檔案並將緩衝區資料寫入磁碟 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/reset-statement) |
| Print # | 將格式化資料寫入循序檔案 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/printstatement) |
| Write # | 將資料以逗號分隔、字串加引號的格式寫入循序檔案 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/writestatement) |
| Input # | 從循序檔案讀取資料存入變數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/inputstatement) |
| Line Input # | 從循序檔案讀取一整行文字 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/line-inputstatement) |
| Get | 從隨機或二進位檔案讀取資料至變數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/get-statement) |
| Put | 將變數資料寫入隨機或二進位檔案 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/put-statement) |
| Width # | 設定循序檔案輸出的每行最大寬度 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/widthstatement) |
| Lock、Unlock | 鎖定/解除鎖定多使用者環境下共用檔案的部分或全部內容 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/lock-unlock-statements) |
| Seek（陳述式） | 設定檔案內下一次讀寫的位置 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/seek-statement) |

## 檔案系統操作

| 陳述式 | 說明 | 連結 |
| --- | --- | --- |
| ChDir | 變更目前的工作目錄 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/chdir-statement) |
| ChDrive | 變更目前的磁碟機 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/chdrive-statement) |
| MkDir | 建立新目錄 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/mkdir-statement) |
| RmDir | 移除既有（空）目錄 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/rmdir-statement) |
| Name | 重新命名檔案或目錄，亦可搬移檔案 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/name-statement) |
| Kill | 刪除檔案 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/kill-statement) |
| FileCopy | 複製檔案 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/filecopy-statement) |
| SetAttr | 設定檔案的屬性（唯讀、隱藏等） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/setattr-statement) |

## 系統/應用程式互動

| 陳述式 | 說明 | 連結 |
| --- | --- | --- |
| AppActivate | 切換作用中視窗至指定的應用程式 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/appactivate-statement) |
| Beep | 讓電腦喇叭發出嗶聲 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/beep-statement) |
| SendKeys | 模擬鍵盤輸入，將按鍵傳送至作用中視窗 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/sendkeys-statement) |
| Date（陳述式） | 設定系統目前日期 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/date-statement) |
| Time（陳述式） | 設定系統目前時間 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/time-statement) |
| Randomize | 初始化亂數產生器的種子值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/randomize-statement) |
| SaveSetting | 將資訊寫入登錄檔中應用程式的設定區段 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/savesetting-statement) |
| DeleteSetting | 從登錄檔中刪除應用程式的設定區段或機碼 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/deletesetting-statement) |
| Error（陳述式） | 模擬指定的錯誤發生（可測試錯誤處理） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/error-statement) |
| Rem | 用來加入註解（建議改用單引號 `'`） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/rem-statement) |
| Resume | 從錯誤處理常式返回，繼續執行程式 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/resume-statement) |

## UserForm 相關

| 陳述式 | 說明 | 連結 |
| --- | --- | --- |
| Load | 將 UserForm 或控制項載入記憶體但不顯示 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/load-statement) |
| Unload | 從記憶體卸載 UserForm 或控制項 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/unload-statement) |
