# 物件 (Objects)

來源分類頁：https://learn.microsoft.com/zh-tw/office/vba/language/reference/objects-visual-basic-for-applications

base URL：`https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/`

## 資料結構類

| 物件 | 說明 | 連結 |
| --- | --- | --- |
| Collection | 內建的有序物件集合，可用索引或索引鍵存取、新增、移除元素 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/collection-object) |
| Dictionary | 索引鍵/值配對的資料結構（需啟用 Microsoft Scripting Runtime），查找效率高 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/dictionary-object) |

## 錯誤處理與除錯

| 物件 | 說明 | 連結 |
| --- | --- | --- |
| Err | 全域物件，保存最近一次執行時期錯誤的資訊（錯誤碼、描述等），常與 On Error 搭配使用 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/err-object) |
| Debug | 提供在偵錯時輸出訊息（Debug.Print）或設定中斷點（Debug.Assert）的功能 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/debug-object) |

## 檔案系統物件（FileSystemObject 家族，需啟用 Microsoft Scripting Runtime）

| 物件 | 說明 | 連結 |
| --- | --- | --- |
| FileSystemObject | 檔案系統操作的主要進入點，可建立/複製/移動/刪除檔案與資料夾 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/filesystemobject-object) |
| Drive | 代表單一磁碟機（含網路磁碟機），提供容量、可用空間等資訊 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/drive-object) |
| Drives 集合 | 系統上所有可用 Drive 物件的集合 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/drives-collection) |
| Folder | 代表單一資料夾，提供路徑、子資料夾、檔案等屬性與方法 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/folder-object) |
| Folders 集合 | 某資料夾底下所有子 Folder 物件的集合 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/folders-collection) |
| File | 代表單一檔案，提供名稱、大小、日期等屬性與方法 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/file-object) |
| Files 集合 | 某資料夾底下所有 File 物件的集合 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/files-collection) |
| TextStream | 代表一個開啟的文字檔案，用於循序讀寫文字內容 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/textstream-object) |

## UI 相關

| 物件 | 說明 | 連結 |
| --- | --- | --- |
| UserForm | 自訂對話方塊/表單物件，可放置控制項並撰寫互動邏輯 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/userform-object) |
