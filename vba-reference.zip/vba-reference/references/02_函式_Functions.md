# 函式 (Functions)

來源分類頁：https://learn.microsoft.com/zh-tw/office/vba/language/reference/functions-visual-basic-for-applications

base URL：`https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/`（除特別標註外）

## 轉換函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| Asc | 傳回字串第一個字元對應的字元碼（數字） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/asc-function) |
| Chr | 傳回指定字元碼對應的字元 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/chr-function) |
| CVErr | 建立一個代表使用者自訂錯誤的 Variant | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/cverr-function) |
| Format | 依指定格式字串將數值/日期/字串格式化為字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/format-function-visual-basic-for-applications) |
| Hex | 傳回數值的十六進位字串表示 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/hex-function) |
| Oct | 傳回數值的八進位字串表示 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/oct-function) |
| Str | 將數值轉換為字串表示 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/str-function) |
| Val | 將字串開頭的數字部分轉換為數值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/val-function) |

## 型別轉換函式（C 系列）

CBool、CByte、CCur、CDate、CDbl、CDec、CInt、CLng、CLngLng、CLngPtr、CSng、CStr、CVar：將運算式強制轉換為對應的資料型別。
說明總覽連結：[型別轉換函式](https://learn.microsoft.com/zh-tw/office/vba/language/concepts/getting-started/type-conversion-functions)

## 數學函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| Abs | 傳回數值的絕對值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/abs-function) |
| Atn | 傳回反正切值（弧度） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/atn-function) |
| Cos | 傳回餘弦值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/cos-function) |
| Sin | 傳回正弦值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/sin-function) |
| Tan | 傳回正切值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/tan-function) |
| Exp | 傳回 e 的指定次方 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/exp-function) |
| Log | 傳回自然對數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/log-function) |
| Sqr | 傳回平方根 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/sqr-function) |
| Rnd | 傳回介於 0 到 1 之間的亂數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/rnd-function) |
| Sgn | 傳回數值的正負符號（-1、0、1） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/sgn-function) |
| Int、Fix | 傳回數值的整數部分（Int 向下取整，Fix 去除小數） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/int-fix-functions) |
| 衍生的數學函式 | 說明如何用基本函式組合出 Sec、Csc、Cot 等三角函式 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/derived-math-functions) |

## 字串函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| Left | 取字串左邊指定字元數的子字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/left-function) |
| Right | 取字串右邊指定字元數的子字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/right-function) |
| Mid（函式） | 取字串中間指定位置與長度的子字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/mid-function) |
| Len | 傳回字串長度或變數所需的位元組數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/len-function) |
| InStr | 從字串中搜尋子字串，傳回第一個出現的位置（由左至右） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/instr-function) |
| InStrRev | 從字串尾端開始搜尋子字串位置（由右至左） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/instrrev-function) |
| Replace | 將字串中的子字串取代為另一字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/replace-function) |
| Split | 依分隔符號將字串拆分成字串陣列 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/split-function) |
| Join | 將字串陣列以分隔符號串接為單一字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/join-function) |
| Filter | 依條件篩選字串陣列，傳回符合條件的子集合 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/filter-function) |
| LCase | 將字串轉為小寫 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/lcase-function) |
| UCase | 將字串轉為大寫 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ucase-function) |
| LTrim、RTrim、Trim | 去除字串左側/右側/兩側的空白字元 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ltrim-rtrim-and-trim-functions) |
| Space | 傳回指定數量空白字元組成的字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/space-function) |
| Spc | 用於 Print # 陳述式中插入指定數量的空白 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/spc-function) |
| Tab | 用於 Print # 陳述式中將輸出定位到指定欄位 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/tab-function) |
| String | 傳回由重複字元組成的字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/string-function) |
| StrReverse | 反轉字串字元順序 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/strreverse-function) |
| StrComp | 比較兩個字串，傳回比較結果（-1/0/1） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/strcomp-function) |
| StrConv | 轉換字串格式（大小寫、全形半形、片假名等） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/strconv-function) |

## 日期時間函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| Date（函式） | 傳回目前系統日期 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/date-function) |
| Time | 傳回目前系統時間 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/time-function) |
| Now | 傳回目前系統日期與時間 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/now-function) |
| Timer | 傳回自午夜起經過的秒數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/timer-function) |
| DateAdd | 將指定的時間間隔加到日期上，傳回新日期 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/dateadd-function) |
| DateDiff | 計算兩個日期之間的時間間隔數量 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/datediff-function) |
| DatePart | 傳回日期中指定的部分（年、月、日等） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/datepart-function) |
| DateSerial | 依年、月、日數值組成日期 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/dateserial-function) |
| DateValue | 將字串轉換為日期值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/datevalue-function) |
| TimeSerial | 依時、分、秒數值組成時間 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/timeserial-function) |
| TimeValue | 將字串轉換為時間值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/timevalue-function) |
| Year、Month、Day | 分別傳回日期的年、月、日部分 | [年](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/year-function) / [Month](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/month-function) / [Day](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/day-function) |
| Hour、Minute、Second | 分別傳回時間的時、分、秒部分 | [Hour](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/hour-function) / [Minute](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/minute-function) / [Second](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/second-function) |
| Weekday | 傳回日期對應的星期幾（數字） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/weekday-function) |
| WeekdayName | 傳回星期幾的名稱字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/weekdayname-function) |
| MonthName | 傳回月份的名稱字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/monthname-function) |
| IsDate | 判斷運算式是否可轉換為日期 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/isdate-function) |

## 財務函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| FV | 計算年金的未來值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/fv-function) |
| PV | 計算年金的現值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/pv-function) |
| NPV | 計算一系列現金流量以特定折現率折現後的淨現值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/npv-function) |
| IRR | 計算一系列現金流量的內部報酬率 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/irr-function) |
| MIRR | 計算考量借貸與再投資利率的修正內部報酬率 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/mirr-function) |
| NPer | 計算年金所需的期數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/nper-function) |
| Pmt | 計算年金的每期付款金額 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/pmt-function) |
| IPmt | 計算年金某期付款中的利息部分 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ipmt-function) |
| PPmt | 計算年金某期付款中的本金部分 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ppmt-function) |
| Rate | 計算年金每期的利率 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/rate-function) |
| DDB | 以倍數餘額遞減法計算資產折舊 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ddb-function) |
| SLN | 以直線法計算資產折舊 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/sln-function) |
| SYD | 以年數合計法計算資產折舊 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/syd-function) |

## 陣列與型別檢查函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| Array | 建立並傳回包含指定元素的 Variant 陣列 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/array-function) |
| LBound | 傳回陣列指定維度的下界索引 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/lbound-function) |
| UBound | 傳回陣列指定維度的上界索引 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ubound-function) |
| IsArray | 判斷變數是否為陣列 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/isarray-function) |
| IsEmpty | 判斷變數是否已初始化（未賦值） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/isempty-function) |
| IsError | 判斷運算式是否為錯誤值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/iserror-function) |
| IsMissing | 判斷選擇性參數是否有傳入引數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/ismissing-function) |
| IsNull | 判斷運算式是否不含任何有效資料（Null） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/isnull-function) |
| IsNumeric | 判斷運算式是否可視為數值運算 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/isnumeric-function) |
| IsObject | 判斷變數是否為物件變數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/isobject-function) |
| TypeName | 傳回變數的資料型別名稱字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/typename-function) |
| VarType | 傳回代表變數子型別的整數代碼 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/vartype-function) |

## 邏輯/分支輔助函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| IIf | 依條件傳回兩個運算式其中之一（行內 if） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/iif-function) |
| Choose | 依索引值從一系列選項中選出對應值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/choose-function) |
| Switch | 依序求值多個條件，傳回第一個為真所對應的值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/switch-function) |
| Partition | 判斷數值落在哪個等距區間，傳回描述該區間的字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/partition-function) |

## 檔案系統函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| Dir | 依檔名樣式尋找檔案或目錄名稱 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/dir-function) |
| CurDir | 傳回目前的路徑 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/curdir-function) |
| FileLen | 傳回檔案大小（位元組） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/filelen-function) |
| FileDateTime | 傳回檔案最後修改的日期與時間 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/filedatetime-function) |
| FileAttr | 傳回以 Open 開啟的檔案的存取模式資訊 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/fileattr-function) |
| GetAttr | 傳回檔案或目錄的屬性 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/getattr-function) |
| FreeFile | 傳回下一個可用的檔案代號，供 Open 使用 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/freefile-function) |
| EOF | 判斷是否已到達開啟檔案的結尾 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/eof-function) |
| Loc | 傳回開啟檔案目前讀寫位置 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/loc-function) |
| LOF | 傳回開啟檔案的總長度（位元組） | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/lof-function) |
| Seek（函式） | 傳回開啟檔案目前讀寫位置 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/seek-function) |
| Input | 從開啟的循序檔案讀取指定數量字元 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/input-function) |

## 互動/系統函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| MsgBox | 顯示訊息對話方塊並可取得使用者按下的按鈕 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/msgbox-function) |
| InputBox | 顯示輸入對話方塊，取得使用者輸入的文字 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/inputbox-function) |
| Shell | 執行外部可執行程式 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/shell-function) |
| CreateObject | 建立並傳回對 ActiveX/COM 物件的參考 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/createobject-function) |
| GetObject | 取得檔案中現有的 ActiveX 物件參考，或執行中物件的參考 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/getobject-function) |
| CallByName | 以字串指定名稱來執行物件的方法或存取屬性 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/callbyname-function) |
| DoEvents | 讓出控制權給作業系統，處理其他事件與訊息 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/doevents-function) |
| Environ | 傳回作業系統環境變數的值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/environ-function) |
| Command | 傳回啟動應用程式時所使用的命令列引數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/command-function) |
| QBColor | 傳回 QBasic 16 色調色盤對應的 RGB 色彩值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/qbcolor-function) |
| RGB | 依紅、綠、藍分量組成一個色彩值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/rgb-function) |
| IMEStatus | 傳回輸入法編輯器 (IME) 的目前狀態 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/imestatus-function) |
| MacID、MacScript | macOS 專用：分別取得檔案類型碼、執行 AppleScript | [MacID](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/macid-function) / [MacScript](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/macscript-function) |

## 格式化函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| FormatCurrency | 將數值格式化為貨幣格式字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/formatcurrency-function) |
| FormatDateTime | 將日期時間格式化為指定樣式字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/formatdatetime-function) |
| FormatNumber | 將數值格式化為指定小數位數的字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/formatnumber-function) |
| FormatPercent | 將數值格式化為百分比字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/formatpercent-function) |
| Round | 將數值四捨五入到指定小數位數 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/round-function) |

## 登錄檔存取函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| GetSetting | 從登錄檔讀取應用程式的設定值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/getsetting-function) |
| GetAllSettings | 從登錄檔讀取應用程式某區段下的所有設定值 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/getallsettings-function) |

## 誤差/例外相關函式

| 函式 | 說明 | 連結 |
| --- | --- | --- |
| Error（函式） | 傳回對應錯誤代碼的錯誤訊息字串 | [連結](https://learn.microsoft.com/zh-tw/office/vba/language/reference/user-interface-help/error-function) |
