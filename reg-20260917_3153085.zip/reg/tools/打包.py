# -*- coding: utf-8 -*-
"""
把 reg 打成兩個交付 zip：reg-claude 與 reg-spade。程式相同，只有 SKILL.md 不同。
輸出到 repo 根目錄的 fin_repo/（.gitignore 已排除 zip 與 sha256 檔）。
    py reg/tools/打包.py
"""
import datetime
import hashlib
import io
import os
import subprocess
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.dirname(HERE)
ROOT = os.path.dirname(REG)
EXCLUDE_DIRS = {"tests", "__pycache__", "platform"}
EXCLUDE_EXT = {".pyc", ".zip"}


def commit_short():
    try:
        r = subprocess.run(["git", "-C", ROOT, "rev-parse", "--short", "HEAD"],
                           capture_output=True, text=True, encoding="utf-8")
        return r.stdout.strip() or "nogit"
    except OSError:
        return "nogit"


def files():
    for dirpath, dirnames, filenames in os.walk(REG):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        for name in sorted(filenames):
            if os.path.splitext(name)[1] in EXCLUDE_EXT:
                continue
            path = os.path.join(dirpath, name)
            yield path, "reg/" + os.path.relpath(path, REG).replace(os.sep, "/")


def build(platform, skill_source):
    out_dir = os.path.join(ROOT, "fin_repo")
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d")
    out = os.path.join(out_dir, "reg-%s_%s_%s.zip" % (platform, stamp, commit_short()))
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for path, arc in files():
            if arc == "reg/SKILL.md":
                z.write(skill_source, arc)
            else:
                z.write(path, arc)
    h = hashlib.sha256()
    with open(out, "rb") as f:
        h.update(f.read())
    with io.open(out[:-4] + ".sha256.txt", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (h.hexdigest(), os.path.basename(out)))
    print(out, flush=True)
    return out


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    build("claude", os.path.join(REG, "SKILL.md"))
    build("spade", os.path.join(REG, "platform", "SKILL.spade.md"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
