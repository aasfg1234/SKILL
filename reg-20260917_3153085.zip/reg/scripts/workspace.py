# -*- coding: utf-8 -*-
"""reg 工作區：把「舊版／新版丟進固定資料夾」跟「配對」「開始」串起來的底層模組。

    工作區/
      匯入/
        舊版/            ← 放現在生效的那份
        新版/            ← 放這次的草稿（沒改的本不放）
        規格包/<規章名>/ ← 有正式基準（LATEST.json）就放
        規章清單.csv     ← 「配對」產生，人確認；「開始」讀它
      產出/
        <規章名>/        ← 永遠是最新一輪
          審閱文件/ 填寫表單/ 系統檔案/
          系統檔案/歷次/<YYYYMMDD_HHMM>/   ← 上一輪的三格整包
        審閱文件/批次摘要.txt、批次驗收摘要.txt、LLM審查總表.xlsx、批次*_提醒.txt
        系統檔案/輸入/規章清單.csv
        系統檔案/歷次/<YYYYMMDD_HHMM>/     ← 上一輪的批次層級三格

本檔只提供底層函式（路徑、配對、清單讀寫、過期檢查、歸檔），不含 CLI；
「配對」「開始」兩個子命令的畫面輸出與 argparse 串接在 run_all.py。
"""
import csv
import datetime
import io
import os
import re
import shutil
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.dirname(HERE)
REGDIFF = os.path.join(HERE, "regdiff")
if REGDIFF not in sys.path:
    sys.path.insert(0, REGDIFF)

# 白名單只有一份：_common.SUPPORTED_EXTS。工作區這邊自己抄一份的話，
# 「配對認得的格式」跟「讀檔認得的格式」遲早會走鐘（no 14 就是這樣來的：
# compare 早就吃得下 .txt／.md，匯入夾卻只認 .docx）。
from _common import SUPPORTED_EXTS, SYSTEM_DIR, home_of

MANIFEST_COLUMNS = ["規章名", "舊版", "新版草稿", "發布根目錄", "配對方式", "備註"]
METHODS = ("檔名相同", "去版本字", "未配對", "手動")


class WorkspaceError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 路徑
# ---------------------------------------------------------------------------

def resolve_root(workspace_arg, settings):
    """--workspace 優先；其次設定.json 的「工作區根目錄」；都沒有就 <reg>/工作區。"""
    if workspace_arg:
        return os.path.abspath(workspace_arg)
    root = (settings or {}).get("工作區根目錄", "")
    if root:
        return os.path.abspath(root)
    return os.path.join(REG, "工作區")


def paths(root):
    """回傳工作區底下各個固定路徑：根、匯入、舊版、新版、規格包、清單、產出。"""
    root = os.path.abspath(root)
    imp = os.path.join(root, "匯入")
    return {
        "根": root,
        "匯入": imp,
        "舊版": os.path.join(imp, "舊版"),
        "新版": os.path.join(imp, "新版"),
        "規格包": os.path.join(imp, "規格包"),
        "清單": os.path.join(imp, "規章清單.csv"),
        "產出": os.path.join(root, "產出"),
    }


def ensure_layout(root):
    """建缺的資料夾（匯入/舊版、匯入/新版、匯入/規格包、產出），回傳新建的路徑。"""
    p = paths(root)
    created = []
    for key in ("舊版", "新版", "規格包", "產出"):
        folder = p[key]
        if not os.path.isdir(folder):
            os.makedirs(folder)
            created.append(folder)
    return created


# ---------------------------------------------------------------------------
# 正規化與配對（規格第三節）
# ---------------------------------------------------------------------------

# 括號（含內容）：（）()［］[]【】
_BRACKET_RE = re.compile(r"[（(［\[【][^）)］\]】]*[）)］\]】]")
# 逐字套用（順序照規格：長詞在前，避免「修訂版」先被「修訂」吃掉一半）。
# item6：「新版本」「最新版」之前沒列在表裡，會先被子字串「新版」吃掉一半，
# 剩下「本」「最」沒去乾淨——「新版本」要整個當一個詞去掉，不能靠「新版」
# 順帶處理；同理「舊版本」「最新版」。
_VERSION_WORDS = ["新版本", "舊版本", "最新版", "舊版", "新版", "草稿", "草案",
                  "修訂版", "修訂", "修正版", "修正", "定稿",
                  "乾淨版", "現行版", "現行", "最終版", "最終", "版本"]
_V_NUM_RE = re.compile(r"v\d+(\.\d+)?", re.IGNORECASE)
_VER_NUM_RE = re.compile(r"ver\.?\d+", re.IGNORECASE)
_DI_VERSION_RE = re.compile(r"第\d+版")
_DATE_RE = re.compile(r"\d{6,8}")
_STRIP_CHARS = "_-.~～"


def normalize_stem(name):
    """規格第三節 2.：NFKC、小寫、去空白、去括號及括號內文字、去版本字樣、去日期、去頭尾分隔符。"""
    s = unicodedata.normalize("NFKC", name or "")
    s = s.lower()
    s = re.sub(r"\s+", "", s)
    s = _BRACKET_RE.sub("", s)
    for word in _VERSION_WORDS:
        s = s.replace(word, "")
    s = _V_NUM_RE.sub("", s)
    s = _VER_NUM_RE.sub("", s)
    s = _DI_VERSION_RE.sub("", s)
    s = _DATE_RE.sub("", s)
    s = s.strip(_STRIP_CHARS)
    return s


def _exact_key(stem):
    """規格第三節 1.：檔名完全相同，不含副檔名，忽略大小寫與全半形。"""
    return unicodedata.normalize("NFKC", stem).lower()


def _stem(filename):
    return os.path.splitext(filename)[0]


def list_inputs(folder):
    """回傳 (支援的輸入檔名, 略過的檔名)，兩份都排序過。

    支援的副檔名照 _common.SUPPORTED_EXTS（.docx／.txt／.md）。
    子資料夾與 Word 的 `~$` 鎖定檔兩邊都不算：前者不是檔，後者是 Word 開著檔案
    時的暫存檔，使用者根本沒放過它，報「略過」只會嚇到人。

    為什麼要回傳「略過的」而不是安靜忽略（no 14）：使用者把十本丟進 匯入/，
    其中兩本是 .doc 或 .pdf，舊的 list_docx 直接跳過，畫面上就只寫「配對 8 本」。
    少掉的那兩本沒有任何一行提過，使用者要自己數才會發現。
    """
    if not os.path.isdir(folder):
        return [], []
    names = []
    skipped = []
    for entry in os.listdir(folder):
        if entry.startswith("~$"):
            continue
        if not os.path.isfile(os.path.join(folder, entry)):
            continue
        if os.path.splitext(entry)[1].lower() in SUPPORTED_EXTS:
            names.append(entry)
        else:
            skipped.append(entry)
    return sorted(names), sorted(skipped)


def list_docx(folder):
    """list_inputs 的舊名，只回「支援的輸入檔名」那一半。

    名字留著是因為 match()／stale_reasons() 這些呼叫端只要檔名清單；
    要「略過了哪些」的呼叫端（配對 CLI）請直接用 list_inputs。
    """
    return list_inputs(folder)[0]


def list_spec_names(spec_folder):
    """規格包底下的規章名清單：資料夾名，且 LATEST.json 存在才算（規格第三節
    6.）。給「配對」CLI 在呼叫 match() 前篩 spec_names 用。"""
    if not os.path.isdir(spec_folder):
        return []
    names = []
    for entry in os.listdir(spec_folder):
        full = os.path.join(spec_folder, entry)
        if os.path.isdir(full) and os.path.isfile(os.path.join(full, "LATEST.json")):
            names.append(entry)
    return sorted(names)


def match(old_names, new_names, spec_names):
    """配對舊版／新版檔名，回傳規章清單列。

    spec_names 是規格包底下的資料夾名清單；呼叫端要先用 list_spec_names() 篩過
    「LATEST.json 存在才算」（規格第三節 6.），這裡只負責用資料夾名對規章名。

    裁定（寫進程式註解）：舊版有、新版沒有的列，「配對方式」欄留空、「備註」寫
    「沒改」；METHODS 驗證只對非空值（見 read_manifest_rows）。正規化後仍對到
    多個候選時（規格第三節 3.），同樣不配、配對方式留空，備註寫「多個候選：…」，
    對應的舊版候選各自留在「沒改」列，交給人手動改清單、把配對方式改成「手動」。
    """
    spec_set = set(spec_names or [])

    def spec_root_rel(name):
        return "規格包/%s" % name if name in spec_set else ""

    old_stems = [_stem(n) for n in old_names]
    new_stems = [_stem(n) for n in new_names]
    old_file_by_stem = dict(zip(old_stems, old_names))
    new_file_by_stem = dict(zip(new_stems, new_names))

    # 第一階段：檔名完全相同（忽略大小寫與全半形）
    old_by_exact = {}
    for s in old_stems:
        old_by_exact.setdefault(_exact_key(s), []).append(s)
    new_by_exact = {}
    for s in new_stems:
        new_by_exact.setdefault(_exact_key(s), []).append(s)

    paired_old = set()
    paired_new = set()
    pair_method = {}  # old_stem -> (new_stem, 配對方式)

    for key, olds in old_by_exact.items():
        news = new_by_exact.get(key)
        if news and len(olds) == 1 and len(news) == 1:
            pair_method[olds[0]] = (news[0], "檔名相同")
            paired_old.add(olds[0])
            paired_new.add(news[0])

    # 第二階段：正規化去版本字
    remaining_old = [s for s in old_stems if s not in paired_old]
    remaining_new = [s for s in new_stems if s not in paired_new]

    old_by_norm = {}
    for s in remaining_old:
        old_by_norm.setdefault(normalize_stem(s), []).append(s)
    new_by_norm = {}
    for s in remaining_new:
        new_by_norm.setdefault(normalize_stem(s), []).append(s)

    ambiguous = {}  # new_stem -> [舊版候選 stem, ...]

    for norm_key, news in new_by_norm.items():
        if not norm_key:
            # 正規化後變空字串（檔名整個都是版本字，例如「新版.docx」「版本.docx」）
            # 沒有辨識力，不能拿來配對——不然任兩個「都只寫版本字」的檔名會被
            # 判成「去版本字」互相配對。讓它們照一般規則落到 未配對／沒改。
            continue
        olds = old_by_norm.get(norm_key, [])
        if len(olds) == 1 and len(news) == 1:
            pair_method[olds[0]] = (news[0], "去版本字")
            paired_old.add(olds[0])
            paired_new.add(news[0])
        elif olds:
            # 正規化後仍對到多個（不管是舊版還是新版那邊有超過一個候選）：不配。
            for n in news:
                ambiguous[n] = list(olds)
                paired_new.add(n)

    rows = []
    for old_stem in sorted(old_stems):
        old_file = old_file_by_stem[old_stem]
        release = spec_root_rel(old_stem)
        if old_stem in pair_method:
            new_stem, method = pair_method[old_stem]
            rows.append({"規章名": old_stem, "舊版": "舊版/%s" % old_file,
                        "新版草稿": "新版/%s" % new_file_by_stem[new_stem],
                        "發布根目錄": release, "配對方式": method, "備註": ""})
        else:
            rows.append({"規章名": old_stem, "舊版": "舊版/%s" % old_file,
                        "新版草稿": "", "發布根目錄": release,
                        "配對方式": "", "備註": "沒改"})

    tail_new = []
    for new_stem in new_stems:
        if new_stem in paired_new and new_stem not in ambiguous:
            continue  # 已經配到舊版、併進上面的列了
        new_file = new_file_by_stem[new_stem]
        release = spec_root_rel(new_stem)
        if new_stem in ambiguous:
            note = "多個候選：" + "、".join(ambiguous[new_stem])
            tail_new.append({"規章名": new_stem, "舊版": "", "新版草稿": "新版/%s" % new_file,
                             "發布根目錄": release, "配對方式": "", "備註": note})
        else:
            tail_new.append({"規章名": new_stem, "舊版": "", "新版草稿": "新版/%s" % new_file,
                             "發布根目錄": release, "配對方式": "未配對", "備註": ""})
    tail_new.sort(key=lambda r: r["規章名"])
    rows.extend(tail_new)
    return rows


DRAFT_MISSING_NOTE = "草稿不存在，需人工"


def _rel_key(rel):
    """清單裡的相對路徑 → 比對用的鍵：normcase＋normpath，把大小寫、斜線方向、
    多餘的 ./ 這些寫法差異拉平，但**保留整段路徑**。

    no 13：這裡以前取的是 os.path.basename，只要檔名一樣就當成同一份檔。手動列
    的「舊版」可以指到 舊版/ 以外（例如 規格包/甲/甲.docx），這時 舊版/甲.docx
    會被誤判成「已經被那個手動列用掉」而整列刪掉；補孤兒那一段又因為 basename
    已經在 referenced_old 裡而不補回來——整本規章就這樣從清單消失，畫面上連一句
    話都沒有。用整段相對路徑當鍵，同名不同路徑就是兩份不同的檔。"""
    return os.path.normcase(os.path.normpath((rel or "").strip()))


def merge_manual(auto_rows, old_rows, root):
    """把既有清單裡「手動」列蓋回這次重新算出來的 auto_rows，回傳
    (rows, kept_names, dropped_names, draft_missing)。

    只有「配對方式＝手動」且 舊版 欄指到的檔還存在的列才沿用（保留人填的
    舊版／新版草稿／發布根目錄／備註，用 規章名 對回 auto_rows 同一列）；
    檔案不存在的手動列不沿用，回到這次自動配對的結果（呼叫端據此印
    「已改回自動配對」）。

    no 16：沿用前也要看「新版草稿」欄指到的檔還在不在——以前只檢查舊版，草稿被
    刪掉時整列原樣寫回去，然後「開始」才在過期檢查那一關擋下來（而且清單已經被
    重寫過一次，下次配對又原樣寫回，永遠卡在同一個錯）。草稿不見時這一列還是留著
    （人填的舊版、發布根目錄別浪費），但把「新版草稿」欄清空、備註改成
    「草稿不存在，需人工」，並把 (規章名, 原本的草稿路徑) 放進 draft_missing 交給
    呼叫端提醒；欄位清空之後重跑配對就不會再把那個不存在的路徑寫回去。

    手動列指定的舊版檔，若被 auto_rows 另一列（規章名不同）當成自己的舊版檔
    （多半是原本「多個候選」的候選之一，各自留了一條「沒改」列），合併後要
    把那一列整筆丟掉，不然同一個舊版檔會出現兩列。草稿那邊同理：手動列認領走的
    草稿，auto_rows 裡那條「未配對」列要丟掉（不然人明明配好了，畫面永遠寫
    「有 1 本要人處理」）；若那一列自己有舊版檔，就退回「沒改」而不是整列刪掉。

    反過來，手動列把規章名改指去別的舊版檔之後，原本那個規章名底下的舊檔
    會變成沒有任何一列引用——不能讓它悄悄從清單消失，合併完成後補成一條
    獨立的「沒改」列（見函式最後一段）。"""
    p = paths(root)
    manual_by_name = {}
    dropped_names = []
    draft_missing = []
    for row in old_rows or []:
        if row.get("配對方式") != "手動":
            continue
        old_rel = row.get("舊版", "")
        if not (old_rel and os.path.isfile(os.path.join(p["匯入"], old_rel))):
            dropped_names.append(row["規章名"])
            continue
        row = dict(row)
        new_rel = row.get("新版草稿", "")
        if new_rel and not os.path.isfile(os.path.join(p["匯入"], new_rel)):
            row["新版草稿"] = ""
            row["備註"] = DRAFT_MISSING_NOTE
            draft_missing.append((row["規章名"], new_rel))
        manual_by_name[row["規章名"]] = row

    used_old_files = set()
    used_new_files = set()
    for row in manual_by_name.values():
        if row.get("舊版"):
            used_old_files.add(_rel_key(row["舊版"]))
        if row.get("新版草稿"):
            used_new_files.add(_rel_key(row["新版草稿"]))

    rows = []
    seen_names = set()
    for row in auto_rows:
        name = row["規章名"]
        if name in manual_by_name:
            rows.append(dict(manual_by_name[name]))
            seen_names.add(name)
            continue
        old_rel = row.get("舊版", "")
        if old_rel and _rel_key(old_rel) in used_old_files:
            continue  # 這個舊版檔已經被某個手動列用掉，這一列不再獨立列出
        new_rel = row.get("新版草稿", "")
        if new_rel and _rel_key(new_rel) in used_new_files:
            if not old_rel:
                continue  # 純粹的「未配對」列，草稿已被手動列認領，整列丟掉
            row = dict(row)
            row["新版草稿"] = ""
            row["配對方式"] = ""
            row["備註"] = "沒改"
        rows.append(row)
        seen_names.add(name)

    kept_names = sorted(manual_by_name)
    for name, row in manual_by_name.items():
        if name not in seen_names:
            rows.append(dict(row))

    # item2：手動列把「規章名」改指去別的舊版檔之後，原本那個規章名底下的舊檔
    # （現在沒有任何一列的「舊版」指到它）會整個從清單消失——它可能是另一份
    # 還沒改的規章，不該悄悄不見。合併完成後，舊版/ 底下沒被任何一列引用到的
    # 檔，補成一列獨立的「沒改」；規章名先用檔名（去副檔名），跟既有規章名
    # 衝突就加 (2)(3)… 直到不衝突為止。
    referenced_old = set()
    for row in rows:
        old_rel = row.get("舊版", "")
        if old_rel:
            referenced_old.add(_rel_key(old_rel))
    existing_names = set(row["規章名"] for row in rows)
    for filename in list_docx(p["舊版"]):
        if _rel_key(os.path.join("舊版", filename)) in referenced_old:
            continue
        stem = _stem(filename)
        name = stem
        n = 2
        while name in existing_names:
            name = "%s(%d)" % (stem, n)
            n += 1
        existing_names.add(name)
        rows.append({"規章名": name, "舊版": "舊版/%s" % filename, "新版草稿": "",
                    "發布根目錄": "", "配對方式": "", "備註": "沒改"})

    return rows, kept_names, sorted(dropped_names), sorted(draft_missing)


# ---------------------------------------------------------------------------
# 清單讀寫
# ---------------------------------------------------------------------------

def write_manifest(rows, path):
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=MANIFEST_COLUMNS, quoting=csv.QUOTE_ALL)
        w.writeheader()
        for row in rows:
            w.writerow(dict((c, row.get(c, "")) for c in MANIFEST_COLUMNS))
    return path


def read_manifest_rows(path):
    """讀規章清單.csv；六欄缺一就 WorkspaceError。METHODS 驗證只對非空值（沒改的
    本、多個候選的本，配對方式本來就留空，不當錯誤）。"""
    if not os.path.isfile(path):
        raise WorkspaceError("找不到規章清單：%s" % path)
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        missing = [c for c in MANIFEST_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise WorkspaceError("規章清單缺欄位：%s" % "、".join(missing))
        rows = list(reader)

    out = []
    for index, row in enumerate(rows, 2):
        item = dict((c, row.get(c) or "") for c in MANIFEST_COLUMNS)
        method = item["配對方式"]
        if method and method not in METHODS:
            raise WorkspaceError("第 %d 列配對方式不合法：%s" % (index, method))
        out.append(item)
    return out


# ---------------------------------------------------------------------------
# 過期檢查（規格第四節 2.）
# ---------------------------------------------------------------------------

def stale_reasons(rows, root):
    """清單裡的檔不存在、或 舊版/／新版/ 出現清單沒列的輸入檔（.docx／.txt／.md）
    → 回傳原因清單；
    空 list 代表沒過期。「手動」列跟其他列一樣只檢查檔案存在，不多做別的檢查。

    item9：舊版/、新版/ 的「多出清單沒列的檔」是拿檔名（basename）去跟 listed_old／
    listed_new 比對的——但手動列的「舊版」欄可以指到 舊版/ 以外的地方（例如
    規格包/<規章名>/<檔名>.docx），這種列的檔名不該算進 listed_old／listed_new，
    不然萬一 規格包 底下剛好有個同名檔，會把 舊版/ 真正沒被列到的同名檔給蓋過去、
    漏掉這個「多出清單沒列的檔」。所以只有路徑正規化後真的落在 舊版/（或 新版/）
    底下的列，才把它的檔名算進 listed 集合；不在底下的列（手動列常見）只檢查
    檔案本身存不存在，不影響「多出清單沒列的檔」的判斷。"""
    p = paths(root)
    reasons = []
    listed_old = set()
    listed_new = set()
    old_dir_norm = os.path.normcase(os.path.normpath(p["舊版"]))
    new_dir_norm = os.path.normcase(os.path.normpath(p["新版"]))

    def _in_dir(dir_norm, rel):
        full = os.path.normcase(os.path.normpath(os.path.join(p["匯入"], rel)))
        return os.path.dirname(full) == dir_norm

    for row in rows:
        name = row["規章名"]
        old_rel = row["舊版"]
        new_rel = row["新版草稿"]
        if old_rel:
            if _in_dir(old_dir_norm, old_rel):
                listed_old.add(os.path.basename(old_rel))
            if not os.path.isfile(os.path.join(p["匯入"], old_rel)):
                reasons.append("%s：舊版檔不存在（%s）" % (name, old_rel))
        if new_rel:
            if _in_dir(new_dir_norm, new_rel):
                listed_new.add(os.path.basename(new_rel))
            if not os.path.isfile(os.path.join(p["匯入"], new_rel)):
                reasons.append("%s：新版草稿不存在（%s）" % (name, new_rel))

    for f in sorted(set(list_docx(p["舊版"])) - listed_old):
        reasons.append("舊版/ 多出清單沒列的檔：%s" % f)
    for f in sorted(set(list_docx(p["新版"])) - listed_new):
        reasons.append("新版/ 多出清單沒列的檔：%s" % f)
    return reasons


# ---------------------------------------------------------------------------
# 歸檔（規格第四節 3.）
# ---------------------------------------------------------------------------

def history_root(base):
    """這一層的 歷次/ 在哪裡：<base>/系統檔案/歷次/。

    去向不是寫死在這裡的，是問 _common.home_of（FILE_HOMES 那張表登記了
    「歷次」→ 系統檔案）——改去向只改那一張表，這裡會跟著動。
    不建資料夾：_resolve_stamp 只是在找有沒有撞名，單純找路徑不該有副作用。
    """
    return os.path.join(base, home_of("歷次"), "歷次")


def _archive_plan(base, skip=()):
    """這一層有哪些東西要搬進 歷次/<stamp>/：[(來源絕對路徑, 目的地相對路徑), ...]。

    產出分三格之後，「上一輪的東西」不是一層平鋪的檔案，是 審閱文件／填寫表單／
    系統檔案 三個資料夾——所以整格搬，歷次/<stamp>/ 底下長得跟搬走之前一模一樣，
    人回頭翻上一輪時不用重新學一套排法。

    系統檔案 這一格例外：歷次/ 自己就住在裡面，整格搬會把歷次搬進自己。改成只搬
    它的內容（輸入/、異動清單.json…），歷次/ 留在原地，目的地照樣是
    歷次/<stamp>/系統檔案/<同名>。

    舊排法殘留在第一層的平鋪檔一樣收進來：不搬的話新舊兩輪會混在同一層，
    人分不出哪個檔是這一輪的。舊排法留在第一層的 歷次/ 則照舊不搬（搬了就是
    把上一輪的歸檔再歸檔一次）。
    """
    plan = []
    if not os.path.isdir(base):
        return plan
    skip = set(skip)
    system = SYSTEM_DIR
    for entry in sorted(os.listdir(base)):
        if entry in skip or entry == system or entry == "歷次":
            continue
        plan.append((os.path.join(base, entry), entry))
    system_dir = os.path.join(base, system)
    if os.path.isdir(system_dir):
        for entry in sorted(os.listdir(system_dir)):
            if entry == "歷次":
                continue
            plan.append((os.path.join(system_dir, entry), os.path.join(system, entry)))
    return plan


def _resolve_stamp(out_root, book_names, need_root, stamp):
    """回傳這次真正要用的時間戳：stamp 本身若會撞到既有的 歷次/<stamp>/（不管是
    某本的還是根層級的），依序試 stamp_2、stamp_3…直到所有這次真的要寫的目的地
    都還沒有人用過。只檢查這次真的要搬東西的本／根層級，避免「這次沒東西可搬」
    的呼叫被誤判成撞名（那樣會破壞冪等：見 archive_previous）。"""
    candidate = stamp
    n = 1
    while True:
        collision = need_root and os.path.isdir(os.path.join(history_root(out_root), candidate))
        if not collision:
            for name in book_names:
                if os.path.isdir(os.path.join(history_root(os.path.join(out_root, name)),
                                              candidate)):
                    collision = True
                    break
        if not collision:
            return candidate
        n += 1
        candidate = "%s_%d" % (stamp, n)


def archive_previous(root, names, stamp=None):
    """產出/<名>/ 已有東西就整包搬到 產出/<名>/系統檔案/歷次/<stamp>/；產出/ 根層級
    （除了各本子資料夾）搬到 產出/系統檔案/歷次/<stamp>/。回傳搬過的目的地。

    搬的單位是三格資料夾（見 _archive_plan）：審閱文件／填寫表單 整格搬，
    系統檔案 只搬內容（歷次/ 住在那一格裡，整格搬會搬進自己）。搬完那一格只剩
    歷次/。冪等：歷次/ 永遠被排除在「要搬的東西」之外；上一輪東西都搬光後再呼叫
    一次，兩層都沒有東西可搬，回傳 []（不做撞名檢查，不然會誤判出一個沒東西可搬
    的 stamp_2）。

    撞名（同一分鐘內兩次歸檔、或呼叫端自己重複用了同一個 stamp）：若這次真的要
    寫的 歷次/<stamp>/ 已經存在，整次呼叫改用 stamp_2、stamp_3…（本與根層級共用
    同一個解出來的時間戳），不覆蓋、不搬進既有的那份裡。

    item4：某個目的地檔案卡在 Excel 裡（Windows 鎖檔）時，shutil.move 會噴
    OSError。不接住的話會是一整條 traceback，使用者看不懂要做什麼。這裡接住、
    改丟 WorkspaceError，訊息附上「已經搬了幾處」——已經搬完的那幾處（moved
    這個 list 目前的長度）是真的搬走了，不是全部作廢；呼叫端（cmd_start／
    cmd_batch）印「[中止]」後 return 1，人關掉 Excel 再重跑即可，不用擔心
    重複搬（歸檔本身冪等，見上）。"""
    stamp = stamp or datetime.datetime.now().strftime("%Y%m%d_%H%M")
    p = paths(root)
    out_root = p["產出"]
    moved = []
    if not os.path.isdir(out_root):
        return moved

    name_set = set(names or [])
    book_plans = {}
    for name in names or []:
        plan = _archive_plan(os.path.join(out_root, name))
        if plan:
            book_plans[name] = plan

    root_plan = _archive_plan(out_root, skip=name_set)

    if not book_plans and not root_plan:
        return moved

    stamp = _resolve_stamp(out_root, list(book_plans.keys()), bool(root_plan), stamp)

    def move_plan(base, plan):
        dest = os.path.join(history_root(base), stamp)
        os.makedirs(dest, exist_ok=True)
        for src, rel in plan:
            target = os.path.join(dest, rel)
            try:
                # rel 可能是「系統檔案/輸入」這種兩層的相對路徑（系統檔案 那一格是
                # 搬內容不是搬整格），目的地那一層要先建出來 shutil.move 才收得下。
                parent = os.path.dirname(target)
                if parent and not os.path.isdir(parent):
                    os.makedirs(parent, exist_ok=True)
                shutil.move(src, target)
            except OSError as exc:
                raise WorkspaceError(
                    "歸檔失敗：%s（可能有檔案開在 Excel）；已搬 %d 處到 %s，關掉檔案後重跑"
                    % (exc, len(moved), dest))
        moved.append(dest)

    for name, plan in book_plans.items():
        move_plan(os.path.join(out_root, name), plan)

    if root_plan:
        move_plan(out_root, root_plan)
    return moved


# ---------------------------------------------------------------------------
# 摘要與畫面輸出
# ---------------------------------------------------------------------------

def summarize(rows, skipped=0):
    """「配對 N 本：檔名相同 a、去版本字 b、未配對 c、多個候選 e；沒改的本 d」。

    「多個候選」桶：備註以「多個候選」開頭的列（match() 對到多個候選時，配對方式
    留空、備註寫「多個候選：…」，不落在 counts 的任何一個配對方式桶）。

    skipped 非 0 時尾巴再加「；略過不支援的檔 N 個」——略過幾個檔不能只出現在
    上面那一則提醒裡，摘要這一行常常是唯一被複製貼走的一行（no 14）。"""
    counts = dict((m, 0) for m in ("檔名相同", "去版本字", "未配對"))
    no_change = 0
    multiple = 0
    for row in rows:
        method = row.get("配對方式", "")
        if method in counts:
            counts[method] += 1
        note = row.get("備註", "")
        if note == "沒改":
            no_change += 1
        elif note.startswith("多個候選"):
            multiple += 1
    text = ("配對 %d 本：檔名相同 %d、去版本字 %d、未配對 %d、多個候選 %d；沒改的本 %d"
            % (len(rows), counts["檔名相同"], counts["去版本字"], counts["未配對"],
               multiple, no_change))
    if skipped:
        text += "；略過不支援的檔 %d 個" % skipped
    return text


def print_table(rows):
    """畫面印一張表（規章名｜舊版檔｜新版檔｜規格包｜配對方式）。"""
    header = ("規章名", "舊版檔", "新版檔", "規格包", "配對方式")
    print("｜".join(header))
    for row in rows:
        old_file = os.path.basename(row["舊版"]) if row["舊版"] else "（無）"
        new_file = os.path.basename(row["新版草稿"]) if row["新版草稿"] else "（無）"
        release = "有" if row["發布根目錄"] else "無"
        method = row["配對方式"] or ("備註：%s" % row["備註"] if row["備註"] else "（未定）")
        print("｜".join((row["規章名"], old_file, new_file, release, method)))
