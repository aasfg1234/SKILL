# -*- coding: utf-8 -*-
r"""
S6 沿用：產生複核表，但沒改的條文直接預填上一版的人工決定

用法：
    py S6_沿用決定.py <資料夾> <舊發布根目錄> [輸出檔]

輸入：<資料夾>\05_flagged.csv
      <舊發布根目錄>\LATEST.json → 版本目錄\06_final.csv、06_deleted.csv
輸出：<資料夾>\06_複核表.csv        （欄位＝原複核表 ＋ 沿用自、沿用狀態）
      <資料夾>\06_沿用報告.txt
      <資料夾>\06_複核表_怎麼填.txt

規則：
    全文（去空白）在舊版唯一命中、旗標相同      → 預填舊決定，狀態「沿用」
    唯一命中、旗標不同                          → 預填舊決定，狀態「旗標有變，請再看一眼」
    無命中或多筆命中                            → 空白，狀態「要人看」
    舊決定是「併入上一筆」但上一筆對不上         → 空白，狀態「要人看（上一筆不同）」

預填的決定寫兩行：第一行決定字，第二行「沿用自 舊ID」。
S6_套用決定.py 只看第一行，第二行會存進「決定備註」。人可以改掉預填值。
這支不改 S6_套用決定.py 的任何規則：每一筆需人工看的仍必須有明確決定。
"""

import collections
import csv
import hashlib
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from S6_產生複核表 import OUT_COLS, HOWTO   # noqa: E402

COLS = OUT_COLS + ["沿用自", "沿用狀態"]
lines = []


def say(text=""):
    lines.append(text)


def normalize(text):
    return re.sub(r"\s+", "", text or "")


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path):
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def load_old(release_root):
    """從 LATEST.json 找版本目錄，核對兩份檔的 SHA，讀出舊決定。回傳依原順序排列的列。"""
    latest_path = os.path.join(release_root, "LATEST.json")
    if not os.path.isfile(latest_path):
        raise ValueError("找不到 %s；只接受 S12 發布根目錄" % latest_path)
    with io.open(latest_path, encoding="utf-8-sig") as f:
        latest = json.load(f)
    version_dir = os.path.join(release_root, latest.get("相對路徑", ""))
    manifest_path = os.path.join(version_dir, "manifest.json")
    if not os.path.isfile(manifest_path):
        raise ValueError("正式版本缺少 manifest.json：%s" % version_dir)
    with io.open(manifest_path, encoding="utf-8-sig") as f:
        manifest = json.load(f)
    expected = {e.get("路徑"): e.get("SHA256") for e in manifest.get("發布檔案", [])}
    rows = []
    for name in ("06_final.csv", "06_deleted.csv"):
        path = os.path.join(version_dir, name)
        if not os.path.isfile(path):
            raise ValueError("正式版本缺少 %s" % name)
        if expected.get(name) != file_sha256(path):
            raise ValueError("%s 的 SHA-256 與 manifest 不符，舊發布檔被改過，不能沿用" % name)
        for row in read_csv(path):
            row["_來源檔"] = name
            rows.append(row)
    rows.sort(key=lambda r: r["條文ID"])
    return rows


def inherit(new_rows, old_rows):
    """回傳 [(新列, 決定, 沿用自, 狀態)]，只含需人工看=Y 的列。"""
    by_text = collections.defaultdict(list)
    for row in old_rows:
        by_text[normalize(row.get("全文"))].append(row)
    old_prev = {}
    for index, row in enumerate(old_rows):
        old_prev[row["條文ID"]] = normalize(old_rows[index - 1].get("全文")) if index else None

    result = []
    for index, row in enumerate(new_rows):
        if row.get("需人工看") != "Y":
            continue
        matches = by_text.get(normalize(row.get("全文")), [])
        if len(matches) != 1:
            result.append((row, "", "", "要人看" if not matches else "要人看（舊版有多筆同文）"))
            continue
        old = matches[0]
        decision = (old.get("人工決定") or "").strip()
        if decision not in ("保留", "刪除", "併入上一筆", "待改"):
            result.append((row, "", old["條文ID"], "要人看（舊決定無法辨識）"))
            continue
        if decision == "併入上一筆":
            prev_new = normalize(new_rows[index - 1].get("全文")) if index else None
            if prev_new is None or prev_new != old_prev.get(old["條文ID"]):
                result.append((row, "", old["條文ID"], "要人看（上一筆不同）"))
                continue
        status = "沿用" if (old.get("旗標") or "") == (row.get("旗標") or "") else "旗標有變，請再看一眼"
        result.append((row, decision, old["條文ID"], status))
    return result


def main(folder, release_root, out_path):
    src = os.path.join(folder, "05_flagged.csv")
    if not os.path.isfile(src):
        say("找不到 " + src)
        return False
    try:
        old_rows = load_old(release_root)
    except ValueError as exc:
        say("[中止] %s" % exc)
        return False
    new_rows = read_csv(src)
    decided = inherit(new_rows, old_rows)

    order = {"空白": 0, "過短": 1, "符號跳號": 2, "完全重複": 3, "開頭相同": 4, "含表格圖形": 5}

    def key(item):
        row, decision, _, status = item
        flags = [f for f in (row.get("旗標") or "").split(";") if f]
        return (0 if not decision else 1, min([order.get(f, 9) for f in flags] or [9]), row["條文ID"])

    decided.sort(key=key)
    with io.open(out_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS, quoting=csv.QUOTE_ALL)
        w.writeheader()
        for row, decision, source_id, status in decided:
            w.writerow({
                "決定": (decision + "\n沿用自 " + source_id) if decision else "",
                "條文ID": row["條文ID"], "旗標": row.get("旗標", ""),
                "系統建議": row.get("建議動作", ""), "字數": row.get("字數", ""),
                "章標題": row.get("章標題", ""), "節標題": row.get("節標題", ""),
                "符號原文": row.get("符號原文", ""), "全文": row.get("全文", ""),
                "重複組": row.get("重複組", ""), "附屬於": row.get("附屬於", ""),
                "含表格標記": row.get("含表格標記", ""),
                "起始序號": row.get("起始序號", ""), "結束序號": row.get("結束序號", ""),
                "附件全文": (row.get("附件全文") or "")[:300],
                "沿用自": source_id, "沿用狀態": status,
            })
    with io.open(os.path.join(folder, "06_複核表_怎麼填.txt"), "w", encoding="utf-8-sig") as f:
        f.write(HOWTO)
        f.write("\n九、這張表有「沿用自」「沿用狀態」兩欄：狀態「沿用」的已預填上一版決定，\n"
                "    看過覺得對就不用動；「要人看」的一定要填；「旗標有變」的請再看一眼。\n")

    tally = collections.Counter()
    for _, decision, _, status in decided:
        tally["沿用" if status == "沿用" else ("旗標有變" if status.startswith("旗標有變") else "要人看")] += 1
    say("=" * 62)
    say("S6 沿用報告")
    say("舊版：%s" % release_root)
    say("=" * 62)
    say("全部條文 %d 筆，需人工看 %d 筆" % (len(new_rows), len(decided)))
    say("  沿用 %d 筆（已預填，可不動）" % tally["沿用"])
    say("  旗標有變 %d 筆（已預填，請再看一眼）" % tally["旗標有變"])
    say("  要人看 %d 筆（空白，一定要填）" % tally["要人看"])
    say("複核表：%s" % out_path)
    return True


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法：py S6_沿用決定.py <資料夾> <舊發布根目錄> [輸出檔]")
        sys.exit(1)
    folder, release_root = sys.argv[1], sys.argv[2]
    out = sys.argv[3] if len(sys.argv) > 3 else os.path.join(folder, "06_複核表.csv")
    ok = main(folder, release_root, out)
    report = "\n".join(lines)
    with io.open(os.path.join(folder, "06_沿用報告.txt"), "w", encoding="utf-8-sig") as f:
        f.write(report + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    print(report, flush=True)
    sys.exit(0 if ok else 1)
