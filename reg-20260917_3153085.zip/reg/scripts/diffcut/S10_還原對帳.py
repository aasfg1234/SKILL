# -*- coding: utf-8 -*-
r"""
S10：把切好的條文組回一份 Word

用法：
    py S10_還原對帳.py <資料夾> [原始txt]

輸入：<資料夾>\06_final.csv       （沒有就退而用 05_flagged.csv）
      <資料夾>\tables\Tnnn.md
      <資料夾>\02_shapes.csv
輸出：<資料夾>\10_還原.docx
      <資料夾>\10_還原.txt        （純文字，拿來逐字比對用）
      <資料夾>\S10_還原報告.txt

===========================================================
先講清楚這支程式的定位
===========================================================
**這是檢查工具，不是交件用的。**

真的要改內規，做法是「改原檔、開追蹤修訂」，不是把切碎的組回去。
組回去一定會出事：格式全掉、表格會歪、流程圖不見、
沒改到的地方也被重打一次。法遵文件不能這樣交。

那還原有什麼用？
    把切出來的東西組回純文字，跟原始 txt 逐字比對。
    比對得上，就證明前面 S1 到 S6 沒有漏字、沒有改字。
    這是整套的最後一道保險。

===========================================================
還原不了的東西（先列清楚）
===========================================================
    字型、字級、粗體、顏色      完全沒存
    縮排、行距、對齊、分頁      完全沒存
    表格的欄列結構            被壓平，不可逆
    流程圖的方塊與箭頭         只剩「【流程圖】」四個字
    頁首頁尾、頁碼            沒有
    目錄                    故意不還原（原檔的目錄是自動產生的）
"""

import csv
import datetime
import hashlib
import io
import json
import os
import re
import sys

# 原始 txt 的目錄區行號。換一份文件就不一樣，執行時給：
#     py S10_還原對帳.py <資料夾> <原始txt> --toc 19-58
# 不給的話，找不到的行只會列出來，不會分類。
TOC_FROM, TOC_TO = None, None

lines = []


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def write_proof(folder, txt_path):
    required_inputs = ("01_paragraphs.csv", "05_flagged.csv",
                       "06_final.csv", "06_deleted.csv")
    required_outputs = ("10_還原.txt", "S10_還原報告.txt")
    proof = {
        "格式版本": 1,
        "產生時間": datetime.datetime.now().astimezone().isoformat(),
        "逐字對帳通過": True,
        "輸入": {},
        "輸出": {},
    }
    for name in required_inputs:
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            raise ValueError("S10 證明缺少輸入：%s" % name)
        proof["輸入"][name] = {"SHA256": file_sha256(path),
                                  "位元組": os.path.getsize(path)}
    if txt_path and os.path.isfile(txt_path):
        proof["原始文字檔"] = {
            "檔名": os.path.basename(txt_path), "SHA256": file_sha256(txt_path),
            "位元組": os.path.getsize(txt_path),
        }
    for name in required_outputs:
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            raise ValueError("S10 證明缺少輸出：%s" % name)
        proof["輸出"][name] = {"SHA256": file_sha256(path),
                                  "位元組": os.path.getsize(path)}
    path = os.path.join(folder, "S10_對帳證明.json")
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump(proof, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return path


def say(s=""):
    lines.append(s)


def load(folder, name):
    p = os.path.join(folder, name)
    if not os.path.isfile(p):
        return None
    with io.open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def load_table(folder, tid):
    """讀 Tnnn.md，回傳一格一列的清單。"""
    p = os.path.join(folder, "tables", "T%s.md" % tid)
    if not os.path.isfile(p):
        return []
    cells = []
    with io.open(p, encoding="utf-8-sig") as f:
        for ln in f:
            ln = ln.rstrip("\n")
            if ln.startswith("- "):
                cells.append(ln[2:].strip())
            elif ln.startswith("|") and set(ln) - set("|- "):
                for c in ln.strip("|").split("|"):
                    if c.strip():
                        cells.append(c.strip())
    return cells


def norm(s):
    """比對用：把空白與全形空白拿掉。"""
    return re.sub(r"[\s　]+", "", s or "")


def main(folder, txt_path):
    rows = load(folder, "06_final.csv") or load(folder, "05_flagged.csv")
    if not rows:
        say("找不到 06_final.csv 或 05_flagged.csv")
        return False

    ok = True
    shapes = {}
    for r in (load(folder, "02_shapes.csv") or []):
        shapes.setdefault(r["圖形編號"], []).append(r["文字"])

    say("=" * 64)
    say("S10 還原報告")
    say("資料夾：" + folder)
    say("=" * 64)
    say()
    say("條文 %d 筆" % len(rows))

    # ---------- 組 Word ----------
    from docx import Document
    from docx.shared import Pt

    doc = Document()
    doc.core_properties.title = "還原稿（檢查用，不可交件）"

    p = doc.add_paragraph()
    run = p.add_run("【本檔為還原稿，只供比對檢查，不可作為正式內規】")
    run.bold = True
    run.font.size = Pt(12)

    plain = []          # 純文字，拿來逐字比對
    n_tbl = n_shp = 0

    for r in rows:
        text = r["全文"]
        kind = r["符號類型"]
        cid = r["條文ID"]

        if not text.strip():
            continue

        # 表格
        if kind == "表格":
            tid = r["含表格標記"].split(";")[0] if r["含表格標記"] else ""
            cells = load_table(folder, tid) if tid else []
            doc.add_paragraph("［表 T%s］（原表格欄列結構已在轉檔時遺失，"
                              "以下一列等於原本一格）" % tid)
            if cells:
                t = doc.add_table(rows=len(cells), cols=1)
                t.style = "Table Grid"
                for i, c in enumerate(cells):
                    t.cell(i, 0).text = c
            n_tbl += 1
            plain.append(text)
            continue

        # 流程圖
        if kind == "圖形":
            sid = r["含圖形標記"].split(";")[0] if r["含圖形標記"] else ""
            doc.add_paragraph("［流程圖 S%s］%s"
                              % (sid, "／".join(shapes.get(sid, []))))
            n_shp += 1
            plain.append(text)
            continue

        # 章、節標題
        if cid.endswith("-000") and r["節序號"] == "000":
            doc.add_heading(text, level=1)
        elif cid.endswith("-000"):
            doc.add_heading(text, level=2)
        else:
            doc.add_paragraph(text)
        plain.append(text)

    out_docx = os.path.join(folder, "10_還原.docx")
    doc.save(out_docx)

    body = "\n".join(plain)
    with io.open(os.path.join(folder, "10_還原.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(body)

    say("   還原段落 %d 段（含表格 %d 張、流程圖 %d 張）"
        % (len(plain), n_tbl, n_shp))

    # ---------- 檢查一：跟切條前的段落檔逐字比對 ----------
    say()
    say("1. 跟 01_paragraphs.csv 逐字比對")
    para = load(folder, "01_paragraphs.csv")
    if not para:
        say("   [不合格] 找不到 01_paragraphs.csv")
        ok = False
    else:
        KEEP = ("章", "節", "內文", "表格標記", "圖形標記")
        src = "".join(x["全文"] for x in para if x["類型"] in KEEP)
        got = "".join(plain)
        say("   切條前 %d 字，還原後 %d 字" % (len(src), len(got)))

        # 用 S5 的原始順序重建「只排除真正刪除」後應有的全文。
        # 併入上一筆的文字仍在 06_final.csv 裡，不能再當刪除字數加一次。
        base = load(folder, "05_flagged.csv") or []
        gone = load(folder, "06_deleted.csv") or []
        deleted_ids = set(
            x["條文ID"] for x in gone if x.get("人工決定") == "刪除"
        )
        expected = src
        if base:
            base_text = "".join(x["全文"] for x in base)
            if base_text != src:
                say("   [不合格] 05_flagged.csv 已經跟 01_paragraphs.csv 不一致")
                ok = False
            expected = "".join(
                x["全文"] for x in base if x["條文ID"] not in deleted_ids
            )

        if got == expected:
            if deleted_ids:
                nchar = sum(
                    len(x["全文"]) for x in base if x["條文ID"] in deleted_ids
                )
                say("   [過] 一字不差；另排除 S6 真正刪除的 %d 筆（%d 字）"
                    % (len(deleted_ids), nchar))
            else:
                say("   [過] 一字不差")
        else:
            at = next((i for i in range(min(len(expected), len(got)))
                       if expected[i] != got[i]), min(len(expected), len(got)))
            say("   [不合格] 第一個不一致在第 %d 個字元" % (at + 1))
            say("      應：" + expected[max(0, at - 40):at + 40])
            say("      還：" + got[max(0, at - 40):at + 40])
            ok = False

    # ---------- 檢查二：跟原始 txt 比對 ----------
    say()
    say("2. 跟原始 %s 比對" % os.path.basename(txt_path or ""))
    if not txt_path or not os.path.isfile(txt_path):
        say("   沒有給原始 txt，跳過")
    else:
        raw = io.open(txt_path, encoding="utf-8-sig").read()
        a = norm(raw)
        cells_all = []
        for r in rows:
            if r["符號類型"] == "表格" and r["含表格標記"]:
                cells_all += load_table(folder, r["含表格標記"].split(";")[0])
        b = norm("".join(plain) + "".join(cells_all))
        say("   原始 txt %d 字（去空白後）" % len(a))
        say("   還原稿   %d 字（條文 ＋ 表格內容）" % len(b))
        say("   還原覆蓋率：%.1f%%" % (100.0 * len(b) / max(len(a), 1)))

        # 逐行點名：原始 txt 哪幾行在還原稿裡找不到
        miss = []
        for k, ln in enumerate(raw.split(chr(10))):
            t = norm(ln)
            if t and t not in b:
                miss.append((k, ln.strip()))
        say("   逐行點名：找不到的 %d 行，共 %d 字"
            % (len(miss), sum(len(norm(x[1])) for x in miss)))
        if TOC_FROM is None:
            toc, other = [], miss
            say("      沒指定目錄區行號，以下全部列出來給你看：")
        else:
            toc = [x for x in miss if TOC_FROM <= x[0] <= TOC_TO]
            other = [x for x in miss if not (TOC_FROM <= x[0] <= TOC_TO)]
            say("      其中目錄區（第 %d 到 %d 行）：%d 行 <- 故意不還原"
                % (TOC_FROM, TOC_TO, len(toc)))
        if other:
            say("      [不合格] 目錄以外還缺 %d 行：" % len(other))
            for k, ln in other[:15]:
                say("         行%d  %s" % (k, ln[:60]))
            ok = False
        else:
            say("      [過] 目錄以外一行都沒缺")

    say()
    say("3. 還原不了的東西（不是程式漏做，是資料本來就沒有）")
    say("   字型、字級、粗體、顏色、縮排、行距、分頁：完全沒存")
    say("   表格欄列結構：轉檔時已壓平，不可逆")
    say("   流程圖方塊與箭頭：只剩文字")
    say("   頁首頁尾、頁碼、自動目錄：沒有")

    say()
    say("4. 這份檔怎麼用")
    say("   拿來核對「字有沒有掉」可以。")
    say("   拿來當正式內規不行。要改內規請走 reg-diff 的改原檔流程：改原檔、開追蹤修訂。")

    say()
    say("   產出：%s" % out_docx)
    return ok


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S10_還原對帳.py <資料夾> [原始txt] [--toc 19-58]")
        sys.exit(1)
    folder = sys.argv[1]
    old_proof = os.path.join(folder, "S10_對帳證明.json")
    if os.path.isfile(old_proof):
        os.remove(old_proof)
    txt = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith("--") else ""
    for i, a in enumerate(sys.argv):
        if a == "--toc" and i + 1 < len(sys.argv) and "-" in sys.argv[i + 1]:
            lo, hi = sys.argv[i + 1].split("-", 1)
            TOC_FROM, TOC_TO = int(lo), int(hi)
    ok = main(folder, txt)
    report = "\n".join(lines)
    with io.open(os.path.join(folder, "S10_還原報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")
    if ok:
        try:
            proof_path = write_proof(folder, txt)
            report += "\n完整對帳證明：%s" % proof_path
        except Exception as exc:
            ok = False
            report += "\n[不合格] 無法產生 S10 對帳證明：%s" % exc
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if ok else 1)
