# -*- coding: utf-8 -*-
r"""
S12：產生唯一、不可覆寫的正式發布版本

用法：
    py S12_發布版本.py <資料夾> <發布根目錄> --version <版本號> \
       --source <原始docx或txt> --name <規章名> [--org <機構>] [--ver <版本日>]

發布前硬性檢查：
1. S6 有完整複核證明，且證明中的輸入、輸出 SHA-256 與目前檔案一致。
2. S10 逐字對帳通過，且 S10 證明綁定的 canonical 段落與輸出都未變。
3. 06_final、09_規章總表、09_impact 的條文 ID 完全一致。
4. S9 兩份主表各有 51 個唯一欄名。
5. 正式版包含 S1 的 01_paragraphs.csv，供 reg-diff 對齊不同解析器的段次。

每個版本只建立一次，既有版本不可覆寫。發布成功後只用
<發布根目錄>/LATEST.json 指到目前正式版，不再人工複製根目錄交付檔。
"""

import argparse
import csv
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import uuid


MAIN_FILES = (
    "01_paragraphs.csv",
    "06_final.csv",
    "06_deleted.csv",
    "07_relations.csv",
    "08_citations.csv",
    "09_規章總表.csv",
    "09_impact.csv",
    "09_impact_明細.csv",
    "S6_套用報告.txt",
    "S6_複核證明.json",
    "10_還原.txt",
    "S10_還原報告.txt",
    "S10_對帳證明.json",
)


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def read_csv(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fields = reader.fieldnames or []
        return fields, list(reader)


def require_file(folder, name):
    path = os.path.join(folder, name)
    if not os.path.isfile(path):
        raise ValueError("找不到必要檔案：%s" % path)
    return path


def validate_version(version):
    if not version or version in (".", ".."):
        raise ValueError("版本號不可空白")
    if not re.match(r"^[0-9A-Za-z._-]+$", version):
        raise ValueError("版本號只能使用英數字、點、底線與連字號")
    return version


def unique_ids(rows, label):
    ids = [r.get("條文ID", "") for r in rows]
    if any(not x for x in ids):
        raise ValueError("%s 有空白條文ID" % label)
    if len(ids) != len(set(ids)):
        raise ValueError("%s 有重複條文ID" % label)
    return set(ids)


def validate_s6(folder):
    proof_path = require_file(folder, "S6_複核證明.json")
    with open(proof_path, "r", encoding="utf-8") as f:
        proof = json.load(f)

    review = proof.get("完整複核", {})
    if review.get("未複核筆數") != 0:
        raise ValueError("S6 複核證明顯示仍有未複核項目")
    if review.get("應複核筆數") != review.get("已明確決定筆數"):
        raise ValueError("S6 應複核筆數與已決定筆數不一致")

    base_path = require_file(folder, "05_flagged.csv")
    if proof.get("底本", {}).get("SHA256") != file_sha256(base_path):
        raise ValueError("05_flagged.csv 已在 S6 完成後變更，複核證明失效")

    _, base_rows = read_csv(base_path)
    required = {r.get("條文ID", ""): r for r in base_rows
                if r.get("需人工看") == "Y"}
    details = proof.get("逐筆複核")
    if not isinstance(details, list):
        raise ValueError("S6 複核證明缺少逐筆複核明細")
    detail_ids = [r.get("條文ID", "") for r in details]
    if len(detail_ids) != len(set(detail_ids)) or set(detail_ids) != set(required):
        raise ValueError("S6 逐筆複核明細未完整涵蓋目前待複核條文")
    allowed = {"保留", "刪除", "併入上一筆", "待改"}
    for detail in details:
        item_id = detail["條文ID"]
        base = required[item_id]
        text_hash = hashlib.sha256(base.get("全文", "").encode("utf-8")).hexdigest()
        if detail.get("決定") not in allowed:
            raise ValueError("S6 逐筆複核決定無效：%s" % item_id)
        if detail.get("旗標", "") != base.get("旗標", ""):
            raise ValueError("S6 逐筆複核旗標不符：%s" % item_id)
        if detail.get("全文SHA256") != text_hash:
            raise ValueError("S6 逐筆複核全文不符：%s" % item_id)

    for name in ("06_final.csv", "06_deleted.csv"):
        path = require_file(folder, name)
        expected = proof.get("輸出", {}).get(name, {}).get("SHA256")
        if not expected or expected != file_sha256(path):
            raise ValueError("%s 與 S6 複核證明不一致" % name)
    return proof


def validate_s10(folder):
    path = require_file(folder, "S10_還原報告.txt")
    with open(path, "r", encoding="utf-8-sig") as f:
        report = f.read()
    if "[過] 一字不差" not in report or "[不合格]" in report:
        raise ValueError("S10 尚未通過逐字對帳")
    proof_path = require_file(folder, "S10_對帳證明.json")
    with open(proof_path, "r", encoding="utf-8-sig") as f:
        proof = json.load(f)
    if proof.get("格式版本") != 1 or proof.get("逐字對帳通過") is not True:
        raise ValueError("S10 對帳證明格式無效或未通過")
    required_groups = {
        "輸入": {"01_paragraphs.csv", "05_flagged.csv", "06_final.csv", "06_deleted.csv"},
        "輸出": {"10_還原.txt", "S10_還原報告.txt"},
    }
    for group in ("輸入", "輸出"):
        entries = proof.get(group)
        if not isinstance(entries, dict) or not entries:
            raise ValueError("S10 對帳證明缺少%s雜湊" % group)
        missing = required_groups[group] - set(entries)
        if missing:
            raise ValueError("S10 對帳證明缺少%s：%s"
                             % (group, "、".join(sorted(missing))))
        for name, info in entries.items():
            current = require_file(folder, name)
            if info.get("SHA256") != file_sha256(current):
                raise ValueError("%s 已在 S10 通過後變更，對帳證明失效" % name)
    return path


def validate_tables(folder):
    final_fields, final_rows = read_csv(require_file(folder, "06_final.csv"))
    master_fields, master_rows = read_csv(require_file(folder, "09_規章總表.csv"))
    impact_fields, impact_rows = read_csv(require_file(folder, "09_impact.csv"))

    for label, fields in (("09_規章總表.csv", master_fields),
                          ("09_impact.csv", impact_fields)):
        if len(fields) != 51:
            raise ValueError("%s 應為 51 欄，實際 %d 欄" % (label, len(fields)))
        if len(set(fields)) != len(fields):
            raise ValueError("%s 有重複欄名，禁止發布" % label)

    final_ids = unique_ids(final_rows, "06_final.csv")
    master_ids = unique_ids(master_rows, "09_規章總表.csv")
    impact_ids = unique_ids(impact_rows, "09_impact.csv")
    if final_ids != master_ids or final_ids != impact_ids:
        raise ValueError("06_final、09_規章總表、09_impact 的條文ID不一致")

    # 不能只核對 ID：否則 S10 通過後，S9 內容被改字仍可能混進正式版。
    # impact 與總表是同一份資料的不同排序，51 欄必須逐列完全相同。
    master_by_id = {r["條文ID"]: r for r in master_rows}
    impact_by_id = {r["條文ID"]: r for r in impact_rows}
    for article_id in sorted(master_ids):
        if master_by_id[article_id] != impact_by_id[article_id]:
            raise ValueError("09_規章總表與09_impact內容不一致：%s" % article_id)

    # S9 新增分析欄，但從 S6 底本帶來的核心欄不得被改寫。
    final_by_id = {r["條文ID"]: r for r in final_rows}
    common_fields = [x for x in final_fields if x in master_fields]
    required_core = ("條文ID", "全文", "章序號", "章標題", "節序號", "節標題",
                     "符號原文", "起始序號", "結束序號")
    missing_core = [x for x in required_core if x not in common_fields]
    if missing_core:
        raise ValueError("S6/S9 缺少共同核心欄：%s" % "、".join(missing_core))
    for article_id in sorted(final_ids):
        left = final_by_id[article_id]
        right = master_by_id[article_id]
        for field in common_fields:
            if left.get(field, "") != right.get(field, ""):
                raise ValueError(
                    "06_final與09_規章總表內容不一致：%s／%s" % (article_id, field))

    return {
        "條文筆數": len(final_rows),
        "規章總表欄數": len(master_fields),
        "規章總表唯一欄名": len(set(master_fields)),
        "風險清單欄數": len(impact_fields),
        "風險清單唯一欄名": len(set(impact_fields)),
    }


def git_commit():
    here = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.dirname(os.path.dirname(here))
    try:
        result = subprocess.run(
            ["git", "-C", repo, "rev-parse", "HEAD"],
            capture_output=True, text=True, encoding="utf-8", errors="replace")
        if result.returncode == 0:
            return result.stdout.strip()
    except OSError:
        pass
    return ""


def build_spec_pack(folder, out_dir, name, org, version_date):
    here = os.path.dirname(os.path.abspath(__file__))
    script = os.path.join(here, "S11_規格包.py")
    command = [sys.executable, script, folder, out_dir, "--name", name]
    if org:
        command += ["--org", org]
    if version_date:
        command += ["--ver", version_date]
    result = subprocess.run(command, capture_output=True, text=True,
                            encoding="utf-8", errors="replace")
    report_path = os.path.join(os.path.dirname(out_dir), "S11_規格包報告.txt")
    with open(report_path, "w", encoding="utf-8-sig") as f:
        f.write(result.stdout or "")
        if result.stderr:
            f.write("\n--- stderr ---\n" + result.stderr)
    if result.returncode != 0:
        raise ValueError("S11 規格包產生失敗，詳見 %s" % report_path)
    required = ("規格.json", "條文.csv", "重複組.csv", "引用.csv", "連帶.csv",
                "synonyms_建議.json", "README.md")
    missing = [name for name in required
               if not os.path.isfile(os.path.join(out_dir, name))]
    if missing:
        raise ValueError("S11 規格包缺少必要檔案：%s" % "、".join(missing))
    try:
        with open(os.path.join(out_dir, "規格.json"), "r", encoding="utf-8-sig") as f:
            spec = json.load(f)
    except (OSError, ValueError) as exc:
        raise ValueError("S11 規格.json 無法讀取：%s" % exc)
    if spec.get("格式版本") != 1:
        raise ValueError("S11 規格包格式版本不支援：%r" % spec.get("格式版本"))


def artifact_manifest(root):
    result = []
    for dirpath, _, files in os.walk(root):
        for name in sorted(files):
            if name == "manifest.json":
                continue
            path = os.path.join(dirpath, name)
            rel = os.path.relpath(path, root).replace(os.sep, "/")
            result.append({
                "路徑": rel,
                "位元組": os.path.getsize(path),
                "SHA256": file_sha256(path),
            })
    return sorted(result, key=lambda x: x["路徑"])


def publish(args):
    folder = os.path.abspath(args.folder)
    release_root = os.path.abspath(args.release_root)
    source = os.path.abspath(args.source)
    version = validate_version(args.version)

    if not os.path.isdir(folder):
        raise ValueError("資料夾不存在：%s" % folder)
    if not os.path.isfile(source):
        raise ValueError("來源檔不存在：%s" % source)

    s6_proof = validate_s6(folder)
    validate_s10(folder)
    stats = validate_tables(folder)
    for name in MAIN_FILES:
        require_file(folder, name)

    os.makedirs(release_root, exist_ok=True)
    final_dir = os.path.join(release_root, version)
    if os.path.exists(final_dir):
        raise ValueError("版本已存在，正式版不可覆寫：%s" % final_dir)

    staging = os.path.join(release_root, ".staging-%s" % uuid.uuid4().hex)
    os.makedirs(staging)
    try:
        for name in MAIN_FILES:
            shutil.copy2(os.path.join(folder, name), os.path.join(staging, name))

        build_spec_pack(folder, os.path.join(staging, "規格包"),
                        args.name, args.org, args.version_date)

        manifest = {
            "格式版本": 1,
            "正式版本": version,
            "產生時間": datetime.datetime.now().astimezone().isoformat(),
            "GitCommit": git_commit(),
            "來源": {
                "檔名": os.path.basename(source),
                "位元組": os.path.getsize(source),
                "SHA256": file_sha256(source),
            },
            "規章": {
                "名稱": args.name,
                "機構": args.org,
                "版本日": args.version_date,
            },
            "驗證": {
                "S6完整複核": True,
                "S6應複核筆數": s6_proof["完整複核"]["應複核筆數"],
                "S10逐字對帳": True,
                **stats,
            },
            "來源資料SHA256": {
                name: file_sha256(os.path.join(folder, name)) for name in MAIN_FILES
            },
        }
        manifest["發布檔案"] = artifact_manifest(staging)
        manifest_path = os.path.join(staging, "manifest.json")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
            f.write("\n")

        manifest_hash = file_sha256(manifest_path)
        os.replace(staging, final_dir)

        latest = {
            "正式版本": version,
            "相對路徑": version,
            "manifest_SHA256": manifest_hash,
            "更新時間": datetime.datetime.now().astimezone().isoformat(),
        }
        latest_tmp = os.path.join(release_root, ".LATEST-%s.tmp" % uuid.uuid4().hex)
        with open(latest_tmp, "w", encoding="utf-8") as f:
            json.dump(latest, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(latest_tmp, os.path.join(release_root, "LATEST.json"))
    except Exception:
        if os.path.isdir(staging):
            shutil.rmtree(staging)
        raise

    print("正式發布完成")
    print("  版本：%s" % version)
    print("  條文：%d 筆" % stats["條文筆數"])
    print("  路徑：%s" % final_dir)
    print("  唯一入口：%s" % os.path.join(release_root, "LATEST.json"))
    return final_dir


def main():
    parser = argparse.ArgumentParser(description="S12：產生唯一正式發布版本")
    parser.add_argument("folder", help="S1 到 S10 的工作資料夾")
    parser.add_argument("release_root", help="正式版本根目錄")
    parser.add_argument("--version", required=True, help="不可重複的版本號")
    parser.add_argument("--source", required=True, help="本次產線的原始 DOCX 或 TXT")
    parser.add_argument("--name", required=True, help="規章名稱")
    parser.add_argument("--org", default="", help="所屬機構")
    parser.add_argument("--ver", dest="version_date", default="", help="規章版本日")
    args = parser.parse_args()
    try:
        publish(args)
        return 0
    except Exception as exc:
        print("[中止] 正式發布失敗：%s" % exc)
        return 1


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    sys.exit(main())
