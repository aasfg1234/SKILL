# -*- coding: utf-8 -*-
"""
連帶決定表：compare 找到的候選合成一張表，人只填「要改嗎」「改成什麼」兩欄。

來源：
    規格包      diff-cut 正式基準已知的重複、相似、引用關係
    相似        整條相似度（fuzzy_duplicate_finder）
    相似（句）  整條相似度不夠，但改到的那一句在別的候選裡分數夠高
    關鍵詞      這次改動的字在別處也出現（有片段可搜）
    關鍵詞（文脈）改動片段太短沒有片段可搜，改用改動處左右文脈搜
    語意        BGE-M3 向量（可選）
同一個候選段次只出現一列，來源與異動條文ID 用「；」併列。

一定有一份同名 .json（指紋檔）：記草稿 SHA-256、初比對異動段落指紋、每列候選全文指紋。
apply 與 finalize 靠它擋「中間動過草稿」與「拿錯表」。位置見 sidecar_path_for
（表在 填寫表單/ 時，指紋檔在隔壁的 系統檔案/）。
"""

import csv
import datetime
import hashlib
import io
import json
import os
import re
import sys

# 三格的名字只有一個來源（_common.FILE_HOMES 那一節），這裡不自己再寫一份字串。
# append 而不是 insert(0)：regdiff/run_all.py 跟 scripts/run_all.py 同名。
_REGDIFF = os.path.join(os.path.dirname(os.path.abspath(__file__)), "regdiff")
if _REGDIFF not in sys.path:
    sys.path.append(_REGDIFF)
from _common import REVIEW_DIR, FILL_DIR, SYSTEM_DIR

COLUMNS = ["來源", "異動條文ID", "異動摘要", "候選條文ID", "候選段次", "候選全文",
           "關係／分數", "經同義詞比對", "要改嗎", "改成什麼"]
ACTIONS = ("改", "刪除", "不改", "")
RELATION_TYPES = ("重複條文", "相似條文", "被誰引用", "我引用誰")
# 選填欄：不是每一次都有，有的時候要照原順序寫出來。
# 「修改類型」＝把這一列帶出來的那一處異動是修改／新增／刪除（多處就用「；」併列）。
# 決定表只寫「異動條文ID」的話，人要回頭翻異動清單才知道那一處到底是改字還是整條刪掉，
# 而這兩種情況要判的事完全不同（刪掉的條文，別章的平行條文多半也要一起刪）。
# 「異動段次」＝把這一列帶出來的那一處異動在哪一段（新增／修改寫「N」，刪除寫「舊版 N」）。
# 無條號的作業手冊型文件，「異動條文ID」只寫得出「段次 N」這種代號，
# 人要回頭數段落才知道那是全文的哪裡；這一欄把座標直接寫在表上。
# 新加的選填欄一律排在最後面（裁定 5）：「修改類型」的欄位置不能動。
OPTIONAL_COLUMNS = ["規章", "修改類型", "AI判斷", "AI分數", "AI理由", "異動段次"]
TYPE_LABELS = {"added": "新增", "deleted": "刪除", "modified": "修改"}


class DecisionTableError(ValueError):
    pass


def normalize(text):
    return re.sub(r"\s+", "", text or "")


def normalize_newlines(text):
    """把 \\r\\n（與單獨的 \\r）收斂成 \\n。

    候選全文可能帶換行（Word 的 <w:br/> 讀進來就是 \\n）。人用 Excel 開決定表、
    存檔之後，儲存格裡的換行會被寫成 \\r\\n；拿它跟草稿段落逐字比就會不相等，
    apply 於是回報「跳過（原文不符）」——但草稿其實一個字都沒被動過。
    這是「比對用字串」的正規化，不改寫任何產出檔裡的原文。
    """
    return (text or "").replace("\r\n", "\n").replace("\r", "\n")


def text_sha256(text):
    return hashlib.sha256(normalize(text).encode("utf-8")).hexdigest()


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _summary(text, limit=40):
    text = (text or "").strip()
    return text if len(text) <= limit else text[:limit] + "…"


# 刪除型異動的「異動摘要」前綴（裁定 5：不另外加欄，改在既有欄位標記）。
# 為什麼要標：決定表上的「異動摘要」對修改型放的是新文、對刪除型放的是舊文，
# 兩者長得一模一樣，看表的人分不出「這一條被改了幾個字」還是「這一條整條沒了」——
# 而這兩種要判的事完全不同：整條刪掉的條文，別章的平行條文多半也要一起刪。
DELETED_PREFIX = "【整條刪除】"


def mark_deleted_summary(summary, type_label):
    """刪除型異動的摘要加上前綴。type_label 是候選 CSV 第 2 欄的「修改類型」。"""
    summary = summary or ""
    if not summary or DELETED_PREFIX in summary:
        return summary
    if TYPE_LABELS["deleted"] not in str(type_label or ""):
        return summary
    return DELETED_PREFIX + summary


def strip_deleted_prefix(summary):
    """把前綴拿掉。拿摘要去跟條文原文做開頭比對的地方（review_pack 收斂同名 ref）
    要用這一支，不然加了前綴之後永遠比不中。"""
    summary = summary or ""
    return summary[len(DELETED_PREFIX):] if summary.startswith(DELETED_PREFIX) else summary


def _merge(row, source, change_id, cand_id, relation, evidence):
    for key, value, sep in (("來源", source, "；"), ("異動條文ID", change_id, "；"),
                            ("候選條文ID", cand_id, "；"), ("關係／分數", relation, " | "),
                            ("經同義詞比對", evidence, "；")):
        if not value:
            continue
        # 傳進來的值本身可能已經是「A；B」這種組合，要拆開逐一比，不然永遠比不中、越併越長
        existing = [x for x in row[key].split(sep) if x] if row[key] else []
        for piece in (value.split(sep) if sep in value else [value]):
            piece = piece.strip()
            if piece and piece not in existing:
                existing.append(piece)
        row[key] = sep.join(existing)


def _new_row(line, summary, text):
    return {"來源": "", "異動條文ID": "", "異動摘要": summary or "", "候選條文ID": "",
            "候選段次": str(line) if line else "", "候選全文": text or "",
            "關係／分數": "", "經同義詞比對": "", "要改嗎": "", "改成什麼": ""}


def _line_of(value):
    value = str(value or "").strip()
    return int(value) if value.isdigit() and int(value) > 0 else 0


line_of = _line_of


def change_keys(item, baseline=None):
    """一處異動在決定表「異動條文ID」欄可能出現的每一種寫法。

    同一處異動在決定表上可能以好幾種寫法出現：有正式基準時是
    「、」.join(spec_ids)（baseline.change_label），沒有基準時是 ref，規格包連帶複核
    那條路又是單一個條文ID，關鍵詞那條路還可能是「段次 N」；無條號文件整段被刪掉時
    寫的是「舊版段次 N」（見 regdiff/run_all.step_duplicates）。

    change_type_map 與 change_position_map 共用這一支，兩欄的鍵才不會漂開——
    一邊查得到、另一邊留白，看表的人會以為那一列真的沒有段次。
    """
    keys = []
    ids = list(item.get("spec_ids") or [])
    if baseline is not None:
        keys.append(baseline.change_label(item))
    elif ids:
        keys.append("、".join(ids))
    keys.append(item.get("ref") or "")
    keys += ids
    if item.get("new_index"):
        keys.append("段次 %d" % item["new_index"])
    if item.get("type") == "deleted" and item.get("old_index"):
        keys.append("舊版段次 %d" % item["old_index"])
    return [k for k in keys if k]


def change_type_map(results, baseline=None):
    """{異動的識別字: [修改類型, ...]}，給 build_rows 標「修改類型」欄用。
    鍵的寫法見 change_keys。"""
    out = {}
    for item in results or []:
        label = TYPE_LABELS.get(item.get("type"))
        if not label:
            continue
        for key in change_keys(item, baseline):
            bucket = out.setdefault(key, [])
            if label not in bucket:
                bucket.append(label)
    return out


def change_position_map(results, baseline=None):
    """{異動的識別字: [段次字串, ...]}，給 build_rows 標「異動段次」欄用。

    新增／修改寫新版段次「N」，刪除寫「舊版 N」（刪除型沒有新版段次，
    寫成「N」會被當成新版座標而翻錯段）。鍵跟 change_type_map 一模一樣。
    """
    out = {}
    for item in results or []:
        if item.get("type") not in TYPE_LABELS:
            continue
        if item.get("type") == "deleted":
            position = "舊版 %d" % item["old_index"] if item.get("old_index") else ""
        else:
            position = "%d" % item["new_index"] if item.get("new_index") else ""
        if not position:
            continue
        for key in change_keys(item, baseline):
            bucket = out.setdefault(key, [])
            if position not in bucket:
                bucket.append(position)
    return out


def values_for_change_id(change_id, mapping):
    """決定表某一列查某一張對照表：把「異動條文ID」用「；」拆開逐段查，
    查到的值去重後用「；」併起來。查不到就回空字串，不猜。"""
    if not mapping or not change_id:
        return ""
    out = []
    for piece in str(change_id).split("；"):
        piece = piece.strip()
        if not piece:
            continue
        values = mapping.get(piece)
        if values is None and "、" in piece:
            # 「A-003、A-003-1」這種一次帶好幾個條文ID的寫法，拆開再查一次
            values = []
            for sub in piece.split("、"):
                values += mapping.get(sub.strip(), [])
        for value in (values or []):
            if value not in out:
                out.append(value)
    return "；".join(out)


def _dedupe(values):
    """保留原順序去重。"""
    out = []
    for value in values:
        if value not in out:
            out.append(value)
    return out


def types_for_change_id(change_id, change_types):
    """決定表某一列的「修改類型」。"""
    return values_for_change_id(change_id, change_types)


def build_rows(candidate_rows, changed_rows, review_rows, new_line_ids, new_paragraphs,
               semantic_rows=None, sentence_rows=None, change_types=None,
               change_positions=None):
    """
    candidate_rows：regdiff run_all.step_duplicates 的 csv_rows（18 欄 list，第 2 欄是修改類型、
                    最後一欄是「異動段次」）
    changed_rows：同函式的 changed_rows（12 欄 list，第 2 欄是修改類型、
                  第 11 欄是「片段」或「文脈」、最後一欄是「異動段次」）
    review_rows：baseline.write_review 的列（dict）
    new_line_ids：baseline.annotate_results 的回傳 {新版段次: [條文ID, ...]}
    semantic_rows：semantic_candidates 讀出的列（dict）
    sentence_rows：regdiff run_all.step_duplicates 的 sentence_rows（9 欄 list）
    change_types：change_type_map 的回傳；只有「自己沒帶類型」的列（句子／規格包／語意）
                  才用它查表，沒給就那些列整欄留空
    change_positions：change_position_map 的回傳；用法同 change_types，填「異動段次」欄
    """
    by_key = {}
    order = []
    # 每一列看過的修改類型與異動段次（候選／關鍵詞列各自帶的 c[1]／h[1] 與
    # c[17]／h[11]）；句子與規格包列沒帶，不記。
    # 為什麼不能一律拿 異動條文ID 去查 change_types／change_positions：手冊型文件
    # 每一章都有一個「1.」，ref 全都是「1.」，全書共用一個鍵——第一章那處改字與
    # 第二章那段整條刪除會被併成「修改；刪除」「2；舊版 5」，段次指到別章，
    # 【整條刪除】前綴也因為混進「修改」而掉了。
    # 這兩份記的才是「真的帶出這一列的那幾處異動」，有記到就以它為準。
    # 【整條刪除】前綴要等整列併完才決定（見函式末尾），不能在 add() 當下就標——
    # 不然同一段先被刪除型帶出來、再被修改型併進來，前綴會留著；反過來就不會有，
    # 結果看合併順序而定，看表的人以為整條沒了其實旁邊還有一筆修改。
    types_seen = {}
    positions_seen = {}

    def add(line_no, source, change_id, summary, cand_id, text, relation, evidence,
            type_label=None, position=None):
        line = _line_of(line_no)
        key = line if line else ("無段次", cand_id, source, relation)
        row = by_key.get(key)
        if row is None:
            row = _new_row(line, summary, text)
            by_key[key] = row
            order.append(key)
        _merge(row, source, change_id, cand_id, relation, evidence)
        if not row["異動摘要"] and summary:
            row["異動摘要"] = summary
        if type_label:
            types_seen.setdefault(key, set()).add(str(type_label))
        if position:
            positions_seen.setdefault(key, []).append(str(position))

    # c／h 的第 2 欄（索引 1）是修改類型、最後一欄是異動段次，兩者都是
    # 「帶出這一列的那一處異動」自己的值。用 len() 守門：舊格式的 list
    # （沒有最後那一欄）就當沒帶，照樣退回 change_types／change_positions 查表。
    for c in candidate_rows or []:
        relation = "%s 分" % c[7] + ("、%s" % c[9] if c[9] else "")
        add(c[5], "相似", c[0] or "", _summary(c[2]),
            c[4] or "", c[6], relation, c[11] or "", type_label=c[1],
            position=(c[17] if len(c) > 17 else ""))
    for h in changed_rows or []:
        mode = h[10] if len(h) > 10 else "片段"
        position = h[11] if len(h) > 11 else ""
        summary = _summary(h[2])
        if mode == "文脈":
            add(h[6], "關鍵詞（文脈）", h[0] or "", summary, h[5] or "", h[7],
                "文脈「%s」" % h[8], "", type_label=h[1], position=position)
        else:
            add(h[6], "關鍵詞", h[0] or "", summary, h[5] or "", h[7],
                "命中「%s」" % h[8], "", type_label=h[1], position=position)
    for s in sentence_rows or []:
        add(s[4], "相似（句）", s[0] or "", _summary(s[1]), s[3] or "", s[7],
            "句 %s 分：%s" % (s[6], _summary(s[5], 30)), s[8] or "")

    id_to_line = {}
    for line, ids in (new_line_ids or {}).items():
        for item_id in ids:
            id_to_line.setdefault(item_id, int(line))
    for r in review_rows or []:
        if r.get("關聯類型") not in RELATION_TYPES:
            continue
        line = id_to_line.get(r.get("關聯條文ID"))
        text = new_paragraphs[line - 1] if line else r.get("關聯條文全文", "")
        relation = r["關聯類型"] + ("" if line else "（無法定位到草稿段落）")
        add(line, "規格包", r.get("異動條文ID", ""), "", r.get("關聯條文ID", ""),
            text, relation, "")

    # 【整條刪除】前綴在這裡一次決定（裁定 5）：這一列的修改類型全部都是「刪除」才標；
    # 混了修改／新增的列一律不標，免得把「改了幾個字」誤寫成整條刪掉。
    # 修改類型與異動段次都以「真的帶出這一列的那幾處異動」為準（types_seen／
    # positions_seen）；只有句子層級、規格包、語意那幾條路的列沒帶，才退回
    # change_types／change_positions 查表。
    seen_by_row = {id(by_key[k]): types_seen.get(k, set()) for k in order}
    pos_by_row = {id(by_key[k]): positions_seen.get(k, []) for k in order}
    rows = [by_key[k] for k in order]
    rows = add_semantic(rows, semantic_rows or [])
    for row in rows:
        # 欄位存不存在還是由 change_types／change_positions 有沒有給決定（不給就整欄
        # 不長出來，呼叫端的欄位契約不變）；欄裡填什麼才改成優先看這一列自己帶的。
        own_positions = _dedupe([p for p in pos_by_row.get(id(row), []) if p])
        own_types = sorted(seen_by_row.get(id(row)) or ())
        if change_positions:
            row["異動段次"] = ("；".join(own_positions) if own_positions
                             else values_for_change_id(row.get("異動條文ID"), change_positions))
        if change_types:
            row["修改類型"] = ("；".join(own_types) if own_types
                             else types_for_change_id(row.get("異動條文ID"), change_types))
            labels = row["修改類型"]
        else:
            labels = "；".join(own_types)
        summary = strip_deleted_prefix(row["異動摘要"])
        if labels and all(t == TYPE_LABELS["deleted"] for t in labels.split("；")):
            summary = mark_deleted_summary(summary, TYPE_LABELS["deleted"])
        row["異動摘要"] = summary
    return rows


def add_semantic(rows, semantic_rows):
    """把語意候選併進既有列；同段次併列，新段次新增。既有的「要改嗎」「改成什麼」不動。"""
    by_line = {r["候選段次"]: r for r in rows if r["候選段次"]}
    for s in semantic_rows or []:
        line = _line_of(s.get("候選段次"))
        if not line:
            continue
        row = by_line.get(str(line))
        if row is None:
            row = _new_row(line, _summary(s.get("異動全文", "")), s.get("候選全文", ""))
            rows.append(row)
            by_line[str(line)] = row
        _merge(row, "語意", s.get("異動條文ID") or ("段次 %s" % s.get("異動段次", "")),
               "", "語意 %s" % s.get("語意分數", ""), "")
    rows.sort(key=lambda r: (0 if r["候選段次"] else 1, int(r["候選段次"] or 0)))
    return rows


def add_cross(rows, cross_rows):
    """把跨本候選（來源「跨本」「跨本引用」）併進既有列。規則同 add_semantic；
    沒有候選段次的列（定位不到草稿段落）依 (候選條文ID, 候選全文) 合併，排最後。既有的決定不動。"""
    by_line = {r["候選段次"]: r for r in rows if r["候選段次"]}
    by_key = {}
    for s in cross_rows or []:
        line = _line_of(s.get("候選段次"))
        if line:
            row = by_line.get(str(line))
            if row is None:
                row = _new_row(line, s.get("異動摘要", ""), s.get("候選全文", ""))
                rows.append(row)
                by_line[str(line)] = row
        else:
            key = (s.get("候選條文ID", ""), normalize(s.get("候選全文", "")))
            row = by_key.get(key)
            if row is None:
                row = _new_row(0, s.get("異動摘要", ""), s.get("候選全文", ""))
                rows.append(row)
                by_key[key] = row
        _merge(row, s.get("來源") or "跨本", s.get("異動條文ID", ""), s.get("候選條文ID", ""),
               s.get("關係／分數", ""), s.get("經同義詞比對", ""))
        if not row["異動摘要"] and s.get("異動摘要"):
            row["異動摘要"] = s["異動摘要"]
    rows.sort(key=lambda r: (0 if r["候選段次"] else 1, int(r["候選段次"] or 0)))
    return rows


def write_change_list(results, path):
    """實質異動清單，給 review-pack 用。修正對照表的欄名可由設定檔改，所以另存一份固定格式。"""
    items = []
    for r in results:
        if r.get("type") not in TYPE_LABELS:
            continue
        items.append({"序號": len(items) + 1, "修改類型": TYPE_LABELS[r["type"]],
                      "old_text": r.get("old_text") or "", "new_text": r.get("new_text") or "",
                      "old_index": r.get("old_index"), "new_index": r.get("new_index"),
                      "ref": r.get("ref") or "", "scope": r.get("scope") or "",
                      "spec_ids": list(r.get("spec_ids") or [])})
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return items


def sidecar_path_for(table_path):
    """一張表（連帶決定表.csv／終比對候選表.xlsx）的指紋檔在哪裡。

    指紋檔一律進 系統檔案/：它是程式接力用的中繼檔，跟表本身放哪一格無關。
    連帶決定表是「人要填」的表（填寫表單/），終比對候選表是「人要看」的表
    （審閱文件/），兩張表的指紋檔都落在同一個 <X>/系統檔案/<同名>.json——
    不然 審閱文件/ 裡會多出一個沒人看得懂、也沒登記在 FILE_HOMES 的 .json。

    所以判斷方式是「表的上一層資料夾是不是三格之一」：是的話往上一層找
    系統檔案/，不是的話（舊排法的平鋪產出、或使用者自己複製一份到桌面上填）
    退回同資料夾的同名 .json——那種情況沒有三格可言，硬要往上找一層只會
    指到一個不存在的地方。

    這裡刻意**不用** _common.place：place 會順手把資料夾建出來，而這一支
    大多數呼叫端是「讀」（apply／finalize 要驗指紋），讀一個路徑不該在
    別人的資料夾裡長出空的 系統檔案/。要寫的那一端自己用 place。
    """
    name = os.path.basename(os.path.splitext(table_path)[0]) + ".json"
    folder = os.path.dirname(table_path)
    if os.path.basename(folder) in (REVIEW_DIR, FILL_DIR, SYSTEM_DIR):
        return os.path.join(os.path.dirname(folder), SYSTEM_DIR, name)
    return os.path.join(folder, name)


def write_table(rows, table_path, json_path, draft_path, changed_texts=None, extra=None,
                params=None, fmt="csv", written=None):
    """寫一張候選表＋它的指紋檔。

    params（選填）：這次初比對實際用的四個 Step 2 門檻
    {"threshold","top","changed_top","sentence_threshold"}，記進指紋檔鍵「比對參數」。
    終比對（finalize／batch-finalize）沒有在命令列另外指定這幾個旗標時，要讀這裡
    記的值沿用初比對的門檻，不能悄悄退回程式自己的硬預設——不然終比對候選表會
    多或少候選，跟初比對兜不起來，人在對照兩張表時看不出差在哪。

    fmt："csv" 是人要**填**的那張表（連帶決定表：程式回頭要讀它，格式不能變）；
    "xlsx" 是人只要**看**的那張表（終比對候選表：欄寬、換行、粗體標題列都留得住），
    走 xlsx_writer.write_tables_or_csv，寫不出來才自動退成 csv。指紋檔兩種都照舊寫。

    written（選填）：給呼叫端收「實際寫出了哪幾個檔」的 list。xlsx 退成 csv 時
    路徑會跟 table_path 不同，呼叫端的產出清單要印的是真的寫出來的那一個。
    """
    extra = dict(extra or {})
    unknown = [k for k in extra if k not in OPTIONAL_COLUMNS]
    if unknown:
        raise DecisionTableError("不認得的額外欄：%s" % "、".join(unknown))
    # 選填欄的來源有兩個：呼叫端統一指定的 extra（例如批次的「規章」），
    # 以及列自己就帶著的（build_rows 填的「修改類型」）。只看 extra 的話，
    # 列上填好的修改類型會在寫檔這一步整欄消失。順序照 OPTIONAL_COLUMNS。
    fields = COLUMNS + [c for c in OPTIONAL_COLUMNS
                        if c in extra or any(c in r for r in rows)]
    if fmt == "xlsx":
        import xlsx_writer as xw
        base = os.path.splitext(table_path)[0]
        sheet = os.path.basename(base)
        cells = [[row.get(c, extra.get(c, "")) for c in fields] for row in rows]
        paths = xw.write_tables_or_csv(base, [(sheet, fields, cells)], source=sheet)
    else:
        with io.open(table_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields, quoting=csv.QUOTE_ALL)
            writer.writeheader()
            for row in rows:
                writer.writerow({c: row.get(c, extra.get(c, "")) for c in fields})
        paths = [table_path]
    if written is not None:
        written.extend(paths)
    sidecar = {
        "格式版本": 1,
        "產生時間": datetime.datetime.now().astimezone().isoformat(),
        "草稿": {"檔名": os.path.basename(draft_path), "SHA256": file_sha256(draft_path)},
        "異動段落SHA256": sorted({text_sha256(t) for t in (changed_texts or []) if t}),
        "列": [{"候選段次": _line_of(r["候選段次"]),
               "候選全文SHA256": text_sha256(r["候選全文"])} for r in rows],
    }
    if params:
        sidecar["比對參數"] = dict(params)
    with io.open(json_path, "w", encoding="utf-8") as f:
        json.dump(sidecar, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return sidecar


def read_sidecar(json_path):
    if not os.path.isfile(json_path):
        raise DecisionTableError(
            "找不到決定表的指紋檔：%s（compare 產生的 .json 要跟 .csv 放在一起）" % json_path)
    with io.open(json_path, encoding="utf-8-sig") as f:
        data = json.load(f)
    if data.get("格式版本") != 1 or "草稿" not in data or "列" not in data:
        raise DecisionTableError("指紋檔格式不對：%s" % json_path)
    return data


def read_table(csv_path):
    with io.open(csv_path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        missing = [c for c in COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise DecisionTableError("決定表缺欄位：%s" % "、".join(missing))
        rows = list(reader)
    for index, row in enumerate(rows, 2):
        action = (row.get("要改嗎") or "").strip()
        row["要改嗎"] = action
        # 帶換行的兩欄先把 Excel 存出來的 \r\n 收斂成 \n（見 normalize_newlines）。
        # 草稿裡的 <w:br/> 讀進來是 \n，不收斂的話這一列會被判成「原文不符」而跳過。
        row["候選全文"] = normalize_newlines(row.get("候選全文") or "")
        row["改成什麼"] = normalize_newlines(row.get("改成什麼") or "")
        if action not in ACTIONS:
            raise DecisionTableError(
                "第 %d 列「要改嗎」寫了認不得的字：「%s」。只能填 改／刪除／不改，或留空"
                % (index, action))
        if action == "改" and not row["改成什麼"].strip():
            raise DecisionTableError("第 %d 列填了「改」但「改成什麼」是空的" % index)
    return rows


def write_rows_csv(path, rows):
    """把 read_table 讀回、人改過的列寫回去；保留 COLUMNS 之外的額外欄；先寫 .tmp 再 os.replace。

    額外欄要看「全部列」有沒有任何一列帶這個欄，不能只看 rows[0]：add_semantic／
    add_cross 用 _new_row 造的新列本來就沒有 AI／規章欄，這種新列如果排序後排第一，
    只看 rows[0].keys() 會讓整張表的 AI 三欄與「規章」欄整個消失，即使其他列都有值。

    使用者自己在 Excel 加的欄（「承辦註記」「複核意見」這類）也一起留著，排在
    已知欄後面，彼此的順序照原表頭（read_table 用 DictReader，每一列的鍵順序
    就是表頭順序）。以前用白名單挑欄，自加的欄整欄無聲消失——法遵填了一整輪
    註記，跑一次 review-import 就全部不見，而且沒有任何一句話說它被丟掉了。
    模組 docstring 與規格 §6.3 寫的都是「照留」。"""
    extra = [c for c in OPTIONAL_COLUMNS if any(c in r for r in rows)]
    known = set(COLUMNS) | set(OPTIONAL_COLUMNS)
    user_added = []
    for row in rows:
        for column in row:
            # DictReader 多出來的值會塞在 restkey（None）底下，那不是欄名。
            if column is None or column in known or column in user_added:
                continue
            user_added.append(column)
    fields = COLUMNS + extra + user_added
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, quoting=csv.QUOTE_ALL)
        writer.writeheader()
        for row in rows:
            writer.writerow({c: row.get(c, "") for c in fields})
    os.replace(tmp, path)
