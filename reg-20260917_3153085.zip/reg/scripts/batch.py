# -*- coding: utf-8 -*-
"""
多本批次與跨本連帶：清單讀取、跨本候選、引用連帶、批次摘要。

跨本候選只列不判：A 本改了某條，到 B 本草稿找整條相似、關鍵詞命中；
B 本有規格包時，再看 B 的引用表有沒有引用到 A 本被改的那條。
每一筆都帶兩條全文與分數，理由由 AI 在第 2 步寫，人決定。
"""

import csv
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import fuzzy_duplicate_finder as fuzzy
import notices as nt
from _common import (build_hierarchy, diff_runs, extract_article_no, format_scope, locate,
                     normalize_terms)

MANIFEST_COLUMNS = ["規章名", "舊版", "新版草稿", "發布根目錄"]


class BatchError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 規章清單
# ---------------------------------------------------------------------------

def read_manifest(path):
    """讀規章清單.csv；相對路徑以清單所在資料夾為準。任何一列不合法就整支停。"""
    if not os.path.isfile(path):
        raise BatchError("找不到規章清單：%s" % path)
    base = os.path.dirname(os.path.abspath(path))
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        missing = [c for c in MANIFEST_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise BatchError("規章清單缺欄位：%s" % "、".join(missing))
        rows = list(reader)

    def resolve(value):
        value = (value or "").strip()
        if not value:
            return ""
        return os.path.normpath(value if os.path.isabs(value) else os.path.join(base, value))

    docs = []
    seen = {}          # 規章名 -> 第一次用到它的列號
    seen_old = {}      # normcase(絕對路徑) -> 第一次用到它的列號，見 item8
    seen_draft = {}
    for index, row in enumerate(rows, 2):
        name = (row.get("規章名") or "").strip()
        if not name:
            raise BatchError("第 %d 列規章名空白" % index)
        if name in (".", "..") or os.path.basename(name) != name:
            raise BatchError("第 %d 列規章名不能含路徑字元：%s" % (index, name))
        if name in seen:
            # no 15：這則訊息現在也會出現在「配對」階段（cmd_pair 寫完清單就跑同一套
            # 驗證），跟其他每一則一樣要講是哪一列，人才知道要去改清單的哪一行。
            raise BatchError("第 %d 列規章名重複：%s（與第 %d 列相同）"
                             % (index, name, seen[name]))
        seen[name] = index
        old_raw = (row.get("舊版") or "").strip()
        if not old_raw:
            # 工作區「配對」寫出的清單，舊版空白代表這本還沒配對成功（未配對／
            # 多個候選都是舊版留空）——跟「填了路徑但檔案不見了」是兩回事，訊息
            # 分開講，才不會誤導使用者去找一個根本沒填過的檔案。
            # item7：多個候選時，「配對」已經把候選寫進「備註」欄
            # （merge_manual／match，例如「多個候選：甲、乙」）——原樣附進錯誤
            # 訊息，人不用另外開清單就知道要在哪幾個裡面選。
            note = (row.get("備註") or "").strip()
            suffix = "（備註：%s）" % note if note else ""
            raise BatchError("第 %d 列（%s）未配對，請先處理%s" % (index, name, suffix))
        old = resolve(old_raw)
        if not os.path.isfile(old):
            raise BatchError("第 %d 列（%s）舊版檔不存在：%s" % (index, name, old))
        # item8：兩列指到同一份舊版／新版草稿檔，套用時後面那本會把前一本的異動
        # 誤判成自己的（同一份 .docx 被兩本各自複製、各自開追蹤修訂，內容卻是同
        # 一份），不能放行——normcase 是為了 Windows 大小寫不敏感的路徑也抓得到。
        old_key = os.path.normcase(os.path.abspath(old))
        if old_key in seen_old:
            raise BatchError("第 %d 列（%s）舊版重複使用：%s（與第 %d 列相同）"
                             % (index, name, old, seen_old[old_key]))
        seen_old[old_key] = index
        draft = resolve(row.get("新版草稿"))
        if draft and not os.path.isfile(draft):
            raise BatchError("第 %d 列（%s）新版草稿不存在：%s" % (index, name, draft))
        if draft:
            draft_key = os.path.normcase(os.path.abspath(draft))
            if draft_key in seen_draft:
                raise BatchError("第 %d 列（%s）新版草稿重複使用：%s（與第 %d 列相同）"
                                 % (index, name, draft, seen_draft[draft_key]))
            seen_draft[draft_key] = index
        release = resolve(row.get("發布根目錄"))
        if release and not os.path.isfile(os.path.join(release, "LATEST.json")):
            raise BatchError("第 %d 列（%s）發布根目錄缺 LATEST.json：%s" % (index, name, release))
        docs.append({"規章名": name, "舊版": old, "草稿": draft or old,
                     "有草稿": bool(draft), "發布根目錄": release})
    if not docs:
        raise BatchError("規章清單沒有任何規章")
    return docs


# 一本要能進 batch-review-pack／batch-review-import，這三個檔案缺一不可
# （相對 <outdir>/<規章名>/ 的路徑，顯示用的標籤是給人看的）：
# 連帶決定表.csv（填寫表單/）、異動清單.json（系統檔案/）是 compare 產出；
# 系統檔案/輸入/輸入指紋.json 是 stage_inputs 產出的指紋檔，rp.load_book 用它核對
# 草稿沒被換掉。三個只要缺一個，rp.load_book 就會在 write_pack／import_review
# 半路才炸，不如在 list_books 這一關先篩掉。
# 每一項是 (檔名, 顯示標籤, 資料夾底下的檔名)；實際路徑一律由 _common.locate 算
# （新排法優先，找不到再看舊排法的平鋪），指紋檔另外接在「輸入」資料夾底下。
_REQUIRED_BOOK_FILES = [
    ("連帶決定表.csv", "連帶決定表.csv", ""),
    ("異動清單.json", "異動清單.json", ""),
    ("輸入", "輸入/輸入指紋.json", "輸入指紋.json"),
]


def _book_file(outdir_doc, name, tail=""):
    """一本產出裡某個檔的實際路徑（新排法優先，找不到退舊平鋪）。

    tail 是接在資料夾底下的檔名（輸入/輸入指紋.json、輸入/規章清單.csv）。
    這種要多退一手：locate 看的是「輸入 這個資料夾」在不在，資料夾在、裡面那個檔
    卻不在的時候（半搬過的資料夾），還是要回頭找舊排法的 <outdir>/輸入/<tail>，
    不然會拿著一個不存在的新路徑去報「找不到規章清單」。
    """
    path = locate(outdir_doc, name)[0]
    if not tail:
        return path
    full = os.path.join(path, tail)
    if os.path.exists(full):
        return full
    legacy = os.path.join(outdir_doc, name, tail)
    return legacy if os.path.exists(legacy) else full


def list_books(outdir):
    """給 batch-review-pack／batch-review-import 用：讀 <outdir>/系統檔案/輸入/規章清單.csv
    （batch 已經把使用者原始清單複製進來，見 run_all.stage_inputs；舊排法的產出資料夾
    退回 <outdir>/輸入/規章清單.csv）取規章名順序，回傳 [(規章名, <outdir>/<規章名>), ...]。

    清單裡「舊版」「新版草稿」「發布根目錄」欄記的是複製前、原始清單所在資料夾的相對
    路徑，搬到留底資料夾之後大多已經找不到那些檔案——但這裡只需要規章名順序，
    所以不用 read_manifest（找不到檔案就整支停），改用 csv.DictReader 只讀規章名欄。

    產出不完整的本（缺 _REQUIRED_BOOK_FILES 任何一個——那一本當初 batch 就失敗、
    還沒跑過 batch，或是被手動刪掉了某個檔案）跳過並印出缺了什麼；一本都不剩就
    raise BatchError。"""
    path = _book_file(outdir, "輸入", "規章清單.csv")
    if not os.path.isfile(path):
        raise BatchError("找不到規章清單：%s（請先跑 batch）" % path)
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if "規章名" not in (reader.fieldnames or []):
            raise BatchError("規章清單缺欄位：規章名")
        rows = list(reader)

    books = []
    for row in rows:
        name = (row.get("規章名") or "").strip()
        if not name:
            continue
        outdir_doc = os.path.join(outdir, name)
        missing = [label for name_, label, tail in _REQUIRED_BOOK_FILES
                   if not os.path.isfile(_book_file(outdir_doc, name_, tail))]
        if missing:
            print("略過 %s：產出不完整（缺 %s）" % (name, "、".join(missing)))
            continue
        books.append((name, outdir_doc))
    if not books:
        raise BatchError("規章清單裡沒有任何一本有完整產出（請先跑 batch）")
    return books


# ---------------------------------------------------------------------------
# 條號正規化：中文數字轉半形數字，讓「第三十四條」對得上「第34條」
# ---------------------------------------------------------------------------

_CN_DIGIT = {"零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "三": 3, "四": 4,
             "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
_CN_UNIT = {"十": 10, "百": 100, "千": 1000}
_CN_RUN = re.compile("[%s%s]+" % ("".join(_CN_DIGIT), "".join(_CN_UNIT)))


def cn_to_int(text):
    total = 0
    number = 0
    for ch in text:
        if ch in _CN_DIGIT:
            number = _CN_DIGIT[ch]
        elif ch in _CN_UNIT:
            total += (number if number else 1) * _CN_UNIT[ch]
            number = 0
    return total + number


def normalize_article_no(text):
    text = re.sub(r"\s+", "", text or "")
    text = text.replace("（", "(").replace("）", ")")
    return _CN_RUN.sub(lambda m: str(cn_to_int(m.group(0))), text)


# ---------------------------------------------------------------------------
# 跨本候選：相似 + 關鍵詞
# ---------------------------------------------------------------------------

def _label(source_name, change):
    """沒有規格包 ID 也沒有條號時退回段次，標籤才不會只剩「A名：」。"""
    tag = change.get("條文ID") or change.get("ref") or ("段次 %s" % change.get("段次", ""))
    return "%s：%s" % (source_name, tag)


def _row(source, label, summary, cand_id, line, text, relation, evidence=""):
    return {"來源": source, "異動條文ID": label, "異動摘要": summary, "候選條文ID": cand_id or "",
            "候選段次": str(line) if line else "", "候選全文": text or "",
            "關係／分數": relation, "經同義詞比對": evidence}


def cross_candidates(source_name, source_changes, target_paragraphs, synonyms,
                     threshold, top, changed_top, sentence_threshold=fuzzy.DEFAULT_SENTENCE_THRESHOLD,
                     target_kinds=None):
    """拿 A 本每個異動到 B 本草稿找整條相似與關鍵詞命中。B 本沒有「自己那段」要排除，
    所以 exclude_index 用 0（不會等於任何段次，也關掉「文字完全相同就跳過」）。

    target_kinds 是 B 本每一段的來源種類（"p"／"cell"），跟 compare 用同一份層級脈絡，
    候選的條號才不會跟 B 本自己的修正對照表對不起來。"""
    contexts = build_hierarchy(target_paragraphs, target_kinds)
    out = []
    for change in source_changes:
        label = _label(source_name, change)
        summary = dt._summary(change["new_text"])
        for c in fuzzy.find_duplicates(change["new_text"], target_paragraphs, threshold=threshold,
                                       top=top, exclude_index=0, contexts=contexts,
                                       synonyms=synonyms, changed_old_text=change.get("old_text")):
            relation = "跨本相似 %s 分" % c["similarity"]
            if c.get("fragment_position"):
                relation += "、%s" % c["fragment_position"]
            out.append(_row("跨本", label, summary, "", c["line_number"], c["text"], relation,
                            "、".join(c.get("synonym_evidence") or [])))
        fragments = fuzzy.changed_fragments(change.get("old_text") or "", change["new_text"], diff_runs)
        if fragments:
            for h in fuzzy.find_by_changed_text(fragments, target_paragraphs, exclude_index=0,
                                                contexts=contexts, synonyms=synonyms,
                                                normalize=normalize_terms,
                                                extract_article_no=extract_article_no,
                                                format_scope=format_scope, top=changed_top):
                terms = "、".join(t for _, t in h["matched"])
                out.append(_row("跨本", label, summary, "", h["line_number"], h["text"],
                                "跨本命中「%s」" % terms))
        else:
            # 一字之差沒有片段可搜，改用改動處左右文脈；whole_only=True 只用整段文脈
            # 當詞，不拆前後綴子詞——文脈本身只有 4 個字，拆出來的 2 字子詞辨識力低。
            context_terms = fuzzy.context_fragments(change.get("old_text") or "", change["new_text"], diff_runs)
            for h in fuzzy.find_by_changed_text(context_terms, target_paragraphs, exclude_index=0,
                                                contexts=contexts, synonyms=synonyms,
                                                normalize=normalize_terms,
                                                extract_article_no=extract_article_no,
                                                format_scope=format_scope, top=changed_top,
                                                whole_only=True):
                terms = "、".join(t for _, t in h["matched"])
                out.append(_row("跨本（文脈）", label, summary, "", h["line_number"], h["text"],
                                "跨本文脈「%s」" % terms))

        if sentence_threshold and sentence_threshold > 0:
            # 目前 cmd_batch 只把 type in ("added","modified") 且 new_text 非空的項目
            # 放進 source_changes，刪除段落不會走到這裡；這裡仍防禦式地把
            # 「deleted 旗標」與「new_text 空/缺」兩種可能表示法都當成「沒有新文」，
            # 跟 run_all.step_duplicates 的處理一致，避免日後放寬篩選時又比出空結果。
            cross_new_text = "" if change.get("deleted") or not change.get("new_text") else change["new_text"]
            sentences = fuzzy.changed_sentences(change.get("old_text") or "", cross_new_text, diff_runs)
            for h in fuzzy.find_by_sentence(sentences, target_paragraphs, threshold=sentence_threshold,
                                            top=top, exclude_index=0, contexts=contexts, synonyms=synonyms):
                out.append(_row("跨本（句）", label, dt._summary(h["changed_sentence"]), "", h["line_number"],
                                h["text"], "跨本句 %s 分：%s" % (h["sentence_score"], dt._summary(h["matched_sentence"], 30)),
                                "、".join(h.get("synonym_evidence") or [])))
    return out


# ---------------------------------------------------------------------------
# 引用連帶：B 本規格包的引用.csv 有沒有引用到 A 本被改的那條
# ---------------------------------------------------------------------------

def citation_links(source_name, source_changes, target_baseline, target_new_line_ids,
                   target_paragraphs):
    path = os.path.join(getattr(target_baseline, "version_dir", ""), "規格包", "引用.csv")
    if not os.path.isfile(path):
        return []
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    id_to_line = {}
    for line, ids in (target_new_line_ids or {}).items():
        for item_id in ids:
            id_to_line.setdefault(item_id, int(line))
    keys = []
    for change in source_changes:
        wanted = set()
        if change.get("ref"):
            wanted.add(normalize_article_no(change["ref"]))
        for pos in change.get("positions") or []:
            wanted.add(normalize_article_no(pos))
        keys.append((_label(source_name, change), {k for k in wanted if k}, dt._summary(change["new_text"])))
    src = normalize_article_no(source_name)
    out = []
    for r in rows:
        if (r.get("規章外引用") or "").strip() != "Y":
            continue
        names = [x.strip() for x in (r.get("規章名") or "").split(";")]
        numbers = [x.strip() for x in (r.get("條號") or "").split(";")]
        for index, name in enumerate(names):
            n = normalize_article_no(name)
            if not n or not (n == src or n in src or src in n):
                continue
            number = numbers[index] if index < len(numbers) else "-"
            line = id_to_line.get(r.get("條文ID"))
            # 真的規格包 引用.csv 沒有「全文」欄；定位不到草稿段落時退回基準的 條文.csv。
            text = (target_paragraphs[line - 1] if line else
                    (getattr(target_baseline, "by_id", {}).get(r.get("條文ID"), {}) or {}).get("全文", ""))
            tail = "" if line else "（無法定位到草稿段落）"
            if number and number != "-":
                nn = normalize_article_no(number)
                for label, wanted, summary in keys:
                    if any(nn == k or nn in k or k in nn for k in wanted):
                        out.append(_row("跨本引用", label, summary, r.get("條文ID", ""), line, text,
                                        "引用 %s %s%s" % (source_name, number, tail)))
            else:
                for label, wanted, summary in keys:
                    out.append(_row("跨本引用", label, summary, r.get("條文ID", ""), line, text,
                                    "引用 %s（未指明條號）%s" % (source_name, tail)))
    return out


# ---------------------------------------------------------------------------
# 摘要
# ---------------------------------------------------------------------------

def write_batch_summary(path, stats):
    """批次摘要。每本的數字之外，還要把各本的提醒彙整在同一張紙上。

    為什麼：批次跑十本時，第三本的「新舊版可能放反」印在畫面上早就被後面七本洗掉了。
    各本子資料夾裡雖然都有自己的 提醒.txt，但沒有人會一本一本去點開——
    會被看到的是這張摘要。
    """
    lines = ["批次摘要", ""]
    # 裁定 7：沒改的本要在摘要最上面單獨列一行。批次跑十本、每本三四行數字，
    # 「實質異動 0 處」那一行躺在第七本裡沒有人會注意到；而 0 異動最常見的原因
    # 不是這本真的沒改，是草稿還沒放進來或檔案拿錯。只列名字，不翻轉整批的結論。
    zero = [s["規章名"] for s in stats
            if s.get("零異動", not s.get("實質異動", 0))]
    lines.append("無異動 %d 本：%s" % (len(zero), "、".join(zero) or "無"))
    lines.append("（無異動請先確認草稿有沒有放進來、檔案有沒有拿錯；確實沒改的本不需要處理。）")
    lines.append("")
    for s in stats:
        lines.append("【%s】%s" % (s["規章名"], "" if s.get("有草稿") else "（沒有草稿，用舊版當草稿）"))
        lines.append("  實質異動 %d 處，候選 %d 列" % (s.get("實質異動", 0), s.get("候選", 0)))
        dist = s.get("來源分佈") or {}
        lines.append("  來源：%s" % ("、".join("%s %d" % kv for kv in sorted(dist.items())) or "無"))
        lines.append("  跨本來自：%s" % ("、".join(sorted(s.get("跨本來自") or [])) or "無"))
        lines.append("  提醒 %d 則（完整內容見本節下方的提醒彙整，或 <規章名>/審閱文件/提醒.txt）"
                     % len(s.get("提醒") or []))
        lines.append("")

    lines.append("─" * 30)
    lines.append("提醒彙整")
    lines.append("")
    total = sum(len(s.get("提醒") or []) for s in stats)
    if not total:
        lines.append("本次批次沒有任何提醒。")
    else:
        for s in stats:
            entries = s.get("提醒") or []
            lines.append("【%s】提醒 %d 則" % (s["規章名"], len(entries)))
            if not entries:
                lines.append("  （無）")
            for entry in entries:
                # 用 notices 自己那一支排版：提醒.txt 與這裡的格式要一模一樣，
                # 各寫一份遲早會漂開
                lines.append("  " + nt.format_line(entry))
            lines.append("")
    lines.append("提醒不等於錯誤，但每一則都要有人看過再決定要不要處理。")
    lines.append("")
    lines.append("每一本的連帶決定表在 <規章名>/填寫表單/；填完再跑 batch-apply、batch-finalize。最終仍需人工複核。")
    with io.open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")
    return path
