# -*- coding: utf-8 -*-
"""讀取 diff-cut S12 正式發布版，供 reg-diff 當舊版權威基準。"""

import csv
import hashlib
import io
import json
import os
import re
import bisect
import difflib


REQUIRED_SPEC_FILES = (
    "01_paragraphs.csv",
    "規格包/規格.json",
    "規格包/條文.csv",
    "規格包/重複組.csv",
    "規格包/引用.csv",
    "規格包/連帶.csv",
    "規格包/synonyms_建議.json",
    "規格包/README.md",
)

REVIEW_FIELDS = (
    "基準版本", "異動條文ID", "異動位置", "異動類型", "舊版段次", "新版段次",
    "關聯類型", "關聯條文ID", "關聯位置", "關聯條文全文", "外部規章",
    "外部條號", "規格包風險", "規格包說明", "人工判斷",
)


class BaselineReleaseError(ValueError):
    pass


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _read_json(path):
    try:
        with io.open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError) as exc:
        raise BaselineReleaseError("無法讀取 JSON：%s（%s）" % (path, exc))


def _read_csv(path, required):
    try:
        with io.open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            fields = reader.fieldnames or []
            rows = list(reader)
    except OSError as exc:
        raise BaselineReleaseError("無法讀取 CSV：%s（%s）" % (path, exc))
    missing = [name for name in required if name not in fields]
    if missing:
        raise BaselineReleaseError("%s 缺少欄位：%s"
                                   % (os.path.basename(path), "、".join(missing)))
    return fields, rows


def _inside(root, relative):
    if not relative or os.path.isabs(relative):
        raise BaselineReleaseError("發布清單含不安全路徑：%r" % relative)
    root = os.path.abspath(root)
    path = os.path.abspath(os.path.join(root, relative.replace("/", os.sep)))
    if os.path.normcase(os.path.commonpath((root, path))) != os.path.normcase(root):
        raise BaselineReleaseError("發布清單路徑超出版本目錄：%s" % relative)
    return path


def _split_ids(value):
    return [x.strip() for x in (value or "").split(";") if x.strip()]


class BaselineRelease(object):
    def __init__(self, release_root, version_dir, latest, manifest,
                 spec, items, impacts, canonical_paragraphs):
        self.release_root = release_root
        self.version_dir = version_dir
        self.latest = latest
        self.manifest = manifest
        self.spec = spec
        self.version = latest["正式版本"]
        self.items = items
        self.impacts = impacts
        self.canonical_paragraphs = canonical_paragraphs
        self.by_id = {row["條文ID"]: row for row in items}
        self.impact_by_id = {row["條文ID"]: row for row in impacts}
        self._line_items = {}
        self.binding_stats = {"已定位": 0, "無法定位": len(items)}

    @staticmethod
    def _normalized(text):
        return re.sub(r"\s+", "", text or "")

    def bind_paragraphs(self, paragraphs):
        """先對齊 S1 canonical 段落；對不上的條文只接受全文唯一命中。"""
        normalized = [self._normalized(text) for text in paragraphs]
        canonical = [self._normalized(text) for text in self.canonical_paragraphs]
        matcher = difflib.SequenceMatcher(None, canonical, normalized, autojunk=False)
        canonical_to_actual = {}
        for block in matcher.get_matching_blocks():
            for offset in range(block.size):
                canonical_to_actual[block.a + offset + 1] = block.b + offset + 1
        offsets = []
        cursor = 0
        for text in normalized:
            offsets.append(cursor)
            cursor += len(text)
        whole = "".join(normalized)
        mapped = 0
        unmapped = 0
        self._line_items = {}

        for row in self.items:
            expected = self._normalized(row.get("全文"))
            if not expected:
                unmapped += 1
                continue
            declared_start = int(row["起始序號"])
            declared_end = int(row["結束序號"])
            line_numbers = []
            line_numbers = [canonical_to_actual[line_no]
                            for line_no in range(declared_start, declared_end + 1)
                            if line_no in canonical_to_actual]
            line_numbers = sorted(set(line_numbers))

            if not line_numbers and whole:
                first = whole.find(expected)
                second = whole.find(expected, first + 1) if first >= 0 else -1
                if first >= 0 and second < 0:
                    last_char = first + max(len(expected) - 1, 0)
                    start_line = bisect.bisect_right(offsets, first)
                    end_line = bisect.bisect_right(offsets, last_char)
                    line_numbers = list(range(start_line, end_line + 1))

            if not line_numbers:
                unmapped += 1
                continue
            mapped += 1
            for line_no in line_numbers:
                self._line_items.setdefault(line_no, []).append(row)

        for rows in self._line_items.values():
            rows.sort(key=lambda r: (int(r["結束序號"]) - int(r["起始序號"]),
                                     -r["條文ID"].count("-"), r["條文ID"]))
        self.binding_stats = {"已定位": mapped, "無法定位": unmapped}
        if not mapped:
            raise BaselineReleaseError(
                "規格包沒有任何條文能以內容對回舊版；即使檔案SHA相同也禁止硬套段次")
        return dict(self.binding_stats)

    def item_ids_for_old_line(self, line_no):
        if not line_no:
            return []
        return [row["條文ID"] for row in self._line_items.get(int(line_no), [])]

    def annotate_results(self, results):
        """把舊版段次對回 diff-cut 條文 ID，並建立新版段次的可沿用 ID。"""
        new_line_ids = {}
        for result in results:
            ids = self.item_ids_for_old_line(result.get("old_index"))
            result["spec_ids"] = ids
            if ids and result.get("new_index"):
                new_line_ids.setdefault(int(result["new_index"]), []).extend(ids)
        for line_no, ids in list(new_line_ids.items()):
            new_line_ids[line_no] = list(dict.fromkeys(ids))
        return new_line_ids

    def change_label(self, result):
        ids = result.get("spec_ids") or []
        return "、".join(ids) if ids else (result.get("ref") or "")

    def apply_candidate_identity(self, candidate, new_line_ids):
        ids = new_line_ids.get(int(candidate.get("line_number") or 0), [])
        if ids:
            candidate["article_no"] = "、".join(ids)
            candidate["spec_ids"] = ids
        return candidate

    def _position(self, item_id):
        row = self.by_id.get(item_id)
        if not row:
            return ""
        return " / ".join(x for x in
                          (row.get("章標題"), row.get("節標題"), row.get("符號原文"))
                          if x)

    def review_rows(self, results):
        """將本次實質異動與既有連帶關係展成一列一關係的人工複核表。"""
        output = []
        for result in results:
            if result.get("type") in ("unchanged", "renumbered", "cosmetic"):
                continue
            if not result.get("spec_ids"):
                output.append({
                    "基準版本": self.version,
                    "異動條文ID": "",
                    "異動位置": "",
                    "異動類型": result.get("type", ""),
                    "舊版段次": result.get("old_index") or "",
                    "新版段次": result.get("new_index") or "",
                    "關聯類型": "無舊版條文ID",
                    "關聯條文ID": "",
                    "關聯位置": "",
                    "關聯條文全文": "",
                    "外部規章": "",
                    "外部條號": "",
                    "規格包風險": "",
                    "規格包說明": "新增條文或無法由舊版段次定位，須人工建立新ID並重跑diff-cut",
                    "人工判斷": "",
                })
                continue
            for item_id in result.get("spec_ids") or []:
                item = self.by_id[item_id]
                impact = self.impact_by_id.get(item_id, {})
                common = {
                    "基準版本": self.version,
                    "異動條文ID": item_id,
                    "異動位置": self._position(item_id),
                    "異動類型": result.get("type", ""),
                    "舊版段次": result.get("old_index") or "",
                    "新版段次": result.get("new_index") or "",
                    "規格包風險": impact.get("風險", "無"),
                    "規格包說明": impact.get("一句話說明", ""),
                    "人工判斷": "",
                }
                count_before = len(output)
                for relation in ("重複條文", "相似條文", "被誰引用", "我引用誰"):
                    for target_id in _split_ids(impact.get(relation, "")):
                        target = self.by_id.get(target_id, {})
                        row = dict(common)
                        row.update({
                            "關聯類型": relation,
                            "關聯條文ID": target_id,
                            "關聯位置": self._position(target_id),
                            "關聯條文全文": target.get("全文", ""),
                            "外部規章": "",
                            "外部條號": "",
                        })
                        output.append(row)
                laws = _split_ids(impact.get("外部規章", ""))
                articles = _split_ids(impact.get("條號", ""))
                for index, law in enumerate(laws):
                    row = dict(common)
                    row.update({
                        "關聯類型": "外部規章",
                        "關聯條文ID": "",
                        "關聯位置": "",
                        "關聯條文全文": "",
                        "外部規章": law,
                        "外部條號": articles[index] if index < len(articles) else "",
                    })
                    output.append(row)
                if len(output) == count_before:
                    row = dict(common)
                    row.update({
                        "關聯類型": "無已知連帶",
                        "關聯條文ID": "",
                        "關聯位置": "",
                        "關聯條文全文": "",
                        "外部規章": "",
                        "外部條號": "",
                    })
                    output.append(row)
        return output

    def write_review(self, results, output_path):
        rows = self.review_rows(results)
        with io.open(output_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=REVIEW_FIELDS, quoting=csv.QUOTE_ALL)
            writer.writeheader()
            writer.writerows(rows)
        return rows

    def write_review_table(self, results, base_path, path_for=None):
        """規格包連帶複核寫成 .xlsx（寫不出來才退 .csv）。回傳 (列, 實際寫出的路徑清單)。

        base_path 不帶副檔名。內容跟 write_review 一模一樣，只是換成給人看的格式
        ——這張表是複核時要一列一列看的，csv 在 Excel 裡沒有欄寬也不會換行。
        """
        import xlsx_writer as xw
        rows = self.review_rows(results)
        table = [[row.get(field, "") for field in REVIEW_FIELDS] for row in rows]
        written = xw.write_tables_or_csv(
            base_path, [("規格包連帶複核", list(REVIEW_FIELDS), table)],
            source="Step 1.2 連帶複核", path_for=path_for)
        return rows, written


def load_baseline_release(release_root, old_file, old_paragraphs=None):
    """只接受 S12 的 LATEST 入口，驗證後回傳 BaselineRelease。"""
    release_root = os.path.abspath(release_root)
    latest_path = os.path.join(release_root, "LATEST.json")
    if not os.path.isfile(latest_path):
        raise BaselineReleaseError(
            "找不到 %s；reg-diff 只接受 S12 LATEST.json，不接受鬆散規格包"
            % latest_path)
    latest = _read_json(latest_path)
    version = latest.get("正式版本")
    relative = latest.get("相對路徑")
    if not version or relative != version:
        raise BaselineReleaseError("LATEST.json 的正式版本與相對路徑不一致")
    version_dir = _inside(release_root, relative)
    if os.path.normcase(os.path.dirname(version_dir)) != os.path.normcase(release_root):
        raise BaselineReleaseError("LATEST.json 必須指向發布根目錄的直接子目錄")

    manifest_path = os.path.join(version_dir, "manifest.json")
    if not os.path.isfile(manifest_path):
        raise BaselineReleaseError("正式版本缺少 manifest.json：%s" % version_dir)
    if file_sha256(manifest_path) != latest.get("manifest_SHA256"):
        raise BaselineReleaseError("manifest.json 與 LATEST.json 記錄的 SHA-256 不符")
    manifest = _read_json(manifest_path)
    if manifest.get("正式版本") != version:
        raise BaselineReleaseError("manifest.json 的正式版本不符")
    validation = manifest.get("驗證", {})
    if validation.get("S6完整複核") is not True or validation.get("S10逐字對帳") is not True:
        raise BaselineReleaseError("正式版本沒有通過 S6 完整複核與 S10 對帳")

    artifacts = manifest.get("發布檔案")
    if not isinstance(artifacts, list):
        raise BaselineReleaseError("manifest.json 缺少發布檔案清單")
    artifact_names = set()
    for entry in artifacts:
        relative_path = entry.get("路徑")
        if relative_path in artifact_names:
            raise BaselineReleaseError("manifest.json 有重複發布路徑：%s" % relative_path)
        artifact_names.add(relative_path)
        path = _inside(version_dir, relative_path)
        if not os.path.isfile(path):
            raise BaselineReleaseError("正式版本缺少發布檔案：%s" % relative_path)
        if os.path.getsize(path) != entry.get("位元組"):
            raise BaselineReleaseError("發布檔案大小不符：%s" % relative_path)
        if file_sha256(path) != entry.get("SHA256"):
            raise BaselineReleaseError("發布檔案 SHA-256 不符：%s" % relative_path)
    missing = [name for name in REQUIRED_SPEC_FILES if name not in artifact_names]
    if missing:
        raise BaselineReleaseError("正式版本缺少規格包檔案：%s" % "、".join(missing))

    expected_source = manifest.get("來源", {}).get("SHA256")
    if not expected_source or file_sha256(old_file) != expected_source:
        raise BaselineReleaseError(
            "指定舊版不是此正式版本的原始檔（SHA-256 不符）；不可套用錯本規格包")

    spec_dir = os.path.join(version_dir, "規格包")
    _, canonical_rows = _read_csv(os.path.join(version_dir, "01_paragraphs.csv"),
                                  ("序號", "全文"))
    try:
        canonical_numbers = [int(row["序號"]) for row in canonical_rows]
    except ValueError:
        raise BaselineReleaseError("01_paragraphs.csv 的序號不是整數")
    if canonical_numbers != list(range(1, len(canonical_rows) + 1)):
        raise BaselineReleaseError("01_paragraphs.csv 的序號必須由 1 連續遞增")
    canonical_paragraphs = [row["全文"] for row in canonical_rows]
    spec = _read_json(os.path.join(spec_dir, "規格.json"))
    if spec.get("格式版本") != 1:
        raise BaselineReleaseError("不支援的規格包格式版本：%r" % spec.get("格式版本"))
    _, items = _read_csv(os.path.join(spec_dir, "條文.csv"),
                         ("條文ID", "章標題", "節標題", "符號原文",
                          "起始序號", "結束序號", "全文"))
    _, impacts = _read_csv(os.path.join(spec_dir, "連帶.csv"),
                           ("條文ID", "風險", "重複條文", "相似條文",
                            "被誰引用", "我引用誰", "外部規章", "條號", "一句話說明"))
    ids = [row["條文ID"] for row in items]
    if any(not x for x in ids) or len(ids) != len(set(ids)):
        raise BaselineReleaseError("條文.csv 有空白或重複條文ID")
    for row in items:
        try:
            start, end = int(row["起始序號"]), int(row["結束序號"])
        except ValueError:
            raise BaselineReleaseError("條文段次不是整數：%s" % row["條文ID"])
        if start < 1 or end < start:
            raise BaselineReleaseError("條文段次範圍無效：%s" % row["條文ID"])
    expected_count = spec.get("統計", {}).get("條文")
    if expected_count != len(items):
        raise BaselineReleaseError("規格.json 條文統計與條文.csv 不一致")
    impact_ids = [row["條文ID"] for row in impacts]
    if len(impact_ids) != len(set(impact_ids)) or any(x not in set(ids) for x in impact_ids):
        raise BaselineReleaseError("連帶.csv 有重複或不存在的條文ID")

    baseline = BaselineRelease(release_root, version_dir, latest, manifest,
                               spec, items, impacts, canonical_paragraphs)
    if old_paragraphs is not None:
        baseline.bind_paragraphs(old_paragraphs)
    return baseline
