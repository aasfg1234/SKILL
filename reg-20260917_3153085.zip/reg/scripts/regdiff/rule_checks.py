# -*- coding: utf-8 -*-
"""
Step 1.6：條文品質與風險檢查

跑完 Step 1 的精確比對之後跑這支。比對告訴你「哪裡改了」，這支告訴你
「這些改動裡有哪些特別該看」，以及「文件本身有沒有結構性的毛病」。

十項檢查，全部是程式碼做得到、不需要 LLM 判斷的：

需要新舊版比對（要給 --old）
    1. 責任用語變更   應→得、不得→得 這種修改是責任強度的實質變更
    2. 數值期間變更   十五日→三十日、五年→三年、十萬元→二十萬元
    3. 施行日期       改了實質條文，但施行日期條文沒動

只看新版就能查
    4. 條號健全性     重複、跳號、「之一」順序錯亂、空白條文
    5. 定義用語       定義了卻全文沒用到；改了定義但用到它的條文沒跟著看
    6. 外部法規引用   抽出所有「○○法第X條」，供人工核對母法是否已修正
    7. 待補殘留       TBD、XXX、待補、待確認 之類沒清掉的字
    8. 格式一致性     （一）與(一)混用、條號後分隔符不一致
    9. 用語混用       要保人／投保人、業務員／業務人員 這類同義詞混著用
   10. 附表引用       文中提到「附表一」，但全文找不到附表一

--------------------------------------------------------------------------
這支程式不做什麼
--------------------------------------------------------------------------
條文之間有沒有邏輯矛盾、修改有沒有逾越母法授權、修正理由該怎麼寫——
這些需要理解條文的意思，程式做不到，交給 SKILL.md 裡的 LLM 檢查層。
本程式只做「規則明確、結果可重複驗證」的部分。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
    python rule_checks.py 新版內規.docx --old 舊版內規.docx
    python rule_checks.py 新版內規.docx                  只做不需要比對的六項
    python rule_checks.py 新版內規.docx --terms 用語表.json   自訂用語混用檢查

輸出：條文檢查報告.xlsx（寫不出來才退 .csv），以及主控台的分級摘要。
"""

import argparse
import csv
import difflib
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, read_paragraphs_with_kinds,
                     build_hierarchy, diff_runs, resolve_output, load_term_groups,
                     normalize_for_compare, clean_law_name, mask_law_names,
                     extract_article_no, strip_article_no, display_path)
import diff_compare
import notices as nt
import xlsx_writer as xw

CN = "零〇一二三四五六七八九十百千萬兩"

HIGH, MEDIUM, LOW = "高", "中", "低"

# 「這一筆是從哪一種異動看出來的」。正常的逐段比對是「修改」；比對相似度太低、
# 判成一刪一增的那種整條改寫，配回同一條之後標這個字串，讓複核的人知道
# 原文與修改後文字是程式配的，不是比對直接配到的。
REWRITE_LABEL = "刪除＋新增（視為改寫）"
# 一個區塊裡剛好只有一刪一增，但條號不同、本文也不像時才用的標籤。
# 這種配對的把握比前一種低，報告上要看得出來差別。
REWRITE_DIFF_NO_LABEL = "刪除＋新增（視為改寫，條號不同）"
MODIFIED_LABEL = "修改"


def clip(text, limit):
    """報告裡的引文一律走這一支：換行先換成空白，真的截到字才加「…」。

    硬切有兩個毛病：一是截在句子中間卻沒有任何記號，看起來像句末標點被刪掉了，
    複核的人會以為那就是條文原樣；二是含換行的條文（<w:br/> 讀進來是 \\n）
    直接切下去，報告的「一列一行」被撐破，後面幾欄全部錯位。
    沒有截到的不加「…」——沒截還加，一樣是在騙人說後面還有字。
    """
    one_line = re.sub(r"\s+", " ", text or "").strip()
    return (one_line[:limit] + "…") if len(one_line) > limit else one_line


# 引文自己帶了標籤（「原文：」「修改後：」）時，report() 不要再疊一次「原文：」——
# 疊出來是「原文：修改後：本行應辦理」，看的人會以為舊版寫的就是那個新值，
# 這一行正好落在最高風險的那幾筆（責任用語變更）上。
_QUOTE_LABELS = ("原文：", "修改後：", "舊版：", "新版：")


def quote_line(quote):
    """報告上引文那一行要印的字（含標籤）。自己帶標籤的不再加「原文：」。"""
    text = quote or ""
    if any(text.startswith(label) for label in _QUOTE_LABELS):
        return text
    return "原文：%s" % text


def finding(severity, check, detail, index=None, ref="", quote="", action="",
            change_type=""):
    """統一的檢查結果格式。"""
    return {"severity": severity, "check": check, "index": index, "ref": ref,
            "quote": quote, "detail": detail, "action": action,
            "change_type": change_type}


# ---------------------------------------------------------------------------
# 0. 把「刪除＋新增」配回同一條（P11）
# ---------------------------------------------------------------------------
#
# 責任用語與數值期間這兩項本來都是 `if result["type"] != "modified": continue` 開頭。
# 一條被整條改寫時（「應於十五日內申報」→「本公司得於三十日內辦理申報事宜」），
# 兩段的相似度低於 diff_compare.PAIR_THRESHOLD，比對會判成「刪除一條、新增一條」，
# 這兩項就整組跳過——最該看的「十五日→三十日」「應→得」反而一筆都不報。
#
# 配對是**以區塊為單位**做的。比對把「這一段被換掉」判成一刪一增時，連續改寫的
# 好幾條會擠成一整塊（刪、刪、增、增），不是一刪一增交錯排。只看 results[i] 與
# results[i+1] 的話，中間那幾對永遠配不到——真實的修法一次改好幾條才是常態。
#
# 一個區塊 = 連續的 deleted／added（中間夾到 unchanged／modified 就斷開）。
# 區塊裡的配對規則刻意保守，而且只用來「多報一筆給人看」，不會改任何文字：
#   一、先配條號相同的。同一個「第三條」被刪掉又新增，實務上就是整條重寫。
#   二、剩下的用相似度配：拿掉條號之後的本文要達到 diff_compare.PAIR_THRESHOLD
#       ——那是比對自己用的同一條門檻，不另立標準。而且不准交叉（保持前後順序），
#       不然第一條會被配到最後一條的新文。
#   三、區塊裡剛好只有一刪一增，前兩輪又都沒配到（條號不同、本文也不像）：
#       這種多半是「同一條被改號又整條重寫」——條號變了所以第一輪配不到，
#       整條重寫所以第二輪配不到。沒有別的候選可以搶，門檻放低到
#       SINGLE_PAIR_THRESHOLD 再判一次，配到就標 REWRITE_DIFF_NO_LABEL，
#       讓人看得出這一對的把握比較低。
#
# 配錯的代價是條文檢查報告多一列要人看，配漏的代價是責任範圍或期間被改掉沒人看到。
# 兩者不對稱，所以寧可多配——但不能配到完全不相干的兩條，那會讓人開始不信任
# 【高】那一欄，連真的該看的也一起略過。

# 「區塊裡只有一刪一增」時才用的較低門檻。0.25 是這樣抓的：
#   真的改號又整條重寫（第三條 …十五日內申報 → 第四條 本公司得於三十日內辦理申報事宜）
#       拿掉條號後相似度 0.286
#   真的不相干（第六條 保險費逾期未繳…契約停止效力 → 第五條 投保人須於契約撤銷期間內以書面通知）
#       0.205
# 兩者中間取 0.25。這是本支最弱的一條規則（樣本少），所以配到的那一筆一定要
# 標成「條號不同」，不跟條號對得上的那種混在一起。
#
# 這個數字的來歷要講白，不然下一個人會以為它是統計出來的：
#   一、校準樣本只有上面那兩筆（假配對 0.205、真改寫 0.286）。兩筆不是分布，
#       是兩個點；0.25 是這兩點中間，不是什麼最佳切點。
#   二、已知的漏抓：長句改寫實測落在 0.2449，就差一點點，配不到。
#       也就是說「真的改號又整條重寫」的長條文本來就有一部分抓不到，
#       這一條規則是補網，不是保證。
#   三、日後要調整，**校準方向看「假配對率」，不是看漏抓率**。
#       把門檻往下拉可以多抓幾筆，但假的【高】警報會淹掉真警報——
#       人一旦開始不信任【高】那一欄，連真的該看的也會一起略過，
#       那比漏抓一筆更糟。要動這個數字，先蒐足夠多「改號又整條重寫」的真條文，
#       兩個方向的錯誤各算一次，再決定。
SINGLE_PAIR_THRESHOLD = 0.25


def _pair_ratio(old_text, new_text):
    """拿掉條號之後的本文相似度。用 diff_compare 自己那一支，門檻不另立一套。

    注意 diff_compare._ratio 低於 PAIR_THRESHOLD 時一律回 0.0（它用便宜的估算
    先擋掉明顯不像的），所以要判比它更低的門檻時得用 _raw_ratio。
    """
    return diff_compare._ratio(strip_article_no(old_text or ""),
                               strip_article_no(new_text or ""))


def _raw_ratio(old_text, new_text):
    """拿掉條號之後的本文相似度，不做 PAIR_THRESHOLD 的預先過濾。"""
    return difflib.SequenceMatcher(None, strip_article_no(old_text or ""),
                                   strip_article_no(new_text or "")).ratio()


def _rewrite_blocks(results):
    """把比對結果切成一段一段「連續的刪除／新增」。"""
    blocks = []
    current = []
    for item in results:
        if item["type"] in ("deleted", "added"):
            current.append(item)
        elif current:
            blocks.append(current)
            current = []
    if current:
        blocks.append(current)
    return blocks


def _pair_block(block):
    """一個區塊裡的配對，回傳 [(deleted, added, 標籤), ...]。"""
    deleted = [x for x in block
               if x["type"] == "deleted" and (x.get("old_text") or "")]
    added = [x for x in block
             if x["type"] == "added" and (x.get("new_text") or "")]
    if not deleted or not added:
        return []

    pairs = []
    taken = set()

    # 第一輪：條號一樣的直接配
    for d in deleted:
        old_no = extract_article_no(d["old_text"])
        if not old_no:
            continue
        for pos, a in enumerate(added):
            if pos in taken:
                continue
            if extract_article_no(a["new_text"]) == old_no:
                taken.add(pos)
                pairs.append((d, a, REWRITE_LABEL))
                break

    # 第二輪：剩下的用相似度配，不准交叉（配到的位置只能往後走）
    paired_deleted = {id(d) for d, _a, _label in pairs}
    floor = -1
    for d in deleted:
        if id(d) in paired_deleted:
            continue
        best_pos, best_score = None, 0.0
        for pos, a in enumerate(added):
            if pos in taken or pos <= floor:
                continue
            score = _pair_ratio(d["old_text"], a["new_text"])
            if score >= diff_compare.PAIR_THRESHOLD and score > best_score:
                best_pos, best_score = pos, score
        if best_pos is not None:
            taken.add(best_pos)
            floor = best_pos
            paired_deleted.add(id(d))
            pairs.append((d, added[best_pos], REWRITE_LABEL))

    # 第三輪：整個區塊就只有一刪一增，而且前兩輪都沒配到
    if (len(deleted) == 1 and len(added) == 1 and not pairs
            and _raw_ratio(deleted[0]["old_text"],
                           added[0]["new_text"]) >= SINGLE_PAIR_THRESHOLD):
        pairs.append((deleted[0], added[0], REWRITE_DIFF_NO_LABEL))
    return pairs


def logical_rewrites(results):
    """把「刪除＋新增」配成邏輯上的改寫，回傳假的 modified 結果清單。

    回傳的每一筆長得跟比對結果一樣（type／old_text／new_text／ref／index），
    另外帶 change_type，讓報告標得出這是配出來的、以及是靠什麼配的。
    原始的刪除列與新增列仍然留在對照表上，這裡不動它們。
    """
    pairs = []
    for block in _rewrite_blocks(results):
        for deleted, added, label in _pair_block(block):
            pairs.append({
                "type": "modified",
                "old_text": deleted["old_text"],
                "new_text": added["new_text"],
                "ref": added.get("ref") or deleted.get("ref") or "",
                "old_index": deleted.get("old_index"),
                "new_index": added.get("new_index"),
                "change_type": label,
            })
    return pairs


def _with_rewrites(results):
    """真的 modified 加上配出來的邏輯改寫。兩項高風險檢查都吃這一份。"""
    return list(results) + logical_rewrites(results)


# ---------------------------------------------------------------------------
# 1. 責任用語變更
# ---------------------------------------------------------------------------

# 強度分級：數字越大責任越重。用來判斷這次修改是鬆綁還是加嚴。
# 法制作業上「應」與「得」是天差地別的兩件事——「應」是義務，「得」是裁量權。
# 在一堆文字修改裡，這種兩個字的差異最容易被滑過去，但它才是真正的實質變更。
MODAL_STRENGTH = {
    "不得": 4, "非經": 4, "禁止": 4,
    "應": 3, "須": 3, "必須": 3, "應予": 3,
    "宜": 2, "原則上": 2,
    "得": 1, "可": 1, "得予": 1, "無須": 1, "免": 1,
}


# 這些詞裡面雖然有「應」「得」「可」「須」，但那不是責任用語，
# 是「應用程式」「取得」「可能」這種一般詞彙的一部分。
# 中文沒有空白斷詞，直接用 count() 會把它們全部算進去——實測「或行動應用程式」
# 就被誤判成「新增了一個應」。比對前先把這些複合詞遮掉。
_MODAL_DECOYS = [
    "應用", "應變", "應答", "應急", "應對", "應收", "應付", "應酬", "應試",
    "因應", "對應", "相應", "適應", "反應", "供應", "呼應", "感應", "響應",
    "取得", "獲得", "所得", "心得", "使得", "值得", "懂得", "覺得", "免得",
    "難得", "記得", "曉得", "捨得", "不得已", "得標", "得利",
    "可能", "可靠", "可疑", "可觀", "認可", "許可", "可行", "可否",
    "不可竄改", "不可抗力", "不可分", "不可歸責", "不可撤銷", "不可逆",
    "須知", "必須",   # 必須另行計數，避免被「須」重複算
    # 會計、繳費用語裡的「應X」是名詞，不是「應該」（實測 no 30）：
    # 「應繳金額」被算成新增了一個「應」，整條被報成【高】的責任用語變更。
    "應繳", "應計", "應攤",
]


def mask_compound_decoys(text):
    """只遮複合詞（應用程式、取得、不可竄改、應繳金額）。

    這一支可以安全地用在「接起來的差異片段」上：它比對的是實際存在的詞，
    不會因為兩段不相連的字被接在一起就生出新的比對結果。
    """
    for decoy in _MODAL_DECOYS:
        text = text.replace(decoy, "○" * len(decoy))
    return text


def mask_decoys(text):
    """把「看起來是責任用語、其實不是」的字遮成等長的替代字元。

    兩類：
      一、複合詞（應用程式、取得、不可竄改）——那幾個字不是責任用語。
      二、外部法規全銜（保險業務員管理規則）——那是引用的專有名詞，
          不是這份內規自己的用語。遮罩規則跟交叉引用檢查共用 _common 那一份，
          兩邊各寫一份的話，同一句話在兩張產出裡會被當成不同的東西。
    長度一律保住：遮短了，後面所有詞的位置就跟原文對不起來。

    **只能餵整段原文**。法規全銜是「連續的一串字」才成立的樣式，餵接起來的
    差異片段會判錯：一處刪掉「應」、另一處刪掉「法」，接起來變成「應法」，
    剛好符合法規名樣式而被整個遮掉，真正被拿走的那個義務就一筆都不報。
    差異片段請改用 mask_compound_decoys。
    """
    return mask_compound_decoys(mask_law_names(text))


def check_modal_changes(results):
    """
    在字級差異裡找出責任用語的變化。

    只看「真正被改掉的那幾個字」，不看整段，所以雜訊很低：
    一段話改了三十個字但沒動到「應」「得」，就不會被列出來。

    法規全銜的遮罩下在**比對之前的整段原文**，不是下在接起來的差異片段上：
    全銜要連續的一串字才成立，遮罩長度又跟原文等長，所以先遮再比對，
    位置一個都不會跑掉，而全銜內部的改動（保險法→保險業務員管理規則）
    會變成一串○對一串○，自然不會被當成責任用語變更。
    片段那一層只遮複合詞（mask_compound_decoys）。
    """
    findings = []
    # 整條改寫（比對判成一刪一增）也要進來，不然責任範圍被改掉沒人看得到。詳見 logical_rewrites。
    for result in _with_rewrites(results):
        if result["type"] != "modified":
            continue

        runs = diff_runs(mask_law_names(result["old_text"] or ""),
                         mask_law_names(result["new_text"] or ""))
        removed = mask_compound_decoys("".join(t for k, t in runs if k == "delete"))
        added = mask_compound_decoys("".join(t for k, t in runs if k == "insert"))
        if not removed.strip("○") and not added.strip("○"):
            continue

        changed = []
        for term in MODAL_STRENGTH:
            delta = added.count(term) - removed.count(term)
            if delta:
                changed.append((term, delta))
        if not changed:
            continue

        gone = [t for t, d in changed if d < 0]
        appeared = [t for t, d in changed if d > 0]
        direction = _strictness_direction(gone, appeared)

        findings.append(finding(
            HIGH if direction != "用語調整" else MEDIUM,
            "責任用語變更",
            "%s（%s → %s）" % (direction,
                              "、".join(gone) or "（無）",
                              "、".join(appeared) or "（無）"),
            index=result.get("new_index") or result.get("old_index"),
            ref=result.get("ref", ""),
            quote="原文：%s ／ 修改後：%s" % (clip(result["old_text"], 40),
                                            clip(result["new_text"], 40)),
            action="確認這是否為有意識的責任範圍調整，並在修正理由欄敘明",
            change_type=result.get("change_type") or MODIFIED_LABEL))
    return findings


def _strictness_direction(gone, appeared):
    """判斷是鬆綁、加嚴，還是只是換個說法。"""
    if not gone or not appeared:
        return "責任用語增刪"
    before = max(MODAL_STRENGTH[t] for t in gone)
    after = max(MODAL_STRENGTH[t] for t in appeared)
    if after < before:
        return "責任放寬（鬆綁）"
    if after > before:
        return "責任加重（加嚴）"
    return "用語調整"


# ---------------------------------------------------------------------------
# 2. 數值、期間、金額變更
# ---------------------------------------------------------------------------

_UNITS = ("個營業日", "個工作日", "個月", "營業日", "工作日", "日", "月", "年",
          "小時", "分鐘", "億元", "萬元", "元", "％", "%", "倍", "次", "人",
          "件", "成", "歲")

_NUMBER_RE = re.compile(r"([%s\d][%s\d,．.]*)\s*(%s)" % (CN, CN, "|".join(_UNITS)))


def check_numeric_changes(results):
    """
    在字級差異裡找出數字、期間、金額的變化。

    法遵複核時這是必看項：期間從十五日放寬成三十日、金額門檻從十萬提高到
    二十萬，都是實質變更，但夾在文字修改裡很容易被當成潤稿滑過去。
    """
    findings = []
    # 整條改寫（比對判成一刪一增）也要進來：期間、金額的門檻最常夾在整條重寫裡。
    for result in _with_rewrites(results):
        if result["type"] != "modified":
            continue

        # 這裡刻意比對「整段」而不是只看 diff 片段。
        # 「十五日」改成「三十日」時，單位「日」沒有變動，會留在相同片段裡，
        # 只掃描差異片段的話只看得到「十五」與「三十」，抓不到單位就整筆漏掉。
        #
        # 抽數字之前先正規化（只給比對用，報告引用的仍是原文）：抽出來的
        # (數字, 單位) 是拿字面比的，不正規化的話全形與半形會被當成兩個不同的值——
        #「３１日 → 31日」這種純字形統一會被列成【高】實質數值變更；更糟的是
        # 單位「％」配不上「%」，「３％至５％ → 3%至7%」會被拆成四筆增刪，
        # 真正變的那個 5%→7% 反而看不出來。
        old_numbers = _NUMBER_RE.findall(normalize_for_compare(result["old_text"]))
        new_numbers = _NUMBER_RE.findall(normalize_for_compare(result["new_text"]))
        removed = [n for n in old_numbers if n not in new_numbers]
        added = [n for n in new_numbers if n not in old_numbers]
        if not removed and not added:
            continue

        # 同單位的一減一增，配成「十五日 → 三十日」比較好讀
        pairs, leftover_removed, leftover_added = _pair_by_unit(removed, added)
        if not pairs and not leftover_removed and not leftover_added:
            continue

        parts = ["%s → %s" % (a, b) for a, b in pairs]
        parts += ["刪除 %s" % x for x in leftover_removed]
        parts += ["新增 %s" % x for x in leftover_added]

        findings.append(finding(
            HIGH, "數值期間變更", "；".join(parts),
            index=result.get("new_index") or result.get("old_index"),
            ref=result.get("ref", ""),
            quote="修改後：%s" % result["new_text"][:50],
            action="確認新的數值是否符合母法或主管機關規定的上下限",
            change_type=result.get("change_type") or MODIFIED_LABEL))
    return findings


def _pair_by_unit(removed, added):
    """把同單位的舊值新值配成一對。配不到的分別列出。"""
    remaining = list(added)
    pairs = []
    leftover_removed = []

    for value, unit in removed:
        match = next((item for item in remaining if item[1] == unit), None)
        if match:
            remaining.remove(match)
            if value != match[0]:
                pairs.append(("%s%s" % (value, unit), "%s%s" % (match[0], unit)))
        else:
            leftover_removed.append("%s%s" % (value, unit))

    return pairs, leftover_removed, ["%s%s" % (v, u) for v, u in remaining]


# ---------------------------------------------------------------------------
# 3. 施行日期
# ---------------------------------------------------------------------------

# 只認「真的在講生效時點」的句型，不是看到「施行／實施」就算。
# 「前項作業應於核定後實施。」「本要點實施前已受理之案件……」這些都含「實施」，
# 但它們不是施行日期條文——誤判會讓程式指著無關的條文說「施行日期沒改」，
# 那比不檢查更糟，人會開始不信任這一項。
_SELF_REF = r"本(?:要點|辦法|準則|規則|規定|細則|注意事項|程序|標準|章程|須知|原則|規章|表)"

_EFFECTIVE_RE = re.compile(
    # 一、「本要點……自／經／於……施行」——最常見的寫法
    _SELF_REF + r".{0,30}?[自經於].{0,20}?(?:施行|生效|實施)"
    # 二、「自發布日施行」——即使沒寫主詞，這個句型也不會是別的意思
    r"|自.{0,20}?(?:發布|公布|核定|頒布|函頒|即日|中華民國|民國|\d).{0,20}?(?:施行|生效)"
    # 三、直接寫「施行日期」「生效日期」
    r"|(?:施行|生效)日期")


def check_effective_date(paragraphs, results):
    """
    改了實質條文，施行日期條文卻原封不動——不一定是錯，但一定要問一句。

    內規修正通常要註明「本要點修正條文自○年○月○日施行」。忘了改的話，
    新規定的生效日會停留在上一版，實務上會出現「規定改了但沒生效」的爭議。
    """
    effective = [(idx, text) for idx, text in enumerate(paragraphs, 1)
                 if _EFFECTIVE_RE.search(text) and len(text) < 60]

    substantive = [r for r in results
                   if r["type"] in ("added", "deleted", "modified")]
    if not substantive:
        return []

    if not effective:
        return [finding(MEDIUM, "施行日期",
                        "全文找不到施行或生效日期的條文",
                        action="確認是否需要補一條「本要點修正條文自○年○月○日施行」")]

    # 施行日期條文只差一個全形空格不算「改過」，不然這一項會靜靜地放行，
    # 人以為日期改好了，實際上還停在上一版。
    # renumbered（只有條號位移、內容一個字沒動）跟 cosmetic 一樣不算「改過」：
    # 施行日期條文被往前遞補一號不代表日期改了，放行的話這一項會靜靜地說沒事。
    changed_effective = any(
        r["type"] not in ("unchanged", "cosmetic", "renumbered")
        and any(text == r.get("new_text") or text == r.get("old_text")
                for _, text in effective)
        for r in results)

    if changed_effective:
        return []

    idx, text = effective[-1]
    return [finding(MEDIUM, "施行日期",
                    "本次有 %d 處實質異動，但施行日期條文沒有跟著修改" % len(substantive),
                    index=idx, quote=text,
                    action="確認修正條文的生效日期是否需要另訂")]


# ---------------------------------------------------------------------------
# 4. 條號健全性
# ---------------------------------------------------------------------------

_ARTICLE_NO_RE = re.compile(r"^第\s*([%s\d]+)\s*條(?:\s*之\s*([%s\d]+))?" % (CN, CN))


def _cn_value(text):
    """中文數字轉整數，支援到千位（條號用得到「第一百十六條」）。"""
    if not text:
        return None
    if text.isdigit():
        return int(text)
    digits = {"零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "三": 3, "四": 4,
              "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    units = {"十": 10, "百": 100, "千": 1000}
    total, current = 0, 0
    for char in text:
        if char in digits:
            current = digits[char]
        elif char in units:
            current = current or 1
            total += current * units[char]
            current = 0
        else:
            return None
    return total + current


# 「第六條　（刪除）」這種刪除註記。依法制慣例，刪除某一條時保留條號並如此註記，
# 後面的條號才不會全部往前移、導致其他規章的引用全部指錯。
_DELETED_MARK_RE = re.compile(r"^[（(]\s*刪\s*除\s*[）)]\s*$")


def check_article_integrity(paragraphs, old_paragraphs=None, kinds=None,
                            old_kinds=None):
    """
    條號本身的健全性：重複、跳號、「之一」順序錯亂、只有條號沒有內容。

    這幾種毛病在 50 頁的內規裡靠肉眼幾乎抓不到，但送出去會被挑。

    old_paragraphs：給了舊版的話，會分辨跳號是「本次修訂造成的」還是
    「上一版就已經存在」。既有的斷號每次修訂都報一次是純雜訊，
    使用者看久了會連真正該看的那筆一起略過。
    """
    findings = []
    contexts = build_hierarchy(paragraphs, kinds)
    seen = {}
    sequence = []

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        if context["level"] != "條":
            continue
        match = _ARTICLE_NO_RE.match(text)
        if not match:
            continue

        main = _cn_value(match.group(1))
        sub = _cn_value(match.group(2)) if match.group(2) else 0
        label = context["article"]

        if label in seen:
            findings.append(finding(
                HIGH, "條號重複",
                "%s 出現兩次（第 %d 段與第 %d 段）" % (label, seen[label], idx),
                index=idx, ref=label, quote=text[:40],
                action="確認是否誤植，或其中一條應改號"))
        else:
            seen[label] = idx

        body = text[match.end():].strip(" 　:：")
        if not body:
            findings.append(finding(
                MEDIUM, "空白條文", "%s 只有條號、沒有內容" % label,
                index=idx, ref=label,
                action="若為刪除，請改為「%s　（刪除）」的標準寫法" % label))

        is_deleted_mark = bool(_DELETED_MARK_RE.match(body))
        sequence.append((main, sub, label, idx, text, is_deleted_mark))

    existing_gaps = _gap_articles(old_paragraphs, old_kinds) if old_paragraphs else set()
    findings.extend(_check_sequence(sequence, existing_gaps))
    findings.extend(_check_tail(sequence, old_paragraphs, old_kinds))
    return findings


def _article_numbers(paragraphs, kinds=None):
    """一份文件裡「條」層級宣告的主條號序列（不含「之一」那種附條）。

    只看 build_hierarchy 判成「條」的段落：舊版裡的引用句（「第二十條之規定…」）
    不是宣告，算進來會生出一段假的條號序列，跳號判斷跟著錯。
    """
    numbers = []
    for text, context in zip(paragraphs or [], build_hierarchy(paragraphs or [], kinds)):
        if context["level"] != "條":
            continue
        match = _ARTICLE_NO_RE.match(text)
        if match and not match.group(2):
            value = _cn_value(match.group(1))
            if value is not None:
                numbers.append(value)
    return numbers


def _gap_articles(paragraphs, kinds=None):
    """算出一份文件裡條號斷掉的地方，用來判斷斷號是不是本來就有。

    含頭：第一條就不見（整份從第三條開始）也是斷號。原本只用
    zip(numbers, numbers[1:]) 兩兩相比，序列的第一個數字永遠沒有「前一個」可比，
    「刪掉第一條」——最常見的刪除之一——因此在新舊兩邊都算不出來：
    新版報不出跳號，舊版也給不出「本來就這樣」的對照。
    尾巴不在這裡：一份文件自己看不出來最後一條之後還該不該有下一條，
    那要跟舊版的最大條號比，見 _check_tail。
    """
    numbers = _article_numbers(paragraphs, kinds)
    missing = set()
    if numbers and numbers[0] > 1:
        missing.update(range(1, numbers[0]))
    for previous, current in zip(numbers, numbers[1:]):
        if current > previous + 1:
            missing.update(range(previous + 1, current))
    return missing


def _check_tail(sequence, old_paragraphs=None, old_kinds=None):
    """含尾：舊版的最後一條在新版不見了。

    這要有舊版才看得出來——一份文件停在第十七條，光看它自己完全正常，
    只有跟舊版的第十八條一比才知道最後一條被整條刪掉了。
    刪最後一條跟刪中間一條同樣要保留條號註記「（刪除）」，否則別的規章引用
    「第十八條」會指到不存在的地方。
    """
    if not old_paragraphs:
        return []
    old_numbers = [n for n in _article_numbers(old_paragraphs, old_kinds)]
    new_numbers = [main for main, sub, _, _, _, _ in sequence
                   if main is not None and not sub]
    if not old_numbers or not new_numbers:
        return []
    old_max, new_max = max(old_numbers), max(new_numbers)
    if old_max <= new_max:
        return []
    missing = ["第%s條" % _int_to_cn(n) for n in range(new_max + 1, old_max + 1)]
    last_index = max(idx for main, sub, _, idx, _, _ in sequence
                     if main == new_max and not sub)
    return [finding(
        MEDIUM, "條號跳號",
        "舊版有 第%s條，新版最後一條是 第%s條，末尾缺 %s"
        % (_int_to_cn(old_max), _int_to_cn(new_max), "、".join(missing)),
        index=last_index, ref="第%s條" % _int_to_cn(new_max),
        action="若為本次刪除，依慣例應保留條號並註記「（刪除）」")]


def _check_sequence(sequence, existing_gaps=frozenset()):
    """檢查條號順序：跳號、「之一」跑到本條前面。

    含頭：以前 previous_main 起手是 None，第一條要等到第二條出現才開始比，
    「整份從第三條開始」（第一條、第二條被整條刪掉）一則都不會報。
    現在序列的第一個主條號一出現就先跟「第一條」對一次。
    """
    findings = []
    previous_main = None

    for main, sub, label, idx, text, is_deleted_mark in sequence:
        if main is None:
            continue

        if sub and previous_main != main:
            # 「第五條之一」前面必須先有「第五條」，否則就是接錯位置
            findings.append(finding(
                HIGH, "條號順序",
                "%s 出現在 第%s條 之前或找不到本條" % (label, main),
                index=idx, ref=label, quote=text[:40],
                action="「之一」的條文應緊接在本條之後"))

        if previous_main is None and not sub and main > 1:
            # 整份的第一個主條號就不是第一條：前面那幾條被整條刪掉了。
            gap_numbers = list(range(1, main))
            missing = ["第%s條" % _int_to_cn(n) for n in gap_numbers]
            pre_existing = existing_gaps and set(gap_numbers) <= existing_gaps
            findings.append(finding(
                LOW if pre_existing else MEDIUM, "條號跳號",
                "全文從 %s 開始，前面缺 %s%s"
                % (label, "、".join(missing),
                   "（舊版即已如此，非本次修訂造成）" if pre_existing else ""),
                index=idx, ref=label, quote=text[:40],
                action="舊版即有，本次可不處理" if pre_existing
                       else "若為本次刪除，依慣例應保留條號並註記「（刪除）」"))

        if previous_main is not None and not sub and main > previous_main + 1:
            gap_numbers = list(range(previous_main + 1, main))
            missing = ["第%s條" % _int_to_cn(n) for n in gap_numbers]
            # 舊版就已經斷在同樣的位置，代表是上一版留下來的，不是這次造成的。
            # 這種每次修訂都報一次只會變成雜訊，降級但不隱藏。
            pre_existing = existing_gaps and set(gap_numbers) <= existing_gaps
            findings.append(finding(
                LOW if pre_existing else MEDIUM, "條號跳號",
                "%s 之後直接跳到 %s，中間缺 %s%s"
                % ("第%s條" % _int_to_cn(previous_main), label, "、".join(missing),
                   "（舊版即已如此，非本次修訂造成）" if pre_existing else ""),
                index=idx, ref=label,
                action="舊版即有，本次可不處理" if pre_existing
                       else "若為本次刪除，依慣例應保留條號並註記「（刪除）」"))

        if not sub:
            previous_main = main
    return findings


def _int_to_cn(value):
    """整數轉中文數字，支援到 999。"""
    digits = "零一二三四五六七八九"
    if value < 10:
        return digits[value]
    if value < 20:
        return "十" + (digits[value - 10] if value % 10 else "")
    if value < 100:
        tens, ones = divmod(value, 10)
        return digits[tens] + "十" + (digits[ones] if ones else "")
    hundreds, rest = divmod(value, 100)
    text = digits[hundreds] + "百"
    if rest == 0:
        return text
    if rest < 10:
        return text + "零" + digits[rest]
    return text + _int_to_cn(rest)


# ---------------------------------------------------------------------------
# 5. 定義用語
# ---------------------------------------------------------------------------

_DEFINITION_PATTERNS = [
    re.compile(r"本(?:要點|辦法|準則|規則|規定|作業程序)所稱\s*[「『]?([^「」『』，,：:]{2,12})[」』]?\s*[，,：:]?\s*(?:指|係指|謂)"),
    re.compile(r"[「『]([^「」『』]{2,12})[」』]\s*[，,：:]?\s*(?:指|係指|謂)"),
]


def check_definitions(paragraphs, results, kinds=None):
    """
    定義用語的兩種毛病：

    1. 定義了卻全文沒用到 —— 通常是條文刪掉了、定義忘了刪
    2. 定義本身被改了 —— 用到這個詞的所有條文都要重看一次，因為它們的意思跟著變了

    第二種是實務上最常出包的：改了「網路投保」的定義，卻只想到要改網路投保章，
    忘了核保章、理賠章也有十幾條寫著「網路投保」。
    """
    findings = []
    contexts = build_hierarchy(paragraphs, kinds)
    definitions = {}

    for idx, text in enumerate(paragraphs, 1):
        for pattern in _DEFINITION_PATTERNS:
            match = pattern.search(text)
            if match:
                definitions.setdefault(match.group(1), (idx, text))
                break

    changed_texts = {r["new_text"] for r in results
                     if r["type"] == "modified" and r.get("new_text")}

    for term, (def_index, def_text) in definitions.items():
        users = [idx for idx, text in enumerate(paragraphs, 1)
                 if idx != def_index and term in text]

        if not users:
            findings.append(finding(
                LOW, "贅定義", "定義了「%s」，但全文其他地方沒有用到" % term,
                index=def_index, ref=contexts[def_index - 1]["ref"],
                quote=def_text[:44],
                action="確認是否為條文刪除後遺留的定義"))
            continue

        if def_text in changed_texts:
            refs = [contexts[i - 1]["ref"] or ("第%d段" % i) for i in users]
            findings.append(finding(
                HIGH, "定義變更連動",
                "「%s」的定義被修改，全文另有 %d 處用到這個詞：%s"
                % (term, len(users), "、".join(refs[:12])
                   + ("…" if len(refs) > 12 else "")),
                index=def_index, ref=contexts[def_index - 1]["ref"],
                quote=def_text[:44],
                action="逐條確認這些條文在新定義下是否仍然成立"))
    return findings


# ---------------------------------------------------------------------------
# 6. 外部法規引用
# ---------------------------------------------------------------------------

_EXTERNAL_RE = re.compile(
    r"([一-鿿]{2,14}?(?:法|條例|辦法|準則|規則|要點|注意事項|自律規範))"
    r"第\s*([%s\d]+)\s*條(?:\s*之\s*[%s\d]+)?" % (CN, CN))

# 法規名稱前面常常黏著動詞或連接詞：「本要點依保險法第X條」「及金融消費者保護法第Y條」。
# 不切掉的話會抓出「本要點依保險法」，還會因為開頭是「本要點」而被誤判成自我引用整筆漏掉。
#
# 剝法本身搬到 _common.clean_law_name，跟 renumber 的交叉引用判定共用同一份。
# 兩邊各寫一份的話，同一句話在條文檢查報告裡被當成「保險法」、在交叉引用檢查裡
# 卻被當成本文自己的引用，兩張產出自相矛盾。


def _clean_law_name(name):
    """把法規名稱前面黏到的動詞、連接詞剝掉。剝完不像法規名稱就回空字串。

    以前剝不出來會退回原樣，結果「其處理方法第三條」這種日常用語也被列進
    外部法規清單，叫人去查一部不存在的法規。
    """
    return clean_law_name(name)


_SELF_NAMES = ("本要點", "本辦法", "本準則", "本規則", "本規定", "本作業程序",
               "本法", "本條例")


def check_external_refs(paragraphs, kinds=None):
    """
    抽出所有外部法規的引用，列成清單。

    程式判斷不了「保險法第一百四十八條之三有沒有修正過」——那要查法規資料庫。
    但程式可以把該查的清單一次列齊，避免人工翻 50 頁去找。
    內規因母法修正而需連動修正，是最常見的漏改來源之一。
    """
    contexts = build_hierarchy(paragraphs, kinds)
    seen = {}

    for idx, text in enumerate(paragraphs, 1):
        for match in _EXTERNAL_RE.finditer(text):
            law = _clean_law_name(match.group(1))
            if not law or law in _SELF_NAMES:
                continue
            citation = law + match.group(0)[len(match.group(1)):]
            seen.setdefault(citation, []).append(
                (idx, contexts[idx - 1]["ref"] or ("第%d段" % idx)))

    if not seen:
        return []

    findings = []
    for citation, places in sorted(seen.items()):
        refs = "、".join(ref for _, ref in places[:8])
        findings.append(finding(
            MEDIUM, "外部法規引用",
            "引用 %s（%d 處：%s%s）"
            % (citation, len(places), refs, "…" if len(places) > 8 else ""),
            index=places[0][0], ref=places[0][1], quote=citation,
            action="查證該法條現行條文，確認引用的條號與內容仍然正確"))
    return findings


# ---------------------------------------------------------------------------
# 7. 待補殘留
# ---------------------------------------------------------------------------

_PLACEHOLDER_RE = re.compile(
    r"(TBD|TODO|XXX|ＸＸＸ|待補|待確認|待議|待訂|暫定|\?\?\?|【待[^】]*】)",
    re.IGNORECASE)


def check_placeholders(paragraphs, kinds=None):
    """草稿階段的佔位文字沒清乾淨就送出去，是很現實的意外。"""
    contexts = build_hierarchy(paragraphs, kinds)
    findings = []
    for idx, text in enumerate(paragraphs, 1):
        for match in _PLACEHOLDER_RE.finditer(text):
            findings.append(finding(
                HIGH, "待補殘留", "條文裡還留著「%s」" % match.group(0),
                index=idx, ref=contexts[idx - 1]["ref"], quote=text[:44],
                action="送出前務必清除或補實"))
    return findings


# ---------------------------------------------------------------------------
# 8. 格式一致性
# ---------------------------------------------------------------------------

def check_format_consistency(paragraphs):
    """
    全形半形混用、條號後分隔符不一致。

    這種問題不影響法律效力，但法制作業複核時會被退件重打，
    而且在 50 頁的文件裡靠肉眼找非常花時間。
    """
    findings = []

    full_width = sum(1 for p in paragraphs if re.match(r"^（", p))
    half_width = sum(1 for p in paragraphs if re.match(r"^\(", p))
    if full_width and half_width:
        findings.append(finding(
            LOW, "格式一致性",
            "目的括號全形半形混用：全形（）%d 段、半形() %d 段"
            % (full_width, half_width),
            action="統一為其中一種，通常內規慣用全形"))

    separators = {}
    for text in paragraphs:
        match = re.match(r"^第[%s\d]+條(?:之[%s\d]+)?(.)" % (CN, CN), text)
        if match:
            char = match.group(1)
            name = {" ": "半形空白", "　": "全形空白"}.get(char, "無空白")
            if char not in (" ", "　"):
                name = "無空白"
            separators[name] = separators.get(name, 0) + 1

    if len(separators) > 1:
        detail = "、".join("%s %d 條" % (k, v) for k, v in sorted(separators.items()))
        findings.append(finding(
            LOW, "格式一致性", "條號後的分隔方式不一致：%s" % detail,
            action="統一條號與條文之間的分隔（內規慣用全形空白）"))

    return findings


# ---------------------------------------------------------------------------
# 9. 用語混用
# ---------------------------------------------------------------------------

# 同一份內規裡混用同義詞，複核時會被要求統一。這裡放保險/金融內規常見的幾組，
# 各單位用語習慣不同，可以用 --terms 指定自己的對照表覆蓋。
#
# 每一組的「第一個」就是建議統一的用字，順序有意義，不要隨意調換。
# 不採用「哪個出現次數多就建議哪個」——法制作業慣用「不得」而非「不可」、
# 「應」而非「須」，跟出現頻率無關。實測就踩過這個坑：測試文本裡「不可竄改」
# 出現一百多次，程式因此建議把「不得」全部改成「不可」，方向完全相反。
DEFAULT_TERM_GROUPS = [
    ["要保人", "投保人"],
    ["被保險人", "受保人"],
    ["業務人員", "業務員", "招攬人員"],
    ["保險費", "保費"],
    ["保險契約", "保險合約"],
    ["本公司", "本行", "本銀行"],
    ["訂定", "制定"],
    ["應", "須"],
    ["得", "可"],
    ["不得", "不可"],
]


def check_term_consistency(paragraphs, groups=None):
    """同一組同義詞在全文混著用，就列出來讓人決定統一成哪一個。"""
    groups = groups or DEFAULT_TERM_GROUPS
    # 同樣要遮掉「不可竄改」「應用程式」「取得」這類複合詞。
    # 不遮的話，測試文本裡「不可竄改」出現一百多次，程式會反過來
    # 建議把「不得」統一成「不可」。
    # 法規全銜也一起遮：一份用「業務人員」的內規只要引用到「保險業務員管理規則」，
    # 全銜裡那三個字就被算成混用，每跑一次固定誤報一筆（實測 no 26）。
    whole = mask_decoys("\n".join(paragraphs))
    findings = []

    for group in groups:
        counts = {term: whole.count(term) for term in group}
        used = {term: n for term, n in counts.items() if n}
        if len(used) < 2:
            continue

        # 「不得」會被「得」的計數涵蓋，要扣掉才不會誤報
        if "得" in used and "不得" in counts:
            used["得"] = used["得"] - counts["不得"]
            if used["得"] <= 0:
                del used["得"]
        if len(used) < 2:
            continue

        detail = "、".join("%s %d 次" % (t, n)
                           for t, n in sorted(used.items(), key=lambda x: -x[1]))
        preferred = next(t for t in group if t in used)
        findings.append(finding(
            LOW, "用語混用", "%s（建議統一為「%s」）" % (detail, preferred),
            action="確認是否為有意區分；若無，統一用語"))
    return findings


# ---------------------------------------------------------------------------
# 10. 附表引用
# ---------------------------------------------------------------------------

_ATTACHMENT_REF_RE = re.compile(r"(附表|附件|附錄)\s*([%s\d]+)" % CN)


def check_attachments(paragraphs, kinds=None):
    """文中寫「詳如附表一」，但全文找不到附表一——附件漏附是很常見的疏漏。"""
    contexts = build_hierarchy(paragraphs, kinds)
    referenced = {}
    defined = set()

    for idx, text in enumerate(paragraphs, 1):
        for match in _ATTACHMENT_REF_RE.finditer(text):
            name = "%s%s" % (match.group(1), match.group(2))
            # 段落開頭就是「附表一」，視為附表本體而非引用
            if text.startswith(name):
                defined.add(name)
            else:
                referenced.setdefault(name, []).append(idx)

    findings = []
    for name, places in sorted(referenced.items()):
        if name in defined:
            continue
        findings.append(finding(
            MEDIUM, "附表引用",
            "條文提到「%s」，但全文找不到該附表的本體（%d 處引用）" % (name, len(places)),
            index=places[0], ref=contexts[places[0] - 1]["ref"],
            action="確認附表是否漏附，或引用名稱是否誤植"))
    return findings


# ---------------------------------------------------------------------------
# 輸出
# ---------------------------------------------------------------------------

SEVERITY_ORDER = {HIGH: 0, MEDIUM: 1, LOW: 2}

# 十項檢查，以及每一項會吐出哪些「檢查項目」字串。
# 報告要逐項講「通過／未檢查／有問題」，就得分得出「這一項沒有發現」與
# 「這一項根本沒跑」——沒有這張表就只能印一句「都沒有發現問題」，而那句話在
# 沒給舊版時是假的：責任用語、數值期間、施行日期三項根本沒有檢查。
CHECK_ITEMS = [
    ("責任用語變更", ("責任用語變更",)),
    ("數值期間變更", ("數值期間變更",)),
    ("施行日期", ("施行日期",)),
    ("條號健全性", ("條號重複", "空白條文", "條號順序", "條號跳號")),
    ("定義用語", ("贅定義", "定義變更連動")),
    ("外部法規引用", ("外部法規引用",)),
    ("待補殘留", ("待補殘留",)),
    ("格式一致性", ("格式一致性",)),
    ("用語混用", ("用語混用",)),
    ("附表引用", ("附表引用",)),
]

# 沒有給舊版時跑不了的項目與原因。rule_checks 單獨執行（沒有 --old）時傳給 report()。
# 定義用語也要列：沒有舊版時 check_definitions 只做得了「贅定義」那一半，
# 真正高風險的「定義變更連動」（改了定義，用到這個詞的條文全部要重看）做不了——
# 印「通過」等於說那一半也看過了。
NO_OLD_REASON = "沒有給舊版，比不出前後差異；請加 --old 舊版檔"
NO_OLD_DEFINITION_REASON = "沒有舊版，只做贅定義檢查，定義變更連動未檢查"
NO_OLD_SKIPPED = [("責任用語變更", NO_OLD_REASON),
                  ("數值期間變更", NO_OLD_REASON),
                  ("施行日期", NO_OLD_REASON),
                  ("定義用語", NO_OLD_DEFINITION_REASON)]


def _tri_state(findings, skipped):
    """每一項的三態：(項目, "通過"／"未檢查（原因）"／"有問題，共 N 項")。"""
    reasons = dict(skipped or [])
    counts = {}
    for item in findings:
        counts[item["check"]] = counts.get(item["check"], 0) + 1
    rows = []
    for name, kinds in CHECK_ITEMS:
        total = sum(counts.get(kind, 0) for kind in kinds)
        if name in reasons:
            # 只做了一半的項目（例：沒有舊版時的定義用語）還是可能有發現，
            # 那幾筆要講出來，但整項的結論仍然是「未檢查」。
            extra = "；另發現 %d 項" % total if total else ""
            rows.append((name, "未檢查（%s）%s" % (reasons[name], extra)))
            continue
        rows.append((name, "有問題，共 %d 項" % total if total else "通過"))
    return rows


def report(findings, skipped=None):
    """依嚴重程度分級印出，並逐項給「通過／未檢查／有問題」的結論。

    skipped：[(檢查項目, 沒檢查的原因), ...]。沒跑到的項目一律印「未檢查」並說明
    原因——印「都沒有發現問題」等於告訴使用者程式看過了，那種假的安心比不檢查更危險。
    """
    print("\n" + "=" * 62)
    print("條文品質與風險檢查")
    print("=" * 62)

    print("\n【十項檢查結論】")
    for name, state in _tri_state(findings, skipped):
        print("  %s：%s" % (name, state))

    if not findings:
        if skipped:
            print("\n有檢查的項目都沒有發現問題；上面標「未檢查」的項目本次沒有跑到。")
        else:
            print("\n十項檢查全部做過，沒有發現問題。")
        print("=" * 62)
        return

    grouped = {}
    for item in findings:
        grouped.setdefault(item["severity"], []).append(item)

    labels = {HIGH: "高（送出前一定要處理或確認）",
              MEDIUM: "中（建議確認）",
              LOW: "低（格式與用語，不影響效力）"}

    for severity in (HIGH, MEDIUM, LOW):
        items = grouped.get(severity)
        if not items:
            continue
        print("\n【%s】共 %d 項" % (labels[severity], len(items)))
        for item in items:
            location = item["ref"] or (
                "第%d段" % item["index"] if item["index"] else "全文")
            tail = ("（%s）" % item["change_type"]
                    if item.get("change_type") in (REWRITE_LABEL, REWRITE_DIFF_NO_LABEL)
                    else "")
            print("  ● [%s] %s%s" % (item["check"], location, tail))
            print("      %s" % item["detail"])
            if item["quote"]:
                print("      %s" % quote_line(item["quote"]))
            if item["action"]:
                print("      建議：%s" % item["action"])

    print("\n" + "-" * 62)
    counts = {s: len(grouped.get(s, [])) for s in (HIGH, MEDIUM, LOW)}
    print("合計 %d 項（高 %d、中 %d、低 %d）"
          % (len(findings), counts[HIGH], counts[MEDIUM], counts[LOW]))
    print("提醒：這十項是規則明確、程式查得出來的部分。條文之間的邏輯矛盾、")
    print("      是否逾越母法授權，程式查不到，仍需人工或 LLM 複核。")
    print("=" * 62)


CSV_COLUMNS = ["嚴重程度", "檢查項目", "位置", "段次", "說明", "相關原文",
               "建議處理", "修改類型", "處理情形（人工填寫）"]

# 提醒列的建議處理欄一律寫這句：提醒不是條文的毛病，是「這次執行發生了什麼事」。
NOTICE_ACTION = "確認這則提醒會不會影響本次比對結果，再決定要不要處理"


def report_rows(findings, notices=None):
    """條文檢查報告的資料列。xlsx 版與 csv 退路共用一份，兩張表才不會漂開。"""
    rows = []
    for item in sorted(findings, key=lambda x: SEVERITY_ORDER[x["severity"]]):
        rows.append([
            item["severity"], item["check"],
            item["ref"] or "", item["index"] or "",
            item["detail"], item["quote"], item["action"],
            item.get("change_type") or "", "",
        ])
    for entry in (notices or []):
        rows.append([
            entry.get("等級") or nt.REMINDER, entry.get("來源") or "執行提醒",
            "", "", entry.get("文字") or "", "", NOTICE_ACTION, "", "",
        ])
    return rows


def write_report_table(findings, base_path, notices=None, path_for=None):
    """寫條文檢查報告（.xlsx；寫不出來才退 .csv）。base_path 不帶副檔名。

    notices 是這次執行累積的提醒，以「提醒」等級附在最後。
    為什麼提醒也要進這張表：畫面上的提醒會被後面的輸出洗掉，而這張表是複核時
    一定會打開的檔案。提醒.txt 是完整留底，這裡是「順手就會看到」的那一份。

    回傳實際寫出的路徑清單。
    """
    written = xw.write_tables_or_csv(
        base_path, [("條文檢查報告", CSV_COLUMNS, report_rows(findings, notices))],
        source="Step 1.6 檢查報告", path_for=path_for)
    for path in written:
        # display_path：走 AtomicWrites 時收到的是「正式路徑 + .tmp」（見 fuzzy 同一段）
        print("\n已產生檢查報告：%s" % display_path(path))
    return written


def main():
    setup_console()
    parser = argparse.ArgumentParser(description="Step 1.6：條文品質與風險檢查")
    parser.add_argument("regulation_file", help="新版內規檔案")
    parser.add_argument("--old", default=None,
                        help="舊版檔案；有給才能做責任用語、數值變更、施行日期三項檢查")
    parser.add_argument("--terms", default=None,
                        help="自訂用語對照表（JSON，格式為二維陣列）")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    print("正在讀取：%s" % args.regulation_file)
    paragraphs, kinds = read_paragraphs_with_kinds(args.regulation_file)
    print("全文共 %d 段。" % len(paragraphs))

    groups = load_term_groups(args.terms, DEFAULT_TERM_GROUPS)

    old_paragraphs, old_kinds = (read_paragraphs_with_kinds(args.old) if args.old
                                 else (None, None))

    findings = []
    skipped = []
    findings += check_article_integrity(paragraphs, old_paragraphs, kinds, old_kinds)
    findings += check_external_refs(paragraphs, kinds)
    findings += check_placeholders(paragraphs, kinds)
    findings += check_format_consistency(paragraphs)
    findings += check_term_consistency(paragraphs, groups)
    findings += check_attachments(paragraphs, kinds)

    if args.old:
        print("正在比對舊版：%s" % args.old)
        results = diff_compare.compare_paragraphs(old_paragraphs, paragraphs,
                                                  old_kinds, kinds)
        findings += check_modal_changes(results)
        findings += check_numeric_changes(results)
        findings += check_effective_date(paragraphs, results)
        findings += check_definitions(paragraphs, results, kinds)
    else:
        findings += check_definitions(paragraphs, [], kinds)
        skipped = NO_OLD_SKIPPED
        nt.notice(nt.REMINDER,
                  "沒有給 --old，責任用語變更、數值期間變更、施行日期無法檢查，"
                  "定義用語也只做得了贅定義那一半；這幾項都是高風險項目，"
                  "強烈建議加上舊版一起跑", "Step 1.6")

    report(findings, skipped=skipped)
    collected = nt.collected()
    if findings or collected:
        base = os.path.splitext(
            resolve_output(args.outdir, args.prefix, "條文檢查報告.xlsx"))[0]
        write_report_table(findings, base, notices=collected)
    return findings


if __name__ == "__main__":
    main()
