# -*- coding: utf-8 -*-
"""
Step 1.5：款目編號重編與交叉引用檢查

什麼時候要用：
你在內規裡刪掉或插入了某一款、某一目之後，跑這支程式。

刪掉「二、」之後會發生三件事，一件比一件嚴重：

1. 編號斷掉        剩下 一、三、四、  ── 肉眼容易漏看，尤其 50 頁的內規
2. 對照表被灌爆    手動把 三、改成二、、四、改成三、之後，對照表會多出一堆
                   「修改」，但那些條文一個字都沒動，只是編號位移
3. 交叉引用失效    別的條文寫「依前條第二款規定」，原本的第二款已經不存在，
                   這句話現在指到完全不同的內容 ── 這是真正會出事的地方

這支程式處理前兩件，第三件明確列出來給人工判斷。

--------------------------------------------------------------------------
為什麼「條」預設不重編
--------------------------------------------------------------------------
法制作業慣例上，刪除某一條時，後面的條號不跟著往前遞補；被刪的條保留條號並
註記「第○條　（刪除）」。這樣做的理由很實際：全文與其他規章裡引用「第五十條」
的地方，不會因為前面刪了一條就全部指錯。新增條文也是同樣道理，才會有
「第五條之一」這種寫法。

所以本程式預設只重編「款」與「目」（它們是條的內部結構，重編不影響外部引用），
條號一律不動，只在發現斷號時提醒你要不要補「（刪除）」註記。
條號一律不重編，也沒有旗標可以打開；要遞補請人工處理並自行複核引用。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
    python renumber.py 新版內規.docx
        檢查模式：只報告問題，不動檔案

    python renumber.py 新版內規.docx --apply
        重編款目編號，輸出「重編後_新版內規.docx」

    python renumber.py 新版內規.docx --apply --rewrite-refs
        連同交叉引用一起改寫（只改「被引用的條款目還在、只是換號」那種；
        引用到已刪除款目的一律不動，強制人工處理；
        「個人資料保護法第五條」這種外部法規的條號一律不動）

    python renumber.py 新版內規.docx --old 舊版內規.docx
        額外比對舊版，找出被整條刪掉的條號，提醒補「（刪除）」註記，
        並且比出「舊條號 → 新條號」，才判得了條層級的交叉引用。
        沒給舊版就一律印「未檢查」，不會印「沒有受影響」這種假的安心。
"""

import argparse
import difflib
import os
import re
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, read_paragraphs_with_kinds,
                     build_hierarchy, cn_from_int, cn_to_int, resolve_output,
                     strip_article_no, normalize_for_compare,
                     is_external_reference, POINT_RE, HAS_DOCX, _CN_NUM)
import notices as nt

# 中文數字的「字元集合」，只給正規表示式的字元類別用（[%s] 那個位置），
# 不要拿它當「第 n 個字是數字 n」的查表——「零」在最前面，索引會整排錯開。
# 要數字轉中文一律用 int_to_cn。
#
# 為什麼要含百／千／零／〇：以前這裡是「一二三四五六七八九十」，
# `_TOKEN_RE` 與 `scan_reference_drift` 的條號樣式因此認不得「第一百二十條」——
# `parse_references` 對三位數條號回空清單，報告卻照印「條層級引用：通過」；
# 更糟的是「第一百二十條第三款」的前半段配不上，後半段的「第三款」變成裸款號，
# 被當成「本條第三款」錯掛到引用所在的那一條。三位數條號在真資料很常見
# （300 條的作業要點），這是靜默漏判。
# 跟 `_common._CN_NUM` 共用同一個常數，兩邊各寫一份遲早會不一致。
CN = _CN_NUM

_CLAUSE_RE = re.compile(r"^([%s]+)(\s*、)" % CN)
# 目分成兩個數字體系：「(一)」是目，「(1)」是目底下再一層。
# 以前兩種收在同一個 _ITEM_RE 裡，plan_renumber 把它們併成一串重編，
# --apply-renumber 就會把「(1) 全職人員…」實際改寫成「(二) 全職人員…」——
# 兩個層級被壓成一層，原文被毀，而且會先誤報一次「編號重複」（實測 idx 45）。
# 重編一律用原本的體系：中文的回中文，阿拉伯的回阿拉伯，永遠不跨體系。
_ITEM_CN_RE = re.compile(r"^([（(])\s*([%s]+)\s*([）)])" % CN)
_ITEM_AR_RE = re.compile(r"^([（(])\s*([0-9０-９]+)\s*([）)])")
_ITEM_RE = re.compile(r"^([（(])\s*([%s\d０-９]+)\s*([）)])" % CN)   # 兩種都收，只給取號用
# 點：「1.」「1、」「１．」。跟 _common.build_hierarchy 判「點」層用的是同一個物件，
# 兩邊各寫一份的話，改了一邊另一邊會對不上（scan 抓不到號碼，重編就靜默跳過）。
_POINT_RE = POINT_RE

_ITEM_STYLE_CN = "目（中文）"
_ITEM_STYLE_AR = "目（阿拉伯）"


def _item_style_of(text):
    """這一段的目是哪一種數字體系，抓不到回 None。"""
    if _ITEM_CN_RE.match(text):
        return _ITEM_STYLE_CN
    if _ITEM_AR_RE.match(text):
        return _ITEM_STYLE_AR
    return None


def _item_pattern(style):
    return _ITEM_AR_RE if style == _ITEM_STYLE_AR else _ITEM_CN_RE


def _number_text(style, value):
    """重編後要寫回原文的號碼：阿拉伯體系寫阿拉伯，其餘寫中文。"""
    return str(value) if style == _ITEM_STYLE_AR else int_to_cn(value)


# 中文數字轉阿拉伯數字，支援到 999。實作在 _common.cn_to_int：
# 層級脈絡判斷「編號有沒有重新起算」用的是同一份，兩邊各寫一份遲早會不一致。
cn_to_int = cn_to_int


# 阿拉伯數字轉中文數字，支援到 999（百位照法規寫法：一百十二、一百零五）。
# 實作在 _common.cn_from_int：層級脈絡的項次也要用同一份，兩邊各寫一份的結果是
# _common 那份只到 99，100 以上吐出「第十十五項」、110 以上直接當掉。
int_to_cn = cn_from_int


# ---------------------------------------------------------------------------
# 掃描目前的編號狀態
# ---------------------------------------------------------------------------

def scan(paragraphs, kinds=None):
    """
    走一遍全文，回傳每一段的編號資訊。

    kinds 是 read_paragraphs_with_kinds 回傳的來源種類（"p"／"cell"），
    往下傳給 build_hierarchy：表格儲存格不能被算成前一條的項，
    否則重編與交叉引用檢查看到的層級跟修正對照表不一樣。

    每個元素：
        {"index": 段次(從1), "level": 條/款/點/目/其他, "article": 所屬條號,
         "written": 目前寫的號碼(整數), "clause_written": 所屬款的號碼,
         "point_written": 所屬「1.」點的號碼, "item_parent": 阿拉伯目所屬的中文目號碼,
         "item_style": 目的數字體系（中文／阿拉伯）,
         "clause_serial"／"point_serial": 所屬的款／點是同一個位置的第幾組}

    組序號來自 build_hierarchy：同一項裡被「本公司辦理前項事項時……」這種沒有編號的
    段落分成兩組的款，各自從「一、」重新起算。不分群的話會誤報「編號重複」，
    --apply-renumber 還會把第二組實際改成「三、四、」——原文就毀了。

    點與目的「所屬」資訊要記下來，重編才分得出「同一款底下不同小群的 (1)」——
    不分群的話兩群的 (1) 會被併成一串，第二群的 (1) 會被改寫成 (3)（實測 idx 45／50）。
    """
    contexts = build_hierarchy(paragraphs, kinds)
    entries = []
    clause_written = None
    point_written = None
    item_parent = None       # 目前所在的中文目，阿拉伯目掛在它底下
    paragraph_no = 1         # 條底下第幾項；每一項的款目都是重新起算的
    clause_serial = 1        # 這一項裡的款是第幾組（編號重新起算就 +1）
    point_serial = 1         # 這一款裡的點是第幾組

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        level = context["level"]
        written = None
        item_style = None

        if level == "條":
            clause_written = point_written = item_parent = None
            paragraph_no = 1
            clause_serial = point_serial = 1
        elif level == "項":
            # 新的一項開始，上一項的款目作廢。不歸零的話，第二項的「(一)(二)」
            # 會被接到第一項的「(一)(二)」後面，先誤報「編號重複」，
            # --apply-renumber 再把它們實際改寫成「(三)(四)」，原文就毀了。
            clause_written = point_written = item_parent = None
            paragraph_no += 1
            clause_serial = point_serial = 1
        elif level == "款":
            match = _CLAUSE_RE.match(text)
            written = cn_to_int(match.group(1)) if match else None
            clause_written = written
            point_written = item_parent = None
            clause_serial = context.get("group_serial", 1)
            point_serial = 1
        elif level == "點":
            match = _POINT_RE.match(text)
            written = cn_to_int(unicodedata.normalize("NFKC", match.group(1))) if match else None
            point_written = written
            item_parent = None
            point_serial = context.get("group_serial", 1)
        elif level == "目":
            item_style = _item_style_of(text)
            match = _ITEM_RE.match(text)
            written = cn_to_int(unicodedata.normalize("NFKC", match.group(2))) if match else None
            if item_style == _ITEM_STYLE_CN:
                item_parent = written

        entries.append({
            "index": idx, "level": level, "article": context["article"],
            "written": written, "clause_written": clause_written,
            "point_written": point_written, "item_style": item_style,
            "paragraph_no": paragraph_no,
            "clause_serial": clause_serial, "point_serial": point_serial,
            # 中文目自己就是群的頭，不掛在別的目底下
            "item_parent": None if item_style == _ITEM_STYLE_CN else item_parent,
            # 沒有「第X條」的規章（作業手冊常見），款目是在章／節底下重新起算的，
            # 重編時要用章節當範圍，不能全文一串編到一百多。
            "scope": (context.get("chapter", ""), context.get("section", "")),
        })
    return entries


def plan_renumber(paragraphs, entries):
    """
    算出「哪一段的編號要從幾號改成幾號」。

    款：同一條底下的款，由上而下重編為 一、二、三……
    目：同一條同一款底下的目，重編為 (一)(二)(三)……

    回傳 (變更清單, 款對照表, 目對照表)。
    對照表是給交叉引用檢查用的：{(條號, 舊號): 新號}
    """
    changes = []
    clause_map = {}
    item_map = {}
    if not numbering_check_applicable(entries):
        return changes, clause_map, item_map

    clause_counter = {}
    item_counter = {}

    for entry in entries:
        article = entry["article"]
        # 有「第X條」就以條為範圍；沒有就以章／節為範圍
        group = _numbering_group(entry)

        if entry["level"] == "款":
            clause_counter[group] = clause_counter.get(group, 0) + 1
            new_no = clause_counter[group]
            if entry["written"] is not None:
                clause_map[(article, entry["written"])] = new_no
            if entry["written"] != new_no:
                changes.append({
                    "index": entry["index"], "level": "款",
                    "article": article,
                    "old": entry["written"], "new": new_no,
                    "old_text": paragraphs[entry["index"] - 1],
                    "new_text": _CLAUSE_RE.sub(
                        lambda m: int_to_cn(new_no) + m.group(2),
                        paragraphs[entry["index"] - 1], count=1),
                })

        elif entry["level"] == "目":
            style = entry.get("item_style") or _ITEM_STYLE_CN
            key = _item_group_key(entry, group)
            item_counter[key] = item_counter.get(key, 0) + 1
            new_no = item_counter[key]
            if entry["written"] is not None:
                map_key = (article, entry["clause_written"], entry["written"])
                # 交叉引用寫的是「第二目」這種中文寫法，中文體系優先佔位，
                # 阿拉伯體系只在中文沒佔到時補上，避免兩種體系互相覆蓋。
                if style == _ITEM_STYLE_CN:
                    item_map[map_key] = new_no
                else:
                    item_map.setdefault(map_key, new_no)
            if entry["written"] != new_no:
                number = _number_text(style, new_no)
                changes.append({
                    "index": entry["index"], "level": "目", "style": style,
                    "article": article,
                    "old": entry["written"], "new": new_no,
                    "old_text": paragraphs[entry["index"] - 1],
                    "new_text": _item_pattern(style).sub(
                        lambda m: m.group(1) + number + m.group(3),
                        paragraphs[entry["index"] - 1], count=1),
                })

    return changes, clause_map, item_map


def _item_group_key(entry, group):
    """目重新起算的範圍。

    中文目掛在（範圍, 款, 點）底下；阿拉伯目再往下掛一層，多帶所屬的中文目。
    少了「點」與「所屬中文目」這兩段，同一款底下不同小群的 (1) 會被併成一串，
    第二群的 (1) 就會被改寫成 (3)——那是實測 idx 45 毀掉原文的那條路。
    """
    style = entry.get("item_style") or _ITEM_STYLE_CN
    base = (style, group, entry.get("clause_written"),
            entry.get("point_written"), entry.get("point_serial") or 1)
    if style == _ITEM_STYLE_AR:
        return base + (entry.get("item_parent"),)
    return base


def find_numbering_gaps(entries):
    """
    找出編號本身就有問題的地方（斷號、重號、沒從一開始）。

    這是「使用者刪了款但沒重編」的直接證據，也是最容易在 50 頁內規裡漏看的東西。
    """
    problems = []
    if not numbering_check_applicable(entries):
        return problems
    groups = {}
    for entry in entries:
        # 跟 plan_renumber 同一套：有「第X條」以條為範圍，沒有就以章／節為範圍。
        # 作業手冊每章各自從「一、」起算，全文合成一組會被誤判成「編號重複」。
        group = _numbering_group(entry)
        if entry["level"] == "款":
            groups.setdefault(("款", group), []).append(entry)
        elif entry["level"] == "目":
            # 分群方式跟 plan_renumber 一模一樣：兩種數字體系、不同的點與中文目
            # 各自成群，否則會把「(一)(1)(2)(二)(1)」誤報成編號重複。
            groups.setdefault(("目",) + _item_group_key(entry, group),
                              []).append(entry)

    for key, group in groups.items():
        written = [e["written"] for e in group]
        if any(w is None for w in written):
            continue
        expected = list(range(1, len(written) + 1))
        if written == expected:
            continue

        if len(set(written)) != len(written):
            reason = "編號重複"
        elif written[0] != 1:
            reason = "沒有從第一%s開始" % key[0]
        else:
            reason = "編號不連續（中間有缺號，通常是刪除後沒有重編）"

        problems.append({
            "level": key[0], "article": group[0]["article"],
            "style": group[0].get("item_style"),
            "written": written, "expected": expected, "reason": reason,
            "first_index": group[0]["index"],
        })
    return problems


def numbering_check_applicable(entries):
    """款目編號檢查／重編只適用於「第X條」底下有款目的規章。

    作業手冊型文件沒有條，款目在標題（含程式看不到的小標）底下各自重新起算，
    無論用條還是章／節分組都會誤報「編號重複」、也會提出錯的重編。真資料實測：
    1,347 段的手冊用章／節分組仍誤報 14 處。所以沒有任何一條的文件直接跳過。"""
    return any(e.get("article") for e in entries)


def _numbering_group(entry):
    """編號重新起算的範圍：有條用（條, 項次），沒有條用 (章, 節)。
    plan_renumber 與 find_numbering_gaps 共用。

    項次一定要進來：一條有兩項時，每一項的款都是從「一、」重新起算的，
    合成一組會誤報「編號重複」，重編還會把第二項的款目實際改號（毀原文）。
    同一項裡被沒有編號的段落分成兩組的款（build_hierarchy 的「（第N組）」）也一樣，
    所以組序號也要進來。"""
    serial = entry.get("clause_serial") or 1
    article = entry.get("article") or ""
    if article:
        return (article, entry.get("paragraph_no") or 1, serial)
    return ("§",) + tuple(entry.get("scope") or ("", "")) + (serial,)


# 舊條有這麼多比例的字出現在同一條新條裡，就算「被併進去」而不是「被刪掉」。
# 0.6 是這樣抓的：真的併條時舊條文幾乎原封不動搬過去，覆蓋率都在 0.9 以上；
# 只是碰巧用詞相近的兩條通常落在 0.3 以下，0.6 留了很寬的安全帶。
MERGE_COVERAGE = 0.6


def _article_texts(paragraphs, kinds=None):
    """把全文切成一條一條：[(條號, 這一條的原文全文)]。原文保留原字。

    整條的文字（條文本體加底下的款目項）才是配對的依據。只拿第一段比，
    兩條開頭都寫「本公司辦理下列事項：」就會互相配錯。
    """
    units = []
    current = None
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] == "條" and context["article"]:
            if current is None or context["article"] != current[0]:
                current = [context["article"], [strip_article_no(text)]]
                units.append(current)
                continue
        if current is not None:
            current[1].append(text)
    return [(article, "".join(parts)) for article, parts in units]


def _article_units(paragraphs, kinds=None):
    """比對用的條文：條號加上正規化過的全文。

    只差全半形或空白的同一條要配得起來，所以比對前一律正規化；
    要印出來或寫進產出檔的一律用 _article_texts 的原文。
    """
    return [(article, normalize_for_compare(text))
            for article, text in _article_texts(paragraphs, kinds)]


def _coverage(old_body, new_body):
    """舊條的文字有多少比例出現在新條裡（0.0~1.0）。用來認「併條」。"""
    if not old_body:
        return 0.0
    matcher = difflib.SequenceMatcher(None, old_body, new_body, autojunk=False)
    matched = sum(block.size for block in matcher.get_matching_blocks())
    return matched / float(len(old_body))


def _align_block(old_chunk, new_chunk):
    """對一個被改過的區塊做一對一對齊。

    回傳 ([(舊區塊內序號, 新區塊內序號或 None), ...], 有沒有走帶狀對齊)。

    對齊演算法跟修正對照表用的是同一支（diff_compare.align_chunk）：保持前後順序、
    總相似度最高。兩邊各寫一份的話，對照表說「這兩條是同一條」、交叉引用卻說
    「這一條被刪了」，兩張產出自相矛盾。

    align_chunk 遇到大區塊會自己印「改用帶狀對齊」的提醒，那段話講的是修正對照表，
    對條號對照是錯的描述，而且一次執行會被印好幾遍。用 diff_compare 自己的收集
    機制先接住，由呼叫端改印一句講條號對照的。
    """
    import diff_compare

    outer = diff_compare._banded_notices
    diff_compare._banded_notices = []
    try:
        pairs = diff_compare.align_chunk(old_chunk, new_chunk)
        banded = bool(diff_compare._banded_notices)
    finally:
        diff_compare._banded_notices = outer

    # align_chunk 回傳的是文字，同一份文件裡可能有兩條文字一模一樣，
    # 所以照順序走游標還原到底是第幾條，不要拿文字回去查。
    result = []
    oi = nj = 0
    for old_text, new_text in pairs:
        if old_text is not None and new_text is not None:
            result.append((oi, nj))
            oi += 1
            nj += 1
        elif old_text is not None:
            result.append((oi, None))
            oi += 1
        else:
            nj += 1
    return result, banded


def _prefer_same_article(old_units, new_units, unpaired, new_indices,
                         old_to_new, new_to_old):
    """同號優先：條號一樣、內容又對得上的，一定是同一條。

    align_chunk 只看文字分數，併條時常常把「新的第四條」配給「舊的第五條」
    （併進去之後新條比較長，跟長的那一條分數比較高），結果報成
    「第四條不見了、併入第四條」——那句話沒有人看得懂。

    unpaired 會被就地改掉：換掉的那一條進來、原本佔位的那一條出去。
    """
    for i in list(unpaired):
        article, old_body = old_units[i]
        for j in new_indices:
            new_article, new_body = new_units[j]
            if not _same_article(new_article, article):
                continue
            if _coverage(old_body, new_body) < MERGE_COVERAGE:
                continue
            holder = new_to_old.get(j)
            if holder is not None:
                del old_to_new[holder]
                unpaired.append(holder)
            old_to_new[i] = j
            new_to_old[j] = i
            unpaired.remove(i)
            break


def plan_article_map(old_paragraphs, new_paragraphs,
                     old_kinds=None, new_kinds=None):
    """
    用「內容」把舊版的條配到新版的條，回傳 {舊條號: {"new":…, "merged_into":…}}。

    new 是新版對應的條號，配不到就是 None；merged_into 是「被併進哪一條」。

    為什麼不能只比條號集合：條號預設不重編，但實務上使用者常常自己先遞補過，
    也常常把兩條併成一條。只比集合的話，「第十條改叫第九條」會被報成
    「第十條被刪除」，人就會去補一個根本不該補的「（刪除）」註記；
    而別的條文寫的「第十條」其實已經指到不同的內容，反而沒人講。
    """
    old_units = _article_units(old_paragraphs, old_kinds)
    new_units = _article_units(new_paragraphs, new_kinds)
    if not old_units:
        return {}
    old_bodies = [body for _, body in old_units]
    new_bodies = [body for _, body in new_units]

    # 先用 difflib 的 opcodes 把「一模一樣的條」整段對掉（跟 _compare_paragraphs
    # 同一套做法），只有真的被改過的 replace 區塊才送進相似度對齊。
    # 不做這一步的話，一份 300 條的規章即使只刪了 3 條，也要算 300x297 格相似度
    # （實測 1.9 秒，而且一定會觸發帶狀對齊的提醒），那個提醒還是假警報。
    old_to_new = {}
    new_to_old = {}
    unpaired = []
    banded = False
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(
            None, old_bodies, new_bodies).get_opcodes():
        if tag == "equal":
            for offset in range(i2 - i1):
                old_to_new[i1 + offset] = j1 + offset
                new_to_old[j1 + offset] = i1 + offset
        elif tag == "delete":
            unpaired.extend(range(i1, i2))
        elif tag == "insert":
            pass                    # 新版多出來的條，沒有舊條要對過去
        else:
            block_pairs, block_banded = _align_block(old_bodies[i1:i2],
                                                     new_bodies[j1:j2])
            banded = banded or block_banded
            block_unpaired = []
            for local_i, local_j in block_pairs:
                if local_j is None:
                    block_unpaired.append(i1 + local_i)
                else:
                    old_to_new[i1 + local_i] = j1 + local_j
                    new_to_old[j1 + local_j] = i1 + local_i
            _prefer_same_article(old_units, new_units, block_unpaired,
                                 range(j1, j2), old_to_new, new_to_old)
            unpaired.extend(block_unpaired)

    if banded:
        nt.notice(nt.REMINDER,
                  "改動的條很多（舊 %d 條、新 %d 條），條號對照改用帶狀對齊；"
                  "若有整章搬移，條層級的交叉引用判斷可能配錯，請人工核對"
                  % (len(old_units), len(new_units)), "Step 0.5")
    unpaired.sort()

    mapping = {}
    for i, (article, _body) in enumerate(old_units):
        j = old_to_new.get(i)
        mapping[article] = {"new": new_units[j][0] if j is not None else None,
                            "merged_into": None}

    # 配不到的再問一次：它是不是整段被搬進某一條新條裡（併條）。
    for i in unpaired:
        article, old_body = old_units[i]
        best_article, best = "", 0.0
        for j, (new_article, new_body) in enumerate(new_units):
            # 併進去的話新條一定至少跟舊條一樣長，短的直接跳過，省下大量比對
            if len(new_body) < len(old_body) * 0.9:
                continue
            # 而且併條的新條除了吃下這一條，自己原本的內容還在，所以一定比它
            # 配到的那條舊文長出一截。只看「像不像」的話，兩條碰巧寫得像的短條
            # （「甲事項規定如下。」對「乙事項規定如下。」）會被誤報成併條，
            # 真正被刪掉的那一條就沒有人去補「（刪除）」註記了。
            holder = new_to_old.get(j)
            grown = len(new_body) - (len(old_units[holder][1])
                                     if holder is not None else 0)
            if grown < len(old_body) * MERGE_COVERAGE:
                continue
            score = _coverage(old_body, new_body)
            if score > best:
                best_article, best = new_article, score
        if best >= MERGE_COVERAGE:
            mapping[article]["merged_into"] = best_article
    return mapping


def find_changed_paragraphs(old_paragraphs, new_paragraphs,
                            old_kinds=None, new_kinds=None):
    """回傳「本次有改過」的新版段次集合（1 起算）。

    比的是去掉條號、正規化過的本體：條號本身會因為重編而變，那不算改內容。
    一段的本體在舊版裡找得到（不管在哪一段）就算沒改。

    用途是條層級引用的保險絲：重編之後，「作者已經改好的新號」跟「還沒改的舊號」
    在文字上一模一樣，程式分不出來。分不出來的時候唯一安全的說法是
    「這一段本次有改，你自己確認」，不能猜。
    """
    old_bodies = set()
    for text in old_paragraphs:
        old_bodies.add(normalize_for_compare(strip_article_no(text)))
    changed = set()
    for idx, text in enumerate(new_paragraphs, 1):
        if normalize_for_compare(strip_article_no(text)) not in old_bodies:
            changed.add(idx)
    return changed


def find_deleted_articles(old_paragraphs, new_paragraphs,
                          old_kinds=None, new_kinds=None, article_map=None):
    """
    比對新舊版，找出新版找不到的舊條號。

    回傳 [{"article": 舊條號, "status": "刪除"／"併入", "into": 新條號}]。

    條號預設不重編，所以刪掉之後新版會出現條號斷點。依法制慣例，
    真的刪掉應該保留條號並註記「第○條　（刪除）」，讓後面的條號維持不變。
    但「併入別條」不是刪除——補「（刪除）」註記反而是錯的，所以分開報。

    article_map 給了就直接用，省得同一次執行把條號對照算兩遍。
    """
    if article_map is None:
        article_map = plan_article_map(old_paragraphs, new_paragraphs,
                                       old_kinds, new_kinds)
    result = []
    for article, info in article_map.items():
        if info["new"] is not None:
            continue
        if info["merged_into"]:
            result.append({"article": article, "status": "併入",
                           "into": info["merged_into"]})
        else:
            result.append({"article": article, "status": "刪除", "into": ""})
    return result


# ---------------------------------------------------------------------------
# 交叉引用
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 交叉引用解析
# ---------------------------------------------------------------------------
#
# 這一段是整支程式風險最高的地方。內規裡的引用寫法遠比「第五條第二款」複雜：
#
#     前條第三款及第四款      ← 「及第四款」的範圍要延續前面的「前條」
#     第五條第二款至第四款    ← 範圍寫法，實際指的是第二、三、四款
#     依前款規定              ← 相對引用，要看它自己在第幾款
#     前二項                  ← 往前數兩個
#     依第五條規定            ← 只到條層級
#
# 每一種漏掉，就是一處指錯的引用送進正式修法文件。所以這裡用逐字掃描配上
# 範圍狀態，而不是一條大正規表示式硬套。
#
# 判定結果分四種：
#     安全      引用的目標編號沒變
#     需改寫    目標還在、只是換號，機械式改寫是安全的
#     危險      目標已被刪除，沒有正確的改寫方式
#     無法判定  解析不出來（可能是原文寫法特殊，也可能本來就寫錯）
#
# 「無法判定」一定要列出來，不能默默跳過 —— 沉默才是最危險的結果。

_TOKEN_RE = re.compile(
    r"(?P<article>第\s*[%(cn)s\d]+\s*條(?:\s*之\s*[%(cn)s\d]+)?)"
    r"|(?P<prev_article>前\s*[%(cn)s]*\s*條)"
    r"|(?P<this_article>本條)"
    r"|(?P<para>第\s*[%(cn)s\d]+\s*項)"
    r"|(?P<prev_para>前\s*[%(cn)s]*\s*項)"
    r"|(?P<clause>第\s*[%(cn)s\d]+\s*款)"
    r"|(?P<prev_clause>前\s*[%(cn)s]*\s*款)"
    r"|(?P<all_clause>各\s*款)"
    r"|(?P<item>第\s*[%(cn)s\d]+\s*目)"
    r"|(?P<prev_item>前\s*[%(cn)s]*\s*目)"
    r"|(?P<rangemark>至)"
    r"|(?P<conj>[及或與和、])"
    r"|(?P<stop>[。；：])" % {"cn": CN})

_NUM_IN_TOKEN = re.compile(r"[%s\d]+" % CN)


def _token_number(token_text):
    """從「第十二款」這種字串裡取出數字。取不到回 None。"""
    match = _NUM_IN_TOKEN.search(token_text.replace("第", "").replace("前", ""))
    return cn_to_int(match.group(0)) if match else None


def _relative_offset(token_text):
    """「前款」= 往前 1 個，「前二款」= 往前 2 個。"""
    number = _token_number(token_text)
    return number if number else 1


def parse_references(text, own_article, own_clause, previous_article,
                    own_para=None, skip_declaration=False):
    """
    解析一段文字裡的所有條款目引用。

    own_article／own_clause／own_para：這一段自己所在的條、款、項，
    用來解析沒寫範圍的引用（例如條文裡直接寫「第三款」，指的就是本條第三款；
    「前項」指的是本條的前一項）。
    previous_article：這一段的「前條」是哪一條。
    skip_declaration：這一段開頭的「第X條」是這一條的條號，不是引用。
        不跳過的話，條層級判定會把條文自己的條號當成要改寫的引用，
        --rewrite-refs 就會直接改掉條號本身。

    回傳引用清單，每筆含 span（在原文的起訖位置，供改寫用）、
    article（指向哪一條）、kind（款／目／項／條）、numbers（指向哪幾號）；
    external 有值代表那是外部法規的條號（例如「個人資料保護法第五條」），
    本程式不判也不改。
    """
    references = []
    scope_article = own_article
    scope_span = None        # 範圍前綴在原文的位置，例如「前條」「第五條」
    pending_range = False
    last_reference = None
    # 外部法規的引用鏈延伸到哪個位置：「個人資料保護法第五條第三款」的「第三款」
    # 緊接在後面，也是別人家的，不能拿本文的對照表去判。
    external_chain_end = None

    def display_quote(token_span):
        """
        報告裡要顯示的引用字句。

        span 只涵蓋號碼那一段（改寫時只能動那裡），但報告寫「引用『第二款』」
        會讓人看不出是哪一條的第二款。所以緊接在範圍前綴後面的引用，
        顯示時把前綴一起帶上，變成「前條第二款」。
        """
        if scope_span and scope_span[1] == token_span[0]:
            return text[scope_span[0]:token_span[1]]
        return text[token_span[0]:token_span[1]]

    for match in _TOKEN_RE.finditer(text):
        kind = match.lastgroup
        token = match.group(0)

        # 緊接在外部法規條號後面的款目（中間只隔連接詞），一律跟著算外部的。
        # 不是緊接著的就不算，否則「保險法第五條所定事項，第三款另有規定」這種
        # 後半句其實是本文自己的引用，會被整句跳過不檢查。
        chained = (external_chain_end is not None
                   and match.start() == external_chain_end)
        if chained and kind in ("clause", "item", "para", "conj", "rangemark"):
            external_chain_end = match.end()
            continue
        if kind != "article":
            external_chain_end = None

        if kind == "stop":
            # 句子結束，範圍重設回本條，「及」的延續也中斷
            scope_article = own_article
            scope_span = None
            pending_range = False
            last_reference = None
            continue

        if kind == "conj":
            # 「及」「或」「、」本身不重設範圍，讓後面的「第四款」延用前面的條
            continue

        if kind == "rangemark":
            pending_range = True
            continue

        if kind == "article":
            law = is_external_reference(text, match.span())
            if law:
                # 別人家的法條。記一筆讓報告看得到，但不判、不改；
                # 範圍也不能留給它，否則後面沒帶條號的「第三款」會被算到它頭上。
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": re.sub(r"\s+", "", token),
                    "kind": "條", "numbers": None, "is_range": False,
                    "external": law,
                })
                scope_article = own_article
                scope_span = None
                external_chain_end = match.end()
                last_reference = None
                continue

            external_chain_end = None
            scope_article = re.sub(r"\s+", "", token)
            scope_span = match.span()
            if skip_declaration and not text[:match.start()].strip():
                # 段落開頭的「第七條」是這一條的條號，不是引用
                scope_span = None
                last_reference = None
                continue
            # 條層級的引用本身也要記一筆。「本公司得依第五條規定辦理」這種
            # 沒帶款目的引用，只要第五條被整條刪掉就會指空，不能漏掉。
            references.append({
                "span": match.span(), "raw": token, "article": scope_article,
                "kind": "條", "numbers": None, "is_range": False,
            })
            last_reference = None
            continue

        if kind == "prev_article":
            offset = _relative_offset(token)
            scope_article = previous_article if offset == 1 else ""
            scope_span = match.span()
            last_reference = None
            continue

        if kind == "this_article":
            scope_article = own_article
            scope_span = match.span()
            last_reference = None
            continue

        if kind in ("para", "prev_para"):
            # 項不像款目那樣把編號寫在文字裡，所以沒有「重編」可言；
            # 但它一樣會出事——刪掉一個項，後面的項次全部往前移，
            # 「前項」「第二項」就指到別的東西了。
            #
            # 早期版本這裡直接 continue，等於靜默略過，違反本程式的原則
            # （解析不出來也要列出來，沉默才是最危險的結果）。現在照樣產生
            # 引用記錄，交給 _judge 與 scan_reference_drift 判斷。
            if kind == "prev_para":
                offset = _relative_offset(token)
                target = (own_para - offset) if own_para else None
                if target and target >= 1:
                    note, hint = "", None
                elif own_para:
                    # 知道自己是第幾項，卻算出往前指到第 0 項或更前面，
                    # 那就是明確的錯：本條第一項前面沒有項可以指。
                    if own_para == 1:
                        note = ("這一段是本條的第一項，前面沒有項可以指，"
                                "「%s」指不到東西" % token)
                    else:
                        note = ("這一段是本條的第 %d 項，前面只有 %d 項，"
                                "「%s」要再往前數 %d 項，指不到東西"
                                % (own_para, own_para - 1, token, offset))
                    hint = "危險"
                else:
                    note = ("這一段本身不在任何條的項次之內，"
                            "解析不出「%s」指的是哪一項" % token)
                    hint = None
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": scope_article, "kind": "項",
                    "numbers": [target] if target and target >= 1 else None,
                    "note": note, "status_hint": hint,
                })
            else:
                number = _token_number(token)
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": scope_article, "kind": "項",
                    "numbers": [number] if number else None,
                    "note": "" if number else "解析不出項次",
                })
            last_reference = None
            continue

        if kind == "all_clause":
            references.append({
                "span": match.span(), "raw": token, "article": scope_article,
                "kind": "款", "numbers": None, "note": "「各款」指全部，重編不影響",
            })
            last_reference = None
            continue

        if kind in ("clause", "item"):
            unit = "款" if kind == "clause" else "目"
            number = _token_number(token)
            if number is None:
                continue

            if pending_range and last_reference and last_reference["kind"] == unit:
                # 「第二款至第四款」：把範圍展開成 2、3、4，並把兩端合併成一筆
                start = last_reference["numbers"][0]
                last_reference["numbers"] = list(range(min(start, number),
                                                       max(start, number) + 1))
                last_reference["span"] = (last_reference["span"][0], match.span()[1])
                last_reference["raw"] = text[last_reference["span"][0]:
                                             last_reference["span"][1]]
                last_reference["is_range"] = True
                last_reference["is_range"] = True
                pending_range = False
                continue

            reference = {
                # span 只涵蓋號碼那一段，改寫時只能動這裡；
                # raw 是報告要顯示的字句，會把「前條」「第五條」這種前綴帶上；
                # token 是純號碼字串，改寫時拿它去換，不能用 raw，
                # 否則「第五條第四款」會被改成「第五條第五條第三款」。
                "span": match.span(), "raw": display_quote(match.span()),
                "token": token, "article": scope_article,
                "kind": unit, "numbers": [number], "is_range": False,
            }
            references.append(reference)
            last_reference = reference
            pending_range = False
            continue

        if kind in ("prev_clause", "prev_item"):
            unit = "款" if kind == "prev_clause" else "目"
            offset = _relative_offset(token)
            if own_clause is None:
                references.append({
                    "span": match.span(), "raw": token, "article": scope_article,
                    "kind": unit, "numbers": None,
                    "note": "這一段本身不在任何%s之下，解析不出「%s」指的是哪一%s"
                            % (unit, token, unit),
                })
            else:
                target = own_clause - offset
                references.append({
                    "span": match.span(), "raw": token, "article": scope_article,
                    "kind": unit,
                    "numbers": [target] if target >= 1 else None,
                    "note": "" if target >= 1 else "「%s」往前數超出範圍" % token,
                })
            last_reference = None
            continue

    return references


def scan_references(paragraphs, entries, clause_map, item_map,
                    known_articles=None, articles_with_clauses=None,
                    kinds=None, article_map=None, changed_paragraphs=None):
    """
    掃描全文的交叉引用，判斷它們會不會因為重編而指錯。

    clause_map／item_map 是 plan_renumber() 算出來的「舊號 → 新號」對照。
    known_articles 是全文實際存在的條號集合，用來抓出指向不存在條號的引用。
    article_map 是 plan_article_map() 算出來的「舊條號 → 新條號」對照；
    沒給就代表沒有舊版可比對，條層級一律不下結論（報告印「未檢查」），
    絕對不可以因此印「沒有受影響」。
    changed_paragraphs 是 find_changed_paragraphs() 算出來的「本次有改過」段次，
    用來把「這一段自己也被改過」的條層級引用降級成危險（見 _judge）。
    """
    contexts = build_hierarchy(paragraphs, kinds)
    entry_by_index = {e["index"]: e for e in entries}
    if articles_with_clauses is None:
        articles_with_clauses = {e["article"] for e in entries
                                 if e["level"] == "款" and e["article"]}

    # 每一條有幾項，用來判斷「第三項」這種引用指不指得到
    para_counts = {}
    for context in contexts:
        if context["level"] in ("條", "項") and context["article"]:
            ordinal = _paragraph_ordinal(context) or 1
            key = context["article"]
            para_counts[key] = max(para_counts.get(key, 0), ordinal)

    findings = []

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        entry = entry_by_index.get(idx, {})
        own_clause = entry.get("clause_written")
        # own_para（這一段是所在條的第幾項）只有在這一段真的是條文本體或某一項
        # 時才算數。表格儲存格裡的段落層級是「其他」，ref 卻沿用所在條——
        # 照樣傳 own_para 的話，格內的「前項」會被當成「本條第一項的前項」，
        # 判成「前面沒有項可以指」的危險（實測 no 23）。那一格根本不在條的項次
        # 結構裡，傳 None 走「解析不出指的是哪一項」那一支，不下危險判斷。
        own_para = (_paragraph_ordinal(context)
                    if context["level"] in ("條", "項") else None)
        references = parse_references(
            text, context["article"], own_clause,
            _previous_article_of(contexts, idx),
            own_para=own_para,
            skip_declaration=(context["level"] == "條"))

        for reference in references:
            finding = _judge(reference, text, idx, clause_map, item_map,
                             own_clause, known_articles, articles_with_clauses,
                             para_counts, article_map, changed_paragraphs)
            if finding:
                findings.append(finding)

    return findings


_ARTICLE_NO_RE = re.compile(r"^第\s*([%s\d]+)\s*條(?:\s*之\s*([%s\d]+))?" % (CN, CN))


def normalize_article_no(text):
    """條號正規化，**只給比對用**（寫進產出檔的原文一律保留原字）。

    全形數字先用 NFKC 轉半形，再把中文數字換成阿拉伯數字，所以
    「第１２條」「第12條」「第十二條」正規化後是同一把鑰匙。
    以前是照字面比，同一份文件裡混寫全形／中文就會判成「引用的條在新版中不存在」，
    那是最高等級的「危險」警告，人得一筆一筆回去查才發現是假警報。
    認不出條號就回去掉空白的原字，不硬猜。
    """
    if not text:
        return ""
    plain = re.sub(r"\s+", "", unicodedata.normalize("NFKC", text))
    match = _ARTICLE_NO_RE.match(plain)
    if not match:
        return plain
    main = cn_to_int(match.group(1))
    if main is None:
        return plain
    sub = cn_to_int(match.group(2)) if match.group(2) else None
    return "條%d%s" % (main, "之%d" % sub if sub else "")


def _same_article(left, right):
    return normalize_article_no(left) == normalize_article_no(right)


def _lookup_by_article(mapping, key):
    """字典查詢：先照原字，查不到再用正規化後的條號比一次。"""
    if key in mapping:
        return mapping[key]
    if isinstance(key, tuple):
        want = (normalize_article_no(key[0]),) + tuple(key[1:])
        for candidate, value in mapping.items():
            if (isinstance(candidate, tuple) and len(candidate) == len(key)
                    and (normalize_article_no(candidate[0]),) + tuple(candidate[1:]) == want):
                return value
        return None
    for candidate, value in mapping.items():
        if _same_article(candidate, key):
            return value
    return None


def _lookup_article_map(article_map, article):
    """在「舊條號 → 新條號」對照裡查一條，查不到回 None。條號先正規化再比。"""
    if not article_map:
        return None
    if article in article_map:
        return article_map[article]
    for candidate, value in article_map.items():
        if _same_article(candidate, article):
            return value
    return None


def _judge(reference, text, index, clause_map, item_map, own_clause,
           known_articles, articles_with_clauses=None, para_counts=None,
           article_map=None, changed_paragraphs=None):
    """判斷單一筆引用會不會出問題。沒問題（安全）就回 None。

    條號一律先正規化再比（normalize_article_no）：全形數字、中文數字混寫的同一條
    以前會被判成「在新版中不存在」的假危險。
    """
    base = {"index": index, "text": text, "quote": reference["raw"],
            "article": reference["article"], "kind": reference["kind"],
            "external": reference.get("external", "")}

    if reference.get("external"):
        # 外部法規的條號：本程式沒有那部法規的新舊版，判不了也不該判。
        # 列出來讓人自己去查，但絕對不能改寫（實測 idx 142 就是被改掉的）。
        base.update({"status": "外部法規", "law": reference["external"],
                     "note": "這是「%s」的條號，不是本規章的條，本程式不檢查也不改寫"
                             % reference["external"]})
        return base

    if reference.get("note") and reference.get("numbers") is None:
        if "各款" in reference["raw"]:
            return None      # 「各款」指全部，不受重編影響
        base.update({"status": reference.get("status_hint") or "無法判定",
                     "note": reference["note"]})
        return base

    if not reference["article"]:
        base.update({"status": "無法判定",
                     "note": "解析不出這個引用指向哪一條，請人工確認"})
        return base

    if known_articles is not None and not any(
            _same_article(reference["article"], known) for known in known_articles):
        base.update({"status": "危險",
                     "note": "引用的 %s 在新版中不存在" % reference["article"]})
        return base

    if reference["kind"] == "條":
        # 以前這裡直接 return None，理由是「條號不重編，條存在就沒事」。
        # 但實務上使用者常常自己把條號往前遞補過：新版的確有「第七條」，
        # 內容卻已經是舊版的第八條——寫「第七條」的地方全部指錯，
        # 程式卻一聲不吭，報告還印「沒有受影響的交叉引用」（實測 idx 63、80）。
        if article_map is None:
            # 沒有舊版可比對，算不出舊條號跟新條號的對應。這裡不下任何結論，
            # 由 report() 把條層級整段印成「未檢查」。
            return None
        target = _lookup_article_map(article_map, reference["article"])
        if target is None:
            # 舊版根本沒有這個條號（新版才有），代表這是新版新寫的引用，
            # 作者是照新版的條號寫的，沒有位移問題，不下判斷也不列出來。
            return None
        if changed_paragraphs is not None and index in changed_paragraphs:
            # 這一段本次有改過。重編之後，「作者已經改好的新號」跟「還沒改的舊號」
            # 文字上一模一樣，程式分不出來，猜錯就是把對的條號改成錯的
            # （實測：作者已經把第七條改成第六條，程式又把它改成第五條）。
            base.update({
                "status": "危險",
                "note": "危險（引用所在段落本次有改，無法判斷是舊號或新號）："
                        "舊版的%s在新版是%s，請人工確認這裡的「%s」指的是哪一個"
                        % (reference["article"],
                           target["new"] or "已刪除或併入別條",
                           reference["article"]),
            })
            return base
        if target["new"] is None:
            if target["merged_into"]:
                base.update({
                    "status": "危險",
                    "note": "舊版的%s已併入%s，這個引用要指向哪裡必須人工確認"
                            % (reference["article"], target["merged_into"]),
                })
            else:
                base.update({
                    "status": "危險",
                    "note": "舊版的%s在新版已被刪除，沒有對應的新條號，必須人工確認"
                            % reference["article"],
                })
            return base
        if _same_article(target["new"], reference["article"]):
            return None      # 條號沒變，指到的還是同一條
        base.update({
            "status": "需改寫", "new_quote": target["new"],
            "span": reference["span"],
            "note": "被引用的條還在，只是從%s變成%s"
                    % (reference["article"], target["new"]),
        })
        return base

    if reference["kind"] == "項":
        # 項沒有寫在文字裡的編號，沒辦法機械式改寫；能做的是確認它指得到，
        # 指不到就一定要講。實際「指到的內容變了沒有」由 scan_reference_drift
        # 比對新舊版來抓。
        counts = para_counts or {}
        total = _lookup_by_article(counts, reference["article"]) or 0
        wanted = reference["numbers"][0]
        if not total:
            base.update({"status": "無法判定",
                         "note": "%s 底下推算不出項次，請人工確認這個引用指向哪裡"
                                 % reference["article"]})
            return base
        if wanted > total:
            base.update({"status": "危險",
                         "note": "%s 只有 %d 項，但這裡引用第 %d 項，指不到"
                                 % (reference["article"], total, wanted)})
            return base
        return None

    # 引用的條底下根本沒有款，代表這個引用本身有問題（常見於「前條」指錯條），
    # 不能報成「已被刪除」——那會讓人以為是這次修訂造成的。
    if (reference["kind"] == "款" and articles_with_clauses is not None
            and not any(_same_article(reference["article"], known)
                        for known in articles_with_clauses)):
        base.update({
            "status": "無法判定",
            "note": "%s 底下沒有任何款，這個引用可能原本就寫錯，請人工確認指向哪裡"
                    % reference["article"],
        })
        return base

    mapped = []
    for number in reference["numbers"]:
        if reference["kind"] == "款":
            mapped.append(_lookup_by_article(clause_map, (reference["article"], number)))
        else:
            mapped.append(_lookup_by_article(
                item_map, (reference["article"], own_clause, number)))

    if any(m is None for m in mapped):
        missing = [n for n, m in zip(reference["numbers"], mapped) if m is None]
        base.update({
            "status": "危險",
            "note": "引用的第%s%s已被刪除，沒有對應的新編號，必須人工確認要改成什麼"
                    % ("、".join(int_to_cn(n) for n in missing), reference["kind"]),
        })
        return base

    if mapped == reference["numbers"]:
        return None          # 安全，編號沒變

    # 範圍引用只有在重編後仍然連續時，機械式改寫才成立
    if reference.get("is_range") and mapped != list(range(mapped[0], mapped[-1] + 1)):
        base.update({"status": "危險",
                     "note": "範圍引用在重編後不再連續，必須人工改寫"})
        return base

    new_quote = _rewrite_quote(reference, mapped)
    base.update({
        "status": "需改寫", "new_quote": new_quote, "span": reference["span"],
        "note": "被引用的%s還在，只是從第%s%s變成第%s%s"
                % (reference["kind"],
                   "、".join(int_to_cn(n) for n in reference["numbers"]),
                   reference["kind"],
                   "、".join(int_to_cn(n) for n in mapped), reference["kind"]),
    })
    return base


def _rewrite_quote(reference, mapped):
    """把引用字句裡的號碼換成新號碼。範圍引用只換頭尾兩端。"""
    unit = reference["kind"]
    if reference.get("is_range"):
        return "第%s%s至第%s%s" % (int_to_cn(mapped[0]), unit,
                                   int_to_cn(mapped[-1]), unit)
    return re.sub(r"第\s*[%s\d]+\s*%s" % (CN, unit),
                  "第%s%s" % (int_to_cn(mapped[0]), unit),
                  reference.get("token", reference["raw"]), count=1)


def _paragraph_ordinal(context):
    """
    這一段是所在條的第幾項。build_hierarchy 已經算好了，從 ref 裡取出來。
    條文本體是第一項，之後每一個沒有編號的獨立段落依序遞增。
    """
    ref = context.get("ref", "")
    match = re.search(r"第([%s]+)項$" % CN, ref)
    if match:
        return cn_to_int(match.group(1))
    return 1 if context.get("level") in ("條", "項") else None


def _previous_article_of(contexts, index):
    """往回找「前條」指的是哪一條。"""
    current = contexts[index - 1]["article"]
    seen_current = False
    for context in reversed(contexts[:index]):
        if context["level"] != "條":
            continue
        if not seen_current:
            if context["article"] == current:
                seen_current = True
            continue
        return context["article"]
    return ""


def _paragraph_bodies(paragraphs, kinds=None):
    """
    把全文的「項」整理成 {(條號, 項次): 條文本體}。

    項沒有寫在文字裡的編號，項次是從條文本體開始往下數出來的。
    刪掉一個項，後面的項次全部往前移——「第二項」就指到別的東西了，
    這跟刪掉一個款完全是同一種問題，只是更難察覺，因為文件上看不出編號變動。
    """
    bodies = {}
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] not in ("條", "項") or not context["article"]:
            continue
        ordinal = _paragraph_ordinal(context) or 1
        bodies[(context["article"], ordinal)] = strip_article_no(text).strip()
    return bodies


def _numbered_bodies(paragraphs, level, kinds=None):
    """
    把全文的款（或目）整理成 {(條號, 編號): 條文本體}，本體是去掉編號後的文字。

    用來比對「同一個編號，新舊版指的是不是同一件事」。
    """
    bodies = {}
    contexts = build_hierarchy(paragraphs, kinds)
    clause_written = None

    for text, context in zip(paragraphs, contexts):
        if context["level"] == "條":
            clause_written = None
        elif context["level"] == "款":
            match = _CLAUSE_RE.match(text)
            number = cn_to_int(match.group(1)) if match else None
            clause_written = number
            if level == "款" and number is not None:
                bodies[(context["article"], number)] = _CLAUSE_RE.sub("", text, count=1).strip()
        elif context["level"] == "目":
            match = _ITEM_RE.match(text)
            number = cn_to_int(match.group(2)) if match else None
            if level == "目" and number is not None:
                bodies[(context["article"], clause_written, number)] =                     _ITEM_RE.sub("", text, count=1).strip()
    return bodies


def scan_reference_drift(old_paragraphs, new_paragraphs,
                         old_kinds=None, new_kinds=None):
    """
    比對新舊版，找出「編號沒變、但指的東西變了」的交叉引用。

    為什麼一定要有這一關：
    如果使用者刪掉第二款之後，自己先把三、四、改成二、三、才拿來跑，
    編號連續性檢查會說「完全乾淨」——因為它確實乾淨。但別的條文寫的
    「依前條第二款規定」，指的已經從被刪掉的「原保險單正本」變成
    「契約變更申請書」，意思整個換掉，而且**表面上完全看不出來**。
    這是所有情況裡最危險的一種，正是因為它看起來沒問題。

    做法很直接：同一個條號、同一個款號，比對新舊版的條文本體。
    不一樣就把兩邊都列出來，交給人判斷。不自動改。
    """
    old_clauses = _numbered_bodies(old_paragraphs, "款", old_kinds)
    new_clauses = _numbered_bodies(new_paragraphs, "款", new_kinds)
    old_paras = _paragraph_bodies(old_paragraphs, old_kinds)
    new_paras = _paragraph_bodies(new_paragraphs, new_kinds)
    # 比對用正規化過的，顯示用原文（產出檔一律保留原字）
    old_articles = dict(_article_units(old_paragraphs, old_kinds))
    new_articles = dict(_article_units(new_paragraphs, new_kinds))
    old_article_texts = dict(_article_texts(old_paragraphs, old_kinds))
    new_article_texts = dict(_article_texts(new_paragraphs, new_kinds))
    contexts = build_hierarchy(new_paragraphs, new_kinds)

    pattern = re.compile(r"(前條|第\s*[%s\d]+\s*條(?:之\s*[%s\d]+)?)?"
                         r"第\s*([%s\d]+)\s*(款|項)" % (CN, CN, CN))
    # 以前只認「第X條」後面還接著款或項的寫法，純粹寫「依第五條規定」的引用
    # 從來沒進到這一關（實測 idx 63、80）——指到的內容整條換掉也不會有人講。
    article_pattern = re.compile(
        r"第\s*[%s\d]+\s*條(?:\s*之\s*[%s\d]+)?(?!\s*第\s*[%s\d]+\s*[款項])"
        % (CN, CN, CN))

    findings = []
    for idx, (text, context) in enumerate(zip(new_paragraphs, contexts), 1):
        for match in article_pattern.finditer(text):
            if context["level"] == "條" and not text[:match.start()].strip():
                continue          # 段落開頭的條號是這一條自己的，不是引用
            if is_external_reference(text, match.span()):
                continue          # 別人家的法條，本程式沒有它的新舊版可比
            target_article = re.sub(r"\s+", "", match.group(0))
            old_body = old_articles.get(target_article)
            if old_body is None or old_body == new_articles.get(target_article):
                continue
            findings.append({
                "index": idx, "text": text, "quote": match.group(0),
                "target": target_article,
                "old_body": old_article_texts.get(target_article),
                "new_body": new_article_texts.get(target_article),
            })

        for match in pattern.finditer(text):
            scope_text, number_text, unit = match.groups()
            number = cn_to_int(number_text)
            if number is None:
                continue
            if is_external_reference(text, match.span()):
                continue          # 「個人資料保護法第五條第三款」不是本文的款

            if scope_text and scope_text.startswith("前條"):
                target_article = _previous_article_of(contexts, idx)
            elif scope_text:
                target_article = re.sub(r"\s+", "", scope_text)
            else:
                target_article = context["article"]
            if not target_article:
                continue

            if unit == "款":
                old_body = old_clauses.get((target_article, number))
                new_body = new_clauses.get((target_article, number))
            else:
                old_body = old_paras.get((target_article, number))
                new_body = new_paras.get((target_article, number))

            if old_body is None or old_body == new_body:
                continue

            findings.append({
                "index": idx, "text": text, "quote": match.group(0),
                "target": "%s第%s%s" % (target_article, number_text, unit),
                "old_body": old_body,
                "new_body": new_body,
            })
    return findings


# ---------------------------------------------------------------------------
# 輸出
# ---------------------------------------------------------------------------

SKIPPED_NUMBERING = "未檢查（此文件沒有第X條，款目編號檢查不適用）"
# 同一份報告裡第二次講同一件事，理由不用再寫一遍
SKIPPED_NUMBERING_AGAIN = "未檢查（同上，此文件沒有第X條）"
# 條層級的引用只列不改，理由見 apply_changes
ARTICLE_REF_MANUAL = "條層級引用只列不改，請人工確認後自行修改"


# report() 這一輪有哪幾項是「沒檢查」。畫面上每一段各自印過「未檢查」了，
# 這裡收起來在最後發一則提醒——畫面留不住，而「沒有發現問題」與「根本沒檢查」
# 在產出檔裡看起來一模一樣，那才是危險的地方。
_unchecked = []


def _note_unchecked(item, reason):
    _unchecked.append("%s（%s）" % (item, reason))


def report(problems, changes, deleted_articles, references, drift=None,
           numbering_applicable=True, article_map=None):
    """把檢查結果印出來。每一段都要明講是「通過」「未檢查」還是「有問題」。

    numbering_applicable：款目編號檢查適不適用於這份文件（沒有「第X條」就不適用）。
    article_map：plan_article_map() 的「舊條號 → 新條號」對照；None 代表沒有舊版
        可比對，條層級與條號增刪一律印「未檢查」。

    為什麼要三態：沒檢查卻印「無，款目編號都是連續的」「沒有受影響的交叉引用」，
    使用者會以為程式看過了、沒問題，實際上是程式根本沒看。這種假的安心比不檢查
    更危險，所以任何沒跑到的分支一律印「未檢查」並說明原因。
    """
    del _unchecked[:]
    print("\n" + "=" * 62)
    print("編號檢查結果")
    print("=" * 62)

    print("\n【編號有問題的地方】")
    if not numbering_applicable:
        print("  " + SKIPPED_NUMBERING)
        _note_unchecked("款目編號", "此文件沒有第X條，不適用")
    elif problems:
        print("  有問題，共 %d 處" % len(problems))
        for problem in problems:
            # 號碼照原本的數字體系印：阿拉伯目印「1、2」，中文目印「一、二」。
            # 印錯體系的話，人拿著報告回文件裡找不到那一段。
            style = problem.get("style")
            print("  %s %s：%s" % (problem["article"], problem["level"], problem["reason"]))
            print("      目前：%s" % "、".join(_number_text(style, n) for n in problem["written"]))
            print("      應為：%s（第 %d 段起）"
                  % ("、".join(_number_text(style, n) for n in problem["expected"]),
                     problem["first_index"]))
    else:
        print("  通過，款目編號都是連續的")

    print("\n【要重編的段落】")
    if not numbering_applicable:
        print("  " + SKIPPED_NUMBERING_AGAIN)
    elif changes:
        print("  有 %d 段要重編" % len(changes))
        for change in changes[:20]:
            style = change.get("style")
            print("  第%d段 %s %s：第%s%s → 第%s%s"
                  % (change["index"], change["article"], change["level"],
                     _number_text(style, change["old"]) if change["old"] else "?",
                     change["level"],
                     _number_text(style, change["new"]), change["level"]))
        if len(changes) > 20:
            print("  …另有 %d 段（完整清單見輸出檔）" % (len(changes) - 20))
    else:
        print("  通過，不需要重編")

    print("\n【新版少掉的條號】")
    if article_map is None:
        print("  未檢查（沒有給舊版，比不出條號有沒有被刪或被併；請加 --old 舊版檔）")
        _note_unchecked("新版少掉的條號", "沒有給舊版，比不出條號有沒有被刪或被併")
    elif not article_map:
        # 舊版根本沒有「第X條」，不是「每一條都找得到」，是根本沒有東西可以比。
        print("  未檢查（舊版沒有「第X條」，比不出條號對照）")
        _note_unchecked("新版少掉的條號", "舊版沒有「第X條」，比不出條號對照")
    elif not deleted_articles:
        print("  通過，舊版每一條在新版都找得到")
    else:
        gone = [d for d in deleted_articles if d["status"] == "刪除"]
        merged = [d for d in deleted_articles if d["status"] == "併入"]
        print("  有問題，共 %d 條" % len(deleted_articles))
        if gone:
            print("  依法制慣例，刪除的條應保留條號並註記「（刪除）」，讓後面的條號維持不變，")
            print("  否則全文及其他規章裡引用這些條號的地方會全部指錯。建議補上：")
            for item in gone:
                print("      %s　（刪除）" % item["article"])
        if merged:
            # 併條不是刪除。補「（刪除）」註記反而是錯的，所以一定要分開講。
            print("  下列各條的內容是被併進別條，不是刪除，不要補「（刪除）」註記：")
            for item in merged:
                print("      %s　併入%s" % (item["article"], item["into"]))

    external = [r for r in references if r["status"] == "外部法規"]
    dangerous = [r for r in references if r["status"] == "危險"]
    rewritable = [r for r in references if r["status"] == "需改寫"]
    unresolved = [r for r in references if r["status"] == "無法判定"]
    affected = dangerous + rewritable + unresolved
    article_level = [r for r in affected if r["kind"] == "條"]
    inner_level = [r for r in affected if r["kind"] != "條"]

    print("\n【交叉引用】")
    if external:
        laws = []
        for ref in external:
            if ref.get("law") and ref["law"] not in laws:
                laws.append(ref["law"])
        print("  外部法規引用（不檢查）%d 處：%s" % (len(external), "、".join(laws)))
        print("      這些是別部法規的條號，本程式沒有那部法規的新舊版，不判也不改寫。")
    if article_map is None:
        print("  條層級引用：未檢查（沒有舊版可比對，算不出舊條號對到新版哪一條；"
              "請加 --old 舊版檔）")
        _note_unchecked("條層級交叉引用", "沒有舊版可比對，算不出舊條號對到新版哪一條")
    elif not article_map:
        # 舊版沒有任何「第X條」，對照表是空的，條層級等於沒檢查
        print("  條層級引用：未檢查（舊版沒有「第X條」，算不出條號對照）")
        _note_unchecked("條層級交叉引用", "舊版沒有「第X條」，算不出條號對照")
    elif article_level:
        print("  條層級引用：有問題，共 %d 處（%s）"
              % (len(article_level), ARTICLE_REF_MANUAL))
    else:
        print("  條層級引用：通過，比對過新舊版條號，沒有指錯的「第X條」")
    if inner_level:
        print("  款目與項引用：有問題，共 %d 處" % len(inner_level))
    else:
        print("  款目與項引用：通過，沒有指錯的款目或項")

    rewritable_inner = [r for r in rewritable if r["kind"] != "條"]
    rewritable_article = [r for r in rewritable if r["kind"] == "條"]
    if rewritable_inner:
        print("  可機械式改寫 %d 處（加 --rewrite-refs 一併處理）：" % len(rewritable_inner))
        for ref in rewritable_inner:
            print("    第%d段「%s」→「%s」" % (ref["index"], ref["quote"], ref["new_quote"]))
            print("        %s" % ref["note"])
    if rewritable_article:
        # 條層級一律只列不改：作者可能已經自己改好了，文字上看不出來，猜錯就是
        # 把對的條號改成錯的。建議的新條號照印，改不改由人決定。
        print("  %s（%d 處）：" % (ARTICLE_REF_MANUAL, len(rewritable_article)))
        for ref in rewritable_article:
            print("    第%d段「%s」→ 建議改成「%s」"
                  % (ref["index"], ref["quote"], ref["new_quote"]))
            print("        %s" % ref["note"])
    if dangerous:
        print("\n  ⚠ 必須人工處理 %d 處 —— 本程式不會自動改：" % len(dangerous))
        for ref in dangerous:
            print("    第%d段：%s" % (ref["index"], ref["text"][:50]))
            print("        引用「%s」，%s" % (ref["quote"], ref["note"]))
    if unresolved:
        # 解析不出來的一定要列出來。沉默才是最危險的結果——使用者會以為
        # 程式看過了、沒問題，實際上是程式根本沒看懂那句話。
        print("\n  ? 解析不出來 %d 處 —— 可能是寫法特殊，也可能原文本來就寫錯，"
              "請人工看一下：" % len(unresolved))
        for ref in unresolved:
            print("    第%d段：%s" % (ref["index"], ref["text"][:50]))
            print("        引用「%s」，%s" % (ref["quote"], ref["note"]))

    if drift:
        print("\n【編號沒變、但指到的內容變了】共 %d 處 —— 這是最容易漏掉的一種"
              % len(drift))
        print("  表面上編號連續、看不出問題，但同一個編號在新舊版指的是不同的東西。")
        for item in drift:
            print("\n    第%d段：%s" % (item["index"], item["text"][:52]))
            print("        引用「%s」" % item["quote"])
            print("        舊版的%s是：%s" % (item["target"], item["old_body"]))
            if item["new_body"] is None:
                print("        新版沒有這一款了")
            else:
                print("        新版的%s是：%s" % (item["target"], item["new_body"]))
        print("\n  本程式不會自動改這些，請逐筆確認引用要指向哪裡。")

    print("=" * 62)
    if _unchecked:
        nt.notice(nt.REMINDER,
                  "編號檢查有 %d 項未檢查：%s。未檢查不等於沒問題，這幾項本次沒有跑到"
                  % (len(_unchecked), "、".join(_unchecked)), "Step 0.5")


def apply_changes(paragraphs, changes, references, rewrite_refs):
    """套用重編（以及選用的引用改寫），回傳新的段落列表。"""
    result = list(paragraphs)
    for change in changes:
        result[change["index"] - 1] = change["new_text"]

    if rewrite_refs:
        # 只改「需改寫」的款目與項。「危險」「無法判定」「外部法規」一律不動，
        # 條層級也一律不動——只列出來給人看。
        #
        # 條層級為什麼不能自動改：重編之後，「作者已經改好的新號」跟「還沒改的
        # 舊號」在文字上一模一樣，程式沒有辦法分辨，而 _judge 一律往「還沒改」
        # 的方向解，猜錯就是把對的條號改成錯的（實測：作者已經把第七條改成
        # 第六條，程式又把它改成第五條）。款目與項不一樣，它們的新舊號是由
        # 本次重編自己算出來的，不是從文字上猜的。
        #
        # 外部法規那一條也特別重要：把別部法規的條號改掉，是在正式修法文件上
        # 寫錯別人的法條，比漏改嚴重得多（實測 idx 142）。
        #
        # 用 span 由後往前取代：同一段裡可能出現兩個「第四款」，
        # 用字串比對會改到錯的那一個。
        by_paragraph = {}
        for ref in references:
            if (ref["status"] == "需改寫" and ref.get("span")
                    and not ref.get("external") and ref.get("kind") != "條"):
                by_paragraph.setdefault(ref["index"], []).append(ref)

        for index, refs in by_paragraph.items():
            text = result[index - 1]
            for ref in sorted(refs, key=lambda r: r["span"][0], reverse=True):
                start, end = ref["span"]
                text = text[:start] + ref["new_quote"] + text[end:]
            result[index - 1] = text

    return result


def write_output(paragraphs, source_path, outdir, prefix):
    """輸出重編後的檔案，格式跟來源檔一致。"""
    base = "重編後_" + os.path.basename(source_path)
    output_path = resolve_output(outdir, prefix, base)

    if output_path.lower().endswith(".docx"):
        if not HAS_DOCX:
            output_path = os.path.splitext(output_path)[0] + ".txt"
            nt.notice(nt.REMINDER, "沒有安裝 python-docx，重編結果改輸出純文字檔", "重編輸出")
        else:
            from docx import Document
            doc = Document()
            for text in paragraphs:
                doc.add_paragraph(text)
            doc.save(output_path)
            print("\n已輸出重編後檔案：%s" % output_path)
            return output_path

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(paragraphs) + "\n")
    print("\n已輸出重編後檔案：%s" % output_path)
    return output_path


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="Step 1.5：款目編號重編與交叉引用檢查")
    parser.add_argument("regulation_file", help="要檢查的內規檔案（通常是你剛改好的新版）")
    parser.add_argument("--old", default=None,
                        help="舊版檔案；給了才能找出被整條刪掉的條號")
    parser.add_argument("--apply", action="store_true",
                        help="實際重編款目編號並輸出檔案；不加就只檢查不動檔案")
    parser.add_argument("--rewrite-refs", action="store_true",
                        help="連同可機械式改寫的交叉引用一起改（引用到已刪除款目的、"
                             "以及外部法規的條號一律不動）")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    print("正在讀取：%s" % args.regulation_file)
    paragraphs, kinds = read_paragraphs_with_kinds(args.regulation_file)
    print("全文共 %d 段。" % len(paragraphs))

    entries = scan(paragraphs, kinds)
    applicable = numbering_check_applicable(entries)
    if not applicable:
        nt.notice(nt.REMINDER,
                  "這份文件沒有「第X條」（作業手冊型），款目編號檢查與重編不適用，"
                  "本次未檢查；交叉引用檢查照常", "Step 0.5")
    problems = find_numbering_gaps(entries)
    changes, clause_map, item_map = plan_renumber(paragraphs, entries)
    known_articles = {c["article"] for c in build_hierarchy(paragraphs, kinds)
                      if c["level"] == "條" and c["article"]}

    # 條層級的判定要先有「舊條號 → 新條號」的對照，所以舊版要先讀進來。
    article_map = None
    changed_paragraphs = None
    deleted_articles = []
    drift = []
    if args.old:
        print("正在比對舊版：%s" % args.old)
        old_paragraphs, old_kinds = read_paragraphs_with_kinds(args.old)
        article_map = plan_article_map(old_paragraphs, paragraphs, old_kinds, kinds)
        changed_paragraphs = find_changed_paragraphs(old_paragraphs, paragraphs,
                                                     old_kinds, kinds)
        deleted_articles = find_deleted_articles(old_paragraphs, paragraphs,
                                                 old_kinds, kinds,
                                                 article_map=article_map)
        drift = scan_reference_drift(old_paragraphs, paragraphs, old_kinds, kinds)
    else:
        nt.notice(nt.REMINDER,
                  "沒有給 --old，無法檢查「編號沒變但指到的內容變了」這種情況，"
                  "條層級的交叉引用也只能印「未檢查」；強烈建議加上舊版一起跑"
                  "（--old 舊版內規.docx）", "Step 0.5")

    references = scan_references(paragraphs, entries, clause_map, item_map,
                                 known_articles=known_articles, kinds=kinds,
                                 article_map=article_map,
                                 changed_paragraphs=changed_paragraphs)

    report(problems, changes, deleted_articles, references, drift,
           numbering_applicable=applicable, article_map=article_map)

    if not args.apply:
        if changes or [r for r in references if r["status"] != "安全"]:
            print("\n這是檢查模式，沒有更動任何檔案。要實際重編請加 --apply。")
        return changes

    updated = apply_changes(paragraphs, changes, references, args.rewrite_refs)
    write_output(updated, args.regulation_file, args.outdir, args.prefix)

    dangerous = [r for r in references if r["status"] == "危險"]
    if dangerous:
        print("\n⚠ 仍有 %d 處交叉引用引用到已刪除的款目，本程式沒有改動它們，"
              "請務必人工確認後再送出。" % len(dangerous))

    return changes


if __name__ == "__main__":
    main()
