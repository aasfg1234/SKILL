# -*- coding: utf-8 -*-
r"""
語意候選：用 BGE-M3 找「意思相近但字面不像」的條文，當連帶決定表的第四種來源。

用法（在有模型的電腦）：
    py semantic_candidates.py 語意輸入.json 語意候選.csv --model <模型資料夾> [--threshold 0.75] [--top 10]

語意輸入.json 由 run_all.py compare 產生。算完把 語意候選.csv 交回去：
    py run_all.py semantic 連帶決定表.csv 語意候選.csv

離開代碼：0 成功；1 輸入有問題；2 模型載不起（SPADE 或沒裝套件），請改手動。

為什麼只當第四種來源、不取代同義詞表：
向量給分數但說不出哪個詞對上；法遵每一筆建議都要能講理由。
所以語意候選一樣列全文與分數，由 AI 在第 2 步逐筆寫理由，人來決定。
"""

import argparse
import csv
import io
import json
import math
import os
import sys

DEFAULT_THRESHOLD = 0.75
DEFAULT_TOP = 10
COLUMNS = ["異動段次", "異動全文", "候選段次", "候選全文", "語意分數", "異動條文ID"]


class SemanticError(ValueError):
    pass


def write_input(path, draft_path, draft_sha, changes, paragraphs, target_name=""):
    data = {"格式版本": 1, "目標規章": target_name,
            "草稿": {"檔名": os.path.basename(draft_path), "SHA256": draft_sha},
            "異動": changes, "段落": list(paragraphs)}
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
        f.write("\n")
    return path


def read_input(path):
    if not os.path.isfile(path):
        raise SemanticError("找不到語意輸入檔：%s" % path)
    with io.open(path, encoding="utf-8-sig") as f:
        data = json.load(f)
    if data.get("格式版本") != 1 or "段落" not in data or "異動" not in data:
        raise SemanticError("語意輸入檔格式不對：%s" % path)
    return data


def load_model(model_path):
    """先試 FlagEmbedding，再試 sentence_transformers。都不行回 None，並印原因。"""
    reasons = []
    try:
        from FlagEmbedding import BGEM3FlagModel
        model = BGEM3FlagModel(model_path, use_fp16=False)
        return lambda texts: model.encode(list(texts), batch_size=16, max_length=512)["dense_vecs"]
    except Exception as exc:
        reasons.append("FlagEmbedding 載不起：%s" % exc)
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(model_path)
        return lambda texts: model.encode(list(texts), batch_size=16, normalize_embeddings=True)
    except Exception as exc:
        reasons.append("sentence_transformers 載不起：%s" % exc)
    for reason in reasons:
        print("  " + reason[:200], flush=True)
    return None


def _cosine(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


def find_candidates(embed, changes, paragraphs, threshold=DEFAULT_THRESHOLD, top=DEFAULT_TOP,
                    target_name=""):
    """embed：list[str] -> 向量列表。每筆異動用自己的「全文」算向量，所以異動可以來自別本規章。
    只有同本（「規章」空白或等於 target_name）且「段次」有效時才排除自己那一段。
    回傳 dict 列，欄位同 COLUMNS。"""
    texts = list(paragraphs)
    changes = [c for c in changes if (c.get("全文") or "").strip()]
    if not texts or not changes:
        return []
    vectors = [[float(x) for x in v] for v in embed(texts + [c["全文"] for c in changes])]
    para_vecs, change_vecs = vectors[:len(texts)], vectors[len(texts):]
    rows = []
    for change, cvec in zip(changes, change_vecs):
        doc = (change.get("規章") or "").strip()
        same_doc = (not doc) or (doc == (target_name or ""))
        idx = int(change.get("段次") or 0) - 1 if same_doc else -1
        scored = []
        for j, vec in enumerate(para_vecs):
            if j == idx:
                continue
            score = _cosine(cvec, vec)
            if score >= threshold:
                scored.append((score, j))
        scored.sort(reverse=True)
        label = change.get("條文ID", "")
        if not same_doc:
            label = "%s：%s" % (doc, label or ("段次 %s" % change.get("段次", "")))
        for score, j in scored[:top]:
            rows.append({"異動段次": str(idx + 1) if idx >= 0 else "",
                         "異動全文": change["全文"], "候選段次": str(j + 1),
                         "候選全文": texts[j], "語意分數": "%.3f" % score,
                         "異動條文ID": label})
    return rows


def write_results(path, rows, draft_sha):
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["#草稿SHA256", draft_sha])
        writer.writerow(COLUMNS)
        for row in rows:
            writer.writerow([row.get(c, "") for c in COLUMNS])


def read_results(path, expected_sha=None):
    if not os.path.isfile(path):
        raise SemanticError("找不到語意候選檔：%s" % path)
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        first = next(reader, None)
        if not first or first[0] != "#草稿SHA256" or len(first) < 2:
            raise SemanticError("語意候選.csv 第一列應為「#草稿SHA256,<指紋>」兩格")
        if expected_sha and first[1] != expected_sha:
            raise SemanticError("語意候選是對另一份草稿算的，指紋不符，不能併入")
        header = next(reader, None)
        if header != COLUMNS:
            raise SemanticError("語意候選.csv 欄位不符，應為：%s" % "、".join(COLUMNS))
        return [dict(zip(COLUMNS, r)) for r in reader if r]


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    parser = argparse.ArgumentParser(description="BGE-M3 語意候選")
    parser.add_argument("input_json")
    parser.add_argument("output_csv")
    parser.add_argument("--model", required=True, help="BGE-M3 模型資料夾")
    parser.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD)
    parser.add_argument("--top", type=int, default=DEFAULT_TOP)
    args = parser.parse_args(argv)
    try:
        data = read_input(args.input_json)
    except SemanticError as exc:
        print("[中止] %s" % exc, flush=True)
        return 1
    print("載入模型：%s" % args.model, flush=True)
    embed = load_model(args.model)
    if embed is None:
        print("[跳過] 這個環境載不起 BGE-M3。請在有模型的電腦執行這支程式，再把結果交回。", flush=True)
        return 2
    rows = find_candidates(embed, data["異動"], data["段落"], args.threshold, args.top,
                           data.get("目標規章", ""))
    write_results(args.output_csv, rows, data["草稿"]["SHA256"])
    print("語意候選 %d 列（門檻 %.2f）：%s" % (len(rows), args.threshold, args.output_csv), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
