# -*- coding: utf-8 -*-
"""
第 1.5 步：驗證 AI 判斷、把三欄寫回連帶決定表、產出 Excel／CSV 報告。

AI 讀 review_pack 產出的審查包，填好 AI候選判斷.csv、AI異動審查.csv 兩張 CSV
（只能填 AI判斷／AI分數／AI理由三欄，列ID／候選段次等對照欄是程式先填好的，不能動）。
這支負責：
    1. 驗證兩張 CSV：列ID／異動ID 對得上、段次對得上、判斷字對、分數與判斷相符、
       理由夠格。任何一條不過，整批中止，什麼都不寫（連帶決定表、報告都不動）。
    2. 通過後把「AI判斷」「AI分數」「AI理由」三欄寫回連帶決定表.csv（走
       decision_table.write_rows_csv，COLUMNS 之外的欄照留；「要改嗎」「改成什麼」
       原樣不動；指紋檔 .json 也不動，因為列指紋只算候選全文）。
    3. 產出人看得懂的報告：LLM審查報告.xlsx（三到四個工作表）。一份產出只出一種
       格式：xlsx 寫得出來就只有 xlsx，寫不出來（磁碟滿、檔案開在 Excel 裡）才
       每張工作表各退一個 _總結.csv／_候選.csv／_異動.csv，並發一則提醒。

AI 只寫判斷，不填「要改嗎」「改成什麼」——那兩欄仍是人的最終決定。
"""

import csv
import difflib
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import notices as nt
import review_pack as rp
import xlsx_writer as xw
from _common import _decode_text, format_scope, locate, place

CAND_VERDICTS = ("建議修改", "需再檢查", "不用改")
CHANGE_VERDICTS = ("沒問題", "需再檢查", "建議修改")
AI_COLUMNS = ["AI判斷", "AI分數", "AI理由"]
# 兩張 AI CSV 該有的欄（review_pack._write_ai_csv 寫出來的表頭）。缺欄、欄名打錯
# 的訊息要點名是哪一欄，見 _check_sheet_shape。
CAND_REQUIRED = ["列ID", "候選段次"] + AI_COLUMNS
CHANGE_REQUIRED = ["異動ID", "新版段次"] + AI_COLUMNS

_HIGH = {"建議修改"}           # 分數要 ≥ 7
_LOW = {"不用改", "沒問題"}     # 分數要 ≤ 3
_MID = {"需再檢查"}            # 分數要 4–6

_CSV_SUFFIX = {"總結": "_總結.csv", "候選審查": "_候選.csv", "異動審查": "_異動.csv",
               "原文已修改未匯入": "_原文不符.csv"}


class ReviewError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 讀兩張 AI CSV
# ---------------------------------------------------------------------------

def _read_ai_csv(path):
    """讀一張 AI CSV，回傳 (dict 的 list, 表頭欄名 list 或 None)。

    表頭要一起回傳（小瑕疵 19）：「缺欄位」「欄名打錯」「只有表頭」這三種問題
    光看資料列分不出來——欄名打錯時每一列的 AI判斷 都讀成空字串，錯誤訊息會變成
    幾十行「AI判斷不是允許的字：「」」，真正的原因（表頭上寫的是「AI判定」）
    一個字都沒有。見 _check_sheet_shape。

    編碼不寫死（should_fix no 27）：AI 填完的表多半經過 Excel 手動確認再存檔，
    台灣的 Excel 預設另存就是 Big5（cp950），選「Unicode 文字」則是 UTF-16。
    以前寫死 `encoding="utf-8-sig"` 而且沒有 try，這兩種檔一律
    UnicodeDecodeError traceback——人看到的是一坨堆疊，不知道是編碼問題。
    改走 `_common._decode_text`：它會先看 BOM（UTF-32／UTF-16），
    再依序試 utf-8-sig／utf-8／cp950／big5hkscs，而且解完做一次亂碼檢查。
    真的認不出來才轉成 ReviewError，訊息直接告訴人怎麼另存。
    """
    with io.open(path, "rb") as f:
        raw = f.read()
    try:
        text = _decode_text(raw, path)
    except (UnicodeDecodeError, ValueError, SystemExit):
        # SystemExit：_decode_text 的 _reject_if_garbled 解出亂碼時丟的就是它
        # （那是給 CLI 直接中止用的）。這一步是可以救的錯，要轉成本模組的錯誤型別，
        # 讓 run_all 印成「[中止] ……」而不是整串 traceback。
        raise ReviewError("AI 檔編碼讀不出來：%s（請在 Excel 另存成「CSV UTF-8」再匯入）" % path)
    # newline="" 跟 open(..., newline="") 同義：不做換行轉換，
    # 理由欄裡包在引號中的換行才不會被切成兩列。
    reader = csv.DictReader(io.StringIO(text, newline=""))
    rows = list(reader)
    return rows, (list(reader.fieldnames) if reader.fieldnames else None)


def load_ai_files(outdir):
    """讀 AI候選判斷.csv、AI異動審查.csv，回傳 (候選列, 異動列, 表頭資訊)。

    前兩個都是 dict 的 list；第三個是 {檔名: {"path": 路徑, "fieldnames": 欄名或 None}}，
    給 validate 判「表頭本身有沒有問題」用（見 _check_sheet_shape）。
    找不到檔案就 ReviewError；編碼認不出來也是 ReviewError（見 _read_ai_csv）；
    欄位內容對不對留給 validate 判斷。"""
    # 讀端走 locate：新排法（填寫表單/）優先，找不到再看舊排法（平鋪在 outdir）
    cand_path = locate(outdir, "AI候選判斷.csv")[0]
    change_path = locate(outdir, "AI異動審查.csv")[0]
    if not os.path.isfile(cand_path):
        raise ReviewError("找不到 AI候選判斷.csv：%s（請先跑 review-pack，讓 AI 填好再匯入）" % cand_path)
    if not os.path.isfile(change_path):
        raise ReviewError("找不到 AI異動審查.csv：%s（請先跑 review-pack，讓 AI 填好再匯入）" % change_path)
    cand_rows, cand_fields = _read_ai_csv(cand_path)
    change_rows, change_fields = _read_ai_csv(change_path)
    meta = {"AI候選判斷.csv": {"path": cand_path, "fieldnames": cand_fields},
            "AI異動審查.csv": {"path": change_path, "fieldnames": change_fields}}
    return cand_rows, change_rows, meta


# ---------------------------------------------------------------------------
# 驗證（純函式，不做任何 I/O）
# ---------------------------------------------------------------------------

def _s(value):
    """欄位值轉字串再去頭尾空白；AI CSV 讀出來一定是字串，但 validate 是公開的純函式，
    別的呼叫端（例如測試、Task 4）可能直接塞 int／None 進來，這裡不要讓它整個炸掉。"""
    return "" if value is None else str(value).strip()


_SCORE_RE = re.compile(r"^(10|[0-9])$")


def _score_ok(raw):
    """回傳 (通不通過, 分數)；一定要是半形 0–10 整數（`^(10|[0-9])$`，逐字元比對，
    不是先轉數字再判斷範圍）才算過。這樣擋得住 `int()` 會放行的怪輸入：全形數字
    （`int("８")` Python 認得，但人眼看不出跟半形的差別）、小數（`"8.0"`）。"""
    raw = _s(raw)
    if not _SCORE_RE.match(raw):
        return False, None
    return True, int(raw)


# 欄名「像但不等於」的門檻：「AI判定」對「AI判斷」是 0.75，「備註」對「AI理由」是 0。
_SIMILAR_ENOUGH = 0.6


def _looks_like(name, target):
    """name 是不是 target 打錯字的版本（不是就回 0）。"""
    return difflib.SequenceMatcher(None, name, target).ratio()


def _check_sheet_shape(filename, path, ai_rows, fieldnames, required_cols, expect_rows=True):
    """AI CSV 的「形狀」對不對：空檔／只有表頭／缺欄位／欄名打錯（小瑕疵 19）。

    為什麼要單獨檢查（而不是交給 _validate_sheet 逐列驗）：這四種問題在逐列驗證
    底下長得一模一樣——欄名打成「AI判定」時每一列的 AI判斷 都讀成空字串，
    畫面上是幾十行「AI判斷不是允許的字：「」」，人看不出真正的原因是表頭；
    表整個空掉時則是幾十行「缺列ID：R1、R2……」，同樣看不出檔案根本沒內容。
    四種各給一句話，講的是這一次真正發生的事：

        「%s」是空檔（0 bytes）
        「%s」只有表頭，沒有任何資料列
        「%s」缺欄位：%s
        「%s」欄名不對：%s（應為 %s）

    path 可以不給（None）：呼叫端手上只有已經讀好的列與表頭時，就只驗表頭。
    expect_rows=False 時不驗「只有表頭」——決定表本來就 0 列候選（compare 一筆
    候選都沒列）時，空白的 AI CSV 是正確的產出，不是壞檔。
    回傳錯誤字串 list；空 list 表示形狀沒問題，可以往下逐列驗。
    """
    errors = []
    if path and os.path.isfile(path):
        try:
            if os.path.getsize(path) == 0:
                return ["「%s」是空檔（0 bytes）" % filename]
        except OSError:
            pass
    if not fieldnames:
        # 有檔案但連表頭都讀不出來（整份空白、或只有幾個空行）：跟 0 bytes 同一件事。
        return ["「%s」是空檔（0 bytes）" % filename]

    actual = [(name or "").strip() for name in fieldnames]
    spare = [name for name in actual if name and name not in required_cols]
    missing = []
    for want in required_cols:
        if want in actual:
            continue
        # 有一個沒人認領、又跟它很像的欄名 → 是打錯字，不是缺欄位。
        best, best_score = "", 0.0
        for name in spare:
            score = _looks_like(name, want)
            if score > best_score:
                best, best_score = name, score
        if best and best_score >= _SIMILAR_ENOUGH:
            spare.remove(best)
            errors.append("「%s」欄名不對：%s（應為 %s）" % (filename, best, want))
        else:
            missing.append(want)
    if missing:
        errors.append("「%s」缺欄位：%s" % (filename, "、".join(missing)))
    if errors:
        return errors
    if expect_rows and not ai_rows:
        return ["「%s」只有表頭，沒有任何資料列" % filename]
    return []


def _validate_sheet(filename, ai_rows, id_col, id_prefix, pos_col, expected_ids, expected_pos):
    """驗證一張 AI CSV：列ID／異動ID 對齊、段次對得上、判斷字、分數、理由。
    verdicts 依 id_prefix 決定（候選用 R、異動用 C，剛好對應兩套判斷字）。
    回傳這張表全部的錯誤字串（不是遇第一個就停）。"""
    verdicts = CAND_VERDICTS if id_prefix == "R" else CHANGE_VERDICTS
    errors = []
    by_id = {}
    dup_ids = []
    for row in ai_rows:
        rid = _s(row.get(id_col))
        if not rid:
            continue
        if rid in by_id and rid not in dup_ids:
            # AI 填表把同一個列ID／異動ID 填到兩列：後面那列會把前面覆蓋掉，
            # 整份表看起來卻少了一列（另一列憑空消失），不擋住的話錯得很隱晦。
            dup_ids.append(rid)
        by_id[rid] = row
    for rid in dup_ids:
        errors.append("「%s」%s重複：%s" % (filename, id_col, rid))

    expected_set = set(expected_ids)
    actual_set = set(by_id.keys())
    for missing in expected_ids:
        if missing not in actual_set:
            errors.append("「%s」缺%s：%s" % (filename, id_col, missing))
    for extra in sorted(actual_set - expected_set, key=lambda x: (len(x), x)):
        errors.append("「%s」多出%s：%s" % (filename, id_col, extra))

    for i, rid in enumerate(expected_ids, 1):
        row = by_id.get(rid)
        if row is None:
            continue
        tag = "「%s」%s" % (filename, rid)

        actual_pos = _s(row.get(pos_col))
        want_pos = _s(expected_pos[i - 1])
        if actual_pos != want_pos:
            errors.append("%s：%s不符（決定表是「%s」，AI檔是「%s」）"
                          % (tag, pos_col, want_pos, actual_pos))

        verdict = _s(row.get("AI判斷"))
        verdict_ok = verdict in verdicts
        if not verdict_ok:
            errors.append("%s：AI判斷不是允許的字：「%s」（只能是 %s）"
                          % (tag, verdict, "／".join(verdicts)))

        score_ok, score = _score_ok(row.get("AI分數"))
        if not score_ok:
            errors.append("%s：分數要是 0–10 的半形整數：「%s」" % (tag, _s(row.get("AI分數"))))
        elif verdict_ok:
            if verdict in _HIGH and score < 7:
                errors.append("%s：分數 %d 與判斷「%s」不符（%s要 ≥ 7）" % (tag, score, verdict, verdict))
            elif verdict in _LOW and score > 3:
                errors.append("%s：分數 %d 與判斷「%s」不符（%s要 ≤ 3）" % (tag, score, verdict, verdict))
            elif verdict in _MID and not (4 <= score <= 6):
                errors.append("%s：分數 %d 與判斷「%s」不符（%s要 4–6）" % (tag, score, verdict, verdict))

        reason = _s(row.get("AI理由"))
        if not reason:
            errors.append("%s：AI理由是空的" % tag)
        else:
            if verdict == "建議修改" and "改成" not in reason:
                errors.append("%s：AI理由沒有寫「改成」（建議修改要寫建議改法）" % tag)
            if verdict == "需再檢查" and "請確認" not in reason and "請問" not in reason:
                errors.append("%s：AI理由沒有寫「請確認」或「請問」（需再檢查要寫查什麼、問誰）" % tag)

    return errors


def validate(rows, changes, ai_cand, ai_change, meta=None):
    """驗證 AI候選判斷.csv、AI異動審查.csv 兩張表，回傳全部錯誤字串（不是遇第一個
    就停）；沒有錯誤回傳空 list。純函式，不讀檔（meta 給了路徑時只 stat 檔案大小）。

    meta（選填，load_ai_files 的第三個回傳值）給了就先驗表頭的「形狀」——空檔、
    只有表頭、缺欄位、欄名打錯（見 _check_sheet_shape）。形狀不對的那一張表
    **不再逐列驗**：表頭都錯了，逐列驗只會噴幾十行看不出原因的衍生錯誤，
    把真正該講的那一句淹掉。"""
    meta = meta or {}

    def sheet_errors(filename, ai_rows, required, expect_rows, validate_args):
        info = meta.get(filename)
        if info is not None:
            shape = _check_sheet_shape(filename, info.get("path"), ai_rows,
                                       info.get("fieldnames"), required,
                                       expect_rows=expect_rows)
            if shape:
                return shape
        return _validate_sheet(*validate_args)

    cand_ids = ["R%d" % i for i in range(1, len(rows) + 1)]
    cand_pos = [_s(row.get("候選段次")) for row in rows]
    errors = sheet_errors("AI候選判斷.csv", ai_cand, CAND_REQUIRED, bool(rows),
                          ("AI候選判斷.csv", ai_cand, "列ID", "R", "候選段次",
                           cand_ids, cand_pos))

    change_ids = ["C%d" % i for i in range(1, len(changes) + 1)]
    change_pos = [_s(ch["new_index"]) if ch.get("new_index") else "刪除" for ch in changes]
    errors += sheet_errors("AI異動審查.csv", ai_change, CHANGE_REQUIRED, bool(changes),
                           ("AI異動審查.csv", ai_change, "異動ID", "C", "新版段次",
                            change_ids, change_pos))
    return errors


# ---------------------------------------------------------------------------
# 驗原文：決定表的「候選全文」有沒有被手改過
# ---------------------------------------------------------------------------

MISMATCH_SHEET = "原文已修改未匯入"
MISMATCH_HEADER = ["列ID", "候選段次", "候選全文（前 40 字）"]


def _sidecar_sha(sidecar_rows, index, line):
    """指紋檔裡對應這一列的 候選全文SHA256。

    先取同索引那一筆（決定表與指紋檔本來就是同一輪 compare 一起寫出來的，
    列序一致）；同索引那筆的候選段次對不上（有人在 Excel 裡排序過、插過列）
    就退而求其次用候選段次找。都對不上回空字串，當成「這列沒得驗」不算不符——
    驗原文是要擋「文字被改掉」，不該因為列序被動過就把整批判斷擋下來。
    """
    item = sidecar_rows[index] if index < len(sidecar_rows) else None
    # 段次空的列（跨本「無法定位」那種）只在指紋檔同索引那筆也沒有段次時才配；
    # 不然會拿別列的指紋來驗，驗到的不是自己。
    if item is not None and (item.get("候選段次") or 0) == (line or 0):
        return item.get("候選全文SHA256") or ""
    if line:
        for other in sidecar_rows:
            if other.get("候選段次") == line:
                return other.get("候選全文SHA256") or ""
    return ""


def check_row_texts(rows, sidecar):
    """逐列比對「候選全文」與指紋檔的 候選全文SHA256。

    回傳 (不符的列索引 set（0 起算）, 指紋檔有沒有列指紋)。

    為什麼要驗（should_fix no 3）：決定表是給人用 Excel 開來填「要改嗎」「改成什麼」
    的，同一張表上的「候選全文」欄很容易被順手改掉（想順便把錯字修掉、
    貼上時把儲存格蓋掉）。以前 review-import 只驗兩張 AI CSV 的列ID 對不對得上，
    改過的原文就這樣一路進到 LLM審查報告，報告上印的「候選全文」已經不是草稿裡
    那一段，但沒有任何一個字提示這件事。

    舊版留底的指紋檔沒有「列」（格式版本 1 之前的產出）就整批照舊匯入，
    由呼叫端發一則提醒——那不是「文字被改過」，是「這次沒得驗」。
    """
    sidecar_rows = (sidecar or {}).get("列") or []
    if not sidecar_rows:
        return set(), False
    bad = set()
    for i, row in enumerate(rows):
        expected = _sidecar_sha(sidecar_rows, i, dt.line_of(row.get("候選段次")))
        if not expected:
            continue
        if dt.text_sha256(row.get("候選全文") or "") != expected:
            bad.add(i)
    return bad, True


def mismatch_rows(rows, bad_idx):
    """「原文已修改未匯入」表的列：列ID、候選段次、候選全文前 40 字。"""
    out = []
    for i in sorted(bad_idx):
        row = rows[i] if i < len(rows) else {}
        text = row.get("候選全文") or ""
        out.append(["R%d" % (i + 1), row.get("候選段次") or "", text[:40]])
    return out


# ---------------------------------------------------------------------------
# 報告
# ---------------------------------------------------------------------------

def _count_by(ai_rows, verdicts):
    counts = dict((v, 0) for v in verdicts)
    for row in ai_rows:
        v = (row.get("AI判斷") or "").strip()
        if v in counts:
            counts[v] += 1
    return counts


def _score_cell(ai_row):
    """報告要數字格：分數轉得出來就給 int（xlsx_writer 會寫成 <v>），轉不出來就照抄字串。"""
    raw = _s(ai_row.get("AI分數"))
    try:
        return int(raw)
    except ValueError:
        return raw


def _cand_id_for(row, contexts):
    """報告要顯示的「候選條文ID」：決定表這欄本來就有填就直接用（決定表本身不動，
    這裡只是報告要顯示什麼）；是空的（沒有正式基準、regdiff 給不出條文ID 的候選，
    實測資料常見）就退回候選段落自己的章節脈絡——ref（例如「第六條」）優先，
    沒有 ref 才用 format_scope（章節，例如「第一章 第一節」）。找不到段落或
    contexts 沒給（沒有 book 可查）就維持空字串。"""
    cand_id = (row.get("候選條文ID") or "").strip()
    if cand_id or not contexts:
        return cand_id
    idx = dt.line_of(row.get("候選段次")) - 1
    if 0 <= idx < len(contexts):
        ctx = contexts[idx]
        return ctx.get("ref") or format_scope(ctx) or ""
    return cand_id


def report_tables(rows, changes, ai_cand, ai_change, book_name="", book=None, books=None,
                  mismatched=None):
    """產報告要的三張表：[(工作表名, header, rows), ...]。欄照規格第七節；「總結」
    前 10 筆依 AI分數 降冪、同分依列ID。批次時（book_name 非空）三張表最前面加
    一欄「規章」。`book`（`review_pack.load_book` 的回傳值，選填）給得出
    `new_contexts` 時，「候選條文ID」欄空白會退回候選段落的章節脈絡（見
    `_cand_id_for`）；不給就照決定表原樣（可能是空的）。`books`（{規章名: book}，
    選填）給跨本列（異動條文ID 是「X：ref」那種）用，沒給就只查得到自己這本，
    跨本列的「異動原條文」「異動修正後條文」會印「（找不到對應異動）」。

    `mismatched`（選填，不符指紋的列索引 set）非空時最後再多一張
    「原文已修改未匯入」表，讓看報告的人知道哪幾列的 AI 判斷沒有寫回去。"""
    cand_by_id = {(r.get("列ID") or "").strip(): r for r in ai_cand}
    change_by_id = {(r.get("異動ID") or "").strip(): r for r in ai_change}
    mini_book = {"changes": changes}  # changes_for_row 只用得到 book["changes"]
    contexts = (book or {}).get("new_contexts")

    # 「修改類型」緊跟在「異動條文ID」後面：那一欄講的就是這一列被哪一處異動帶出來的，
    # 是修改還是整條刪掉，判的事完全不同，不能只給 ID 叫人自己去翻異動清單。
    cand_header = ["列ID", "候選段次", "候選條文ID", "來源", "關係／分數", "異動條文ID",
                  "修改類型", "異動原條文", "異動修正後條文", "候選全文",
                  "AI判斷", "AI分數", "AI理由"]
    cand_rows = []
    for i, row in enumerate(rows, 1):
        rid = "R%d" % i
        ai_row = cand_by_id.get(rid, {})
        matches = rp.changes_for_row(row, mini_book, books)
        if matches:
            old_text = "\n\n".join((ch.get("old_text") or "") for _, ch in matches)
            new_text = "\n\n".join((ch.get("new_text") or "") for _, ch in matches)
        else:
            old_text = new_text = "（找不到對應異動）"
        cand_rows.append([
            rid, row.get("候選段次") or "", _cand_id_for(row, contexts), row.get("來源") or "",
            row.get("關係／分數") or "", row.get("異動條文ID") or "",
            row.get("修改類型") or "", old_text, new_text,
            row.get("候選全文") or "", ai_row.get("AI判斷") or "", _score_cell(ai_row),
            ai_row.get("AI理由") or "",
        ])

    change_header = ["異動ID", "新版段次", "條號", "修改類型", "原條文", "修正後條文",
                     "AI判斷", "AI分數", "AI理由"]
    change_rows = []
    for i, ch in enumerate(changes, 1):
        cid = "C%d" % i
        ai_row = change_by_id.get(cid, {})
        ref = ch.get("ref") or ch.get("scope") or ""
        change_rows.append([
            cid, ch.get("new_index") or "刪除", ref, ch.get("修改類型") or "",
            ch.get("old_text") or "", ch.get("new_text") or "",
            ai_row.get("AI判斷") or "", _score_cell(ai_row), ai_row.get("AI理由") or "",
        ])

    cand_counts = _count_by(ai_cand, CAND_VERDICTS)
    change_counts = _count_by(ai_change, CHANGE_VERDICTS)
    summary_header = ["項目", "數量"]
    # 「項目」欄光看「需再檢查」分不出是候選審查還是異動審查那一種，加「候選：」「異動：」
    # 字首才看得出兩個表各自的三種判斷數量。
    summary_rows = [["候選：%s" % v, cand_counts[v]] for v in CAND_VERDICTS]
    summary_rows += [["異動：%s" % v, change_counts[v]] for v in CHANGE_VERDICTS]
    summary_rows.append(["", ""])
    summary_rows.append(["分數最高前 10 筆", ""])
    # 「候選段次」緊跟在列ID 後面（小瑕疵 5）：這張總結是拿來排優先序、然後回決定表
    # 逐列處理的，只給列ID 的話人得先翻到「候選審查」表查段次，才找得到草稿裡的那一段。
    summary_rows.append(["列ID", "候選段次", "候選條文ID", "候選全文", "AI分數", "AI理由"])

    def _sort_key(i):
        ai_row = cand_by_id.get("R%d" % (i + 1), {})
        score_ok, score = _score_ok(ai_row.get("AI分數"))
        return (-score if score_ok else 1, i)

    for i in sorted(range(len(rows)), key=_sort_key)[:10]:
        rid = "R%d" % (i + 1)
        ai_row = cand_by_id.get(rid, {})
        row = rows[i]
        summary_rows.append([rid, row.get("候選段次") or "", _cand_id_for(row, contexts),
                             row.get("候選全文") or "",
                             _score_cell(ai_row), ai_row.get("AI理由") or ""])

    tables = [("總結", summary_header, summary_rows),
             ("候選審查", cand_header, cand_rows),
             ("異動審查", change_header, change_rows)]
    if mismatched:
        tables.append((MISMATCH_SHEET, MISMATCH_HEADER, mismatch_rows(rows, mismatched)))

    if book_name:
        tables = [(name, ["規章"] + header, [[book_name] + list(r) for r in table_rows])
                  for name, header, table_rows in tables]
    return tables


def write_report(base_path, tables, source="審查匯入"):
    """報告只出一種格式：先試 .xlsx，寫不出來（磁碟滿、檔案開在 Excel 裡）才
    每張工作表各退一個 .csv（`_總結.csv`、`_候選.csv`、`_異動.csv`、`_原文不符.csv`）
    並發一則提醒。回傳實際寫出來的第一個檔（xlsx 或第一份 csv）。

    以前是「csv 每次都寫、xlsx 再寫一次」，同一份報告在資料夾裡有四個檔，
    人分不出哪一個才是這次要看的；而且 csv 沒有欄寬、沒有換行，打開就是一團。

    這一輪沒有寫出來的檔（xlsx 成功時的那幾份 csv、或這一輪沒有「原文已修改未匯入」
    那張表的 `_原文不符.csv`）要把上一輪留下來的同名檔刪掉——不然人會拿上一輪的
    結果當成這一次的。"""
    names = dict((name, os.path.basename(base_path) + suffix)
                 for name, suffix in _CSV_SUFFIX.items())
    written = xw.write_tables_or_csv(base_path, tables, source=source, csv_names=names)
    kept = set(os.path.abspath(p) for p in written)
    for suffix in _CSV_SUFFIX.values():
        stale = base_path + suffix
        if os.path.abspath(stale) not in kept and os.path.isfile(stale):
            os.remove(stale)
    return written[0]


# ---------------------------------------------------------------------------
# 匯入主流程
# ---------------------------------------------------------------------------

def import_review(outdir, book_name="", books=None, book=None):
    """驗證兩張 AI CSV → 通過就把 AI判斷／AI分數／AI理由 三欄寫回連帶決定表.csv，
    再產出 LLM審查報告.xlsx 與三份保底 .csv。驗證不過就 raise ReviewError（訊息是
    每行一條的全部錯誤），什麼都不寫。`books`（{規章名: book}，選填）給跨本候選查
    來源本的異動全文用，見 report_tables。

    `book`（rp.load_book 的回傳值，選填）給得出就不再重新 load_book——批次逐本
    呼叫時，第一階段驗證已經 load_book 過一次（見 run_all.cmd_batch_review_import
    的 loaded dict），這裡不用再讀一次連帶決定表／異動清單／docx。

    匯入前先驗原文（should_fix no 3）：決定表上的「候選全文」要跟初比對指紋檔
    （<決定表>.json 的「列」）的 候選全文SHA256 一致，不一致的列不寫 AI 三欄，
    另外列一張「原文已修改未匯入」表並發一則警告。見 check_row_texts。

    回傳 {"候選": {判斷: 數}, "異動": {判斷: 數}, "報告": xlsx路徑,
          "表": [(工作表名, header, rows), ...], "原文不符": [列ID...]}。"""
    if book is None:
        book = rp.load_book(outdir)
    rows, changes = book["rows"], book["changes"]
    ai_cand, ai_change, ai_meta = load_ai_files(outdir)

    errors = validate(rows, changes, ai_cand, ai_change, ai_meta)
    if errors:
        raise ReviewError("\n".join(errors))

    csv_path = locate(outdir, "連帶決定表.csv")[0]
    sidecar = book.get("sidecar")
    if sidecar is None:
        # load_book 沒把指紋檔存進 book（舊的 book dict、或呼叫端自己組的）就補讀一次。
        try:
            sidecar = dt.read_sidecar(dt.sidecar_path_for(csv_path))
        except dt.DecisionTableError:
            sidecar = {}
        book["sidecar"] = sidecar
    bad_idx, has_fingerprints = check_row_texts(rows, sidecar)
    if not has_fingerprints:
        nt.notice(nt.REMINDER,
                  "指紋檔沒有列指紋，這次沒驗原文（舊版留底的產出資料夾）；"
                  "決定表上的候選全文有沒有被手改過，這一輪查不出來",
                  "review-import")
    mismatch_ids = ["R%d" % (i + 1) for i in sorted(bad_idx)]
    if mismatch_ids:
        nt.notice(nt.WARNING,
                  "有 %d 列候選全文與初比對指紋不符（列ID %s），這幾列的 AI 判斷沒有匯入；"
                  "請重跑 compare 或還原決定表"
                  % (len(mismatch_ids), "、".join(mismatch_ids)),
                  "review-import")

    cand_by_id = {(r.get("列ID") or "").strip(): r for r in ai_cand}
    for i, row in enumerate(rows, 1):
        if (i - 1) in bad_idx:
            # 候選全文已經不是初比對那一段了，AI 是照著被改過的文字判的；
            # 寫回去只會讓報告看起來有憑有據。三欄清空，不留上一輪的舊判斷——
            # 留著的話決定表上那一列會掛著跟旁邊文字對不上的 AI 建議，
            # 而人填「要改嗎」時看的正是這一張表（審查發現）。
            row["AI判斷"] = row["AI分數"] = row["AI理由"] = ""
            continue
        ai_row = cand_by_id.get("R%d" % i, {})
        _, score = _score_ok(ai_row.get("AI分數"))
        row["AI判斷"] = (ai_row.get("AI判斷") or "").strip()
        row["AI分數"] = str(score)
        row["AI理由"] = (ai_row.get("AI理由") or "").strip()

    dt.write_rows_csv(csv_path, rows)

    tables = report_tables(rows, changes, ai_cand, ai_change, book_name, book=book,
                           books=books, mismatched=bad_idx)
    # 報告是人要看的 → 審閱文件/。place 回傳的是帶副檔名的路徑，write_report 要的是
    # 不帶副檔名的 base（副檔名由它自己補，因為可能退成 csv）。
    report_path = write_report(os.path.splitext(place(outdir, "LLM審查報告.xlsx"))[0], tables)

    return {"候選": _count_by(ai_cand, CAND_VERDICTS), "異動": _count_by(ai_change, CHANGE_VERDICTS),
            "報告": report_path, "表": tables, "原文不符": mismatch_ids}
