# -*- coding: utf-8 -*-
"""
終比對驗收：三個問題。三個都是零才算改好。

一、填了「改」或「刪除」的，定稿裡真的改了嗎？
二、初比對的候選，還有沒填決定的嗎？（空白＝還沒決定；「不改」算已決定）
三、定稿冒出初比對沒列過的新候選嗎？

另外報一行（不擋結論）：
四、填了「改」但「改成什麼」跟原文一字不差的有幾列？那是人自己選的不改，
    定稿上不會有修訂記號；不講的話人會以為那幾列真的改過了。
"""

import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

REGDIFF = os.path.join(HERE, "regdiff")
if REGDIFF not in sys.path:
    sys.path.insert(0, REGDIFF)

import apply_changes as ac
import decision_table as dt
import notices as nt


# 三問的鍵。「等於原文」不在裡面：它不是「還有事沒做完」，不能擋「改好」。
BLOCKING_KEYS = ("未改到", "未決定", "新候選")
SAME_TEXT_KEY = "等於原文"


def blocking_total(answers):
    """會擋住「改好」的總數。只算三問，不算「等於原文」——那是人自己決定的不改。"""
    return sum(len(answers.get(key) or []) for key in BLOCKING_KEYS)


def three_questions(decision_rows, sidecar, clean_paragraphs, final_rows):
    clean = {dt.normalize(p) for p in clean_paragraphs}
    not_done = []
    same_text = []
    for row in decision_rows:
        if row["要改嗎"] == "改" and ac.same_after_normalize(row["候選全文"], row["改成什麼"]):
            # 填了「改」，但填的字跟原文一字不差。定稿上不會有任何修訂記號，
            # 定稿裡也「找得到」這段字，所以它不是「未改到」；但也不能默不作聲，
            # 不然人會以為這一列真的改過了。單獨列一行，不擋「改好」。
            #
            # 判定一定要用 apply 那一支（same_after_normalize），不可以自己用
            # dt.normalize 再判一次：dt.normalize 會把所有空白殺光，
            # 「改成什麼」只比原文多一個半形空格時，apply 真的寫了一處修訂、
            # 回報「已套用」，這裡卻會說「填了但等於原文（視為不改）」——
            # 同一列，兩支程式講相反的話，而人只會看到後面這一句。
            same_text.append(row)
        elif row["要改嗎"] == "改" and dt.normalize(row["改成什麼"]) not in clean:
            not_done.append(row)
        elif row["要改嗎"] == "刪除" and dt.normalize(row["候選全文"]) in clean:
            not_done.append(row)
    undecided = [row for row in decision_rows if row["要改嗎"] == ""]
    return {"未改到": not_done, "未決定": undecided,
            "新候選": fresh_rows(decision_rows, sidecar, final_rows),
            SAME_TEXT_KEY: same_text}


def fresh_rows(decision_rows, sidecar, rows):
    """rows 裡哪幾列是「初比對沒列過」的新候選。

    抽成獨立一支，是因為第三問不是只有 three_questions 要問：batch-finalize 拿各本
    定稿重算跨本連帶之後，那批跨本列也要用**同一把尺**篩過才能併進第三問。
    兩邊各寫一次 known 集合，遲早會漂開成「同一列在單本報告算新候選、在批次不算」。

    known 的三個來源：
    - sidecar「列」：初比對決定表列過的候選（人看過的）。
    - sidecar「異動段落SHA256」：初比對那一輪的異動段落本文，本來就會在定稿裡。
    - 決定表填「改」的「改成什麼」：那是人指定定稿要長成的樣子，定稿冒出來不算新的。
    """
    known = {entry["候選全文SHA256"] for entry in sidecar.get("列", [])}
    known |= set(sidecar.get("異動段落SHA256", []))
    known |= {dt.text_sha256(row["改成什麼"]) for row in decision_rows if row["要改嗎"] == "改"}
    return [row for row in rows if dt.text_sha256(row["候選全文"]) not in known]


def verdict(total, notices=None):
    """驗收結論那一行。畫面與報告檔共用同一支，兩邊不能各講各的。

    三問皆零但這一輪有警告（定稿仍含追蹤修訂、apply 中止……）時不准只寫「改好」：
    那三個問題問的是「決定表上的事做完了沒」，警告講的是「這份檔案本身有狀況」，
    是兩回事。只寫「改好」會讓人直接送出一份還帶著追蹤修訂的定稿。
    """
    if total:
        return "結論：還有 %d 處要看，請勿送出。回到連帶決定表補決定或補改，再跑一次。" % total
    alerts = nt.warnings(notices)
    if alerts:
        return ("結論：三問皆零，但有 %d 則警告（例：%s），請先看提醒段再決定是否送出。"
                % (len(alerts), _headline(alerts[0])))
    return "結論：改好。三個問題都是零。最終仍需人工複核後才能送出。"


def _headline(entry, limit=18):
    """警告本文取前一小段當例子，長的用刪節號收尾。"""
    text = (entry.get("文字") or "").split("：")[0].split("（")[0].strip()
    return text if len(text) <= limit else text[:limit] + "…"


def write_report(answers, path, notices=None):
    """寫終比對驗收報告。notices 是這次終比對累積的提醒，附在結論後面。

    為什麼提醒要進這一份：這是「可不可以送出」的那張紙。三問都是零、結論寫「改好」，
    但這一輪發生過「有 N 處標不上去」「跳過（原文不符）」的話，那個「改好」是有
    前提的。前提只印在畫面上等於沒講。
    """
    notices = nt.collected() if notices is None else notices
    total = blocking_total(answers)
    lines = ["終比對驗收報告", ""]
    for title, key in (("一、填了「改」或「刪除」但定稿裡沒改到"
                        "（含 apply 跳過的程式做不到類：找不到段、原文不符、"
                        "範本鎖定欄位、段落含巢狀內容）", "未改到"),
                       ("二、初比對候選還沒填決定（要改嗎留空）", "未決定"),
                       ("三、定稿冒出的新候選（初比對沒列過）", "新候選"),
                       ("四、填了「改」但「改成什麼」等於原文（視為不改，不擋結論）",
                        SAME_TEXT_KEY)):
        rows = answers.get(key) or []
        lines.append("%s：%d 列" % (title, len(rows)))
        for row in rows:
            lines.append("   段次 %s  %s  %s" % (row.get("候選段次") or "-", row.get("來源", ""),
                                                 (row.get("候選全文") or "")[:40]))
        lines.append("")
    lines.append(verdict(total, notices))
    if notices:
        lines.append("")
        lines.append("※ 這一輪有 %d 則提醒，上面的結論要連提醒一起看。" % len(notices))
    lines.append("")
    lines += nt.report_lines(notices)
    with io.open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")
    return total == 0
