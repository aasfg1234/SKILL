# output

請把完成的檔案放在這個資料夾：

- `completed-presentation.json`（必要）：完整的 Presentation Specification，
  其中 AI 任務的 `status` 為 `completed` 且帶有 `result`。
- `final-presentation.html`（選用）：可直接以瀏覽器開啟的簡報。
- `validation-report.json`（選用）：你自行執行的驗證結果。

使用者會把 `completed-presentation.json` 匯回 SlideForge｜簡報鍛造所。
