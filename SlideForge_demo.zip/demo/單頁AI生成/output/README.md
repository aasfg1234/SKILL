# 輸出

請將`single-slide-result.json`放在這裡，再交回使用者。
