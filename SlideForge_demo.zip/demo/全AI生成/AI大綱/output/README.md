# 輸出

請將`full-ai-outline-result.json`放在這裡，再交回使用者。
