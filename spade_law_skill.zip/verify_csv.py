#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_csv.py  --  交付前驗證

實際讀檔、實際比對。不做口頭宣稱。
全部通過才回傳 0，有任何一項失敗回傳 1。

用法：
    python verify_csv.py --dir D:\\Spade\\ws\\law_kb
"""

import argparse
import csv
import io
import json
import os
import sys
from collections import Counter

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

F01 = "01_完整判讀.csv"
F02 = "02_銀行體系專屬義務.csv"
F03 = "03_引用追查.csv"
F04 = "04_完整性核對.csv"
FJSON = "law_units.json"

COL_ID = "紀錄編號"
COL_ART = "條號"
COL_SRC = "來源"
COL_CLASS = "分類"
COL_STATUS = "判讀狀態"
COL_REL = "關聯紀錄編號"
COL_SCOPE = "適用身分"
STATUS_DONE = "已完成"
VALID_CLASS = {"A1_銀行兼營保代專屬", "A2_銀行兼營保經專屬", "A3_金控轉投資子公司",
               "A4_銀行轉投資子公司", "B_保經代通用", "C_不適用", "D_引用他法"}
VALID_SCOPE = {"S1_銀行兼營保代", "S2_銀行兼營保經",
               "S3_金控轉投資子公司", "S4_銀行轉投資子公司"}

fail = []


def p(*a):
    print(*a, flush=True)


def bad(m):
    fail.append(m)
    p("  [失敗] %s" % m)


def ok(m):
    p("  [通過] %s" % m)


def split_multi(v):
    v = (v or "").strip()
    if not v:
        return []
    for s in ["；", ";", "，", ",", "|"]:
        v = v.replace(s, "\n")
    return [x.strip() for x in v.split("\n") if x.strip()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=".")
    args = ap.parse_args()
    d = args.dir

    def load(name):
        path = os.path.join(d, name)
        if not os.path.exists(path):
            bad("找不到檔案 %s" % name)
            return None, None
        try:
            with open(path, "r", encoding="utf-8-sig", newline="") as f:
                r = csv.DictReader(f)
                return r.fieldnames or [], list(r)
        except Exception as e:
            bad("%s 解析失敗：%s" % (name, e))
            return None, None

    p("=" * 70)
    p("步驟 1：解析四個 CSV")
    p("=" * 70)
    h1, r1 = load(F01)
    h2, r2 = load(F02)
    h3, r3 = load(F03)
    h4, r4 = load(F04)
    for n, h, r in [(F01, h1, r1), (F02, h2, r2), (F03, h3, r3), (F04, h4, r4)]:
        if r is None:
            continue
        p("  %s：%d 列，%d 欄" % (n, len(r), len(h)))
        p("    欄位：%s" % h)
        p("    每列欄位數分布：%s" % dict(Counter(len(x) for x in r)))

    if r1 is None:
        p("01 檔讀不到，後面無法比對。")
        sys.exit(1)

    p("")
    p("=" * 70)
    p("步驟 2：紀錄編號重複與代碼合法性")
    p("=" * 70)
    for n, r in [(F01, r1), (F02, r2), (F03, r3)]:
        if r is None:
            continue
        ids = [(x.get(COL_ID) or "").strip() for x in r]
        dup = [k for k, c in Counter(ids).items() if c > 1 and k]
        if dup:
            bad("%s 紀錄編號重複：%s" % (n, dup))
        else:
            ok("%s 紀錄編號沒有重複" % n)
        blank = [i for i, x in enumerate(ids, 2) if not x]
        if blank:
            bad("%s 有空白紀錄編號，第 %s 列" % (n, blank[:10]))

    badcls = sorted({(x.get(COL_CLASS) or "").strip() for x in r1} - VALID_CLASS - {""})
    if badcls:
        bad("01 檔出現未定義的分類代碼：%s" % badcls)
    else:
        ok("01 檔分類代碼全部合法")

    badsc = set()
    for x in r1:
        for s in split_multi(x.get(COL_SCOPE)):
            if s not in VALID_SCOPE:
                badsc.add(s)
    if badsc:
        bad("01 檔出現未定義的適用身分代碼：%s" % sorted(badsc))
    else:
        ok("01 檔適用身分代碼全部合法")

    p("")
    p("=" * 70)
    p("步驟 3：02 檔要等於 01 檔篩選（分類 A 開頭 + %s）" % STATUS_DONE)
    p("=" * 70)
    if r2 is None:
        bad("02 檔讀不到")
    else:
        expect = {(x.get(COL_ID) or "").strip() for x in r1
                  if (x.get(COL_CLASS) or "").strip().startswith("A")
                  and (x.get(COL_STATUS) or "").strip() == STATUS_DONE}
        actual = {(x.get(COL_ID) or "").strip() for x in r2}
        p("  01 篩出 %d 筆，02 檔 %d 筆" % (len(expect), len(actual)))
        oe = sorted(expect - actual)
        oa = sorted(actual - expect)
        if oe:
            bad("01 有但 02 漏掉：%s" % oe)
        if oa:
            bad("02 有但 01 篩不出來：%s" % oa)
        if not oe and not oa:
            ok("02 檔與 01 檔篩選結果一致")

    p("")
    p("=" * 70)
    p("步驟 4：03 檔關聯編號要存在於 01 檔")
    p("=" * 70)
    if r3 is None:
        bad("03 檔讀不到")
    else:
        id1 = {(x.get(COL_ID) or "").strip() for x in r1}
        missing = []
        for x in r3:
            for ref in split_multi(x.get(COL_REL)):
                if ref not in id1:
                    missing.append((x.get(COL_ID), ref))
        if missing:
            bad("03 檔引用到 01 檔沒有的編號：%s" % missing)
        else:
            ok("03 檔關聯編號全部對得到")

    p("")
    p("=" * 70)
    p("步驟 5：01 檔內部一致性")
    p("=" * 70)
    id1 = {(x.get(COL_ID) or "").strip() for x in r1}
    badrel = []
    for x in r1:
        for ref in split_multi(x.get(COL_REL)):
            if ref not in id1:
                badrel.append((x.get(COL_ID), ref))
    if badrel:
        bad("01 檔關聯編號指到不存在的紀錄：%s" % badrel)
    else:
        ok("01 檔關聯編號全部對得到")

    badexc = []
    for x in r1:
        v = (x.get("例外或排除") or "").strip()
        if v.startswith("排除"):
            for ref in split_multi(v.replace("排除", "")):
                if ref not in id1:
                    badexc.append((x.get(COL_ID), ref))
    if badexc:
        bad("但書排除的編號不存在：%s" % badexc)
    else:
        ok("但書排除欄位全部對得到")

    p("")
    p("=" * 70)
    p("步驟 6：01 檔 vs law_units.json")
    p("=" * 70)
    jp = os.path.join(d, FJSON)
    if not os.path.exists(jp):
        bad("找不到 %s" % FJSON)
    else:
        law = json.load(open(jp, encoding="utf-8"))
        meta = law.get("meta", {})
        seq = set(meta.get("article_seq", []))
        incsv = {(x.get(COL_ART) or "").strip() for x in r1 if (x.get(COL_ART) or "").strip()}
        p("  law_units.json ARTICLES=%s UNITS=%s" % (meta.get("ARTICLES"), meta.get("UNITS")))
        p("  01 檔涵蓋 %d 條，原文 %d 條" % (len(incsv), len(seq)))
        miss = sorted(seq - incsv)
        extra = sorted(incsv - seq)
        if miss:
            bad("01 檔缺這些條：%s" % miss)
        if extra:
            bad("01 檔多出原文沒有的條：%s" % extra)
        if not miss and not extra:
            ok("條號集合完全一致")

        allkeys = set()
        for a in law.get("articles", []):
            allkeys.add(a["key"])
            for u in a.get("units", []):
                allkeys.add(u["key"])
        badsrc = sorted({(x.get(COL_SRC) or "").strip() for x in r1} - allkeys - {""})
        if badsrc:
            bad("01 檔來源欄有不存在的 key：%s" % badsrc[:20])
        else:
            ok("01 檔來源欄全部對得到 law_units.json 的 key")

        if r4 is None:
            bad("04 檔讀不到")
        else:
            flat = " ".join(" ".join((v or "") for v in x.values()) for x in r4)
            for label, val in [("ARTICLES", meta.get("ARTICLES")),
                               ("UNITS", meta.get("UNITS"))]:
                if str(val) in flat:
                    ok("04 檔有出現 %s=%s" % (label, val))
                else:
                    bad("04 檔找不到 %s=%s" % (label, val))
            ng = [x.get("檢查項目") for x in r4 if (x.get("結果") or "").strip() == "不通過"]
            wait = [x.get("檢查項目") for x in r4 if (x.get("結果") or "").strip() == "待補"]
            if ng:
                bad("04 檔自身有不通過項目：%s" % ng)
            else:
                ok("04 檔沒有不通過項目")
            if wait:
                p("  [待補] 04 檔有待補項目，不擋交付但要跟使用者講：%s" % wait)

    p("")
    p("=" * 70)
    if fail:
        p("驗證結果：不通過，共 %d 項" % len(fail))
        for i, m in enumerate(fail, 1):
            p("  %d. %s" % (i, m))
        p("=" * 70)
        sys.exit(1)
    p("驗證結果：全部通過")
    p("注意：格式全過不代表法律判斷正確。")
    p("A 類（數量最少最關鍵）與 D 類（引用來的最易錯）要人工抽樣覆核。")
    p("=" * 70)


if __name__ == "__main__":
    main()
