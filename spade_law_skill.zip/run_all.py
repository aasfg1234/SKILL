#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_all.py  --  一次跑完一個階段

階段 scan  ：parse_law.py + scan_keywords.py（關卡一、二）
階段 build ：make_csv.py + verify_csv.py（關卡四）

用法：
    python run_all.py --stage scan  --dir D:\\Spade\\ws\\law_kb
    python run_all.py --stage build --dir D:\\Spade\\ws\\law_kb
"""

import argparse
import io
import os
import subprocess
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))


def p(*a):
    print(*a, flush=True)


def run(script, argv):
    path = os.path.join(HERE, script)
    p("")
    p("#" * 70)
    p("# 執行 %s" % script)
    p("#" * 70)
    r = subprocess.run([sys.executable, path] + argv,
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.stdout:
        p(r.stdout.rstrip())
    if r.stderr:
        p("--- 錯誤輸出 ---")
        p(r.stderr.rstrip())
    p("# %s 離開代碼：%d" % (script, r.returncode))
    return r.returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["scan", "build"], required=True)
    ap.add_argument("--dir", default=".")
    args = ap.parse_args()
    d = os.path.abspath(args.dir)
    os.makedirs(d, exist_ok=True)

    if args.stage == "scan":
        rc = run("parse_law.py", ["--indir", d, "--outdir", d])
        if rc != 0:
            p("")
            p("解析失敗，停在關卡一。不繼續。")
            sys.exit(1)
        rc = run("scan_keywords.py", ["--dir", d])
        if rc != 0:
            sys.exit(1)
        p("")
        p("=" * 70)
        p("關卡一、二完成。請使用者確認條號清單，再進關卡三引用鏈。")
        p("=" * 70)
        return

    rc = run("make_csv.py", ["--dir", d])
    if rc != 0:
        p("")
        p("CSV 產出失敗，不進驗證。")
        sys.exit(1)
    rc = run("verify_csv.py", ["--dir", d])
    p("")
    p("=" * 70)
    if rc == 0:
        p("四份 CSV 已產出且驗證全過。位置：%s" % d)
        p("下一步：人工抽樣覆核 A 類與 D 類。")
    else:
        p("驗證沒過。修 judgements.json 之後重跑：python run_all.py --stage build --dir %s" % d)
    p("=" * 70)
    sys.exit(rc)


if __name__ == "__main__":
    main()
