#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
scan_keywords.py  --  第二關：掃出可能適用的條號

讀 law_units.json，依四種身分的關鍵字掃描，輸出：
  scan_result.json  給後面的程式吃
  scan_result.csv   給人看

只列條號和命中的關鍵字。不做判讀。

用法：
    python scan_keywords.py --dir D:\\Spade\\ws\\law_kb
"""

import argparse
import csv
import io
import json
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

# 四種身分。命中任一關鍵字就列進來。
SCOPES = {
    "S1_銀行兼營保代": ["銀行", "兼營", "銀行保險", "金融機構"],
    "S2_銀行兼營保經": ["銀行", "兼營", "銀行保險", "金融機構"],
    "S3_金控轉投資子公司": ["金融控股", "子公司", "轉投資", "投資", "持股", "母公司"],
    "S4_銀行轉投資子公司": ["銀行", "轉投資", "子公司", "投資", "持股"],
}
ALL_KW = sorted({k for v in SCOPES.values() for k in v})


def p(*a):
    print(*a, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=".")
    args = ap.parse_args()
    d = args.dir

    fp = os.path.join(d, "law_units.json")
    if not os.path.exists(fp):
        p("錯誤：找不到 law_units.json。請先執行 parse_law.py。")
        sys.exit(1)
    law = json.load(open(fp, encoding="utf-8"))

    hits = []
    for a in law["articles"]:
        t = a["t"]
        found = [k for k in ALL_KW if k in t]
        if not found:
            continue
        scopes = [s for s, kws in SCOPES.items() if any(k in t for k in kws)]
        hits.append({
            "條號": a["key"],
            "法規": a["law"],
            "章節": a.get("chapter", ""),
            "命中關鍵字": "；".join(found),
            "可能身分": "；".join(scopes),
            "單位數": len(a["units"]),
            "字數": len(t),
            "首句": t[:40],
        })

    with open(os.path.join(d, "scan_result.json"), "w", encoding="utf-8") as f:
        json.dump({"hits": hits}, f, ensure_ascii=False, indent=2)

    cols = ["條號", "法規", "章節", "命中關鍵字", "可能身分", "單位數", "字數", "首句"]
    with open(os.path.join(d, "scan_result.csv"), "w",
              encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for h in hits:
            w.writerow(h)

    p("=" * 60)
    p("關鍵字掃描結果")
    p("=" * 60)
    per = {}
    for h in hits:
        per[h["法規"]] = per.get(h["法規"], 0) + 1
    for k, v in per.items():
        p("%-14s 命中 %d 條" % (k, v))
    p("-" * 60)
    p("合計命中 %d 條，全部原文 %d 條" % (len(hits), law["meta"]["ARTICLES"]))
    p("-" * 60)
    p("命中條號：")
    p("、".join(h["條號"] for h in hits))
    p("-" * 60)
    p("已寫出：scan_result.json、scan_result.csv")
    p("停。請使用者確認這份清單範圍正確，才可以進下一關。")
    p("=" * 60)


if __name__ == "__main__":
    main()
