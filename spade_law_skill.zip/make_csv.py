#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_csv.py  --  產出四份 CSV

吃 judgements.json（判讀結果）加 law_units.json（原文），吐出四份 CSV。
02 檔由程式從 01 篩，不手抄。
04 檔的數字直接抄 law_units.json 的 meta，不另外估算。

用法：
    python make_csv.py --dir D:\\Spade\\ws\\law_kb
"""

import argparse
import csv
import io
import json
import os
import sys
from collections import Counter

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

COLS01 = ["紀錄編號", "法規", "條號", "單位", "來源", "適用身分", "規範對象",
          "義務動作", "分類", "判讀狀態", "例外或排除", "關聯紀錄編號",
          "原文摘錄", "備註"]
COLS03 = ["紀錄編號", "關聯紀錄編號", "引用類型", "被引用標的",
          "是否取得原文", "取得方式", "影響說明"]
COLS04 = ["檢查項目", "原文依據", "數值", "結果", "說明"]

F01 = "01_完整判讀.csv"
F02 = "02_銀行體系專屬義務.csv"
F03 = "03_引用追查.csv"
F04 = "04_完整性核對.csv"
STATUS_DONE = "已完成"


def p(*a):
    print(*a, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=".")
    args = ap.parse_args()
    d = args.dir

    fj = os.path.join(d, "judgements.json")
    fl = os.path.join(d, "law_units.json")
    for f in (fj, fl):
        if not os.path.exists(f):
            p("錯誤：找不到 %s" % f)
            sys.exit(1)

    law = json.load(open(fl, encoding="utf-8"))
    jud = json.load(open(fj, encoding="utf-8"))
    meta = law.get("meta", {})
    records = jud.get("records", [])
    refs = jud.get("references", [])
    if not records:
        p("錯誤：judgements.json 的 records 是空的。")
        sys.exit(1)

    allkeys = {}
    for a in law.get("articles", []):
        allkeys[a["key"]] = a["t"]
        for u in a.get("units", []):
            allkeys[u["key"]] = u["t"]

    for r in records:
        if not r.get("原文摘錄"):
            r["原文摘錄"] = allkeys.get((r.get("來源") or "").strip(), "")
        if not r.get("法規") and r.get("條號"):
            r["法規"] = r["條號"].split("-")[0]

    def write(name, cols, rows):
        path = os.path.join(d, name)
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            for r in rows:
                w.writerow({c: r.get(c, "") for c in cols})
        p("寫出 %s：%d 列" % (name, len(rows)))

    write(F01, COLS01, records)

    sel = [r for r in records
           if (r.get("分類") or "").strip().startswith("A")
           and (r.get("判讀狀態") or "").strip() == STATUS_DONE]
    write(F02, COLS01, sel)
    write(F03, COLS03, refs)

    seq = set(meta.get("article_seq", []))
    incsv = {(r.get("條號") or "").strip() for r in records if r.get("條號")}
    miss = sorted(seq - incsv)
    extra = sorted(incsv - seq)
    noorig = [r.get("紀錄編號") for r in records
              if (r.get("判讀狀態") or "").strip() == "未取得原文"]
    noref = [r.get("紀錄編號") for r in refs
             if (r.get("是否取得原文") or "").strip() == "否"]
    per_law = meta.get("per_law", {})
    notup = [v["name"] for v in per_law.values() if v.get("status") == "未上傳"]

    cnt = Counter((r.get("分類") or "").strip() for r in records)
    scope = Counter()
    for r in records:
        for s in (r.get("適用身分") or "").replace(";", "；").split("；"):
            if s.strip():
                scope[s.strip()] += 1

    check = [
        {"檢查項目": "原文條文總數", "原文依據": "law_units.json",
         "數值": "ARTICLES=%s" % meta.get("ARTICLES"), "結果": "通過",
         "說明": "直接引用 meta，未另行估算"},
        {"檢查項目": "原文單位總數", "原文依據": "law_units.json",
         "數值": "UNITS=%s" % meta.get("UNITS"), "結果": "通過",
         "說明": "直接引用 meta，未另行估算"},
        {"檢查項目": "key 唯一性", "原文依據": "law_units.json",
         "數值": str(meta.get("key_unique")),
         "結果": "通過" if meta.get("key_unique") else "不通過",
         "說明": "重複 key：%s" % (meta.get("duplicate_keys") or "無")},
        {"檢查項目": "法規檔上傳狀況", "原文依據": "laws.json",
         "數值": "未上傳 %d 部" % len(notup),
         "結果": "通過" if not notup else "待補",
         "說明": "未上傳：%s。相關條文只能標未取得原文" % (notup or "無")},
        {"檢查項目": "01 檔條號涵蓋", "原文依據": "law_units.json + 01",
         "數值": "缺 %d 條，多 %d 條" % (len(miss), len(extra)),
         "結果": "通過" if not miss and not extra else "不通過",
         "說明": "缺：%s；多：%s" % (miss or "無", extra or "無")},
        {"檢查項目": "01 檔紀錄總數", "原文依據": F01,
         "數值": str(len(records)), "結果": "通過", "說明": "拆列後列數"},
        {"檢查項目": "分類分布", "原文依據": F01,
         "數值": "；".join("%s=%d" % (k, v) for k, v in sorted(cnt.items())),
         "結果": "通過", "說明": "A 開頭合計即 02 檔母體"},
        {"檢查項目": "適用身分分布", "原文依據": F01,
         "數值": "；".join("%s=%d" % (k, v) for k, v in sorted(scope.items())),
         "結果": "通過", "說明": "四種身分各命中幾列"},
        {"檢查項目": "A 類已完成筆數", "原文依據": F02,
         "數值": str(len(sel)), "結果": "通過", "說明": "程式篩出，需人工抽樣覆核"},
        {"檢查項目": "未取得原文紀錄", "原文依據": F01,
         "數值": str(len(noorig)),
         "結果": "通過" if not noorig else "待補",
         "說明": "編號：%s" % (noorig or "無")},
        {"檢查項目": "引用未取得原文", "原文依據": F03,
         "數值": str(len(noref)),
         "結果": "通過" if not noref else "待補",
         "說明": "編號：%s" % (noref or "無")},
    ]
    write(F04, COLS04, check)

    dup = [k for k, c in Counter(r.get("紀錄編號") for r in records).items() if c > 1]
    p("-" * 60)
    if dup:
        p("警告：01 檔紀錄編號重複：%s" % dup)
    p("分類分布：%s" % dict(cnt))
    p("身分分布：%s" % dict(scope))
    p("完成。接著執行：python verify_csv.py --dir %s" % d)


if __name__ == "__main__":
    main()
