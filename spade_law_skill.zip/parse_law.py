#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
parse_law.py  --  法規原文切條程式（SPADE 版）

只用 Python 內建功能。沒有用 bs4，因為 SPADE 沒有 pip。

讀 laws.json 列出的每一個 HTML 檔，切成條 / 項 / 款 / 目，
合併成一個 law_units.json。

用法（在 SPADE 裡）：
    python parse_law.py --indir D:\\Spade\\ws\\law_kb --outdir D:\\Spade\\ws\\law_kb
"""

import argparse
import io
import json
import os
import re
import sys
from collections import Counter
from html.parser import HTMLParser

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

CN = "零一二三四五六七八九十百千"
RE_KUAN = re.compile(r"^[%s]+[、.]" % CN)
RE_MU = re.compile(r"^([（(][%s]+[)）]|\d+[.、])" % CN)
RE_ARTNO = re.compile(r"第\s*([0-9]+(?:[-之][0-9]+)?)\s*條")
RE_CHAPTER = re.compile(r"^第\s*[%s]+\s*[章節編]" % CN)


def p(*a):
    print(*a, flush=True)


def die(msg, code=1):
    p("=" * 60)
    p("錯誤：%s" % msg)
    p("已中止。沒有產生 law_units.json。")
    p("=" * 60)
    sys.exit(code)


def clean(s):
    s = s.replace("\u3000", " ").replace("\xa0", " ")
    s = re.sub(r"\s+", " ", s)
    return s.strip()


class LawHTMLParser(HTMLParser):
    """抓 div.col-no（條號）與 div.line-XXXX（條文行）與章節標題。"""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows = []          # (kind, value, indent)
        self.depth = 0
        self.cap = None         # ('no'|'line'|'chapter', indent, start_depth)
        self.buf = []
        self.skip = 0           # script/style

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.skip += 1
            return
        if tag != "div":
            return
        self.depth += 1
        if self.cap is not None:
            return
        cls = ""
        for k, v in attrs:
            if k == "class" and v:
                cls = v
        if "col-no" in cls:
            self.cap = ("no", 0, self.depth)
            self.buf = []
        elif "line-" in cls:
            m = re.search(r"line-(\d+)", cls)
            self.cap = ("line", int(m.group(1)) if m else 0, self.depth)
            self.buf = []
        elif "char-" in cls or "h3" in cls.split():
            self.cap = ("chapter", 0, self.depth)
            self.buf = []

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.skip = max(0, self.skip - 1)
            return
        if tag != "div":
            return
        if self.cap is not None and self.depth == self.cap[2]:
            kind, indent, _ = self.cap
            txt = clean(" ".join(self.buf))
            self.cap = None
            self.buf = []
            if txt:
                if kind == "no":
                    m = RE_ARTNO.search(txt)
                    if m:
                        self.rows.append(("article", m.group(1).replace("之", "-"), 0))
                elif kind == "chapter":
                    if RE_CHAPTER.match(txt) and len(txt) < 40:
                        self.rows.append(("chapter", txt, 0))
                else:
                    self.rows.append(("line", txt, indent))
        self.depth = max(0, self.depth - 1)

    def handle_data(self, data):
        if self.skip:
            return
        if self.cap is not None and data.strip():
            self.buf.append(data)


def read_html(path):
    for enc in ("utf-8", "utf-8-sig", "big5", "cp950"):
        try:
            with open(path, "r", encoding=enc, errors="strict") as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def fallback_rows(html):
    """沒有 div.row 結構時的備援：把標籤拔掉，用「第 N 條」硬切。"""
    text = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
    text = re.sub(r"<[^>]+>", "\n", text)
    rows = []
    cur = None
    for raw in text.split("\n"):
        s = clean(raw)
        if not s:
            continue
        m = re.fullmatch(r"第\s*([0-9]+(?:[-之][0-9]+)?)\s*條", s)
        if m:
            cur = m.group(1).replace("之", "-")
            rows.append(("article", cur, 0))
        elif cur:
            rows.append(("line", s, 0))
    return rows


def split_proviso(t):
    for m in re.finditer(r"但", t):
        i = m.start()
        if i > 0 and t[i - 1] in "。；;，,、：:":
            return t[:i].strip(), t[i:].strip()
    return t, None


def sort_key(raw):
    if "-" in raw:
        a, b = raw.split("-", 1)
        return (int(a), int(b))
    return (int(raw), 0)


def build(rows, code):
    articles = []
    chapter = ""
    cur = None
    xi = ki = mi = 0
    last = None
    for kind, val, indent in rows:
        if kind == "chapter":
            chapter = val
            continue
        if kind == "article":
            no = "第%s條" % val
            cur = {"law": code, "no": no, "no_raw": val, "chapter": chapter,
                   "key": "%s-%s" % (code, no), "t": "", "units": []}
            articles.append(cur)
            xi = ki = mi = 0
            last = None
            continue
        if cur is None:
            continue
        txt = val
        if RE_MU.match(txt):
            mi += 1
            key = "%s-%s-項%d-款%d-目%d" % (code, cur["no"], max(xi, 1), max(ki, 1), mi)
            cur["units"].append({"key": key, "type": "目", "t": txt})
            last = cur["units"][-1]
        elif RE_KUAN.match(txt):
            ki += 1
            mi = 0
            key = "%s-%s-項%d-款%d" % (code, cur["no"], max(xi, 1), ki)
            cur["units"].append({"key": key, "type": "款", "t": txt})
            last = cur["units"][-1]
        elif indent == 0 or last is None:
            xi += 1
            ki = mi = 0
            key = "%s-%s-項%d" % (code, cur["no"], xi)
            cur["units"].append({"key": key, "type": "項", "t": txt})
            last = cur["units"][-1]
        else:
            last["t"] = (last["t"] + txt).strip()

    for a in articles:
        a["t"] = "".join(u["t"] for u in a["units"])
        for u in a["units"]:
            body, prov = split_proviso(u["t"])
            u["body"] = body
            u["proviso"] = prov
            u["has_proviso"] = prov is not None
            u["len"] = len(u["t"])
        a["empty"] = (not a["units"]) or len(a["t"]) < 5
    return articles


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--indir", default=".")
    ap.add_argument("--outdir", default=".")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    cfg_path = os.path.join(args.indir, "laws.json")
    if not os.path.exists(cfg_path):
        die("找不到 laws.json，位置：%s" % cfg_path)
    cfg = json.load(open(cfg_path, encoding="utf-8"))

    all_articles = []
    per_law = {}
    missing_files = []

    for law in cfg.get("laws", []):
        code = law["code"]
        fn = os.path.join(args.indir, law["file"])
        if not os.path.exists(fn):
            missing_files.append((code, law["file"], law.get("required", False)))
            per_law[code] = {"name": law["name"], "status": "未上傳",
                             "ARTICLES": 0, "UNITS": 0, "article_seq": []}
            continue
        html = read_html(fn)
        pr = LawHTMLParser()
        pr.feed(html)
        rows = pr.rows
        if not any(r[0] == "article" for r in rows):
            rows = fallback_rows(html)
        arts = build(rows, code)
        if not arts:
            die("%s（%s）抓不到任何條文。請確認存檔的是法規內容整頁。" % (code, law["file"]))
        arts.sort(key=lambda a: sort_key(a["no_raw"]))
        all_articles.extend(arts)
        units = sum(len(a["units"]) for a in arts)
        mains = sorted({int(a["no_raw"].split("-")[0]) for a in arts})
        gaps = [n for n in range(mains[0], mains[-1] + 1) if n not in mains]
        per_law[code] = {
            "name": law["name"],
            "status": "已解析",
            "file": law["file"],
            "ARTICLES": len(arts),
            "UNITS": units,
            "article_seq": [a["key"] for a in arts],
            "missing_article_numbers": ["第%d條" % n for n in gaps],
            "empty_articles": [a["key"] for a in arts if a["empty"]],
        }

    if not all_articles:
        die("一個法規檔都沒讀到。請先把 HTML 上傳，或檢查 laws.json 的檔名。")

    keys = [a["key"] for a in all_articles] + \
           [u["key"] for a in all_articles for u in a["units"]]
    dup = [k for k, c in Counter(keys).items() if c > 1]
    seq = [a["key"] for a in all_articles]
    units_total = sum(len(a["units"]) for a in all_articles)

    data = {
        "meta": {
            "ARTICLES": len(all_articles),
            "UNITS": units_total,
            "article_seq": seq,
            "key_unique": not dup,
            "duplicate_keys": dup,
            "per_law": per_law,
            "missing_files": [{"code": c, "file": f, "required": r}
                              for c, f, r in missing_files],
        },
        "articles": all_articles,
    }
    out = os.path.join(args.outdir, "law_units.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    # 摘要印在最後面。SPADE 截斷是留尾巴切開頭。
    p("=" * 60)
    p("解析結果")
    p("=" * 60)
    for code, v in per_law.items():
        p("%-10s %-28s %s  ARTICLES=%d UNITS=%d"
          % (code, v["name"], v["status"], v["ARTICLES"], v["UNITS"]))
        if v.get("missing_article_numbers"):
            p("           原文缺號：%s" % v["missing_article_numbers"])
        if v.get("empty_articles"):
            p("           疑似空條：%s" % v["empty_articles"])
    p("-" * 60)
    p("ARTICLES 總數 ：%d" % len(all_articles))
    p("UNITS 總數    ：%d" % units_total)
    p("key 唯一性    ：%s" % ("通過" if not dup else "失敗 %s" % dup[:10]))
    if missing_files:
        p("未上傳的法規  ：%s" % [f for _, f, _ in missing_files])
        req = [f for _, f, r in missing_files if r]
        if req:
            p("其中必要檔案未上傳：%s  →  這幾部法規只能標『未取得原文』" % req)
    p("-" * 60)
    p("條號序列（前 40 筆）：")
    p("、".join(seq[:40]) + ("…" if len(seq) > 40 else ""))
    p("完整序列在 law_units.json 的 meta.article_seq")
    p("-" * 60)
    p("已寫出：%s" % out)
    p("=" * 60)


if __name__ == "__main__":
    main()
