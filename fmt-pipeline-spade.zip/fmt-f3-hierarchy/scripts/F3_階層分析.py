# -*- coding: utf-8 -*-
r"""
F3：階層分析

用法：
    py F3_階層分析.py <資料夾>

輸入：<資料夾>\F1_paragraphs.csv
輸出：<資料夾>\F3_階層清單.csv      每一段推斷出來的階層，以及依據
      <資料夾>\F3_階層違規.csv      不符合階層規則的段落
      <資料夾>\F3_建議階層表.csv    每一階建議用什麼編號與縮排
      <資料夾>\F3_階層報告.txt

它在回答什麼
    「這份規章總共有幾階？每一階長什麼樣？哪些地方階層是亂的？」

怎麼推斷階層
    章、節看標題：樣式含「標題」、或開頭是「第X章」「第X節」
    其餘看編號種類：在同一個章節範圍裡，
    照「第一次出現的先後」決定它是第幾階。
    這是相對階層，不是固定的，因為不同章節可能少用一階。

抓哪六種階層亂象
    一、同一階用了兩種以上編號寫法
    二、跳階　例如（一）底下直接接（1），中間少了 1、
    三、縮排與階層矛盾　階層更深但縮排沒有更深
    四、同一階縮排不一致
    五、自動清單的階層與推斷階層不合
    六、子編號重新起算前疑似漏寫父階編號

只讀不改。
"""

import csv
import io
import os
import re
import sys
import collections

CH_PREFIX = "第"
lines = []


def say(s=""):
    lines.append(s)


def num(v, d=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return d


def mark_class(t):
    """把編號寫法歸成「類」。

    收尾標點不同（1、 與 1.）是同一階的寫法不一致，不是兩個階層。
    全形半形括號也是一樣（（一）與 (一)）。
    推階層要先歸類，不然同一階會被拆成兩階。

    反過來，大小寫中文數字（一 與 壹）、英文大小寫（A 與 a）
    是不同階層，不可以合併。合併的話最多只推得出五階。
    """
    t = t or "無"

    if t.startswith("第X") and len(t) >= 3:
        return t[:3]                      # 第X章 / 第X節 / 第X條 / 第X點…

    if "括號" in t:
        if "大寫中文" in t:
            return "括號大寫中文"
        if "英文大寫" in t:
            return "括號英文大寫"
        if "英文小寫" in t:
            return "括號英文小寫"
        if "數字" in t:
            return "括號數字"
        return "括號中文"

    for pre in ("大寫中文數字", "中文數字", "數字",
                "羅馬大寫", "羅馬小寫", "英文大寫", "英文小寫"):
        if t.startswith(pre):
            return pre

    if t.startswith("英文字母"):          # 舊版 F1 產出的相容寫法
        return "英文大寫"

    return "無"


def is_chapter(r):
    t = (r.get("全文") or "").lstrip()
    return t.startswith(CH_PREFIX) and "章" in t[:8] and len(t) <= 40


def is_section(r):
    t = (r.get("全文") or "").lstrip()
    return t.startswith(CH_PREFIX) and "節" in t[:8] and len(t) <= 60


CN_DIGITS = {
    "一": 1, "二": 2, "三": 3, "四": 4, "五": 5,
    "六": 6, "七": 7, "八": 8, "九": 9, "十": 10,
}


def cn_value(s):
    """讀取一至九十九的中文數字。"""
    if not s:
        return None
    if "十" not in s:
        return CN_DIGITS.get(s)
    left, right = s.split("十", 1)
    tens = CN_DIGITS.get(left, 1) if left else 1
    ones = CN_DIGITS.get(right, 0) if right else 0
    return tens * 10 + ones


def cn_render(v):
    """把 1 至 99 轉成中文數字。"""
    by_value = dict((n, k) for k, n in CN_DIGITS.items() if n < 10)
    if 1 <= v <= 9:
        return by_value[v]
    if 10 <= v <= 99:
        tens, ones = divmod(v, 10)
        return ("" if tens == 1 else by_value[tens]) + "十" + (by_value[ones] if ones else "")
    return ""


def mark_value(mark):
    """讀取段首編號的數值；只用於判斷同階是否重新從 1 起算。"""
    s = (mark or "").strip()
    m = re.search(r"\d+", s)
    if m:
        return int(m.group())
    m = re.search(r"[一二三四五六七八九十]+", s)
    if m:
        return cn_value(m.group())
    return None


def next_parent_mark(mark):
    """依目前父階編號，產生下一個同階編號的顯示文字。"""
    s = (mark or "").strip()
    v = mark_value(s)
    if not v:
        return "下一個父階編號"
    nv = v + 1
    cm = re.search(r"[一二三四五六七八九十]+", s)
    if cm:
        new = cn_render(nv)
        if new:
            return s[:cm.start()] + new + s[cm.end():]
    m = re.search(r"\d+", s)
    if m:
        return s[:m.start()] + str(nv) + s[m.end():]
    return "下一個父階編號"


STANDALONE_CUE = re.compile(r"(前項|前款|前目|前述|上述|下列|以下)")


def standalone_intro(text):
    """自己獨立一段、沒有編號的導入句。

    真檔常見的形狀是這樣：

        3、 要保人透過生物辨識……不在此限。
        前項確認程序，應依下列方式執行：      <- 這一段，原文漏寫了 (二)
        1、 首次經由本行與保險公司洽訂保險契約……

    find_embedded_intro 只認得導入句「接在上一段尾端」那一種。
    那是 data_835 測資的形狀，因為那份測資是有損還原稿，段落被合併過。
    真檔裡導入句是獨立的一段，要另外認。

    三個條件都成立才算：長度不超過 120、結尾是冒號、含前項或下列這類詞。
    實測整本規章符合的只有 7 段，再配上「同階重新從 1 起算」就只剩 1 段。
    """
    s = (text or "").strip()
    if not s or len(s) > 120:
        return ""
    if not s.endswith("：") and not s.endswith(":"):
        return ""
    if not STANDALONE_CUE.search(s):
        return ""
    return s


def find_embedded_intro(text, mark):
    """找出編號子項末尾、用來引出下一組子項的導入句。

    例如「3、……不在此限。前項確認程序，應依下列方式執行：」。
    單靠子編號重新從 1 起算不足以判斷父階漏號；必須同時出現這種
    位於上一個子項結尾的新導入句，才列為「疑似缺少父階編號」。
    """
    s = (text or "").strip()
    lead = (mark or "").strip()
    if lead and s.startswith(lead):
        s = s[len(lead):].lstrip()

    cue = re.compile(
        r"(?P<intro>(?:前項|前款|前目|前述|上述|以下|下列)"
        r"[^。！？；;]{0,100}?(?:下列|以下|方式|程序|項目|情形|事項)"
        r"[^。！？；;]{0,60}?[：:])"
    )
    hits = list(cue.finditer(s))
    if not hits:
        return ""
    hit = hits[-1]
    # 導入句必須在本子項正文之後，且前面已有一句完整內容；避免把正常的
    # 「1、前項……如下：」誤認成父階漏號。
    before = s[:hit.start()].rstrip()
    if not before or before[-1:] not in "。！？；;":
        return ""
    return hit.group("intro")


def main(folder):
    src = os.path.join(folder, "F1_paragraphs.csv")
    if not os.path.isfile(src):
        say("找不到 " + src)
        say("請先在有 Word 的電腦跑 F1_格式盤點.bas。")
        return None

    with io.open(src, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    body = [r for r in rows if (r.get("全文") or "").strip()]

    say("=" * 64)
    say("F3 階層分析報告")
    say("資料夾：" + folder)
    say("=" * 64)
    say()
    say("段落 %d 段" % len(body))

    # ---------- 推斷階層 ----------
    out = []
    cur_ch, cur_se = "", ""
    order = []           # 這個章節範圍裡，編號種類第一次出現的順序
    scope = None

    for r in body:
        mk = r.get("開頭符號類型") or "無"
        rec = dict(r)

        if is_chapter(r):
            cur_ch = (r.get("全文") or "")[:30]
            cur_se = ""
            order = []
            scope = (cur_ch, cur_se)
            rec.update({"所在章": cur_ch, "所在節": "", "種類": "章",
                        "階層": 1, "階層名": "第1階", "依據": "開頭是第X章"})
            out.append(rec)
            continue

        if is_section(r):
            cur_se = (r.get("全文") or "")[:30]
            order = []
            scope = (cur_ch, cur_se)
            rec.update({"所在章": cur_ch, "所在節": cur_se, "種類": "節",
                        "階層": 2, "階層名": "第2階", "依據": "開頭是第X節"})
            out.append(rec)
            continue

        if mk == "無":
            # 自動編號清單的段落，編號不在文字裡，但 Word 記得它在第幾階。
            # 不看這一欄的話，這些段落會被當成「無編號」，階層推斷整個失效。
            ll = int(num(r.get("清單層級"), 0))
            if r.get("是否清單") == "Y" and ll > 0:
                rec.update({"所在章": cur_ch, "所在節": cur_se,
                            "編號類": "自動清單", "種類": "自動清單",
                            "階層": ll + 2, "階層名": "第%d階" % (ll + 2),
                            "依據": "Word 自動清單的第 %d 階" % ll})
                out.append(rec)
                continue
            rec.update({"所在章": cur_ch, "所在節": cur_se, "種類": "無編號",
                        "階層": "", "階層名": "無編號", "依據": "沒有開頭編號"})
            out.append(rec)
            continue

        cls = mark_class(mk)
        if cls not in order:
            order.append(cls)
        lv = order.index(cls) + 3      # 章佔第1階、節佔第2階，條列從第3階起
        rec.update({"所在章": cur_ch, "所在節": cur_se, "編號類": cls,
                    "種類": "編號", "階層": lv, "階層名": "第%d階" % lv,
                    "依據": "本範圍第 %d 種出現的編號類（%s）" % (lv - 2, cls)})
        out.append(rec)

    # ---------- 統計每一階 ----------
    say()
    say("1. 每一階有幾段、用什麼編號")
    by_lv = collections.defaultdict(list)
    for r in out:
        by_lv[r["階層名"]].append(r)

    suggest = []
    def lv_key(x):
        return (1, 0) if x == "無編號" else (0, int(x.replace("第", "").replace("階", "")))

    for name in sorted(by_lv, key=lv_key):
        grp = by_lv[name]
        cc = collections.Counter(r.get("開頭符號類型") or "無" for r in grp)
        ind = collections.Counter(r.get("左縮排") or "0" for r in grp)
        say()
        say("   【%s】%d 段" % (name, len(grp)))
        top_mk = cc.most_common(1)[0]
        say("      編號：%d 種，多數是「%s」（%d/%d）"
            % (len(cc), top_mk[0], top_mk[1], len(grp)))
        for k, v in cc.most_common()[1:]:
            say("         少數：「%s」%d 段" % (k, v))
        top_ind = ind.most_common(1)[0]
        say("      左縮排：%d 種，多數是 %s（%d/%d）"
            % (len(ind), top_ind[0], top_ind[1], len(grp)))
        for k, v in ind.most_common()[1:4]:
            say("         少數：%s 共 %d 段" % (k, v))
        suggest.append({
            "階層名": name, "段數": len(grp),
            "建議編號": top_mk[0], "編號符合": top_mk[1],
            "編號待改": len(grp) - top_mk[1],
            "建議左縮排": top_ind[0], "縮排符合": top_ind[1],
            "縮排待改": len(grp) - top_ind[1],
        })

    # ---------- 抓違規 ----------
    bad = []

    def flag(r, kind, why, related=""):
        """related：跟這一筆連動、下游也要一起小心處理的段落序號。

        例如「疑似缺少父階編號」報在下一組的第一段，但真正要動的是
        那句導入句。F4 如果不知道，會把導入句當成前言自動改縮排。
        """
        bad.append({"序號": r.get("序號"), "階層名": r.get("階層名"),
                    "違規": kind, "說明": why, "相關序號": related,
                    "所在章": r.get("所在章", ""), "所在節": r.get("所在節", ""),
                    "全文": (r.get("全文") or "")[:60]})

    # 一、同一階兩種以上編號
    for name, grp in by_lv.items():
        cc = collections.Counter(r.get("開頭符號類型") or "無" for r in grp)
        kinds = set(r.get("種類") for r in grp)
        if len(cc) > 1 and not (kinds & {"章", "節", "無編號"}):
            top = cc.most_common(1)[0][0]
            for r in grp:
                if (r.get("開頭符號類型") or "無") != top:
                    flag(r, "同階兩種編號",
                         "這一階多數用「%s」，這段用「%s」"
                         % (top, r.get("開頭符號類型")))

    # 二、跳階
    #
    # 第1階是章、第2階是節。有的章底下沒有分節，直接接條列，那是正常的
    # 文件寫法，不是跳階。只有條列之間（第3階以下）才算。
    # 這條規則要跟 F4_比對.py 一致，兩邊都只從第3階起算。
    prev_lv = None
    for r in out:
        lv = r.get("階層")
        if not isinstance(lv, int):
            continue
        if prev_lv is not None and prev_lv >= 3 and lv > prev_lv + 1:
            flag(r, "跳階", "上一段是第 %d 階，這段直接跳到第 %d 階"
                 % (prev_lv, lv))
        prev_lv = lv

    # 二之一、子編號重新起算，但重新起算前出現新的導入句。
    #
    # 一般文件容許同一父項底下有多組 1、2、3、，因此「又看到 1」本身
    # 不能報錯。若上一個子項尾端另有「前項……應依下列方式執行：」等
    # 導入句，卻沒有先出現新的父階編號，才是疑似漏寫父階的強訊號。
    last_at_level = {}
    active_at_level = {}
    pending_plain = []      # 上一個有編號段落之後出現的無編號段落
    last_numbered = None    # 文件上最近一個有編號的段落，不分階
    for r in out:
        lv = r.get("階層")
        if not isinstance(lv, int):
            # 無編號段落先存起來。導入句有可能就是這種自己一段的。
            if r.get("種類") == "無編號":
                pending_plain.append(r)
            continue

        # 進入較淺階時，較深階的舊狀態已失效。
        for old_lv in list(active_at_level):
            if old_lv > lv:
                active_at_level.pop(old_lv, None)
                last_at_level.pop(old_lv, None)
        active_at_level[lv] = r

        cur_v = mark_value(r.get("開頭符號"))
        prev = last_at_level.get(lv)

        # 同階的前一段，必須就是文件上緊鄰的前一個有編號段落。
        #
        # 中間夾了別階的編號，代表那是另一個父項底下的新清單，重新從 1
        # 起算很正常，不是漏編號。少了這一條會誤報：
        #   6、…            <- 同階前一段
        #   (三) 適格性審查：  <- 中間夾了別階
        #   (五) 合作保險公司之管理原則
        #   以下列項目作為…：
        #   1、…            <- 這裡從 1 起算是正常的
        if prev is not None and prev is not last_numbered:
            prev = None

        if cur_v == 1 and prev:
            prev_v = mark_value(prev.get("開頭符號"))

            # 形狀一：導入句接在上一個子項的尾端（有損還原稿常見）
            intro = find_embedded_intro(prev.get("全文"), prev.get("開頭符號"))
            where = prev.get("序號")
            shape = "前一段尾端"

            # 形狀二：導入句自己一段，沒有編號（真檔常見）
            if not intro:
                for p in pending_plain:
                    t = standalone_intro(p.get("全文"))
                    if t:
                        intro = t
                        where = p.get("序號")
                        shape = "獨立一段"
                        break

            parent = active_at_level.get(lv - 1)
            if prev_v and prev_v >= 2 and intro and parent:
                want = next_parent_mark(parent.get("開頭符號"))
                flag(
                    r,
                    "疑似缺少父階編號",
                    "上一組子編號已到 %d，下一段又從 1 起算；中間有新導入句"
                    "「%s」（%s）。疑似應在該導入句前補「%s」（插入位置：第 %s 段）。"
                    % (prev_v, intro, shape, want, where),
                    related=str(where),
                )
        last_at_level[lv] = r
        last_numbered = r
        pending_plain = []

    # 三、縮排與階層矛盾　四、同一階縮排不一致
    lv_ind = {}
    for name, grp in by_lv.items():
        if set(r.get("種類") for r in grp) & {"章", "節", "無編號"}:
            continue
        ind = collections.Counter(r.get("左縮排") or "0" for r in grp)
        lv_ind[name] = num(ind.most_common(1)[0][0])
        if len(ind) > 1:
            top = ind.most_common(1)[0][0]
            for r in grp:
                if (r.get("左縮排") or "0") != top:
                    flag(r, "同階縮排不一致",
                         "這一階多數縮排 %s，這段是 %s"
                         % (top, r.get("左縮排")))

    names = sorted(lv_ind, key=lambda x: int(x.replace("第", "").replace("階", "")))

    for a, b in zip(names, names[1:]):
        if lv_ind[b] <= lv_ind[a]:
            say()
            say("   [亂象] %s 的縮排 %.0f 沒有比 %s 的 %.0f 更深"
                % (b, lv_ind[b], a, lv_ind[a]))

    # 五、同一個清單樣板裡，階層對應不一致
    #
    # 不可以拿「Word 清單層級」直接跟「推斷階層」比。
    #   Word 的清單層級是「在這個清單樣板裡的第幾階」
    #   推斷階層是「在整份文件結構裡的第幾階」
    # 兩者本來就不是同一個東西。只要清單掛在樣板第 1 階、實際巢狀較深，
    # 直接比就會誤報。實測一份測資 3 段全中，誤報率 100%。
    #
    # 有意義的檢查是：同一個樣板底下，兩者的落差應該是固定的。
    # 落差不一致，才代表那個樣板被拿去掛在不同深度。
    tpl_off = collections.defaultdict(list)
    for r in out:
        if r.get("是否清單") != "Y":
            continue
        ll = int(num(r.get("清單層級"), 0))
        lv = r.get("階層")
        if not ll or not isinstance(lv, int):
            continue
        tpl_off[r.get("清單樣板") or "（未命名樣板）"].append((r, lv - ll))

    for tpl, items in tpl_off.items():
        offs = collections.Counter(o for _, o in items)
        if len(offs) < 2:
            continue
        top = offs.most_common(1)[0][0]
        for r, o in items:
            if o != top:
                flag(r, "清單階層對不上",
                     "清單樣板「%s」多數掛在深度差 %d，這一段是 %d"
                     % (tpl, top, o))

    say()
    say("2. 階層違規")
    cc = collections.Counter(b["違規"] for b in bad)
    if not bad:
        say("   沒有")
    for k, v in cc.most_common():
        say("   %-14s %d 段" % (k, v))
    for b in bad[:12]:
        say("   第 %s 段　%s" % (b["序號"], b["違規"]))
        say("      %s" % b["說明"])
        say("      %s" % b["全文"][:50])

    say()
    say("=" * 64)
    say("結論")
    say("   推斷出 %d 個階層" % len([k for k in by_lv if k.startswith("第")]))
    say("   階層違規合計 %d 段" % len(bad))
    say("   若照多數決訂階層標準，編號要改 %d 段、縮排要改 %d 段"
        % (sum(s["編號待改"] for s in suggest),
           sum(s["縮排待改"] for s in suggest)))
    say("=" * 64)

    return out, bad, suggest


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py F3_階層分析.py <資料夾>")
        sys.exit(1)

    folder = sys.argv[1]
    res = main(folder)

    if res:
        out, bad, suggest = res
        cols = ["序號", "所在章", "所在節", "階層", "階層名", "種類", "編號類", "依據",
                "開頭符號", "開頭符號類型", "是否清單", "清單層級",
                "左縮排", "首行縮排", "樣式", "字型", "字級", "全文"]
        with io.open(os.path.join(folder, "F3_階層清單.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols, quoting=csv.QUOTE_ALL)
            w.writeheader()
            for r in out:
                w.writerow(dict((c, r.get(c, "")) for c in cols))
        with io.open(os.path.join(folder, "F3_階層違規.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["序號", "階層名", "違規", "說明",
                                              "相關序號",
                                              "所在章", "所在節", "全文"],
                               quoting=csv.QUOTE_ALL)
            w.writeheader()
            w.writerows(bad)
        with io.open(os.path.join(folder, "F3_建議階層表.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["階層名", "段數", "建議編號",
                                              "編號符合", "編號待改",
                                              "建議左縮排", "縮排符合", "縮排待改"],
                               quoting=csv.QUOTE_ALL)
            w.writeheader()
            w.writerows(suggest)
        say()
        say("已寫出 F3_階層清單.csv（%d 列）、F3_階層違規.csv（%d 列）、"
            "F3_建議階層表.csv（%d 列）" % (len(out), len(bad), len(suggest)))

    report = "\n".join(lines)
    with io.open(os.path.join(folder, "F3_階層報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if res else 1)
