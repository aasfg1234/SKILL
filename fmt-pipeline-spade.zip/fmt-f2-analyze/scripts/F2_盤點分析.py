# -*- coding: utf-8 -*-
r"""
F2：盤點分析

用法：
    py F2_盤點分析.py <資料夾>

輸入：<資料夾>\F1_paragraphs.csv     （F1 格式盤點的產出）
輸出：<資料夾>\F2_變體清單.csv        一種寫法一列，各幾段、例子在哪
      <資料夾>\F2_建議標準.csv        每一層建議用什麼，少數的列出來
      <資料夾>\F2_盤點報告.txt

它在回答什麼
    「這份規章的格式，總共有幾種寫法？哪一種是多數？」

沒有現成的公司格式規範，所以標準從這份文件反推：
**同一層裡面用最多的那一種，就是建議標準。** 其餘的列成待改清單。

只讀不改。這一階段不動任何文字。
"""

import csv
import io
import os
import sys
import collections

# 用來分層的依據：開頭編號的種類
LAYER_ORDER = ["中文數字", "括號中文", "數字", "括號數字", "英文字母", "無編號"]

# 每一層要看的格式維度
DIMS = ["開頭符號類型", "是否清單", "清單類型", "樣式",
        "字型", "字級", "粗體", "斜體", "底線", "刪除線", "字色", "標示色",
        "對齊", "左縮排", "右縮排", "首行縮排",
        "行距規則", "行距", "段前", "段後",
        "段落網底", "段落下框線", "段前分頁", "與下段同頁", "段中不分頁"]

lines = []


def say(s=""):
    lines.append(s)


def layer_of(row):
    """把「開頭符號類型」歸到同一「類」。

    跟 F3_階層分析.py 的 mark_class 同一套規則，兩邊要一致。
    收尾標點與全形半形括號視為同一類；
    中文數字大小寫、英文大小寫是不同類，不可以合併。
    """
    t = row.get("開頭符號類型", "") or ""

    if t.startswith("第X") and len(t) >= 3:
        return t[:3]

    if "括號" in t:
        if "大寫中文" in t:
            return "括號大寫中文"
        if "英文大寫" in t:
            return "括號英文大寫"
        if "英文小寫" in t:
            return "括號英文小寫"
        if "數字" in t:
            return "括號數字"
        return "括號中文"

    for pre in ("大寫中文數字", "中文數字", "數字",
                "羅馬大寫", "羅馬小寫", "英文大寫", "英文小寫"):
        if t.startswith(pre):
            return pre

    if t.startswith("英文字母"):
        return "英文大寫"

    return "無編號"


def main(folder):
    src = os.path.join(folder, "F1_paragraphs.csv")
    if not os.path.isfile(src):
        say("找不到 " + src)
        say("請先在有 Word 的電腦跑 F1_格式盤點.bas。")
        return None

    with io.open(src, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    body = [r for r in rows if r.get("全文", "").strip()]

    say("=" * 64)
    say("F2 盤點分析報告")
    say("資料夾：" + folder)
    say("=" * 64)
    say()
    say("段落 %d 段，其中有文字的 %d 段" % (len(rows), len(body)))

    # ---------- 1 標題是清單還是純文字 ----------
    say()
    say("1. 編號是「Word 自動清單」還是「人打的字」")
    c = collections.Counter(r.get("是否清單", "") for r in body)
    say("   自動清單 %d 段　純文字 %d 段" % (c.get("Y", 0), c.get("N", 0)))
    if c.get("Y") and c.get("N"):
        say("   [亂象] 兩種都有。改編號規則時，自動清單那些會整批跳動，純文字那些不會。")
    tl = collections.Counter(r.get("清單樣板", "") for r in body
                             if r.get("是否清單") == "Y")
    if tl:
        say("   用到的清單樣板：")
        for k, v in tl.most_common():
            say("      %-28s %d 段" % (k[:28], v))

    # ---------- 2 每一層的編號寫法 ----------
    say()
    say("2. 每一層的編號寫法")
    by_layer = collections.defaultdict(list)
    for r in body:
        by_layer[layer_of(r)].append(r)

    variants = []
    suggest = []
    for lay in LAYER_ORDER:
        grp = by_layer.get(lay, [])
        if not grp:
            continue
        say()
        say("   【%s】共 %d 段" % (lay, len(grp)))
        cc = collections.Counter(r.get("開頭符號類型", "") for r in grp)
        for k, v in cc.most_common():
            ex = next(r for r in grp if r.get("開頭符號類型") == k)
            mark = "  <- 多數" if k == cc.most_common(1)[0][0] else ""
            say("      %-16s %4d 段%s" % (k, v, mark))
            say("         例：%s" % ex.get("全文", "")[:44])
            variants.append({
                "維度": "開頭符號類型", "層": lay, "寫法": k, "段數": v,
                "占比": "%.1f%%" % (100.0 * v / len(grp)),
                "是否多數": "Y" if k == cc.most_common(1)[0][0] else "N",
                "例子序號": ex.get("序號", ""), "例子": ex.get("全文", "")[:60],
            })
        if len(cc) > 1:
            say("      [亂象] 同一層有 %d 種寫法" % len(cc))

    # ---------- 3 每一層的排版 ----------
    say()
    say("3. 每一層的排版（字型、字級、縮排…）")
    for lay in LAYER_ORDER:
        grp = by_layer.get(lay, [])
        if not grp:
            continue
        say()
        say("   【%s】" % lay)
        for d in DIMS:
            if d == "開頭符號類型":
                continue
            cc = collections.Counter((r.get(d, "") or "（空白）") for r in grp)
            if len(cc) <= 1:
                continue
            top, tn = cc.most_common(1)[0]
            say("      %-8s %d 種寫法，多數是「%s」（%d/%d）"
                % (d, len(cc), top, tn, len(grp)))
            for k, v in cc.most_common()[1:6]:
                ex = next(r for r in grp if (r.get(d, "") or "（空白）") == k)
                say("           少數：「%s」%d 段，例如第 %s 段"
                    % (k, v, ex.get("序號", "")))
                variants.append({
                    "維度": d, "層": lay, "寫法": k, "段數": v,
                    "占比": "%.1f%%" % (100.0 * v / len(grp)),
                    "是否多數": "N",
                    "例子序號": ex.get("序號", ""), "例子": ex.get("全文", "")[:60],
                })
            variants.append({
                "維度": d, "層": lay, "寫法": top, "段數": tn,
                "占比": "%.1f%%" % (100.0 * tn / len(grp)),
                "是否多數": "Y", "例子序號": "", "例子": "",
            })
            suggest.append({
                "層": lay, "維度": d, "建議標準": top,
                "符合段數": tn, "待改段數": len(grp) - tn,
                "符合率": "%.1f%%" % (100.0 * tn / len(grp)),
            })

    # 編號寫法的建議標準
    for lay in LAYER_ORDER:
        grp = by_layer.get(lay, [])
        if not grp:
            continue
        cc = collections.Counter(r.get("開頭符號類型", "") for r in grp)
        top, tn = cc.most_common(1)[0]
        suggest.insert(0, {
            "層": lay, "維度": "開頭符號類型", "建議標準": top,
            "符合段數": tn, "待改段數": len(grp) - tn,
            "符合率": "%.1f%%" % (100.0 * tn / len(grp)),
        })

    # ---------- 4 空白亂象 ----------
    say()
    say("4. 用空白排版的情形")
    n3 = sum(1 for r in body if (r.get("前導全形空格") or "0") not in ("0", ""))
    n1 = sum(1 for r in body if (r.get("前導半形空格") or "0") not in ("0", ""))
    nt = sum(1 for r in body if r.get("含Tab") == "Y")
    nb = sum(1 for r in body if r.get("含手動換行") == "Y")
    say("   前導全形空格 %d 段　前導半形空格 %d 段" % (n3, n1))
    say("   含 Tab %d 段　含手動換行 %d 段" % (nt, nb))
    if n3 or n1 or nt:
        say("   [亂象] 有人用空格或 Tab 排版。那不是縮排，換字型就會跑掉。")

    # ---------- 5 一段裡面格式不一致 ----------
    say()
    say("5. 一段裡面格式不一致的")
    for d in ("粗體", "斜體", "底線", "刪除線", "字級", "字型", "字色", "標示色"):
        n = sum(1 for r in body if r.get(d) == "混合")
        if n:
            say("   %-4s 混合 %d 段" % (d, n))
    say("   （混合代表同一段裡面有的有、有的沒有，例如只有幾個字是粗體）")

    # ---------- 6 總結 ----------
    say()
    say("=" * 64)
    tot = sum(s["待改段數"] for s in suggest)
    say("盤點結論")
    say("   維度 x 層 的組合：%d 組" % len(suggest))
    say("   若照多數決訂標準，要改的段落合計：%d 段次" % tot)
    say("   （同一段可能在好幾個維度都要改，所以是段次不是段數）")
    say("=" * 64)

    return variants, suggest


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py F2_盤點分析.py <資料夾>")
        sys.exit(1)

    folder = sys.argv[1]
    res = main(folder)

    if res:
        variants, suggest = res
        with io.open(os.path.join(folder, "F2_變體清單.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["維度", "層", "寫法", "段數", "占比",
                                              "是否多數", "例子序號", "例子"],
                               quoting=csv.QUOTE_ALL)
            w.writeheader()
            w.writerows(variants)
        with io.open(os.path.join(folder, "F2_建議標準.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["層", "維度", "建議標準",
                                              "符合段數", "待改段數", "符合率"],
                               quoting=csv.QUOTE_ALL)
            w.writeheader()
            w.writerows(suggest)
        say()
        say("已寫出 F2_變體清單.csv（%d 列）、F2_建議標準.csv（%d 列）"
            % (len(variants), len(suggest)))

    report = "\n".join(lines)
    with io.open(os.path.join(folder, "F2_盤點報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if res else 1)
