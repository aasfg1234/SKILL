# -*- coding: utf-8 -*-
r"""
run_all：在同一次執行裡跑完 format-std 的 Python 階段

SPADE 每次執行都是新的暫存目錄，中間檔不跨執行存活。
所以不能一階段一次，必須一口氣跑完。

用法：
    py run_all.py --pass 1 <資料夾>
    py run_all.py --pass 2 <資料夾> --std <標準格式表.csv>

第一趟：F2 -> F3，產出建議標準，然後停下來等人填設定表
第二趟：F2 -> F3 -> F4比對，產出改動清單

第二趟為什麼要從 F2 重跑：因為中間檔沒留下來。全部不到 10 秒。

F1 盤點與 F4 套用是 VBA，在有 Word 的電腦跑，不走這裡。
"""

import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))

# Windows 主控台預設 cp950，遇到罕用字會整支炸掉。強制轉 utf-8。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def find(name):
    """在 skill 樹裡找那一支程式。

    HERE 是 fmt-pipeline/scripts，往上兩層才是放所有 fmt-* 的根。
    """
    root = os.path.dirname(os.path.dirname(HERE))
    for dirpath, _, files in os.walk(root):
        if name in files:
            return os.path.join(dirpath, name)
    return None


def run(name, args):
    p = find(name)
    if not p:
        print("[中止] 找不到 %s" % name)
        return False
    t = time.time()
    r = subprocess.run([sys.executable, p] + args,
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    print(r.stdout or "")
    ok = (r.returncode == 0)
    if not ok and r.stderr:
        print("--- 錯誤訊息 ---")
        print(r.stderr[-1500:])
    print("--- %s 花了 %.1f 秒，%s ---" % (name, time.time() - t,
                                           "過" if ok else "沒過"))
    print()
    return ok


def main(argv):
    if "--pass" not in argv:
        print(__doc__)
        return 1
    i = argv.index("--pass")
    which = argv[i + 1]
    rest = [a for k, a in enumerate(argv) if k not in (i, i + 1)]

    std = None
    if "--std" in rest:
        j = rest.index("--std")
        std = rest[j + 1]
        rest = [a for k, a in enumerate(rest) if k not in (j, j + 1)]

    if not rest:
        print("要給資料夾")
        return 1
    folder = rest[0]

    if not os.path.isfile(os.path.join(folder, "F1_paragraphs.csv")):
        print("[中止] 找不到 %s\\F1_paragraphs.csv" % folder)
        print("       請先在有 Word 的電腦跑 F1_格式盤點.bas，")
        print("       或用 F0D_從純文字建盤點檔.py 產陽春盤點檔（只能測編號與階層）。")
        return 1

    if not run("F2_盤點分析.py", [folder]):
        return 1
    if not run("F3_階層分析.py", [folder]):
        return 1

    if which == "1":
        print("=" * 60)
        print("第一趟跑完了。接下來要人做一件事：")
        print()
        print("  用瀏覽器打開 F3_標準格式設定表.html，訂出每一階的標準格式，")
        print("  匯出 標準格式表.csv。")
        print()
        print("  F2_建議標準.csv 與 F3_建議階層表.csv 可以載進去當參考，")
        print("  但那是「目前主流」不是「應該用哪一種」，最後由人決定。")
        print()
        print("填好之後跑：")
        print("  py run_all.py --pass 2 %s --std <標準格式表.csv>" % folder)
        print("=" * 60)
        return 0

    if not std:
        print("[中止] 第二趟要給 --std <標準格式表.csv>")
        return 1
    if not os.path.isfile(std):
        print("[中止] 找不到 %s" % std)
        return 1

    if not run("F4_比對.py", [folder, std]):
        return 1

    print("=" * 60)
    print("第二趟跑完了。改動清單在 %s\\F4_改動清單.csv" % folder)
    print()
    print("接下來要人做兩件事：")
    print("  一、複核改動清單並簽核")
    print("  二、到有 Word 的電腦匯入 F4_套用.bas，執行 F4_套用標準格式")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
