# diff-cut 正式交付說明

## 唯一正式版本

只有 `releases/LATEST.json` 指向的不可覆寫版本目錄，才是正式發布版本。

工作資料夾中的 `09_規章總表.csv`、`09_impact.csv`、根目錄舊 CSV，及單獨
產生的 S11 規格包，都只是中間產物或歷史檔，不可直接當成最新正式版交付。

## 目前狀態

現有真實資料尚未具備 `S6_複核證明.json`，因此沒有可宣告的正式發布版本。
請先對 `05_flagged.csv` 的每一筆 `需人工看=Y` 資料完成明確決定，重新執行
S6、S7、S8、S9、S10，最後由 S12 建立版本並原子更新 `LATEST.json`。

S12 會檢查 S6 完整複核證明、S10 逐字對帳、三份主表的 ID 與內容一致性、
51 個唯一欄名，以及各輸入輸出的 SHA-256；任一條件不符都不會留下正式版本。

正式版建立後，reg-diff 以發布根目錄接入：

```
python scripts/run_all.py 舊版.docx 新版.docx --outdir 產出 --baseline-release <發布根目錄>
```

reg-diff 會再次驗證 `LATEST.json`、manifest、全部發布檔及舊版原檔 SHA-256，
並用正式版內的 `01_paragraphs.csv` 對齊段次、產生 `規格包連帶複核.csv`。
不可直接把 `規格包/` 資料夾餵給 reg-diff。
