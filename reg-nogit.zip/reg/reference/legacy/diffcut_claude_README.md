# 內規切條產線　Claude版

把一份 Word 內規變成 51 欄的規章總表。

## 怎麼裝

把 `reg-*` 這些資料夾整包放進 `~/.claude/skills/`。
架構 skill 是 `reg-pipeline`，其餘是它會呼叫的階段 skill。

## 怎麼用

跟它說「幫我跑內規切條產線」，或直接指定階段，例如「跑 S3」。

## 全部階段

| 階段 | skill | 誰做 | 性質 |
|---|---|---|---|
| S1 | `reg-s1-export` | VBA，在有 Word 的電腦 | — |
| S1T | `reg-s1t-fromtxt` | 只在拿不到 Word 時 | — |
| S2 | `reg-s2-verify` | Python | 關卡 |
| S3 | `reg-s3-split` | Python | — |
| S4 | `reg-s4-deepen` | Python | — |
| QA | `reg-qa-audit` | Python | 關卡 |
| S5 | `reg-s5-flag` | Python | — |
| S6 | `reg-s6-review` | 人填 Excel ＋ Python | 人工 |
| S7 | `reg-s7-duplicate` | Python | — |
| S8 | `reg-s8-citation` | Python | — |
| S9 | `reg-s9-master` | Python | 發布前中間產物 |
| S10 | `reg-s10-restore` | Python | 關卡 |
| S11 | `reg-s11-specpack` | Python | 規格包中間產物 |
| S12 | `reg-s11-specpack` | Python | 唯一正式發布 |

## 四道關卡

S2 驗收、QA 法遵稽核、S10 還原對帳、S12 發布驗證。**沒過不准往下走。**

## 一個人工步驟

S6 第二步：人填完整複核表。每一筆待複核資料都要明確決定，不能省略；
程式不代填。通過後會產生 `S6_複核證明.json`。

## 唯一正式版本

工作資料夾、S9 CSV、S11 規格包都不是正式發布。S12 會建立不可覆寫的
版本目錄；對外只認發布根目錄的 `LATEST.json` 指向的版本。

## 要維護的兩個表

- `reg-s7-duplicate/scripts/S7_同義詞表.csv`
- `reg-s8-citation/scripts/S8_外部規章表.csv`

換一本規章只要改這兩個，其餘程式不用動。

## 相依

除了 S10 需要 `python-docx`，其餘全部只用 Python 標準函式庫。

```
py -m pip install python-docx
```
