# -*- coding: utf-8 -*-
"""
AI 上網查證結果的快取：同一段文字裡的同一處外部規章引用，查過、而且還在有效期內，就沿用。

每一輪 AI 都要重新上網查「保險法第一百七十七條」這種同一條引用；沒改的規章被拉進流程時，
它的每一處引用又要再查一次。查證結果（判斷、理由、更正、查證網址、類別、日期）存在
<現行規章>/系統快取/AI查證紀錄.json，下一次 review-pack 直接填進 AI外部引用.csv，
「沿用查證」欄寫當初查證的日期，AI 只要查沒填的那幾列。

超過 VALID_DAYS 天一定重查：法規會修。「無法查證」不存（下次再試）。
刪掉這個檔不會出錯，只是下次全部重查。
"""

import datetime
import hashlib
import io
import json
import os

FILE = "AI查證紀錄.json"
VALID_DAYS = 90
CACHE_COLUMN = "沿用查證"
FIELDS = ("AI判斷", "AI理由", "AI更正", "查證來源", "類別")
KEEP_VERDICTS = ("有誤", "沒問題")


def key(citation, paragraph):
    return hashlib.sha256(("%s\n\x00\n%s" % (citation or "", "".join((paragraph or "").split())))
                          .encode("utf-8")).hexdigest()


def _path(folder):
    return os.path.join(folder, FILE)


def load(folder):
    if not folder or not os.path.isfile(_path(folder)):
        return {}
    try:
        with io.open(_path(folder), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def lookup(entries, k, today=None, days=VALID_DAYS):
    """有效期內的那一筆（dict，含「日期」）；沒有或過期回 None。"""
    entry = entries.get(k)
    if not entry:
        return None
    try:
        when = datetime.date.fromisoformat(entry.get("日期") or "")
    except ValueError:
        return None
    today = today or datetime.date.today()
    return entry if (today - when).days <= days else None


def record(folder, rows, today=None):
    """rows：[(鑰匙, AI 那一列)]；只存「有誤」「沒問題」、而且不是沿用來的。回傳存了幾筆。"""
    if not folder:
        return 0
    entries = load(folder)
    stamp = (today or datetime.date.today()).isoformat()
    count = 0
    for k, row in rows:
        verdict = (row.get("AI判斷") or "").strip()
        if verdict not in KEEP_VERDICTS or (row.get(CACHE_COLUMN) or "").strip():
            continue
        entries[k] = dict(((f, (row.get(f) or "").strip()) for f in FIELDS), 日期=stamp)
        count += 1
    if count:
        os.makedirs(folder, exist_ok=True)
        tmp = _path(folder) + ".tmp"
        with io.open(tmp, "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, indent=1)
        os.replace(tmp, _path(folder))
    return count
