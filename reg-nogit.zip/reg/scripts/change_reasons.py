# -*- coding: utf-8 -*-
"""
修正對照表「修改依據／理由」欄的草稿：只寫查得到依據的，其餘寫「請補修正理由」。

程式看得到的只有檔案裡的東西；多數修正真正的原因（為什麼三日要改五日）不在任何一份
檔案裡，不能猜。所以只草擬四種、每一列都附「依據來源」（寫在 xlsx 版最後一欄），
人看得出這一句不是編的：

    一、編號調整、只差字形空白        比對結果本身（終比對的修改類型）
    二、連帶修正                     連帶決定表上填了「改／刪除」的那一列（R 幾、跟著哪一處異動改）
    三、外部規章引用更新             決定表「外部引用」列，附 AI 上網查證的網址
    四、錯字、用詞、標點              AI異動審查 標〔更正筆誤〕〔文字調整〕〔純形式〕的那一處（C 幾）

其他（人自己在草稿裡改的實質內容）一律寫 PLEASE_FILL，送簽前由人補上。人補的不會白補，也不另外做表：

    五、人在上一版修正對照表（xlsx）上補的    同一處（舊文、新文都一樣）重產對照表時照抄回來
    六、人工確認表裡對這一處異動寫的「說明」   那一列結案（已確認）了，就拿來當草稿

人補在 產出/結果彙整/修正對照表/<規章名>_修正對照表.xlsx 的理由，跑 繼續 時會重產對照表，
Word 版跟著有（見 needs_refresh）；重跑開始之後也從上一輪歸檔的那一份讀回來。

對位方式：終比對（舊版 → 乾淨版）的每一列，
    跟決定表的列比：新文等於「改成什麼」（刪除列是舊文等於候選全文）→ 連帶修正
    跟初比對的異動比：舊文、新文都一樣 → 人自己改的那一處
"""

import csv
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
from _common import SYSTEM_DIR, batch_root_of, locate, place, result_home

PLEASE_FILL = "請補修正理由"
SUMMARY_FILE = "修改依據.json"
MECHANICAL_SOURCES = ("章節引用", "跨本引用")
# AI異動審查 的這幾個標籤，理由照寫就好
WORDING_LABELS = {"更正筆誤": "修正誤繕文字", "文字調整": "酌作文字修正", "純形式": "格式調整（編號、標點）"}
# 異動內容尾巴程式加的標記：「（章節換號）」「（A名換號）」「（外部引用〔引用過時〕）」
_TAG_RE = re.compile(r"（[^（）]*(?:換號|外部引用[^（）]*)）$")
_URL_RE = re.compile(r"https?://[^\s；|｜]+")


def _norm(text):
    return dt.normalize(dt.normalize_newlines(text or ""))


def _read_ai_change(folder, changes):
    """AI異動審查.csv 裡每一處異動的〔標籤〕：{異動序（0 起）: 標籤}。指紋對不上（上一輪的）不用。"""
    import review_pack as rp
    import scoring_rubric as sr
    path = locate(folder, "AI異動審查.csv")[0]
    if not os.path.isfile(path):
        return {}
    try:
        with io.open(path, encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
    except (OSError, UnicodeDecodeError, csv.Error):
        return {}
    out = {}
    for row in rows:
        cid = (row.get("異動ID") or "").strip()
        if not cid[1:].isdigit():
            continue
        index = int(cid[1:]) - 1
        if not 0 <= index < len(changes):
            continue
        sha = (row.get(rp.CHANGE_SHA_COLUMN) or "").strip()
        if sha and sha != rp.change_sha256(changes[index]):
            continue
        label = sr.label_in(row.get("AI理由") or "")
        if label:
            out[index] = label
    return out


def _change_label(row):
    """決定表這一列「跟著哪一處改」：「第二點（三日→五日）」「招攬作業要點第三點、第五點」這種寫法。
    異動條文ID 是「規章名：條號」（跨本）或條號（本本），用「；」併列；「段次 N」這種程式代號不寫進正式文件。"""
    pairs = []
    for piece in (row.get("異動條文ID") or "").split("；"):
        book, _, ref = piece.strip().rpartition("：")
        if not ref or ref.startswith(("段次", "舊版段次")) or "換號" in ref:
            continue
        if (book, ref) not in pairs:
            pairs.append((book, ref))
    parts, last = [], None
    for book, ref in pairs[:3]:
        parts.append(ref if book == last else book + ref)
        last = book
    head = "、".join(parts)
    what = _TAG_RE.sub("", (row.get("異動內容") or "").split("；")[0].strip())
    if head and what:
        return "%s（%s）" % (head, what)
    return head or what


def _decision_reason(n, row):
    """(理由, 依據來源)。"""
    sources = [x for x in (row.get("來源") or "").split("；") if x]
    relation = row.get("關係／分數") or ""
    where = "連帶決定表 R%d（來源：%s）" % (n, "、".join(sources) or "-")
    if dt.EXTERNAL_SOURCE in sources:
        what = (row.get("異動內容") or "").split("；")[-1]
        match = re.match(r"^「(.+?)」→「(.+?)」", what)
        urls = _URL_RE.findall(relation)
        reason = ("配合%s，修正引用為「%s」" % ("法規修正" if "過時" in what else "查證結果", match.group(2))
                  if match else "配合外部法規現行條文，修正引用")
        return reason, where + ("；查證：" + "；".join(urls) if urls else "")
    label = _change_label(row)
    if sources and all(s in MECHANICAL_SOURCES for s in sources):
        match = re.match(r"^「(.+?)」→「(.+?)」", _TAG_RE.sub("", (row.get("異動內容") or "").split("；")[0]))
        if match:
            return ("配合編號調整，引用之「%s」修正為「%s」" % match.groups(), where)
        return ("配合編號調整，修正引用之章節、條次或點次", where)
    if row.get("要改嗎") == "刪除":
        return ("配合%s之修正，一併刪除" % (label or "前開規定"), where)
    return ("配合%s之修正，一併修正" % (label or "前開規定"), where)


# ---------------------------------------------------------------------------
# 人補的理由：上一版修正對照表（xlsx）、人工確認的說明
# ---------------------------------------------------------------------------

TABLE = "修正對照表.xlsx"
_ADDED = "（無，此為新增段落）"        # diff_compare.table_rows 寫在空的那一邊的字
_DELETED = "（無，此段落已刪除）"


def _titles():
    """修正對照表上三欄的標題（設定檔 tables/對照表格式.json 可以改名）：(原文, 修改後文字, 修改依據)。"""
    import diff_compare
    titles = dict((c["鍵"], c["標題"]) for c in diff_compare.load_table_format()["欄位"])
    return titles.get("原文", "原條文"), titles.get("修改後文字", "修正後條文"), titles.get("修改依據", "修改依據／理由")


def row_key(old, new):
    """對照表一列是哪一處：(舊文, 新文) 正規化之後。新增／刪除那一邊的佔位字當空的。"""
    old = "" if (old or "").strip() == _ADDED else old
    new = "" if (new or "").strip() == _DELETED else new
    return _norm(old), _norm(new)


def reason_cells(path):
    """一份修正對照表 xlsx 每一列寫的修改依據：{(舊文, 新文): 理由}。沒有檔、讀不出來回 {}。"""
    from _common import read_xlsx_dicts
    if not path or not os.path.isfile(path):
        return {}
    old_title, new_title, reason_title = _titles()
    try:
        rows = read_xlsx_dicts(path)
    except Exception:            # 開在 Excel 裡、存壞了：當成沒有，不能讓終比對跟著失敗
        return {}
    out = {}
    for row in rows:
        if reason_title in row:
            out.setdefault(row_key(row.get(old_title), row.get(new_title)), (row.get(reason_title) or "").strip())
    return out


def tables_of(folder):
    """(人會去改的那一份修正對照表, 程式自己那一份)。批次時人改的是排到 產出/結果彙整/修正對照表/ 的
    「<規章名>_修正對照表.xlsx」，程式那一份在這一本自己的 結果彙整/；單本兩個是同一份。"""
    own = os.path.join(result_home(folder), TABLE)
    root = batch_root_of(folder)
    if not root:
        return own, own
    import result_publish as rpub
    return rpub.published_path(root, os.path.basename(os.path.normpath(folder)), TABLE), own


def _kept(path):
    import result_publish as rpub
    stem, ext = os.path.splitext(path)
    return stem + rpub.KEPT + ext


def previous_reasons(folder):
    """人在上一版修正對照表上寫的修改依據：{(舊文, 新文): (理由, 出處)}。空白、「請補修正理由」不算。
    依序讀：這一輪排上來的那一份（和它的「（手改保留）」）、重跑開始之前歸檔的那一份；
    單本另讀 審閱文件/上一輪_修正對照表.xlsx。"""
    from _common import REVIEW_DIR
    published, _ = tables_of(folder)
    candidates = [(published, "上一版對照表"), (_kept(published), "上一版對照表（手改保留）")]
    root = batch_root_of(folder)
    if root:
        history = os.path.join(root, SYSTEM_DIR, "歷次")
        rel = os.path.relpath(published, root)
        stamps = sorted((s for s in (os.listdir(history) if os.path.isdir(history) else []) if s[:1].isdigit()),
                        reverse=True)
        # 每一格歸檔都看（新的優先）：只看最新那一格的話，連跑兩次開始之後，
        # 人補的理由在更早那一格裡，就讀不到了（B15）
        for stamp in stamps:
            archived = os.path.join(history, stamp, rel)
            if os.path.isfile(archived) or os.path.isfile(_kept(archived)):
                candidates += [(archived, "上一輪對照表（%s）" % stamp),
                               (_kept(archived), "上一輪對照表（%s，手改保留）" % stamp)]
    else:
        candidates.append((os.path.join(folder, REVIEW_DIR, "上一輪_" + TABLE), "上一輪對照表"))
    out = {}
    for path, label in candidates:
        for key, reason in reason_cells(path).items():
            if reason and PLEASE_FILL not in reason and key not in out:
                out[key] = (reason, "%s的修改依據（人補寫或前次草擬，請再看一遍）" % label)
    return out


def confirm_notes(folder, changes):
    """人工確認表裡，人對「這一處異動本身」寫的說明（那一列已經結案）：{異動序（0 起）: (確認ID, 說明)}。"""
    import review_import as ri
    import review_pack as rp
    by_sha = {}
    for row in ri._read_confirmations(locate(folder, ri.CONFIRM_FILE)[0]):
        kind, _, sha = ri._row_key(row).partition(":")
        note = (row.get("說明") or "").strip()
        if kind == "異動" and note and ri.is_closed(row.get(ri.CONFIRM_COLUMN)):
            by_sha[sha] = ((row.get("確認ID") or "").strip(), note)
    out = {}
    for index, change in enumerate(changes):
        hit = by_sha.get(rp.change_sha256(change))
        if hit:
            out[index] = hit
    return out


def pending_in_table(folder):
    """人會去改的那一份修正對照表上，還寫著「請補修正理由」的列數；沒有那一份回 None。"""
    published, _ = tables_of(folder)
    if not os.path.isfile(published):
        return None
    return sum(1 for reason in reason_cells(published).values() if PLEASE_FILL in reason)


def needs_refresh(folder):
    """批次：人在 產出/結果彙整/ 那一份補了理由，程式自己那一份（與 Word 版）還沒有——要重產對照表。"""
    published, own = tables_of(folder)
    if published == own or not (os.path.isfile(published) and os.path.isfile(own)):
        return False
    mine = reason_cells(own)
    for key, reason in reason_cells(published).items():
        if reason and PLEASE_FILL not in reason and mine.get(key) != reason:
            return True
    return False


def carried(edited, fresh):
    """人改過的那一份（edited）只改了修改依據，而且新產的（fresh）都帶上了：不用另存「（手改保留）」。
    別的欄也被改過、或這一輪的列不一樣，一律回 False（手改那一份照舊留著）。"""
    from _common import read_xlsx_rows
    try:
        before, after = read_xlsx_rows(edited), read_xlsx_rows(fresh)
    except Exception:
        return False
    if not before or not after or before[0] != after[0]:
        return False
    header = before[0]
    _, _, reason_title = _titles()
    skip = set(i for i, title in enumerate(header) if title in (reason_title, "依據來源"))

    def body(rows):
        return [tuple(c for i, c in enumerate(list(r) + [""] * (len(header) - len(r))) if i not in skip)
                for r in rows[1:]]
    if body(before) != body(after):
        return False
    now = reason_cells(fresh)
    return all(now.get(key) == reason for key, reason in reason_cells(edited).items()
               if reason and PLEASE_FILL not in reason)


def _row_matches(r, row):
    kind = r.get("type")
    if kind in ("unchanged", "renumbered", "cosmetic"):
        return False
    if row.get("要改嗎").strip() == "刪除":
        return kind == "deleted" and _norm(r.get("old_text")) == _norm(row.get("候選全文"))
    new = _norm(r.get("new_text"))
    return bool(new) and new == _norm(row.get("改成什麼"))


def _assign_rows(results, applied):
    """決定表的每一列只能是一處異動的「連帶修正」，一對一配（B14）。
    以前逐段找「新文等於改成什麼」的第一列：兩段同文時，人自己改的那一段也被當成連帶修正，
    「請補」歸零。現在每一列照它的段次（刪除的列往前推算）配給位置最近、文字相符的那一處，
    配過的就不再給別處。回傳 {id(結果列): (列號, 決定列)}。"""
    deleted_lines = sorted(int(row["候選段次"]) for _, row in applied
                           if row.get("要改嗎").strip() == "刪除" and str(row.get("候選段次") or "").strip().isdigit())
    out = {}
    for n, row in applied:
        line = str(row.get("候選段次") or "").strip()
        target = None
        if line.isdigit():
            target = int(line) - sum(1 for d in deleted_lines if d < int(line))
        best = None
        for r in results:
            if id(r) in out or not _row_matches(r, row):
                continue
            where = r.get("new_index") or r.get("old_index") or 0
            gap = abs(where - target) if target is not None else 0
            if best is None or gap < best[0]:
                best = (gap, r)
        if best is not None:
            out[id(best[1])] = (n, row)
    return out


def draft(results, decision_rows, changes, ai_labels, previous=None, notes=None):
    """在 results（終比對結果）每一筆有異動的列寫上「修改依據」「依據來源」。回傳統計。
    previous：previous_reasons 讀回來的人補理由；notes：confirm_notes 的人工確認說明。
    這兩種只補在程式沒有依據、原本要寫「請補修正理由」的列。"""
    applied = [(n, row) for n, row in enumerate(decision_rows, 1)
               if (row.get("要改嗎") or "").strip() in ("改", "刪除")]
    assigned = _assign_rows(results, applied)
    stats = {"草擬": 0, "請補": 0, "沿用": 0, "人工確認": 0}
    for r in results:
        kind = r.get("type")
        if kind == "unchanged":
            continue
        reasons, where = [], []
        own = None
        if kind == "renumbered":
            reasons.append("配合條次（點次）調整，修正編號")
            where.append("終比對：只有編號不同")
        elif kind == "cosmetic":
            reasons.append("格式調整（全半形、空白）")
            where.append("終比對：只有字形或空白不同")
        else:
            old, new = _norm(r.get("old_text")), _norm(r.get("new_text"))
            hit = assigned.get(id(r))
            own = None
            for i, ch in enumerate(changes):
                ch_old, ch_new = _norm(ch.get("old_text")), _norm(ch.get("new_text"))
                if hit:
                    # 連帶修正的那一段，草稿上本來就被人改過（決定表的候選全文＝人改完的樣子）
                    if ch_new and ch_new == _norm(hit[1].get("候選全文")) and ch_old == old:
                        own = i
                        break
                elif ch_old == old and ch_new == new:
                    own = i
                    break
            if hit:
                reason, source = _decision_reason(*hit)
                reasons.append(reason)
                where.append(source)
            if own is not None:
                label = ai_labels.get(own)
                if label in WORDING_LABELS:
                    reasons.insert(0, WORDING_LABELS[label])
                    where.insert(0, "AI異動審查 C%d〔%s〕" % (own + 1, label))
                else:
                    reasons.insert(0, PLEASE_FILL)
            elif not hit:
                reasons.append(PLEASE_FILL)
        if PLEASE_FILL in reasons:
            prev = (previous or {}).get(row_key(r.get("old_text"), r.get("new_text")))
            note = (notes or {}).get(own) if own is not None else None
            if prev and note and prev[0] == note[1]:
                # 上一版那一句就是從人工確認的說明抄來的：出處照舊寫人工確認，不要變成「上一版對照表」
                reasons, where = [prev[0]], ["人工確認.csv %s 的說明（人寫的，請再看一遍）" % (note[0] or "那一列")] + where
                stats["人工確認"] += 1
            elif prev:
                # 人上一版補的是整格：照抄整格（裡面可能連程式草擬的那一段一起改寫過）
                reasons, where = [prev[0]], [prev[1]] + where
                stats["沿用"] += 1
            elif note:
                reasons[reasons.index(PLEASE_FILL)] = note[1]
                where.insert(0, "人工確認.csv %s 的說明（人寫的，請再看一遍）" % (note[0] or "那一列"))
                stats["人工確認"] += 1
        r["修改依據"] = "；".join(reasons)
        r["依據來源"] = "；".join(where)
        stats["請補" if PLEASE_FILL in reasons else "草擬"] += 1
    return stats


def make_drafter(decisions_path, folder):
    """finalize 用：回傳一支 fn(results)，交給比對在寫修正對照表之前呼叫。
    folder：決定表所在的產出資料夾（初比對那一輪）。讀不到它的異動清單時照樣草擬，
    只是認不出人自己改的那幾處（一律請補）。"""
    decision_rows = dt.read_table(decisions_path)
    changes = []
    path = locate(folder, "異動清單.json")[0]
    if os.path.isfile(path):
        with io.open(path, encoding="utf-8") as f:
            changes = json.load(f)
    labels = _read_ai_change(folder, changes)
    previous = previous_reasons(folder)
    notes = confirm_notes(folder, changes)
    box = {}

    def fn(results):
        box.update(draft(results, decision_rows, changes, labels, previous, notes))
        return box
    fn.stats = box
    return fn


def write_summary(outdir, stats):
    """記下這一輪對照表有幾列要人補理由（人工待辦讀它）。"""
    with io.open(place(outdir, SUMMARY_FILE), "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False)


def read_summary(outdir):
    path = locate(outdir, SUMMARY_FILE)[0]
    if not os.path.isfile(path):
        return None
    with io.open(path, encoding="utf-8") as f:
        return json.load(f)
