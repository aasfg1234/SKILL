# -*- coding: utf-8 -*-
"""
檢視報告：把一個產出資料夾裡散在各格的報告，彙整成一份 結果彙整/檢視報告.xlsx。

最終使用者要的只有三類：標註版全文、修正對照表、檢視報告。前兩類本身就是一份檔
（place() 直接寫進 結果彙整/）；檢視報告則是好幾步各自產生的報告拼起來的——
條文檢查、連帶決定、規格包連帶複核、LLM 審查、套用、終比對驗收、提醒——
原本那幾份照舊留在 審閱文件/ 當稽核紀錄，這裡只讀、不搬、不改。

每一步（compare／apply／review-import／finalize 與批次版本）跑完都呼叫 refresh()，
依資料夾裡「現在有什麼」整份重建：缺的那一段就不出那一張工作表，總覽上寫「尚未產生」。
所以不管跑到第幾步，結果彙整/ 裡的檢視報告都是當下最新、最完整的那一份。
"""

import csv
import datetime
import glob
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import xlsx_writer as xw
from _common import REVIEW_DIR, locate, place, read_xlsx_rows, xlsx_sheet_names

REPORT_NAME = "檢視報告.xlsx"
FINAL_PREFIX = "最終版"
# 從連帶決定表帶進報告的欄（有哪欄帶哪欄，順序照這裡）
DECISION_COLUMNS = ["候選段次", "候選全文", "異動內容", "建議改法", "要改嗎", "改成什麼", "沿用上一輪",
                    "AI判斷", "AI分數", "AI理由", "修改類型", "異動摘要", "異動條文ID", "候選條文ID",
                    "來源", "關係／分數"]


def _existing(outdir, filename, prefix=""):
    path = locate(outdir, filename, prefix)[0]
    return path if os.path.isfile(path) else None


def _prefer_final(outdir, filename):
    """終比對跑過就用定稿對舊版那一份，沒有才用初比對那一份。

    終比對整理完 結果彙整 之後，最終版改回原本的檔名（run_all._settle_result_folder），
    靠「新版定稿_乾淨版.docx 在不在」認出這一份是定稿對舊版；還沒整理的（終比對中途、
    或舊的產出資料夾）照舊找「最終版_」。"""
    final = _existing(outdir, filename, FINAL_PREFIX)
    if final:
        return final, True
    from _common import result_home
    path = _existing(outdir, filename)
    return path, bool(path) and os.path.isfile(os.path.join(result_home(outdir), "新版定稿_乾淨版.docx"))


def _xlsx_sheet(path, sheet=None):
    rows = read_xlsx_rows(path, sheet)
    return (rows[0], rows[1:]) if rows else ([], [])


def _text_lines(path):
    with io.open(path, encoding="utf-8-sig") as f:
        return [line.rstrip("\n") for line in f]


def _decision_rows(outdir, decisions=None):
    """回傳 (欄, 列, 讀不出來的原因)。表不在回 (None, [], "")。

    以前寫死 utf-8-sig：人在 Excel 用「CSV（逗號分隔）」另存（Big5），每一步收尾重建
    檢視報告時就噴 UnicodeDecodeError 的 traceback，那一步明明已經做完了（第三批）。
    改用 _common.open_csv（自動認 UTF-8／Big5）；真的認不出來，檢視報告照出，
    總覽上寫明讀不出來、怎麼修。"""
    from _common import InputError, open_csv
    path = decisions if decisions and os.path.isfile(decisions) else _existing(outdir, "連帶決定表.csv")
    if not path:
        return None, [], ""
    import decision_table as dt
    try:
        with open_csv(path) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
            # 欄序跟決定表本身一樣（dt.DISPLAY_ORDER），人在兩邊看到的是同一個順序
            present = [c for c in (reader.fieldnames or []) if c in DECISION_COLUMNS]
            fields = dt.ordered_fields(present)
    except (InputError, OSError, csv.Error) as exc:
        return None, [], str(exc)
    return fields, rows, ""


def _change_counts(path):
    """修正對照表的實質異動統計：{修改類型: 筆數}。"""
    header, rows = _xlsx_sheet(path)
    if "修改類型" not in header:
        return {}
    col = header.index("修改類型")
    counts = {}
    for row in rows:
        kind = row[col] if col < len(row) else ""
        if kind:
            counts[kind] = counts.get(kind, 0) + 1
    return counts


def _notice_files(outdir):
    folder = os.path.join(outdir, REVIEW_DIR)
    return sorted(glob.glob(os.path.join(folder, "*提醒.txt")))


def build(outdir, decisions=None):
    """組出檢視報告的工作表：[(工作表名, 表頭, 列), ...]。第一張一定是「總覽」。"""
    overview = [["產出資料夾", os.path.abspath(outdir)],
                ["產生時間", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")],
                ["", ""]]
    sheets = []

    from _common import result_home
    unchanged = os.path.isfile(os.path.join(result_home(outdir), "本次未修改.txt"))
    table, final = _prefer_final(outdir, "修正對照表.xlsx")
    if unchanged:
        overview.append(["修正對照表", "本次未修改（新版與舊版內容完全相同，不需要送核）"])
    elif table:
        counts = _change_counts(table)
        overview.append(["修正對照表", "%s（%s）" % (
            "、".join("%s %d" % (k, v) for k, v in sorted(counts.items())) or "無實質異動",
            "定稿對舊版" if final else "草稿對舊版")])
    else:
        overview.append(["修正對照表", "尚未產生"])

    from _common import batch_root_of
    # 路徑寫成相對於產出資料夾（批次時是產出根目錄）。批次時人拿到的是排在
    # 產出/結果彙整/<文件種類>/<規章名>_… 的那一份（見 result_publish），寫那個路徑
    root = batch_root_of(outdir)
    shown_from = root or outdir
    finals = [p for p in (_existing(outdir, n) for n in ("新版定稿_乾淨版.docx", "新版定稿_追蹤修訂.docx")) if p]
    if root:
        import result_publish as rpub
        book = os.path.basename(os.path.abspath(outdir))
        finals = [rpub.published_path(root, book, os.path.basename(p)) for p in finals]
    if unchanged:
        overview.append(["新版定稿", "不需要（本次未修改）"])
    else:
        overview.append(["新版定稿", "、".join(os.path.relpath(p, shown_from).replace(os.sep, "/") for p in finals)
                         if finals else "尚未產生（終比對之後才會放進結果彙整）"])

    check, final = _prefer_final(outdir, "條文檢查報告.xlsx")
    if check:
        header, rows = _xlsx_sheet(check)
        overview.append(["條文檢查", "%d 筆（%s）" % (len(rows), "定稿" if final else "草稿")])
        sheets.append(("條文檢查", header, rows))
    else:
        overview.append(["條文檢查", "尚未產生"])

    fields, rows, unreadable = _decision_rows(outdir, decisions)
    if unreadable:
        print("提醒：檢視報告讀不了連帶決定表（%s），「連帶決定」那一張先不出" % unreadable, flush=True)
        overview.append(["連帶決定", "讀不出來：%s" % unreadable])
    elif fields:
        tally = {}
        import decision_table as dt
        for row in rows:
            written = (row.get("要改嗎") or "").strip()
            key = dt.normalize_action(written)          # 「否」「維持」這類同義字照「不改」算
            key = (written if key is None else key) or "未填"
            tally[key] = tally.get(key, 0) + 1
        overview.append(["連帶決定", "候選 %d 列：%s" % (len(rows), "、".join(
            "%s %d" % (k, tally[k]) for k in ("改", "刪除", "不改", "未填") if tally.get(k)) or "無")])
        sheets.append(("連帶決定", fields, [[row.get(c, "") for c in fields] for row in rows]))
    else:
        overview.append(["連帶決定", "尚未產生"])

    spec = _existing(outdir, "規格包連帶複核.xlsx")
    if spec:
        header, rows = _xlsx_sheet(spec)
        sheets.append(("規格包連帶複核", header, rows))

    llm = _existing(outdir, "LLM審查報告.xlsx")
    if llm:
        overview.append(["LLM 審查", "已匯入（見 LLM-開頭的工作表）"])
        for name in xlsx_sheet_names(llm):
            header, rows = _xlsx_sheet(llm, name)
            sheets.append(("LLM-" + name, header, rows))
    else:
        overview.append(["LLM 審查", "尚未匯入"])

    applied = _existing(outdir, "套用報告.txt")
    if applied:
        lines = _text_lines(applied)
        stats = [re.sub(r"\s+", " ", ln.strip()) for ln in lines if re.match(r"^\s+\S.*\d+ 列$", ln)]
        overview.append(["套用（apply）", "；".join(stats) or "見「套用」工作表"])
        sheets.append(("套用", ["內容"], [[ln] for ln in lines]))
    else:
        overview.append(["套用（apply）", "尚未執行"])

    verdict = _existing(outdir, "終比對驗收報告.txt")
    if verdict:
        lines = _text_lines(verdict)
        overview.append(["終比對驗收", next((ln for ln in lines if ln.startswith("結論：")), "")])
        for ln in lines:
            if re.match(r"^[一二三四]、.*：\d+ 列$", ln):
                overview.append(["", ln])
        sheets.append(("終比對驗收", ["內容"], [[ln] for ln in lines]))
    else:
        overview.append(["終比對驗收", "尚未執行"])

    notice_rows = []
    for path in _notice_files(outdir):
        for ln in _text_lines(path):
            if ln.strip():
                notice_rows.append([os.path.basename(path), ln])
    warnings = sum(1 for _, ln in notice_rows if "警告" in ln)
    overview.append(["提醒", "%d 行（含「警告」%d 行），見「提醒」工作表" % (len(notice_rows), warnings)
                     if notice_rows else "沒有提醒檔"])
    if notice_rows:
        sheets.append(("提醒", ["檔案", "內容"], notice_rows))

    overview += [["", ""],
                 ["說明", "本報告由程式彙整各步驟的報告而成；原始報告留在 審閱文件/ 備查。"
                          "所有產出都是輔助，最終仍需人工複核後才能送出。"]]
    return [("總覽", ["項目", "內容"], overview)] + sheets


def batch_books(root):
    """批次產出根目錄底下有哪幾本：[(規章名, 那一本的產出資料夾)]，照規章清單的順序。"""
    from _common import BATCH_RESERVED, FILL_DIR, SYSTEM_DIR, book_dir
    names = []
    manifest = os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv")
    if os.path.isfile(manifest):
        # 規章清單是人會拿 Excel 開、存的表，Big5 也要讀得動（第三批）；
        # 真的讀不出來就只靠下面的資料夾清單，檢視報告照出
        from _common import InputError, open_csv
        try:
            with open_csv(manifest) as f:
                names = [(r.get("規章名") or "").strip() for r in csv.DictReader(f)]
        except (InputError, OSError, csv.Error) as exc:
            print("提醒：檢視報告讀不了規章清單（%s），改照資料夾列各本" % exc, flush=True)
    # 清單以外、但資料夾還在的本（清單被改過）：各本在 系統檔案/<規章名>/，上一版在根目錄
    for folder in (os.path.join(root, SYSTEM_DIR), root):
        for name in sorted(os.listdir(folder)) if os.path.isdir(folder) else []:
            if name not in names:
                names.append(name)
    import batch as bt
    skip = bt.unaffected_books(root)
    books = []
    for name in names:
        if not name or name in BATCH_RESERVED or name in skip:
            continue
        path = book_dir(root, name)
        if not os.path.isdir(path):
            continue
        if any(os.path.isdir(os.path.join(path, d)) for d in (REVIEW_DIR, FILL_DIR, SYSTEM_DIR)):
            books.append((name, path))
    return books


def build_batch(root, books):
    """多本合成一份檢視報告：每一張工作表最前面多一欄「規章」，標明那一列是哪一本的。

    各本的工作表照 build() 組，同名的表（條文檢查、連帶決定、LLM-候選審查……）上下接起來；
    各本的欄不完全一樣時取聯集，沒有那一欄的格留白。總覽也是一本接一本列。
    """
    overview = [["", "產生時間", datetime.datetime.now().strftime("%Y-%m-%d %H:%M")],
                ["", "產出資料夾", os.path.abspath(root)],
                ["", "規章", "、".join(name for name, _ in books) or "（沒有找到任何一本）"],
                ["", "", ""]]
    merged, order = {}, []
    for name, outdir in books:
        sheets = build(outdir)
        for item, content in sheets[0][2]:
            if item in ("產出資料夾", "產生時間", "說明") or not (item or content):
                continue
            overview.append([name, item, content])
        overview.append(["", "", ""])
        for sheet, header, rows in sheets[1:]:
            if sheet not in merged:
                merged[sheet] = ([], [])
                order.append(sheet)
            columns, collected = merged[sheet]
            for column in header:
                if column != "規章" and column not in columns:
                    columns.append(column)
            for row in rows:
                collected.append((name, dict(zip(header, row))))
    overview.append(["", "說明", "本報告由程式彙整各本、各步驟的報告而成；原始報告留在各本的 審閱文件/ 備查。"
                                 "所有產出都是輔助，最終仍需人工複核後才能送出。"])
    sheets = [("總覽", ["規章", "項目", "內容"], overview)]
    for sheet in order:
        columns, collected = merged[sheet]
        sheets.append((sheet, ["規章"] + columns,
                       [[name] + [values.get(c, "") for c in columns] for name, values in collected]))
    return sheets


def refresh_batch(root):
    """重建 <產出根>/結果彙整/檢視報告.xlsx（多本合一）。沒有任何一本就回 None。"""
    books = batch_books(root)
    if not books:
        return None
    base = os.path.splitext(place(root, REPORT_NAME))[0]
    try:
        written = xw.write_tables_or_csv(base, build_batch(root, books), source="檢視報告")
    except OSError as exc:
        print("提醒：檢視報告寫不出來（%s）；關掉開著的檢視報告.xlsx 後重跑這一步即可" % exc,
              flush=True)
        return None
    if written and written[0].endswith(".xlsx"):
        for stale in glob.glob(base + "_*.csv"):
            try:
                os.remove(stale)
            except OSError:
                pass
    return written[0] if written else None


def refresh(outdir, decisions=None):
    """重建 <outdir>/結果彙整/檢視報告.xlsx。回傳寫出的第一個檔；資料夾裡什麼都還沒有就回 None。

    檢視報告是「附帶」的產物：寫不出來（檔案開在 Excel 裡）只印一行，不讓那一步失敗——
    那一步真正的產出（對照表、定稿、驗收報告）已經寫好了。
    """
    if not os.path.isdir(outdir):
        return None
    from _common import batch_root_of
    root = batch_root_of(outdir)
    if root:
        # 批次裡的一本：不另外出這一本的報告，重建整批合一的那一份
        return refresh_batch(root)
    base = os.path.splitext(place(outdir, REPORT_NAME))[0]
    try:
        written = xw.write_tables_or_csv(base, build(outdir, decisions), source="檢視報告")
    except OSError as exc:
        print("提醒：檢視報告寫不出來（%s）；關掉開著的檢視報告.xlsx 後重跑這一步即可" % exc,
              flush=True)
        return None
    if written and written[0].endswith(".xlsx"):
        # 上一輪 xlsx 寫不出來時留下的 csv 退路要清掉，不然人會打開舊的那幾份
        for stale in glob.glob(base + "_*.csv"):
            try:
                os.remove(stale)
            except OSError:
                pass
    return written[0] if written else None


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    args = sys.argv[1:] if argv is None else argv
    if not args:
        print("用法：py review_report.py <產出資料夾> [連帶決定表.csv]")
        return 1
    path = refresh(args[0], args[1] if len(args) > 1 else None)
    print("檢視報告：%s" % path if path else "沒有可以彙整的報告")
    return 0 if path else 1


if __name__ == "__main__":
    sys.exit(main())
