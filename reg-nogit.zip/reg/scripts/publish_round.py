# -*- coding: utf-8 -*-
"""
發布：簽完之後，把改好的新版定稿換成 匯入/現行規章 裡的那一份，修訂版收走，下一輪從乾淨的 匯入/ 開始。

以前這一步要人自己做：到 產出/結果彙整/新版定稿（乾淨版）/ 找檔、改回原檔名蓋掉現行規章、再清空
修訂規章；漏一步，下一輪「開始」就停下來講「上一輪已經定稿」。

    只發布驗收「改好」的本；還沒改好、本次沒改的照舊不動（講一聲）。
    動之前先把換下來的現行規章、收走的修訂版整份複製到 產出/系統檔案/歷次/發布_<時間>/（要找回來從那裡拿）。
    有規格包的本：新版發布後，舊的規格包對不上新的現行規章，提醒用 cut --inherit 重建。
    發布完寫 產出/系統檔案/已發布.json：人工待辦與「繼續」看到它就講「這一輪已經發布」，不會叫人重跑開始；
    修訂規章再放進新的修訂版，就是新的一輪。
"""

import datetime
import io
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import REVIEW_DIR, SYSTEM_DIR, book_dir, result_home

RECORD = "已發布.json"
LOG = "發布紀錄.txt"
FINAL = "新版定稿_乾淨版.docx"


class PublishError(Exception):
    pass


def _sha(path):
    from fill_sync import _sha_file
    return _sha_file(path)


def record_path(root):
    return os.path.join(root, SYSTEM_DIR, RECORD)


def load_record(root):
    try:
        with io.open(record_path(root), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def plan(root, workspace_root):
    """(要發布的 [dict], 不發布的 [(規章名, 原因)])。清單讀不出來丟 batch.BatchError。"""
    import batch as bt
    import result_publish as rpub
    import todo
    import workspace as wsm
    docs = bt.read_manifest(wsm.paths(workspace_root)["清單"])
    statuses = dict((s["規章"], s) for s in todo.statuses_of(root))
    done = (load_record(root).get("規章") or {})
    ready, skipped = [], []
    for doc in docs:
        name = doc["規章名"]
        status = statuses.get(name)
        if status is None:
            continue                          # 只讀過全文、沒進流程的本：本來就不用換
        target = os.path.splitext(doc["舊版"])[0] + ".docx"
        if name in done and os.path.isfile(target) and _sha(target) == done[name].get("SHA256"):
            skipped.append((name, "已經發布過了"))
            continue
        if status["本次未修改"]:
            skipped.append((name, "本次沒有修改，現行規章不用換"))
            continue
        if status["階段"] != "送簽前":
            skipped.append((name, "還沒改好（走到「%s」）" % status["階段"]))
            continue
        final = rpub.published_path(root, name, FINAL)
        if not os.path.isfile(final):
            final = os.path.join(result_home(book_dir(root, name)), FINAL)
        if not os.path.isfile(final):
            skipped.append((name, "找不到新版定稿（乾淨版）"))
            continue
        ready.append({"規章": name, "定稿": final, "現行": doc["舊版"], "新現行": target,
                      "修訂版": doc["草稿"] if doc["有草稿"] else "", "規格包": doc["發布根目錄"],
                      "請補": status.get("請補") or 0})
    return ready, skipped


def _backup_dir(root, stamp):
    base = os.path.join(root, SYSTEM_DIR, "歷次", "發布_" + stamp)
    candidate, n = base, 1
    while os.path.exists(candidate):
        n += 1
        candidate = "%s_%d" % (base, n)
    return candidate


def _update_manifest(workspace_root, done):
    """發布之後 匯入/規章清單.csv 跟著改：發布的那幾本「新版草稿」清空（修訂版已經收走）、「舊版」指到新的
    現行規章。不改的話清單指著收走的檔，下一個指令一讀清單就中止。"""
    import workspace as wsm
    p = wsm.paths(workspace_root)
    if not os.path.isfile(p["清單"]):
        return
    rows = wsm.read_manifest_rows(p["清單"])
    by_name = dict((item["規章"], item) for item in done)
    for row in rows:
        item = by_name.get(row["規章名"])
        if not item:
            continue
        row["新版草稿"] = ""
        row["舊版"] = os.path.relpath(item["新現行"], p["匯入"]).replace(os.sep, "/")
        row["備註"] = "已發布 %s" % datetime.datetime.now().strftime("%Y-%m-%d")
    wsm.write_manifest(rows, p["清單"])


def execute(root, ready, stamp=None, workspace_root=None):
    """照 plan 換檔。回傳 (備份資料夾, 換好的 list)。換到一半失敗（檔案開在 Word 裡）丟 PublishError，
    已經換好的那幾本照樣記進 已發布.json（再跑一次 發布 會跳過它們）。"""
    # 先全部檢查一遍：有檔開著（Word）就一本都不換（B19）。以前換到一半才失敗——
    # 現行規章已經換成新版、修訂版卻刪不掉，這一本沒記進 已發布.json，再跑說「還沒改好」
    busy = []
    for item in ready:
        for path in (item["現行"], item["新現行"], item.get("修訂版")):
            if path and os.path.isfile(path) and _locked(path):
                busy.append(path)
    if busy:
        raise PublishError("有 %d 個檔開著（可能在 Word 裡），這次一本都沒換：%s。關掉檔案再跑一次 發布"
                           % (len(busy), "、".join(os.path.basename(b) for b in busy)))
    stamp = stamp or datetime.datetime.now().strftime("%Y%m%d_%H%M")
    backup = _backup_dir(root, stamp)
    for sub in ("現行規章", "修訂規章"):
        os.makedirs(os.path.join(backup, sub), exist_ok=True)
    record = load_record(root)
    record.setdefault("規章", {})
    record["時間"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    record["備份"] = os.path.relpath(backup, root)
    done = []
    try:
        for item in ready:
            tmp = item["新現行"] + ".tmp"
            try:
                # 先複製一份到備份，再動原檔：中途出事，舊的現行規章與修訂版都還拿得回來
                shutil.copy2(item["現行"], os.path.join(backup, "現行規章", os.path.basename(item["現行"])))
                if item["修訂版"] and os.path.isfile(item["修訂版"]):
                    shutil.copy2(item["修訂版"], os.path.join(backup, "修訂規章", os.path.basename(item["修訂版"])))
                shutil.copy2(item["定稿"], tmp)
                os.replace(tmp, item["新現行"])
            except OSError as exc:
                if os.path.isfile(tmp):
                    os.remove(tmp)
                raise PublishError("%s 換不了（%s，可能開在 Word 裡）；已發布 %d 本%s，關掉檔案再跑一次 發布"
                                   % (item["規章"], exc, len(done),
                                      "（%s）" % "、".join(d["規章"] for d in done) if done else ""))
            # 現行規章換好了就算發布：後面收舊檔、收修訂版失敗只講一聲，不能讓這一本變成「沒發布」
            leftovers = []
            if os.path.normcase(os.path.abspath(item["現行"])) != os.path.normcase(os.path.abspath(item["新現行"])):
                leftovers.append(item["現行"])           # 舊的是 .txt／.md：新的一份已經是 .docx
            if item["修訂版"] and os.path.isfile(item["修訂版"]):
                leftovers.append(item["修訂版"])
            left = []
            for path in leftovers:
                try:
                    os.remove(path)
                except OSError:
                    left.append(os.path.basename(path))
            record["規章"][item["規章"]] = {"現行規章": item["新現行"], "SHA256": _sha(item["新現行"]),
                                          "時間": record["時間"]}
            if left:
                record["規章"][item["規章"]]["沒收走"] = left
            done.append(item)
    finally:
        if done:
            # 清單開在 Excel 裡改不了：不能讓這個例外蓋掉發布的結果（第三批）。記下來，
            # 下一次 發布／繼續 再補改（retry_manifest）
            if workspace_root:
                try:
                    _update_manifest(workspace_root, done)
                except OSError:
                    record["清單待更新"] = [item["規章"] for item in done]
                    print("[提醒] 匯入/規章清單.csv 開著，沒跟著改：關掉後再跑一次 發布 或 繼續 就會補改", flush=True)
            with io.open(record_path(root), "w", encoding="utf-8") as f:
                json.dump(record, f, ensure_ascii=False, indent=2)
            _log(root, record["時間"], done, backup)
    return backup, done


def retry_manifest(root, workspace_root):
    """上一次發布時清單開著沒改到：現在補改。回傳補改了幾本。"""
    record = load_record(root)
    names = record.get("清單待更新") or []
    if not names or not workspace_root:
        return 0
    done = [{"規章": n, "新現行": (record.get("規章") or {}).get(n, {}).get("現行規章")} for n in names]
    done = [d for d in done if d["新現行"]]
    try:
        _update_manifest(workspace_root, done)
    except OSError:
        return 0
    record.pop("清單待更新", None)
    with io.open(record_path(root), "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
    return len(done)


def _locked(path):
    """這個檔現在換得掉、刪得掉嗎：改個名再改回來試試（Word 開著、別的程式握著都會失敗）。"""
    probe = path + ".發布檢查"
    try:
        os.rename(path, probe)
    except OSError:
        return True
    try:
        os.rename(probe, path)
    except OSError:
        return True
    return False


def _log(root, when, done, backup):
    path = os.path.join(root, REVIEW_DIR, LOG)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    lines = ["%s 發布 %d 本（換下來的舊版與修訂版在 %s）" % (when, len(done), os.path.relpath(backup, root))]
    for item in done:
        lines.append("  %s：%s ← %s" % (item["規章"], item["新現行"], item["定稿"]))
    with io.open(path, "a", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n\n")


def published_state(root, workspace_root=None):
    """這一輪發布過、而且還沒開始下一輪（修訂規章裡沒有新的修訂版）：回傳發布紀錄，否則 None。"""
    record = load_record(root)
    if not record.get("規章"):
        return None
    if workspace_root:
        import workspace as wsm
        if wsm.list_inputs(wsm.paths(workspace_root)["新版"])[0]:
            return None                     # 放了新的修訂版：下一輪
    return record
