# -*- coding: utf-8 -*-
"""純 stdlib 寫 .xlsx（這台電腦沒有 openpyxl，而且我們不裝套件）。
.xlsx 就是一個 zip，裡面幾個 XML。只做報告需要的：多工作表、inline 字串、數字格、
一種字型（微軟正黑體 11）、靠左垂直置中自動換行、標題列粗體、欄寬照內容算。"""
import csv, io, os, re, sys, unicodedata, zipfile
from xml.sax.saxutils import escape

_REGDIFF = os.path.join(os.path.dirname(os.path.abspath(__file__)), "regdiff")
if _REGDIFF not in sys.path:
    sys.path.insert(0, _REGDIFF)
from _common import XML_CLEANUP_NOTICE, sanitize_for_xml
import notices as nt

_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")

# 這一份 .xlsx 清掉了幾個 XML 不合法字元。_CTRL 只清低位控制字元，U+FFFE、
# U+FFFF 與未配對代理字照樣寫進去——.xlsx 打不開，程式卻回報成功、exit 0
# （實測 no 32）。寫完一份發一則提醒，不是每一格一則。
_XML_CLEANED = [0]
_CELL_LIMIT = 32767      # Excel 儲存格上限
_CELL_KEEP = 32000       # 截斷後留的長度，留空間給截斷提示
# 這一張工作表截斷了幾格（_sheet_xml 每張表開頭歸零）。有截斷的表另存一份完整的 csv。
_TRUNCATED = [0]
# 上一次 write_xlsx 因為截斷而另存的完整 csv（正式路徑），write_tables_or_csv 拿去併進回傳清單
_SPILLED = []


def truncate_note(sheet_name, csv_names=None):
    """某一格超過 Excel 上限被截斷時，格子裡留的那句提示（小瑕疵 17）。

    以前這句寫死成「全文見 _候選.csv」——那是「候選審查」那一張表的檔名，
    別張工作表被截斷時會把人指到一個跟它無關的檔案（「總結」表的長格子
    叫人去看 _候選.csv）。改成把**這一張工作表自己**的名字與對應的 csv
    寫進去，指到的才是真的有全文的那一份。

    csv_names：{工作表名: 該張表的 csv 檔名}。不給就用 write_tables_or_csv
    的預設命名（<同名>_<工作表名>.csv）。
    """
    target = (csv_names or {}).get(sheet_name) or ("_%s.csv" % sheet_name)
    return "…（已截斷，工作表「%s」的全文見同資料夾的 %s）" % (sheet_name, target)


def _write_csv(path, header, rows):
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for row in rows:
            writer.writerow(row)

def display_width(text):
    w = 0
    for ch in str(text):
        w += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return w

def column_widths(header, rows, lo=8, hi=80):
    # 欄數不能只看 header：像「總結」那種前面是兩欄統計、後面接一段 5 欄子表的參差列，
    # 資料列可能比 header 長，欄數要照最寬的那一列算，不然多出來的欄完全沒有 <col> 寬度。
    n = max(len(header), max((len(row) for row in rows), default=0))
    best = [0] * n
    for row in [header] + list(rows):
        for i in range(min(n, len(row))):
            for line in str(row[i] if row[i] is not None else "").split("\n"):
                best[i] = max(best[i], display_width(line))
    return [min(hi, max(lo, round(b * 1.1 + 2, 1))) for b in best]

def _col(i):  # 0 → A, 26 → AA
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s

def _cell(ref, value, style, note=""):
    if isinstance(value, bool):
        value = str(value)
    if isinstance(value, int):
        return '<c r="%s" s="%d"><v>%d</v></c>' % (ref, style, value)
    text = "" if value is None else str(value)
    text = text.replace("\r", "")     # \r\n 的候選全文寫進 xlsx 前先去掉 \r，只留 \n 換行
    text = _CTRL.sub("", text)
    text, removed = sanitize_for_xml(text)
    _XML_CLEANED[0] += removed
    if len(text) > _CELL_LIMIT:
        # Excel 一格上限 32,767 字元，超過整份 .xlsx 打不開；全文另外看同名的
        # csv（沒有這個上限，見 truncate_note）。那份 csv 由 write_xlsx 真的寫出來
        # ——以前只有這句提示、沒有那個檔，截掉的字就不見了。
        text = text[:_CELL_KEEP] + note
        _TRUNCATED[0] += 1
    return '<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, style, escape(text))

def _sheet_xml(header, rows, note=""):
    widths = column_widths(header, rows)
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           "<cols>"]
    for i, w in enumerate(widths):
        out.append('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (i + 1, i + 1, w))
    out.append("</cols><sheetData>")
    for r, row in enumerate([header] + list(rows), 1):
        style = 2 if r == 1 else 1
        cells = "".join(_cell("%s%d" % (_col(c), r), v, style, note) for c, v in enumerate(row))
        out.append('<row r="%d">%s</row>' % (r, cells))
    out.append("</sheetData></worksheet>")
    return "".join(out)

def _styles_xml(font_name, font_size):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<fonts count="2"><font><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '<font><b/><sz val="%(s)s"/><name val="%(f)s"/></font></fonts>'
            '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            '<cellXfs count="3">'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
            ) % {"f": escape(str(font_name), {'"': "&quot;"}), "s": font_size}

def write_xlsx(path, sheets, font_name="微軟正黑體", font_size=11, csv_names=None,
               csv_dir=None, path_for=None, source=""):
    """sheets = [(工作表名, header, rows), ...]。csv_names 見 truncate_note。

    有格子超過 Excel 上限被截斷的工作表，另外寫一份完整內容的 csv 放在 csv_dir
    （預設是 path 的資料夾），檔名照 csv_names，沒給就用 <同名>_<工作表名>.csv；
    xlsx 格子裡的截斷提示指的就是這一份。path_for 同 write_tables_or_csv。
    另存了哪幾份記在 _SPILLED（正式路徑）。
    """
    sheets = [(str(name), list(header), list(rows)) for name, header, rows in sheets]
    _XML_CLEANED[0] = 0
    del _SPILLED[:]
    stem = os.path.splitext(os.path.basename(path))[0]
    names = {name: "%s_%s.csv" % (stem, name) for name, _h, _r in sheets}
    names.update({str(k): v for k, v in (csv_names or {}).items() if v})
    truncated = []
    ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
          '<Default Extension="xml" ContentType="application/xml"/>',
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>']
    rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    parts = {}
    used = set()
    for i, (name, header, rows) in enumerate(sheets, 1):
        safe = re.sub(r'[\\/?*\[\]:]', "_", str(name))[:31] or "Sheet%d" % i
        # 工作表名清理後撞名（例如「報告:A」「報告/A」）Excel 會判檔案損壞，補流水號避開
        base, k = safe, 2
        while safe in used:
            suffix = "_%d" % k
            safe = base[:31 - len(suffix)] + suffix
            k += 1
        used.add(safe)
        ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % i)
        wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (escape(safe, {'"': "&quot;"}), i, i))
        rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i, i))
        # 截斷提示用**原始**工作表名（清理／補流水號之前的那個）：人是照程式印出來的
        # 名字去找對應的 csv，不是照 Excel 顯示的那個被清理過的名字。
        _TRUNCATED[0] = 0
        parts["xl/worksheets/sheet%d.xml" % i] = _sheet_xml(
            list(header), list(rows), truncate_note(str(name), names))
        if _TRUNCATED[0]:
            truncated.append((name, header, rows, _TRUNCATED[0]))
    n = len(sheets)
    rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % (n + 1))
    ct.append("</Types>"); wb.append("</sheets></workbook>")
    parts["[Content_Types].xml"] = "".join(ct)
    parts["_rels/.rels"] = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    parts["xl/workbook.xml"] = "".join(wb)
    parts["xl/_rels/workbook.xml.rels"] = "".join(rels)
    parts["xl/styles.xml"] = _styles_xml(font_name, font_size)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name in ("[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/styles.xml"):
            z.writestr(name, parts[name].encode("utf-8"))
        for name in sorted(k for k in parts if k.startswith("xl/worksheets/")):
            z.writestr(name, parts[name].encode("utf-8"))
    if _XML_CLEANED[0]:
        nt.notice(nt.REMINDER, XML_CLEANUP_NOTICE % _XML_CLEANED[0], "審查包 xlsx")
    _XML_CLEANED[0] = 0
    folder = csv_dir or os.path.dirname(os.path.abspath(path))
    for name, header, rows, count in truncated:
        final = os.path.join(folder, names[name])
        _write_csv((path_for or (lambda p: p))(final), header, rows)
        _SPILLED.append(final)
        nt.notice(nt.REMINDER,
                  "工作表「%s」有 %d 格超過 Excel 一格 %d 字的上限，xlsx 裡已截斷；"
                  "完整內容另存在同資料夾的 %s" % (name, count, _CELL_LIMIT, names[name]),
                  source or "產出表格")
    return path


def csv_names_for(base_path, sheets):
    """每張工作表退成 csv 時要叫什麼檔名（只有檔名，不含資料夾）。

    一張表就 <同名>.csv，多張表就 <同名>_<工作表名>.csv——多張表擠成同一個
    檔名會互相蓋掉，而「候選明細」那三張表正是要分開看的三件事。
    """
    base = os.path.basename(base_path)
    names = [str(name) for name, _h, _r in sheets]
    if len(names) == 1:
        return {names[0]: base + ".csv"}
    return {name: "%s_%s.csv" % (base, name) for name in names}


def write_tables_or_csv(base_path, sheets, source="", path_for=None, csv_names=None):
    """給人看的表只出一種格式：先試 .xlsx，寫不出來才退 .csv。回傳實際寫出的路徑清單。

    base_path 不帶副檔名（例如 …/結果彙整/修正對照表），副檔名由這裡補。

    為什麼要有退路：xlsx 是一個 zip，寫不出來的成因是環境問題（磁碟滿了、
    檔案正在 Excel 裡開著被鎖住、路徑太長），跟資料本身沒關係。那時候整張表
    直接消失是最糟的結果——人手上什麼都沒有，卻只在畫面上看到一行錯誤。
    csv 沒有格式、沒有欄寬，但至少每一列每一欄都在。

    path_for：走 AtomicWrites 時傳 aw.path，實際寫進去的是 .tmp，回傳的仍是
    正式路徑（呼叫端的 produced 清單要的是人看得到的那一個）。

    csv_names：{工作表名: csv 檔名}，覆寫預設命名。呼叫端本來就有一套命名時
    （review_import 的 _候選.csv／_異動.csv）傳這個，退路檔名與截斷提示才對得上。
    """
    path_for = path_for or (lambda path: path)
    sheets = [(str(name), list(header), list(rows)) for name, header, rows in sheets]
    folder = os.path.dirname(base_path)
    names = csv_names_for(base_path, sheets)
    names.update({str(k): v for k, v in (csv_names or {}).items() if k in names})
    csv_names = names
    xlsx_final = base_path + ".xlsx"
    target = path_for(xlsx_final)
    try:
        write_xlsx(target, sheets, csv_names=csv_names, csv_dir=folder,
                   path_for=path_for, source=source)
    except (OSError, ValueError) as exc:
        # 半份 zip 一定要清掉：走 AtomicWrites 時那個 .tmp 會在收尾被當成
        # 「這一次的產物」搬到正式檔名上，變成一個打不開的 .xlsx。
        # 上一輪留下來的正式 .xlsx 也要清掉（target 走 AtomicWrites 時是 .tmp，
        # 跟 xlsx_final 不同）：這一輪的內容只在 csv 裡，留著一份舊的 .xlsx
        # 會讓人打開上一輪的報告，還以為那就是這次的結果。
        for stale in (target, xlsx_final):
            try:
                if os.path.exists(stale):
                    os.remove(stale)
            except OSError:
                pass
        nt.notice(nt.REMINDER, "xlsx 寫不出來（%s），已改出 csv" % exc,
                  source or "產出表格")
        written = []
        for name, header, rows in sheets:
            final = os.path.join(folder, csv_names[name])
            _write_csv(path_for(final), header, rows)
            written.append(final)
        return written
    # 有格子被截斷的工作表另存了完整的 csv：也是這一次真的寫出來的檔，一起回報
    return [xlsx_final] + list(_SPILLED)
