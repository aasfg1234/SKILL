# -*- coding: utf-8 -*-
"""
多本批次與跨本連帶：清單讀取、跨本候選、引用連帶、批次摘要。

跨本候選只列不判：A 本改了某條，到 B 本草稿找整條相似、關鍵詞命中；
B 本有規格包時，再看 B 的引用表有沒有引用到 A 本被改的那條。
每一筆都帶兩條全文與分數，理由由 AI 在第 2 步寫，人決定。
"""

import csv
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import fuzzy_duplicate_finder as fuzzy
import notices as nt
from _common import (book_dir, build_hierarchy, diff_runs, extract_article_no, format_scope, locate,
                     normalize_terms)

MANIFEST_COLUMNS = ["規章名", "舊版", "新版草稿", "發布根目錄"]


class BatchError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 規章清單
# ---------------------------------------------------------------------------

def folder_key(name):
    """規章名落到磁碟上是哪一個資料夾：<產出>/<規章名>/ 撞不撞，要用這把尺比。

    Windows（和 macOS 預設的檔案系統）資料夾名不分大小寫，Windows 還會把名稱結尾的
    「.」和空白吃掉。只比原字串的話「規章A」「規章a」會被當成兩本，實際寫進同一個
    資料夾。這裡一律照最嚴的那一種比（不管現在跑在哪個平台）：同一份清單拿到
    Windows 上跑也不會撞。比嚴了頂多是請人改個名，比鬆了是整本產出被蓋掉。
    """
    import unicodedata
    return unicodedata.normalize("NFC", name).rstrip(". ").casefold()


def read_manifest(path):
    """讀規章清單.csv；相對路徑以清單所在資料夾為準。任何一列不合法就整支停。"""
    if not os.path.isfile(path):
        raise BatchError("找不到規章清單：%s" % path)
    base = os.path.dirname(os.path.abspath(path))
    from _common import open_csv
    with open_csv(path) as f:        # 人會用 Excel 改清單，另存可能是 Big5
        reader = csv.DictReader(f)
        missing = [c for c in MANIFEST_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise BatchError("規章清單缺欄位：%s" % "、".join(missing))
        rows = list(reader)

    def resolve(value):
        value = (value or "").strip()
        if not value:
            return ""
        return os.path.normpath(value if os.path.isabs(value) else os.path.join(base, value))

    docs = []
    seen = {}          # folder_key(規章名) -> (第一次用到它的列號, 那一列寫的規章名)
    seen_old = {}      # normcase(絕對路徑) -> 第一次用到它的列號，見 item8
    seen_draft = {}
    for index, row in enumerate(rows, 2):
        name = (row.get("規章名") or "").strip()
        if not name:
            raise BatchError("第 %d 列規章名空白" % index)
        if name in (".", "..") or os.path.basename(name) != name:
            raise BatchError("第 %d 列規章名不能含路徑字元：%s" % (index, name))
        key = folder_key(name)
        from _common import BATCH_RESERVED
        if key in set(folder_key(r) for r in BATCH_RESERVED):
            # 各本的過程檔放在 產出/系統檔案/<規章名>/，送簽文件排在 產出/結果彙整/<種類>/<規章名>_…；
            # 規章名跟那幾個固定資料夾同名會撞在一起
            raise BatchError("第 %d 列規章名不能叫「%s」（跟產出資料夾裡的固定資料夾同名），請改名"
                             % (index, name))
        if key in seen:
            # no 15：這則訊息現在也會出現在「配對」階段（cmd_pair 寫完清單就跑同一套
            # 驗證），跟其他每一則一樣要講是哪一列，人才知道要去改清單的哪一行。
            first_index, first_name = seen[key]
            if first_name == name:
                raise BatchError("第 %d 列規章名重複：%s（與第 %d 列相同）"
                                 % (index, name, first_index))
            # 字面不同、資料夾卻是同一個：「規章A」「規章a」在 Windows 上會寫進同一個
            # <產出>/<規章名>/，後跑的那本整本蓋掉前一本，batch 照樣 exit 0。
            raise BatchError("第 %d 列規章名「%s」與第 %d 列「%s」只差大小寫或結尾的點／空白，"
                             "產出會寫進同一個資料夾、後一本蓋掉前一本；請把其中一本改名"
                             % (index, name, first_index, first_name))
        seen[key] = (index, name)
        old_raw = (row.get("舊版") or "").strip()
        if not old_raw:
            # 工作區「配對」寫出的清單，舊版空白代表這本還沒配對成功（未配對／
            # 多個候選都是舊版留空）——跟「填了路徑但檔案不見了」是兩回事，訊息
            # 分開講，才不會誤導使用者去找一個根本沒填過的檔案。
            # item7：多個候選時，「配對」已經把候選寫進「備註」欄
            # （merge_manual／match，例如「多個候選：甲、乙」）——原樣附進錯誤
            # 訊息，人不用另外開清單就知道要在哪幾個裡面選。
            note = (row.get("備註") or "").strip()
            suffix = "（備註：%s）" % note if note else ""
            raise BatchError("第 %d 列（%s）未配對，請先處理%s" % (index, name, suffix))
        old = resolve(old_raw)
        if not os.path.isfile(old):
            raise BatchError("第 %d 列（%s）舊版檔不存在：%s" % (index, name, old))
        # item8：兩列指到同一份舊版／新版草稿檔，套用時後面那本會把前一本的異動
        # 誤判成自己的（同一份 .docx 被兩本各自複製、各自開追蹤修訂，內容卻是同
        # 一份），不能放行——normcase 是為了 Windows 大小寫不敏感的路徑也抓得到。
        old_key = os.path.normcase(os.path.abspath(old))
        if old_key in seen_old:
            raise BatchError("第 %d 列（%s）舊版重複使用：%s（與第 %d 列相同）"
                             % (index, name, old, seen_old[old_key]))
        seen_old[old_key] = index
        draft = resolve(row.get("新版草稿"))
        if draft and not os.path.isfile(draft):
            raise BatchError("第 %d 列（%s）新版草稿不存在：%s" % (index, name, draft))
        if draft:
            draft_key = os.path.normcase(os.path.abspath(draft))
            if draft_key in seen_draft:
                raise BatchError("第 %d 列（%s）新版草稿重複使用：%s（與第 %d 列相同）"
                                 % (index, name, draft, seen_draft[draft_key]))
            seen_draft[draft_key] = index
        release = resolve(row.get("發布根目錄"))
        if release and not os.path.isfile(os.path.join(release, "LATEST.json")):
            raise BatchError("第 %d 列（%s）發布根目錄缺 LATEST.json：%s" % (index, name, release))
        docs.append({"規章名": name, "舊版": old, "草稿": draft or old,
                     "有草稿": bool(draft), "發布根目錄": release})
    if not docs:
        raise BatchError("規章清單沒有任何規章")
    return docs


# 一本要能進 batch-review-pack／batch-review-import，這三個檔案缺一不可
# （相對 <outdir>/<規章名>/ 的路徑，顯示用的標籤是給人看的）：
# 連帶決定表.csv（填寫表單/）、異動清單.json（系統檔案/）是 compare 產出；
# 系統檔案/輸入/輸入指紋.json 是 stage_inputs 產出的指紋檔，rp.load_book 用它核對
# 草稿沒被換掉。三個只要缺一個，rp.load_book 就會在 write_pack／import_review
# 半路才炸，不如在 list_books 這一關先篩掉。
# 每一項是 (檔名, 顯示標籤, 資料夾底下的檔名)；實際路徑一律由 _common.locate 算
# （新排法優先，找不到再看舊排法的平鋪），指紋檔另外接在「輸入」資料夾底下。
_REQUIRED_BOOK_FILES = [
    ("連帶決定表.csv", "連帶決定表.csv", ""),
    ("異動清單.json", "異動清單.json", ""),
    ("輸入", "輸入/輸入指紋.json", "輸入指紋.json"),
]


def _book_file(outdir_doc, name, tail=""):
    """一本產出裡某個檔的實際路徑（新排法優先，找不到退舊平鋪）。

    tail 是接在資料夾底下的檔名（輸入/輸入指紋.json、輸入/規章清單.csv）。
    這種要多退一手：locate 看的是「輸入 這個資料夾」在不在，資料夾在、裡面那個檔
    卻不在的時候（半搬過的資料夾），還是要回頭找舊排法的 <outdir>/輸入/<tail>，
    不然會拿著一個不存在的新路徑去報「找不到規章清單」。
    """
    path = locate(outdir_doc, name)[0]
    if not tail:
        return path
    full = os.path.join(path, tail)
    if os.path.exists(full):
        return full
    legacy = os.path.join(outdir_doc, name, tail)
    return legacy if os.path.exists(legacy) else full


# 沒放修訂版、別本的改動也沒影響到的規章：只讀過全文當「被查對象」，沒有產出資料夾，
# 後面每一個批次指令都不處理它們（見 run_all.cmd_batch）。記規章名與它的舊版路徑：
# batch-semantic 在別台算出它有語意候選時，要靠這份把它拉進流程（不必再讀工作區的清單）。
UNAFFECTED_FILE = "未受影響規章.json"


def unaffected_path(root):
    from _common import SYSTEM_DIR
    return os.path.join(root, SYSTEM_DIR, "輸入", UNAFFECTED_FILE)


def unaffected_docs(root):
    """這一輪沒進流程的規章：{規章名: read_manifest 那種 doc}。沒有這個檔（舊的產出資料夾、單本）回 {}。"""
    import json
    path = unaffected_path(root or "")
    if not root or not os.path.isfile(path):
        return {}
    try:
        with io.open(path, encoding="utf-8") as f:
            return dict((doc["規章名"], doc) for doc in json.load(f))
    except (OSError, ValueError, KeyError, TypeError):
        return {}


def unaffected_books(root):
    """這一輪沒進流程的規章名（set）。"""
    return set(unaffected_docs(root))


def write_unaffected(root, docs):
    """docs：read_manifest 那種 doc 的 list（路徑寫絕對路徑）。"""
    import json
    path = unaffected_path(root)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump([dict(doc, 舊版=os.path.abspath(doc["舊版"]), 草稿=os.path.abspath(doc["草稿"]))
                   for doc in docs], f, ensure_ascii=False, indent=1)


# 快取（語意向量、AI 查證結果）放在現行規章那個資料夾底下的 系統快取/：跨很多輪一直累積，
# 「開始」歸檔上一輪不會搬走它。批次產出記一個指標，後面的指令（review-pack／import、
# 手動語意指令）照它找。清單裡的舊版不在同一個資料夾（自己寫的清單）就不用快取。
CACHE_POINTER = "快取位置.txt"
CACHE_DIR = "系統快取"


def cache_dir_for_docs(docs):
    folders = set(os.path.dirname(os.path.abspath(doc["舊版"])) for doc in docs)
    return os.path.join(folders.pop(), CACHE_DIR) if len(folders) == 1 else ""


def write_cache_pointer(root, folder):
    """記成相對產出根目錄的路徑（../匯入/現行規章/系統快取）：整個工作區複製到別台電腦
    （有語意模型的那台）時照樣找得到；不在同一個磁碟才記絕對路徑。"""
    from _common import SYSTEM_DIR
    path = os.path.join(root, SYSTEM_DIR, "輸入", CACHE_POINTER)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    value = folder or ""
    if value:
        try:
            value = os.path.relpath(value, os.path.abspath(root))
        except ValueError:
            pass
    with io.open(path, "w", encoding="utf-8") as f:
        f.write(value)


def cache_dir(outdir):
    """批次產出（根或其中一本）用的快取資料夾；沒有回 ""。"""
    from _common import SYSTEM_DIR, batch_root_of
    for root in (batch_root_of(outdir) if outdir else "", outdir):
        if not root:
            continue
        path = os.path.join(root, SYSTEM_DIR, "輸入", CACHE_POINTER)
        if os.path.isfile(path):
            with io.open(path, encoding="utf-8") as f:
                value = f.read().strip()
            if value and not os.path.isabs(value):
                value = os.path.normpath(os.path.join(os.path.abspath(root), value))
            return value
    return ""


def active_docs(docs, root):
    """read_manifest 的結果拿掉這一輪沒進流程的規章（batch-apply／batch-finalize 用）。"""
    skip = unaffected_books(root)
    return [doc for doc in docs if doc["規章名"] not in skip]


def list_books(outdir):
    """給 batch-review-pack／batch-review-import 用：讀 <outdir>/系統檔案/輸入/規章清單.csv
    （batch 已經把使用者原始清單複製進來，見 run_all.stage_inputs；舊排法的產出資料夾
    退回 <outdir>/輸入/規章清單.csv）取規章名順序，回傳 [(規章名, <outdir>/<規章名>), ...]。

    清單裡「舊版」「新版草稿」「發布根目錄」欄記的是複製前、原始清單所在資料夾的相對
    路徑，搬到留底資料夾之後大多已經找不到那些檔案——但這裡只需要規章名順序，
    所以不用 read_manifest（找不到檔案就整支停），改用 csv.DictReader 只讀規章名欄。

    產出不完整的本（缺 _REQUIRED_BOOK_FILES 任何一個——那一本當初 batch 就失敗、
    還沒跑過 batch，或是被手動刪掉了某個檔案）跳過並印出缺了什麼；一本都不剩就
    raise BatchError。"""
    path = _book_file(outdir, "輸入", "規章清單.csv")
    if not os.path.isfile(path):
        raise BatchError("找不到規章清單：%s（請先跑 batch）" % path)
    from _common import open_csv
    with open_csv(path) as f:
        reader = csv.DictReader(f)
        if "規章名" not in (reader.fieldnames or []):
            raise BatchError("規章清單缺欄位：規章名")
        rows = list(reader)

    books = []
    skip = unaffected_books(outdir)
    for row in rows:
        name = (row.get("規章名") or "").strip()
        if not name or name in skip:
            continue
        outdir_doc = book_dir(outdir, name)
        missing = [label for name_, label, tail in _REQUIRED_BOOK_FILES
                   if not os.path.isfile(_book_file(outdir_doc, name_, tail))]
        if missing:
            print("略過 %s：產出不完整（缺 %s）" % (name, "、".join(missing)))
            continue
        books.append((name, outdir_doc))
    if not books:
        raise BatchError("規章清單裡沒有任何一本有完整產出（請先跑 batch）")
    return books


# ---------------------------------------------------------------------------
# 條號正規化：中文數字轉半形數字，讓「第三十四條」對得上「第34條」
# ---------------------------------------------------------------------------

_CN_DIGIT = {"零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "三": 3, "四": 4,
             "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
_CN_UNIT = {"十": 10, "百": 100, "千": 1000}
_CN_RUN = re.compile("[%s%s]+" % ("".join(_CN_DIGIT), "".join(_CN_UNIT)))


def cn_to_int(text):
    total = 0
    number = 0
    for ch in text:
        if ch in _CN_DIGIT:
            number = _CN_DIGIT[ch]
        elif ch in _CN_UNIT:
            total += (number if number else 1) * _CN_UNIT[ch]
            number = 0
    return total + number


def normalize_article_no(text):
    text = re.sub(r"\s+", "", text or "")
    text = text.replace("（", "(").replace("）", ")")
    return _CN_RUN.sub(lambda m: str(cn_to_int(m.group(0))), text)


# ---------------------------------------------------------------------------
# 跨本候選：相似 + 關鍵詞
# ---------------------------------------------------------------------------

def _label(source_name, change):
    """沒有規格包 ID 也沒有條號時退回段次，標籤才不會只剩「A名：」。"""
    tag = change.get("條文ID") or change.get("ref") or ("段次 %s" % change.get("段次", ""))
    return "%s：%s" % (source_name, tag)


def _row(source, label, summary, cand_id, line, text, relation, evidence=""):
    return {"來源": source, "異動條文ID": label, "異動摘要": summary, "候選條文ID": cand_id or "",
            "候選段次": str(line) if line else "", "候選全文": text or "",
            "關係／分數": relation, "經同義詞比對": evidence}


def cross_candidates(source_name, source_changes, target_paragraphs, synonyms,
                     threshold, top, changed_top, sentence_threshold=fuzzy.DEFAULT_SENTENCE_THRESHOLD,
                     target_kinds=None):
    """拿 A 本每個異動到 B 本草稿找整條相似與關鍵詞命中。B 本沒有「自己那段」要排除，
    所以 exclude_index 用 0（不會等於任何段次，也關掉「文字完全相同就跳過」）。

    target_kinds 是 B 本每一段的來源種類（"p"／"cell"），跟 compare 用同一份層級脈絡，
    候選的條號才不會跟 B 本自己的修正對照表對不起來。"""
    contexts = build_hierarchy(target_paragraphs, target_kinds)
    out = []

    def tag(row, index, kind, score):
        # 給 select_cross 用的內部欄（不寫進決定表）：哪一處異動、哪一種找法、分數
        row[CROSS_CHANGE_KEY] = (source_name, index)
        row[CROSS_KIND_KEY] = kind
        row[CROSS_SCORE_KEY] = float(score)
        return row

    for index, change in enumerate(source_changes):
        label = _label(source_name, change)
        summary = dt._summary(change["new_text"])
        for c in fuzzy.find_duplicates(change["new_text"], target_paragraphs, threshold=threshold,
                                       top=top, exclude_index=0, contexts=contexts,
                                       synonyms=synonyms, changed_old_text=change.get("old_text")):
            relation = "跨本相似 %s 分" % c["similarity"]
            if c.get("fragment_position"):
                relation += "、%s" % c["fragment_position"]
            out.append(tag(_row("跨本", label, summary, "", c["line_number"], c["text"], relation,
                                "、".join(c.get("synonym_evidence") or [])), index, "相似", c["similarity"]))
        fragments = fuzzy.changed_fragments(change.get("old_text") or "", change["new_text"], diff_runs)
        if fragments:
            for h in fuzzy.find_by_changed_text(fragments, target_paragraphs, exclude_index=0,
                                                contexts=contexts, synonyms=synonyms,
                                                normalize=normalize_terms,
                                                extract_article_no=extract_article_no,
                                                format_scope=format_scope, top=changed_top):
                terms = "、".join(t for _, t in h["matched"])
                out.append(tag(_row("跨本", label, summary, "", h["line_number"], h["text"],
                                    "跨本命中「%s」" % terms), index, "命中", h["strength"]))
        else:
            # 一字之差沒有片段可搜，改用改動處左右文脈；whole_only=True 只用整段文脈
            # 當詞，不拆前後綴子詞——文脈本身只有 4 個字，拆出來的 2 字子詞辨識力低。
            context_terms = fuzzy.context_fragments(change.get("old_text") or "", change["new_text"], diff_runs)
            for h in fuzzy.find_by_changed_text(context_terms, target_paragraphs, exclude_index=0,
                                                contexts=contexts, synonyms=synonyms,
                                                normalize=normalize_terms,
                                                extract_article_no=extract_article_no,
                                                format_scope=format_scope, top=changed_top,
                                                whole_only=True):
                terms = "、".join(t for _, t in h["matched"])
                out.append(tag(_row("跨本（文脈）", label, summary, "", h["line_number"], h["text"],
                                    "跨本文脈「%s」" % terms), index, "文脈", h["strength"]))

        if sentence_threshold and sentence_threshold > 0:
            # 目前 cmd_batch 只把 type in ("added","modified") 且 new_text 非空的項目
            # 放進 source_changes，刪除段落不會走到這裡；這裡仍防禦式地把
            # 「deleted 旗標」與「new_text 空/缺」兩種可能表示法都當成「沒有新文」，
            # 跟 run_all.step_duplicates 的處理一致，避免日後放寬篩選時又比出空結果。
            cross_new_text = "" if change.get("deleted") or not change.get("new_text") else change["new_text"]
            sentences = fuzzy.changed_sentences(change.get("old_text") or "", cross_new_text, diff_runs)
            for h in fuzzy.find_by_sentence(sentences, target_paragraphs, threshold=sentence_threshold,
                                            top=top, exclude_index=0, contexts=contexts, synonyms=synonyms):
                out.append(tag(_row("跨本（句）", label, dt._summary(h["changed_sentence"]), "", h["line_number"],
                                    h["text"], "跨本句 %s 分：%s" % (h["sentence_score"],
                                                                  dt._summary(h["matched_sentence"], 30)),
                                    "、".join(h.get("synonym_evidence") or [])), index, "句", h["sentence_score"]))
    return out


# ---------------------------------------------------------------------------
# 跨本候選分層＋全域上限
# ---------------------------------------------------------------------------
# 以前是「每一處異動，在每一本各取前幾名」：規章越多，決定表越長（實測 300 本×3 本有改，
# 模擬資料 3 萬 2 千列），「陳報主管」這種套語會把幾乎每一本都拉進流程，人與 AI 都看不完。
# 改成照證據強弱分層：
#   一定列  明確引用（跨本引用、規格包引用：沒有下面這幾個內部欄的列）
#   一定列  舊值原樣還在（這一處的改法套得上候選段：建議改法寫得出來），而且是相似或同句找到的
#   限量列  其他只是相似的：每一處異動、每一種找法（相似／句／命中／文脈），全部規章加起來只留
#           分數最高的 CROSS_TOP 段，其餘講一聲「另有 N 段相似度較低，未列」
# 列數因此由「改了幾處」決定，不再由「放了幾本規章」決定。
CROSS_TOP = 10
# 「舊值原樣還在」那一層的上限（每一處異動、全部規章合計）。以前這層一律列：舊字是常見字
# （「七日」）時，一處修改就列出幾百列（實測 20 本 296 列）。設定.json「跨本舊值上限」可改，0＝不限
CROSS_STRONG_TOP = 30
CROSS_CHANGE_KEY = "_跨本異動"
CROSS_KIND_KEY = "_跨本找法"
CROSS_SCORE_KEY = "_跨本分數"
_STRONG_KINDS = ("相似", "句")


def old_value_present(candidate, old, new):
    """這一處異動改掉的舊字（前後各帶一個字，「於三日內」這種），候選段裡原樣都還在。
    只加字、沒改掉任何舊字的異動不算（沒有「舊值」可言）。"""
    import row_assist as ra
    text, old = candidate or "", old or ""
    hunks = [h for h in ra._hunks(old, new or "") if h[0]]
    if not hunks:
        return False
    for old_seg, _, i1, i2 in hunks:
        probe = old[max(0, i1 - 1):i1] + old_seg + old[i2:i2 + 1]
        if len(probe) < 2 or probe not in text:
            return False
    return True


def select_cross(found, source_changes, cap=CROSS_TOP, unlisted=None, strong_cap=CROSS_STRONG_TOP):
    """found：{被查的本: [cross_candidates／citation 的列]}；source_changes：{來源本: [異動]}。
    回傳 ({被查的本: 留下的列}, {(來源本, 異動序): 沒列的候選段數})。cap<=0 不設上限。
    unlisted（dict，選填）：填進 {被查的本: [{候選段次, 候選全文SHA256}]}——因為上限沒列出來的段。
    驗收時要拿它排除：那些段人本來就不用看，不能到驗收才冒出來變成「新候選」擋住改好。"""
    if not cap or cap <= 0:
        return found, {}
    keep = set()           # (被查的本, 段次, 異動)
    ranked = {}            # (異動, 找法) → [(分數, 被查的本, 段次)]
    strong = {}            # 異動 → {(被查的本, 段次): 分數}（舊值原樣還在的）
    checked = {}
    candidates = set()
    texts = {}
    for target, rows in found.items():
        for row in rows:
            key = row.get(CROSS_CHANGE_KEY)
            if key is None:
                continue                          # 明確引用：一定列（下面不過濾）
            line = row.get("候選段次")
            cand = (target, line, key)
            candidates.add(cand)
            texts[cand] = row.get("候選全文") or ""
            kind = row.get(CROSS_KIND_KEY)
            score = row.get(CROSS_SCORE_KEY) or 0.0
            if kind in _STRONG_KINDS:
                if cand not in checked:
                    change = source_changes[key[0]][key[1]]
                    checked[cand] = old_value_present(row.get("候選全文"), change.get("old_text"),
                                                      change.get("new_text"))
                if checked[cand]:
                    bucket = strong.setdefault(key, {})
                    bucket[(target, line)] = max(bucket.get((target, line), -1.0), score)
            ranked.setdefault((key, kind), []).append((score, target, line))
    for key, bucket in strong.items():
        best = sorted(bucket.items(), key=lambda kv: -kv[1])
        for (target, line), _ in (best[:strong_cap] if strong_cap and strong_cap > 0 else best):
            keep.add((target, line, key))         # 舊值原樣還在：優先列（每處最多 strong_cap 段）
    for (key, _), items in ranked.items():
        best = {}
        for score, target, line in items:
            if score > best.get((target, line), -1):
                best[(target, line)] = score
        for (target, line), _ in sorted(best.items(), key=lambda kv: -kv[1])[:cap]:
            keep.add((target, line, key))
    dropped = {}
    for cand in candidates - keep:
        target, line, key = cand
        dropped[key] = dropped.get(key, 0) + 1
        if unlisted is not None:
            entry = {"候選段次": dt.line_of(line), "候選全文SHA256": dt.text_sha256(texts.get(cand, ""))}
            if entry not in unlisted.setdefault(target, []):
                unlisted[target].append(entry)
    out = {}
    for target, rows in found.items():
        out[target] = [row for row in rows
                       if row.get(CROSS_CHANGE_KEY) is None
                       or (target, row.get("候選段次"), row[CROSS_CHANGE_KEY]) in keep]
    return out, dropped


# ---------------------------------------------------------------------------
# 跨本引用（不靠規格包）：直接在 B 本草稿裡找「A 本名稱＋第X條／第X點／第X章第X節…」
# ---------------------------------------------------------------------------
# 規格包的 引用.csv 是建基準（切條）時才有的；沒做建基準，「B 本寫明依 A 本第三點辦理、
# 而 A 本第三點這次改了或換號了」這種最直接的跨本連帶，只能靠文字相似去碰。
# 這裡直接讀 B 本的字：B 的引用是照 A 的**舊編號**寫的，所以拿 A 的舊版去解讀，
# 再看那個位置這一輪怎麼了——
#   換號 → 需改寫：建議改法照位置把號碼換成新的（跟同本的章節引用同一套，見 row_assist）
#   刪除 → 危險：沒有建議改法，要人決定改指哪裡
#   內容改了 → 要看：號碼沒變，但指到的條文內容這次改了
#   只寫「依 A 本辦理」→ 未指明條號：A 本這次有改就提醒一次

_CITE_NUM = r"[%s\d０-９]+" % "零〇一二三四五六七八九十百千兩"
_AFTER_NAME_RE = re.compile(r"[」』》〉\"'\s]*(?:中之|之|所定之?|規定之?)?\s*")
_CITE_ARTICLE_RE = re.compile(r"第\s*(%s)\s*條(?:\s*之\s*(%s))?" % (_CITE_NUM, _CITE_NUM))
_CITE_POINT_RE = re.compile(r"第\s*(%s)\s*點" % _CITE_NUM)


class SourceIndex(object):
    """A 本（被引用的那一本）這一輪的新舊對照：舊版每一條、每一點、每一章節這次怎麼了。"""

    def __init__(self, outcome):
        import renumber
        from _common import cn_to_int as _cn
        self.cn = _cn
        old, new = outcome["old_paragraphs"], outcome["new_paragraphs"]
        old_kinds, new_kinds = outcome.get("old_kinds"), outcome.get("new_kinds")
        self.old_to_new = {}
        self.changed_old = set()
        self.changed_ref = {}     # 舊版段次 → 那一處異動的條號（跟異動清單的 ref 一樣）
        self.last_refs = []       # 上一次查詢（article／point／outline_touched）碰到的異動條號
        self.substantive = 0
        for r in outcome["results"]:
            oi = r.get("old_index")
            if oi:
                self.old_to_new[oi] = None if r["type"] == "deleted" else r.get("new_index")
                if r["type"] in ("modified", "deleted"):
                    self.changed_old.add(oi)
                    self.changed_ref[oi] = r.get("ref") or ""

            if r["type"] in ("added", "deleted", "modified"):
                self.substantive += 1
        self.old_ctx = build_hierarchy(old, old_kinds)
        self.article_map = renumber.plan_article_map(old, new, old_kinds, new_kinds)
        old_entries = renumber.scan(old, old_kinds)
        self.has_articles = renumber.numbering_check_applicable(old_entries)
        self.doc_wide = not self.has_articles and renumber._points_run_through(old_entries)
        self.old_points = {}
        clauses = [e for e in old_entries if e["level"] == "款" and e["written"] is not None
                   and (e.get("clause_serial") or 1) == 1]
        for pos, e in enumerate(clauses):
            end = clauses[pos + 1]["index"] - 1 if pos + 1 < len(clauses) else len(old)
            self.old_points.setdefault(e["written"], (e["index"], end))
        self.new_written = dict((e["index"], e["written"]) for e in renumber.scan(new, new_kinds)
                                if e["level"] == "款" and e["written"] is not None)
        self.old_units = renumber.outline_units(old, old_kinds)
        self.outline_map = renumber.plan_outline_map(self.old_units, renumber.outline_units(new, new_kinds))
        self.point_map = renumber.plan_point_map(renumber.outline_points(old, old_kinds),
                                                 renumber.outline_points(new, new_kinds), self.outline_map)

    def _touched(self, first, last):
        hits = sorted(i for i in self.changed_old if first <= i <= last)
        self.last_refs = [self.changed_ref[i] for i in hits if self.changed_ref.get(i)]
        return bool(hits)

    def article(self, number):
        """「第X條」：回傳 (狀態, 新寫法或 None, 說明)。狀態 None＝這一條這輪沒動，不用報。"""
        from renumber import normalize_article_no as _norm
        key = _norm(number)
        entry = None
        for old_article, value in self.article_map.items():
            if _norm(old_article) == key:
                entry, key = value, old_article
                break
        if entry is None:
            return "無法判定", None, "舊版找不到%s" % number
        indices = [i for i, c in enumerate(self.old_ctx, 1) if c.get("article") == key]
        touched = bool(indices) and self._touched(min(indices), max(indices))
        if entry.get("new") is None:
            if entry.get("merged_into"):
                return "需改寫", entry["merged_into"], "%s這次併入%s" % (key, entry["merged_into"])
            return "危險", None, "%s這次刪掉了" % key
        if _norm(entry["new"]) != _norm(key):
            return "需改寫", entry["new"], "%s這次改號為%s" % (key, entry["new"])
        if touched:
            return "內容改了", None, "%s的內容這次改了" % key
        return None, None, ""

    def point(self, number):
        """「第X點」（沒有條、一路編到底的要點）。"""
        if self.has_articles:
            return "無法判定", None, "A 本有「第X條」，「第%s點」對不到" % self.cn_text(number)
        if not self.doc_wide:
            return "無法判定", None, "A 本各章節各自從一編點，「第%s點」看不出是哪一章" % self.cn_text(number)
        unit = self.old_points.get(number)
        if unit is None:
            return "無法判定", None, "舊版找不到第%s點" % self.cn_text(number)
        first, last = unit
        new_index = self.old_to_new.get(first)
        if new_index is None:
            return "危險", None, "第%s點這次刪掉了" % self.cn_text(number)
        new_number = self.new_written.get(new_index)
        if new_number is not None and new_number != number:
            return "需改寫", new_number, "第%s點這次改號為第%s點" % (self.cn_text(number), self.cn_text(new_number))
        if self._touched(first, last):
            return "內容改了", None, "第%s點的內容這次改了" % self.cn_text(number)
        return None, None, ""

    def outline_touched(self, key):
        """舊版 key＝(章號, 節號或 0) 那一章（節）裡，這一輪有沒有段落被改或被刪。"""
        import renumber

        def number_of(label):
            match = renumber._HEADING_NO_RE.match(label or "")
            return self.cn(match.group(1)) if match else 0

        hits = []
        for i in sorted(self.changed_old):
            context = self.old_ctx[i - 1]
            if number_of(context.get("chapter")) != key[0]:
                continue
            if key[1] and number_of(context.get("section")) != key[1]:
                continue
            hits.append(i)
        self.last_refs = [self.changed_ref[i] for i in hits if self.changed_ref.get(i)]
        return bool(hits)

    def cn_text(self, number):
        from _common import cn_from_int
        return cn_from_int(number)


def _cited_number(text):
    from _common import cn_to_int as _cn
    return _cn(unicodedata_nfkc(text))


def unicodedata_nfkc(text):
    import unicodedata
    return unicodedata.normalize("NFKC", text or "")


def text_citation_links(source_name, index, target_paragraphs):
    """B 本草稿裡明文引用 A 本（source_name）的每一處，對照 A 本這一輪的異動（index＝SourceIndex）。
    回傳跨本候選列；要改寫的列帶 dt.OUTLINE_KEY（建議改法由 row_assist 照位置改寫）。"""
    import renumber
    out = []
    for line, text in enumerate(target_paragraphs, 1):
        pos = 0
        while True:
            at = text.find(source_name, pos)
            if at < 0:
                break
            pos = at + len(source_name)
            if text[max(0, at - 1):at] == "本":
                continue
            lead = _AFTER_NAME_RE.match(text, pos).end()
            status, new_text_num, note, quote_span, label, rewrite = None, None, "", None, "", None
            index.last_refs = []
            article = _CITE_ARTICLE_RE.match(text, lead)
            point = _CITE_POINT_RE.match(text, lead)
            chain = [c for c in renumber._outline_citations(text[lead:lead + 120]) if c["start"] == 0]
            if article:
                number = "第%s條" % re.sub(r"\s+", "", article.group(1)) + (
                    "之%s" % article.group(2) if article.group(2) else "")
                status, new_value, note = index.article(number)
                quote_span, label = article.span(), number
                if status == "需改寫":
                    rewrite = new_value
            elif point:
                number = _cited_number(point.group(1))
                status, new_value, note = index.point(number) if number else ("無法判定", None, "點號讀不出來")
                quote_span, label = point.span(), "第%s點" % point.group(1)
                if status == "需改寫":
                    digits = unicodedata_nfkc(point.group(1)).isdigit()
                    rewrite = "第%s點" % (str(new_value) if digits else index.cn_text(new_value))
            elif chain:
                citation = chain[0]
                numbers = dict((lvl, value) for lvl, value, _ in citation["parts"])
                key = (numbers.get("章") or 0, numbers.get("節") or 0)
                quote_span = (lead, lead + citation["end"])
                label = text[quote_span[0]:quote_span[1]]
                if "章" not in numbers or key not in index.old_units:
                    status, note = "無法判定", "舊版找不到%s" % label
                else:
                    target = index.outline_map.get(key)
                    point_no = numbers.get("點")
                    mapped = index.point_map.get((key, point_no)) if point_no else (target, None)
                    if target is None or (point_no and mapped is None):
                        status, note = "危險", "%s這次刪掉了" % label
                    else:
                        renum = {"章": target[0], "節": target[1], "點": mapped[1] if point_no else None}
                        if (target, renum["點"]) != (key, point_no):
                            status = "需改寫"
                            rewrite = renumber._rewrite_citation(text[lead:], citation, renum)
                            note = "%s這次改號" % label
                        elif index.outline_touched(key):
                            status, note = "內容改了", "%s的內容這次有改" % label
            elif index.substantive:
                status, note = "未指明條號", "只寫依%s，沒寫條號；%s這次有 %d 處異動" % (
                    source_name, source_name, index.substantive)
                label = "（未指明條號）"
            if not status:
                continue
            # 「內容改了」：異動條文ID 寫被引用的那一點裡實際改了的那幾段的條號（跟異動清單同一套），
            # 決定表才對得回那一處異動，寫得出「異動內容」「建議改法」（例：三日→五日）
            refs = list(dict.fromkeys(index.last_refs)) if status == "內容改了" else []
            change_id = "；".join("%s：%s" % (source_name, r) for r in refs) or "%s：%s" % (source_name, label)
            row = _row("跨本引用", change_id, note, "", line, text,
                       "引用 %s%s：%s" % (source_name, label if label != "（未指明條號）" else "", note))
            if status in ("需改寫", "危險") and quote_span:
                row[dt.OUTLINE_KEY] = [{
                    "status": status, "quote": text[quote_span[0]:quote_span[1]],
                    "new_quote": rewrite or "", "start": quote_span[0], "end": quote_span[1],
                    "note": note, "tag": "%s換號" % source_name}]
            out.append(row)
    return out


# ---------------------------------------------------------------------------
# 引用連帶：B 本規格包的引用.csv 有沒有引用到 A 本被改的那條
# ---------------------------------------------------------------------------

def citation_links(source_name, source_changes, target_baseline, target_new_line_ids,
                   target_paragraphs):
    path = os.path.join(getattr(target_baseline, "version_dir", ""), "規格包", "引用.csv")
    if not os.path.isfile(path):
        return []
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    id_to_line = {}
    for line, ids in (target_new_line_ids or {}).items():
        for item_id in ids:
            id_to_line.setdefault(item_id, int(line))
    keys = []
    for change in source_changes:
        wanted = set()
        if change.get("ref"):
            wanted.add(normalize_article_no(change["ref"]))
        for pos in change.get("positions") or []:
            wanted.add(normalize_article_no(pos))
        keys.append((_label(source_name, change), {k for k in wanted if k}, dt._summary(change["new_text"])))
    src = normalize_article_no(source_name)
    out = []
    for r in rows:
        if (r.get("規章外引用") or "").strip() != "Y":
            continue
        names = [x.strip() for x in (r.get("規章名") or "").split(";")]
        numbers = [x.strip() for x in (r.get("條號") or "").split(";")]
        for index, name in enumerate(names):
            n = normalize_article_no(name)
            if not n or not (n == src or n in src or src in n):
                continue
            number = numbers[index] if index < len(numbers) else "-"
            line = id_to_line.get(r.get("條文ID"))
            # 真的規格包 引用.csv 沒有「全文」欄；定位不到草稿段落時退回基準的 條文.csv。
            text = (target_paragraphs[line - 1] if line else
                    (getattr(target_baseline, "by_id", {}).get(r.get("條文ID"), {}) or {}).get("全文", ""))
            tail = "" if line else "（無法定位到草稿段落）"
            if number and number != "-":
                nn = normalize_article_no(number)
                for label, wanted, summary in keys:
                    if any(nn == k or nn in k or k in nn for k in wanted):
                        out.append(_row("跨本引用", label, summary, r.get("條文ID", ""), line, text,
                                        "引用 %s %s%s" % (source_name, number, tail)))
            else:
                for label, wanted, summary in keys:
                    out.append(_row("跨本引用", label, summary, r.get("條文ID", ""), line, text,
                                    "引用 %s（未指明條號）%s" % (source_name, tail)))
    return out


# ---------------------------------------------------------------------------
# 摘要
# ---------------------------------------------------------------------------

def write_batch_summary(path, stats):
    """批次摘要。每本的數字之外，還要把各本的提醒彙整在同一張紙上。

    為什麼：批次跑十本時，第三本的「新舊版可能放反」印在畫面上早就被後面七本洗掉了。
    各本子資料夾裡雖然都有自己的 提醒.txt，但沒有人會一本一本去點開——
    會被看到的是這張摘要。
    """
    lines = ["批次摘要", ""]
    # 裁定 7：沒改的本要在摘要最上面單獨列一行。批次跑十本、每本三四行數字，
    # 「實質異動 0 處」那一行躺在第七本裡沒有人會注意到；而 0 異動最常見的原因
    # 不是這本真的沒改，是草稿還沒放進來或檔案拿錯。只列名字，不翻轉整批的結論。
    # 清單裡沒放新版草稿的本（配對時標「沒改」）是刻意不改，跟「放了草稿卻一處都沒改」
    # 分開講：前者是預期的，後者才可能是檔案拿錯。混在同一行「無異動」底下再叫人
    # 「確認草稿有沒有放進來」，刻意不改的那一本也會被懷疑漏放。
    kept = [s["規章名"] for s in stats if not s.get("有草稿", True)]
    zero = [s["規章名"] for s in stats if s.get("有草稿", True)
            and s.get("零異動", not s.get("實質異動", 0))]
    if kept:
        lines.append("本次不修改 %d 本：%s（清單裡沒有新版草稿；只檢查別本的改動要不要帶到這幾本）"
                     % (len(kept), "、".join(kept)))
    lines.append("無異動 %d 本：%s" % (len(zero), "、".join(zero) or "無"))
    if zero:
        lines.append("（有放新版草稿卻一處都沒改，請確認草稿有沒有放對、檔案有沒有拿錯。）")
    lines.append("")
    for s in stats:
        lines.append("【%s】%s" % (s["規章名"], "" if s.get("有草稿", True) else "（本次不修改，只看別本的改動）"))
        lines.append("  實質異動 %d 處，候選 %d 列" % (s.get("實質異動", 0), s.get("候選", 0)))
        dist = s.get("來源分佈") or {}
        lines.append("  來源：%s" % ("、".join("%s %d" % kv for kv in sorted(dist.items())) or "無"))
        lines.append("  跨本來自：%s" % ("、".join(sorted(s.get("跨本來自") or [])) or "無"))
        if s.get("沿用") is not None:
            lines.append("  沿用上一輪決定 %d 列（決定表「沿用上一輪」欄寫「是」）；其餘 %d 列要重新看"
                         % (s["沿用"], s.get("候選", 0) - s["沿用"]))
        warned = len(nt.warnings(s.get("提醒") or []))
        lines.append("  提醒 %d 則%s（完整內容見本節下方的提醒彙整，或 產出/系統檔案/<規章名>/審閱文件/提醒.txt）"
                     % (len(s.get("提醒") or []), "（其中警告 %d 則，要處理）" % warned if warned else ""))
        lines.append("")

    lines.append("─" * 30)
    lines.append("提醒彙整")
    lines.append("")
    total = sum(len(s.get("提醒") or []) for s in stats)
    if not total:
        lines.append("本次批次沒有任何提醒。")
    else:
        # 一字不差出現在兩本以上的提醒（例如每本都有的「沒有第X條」）只講一次：
        # 十本各列一次，真正只屬於某一本的那一則就被淹掉了
        # 用 notices 自己那一支排版：提醒.txt 與這裡的格式要一模一樣，各寫一份遲早會漂開
        owners = {}
        for s in stats:
            for line in set(nt.format_line(e) for e in s.get("提醒") or []):
                owners.setdefault(line, []).append(s["規章名"])
        shared = [line for line, names in owners.items() if len(names) > 1]
        if shared:
            lines.append("【各本共同】")
            for line in sorted(shared, key=lambda l: (not l.startswith(nt.WARNING), l)):
                lines.append("  %s（%s）" % (line, "、".join(owners[line])))
            lines.append("")
        for s in stats:
            entries = s.get("提醒") or []
            own = [nt.format_line(e) for e in entries if nt.format_line(e) not in shared]
            lines.append("【%s】提醒 %d 則%s" % (
                s["規章名"], len(entries),
                "（其中 %d 則見上面「各本共同」）" % (len(entries) - len(own)) if len(own) < len(entries) else ""))
            if not own:
                lines.append("  （無）" if not entries else "  （都在上面「各本共同」）")
            for line in own:
                lines.append("  " + line)
            lines.append("")
    lines.append("提醒不等於錯誤，但每一則都要有人看過再決定要不要處理。")
    lines.append("")
    lines.append("連帶決定表在 產出/填寫表單/連帶決定表.csv（全部規章一張，第一欄是規章）；"
                 "填完再跑 batch-apply、batch-finalize。最終仍需人工複核。")
    with io.open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")
    return path
