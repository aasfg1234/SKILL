# -*- coding: utf-8 -*-
"""提醒留底：印到畫面的同一句話，同時收進清單，收尾時寫進產出檔。

為什麼需要這一支（實測 P2）：
這支工具最重要的幾句話全部只活在 console——「新舊版可能放反」「有 N 處標不上去」
「有 N 列程式沒改到」「定稿仍含追蹤修訂」「無法定位 N 筆」。畫面會被後面的
統計洗掉，SPADE 之類的平台還會把輸出截斷（留尾巴、切開頭），使用者最後拿到的
只有產出資料夾裡的那幾個檔案。提醒一個字都沒留下，等於沒提醒。

所以規則很簡單：**任何提醒都要走這一支**。這裡負責兩件事——
    一、立刻印到畫面（文字與原本一字不差，前綴由等級決定）
    二、收進清單，由呼叫端在收尾時寫進 提醒.txt、條文檢查報告、批次摘要

用法：
    import notices as nt
    nt.notice(nt.REMINDER, "新舊版可能放反了（檔名帶新舊字樣但順序相反）", "讀檔")
    ...
    nt.write_notices(outdir)          # 寫 <outdir>/審閱文件/提醒.txt

清單是模組層的單一狀態（一支程式就是一次作業，不需要多執行緒）。
批次是一本一本跑的，每本開始前 reset()、結束後 drain()，各本的提醒才不會互相混進去。
"""

import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

# 不在模組層 import _common：_common 自己要呼叫 notice()（讀檔提醒都在那裡），
# 兩邊在模組層互相 import 會變成循環匯入。只有 write_notices 需要 place()，
# 到那時候 _common 一定早就載好了，臨時 import 一次就好。

REMINDER = "提醒"
WARNING = "警告"

# 等級決定畫面上的前綴。提醒沿用既有的「提醒：」寫法（很多測試與使用者的眼睛
# 都認這四個字），警告用方括號，跟「[中止]」同一個視覺層級。
_PREFIX = {REMINDER: "提醒：", WARNING: "[警告] "}

FILENAME = "提醒.txt"
# 一行一則：等級｜來源｜文字。用全形直線是因為提醒文字裡逗號、頓號很多，
# 用它們當分隔會切不開。
SEPARATOR = "｜"

_collected = []

# 還沒被任何一次作業收走的提醒。有些提醒發生在「作業開始之前」（例如
# 設定.json 讀不出來——那是 main() 解參數的時候就發生的事），reset() 不能把它
# 清掉，不然第一次 write_notices 寫出來的檔案裡它就消失了。第一次寫檔併進去之後
# 才算交付完成。
_pending = []

# 「這件事這一輪已經講過了」。以前這些旗標各自散在 _common 的模組層
# （_REMINDED_FILES、_group_marker_warned、_MD_WARNED），一支程式跑完才會消失——
# 批次跑第二本時，第二本的文字方塊、自動編號、「（第N組）」提醒全部被當成
# 「已經講過」而整個吞掉，那一本的 提醒.txt 就少了幾則。改放這裡，跟提醒清單
# 同一個生命週期，reset() 一起清掉，每一本都會重新講一次。
_once = set()
# 要跨呼叫累積的資料（例如 display_ref 拿掉過標記的 ref），同樣跟著 reset()。
_memory = {}


def notice(level, text, source=""):
    """記一則提醒：立刻印到畫面，同時收進清單。回傳這一則的 dict。

    level  "提醒" 或 "警告"（不認得的值一律當成提醒，寧可多印也不要吞掉）
    text   提醒本文，**不要自己加「提醒：」前綴**，前綴由等級決定
    source 哪一步發出的（讀檔、Step 1 比對、套用……），只給留底用
    """
    return _record(_collected, level, text, source)


def notice_pending(level, text, source=""):
    """跟 notice 一樣，但這一則在作業開始前就發生了，reset() 不會清掉它。

    用在「還沒進到某一次 compare／apply」就發生的提醒：設定檔讀不出來之類的。
    第一次 write_notices 把它寫進檔案之後才算交付完成，屆時才清掉。
    """
    return _record(_pending, level, text, source)


def carry_over():
    """目前收到的提醒搬去「作業開始前」那一格（不重印）：接下來的 reset() 不會清掉。
    用在 compare 開始前就發生的提醒（輸入留底覆寫之類），不然 run_compare 一開頭就把它清掉（B9）。"""
    _pending.extend(_collected)
    del _collected[:]


def _record(bucket, level, text, source):
    level = level if level in _PREFIX else REMINDER
    text = (text or "").strip()
    entry = {"等級": level, "來源": source or "", "文字": text}
    bucket.append(entry)
    print(_PREFIX[level] + text, flush=True)
    return entry


def collected():
    """目前累積的提醒（複本，不清空）。要算數量、要寫檔的都用這一支。"""
    return _pending + _collected


def warnings(entries=None):
    """其中屬於「警告」等級的那幾則。結論要不要保留「改好」看這個。"""
    entries = collected() if entries is None else entries
    return [e for e in entries if e.get("等級") == WARNING]


def drain():
    """取出目前累積的提醒並清空。批次每跑完一本用它把那一本的提醒收走。"""
    taken = collected()
    del _collected[:]
    del _pending[:]
    return taken


def reset():
    """清空。每一次作業（compare／apply／finalize、批次的每一本）開始時呼叫。

    _pending 不清：那是作業開始之前就發生的事，還沒寫進任何檔案。
    """
    del _collected[:]
    _once.clear()
    _memory.clear()


def once(key):
    """第一次看到這個 key 回 True，之後都回 False。reset() 之後重新算一次。

    「同一個檔案的讀檔提醒只講一次」這種去重用它，不要自己在別的模組開旗標——
    那種旗標的生命週期是「整支程式」，批次的第二本就再也不會提醒了。
    """
    if key in _once:
        return False
    _once.add(key)
    return True


def forget(key):
    """把某個 key 從「已經講過」裡拿掉，下一次 once(key) 又會回 True。

    正常流程用不到（reset() 就夠了），是給測試重播單一檔案的讀檔提醒用的。
    """
    _once.discard(key)


def remember(key, value):
    """把 value 累積到 key 底下（例：display_ref 拿掉過標記的 ref）。"""
    _memory.setdefault(key, []).append(value)


def remembered(key):
    """key 底下累積到的東西（複本）。"""
    return list(_memory.get(key, ()))


def format_line(entry):
    """一則提醒在留底檔裡的樣子：等級｜來源｜文字。"""
    return SEPARATOR.join([entry.get("等級") or REMINDER,
                           entry.get("來源") or "（未註明）",
                           entry.get("文字") or ""])


def report_lines(entries=None, title="提醒（畫面上印過的，這裡留一份）"):
    """給別的報告檔（終比對驗收報告、批次摘要）內嵌用的一段文字。"""
    entries = collected() if entries is None else entries
    lines = [title]
    if not entries:
        lines.append("  本次沒有提醒。")
        return lines
    for entry in entries:
        lines.append("  " + format_line(entry))
    return lines


# append 模式的段落分隔線。一份 提醒.txt 可能由 compare 與 apply 前後接力寫成，
# 兩段之間要看得出斷點，不然會以為是同一步發出的。
SECTION_DIVIDER = "─" * 30


def write_notices(outdir, prefix="", entries=None, title="", append=False):
    """把提醒寫成 <outdir>/審閱文件/提醒.txt（有 prefix 就是 <prefix>_提醒.txt）。

    一則都沒有也照寫：使用者要看得出「這次真的沒有提醒」，跟「這個功能沒跑到」
    是兩件事，沒有檔案的話兩者長得一模一樣。回傳寫出來的絕對路徑。

    title：檔頭那一行要不要多寫一句「這是哪一步的提醒」。同一個資料夾裡可能有
    好幾份提醒檔（各本一份、批次驗收一份），沒有標題就分不出誰是誰。

    append：檔案已經在了就接在後面，不覆寫。
        compare 與 apply 用的是同一個產出資料夾、同一個 審閱文件/提醒.txt，
        而 apply 開頭會 reset() 清空清單——直接覆寫的話，compare 那幾則
        （新舊版可能放反、有 N 處標不上去、款目編號未檢查……）會被洗成
        apply 自己的那一兩則，甚至洗成「本次沒有提醒」。那份檔案是提醒的權威留底，
        被洗掉等於那幾則從來沒發生過。append 模式一定要給 title，
        檔頭才分得出哪一段是哪一步寫的。
    """
    from _common import place
    own = entries is None
    entries = collected() if own else entries
    # 提醒.txt 是「人要看」的那一份，跟報告一起進 審閱文件/（見 _common.FILE_HOMES）。
    path = os.path.abspath(place(outdir or ".", FILENAME, prefix))
    appending = bool(append) and os.path.isfile(path)
    lines = ["", SECTION_DIVIDER, ""] if appending else []
    lines += ["提醒留底" + ("　—　" + title if title else ""),
              "（畫面會被後面的輸出洗掉或截斷，這份檔案才是留得住的那一份）", ""]
    if entries:
        lines.append("共 %d 則。格式：等級%s來源%s內容" % (len(entries), SEPARATOR, SEPARATOR))
        lines.append("")
        lines += [format_line(entry) for entry in entries]
    else:
        lines.append("本次沒有提醒。")
    lines.append("")
    lines.append("提醒不等於錯誤，但每一則都要有人看過再決定要不要處理。最終仍需人工複核。")
    # 接寫時不能再用 utf-8-sig：BOM 只能在檔頭出現一次，接在中間會變成一個怪字元。
    with io.open(path, "a" if appending else "w",
                 encoding="utf-8" if appending else "utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")
    if own:
        # 作業開始前累積的那幾則已經落到磁碟上了，任務完成，不用再跟著下一次作業跑
        del _pending[:]
    return path
