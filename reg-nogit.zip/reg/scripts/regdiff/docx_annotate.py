# -*- coding: utf-8 -*-
"""
在「原檔」上標註，而不是另外生一份新的 Word 檔。

--------------------------------------------------------------------------
為什麼要有這支
--------------------------------------------------------------------------
早期版本的標註版全文是開一份空白 Word、把文字一段一段倒進去。文字是對的，
但原檔的東西全部不見：實測一份普通的內規，11 項格式裡掉了 10 項——

    字型（標楷體）、字級、首行縮排、頁首、頁尾、頁面邊界、
    以及整張附表（表格直接消失）

法遵拿到那份檔案沒辦法用。對照表可以是新做的表格，但「標註版全文」的意思
就是「你原本那份，只是把改動標起來」，格式跑掉就失去意義了。

這支的做法是：**把原檔複製一份，只動有改到的那幾段裡面的文字**。
沒改到的段落一個位元組都不碰，表格、頁首頁尾、樣式、頁面設定自然全部留著。

--------------------------------------------------------------------------
只用標準函式庫
--------------------------------------------------------------------------
.docx 就是一個 zip，內容在 word/document.xml。用 zipfile ＋ xml.etree 就夠了。

這件事有額外的好處：套件庫固定的平台（例如 SPADE）裝不了 python-docx，
以前在那種環境完全產不出 Word 檔，現在產得出來，而且格式比以前更完整。

--------------------------------------------------------------------------
做不到的事
--------------------------------------------------------------------------
- 輸入不是 .docx（例如 .txt）時沒有原檔可改，會退回舊的「新建一份」做法
- 表格儲存格內含多段文字時，那一格不標記（會回報幾格沒標）
- 不寫成 Word 的「追蹤修訂」，是直接把顏色與底線刪除線套上去。
  追蹤修訂要另外處理 rsid 與作者資訊，而且法遵要的是可以直接列印的版本。
"""

import copy
import os
import re
import shutil
import zipfile
import xml.etree.ElementTree as ET

from _common import (ANCHOR_TAGS, DELETE_LIKE_TAGS, INSERT_LIKE_TAGS,
                     PROPERTY_CHANGE_TAGS, RANGE_MARKER_TAGS,
                     _docx_paragraph_text, accept_revisions,
                     has_tracked_changes, is_line_break, iter_docx_text_nodes,
                     run_symbol_text, sanitize_for_xml)

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_W = "{%s}" % W

# 這一輪寫 docx 時清掉了幾個 XML 不合法字元。寫檔的那一支開頭 reset_xml_cleanup()、
# 收尾看 xml_cleanup_count()，一份文件只發一則提醒（不是每個 run 一則）。
_XML_CLEANED = [0]


def reset_xml_cleanup():
    """開始寫一份新的 docx 之前歸零。"""
    _XML_CLEANED[0] = 0


def xml_cleanup_count():
    """上次歸零之後，總共清掉幾個 XML 不合法字元。"""
    return _XML_CLEANED[0]


# 範本鎖定：<w:sdtPr><w:lock w:val="…"/>。ECMA-376 的 ST_Lock 有四個值，
# 只有前兩個是「內容不准改」，才輪得到 apply 跳過：
#     contentLocked     內容不准改（控制項本身還是可以刪）
#     sdtContentLocked  內容與控制項都鎖住
#     sdtLocked         只有控制項不准刪，**內容照樣可以編輯**
#     unlocked          都沒鎖
# 把 sdtLocked 也當成鎖定會平白少改一條，而且報告會寫「範本不准改」——那是假話。
LOCKED_SDT_VALUES = frozenset(("contentLocked", "sdtContentLocked"))


def parent_map(root):
    """root 底下每個元素的父節點。ElementTree 沒有 .getparent()，要自己建一份。"""
    return {id(child): parent for parent in root.iter() for child in parent}


def locked_sdt_alias(node, parents):
    """node 的祖先裡有沒有「內容被鎖住」的 w:sdt（見 LOCKED_SDT_VALUES）。

    有就回傳那個控制項的別名（範本設計者給的欄位名；沒取名回「未命名欄位」），
    沒有就回傳空字串。公文範本常把核定欄、發文字號那幾格鎖起來，
    程式硬寫進去 Word 會擋掉或還原，套用報告卻記「已套用」（實測 no 24）。

    只鎖控制項不鎖內容的 sdtLocked 不算：那一格的字是可以改的。
    """
    current = node
    while current is not None:
        if current.tag == _W + "sdt":
            props = current.find(_W + "sdtPr")
            if props is not None:
                lock = props.find(_W + "lock")
                if lock is not None and lock.get(_W + "val") in LOCKED_SDT_VALUES:
                    alias = props.find(_W + "alias")
                    name = alias.get(_W + "val") if alias is not None else ""
                    return name or "未命名欄位"
        current = parents.get(id(current))
    return ""


def _register_namespaces(xml_bytes):
    """
    先把原檔宣告過的命名空間前綴全部註冊回去，再解析。

    不做這件事的話，ElementTree 會自己編出 ns0、ns1 這種前綴。整份都掃（不是只看開頭）：
    文字方塊、圖形裡面才宣告的前綴也要註冊，不然輸出會冒出 ns5。
    只註冊還不夠：ElementTree 輸出時會丟掉「沒用到」的宣告，mc:Ignorable 指名的前綴
    一不見 Word 就說檔案毀損——寫回去一律用 to_xml_bytes（把原檔根元素的宣告補回去）。
    """
    head = xml_bytes.decode("utf-8", "replace")
    for prefix, uri in re.findall(r'xmlns:([A-Za-z0-9_.-]+)\s*=\s*"([^"]+)"', head):
        try:
            ET.register_namespace(prefix, uri)
        except ValueError:
            pass
    default = re.search(r'xmlns\s*=\s*"([^"]+)"', head)
    if default:
        try:
            ET.register_namespace("", default.group(1))
        except ValueError:
            pass


_ROOT_TAG = re.compile(rb"<(?![?!])[^>]*>")
_NS_DECL = re.compile(rb'\sxmlns(?::([A-Za-z0-9_.-]+))?\s*=\s*"([^"]*)"')


def to_xml_bytes(root, original_bytes):
    """ElementTree 寫回 XML，並把原檔根元素上的命名空間宣告補齊（A1）。

    ElementTree 只輸出「有元素或屬性用到」的宣告；Word 的 document.xml、settings.xml 根元素上
    一口氣宣告了二三十個前綴，mc:Ignorable="w14 w15 w16se …" 又指名其中好幾個。宣告被丟掉，
    Ignorable 就指到不存在的前綴，Word 開檔說「檔案似乎已毀損」（本機 Word 實測過）。
    這裡把原檔根元素有、輸出根元素沒有的宣告原樣補回去（同一個前綴不重複宣告）。
    """
    out = ET.tostring(root, encoding="UTF-8", xml_declaration=True)
    old_tag = _ROOT_TAG.search(original_bytes or b"")
    new_tag = _ROOT_TAG.search(out)
    if not old_tag or not new_tag:
        return out
    have = set(m.group(1) for m in _NS_DECL.finditer(new_tag.group(0)))
    missing = [m.group(0) for m in _NS_DECL.finditer(old_tag.group(0)) if m.group(1) not in have]
    if not missing:
        return out
    tag = new_tag.group(0)
    cut = len(tag) - (2 if tag.endswith(b"/>") else 1)
    fixed = tag[:cut] + b"".join(missing) + tag[cut:]
    return out[:new_tag.start()] + fixed + out[new_tag.end():]


def _paragraph_text(paragraph):
    """跟讀檔那邊同一支：直接用 _common._docx_paragraph_text，只是不 strip。

    兩邊差一個字，套用時就會判成「原文不符」而整段跳過，所以不再各寫一份。
    """
    return _docx_paragraph_text(paragraph, strip=False)


def collect_slots(body):
    """
    照 read_docx_stdlib 的順序把段落列出來：表格走到哪就在哪展開，格內每段各算一段。

    順序必須跟讀檔那邊一模一樣，否則標註會標到別段去——那比不標還糟。
    所以兩邊都只呼叫 _common.iter_docx_text_nodes（會走進內容控制項、巢狀表格
    每一格只走一次），連「空白的不算一段」這個條件也要一致。

    每一個 slot 的 "p" 一定是一個 <w:p>，不會是 None：以前多段的格整格算一段、
    "p" 填 None，apply 只能整格跳過（「跳過（儲存格多段）」）、標註也標不上去。
    """
    slots = []
    for kind, node, container in iter_docx_text_nodes(body):
        # 兩種節點現在都是 <w:p>，"cell" 只是說「它住在表格的某一格裡」，
        # 差別只在 container（格內段落的容器是那一格，不是段落的直屬父元素）。
        if _paragraph_text(node).strip():
            slots.append({"kind": kind, "p": node, "parent": container})
    return slots


# ---------------------------------------------------------------------------
# 取出每個字目前套的格式
# ---------------------------------------------------------------------------

def _visible_runs(paragraph):
    """
    段落裡「看得到的」run，依序回傳 (run 元素, 文字)。

    <w:del> 底下的 run 放的是 <w:delText>，那是已經被刪掉的文字，不算在內。
    """
    runs = []
    for run in paragraph.iter(_W + "r"):
        text = "".join(t.text or "" for t in run.findall(_W + "t"))
        if text:
            runs.append((run, text))
    return runs


# ---------------------------------------------------------------------------
# 產生標記過的 run
# ---------------------------------------------------------------------------

def _make_run(text, base_rpr, mark):
    """
    做一個 <w:r>。base_rpr 是原本的格式，mark 是要加上的標示（可以是 None）。

    先複製原本的格式再疊上標示，字型與字級才不會掉。
    """
    run = ET.Element(_W + "r")
    rpr = copy.deepcopy(base_rpr) if base_rpr is not None else ET.Element(_W + "rPr")

    if mark:
        for tag in ("color", "u", "strike"):
            for old in rpr.findall(_W + tag):
                rpr.remove(old)
        color = ET.SubElement(rpr, _W + "color")
        color.set(_W + "val", str(mark.get("顏色", "C00000")).lstrip("#"))
        if mark.get("底線"):
            underline = ET.SubElement(rpr, _W + "u")
            underline.set(_W + "val", "single")
        if mark.get("刪除線"):
            strike = ET.SubElement(rpr, _W + "strike")
            strike.set(_W + "val", "1")

    if len(rpr):
        run.append(rpr)

    append_text_nodes(run, text)
    return run


def append_text_nodes(run, text, tag="t"):
    """把文字放進一個 <w:r>；\\t 還原成 <w:tab/>、\\n 還原成 <w:br/>。

    讀檔把定位點與換行讀成 \\t 與 \\n（_common._docx_paragraph_text），寫回去時不還原
    的話，Word 會把它們當成一般空白顯示，原本的定位點與手動換行就消失了。

    寫進去之前先過 sanitize_for_xml：XML 1.0 不收的字元（U+FFFF、未配對代理字……）
    留在 document.xml 裡，Word 會說檔案毀損，而程式一路回報成功（實測 no 32）。
    """
    text, removed = sanitize_for_xml(text or "")
    _XML_CLEANED[0] += removed
    for index, piece in enumerate(re.split(r"([\t\n])", text)):
        if piece == "\t":
            ET.SubElement(run, _W + "tab")
        elif piece == "\n":
            ET.SubElement(run, _W + "br")
        elif piece or (index == 0 and not text):
            node = ET.SubElement(run, _W + tag)
            node.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            node.text = piece
    return run


def edge_runs(raw, rpr_per_char):
    """段落前後被 strip 掉的那一小段（含 <w:tab/>、<w:br/>），回傳 ((前綴, 格式), (後綴, 格式))。

    比對一律用 strip 過的文字——前後空白不算異動，不然整份內規會因為縮排全被判成
    修改。但「寫進產出檔的原文一律保留原字」：重寫段落時前後綴一定要原樣放回去。
    實測 835 條的內規手冊有 15 個 <w:tab/>，全部是段首縮排；吃掉等於把版面改掉，
    而且 apply 還會回報「已套用」，使用者不會發現。
    """
    head = raw[:len(raw) - len(raw.lstrip())]
    tail = raw[len(raw.rstrip()):] if raw.strip() else ""
    head_rpr = rpr_per_char[0] if rpr_per_char else None
    tail_rpr = rpr_per_char[-1] if rpr_per_char else None
    return (head, head_rpr), (tail, tail_rpr)


def _segments_with_format(diff_parts, rpr_per_char, offset):
    """
    把字級差異片段配上原本的格式。

    diff_parts 是 [(種類, 文字), ...]，種類為 equal／insert／delete。
    回傳 [(種類, 文字, rPr, 從第幾個字開始), ...]——位置是用來把書籤、圖片、
    分頁符這些非文字元素插回原來的相對位置。
    equal 與 insert 的文字來自新版，可以直接對到新版原檔的第幾個字；
    delete 的文字在新版裡不存在，就沿用游標當下位置的格式。
    """
    out = []
    pos = offset
    for kind, text in diff_parts:
        if not text:
            continue
        if kind == "delete":
            rpr = rpr_per_char[min(pos, len(rpr_per_char) - 1)] if rpr_per_char else None
            out.append((kind, text, rpr, pos))
            continue

        # 同一段文字中間格式若有變（例如其中兩個字是粗體），要拆開才保得住
        start = 0
        while start < len(text):
            idx = pos + start
            rpr = rpr_per_char[idx] if idx < len(rpr_per_char) else None
            end = start + 1
            while end < len(text):
                nxt = pos + end
                nxt_rpr = rpr_per_char[nxt] if nxt < len(rpr_per_char) else None
                if nxt_rpr is not rpr:
                    break
                end += 1
            out.append((kind, text[start:end], rpr, pos + start))
            start = end
        pos += len(text)
    return out


def _scan_paragraph(paragraph):
    """
    把一段拆成「文字」與「不是文字的東西」兩類，並記下後者卡在第幾個字。

    段落裡除了文字還有一堆東西：書籤、圖片、分頁符、域代碼、註解錨點。
    早期版本重寫段落時把 <w:pPr> 以外的子元素全部清掉再放新文字，
    實測一份含這些元素的內規，**分頁符與書籤直接消失**。

    書籤消失最嚴重：內規常用交叉參照欄位指向書籤，書籤沒了之後
    Word 會在那裡印出「錯誤! 找不到參照來源」，等於把原檔弄壞。

    追蹤修訂照 `_common.REVISION_NODES` 那一張表看，跟讀檔那邊同一套：
    <w:ins>／<w:moveTo> 裡的字**算文字**（讀檔讀的是接受修訂後的樣子，這裡不算的話
    兩邊會差字），<w:del>／<w:moveFrom> 裡的字不算，格式修訂與移動範圍標記不算內容。
    以前這裡只走段落的直屬子層，<w:ins> 被當成「不是文字的東西」整包保留，raw 少了
    插入的字，_rewrite_paragraph 的 expect 就比不過——實測一份含追蹤修訂的草稿，
    標註版全文是每一段都回報「原文不符」，整份標不上去。

    回傳 (完整文字, 每個字的 rPr, [(卡在第幾個字, 要保留的元素), ...])
    """
    text_parts, rpr_per_char, keepers = [], [], []
    pos = 0

    def rescue_anchors(subtree):
        """要丟掉的子樹裡若夾著書籤或註解錨點，撈出來放回目前這個位置。

        刪掉的那幾個字中間常常正好是一個書籤（交叉參照指過來的落點）。連書籤一起
        丟掉的話，Word 會在指過來的地方印「錯誤! 找不到參照來源」，等於把原檔弄壞。
        """
        for node in subtree.iter():
            if node.tag not in ANCHOR_TAGS:
                continue
            spare = copy.deepcopy(node)
            spare[:] = []                     # 錨點本身不帶內容
            if node.tag == _W + "commentReference":
                shell = ET.Element(_W + "r")  # 註解參照一定要包在 <w:r> 裡才合法
                shell.append(spare)
                spare = shell
            keepers.append((pos, spare))

    def walk(parent):
        nonlocal pos
        for child in parent:
            if child.tag == _W + "pPr":
                continue
            if child.tag in INSERT_LIKE_TAGS:
                # 插入／移進來的字就是接受修訂後看得到的字，外殼跳過、裡面照走
                walk(child)
                continue
            if (child.tag in DELETE_LIKE_TAGS or child.tag in PROPERTY_CHANGE_TAGS
                    or child.tag in RANGE_MARKER_TAGS):
                # 刪除／移出的字不算文字，也不必留；格式修訂記的是「改之前的格式」，
                # 移動範圍標記只是一對空元素。重寫這一段等於接受修訂，它們都不留——
                # 但裡面的書籤與註解錨點要撈出來，那不是修訂的一部分。
                rescue_anchors(child)
                continue
            if child.tag == _W + "r":
                rpr = child.find(_W + "rPr")
                # 同一個 run 裡文字與 tab／換行／圖片交錯時，要照原本順序逐個記位置：
                # <w:t>甲</w:t><w:tab/><w:t>乙</w:t> 的 tab 在第 1 個字之後，不是在「甲乙」之後。
                # 以前把所有 <w:t> 先合併再把其餘元素排在後面，tab 會跑到整段文字最後。
                for node in child:
                    if node.tag == _W + "rPr":
                        continue
                    if node.tag == _W + "t":
                        text = node.text or ""
                        if text:
                            text_parts.append(text)
                            rpr_per_char.extend([rpr] * len(text))
                            pos += len(text)
                        continue
                    # 定位點與換行在讀檔那邊算一個字（\t、\n），這裡也要算一個字，
                    # 位置才對得上；寫回去時 append_text_nodes 會把它們還原成元素。
                    if node.tag == _W + "tab" or is_line_break(node):
                        text_parts.append("\t" if node.tag == _W + "tab" else "\n")
                        rpr_per_char.append(rpr)
                        pos += 1
                        continue
                    # 不斷行連字號、<w:sym> 符號：讀檔那邊各算一個字（run_symbol_text），
                    # 這裡也算一個字，位置才對得上。<w:softHyphen/> 讀檔不算字，這裡也不算，
                    # 照下面非文字元素原位保留。
                    symbol = run_symbol_text(node)
                    if symbol is not None:
                        text_parts.append(symbol)
                        rpr_per_char.append(_symbol_rpr(rpr, node))
                        pos += 1
                        continue
                    shell = ET.Element(_W + "r")
                    if rpr is not None:
                        shell.append(copy.deepcopy(rpr))
                    shell.append(copy.deepcopy(node))
                    keepers.append((pos, shell))
                continue

            # 書籤、域代碼、超連結、註解錨點……原封不動留著
            keepers.append((pos, copy.deepcopy(child)))

    walk(paragraph)
    return "".join(text_parts), rpr_per_char, keepers


def _symbol_rpr(rpr, node):
    """<w:sym> 那個字寫回去時要用的格式：原本的 rPr 加上 w:font 指定的符號字型。

    重寫段落時 <w:sym> 會變成一般文字（append_text_nodes 只寫 <w:t>），私用區碼
    （F0B7 之類）不配上 Symbol／Wingdings 字型的話，Word 顯示成方框。其他元素照原 rPr。
    """
    font = node.get(_W + "font") if node.tag == _W + "sym" else None
    if not font:
        return rpr
    out = copy.deepcopy(rpr) if rpr is not None else ET.Element(_W + "rPr")
    for old in out.findall(_W + "rFonts"):
        out.remove(old)
    fonts = ET.Element(_W + "rFonts")
    for attr in ("ascii", "hAnsi", "eastAsia", "cs"):
        fonts.set(_W + attr, font)
    # rFonts 在 rPr 裡排在 rStyle 之後、其他格式之前（順序錯了 Word 會說檔案損毀）
    at = 1 if len(out) and out[0].tag == _W + "rStyle" else 0
    out.insert(at, fonts)
    return out


def accept_paragraph_revisions(paragraph):
    """把這一段裡既有的追蹤修訂就地接受掉；本來就沒有修訂就完全不動。回傳有沒有動過。

    為什麼重寫一段之前要先接受：重寫是「清掉 <w:pPr> 以外的子元素再重新排出來」。
    行內的舊修訂外殼（ins／del／moveFrom／moveTo）因此本來就不會留下——`_scan_paragraph`
    既不把它們算進文字，也不收進 keepers。真正需要這一支的是**留在 <w:pPr> 裡的修訂
    記錄**：段落記號的 del／moveFrom 與 pPrChange 會被原封不動保留下來。
    段落記號的刪除記號留著，等於交出去的檔案帶著一個跟這次改動無關的修訂——
    在 Word 裡接受之後，這一段會莫名其妙跟下一段合併。

    段落記號上的刪除／移出標記這裡只把記號拿掉，不併段：併不併段是整份文件的事
    （apply_changes.clean_tree 才做），標註版全文的段落必須跟讀檔的段次一一對應，
    在這裡併段會把後面每一段的段次都挪掉一格，標註就會標到別段去。
    """
    if not has_tracked_changes(paragraph):
        return False
    accept_revisions(paragraph)
    ppr = paragraph.find(_W + "pPr")
    rpr = ppr.find(_W + "rPr") if ppr is not None else None
    if rpr is not None:
        for tag in DELETE_LIKE_TAGS:
            for marker in rpr.findall(tag):
                rpr.remove(marker)
        if len(rpr) == 0:
            ppr.remove(rpr)
    return True


def _rewrite_paragraph(paragraph, diff_parts, marks, expect=None):
    """
    把一段的文字換成標記過的 run。

    段落設定（<w:pPr>：縮排、行距、對齊、樣式）留著，
    段落裡的書籤、圖片、分頁符、域代碼也留著，而且留在原來的相對位置。
    """
    raw, rpr_per_char, keepers = _scan_paragraph(paragraph)

    # 防呆：這一段「直接放著的文字」必須就是我們要改的那一段。
    #
    # 對不上的典型情形是文字方塊：條文放在 <w:txbxContent> 裡，
    # 讀檔時用遞迴看得到，標註時只看直接子層看不到。硬標下去的結果是
    # 原本的文字留著、標記過的文字又疊上去，**同一條會印兩次**。
    # 那比不標還糟，所以對不上就整段不動，交給呼叫端回報。
    if expect is not None and raw.strip() != expect.strip():
        return False

    # 確定要重寫了才動它：段落裡本來就有的追蹤修訂先接受掉，免得標註版裡
    # 同時存在舊的修訂記號與新的標色，而且段落記號的刪除標記留著會害這一段
    # 在 Word 裡跟下一段合併。raw／keepers 是接受前掃的，內容一樣，不受影響。
    accept_paragraph_revisions(paragraph)

    offset = len(raw) - len(raw.lstrip())

    pieces = _segments_with_format(diff_parts, rpr_per_char, offset)
    (head, head_rpr), (tail, tail_rpr) = edge_runs(raw, rpr_per_char)

    # 只清內容，<w:pPr> 一定要留
    for child in list(paragraph):
        if child.tag != _W + "pPr":
            paragraph.remove(child)

    kept = list(keepers)

    def flush_before(position):
        while kept and kept[0][0] <= position:
            paragraph.append(kept.pop(0)[1])

    # 段首被 strip 掉的縮排（定位點、換行、空白）原樣放回去，而且不標記——它沒有改
    if head:
        paragraph.append(_make_run(head, head_rpr, None))

    for kind, text, rpr, start in pieces:
        if kind == "delete":
            # 刪掉的字在新版裡不佔位置，只要把它之前的元素放回去就好
            flush_before(start)
            paragraph.append(_make_run(text, rpr, marks.get("刪除")))
            continue

        mark = marks.get("新增") if kind == "insert" else None
        cursor, rest = start, text
        while rest:
            flush_before(cursor)
            # 元素若卡在這段文字「中間」，就把文字切開，元素才會留在原位。
            # 只在段落邊界插入的話，句子中間的圖片會被推到整段最後面。
            nxt = kept[0][0] if kept else None
            if nxt is not None and cursor < nxt < cursor + len(rest):
                take = nxt - cursor
            else:
                take = len(rest)
            paragraph.append(_make_run(rest[:take], rpr, mark))
            cursor += take
            rest = rest[take:]

    # 段尾被 strip 掉的那一小段（排在段尾的保留元素之前，跟原本的相對位置一樣）
    if tail:
        paragraph.append(_make_run(tail, tail_rpr, None))
    for _, element in kept:
        paragraph.append(element)
    return True


# pPr 裡排在 numPr 前面的子元素（OOXML 規定的順序），補 numPr 時要插在它們後面
_PPR_BEFORE_NUMPR = tuple(_W + name for name in (
    "pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr", "widowControl"))


def _deleted_paragraph_ppr(template):
    """「已刪除」段落用的段落設定：從錨點段落複製，但拿掉不能跟著複製的東西。

    - numPr：錨點若是自動編號的一項，複製過去等於多一項編號，後面每一項的號碼都 +1
      （標註版上的編號就跟新版對不起來了）。拿掉之後再明寫 numId=0，
      連「樣式本身帶編號」的那一種也關掉。
    - sectPr：錨點若是分節的最後一段，複製過去等於憑空多一個分節（多一頁、頁首頁尾錯位）。
    - pPrChange 與段落記號上的修訂記號：那是錨點自己的修訂記錄，不是這一段的。
    """
    ppr = template.find(_W + "pPr") if template is not None else None
    if ppr is None:
        return None
    ppr = copy.deepcopy(ppr)
    for child in list(ppr):
        if child.tag in (_W + "numPr", _W + "sectPr") or child.tag in PROPERTY_CHANGE_TAGS:
            ppr.remove(child)
    mark = ppr.find(_W + "rPr")
    if mark is not None:
        for child in list(mark):
            if (child.tag in INSERT_LIKE_TAGS or child.tag in DELETE_LIKE_TAGS
                    or child.tag in PROPERTY_CHANGE_TAGS):
                mark.remove(child)
        if len(mark) == 0:
            ppr.remove(mark)
    numbering = ET.Element(_W + "numPr")
    ET.SubElement(numbering, _W + "numId").set(_W + "val", "0")
    at = 0
    for index, child in enumerate(list(ppr)):
        if child.tag in _PPR_BEFORE_NUMPR:
            at = index + 1
    ppr.insert(at, numbering)
    return ppr


def _deleted_paragraph(template, text, marks):
    """
    整段被刪掉的條文，在新版裡沒有對應段落，要新做一段插進去。

    段落設定從鄰近那一段複製，這樣縮排與樣式才跟上下文一致，
    不會突然變成一段靠左頂格的文字。編號、分節與修訂記錄不複製（見 _deleted_paragraph_ppr）。
    """
    para = ET.Element(_W + "p")
    ppr = _deleted_paragraph_ppr(template)
    if ppr is not None:
        para.append(ppr)
    base = None
    if template is not None:
        runs = _visible_runs(template)
        if runs:
            base = runs[0][0].find(_W + "rPr")
    para.append(_make_run(text, base, marks.get("刪除")))
    return para


# ---------------------------------------------------------------------------
# 對外入口
# ---------------------------------------------------------------------------

def annotate_in_place(source_docx, results, output_path, marks, diff_runs):
    """
    複製 source_docx，只把有改到的段落標記起來，寫到 output_path。

    回傳一份摘要 dict，說明標了幾段、有幾段標不到——標不到的一定要講，
    不能讓人以為「沒有紅字就是沒有改」。摘要裡的 xml_cleaned 是這一份清掉了
    幾個 XML 不合法字元，由呼叫端發成一則提醒。
    """
    reset_xml_cleanup()
    with zipfile.ZipFile(source_docx) as archive:
        names = archive.namelist()
        if "word/document.xml" not in names:
            raise ValueError("不是有效的 .docx：找不到 word/document.xml")
        payload = {n: archive.read(n) for n in names}
        infos = {i.filename: i for i in archive.infolist()}

    xml_bytes = payload["word/document.xml"]
    _register_namespaces(xml_bytes)
    root = ET.fromstring(xml_bytes)
    body = root.find(_W + "body")
    if body is None:
        raise ValueError("不是有效的 .docx：找不到 <w:body>")

    slots = collect_slots(body)
    summary = {"marked": 0, "inserted": 0,
               "unmatched": 0, "mismatch": 0, "slots": len(slots)}

    # 「僅字形／空白差異」跟沒改一樣不標：全形空格標上紅字底線，印出來看不出
    # 差別，只會讓人以為那一段有實質異動。要看它請改看修正對照表。
    changed = [r for r in results if r["type"] not in ("unchanged", "cosmetic")]

    # 先處理有對應段落的（修改、新增、編號調整），刪除的最後再插入，
    # 免得先插入改變了後面段落的位置
    for r in changed:
        if r["type"] == "deleted":
            continue
        idx = r.get("new_index")
        if not idx or idx > len(slots):
            summary["unmatched"] += 1
            continue
        slot = slots[idx - 1]
        if r["type"] == "added":
            parts = [("insert", r["new_text"])]
        else:
            parts = diff_runs(r["old_text"] or "", r["new_text"] or "")
        if _rewrite_paragraph(slot["p"], parts, marks,
                              expect=r.get("new_text")):
            summary["marked"] += 1
        else:
            summary["mismatch"] += 1

    # 刪掉的條文插在它原本的位置附近：後面有留下來的段落就插在它前面；
    # 後面沒有了（刪的是最後幾條）就接在前面那一段之後——以前一律「插在錨點前面」，
    # 最後一條被刪時跑到倒數第二（B10）。同一個錨點後面接好幾條時照順序一條接一條。
    placed_after = {}
    for r in changed:
        if r["type"] != "deleted" or not r.get("old_text"):
            continue
        anchor = None
        behind = False
        for after in results[results.index(r) + 1:]:
            j = after.get("new_index")
            if j and j <= len(slots) and slots[j - 1]["p"] is not None:
                anchor = slots[j - 1]
                break
        if anchor is None:
            for before in reversed(results[:results.index(r)]):
                j = before.get("new_index")
                if j and j <= len(slots) and slots[j - 1]["p"] is not None:
                    anchor = slots[j - 1]
                    behind = True
                    break
        if anchor is None:
            summary["unmatched"] += 1
            continue

        parent = anchor["parent"]
        para = _deleted_paragraph(anchor["p"], r["old_text"], marks)
        children = list(parent)
        if anchor["p"] in children:
            if behind:
                last = placed_after.get(id(anchor["p"]), anchor["p"])
                parent.insert(children.index(last) + 1, para)
                placed_after[id(anchor["p"])] = para
            else:
                parent.insert(children.index(anchor["p"]), para)
            summary["inserted"] += 1
        else:
            summary["unmatched"] += 1

    payload["word/document.xml"] = to_xml_bytes(root, xml_bytes)

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as out:
        for name in names:
            info = infos[name]
            item = zipfile.ZipInfo(name, date_time=info.date_time)
            item.compress_type = info.compress_type
            item.external_attr = info.external_attr
            out.writestr(item, payload[name])

    summary["xml_cleaned"] = xml_cleanup_count()
    return summary
