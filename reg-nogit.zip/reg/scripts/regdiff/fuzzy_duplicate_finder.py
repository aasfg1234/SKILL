# -*- coding: utf-8 -*-
"""
Step 2：跨章節重複條文抓取工具（模糊字串比對）── 整個流程最重要的一步

目的：
你修改了某一條規定，但同一個規定因為內規結構的關係，可能在別的章節
(壽險、產險、網路投保……)也各寫了一次，用詞因為實務作業需求略有調整。
只改一處就會漏改。這支程式把你改過的段落拿去跟全文其他段落比相似度，
把有嫌疑的都列出來，交給人工判斷。

原則：寧可多列、不要漏列。法規漏改的代價遠高於多花時間看候選清單。

--------------------------------------------------------------------------
重要：要傳「新版全文」，不是舊版
--------------------------------------------------------------------------
regulation_file 請傳「你已經改好的新版內規全文」。
傳舊版的話，你剛改掉的那一條的舊文字會以極高相似度霸佔候選第一名，
每一筆都被同一個假陽性佔位，等於白跑。

--------------------------------------------------------------------------
關於中文的相似度計算（跟舊版本的差別）
--------------------------------------------------------------------------
跟舊版有三個地方不一樣：

1) 不再用 token_sort_ratio。舊版用它並宣稱「即使詞語順序不一樣也能抓出相似度」，
   這對中文是錯的：token_sort 是靠空白切詞的，中文整句沒有空白會被當成單一 token，
   分數退化成跟 ratio 一模一樣（實測 token_sort / token_set / ratio 三者同分）。
   現在直接用 ratio，不再宣稱做不到的事。

2) 比對前先把條號拿掉。條號不是條文內容，卻會干擾分數——「第三條」對上
   「第二十二條」光這幾個字就先扣一截。實測拿掉條號後，真正相關的條文分數幾乎
   不動(53.1 -> 51.3)，不相干的卻從 22~32 掉到 11~18，訊號雜訊比明顯拉開。

3) 門檻從 70 下修到 45。實測資料：
     「逾期未繳超過三十日者，契約停止效力」
     vs「逾期未繳者，契約停止效力」              同一條漏改  83.9 分
     vs「保險費未於到期日後未繳納者，契約效力停止」 換句話說   51.3 分
     vs 同一份內規裡其他不相干條文                          11~18 分
   舊門檻 70 會漏掉「換句話說」那一類，正好就是本步驟要抓的東西；而 45 距離
   雜訊帶(18)還有很大的空間。原則是寧可多列、不要漏列。

代價是法規慣用語(「本公司應於……」「要保人應……」)會讓不相干的條文分數偏高。
所以輸出多附一欄「最長共同片段」：
  - 分數高、共同片段也長  → 很可能是真的重複條文
  - 分數高、共同片段很短  → 多半只是公文套語像，可以快速跳過
這一欄是給人看的分流線索，不參與門檻判斷。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
三種指定「你改了哪一段」的方法，擇一即可：

1) 直接貼上修改後的文字：
     python fuzzy_duplicate_finder.py 新版全文.docx "第三條 逾期未繳超過三十日者……"

2) 指定它在新版全文裡的段次（就是 Step 1 產出的 CSV 裡「新版段次」那一欄）：
     python fuzzy_duplicate_finder.py 新版全文.docx --changed-line 4

3) 一次跑完 Step 1 抓到的所有修改段落（實務上都用這個，不用手動跑 N 次）：
     python fuzzy_duplicate_finder.py 新版全文.docx --from-csv 修正對照表.xlsx

可調參數：
     --threshold 45   相似度門檻，調低抓得廣、雜訊多；調高會漏
     --top 15         每個修改段落最多列幾筆候選
"""

import argparse
import csv
import functools
import re
import difflib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, read_paragraphs_with_kinds,
                     build_hierarchy,
                     extract_article_no, format_scope, load_synonyms,
                     normalize_terms, strip_article_no, synonym_evidence,
                     resolve_output, load_table_format,
                     normalize_for_compare, COSMETIC_LABEL, display_path,
                     read_xlsx_dicts,
                     diff_runs as _diff_runs)
import xlsx_writer as xw

try:
    from rapidfuzz import fuzz
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False

DEFAULT_THRESHOLD = 45.0
DEFAULT_TOP = 15

# 候選條文要附帶前後各幾段。1 段通常就夠看出它在那一章裡的位置。
DEFAULT_CONTEXT = 1

# 句子層級比對的門檻。整段對整段時，改到的那一句會被沒改的部分稀釋
# （真資料 36.6 分），拿「改到的那一句」去比才對得上（90.3 分）；
# 句子本身短，門檻要比整段比對（45）高，60 分能濾掉不相干的句子。
DEFAULT_SENTENCE_THRESHOLD = 60.0


def calc_similarity(text_a, text_b):
    """
    兩段文字的相似度，0~100，越高越像。傳進來的應該是已經去掉條號的條文本體。

    用 ratio(單純比字元重疊)。理由見檔頭說明：對中文而言 rapidfuzz 的
    token_sort_ratio / token_set_ratio 會退化成 ratio，用它們只是自欺欺人。
    沒裝 rapidfuzz 就退回 Python 內建 difflib，演算法相近，只是慢一點。
    """
    if HAS_RAPIDFUZZ:
        return float(fuzz.ratio(text_a, text_b))
    return difflib.SequenceMatcher(None, text_a, text_b).ratio() * 100.0


# 相似度高到這個程度時，「片段不是從句首開始」就不再是套語的訊號。
# 實測 152 筆候選：80 分以上的 107 筆片段全部從句首開始，套語假陽性最高只到 79.4 分。
# 但真實案例會出現高分卻非句首的情形——「以書面通知」對上「以電子方式通知」，
# 差異落在句子前段，最長片段就被推到句中，分數卻有 94.4，而且是真的重複條文。
HIGH_CONFIDENCE = 80.0


def longest_common_fragment(text_a, text_b):
    """
    兩段文字最長的一段完全相同的連續文字，以及這段文字從哪裡開始。

    回傳 (片段, 位置)，位置是「句首」「句中」或「句尾」。

    為什麼要標位置：
    片段長度單獨看會騙人。實測一份 50 頁的內規：真正被抄到別章的重複條文，
    共同片段 21 字；而一堆毫不相干的條文因為都用同一個句尾套語（「，作為內部
    控制制度有效運作之依據；但金額未達新臺幣十萬元者，得由單位主管逕行核定」），
    共同片段有 40 字，比真的重複還長。只看長度會把套語排在真貨前面。

    改看「片段從哪裡開始」就分得開了。同一份實測資料的 77 筆候選中：
        片段不是從句首開始的 44 筆 —— 全部是套語假陽性，沒有一筆是真的
        片段從句首開始的 33 筆 —— 包含全部 2 筆真的重複，其餘仍需人工判斷
    也就是說，這是個可靠的「排除」訊號，不是「確認」訊號：非句首幾乎可以直接
    跳過，句首則還是要看內容。

    但這個結論有分數上限。同一份資料裡非句首的候選最高只到 79.4 分，
    80 分以上的 107 筆全部是句首。實際案例出現過 94.4 分的非句首候選
    （「以書面通知」對「以電子方式通知」，差異在句子前段），那是真的重複條文。
    所以「非句首＝套語」只在 HIGH_CONFIDENCE 以下成立，高分時不能拿它叫人跳過。
    """
    matcher = difflib.SequenceMatcher(None, text_a, text_b)
    match = matcher.find_longest_match(0, len(text_a), 0, len(text_b))
    fragment = text_a[match.a:match.a + match.size]
    if not fragment:
        return "", ""

    # 容許兩個字的誤差，開頭的主詞用字差異不影響判斷
    if match.a <= 2 and match.b <= 2:
        return fragment, "句首"
    # 落在候選條文後 40% 才開始的，通常就是但書、目的語那一段
    if match.b >= len(text_b) * 0.6:
        return fragment, "句尾"
    return fragment, "句中"


def neighbours(all_paragraphs, index, span):
    """
    候選條文的前後文。index 是 0 起算的位置。

    為什麼需要：
    實測真實內規時發現，「並陳報主管覆核」這類句子在整份文件裡到處都是，
    光看分數與片段位置分不出「這是漏改」還是「這兩個作業的核准層級本來就不同」。

        第六條　分行辦理房屋貸款……並陳報分行經理覆核。
        第七條　分行辦理車輛貸款……並陳報分行經理覆核。
        第十三條　區域中心辦理房屋貸款……並陳報區域中心主管覆核。

    改了第六條，上面兩條都會被列成候選，但只有第十三條該一起看
    （同樣是房貸），第七條是不同業務，不該動。

    前後文看得出這一條在它那一章裡的位置：第十三條前面是個人信用貸款、
    後面是車輛貸款，跟第六條所在的第一章結構平行——這個訊號程式判斷不了，
    但 LLM 看得懂。
    """
    if span <= 0:
        return "", ""
    before = [p.strip() for p in all_paragraphs[max(0, index - span):index]]
    after = [p.strip() for p in all_paragraphs[index + 1:index + 1 + span]]
    return " ／ ".join(x for x in before if x), " ／ ".join(x for x in after if x)


def changed_fragments(old_text, new_text, diff_runs, min_len=2):
    """
    這次修改「加了哪幾段字」。回傳片段清單。

    只取新增的部分。刪除的部分沒辦法拿去別條找——那些字本來就不該存在了。

    片段一律過 _HAS_CONTENT（同檔的 context_fragments 早就這樣做，這裡漏了）：
    只插入「！？」「（）」這種標點也會通過長度檢查變成搜尋詞，拿去搜全文撈回
    一整批毫無關聯的條文，看表的人還得一條一條讀完才知道全部是雜訊。
    """
    if not old_text or not new_text:
        return []
    out = []
    for kind, text in diff_runs(old_text, new_text):
        if kind != "insert":
            continue
        piece = text.strip("，、。；：（）()　 ")
        if len(piece) >= min_len and _HAS_CONTENT(piece):
            out.append(piece)
    return out


# 長句子超過 MAX_FRAGMENT 抽不出詞時，用這幾個標點切成子句再抽（見 deleted_fragments）。
_CLAUSE_SPLIT = re.compile(r"[，、；：]")


def deleted_fragments(old_text, min_len=2, max_terms=6):
    """
    整段被刪掉時沒有新文可比對「這次加了什麼」——changed_fragments(old, old)
    永遠是空的，因為跟自己比對沒有 insert。但這條被刪了，別的章節可能還留著
    同一句沒刪，一樣是漏改，一樣要能搜。

    拿舊文（去條號）切句，每句用既有的 search_terms() 抽詞，取每句前兩個、
    整體去重，湊到 max_terms 個就停。不像 changed_fragments／context_fragments
    那樣有「找不到再退文脈」的退路——沒有新文，文脈搜尋沒有意義。
    """
    body = strip_article_no(old_text or "")
    out = []
    for sentence in split_sentences(body):
        if len(sentence) <= MAX_FRAGMENT:
            clauses = [sentence]
        else:
            # 句子超過 MAX_FRAGMENT 時 search_terms() 本身會直接回 []（見它的長度
            # 篩選），整句一個詞都抽不出來——法規條文常常一句話 50 字以上，這樣
            # 會白跑。先用「，、；：」切成子句，每個子句照樣抽詞；子句本身還是
            # 太長就讓 search_terms() 自然回空，不勉強再往下切，其餘子句仍能貢獻詞。
            clauses = [c for c in _CLAUSE_SPLIT.split(sentence) if c.strip()]
        for clause in clauses:
            for term in search_terms(clause, min_len=min_len)[:2]:
                if term not in out:
                    out.append(term)
                    if len(out) >= max_terms:
                        return out
    return out


def coverage_note(fragments, candidate_body, normalize, synonyms):
    """
    這次新增的那幾段字，候選條文裡有沒有。

    --------------------------------------------------------------------
    為什麼這一項比「業務相不相同」重要
    --------------------------------------------------------------------
    實測過一個會漏判的情境：某條加了「至少五年」的保存期限，
    其他三條分別講信貸、車貸、信用卡——**業務全都不同**，
    但那三條也都寫「並留存電子紀錄」，也都該加保存期限。

    如果照「業務不同就不用改」去篩，這三條會全部被漏掉。

    真正該問的不是「業務同不同」，是「**你這次加的東西，那一條有沒有**」。
    這件事程式量得出來，不必交給判斷。

    回傳三種結果：
        ""              沒有可比的新增內容（例如整條新增、整條刪除）
        "候選也有：…"    候選條文已經有這些內容，多半不用動
        "候選缺少：…"    候選缺這些內容，**這是最該看的一種**
    """
    if not fragments:
        return ""

    body = candidate_body or ""
    body_norm = normalize(body, synonyms)[0] if synonyms else body

    missing, present = [], []
    for piece in fragments:
        piece_norm = normalize(piece, synonyms)[0] if synonyms else piece
        if piece in body or piece_norm in body_norm:
            present.append(piece)
        else:
            missing.append(piece)

    if missing:
        note = "候選缺少：" + "、".join(missing[:5])
        if present:
            note += "（已有：%s）" % "、".join(present[:3])
        return note
    return "候選也有：" + "、".join(present[:5])


# 改動片段開頭常見的連接詞與虛字。這些不是要找的概念，要先剝掉，
# 否則「及火險保單」會拿「及」去搜，全文到處都是。
_LEADING = "及並或暨與且的之其該此本前後另應得須不亦仍即"
_TRAILING = "的之者等"

# 短到沒有辨識力的詞，拿去搜只會製造雜訊。
_TOO_COMMON = set((
    "規定 辦理 作業 事項 相關 有關 應予 予以 得予 本行 本公司 本要點 各款 前項 "
    "前條 該等 情形 方式 內容 資料 文件 紀錄 人員 單位 主管 機關 業務"
).split())


# 條號與款目編號。它們是編號不是概念，留著會讓「一、受託人授權書」
# 拿「一、」去搜，全文到處都是。
_NUMBERING = re.compile(
    r"^\s*(第\s*[零〇一二三四五六七八九十百千兩\d]+\s*[條點項款目章節]"
    r"(\s*之\s*[零〇一二三四五六七八九十百千兩\d]+)?"
    r"|[零〇一二三四五六七八九十百千兩\d]+\s*[、.]"
    r"|[（(]\s*[零〇一二三四五六七八九十百千兩\d]+\s*[）)])\s*")

# 改動片段長到這個程度，就不是「加了一個概念」而是整條改寫或整條新增，
# 那種情況相似度比對本來就抓得到，再用關鍵詞搜只會製造雜訊。
MAX_FRAGMENT = 20


def search_terms(fragment, min_len=2, max_terms=6):
    """
    從一段「這次改動的文字」抽出可以拿去搜的詞。

    只取**前綴與後綴**，不取中間的滑動窗。原因是中文沒有斷詞套件可用，
    中間的窗會切出「險保」這種跨詞碎片。實測用整句抽 n-gram，974 段的內規
    有 319 段命中（33%），完全不能用；只取前後綴就沒有這個問題，
    因為改動片段本身很短，而且是人寫出來的完整概念。

        「及火險保單」→ 剝掉「及」→「火險保單」
          前綴：火險、火險保、火險保單
          後綴：保單、險保單
          （不會產生「險保」這種碎片）

    **原始片段本身排在最前面**（只去編號、去頭尾標點，不剝 _LEADING／_TRAILING）。
    原因（should_fix no 28）：同義詞表（tables/synonyms.json、normalize_terms）是
    整詞比對，剝過頭的詞永遠配不上同義詞。SKILL／reference/02 拿
    「保險費 → 應繳金額」當示範，但

        「應繳金額」→ 剝掉開頭的「應」→「繳金額」

    「繳金額」不在同義詞表裡，於是那個示範反而搜不到「保險費」那幾條。
    先放整詞「應繳金額」就配得上，剝後的前後綴照舊排在它後面當備援。
    """
    stripped = _NUMBERING.sub("", (fragment or "").strip())
    # 原始片段（不剝頭尾虛字），給同義詞整詞比對用
    whole = stripped.strip("，、。；：（）()　 ")
    text = stripped
    while text and text[0] in _LEADING:
        text = text[1:]
    while text and text[-1] in _TRAILING:
        text = text[:-1]
    text = text.strip("，、。；：（）()　 ")

    terms = []
    if min_len <= len(whole) <= MAX_FRAGMENT and whole not in _TOO_COMMON:
        terms.append(whole)
    if not (min_len <= len(text) <= MAX_FRAGMENT):
        return terms[:max_terms]

    for n in range(len(text), min_len - 1, -1):
        for candidate in (text[:n], text[-n:]):
            if candidate not in terms and candidate not in _TOO_COMMON:
                terms.append(candidate)
    return terms[:max_terms]


_SENTENCE_SPLIT = re.compile(r"[。；]")
# 排除純標點片段：原本用列舉標點字元的 _ONLY_PUNCT 反過來擋，但那份列舉不完整
# （像「！？／％」就不在裡面），標點片段照樣會混進去。改成正向判斷——片段裡
# 至少要有一個中文字、數字或英文字母，不然不算「內容」。
_CONTENT_CHAR_RE = re.compile(r"[一-鿿0-9A-Za-z]")


def _HAS_CONTENT(piece):
    """這個片段裡有沒有「內容」（至少一個漢字、數字或英文字母）。

    先過 normalize_for_compare 再判，全形的 Ａ-Ｚ／ａ-ｚ／０-９ 才算得上內容。
    以前直接拿字面比，全形英數條文（「ＡＢＣ級客戶……」）改一個字時抽出來的
    文脈片段會被整批丟掉，find_by_changed_text 回空、連帶條文搜尋整段靜默跳過——
    是漏抓加上沉默，比假陽性危險。
    """
    return bool(_CONTENT_CHAR_RE.search(normalize_for_compare(piece)))


def whole_terms(fragment, min_len=2):
    """whole_only（文脈）模式的搜尋詞：只拿整段片段本身，但一樣過兩道濾網。

    文脈模式以前直接 `[fragment]`，繞過 search_terms 的 _NUMBERING 與
    _TOO_COMMON——程式自己列成「沒有辨識力」的「規定」「辦理」，以及款目編號
    「一、」「(1)」照樣被當搜尋詞拿去撈全文，撈回來的是滿滿的公文套語段落。
    同一支程式對「這個詞有沒有辨識力」不能有兩套標準。
    """
    whole = _NUMBERING.sub("", (fragment or "").strip()).strip("，、。；：（）()　 ")
    if len(whole) < min_len or whole in _TOO_COMMON:
        return []
    return [whole]


# 純數字的片段（全形半形都算）。中文數字不在內：「十五」在「一百十五年」裡是
# 另一個數，但中文數字的邊界要連「百」「千」一起看，規則複雜且誤殺風險高，
# 這裡只處理阿拉伯數字這種一眼看得出邊界的。
_ALL_DIGITS_RE = re.compile(r"^[0-9０-９]+$")
_DIGIT_CLASS = "0-9０-９"


def term_hits(term, text):
    """這個搜尋詞有沒有出現在這一段裡。純數字的詞要看前後邊界。

    子字串比對會讓「15」命中「115年」「150人」——撈回來的條文跟這次改的數字
    毫無關係，而數字正是最需要精準的那一種片段（期限、比率、金額）。
    """
    if not term or not text:
        return False
    if _ALL_DIGITS_RE.match(term):
        pattern = r"(?<![%s])%s(?![%s])" % (_DIGIT_CLASS, re.escape(term), _DIGIT_CLASS)
        return re.search(pattern, text) is not None
    return term in text


_SENTENCE_BOUNDARY = "。；"


@functools.lru_cache(maxsize=20000)
def _split_sentences_cached(text, min_len):
    # 回傳 tuple 不是 list：lru_cache 的快取內容一定要是不可變的，
    # 不然呼叫端改到回傳值會連著改到快取本身。
    return tuple(s.strip() for s in _SENTENCE_SPLIT.split(text or "") if len(s.strip()) >= min_len)


def split_sentences(text, min_len=6):
    """以「。」「；」切句，去頭尾空白，太短的片段不算句子（「其他事項」這種對不出什麼）。

    句子層級比對每個異動段落都要把全文 1,347 段重新切句一次，同一段落在不同
    異動之間會被重算很多次；用 lru_cache 記住結果。公開介面型別不變，仍回傳 list。
    """
    return list(_split_sentences_cached(text, min_len))


def changed_sentences(old_text, new_text, diff_runs, limit=5):
    """
    這次改動落在哪幾句。整段對整段時，改到的那一句會被沒改的 200 字稀釋到門檻以下；
    拿「改到的那一句」去比，長段落裡的同一句才抓得到（真資料 36.6 分 → 90.3 分）。

    新增段：新文的句子（最長前 limit 句）。刪除段：舊文的句子。修改：新文中含插入片段的句子，
    加上刪除片段所在位置對應的新文句子。
    """
    if not new_text:
        return sorted(split_sentences(old_text), key=len, reverse=True)[:limit]
    if not old_text:
        return sorted(split_sentences(new_text), key=len, reverse=True)[:limit]
    positions = []          # 新文裡「有改動」的字元位置
    pos = 0
    for kind, text in diff_runs(old_text, new_text):
        if kind == "insert":
            positions.extend(range(pos, pos + len(text)))
        elif kind == "delete":
            positions.append(min(pos, max(len(new_text) - 1, 0)))
        if kind != "delete":
            pos += len(text)
    if not positions:
        return []
    out = []
    start = 0
    for piece in _SENTENCE_SPLIT.split(new_text):
        end = start + len(piece)
        sentence = piece.strip()
        if len(sentence) >= 6 and any(start <= p <= end for p in positions) and sentence not in out:
            out.append(sentence)
        start = end + 1          # 補回被切掉的標點
    return out[:limit]


def context_fragments(old_text, new_text, diff_runs, width=4, min_len=2):
    """
    改動處左右各 width 字。一字之差（五→七）沒有片段可搜，「約期滿後」「定之日起」才搜得到別處的同一句。

    左右視窗都不跨句界（「。」「；」）：跨過去的片段（例如「項作業。」）在別的段落
    幾乎不可能整段再出現一次，尤其 whole_only 模式下等於永遠比不到，不如乾脆不取。
    片段被句界削到比 min_len 短就整段丟棄，不會留下沒有意義的殘片。

    delete 後面緊接 insert 時（一般的「取代」），delete 那一步的右視窗會從 pos
    開始算，但 pos 還沒跳過緊接在後的新字——算出來的右視窗會混進剛插入的字，
    不是真正的「原本的下文」。這種情況下略過 delete 的右視窗，交給後面那步
    insert（它的右視窗會正確地從插入文字之後算起）去取。
    """
    out = []
    pos = 0
    runs = list(diff_runs(old_text or "", new_text or ""))
    for idx, (kind, text) in enumerate(runs):
        if kind in ("insert", "delete"):
            left = (new_text or "")[max(0, pos - width):pos]
            # 左視窗只留最後一個句界之後的部分，不跨到前一句
            boundary = max(left.rfind(ch) for ch in _SENTENCE_BOUNDARY)
            if boundary != -1:
                left = left[boundary + 1:]
            pieces = [left]
            skip_right = (kind == "delete" and idx + 1 < len(runs)
                         and runs[idx + 1][0] == "insert")
            if not skip_right:
                right_start = pos + (len(text) if kind == "insert" else 0)
                right = (new_text or "")[right_start:right_start + width]
                # 右視窗只留第一個句界之前的部分，不跨到下一句
                cuts = [i for i in (right.find(ch) for ch in _SENTENCE_BOUNDARY) if i != -1]
                if cuts:
                    right = right[:min(cuts)]
                pieces.append(right)
            for piece in pieces:
                piece = piece.strip()
                if len(piece) >= min_len and _HAS_CONTENT(piece) and piece not in out:
                    out.append(piece)
        if kind != "delete":
            pos += len(text)
    return out


def find_by_sentence(changed, all_paragraphs, threshold=DEFAULT_SENTENCE_THRESHOLD, top=DEFAULT_TOP,
                     exclude_index=None, contexts=None, synonyms=None):
    """
    拿改到的那幾句，去跟全文每一段的每一句比，取每段最高分。回傳 dict 列，依分數排序。

    分數用去掉條號後的句子算（同 find_duplicates 的整段比對）。句子本身可能是段落
    第一句、帶著開頭的條號（「第三百二十七條 ……」），三個內文一模一樣、只有條號不同
    的候選不去掉條號會各自扣掉不一樣的分數（84.6／83.6／92.9），變成看條號長得像不像，
    不是看內容像不像。顯示用的 matched_sentence／changed_sentence 仍保留原文（含條號）。
    """
    changed = [s for s in (changed or []) if s]
    if not changed:
        return []
    syn_key = tuple(synonyms or [])
    changed_norm = [(_normalize_cached(strip_article_no(s), syn_key), s) for s in changed]
    hits = []
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        best = None
        for sentence in split_sentences(paragraph):
            sentence_norm, sentence_applied = _normalize_cached(strip_article_no(sentence), syn_key)
            for (c_norm, c_applied), c_raw in changed_norm:
                score = calc_similarity(c_norm, sentence_norm)
                if score >= threshold and (best is None or score > best[0]):
                    best = (score, sentence, c_raw, c_applied, sentence_applied)
        if best is None:
            continue
        score, sentence, c_raw, c_applied, sentence_applied = best
        context = contexts[idx] if contexts else None
        hits.append({
            "line_number": line_no,
            "article_no": (context["ref"] if context else "") or extract_article_no(paragraph),
            "scope": format_scope(context),
            "text": paragraph,
            "sentence_score": round(score, 1),
            "matched_sentence": sentence,
            "changed_sentence": c_raw,
            "synonym_evidence": synonym_evidence(set(c_applied), set(sentence_applied),
                                                 c_raw, sentence, synonyms or []),
        })
    hits.sort(key=lambda h: h["sentence_score"], reverse=True)
    return hits[:top] if top and top > 0 else hits


SENTENCE_COLUMNS = ["異動條號", "改動所在句", "候選章節", "候選條號", "候選段次",
                    "候選句", "句分數", "候選條文", "經同義詞比對"]


def write_sentence_csv(rows, output_path):
    """句子層級候選另存一份（分步流程／測試用；單次執行走 write_candidate_workbook）。"""
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(SENTENCE_COLUMNS)
        for row in rows:
            writer.writerow(row)
    print("已產生句子層級候選：%s" % output_path)


def find_by_changed_text(fragments, all_paragraphs, exclude_index=None,
                         contexts=None, synonyms=None, normalize=None,
                         extract_article_no=None, format_scope=None,
                         top=10, max_ratio=0.05, whole_only=False):
    """
    拿「這次改動的那幾個字」去搜全文，而不是拿整條去比相似度。

    --------------------------------------------------------------------
    為什麼整條比對不夠
    --------------------------------------------------------------------
    整條對整條時，分數被「沒改到的部分」主導，而那部分往往就是公文套語。
    真正該找的是改動涉及的概念在哪裡還有出現。

    實測：第六條加了「及火險保單」。同一份內規裡有

        第四十條　本行辦理擔保放款，應確認擔保品已投保火險……
        第四十一條　擔保品之保險單正本應由本行收執……

    這兩條講的就是火險與保單，直接相關。但整條比對只有 26.5 分與 16.7 分，
    在 45 分門檻下**一條都抓不到**。改用改動文字去搜就找得到。

    回傳依「命中的詞多長」排序——命中越長的詞，關聯越明確。

    whole_only：True 時每個片段只拿整段本身當詞，不拆 search_terms() 的前後綴子詞
    （一樣經過 distinctive() 篩選）。改動處左右文脈通常只有 4 個字，拆出來的
    2 字子詞（如「定之」）辨識力低，命中的多半是不相干的套語段落。
    """
    if not fragments:
        return []

    # 在全文命中太多段的詞，本身就沒有辨識力（「受託」「三十」這種），
    # 留著只會把整份文件都撈出來。用資料自己算，不用手工黑名單。
    limit = max(3, int(len(all_paragraphs) * max_ratio))

    # 分母要跟 search_terms 對齊：search_terms 一開頭就把條號剝掉，這裡卻拿含條號的
    # 原文去數，於是「三十」被第三十條、第三十一條、第三十二條……的條號灌爆，
    # 判成「沒有辨識力」而整組搜尋詞被丟掉——中文數字的片段幾乎一定活不下來，
    # 而期限、比率這類最該追的異動，片段正好就是數字。
    bodies = [strip_article_no(p) for p in all_paragraphs]

    def distinctive(term):
        hits = 0
        for body in bodies:
            if term_hits(term, body):
                hits += 1
                if hits > limit:
                    return False
        return True

    term_sets = []
    for fragment in fragments:
        terms = whole_terms(fragment) if whole_only else search_terms(fragment)
        terms = [t for t in terms if distinctive(t)]
        if terms:
            term_sets.append((fragment, terms))
    if not term_sets:
        return []

    hits = []
    syn_key = tuple(synonyms or [])
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        # 比對也用剝掉條號的本文，跟 distinctive() 的分母同一把尺（B6）：
        # 用整段比，「三十」會命中第三十～三十七條的條號，真正的候選被擠出前幾名
        body = bodies[idx]
        if normalize and synonyms:
            body_norm = (_normalize_cached(body, syn_key)[0]
                         if normalize is normalize_terms else normalize(body, synonyms)[0])
        else:
            body_norm = body

        matched = []
        for fragment, terms in term_sets:
            for term in terms:
                term_norm = (normalize(term, synonyms)[0]
                             if (normalize and synonyms) else term)
                if term_hits(term, body) or term_hits(term_norm, body_norm):
                    matched.append((fragment, term))
                    break        # 每個改動片段只記最長的那一個命中
        if not matched:
            continue

        context = contexts[idx] if contexts else None
        hits.append({
            "line_number": line_no,
            "article_no": ((context["ref"] if context else "")
                           or (extract_article_no(paragraph)
                               if extract_article_no else "")),
            "scope": format_scope(context) if format_scope else "",
            "text": paragraph,
            "matched": matched,
            "strength": max(len(term) for _, term in matched),
        })

    hits.sort(key=lambda h: (h["strength"], -h["line_number"]), reverse=True)
    return hits[:top] if top and top > 0 else hits

def hit_label(article_no, line_number):
    """畫面上的定位標籤：有條號寫「第五條（第16段）」，沒有條號只寫「第16段」。

    條號欄空的時候 label 本來就退回「第N段」，格式字串再固定補一次括號，
    無條號的作業手冊型文件整份印成「第16段（第16段）」——同一個座標印兩次，
    看的人會先以為那是兩個不同的數字，再花時間確認它們是同一個。
    """
    if article_no:
        return "%s（第%d段）" % (article_no, line_number)
    return "第%d段" % line_number


def scoped_label(scope, article_no, line_number):
    """章節＋定位標籤。條號本身已經帶著章節（「第二章第三款」）時不再前面補一次章節，
    不然畫面印成「第二章 第二章第三款」，看起來像程式把章節算錯了。"""
    label = hit_label(article_no, line_number)
    if not scope:
        return label
    if article_no and re.sub(r"\s+", "", article_no).startswith(re.sub(r"\s+", "", scope)):
        return label
    return "%s %s" % (scope, label)


def print_changed_text_hits(fragments, hits):
    """把「拿改動文字去搜」的結果印出來，跟相似度候選分開列。"""
    if not fragments:
        return
    print("")
    print("── 以這次改動的文字搜尋全文 ──")
    # 這幾段是「改動處前後的字」拿去搜的搜尋詞，不是完整的詞，所以一段一段框起來，
    # 不要用頓號連成一串（以前印「改動片段：人員應於、日內將招」，看起來像一句壞掉的話）
    print("   用改動處前後的字去搜：%s" % "".join("「%s」" % f for f in fragments))
    if not hits:
        print("   全文沒有其他條文提到這些內容。")
        return
    print("   %d 條提到相同內容（整條相似度可能很低，但概念直接相關）：" % len(hits))
    for hit in hits:
        label = scoped_label(hit["scope"], hit["article_no"], hit["line_number"])
        terms = "".join("「%s」" % term for _, term in hit["matched"])
        print("   [%s] 命中%s" % (label, terms))
        print("      %s" % hit["text"])

def describe_difference(changed_body, candidate_body, diff_runs,
                        limit=8, pad=4):
    """
    兩條相似條文「差在哪」，逐處列出，格式是 `……〔異動→候選〕……`。

    這一項直接回答「這是漏改，還是兩個作業的層級本來就不同」：

        受理後〔三→五〕日內　　　　　　異動寫三日，候選寫五日
        〔分行經理→區域中心主管〕覆核　核准層級不同
        鑑價報告〔及火險保單→無〕，並　異動有、候選沒有

    看到只有層級用詞在變，人一眼就知道那是刻意分級；看到業務名稱也在變，
    就知道那兩條本來講的就不是同一件事。

    --------------------------------------------------------------------
    為什麼要帶前後幾個字
    --------------------------------------------------------------------
    早期版本只把兩邊各自獨有的文字列出來，而且「少於兩個字就跳過」——
    本意是去掉標點雜訊，結果把訊號一起丟了。實測這幾種差異全部顯示成空白：

        三日 vs 五日　　　　　　（期間）
        不得 vs 得　　　　　　　（責任用語）
        一百萬元 vs 三百萬元　　（金額）

    差異欄空白會讓人以為兩條一模一樣，那比不顯示更糟。
    現在一個字的差異也照列，靠前後各借幾個字讓它讀得懂。

    limit：最多列幾處差異；超過會明講還有幾處，不會安靜截斷。
    pad：每處差異前後各借幾個相同的字當脈絡。
    """
    # 方向固定是「異動條文 → 候選條文」。反過來寫的話，〔區域中心→分行〕
    # 會被讀成「變成」，但候選條文不是舊版、是另一條條文，那樣讀是錯的。
    parts = diff_runs(changed_body or "", candidate_body or "")

    # 先整理成交錯的「相同／差異」兩種塊
    items = []
    for kind, text in parts:
        if kind == "equal":
            items.append(("equal", text))
            continue
        if not items or items[-1][0] != "diff":
            items.append(("diff", [], []))
        # 只有異動條文有的字進左邊，只有候選條文有的字進右邊
        (items[-1][1] if kind == "delete" else items[-1][2]).append(text)
    diffs = [k for k, item in enumerate(items) if item[0] == "diff"]
    if not diffs:
        return ""

    def body(item):
        chg, cand = "".join(item[1]), "".join(item[2])
        # 一律寫成〔異動→候選〕。缺的那一邊寫「無」，不用 ＋／－ 符號，
        # 那兩個符號在這裡容易被讀反。
        return "〔%s→%s〕" % (chg or "無", cand or "無")

    def equal_at(k):
        return items[k][1] if 0 <= k < len(items) and items[k][0] == "equal" else ""

    # 兩處差異中間隔的字不多時照原文接起來，不各自帶前後字再用空白隔開：
    # 以前寫成「〔無→財產保險〕業務人員　人員應於〔五→三〕日內將招」，
    # 「業務人員」「人員應於」其實是同一串字被印了兩次，看起來像條文有錯。
    # 隔得遠的才切開，中間用「…」表示省略。
    shown = diffs[:limit]
    out = [equal_at(shown[0] - 1)[-pad:]]
    for n, k in enumerate(shown):
        if n:
            gap = equal_at(k - 1)
            out.append(gap if len(gap) <= 2 * pad else gap[:pad] + "…" + gap[-pad:])
        out.append(body(items[k]))
    out.append(equal_at(shown[-1] + 1)[:pad])
    text = "".join(out)
    if len(diffs) > limit:
        # 截斷要講出來。安靜截斷會讓人以為只有這幾處不同。
        text += "　（另有 %d 處差異未列出）" % (len(diffs) - limit)
    return text


@functools.lru_cache(maxsize=50000)
def _normalize_cached(text, syn_key):
    """normalize_terms 的快取版。目標段落的正規化只跟段落與詞表有關，卻在每個異動、
    每個來源本都重算一次（10 個異動 × 1,350 段 × 94 組詞 ≈ 127 萬次子字串比對）。
    syn_key 是 tuple(synonyms)，同一份詞表在整個 process 裡是同一個 key。
    回傳 (正規化文字, frozenset(代表詞))；frozenset 是為了不讓呼叫端改到快取內容。"""
    text_norm, applied = normalize_terms(text, list(syn_key))
    return text_norm, frozenset(applied)


def find_duplicates(changed_text, all_paragraphs, threshold=DEFAULT_THRESHOLD,
                    top=DEFAULT_TOP, exclude_index=None, contexts=None,
                    synonyms=None, context_span=DEFAULT_CONTEXT,
                    changed_old_text=None, is_deleted=False):
    """
    拿修改過的文字去跟全文每一段比，回傳超過門檻的候選清單。

    exclude_index：要跳過的段次(從 1 起算)，通常就是被修改的那一段自己。
    沒指定的話，退而求其次跳過「文字完全相同」的段落。

    is_deleted：這一處異動是「整條刪除」。刪掉的那一段在新版全文裡已經不存在，
    自然也就沒有 exclude_index 可以給——於是上面那條「沒指定就跳過文字完全相同
    的段落」的退路會反過來咬人：整條刪除最該抓的就是別章那個一字不差的孿生條
    （壽險章刪了、產險章忘了刪），它偏偏就是唯一一個「文字完全相同」的段落，
    被當成「那是它自己」跳掉，這個功能對刪除型異動等於整個失效。
    所以刪除型一律不跳文字相同的段落——孿生條就是要找的東西本身。

    contexts：build_hierarchy() 算出的層級脈絡。有給的話，候選的條號會寫成
    「第三十三條第二款第二目」而不是只有「(二)」——候選清單是要拿去人工核對的，
    寫「(二)」等於叫人在 50 頁裡自己找。

    synonyms：同義詞表。有給的話，比對前先把「應繳金額」這類變體收斂成
    「保險費」，才抓得到用詞完全換掉的重複條文（實測 34 分拉到 56 分）。
    每一筆候選會一併記錄是哪一組詞讓它配對上的——不能只給分數不給理由。
    """
    changed_body = strip_article_no(changed_text)
    # 這次「加了哪幾段字」。拿去每個候選裡找，找不到的就是最該看的那幾條。
    added = changed_fragments(strip_article_no(changed_old_text or ""),
                              changed_body, _diff_runs)
    changed_norm, changed_applied = normalize_terms(changed_body, synonyms)
    syn_key = tuple(synonyms or [])

    candidates = []
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        if exclude_index is None and not is_deleted and paragraph == changed_text:
            continue

        paragraph_body = strip_article_no(paragraph)
        paragraph_norm, paragraph_applied = _normalize_cached(paragraph_body, syn_key)

        # 分數一律用正規化後的文字算。沒有同義詞命中時，正規化後就等於原文，
        # 分數也就等於純字面比對，不會憑空灌水。
        score = calc_similarity(changed_norm, paragraph_norm)
        if score >= threshold:
            # 分數用正規化後的文字算，但「共同片段」一定要用原文算。
            # 正規化會把「停止效力」換成代表詞「終止」，拿正規化後的片段去顯示，
            # 人工複核時把那段字複製到文件裡搜尋會完全找不到——
            # 一個叫人去核對的工具，給的線索必須是文件裡真的有的字。
            fragment, position = longest_common_fragment(changed_body, paragraph_body)
            context = contexts[idx] if contexts else None
            evidence = synonym_evidence(changed_applied, paragraph_applied,
                                        changed_body, paragraph_body,
                                        synonyms or [])
            candidates.append({
                "line_number": line_no,
                "article_no": ((context["ref"] if context else "")
                               or extract_article_no(paragraph)),
                "scope": format_scope(context),
                "text": paragraph,
                "similarity": round(score, 1),
                "common_fragment": fragment,
                "fragment_len": len(fragment),
                "fragment_position": position,
                "synonym_evidence": evidence,
                # 前後文與「差在哪」：光看分數分不出「漏改」與「層級本來就不同」，
                # 這兩項是給 LLM 判斷用的材料，不是給程式判斷的。
                "context_before": neighbours(all_paragraphs, idx, context_span)[0],
                "context_after": neighbours(all_paragraphs, idx, context_span)[1],
                "difference": describe_difference(changed_body, paragraph_body,
                                                  _diff_runs),
                # 比「業務同不同」更關鍵：這次加的字，這一條有沒有
                "coverage": coverage_note(added, paragraph_body,
                                          normalize_terms, synonyms),
            })

    # 排序以相似度為主。同分時，共同片段從句首開始的排前面——實測顯示真正的
    # 重複條文都在這一類，非句首的則全是套語假陽性。
    candidates.sort(
        key=lambda c: (c["similarity"],
                       1 if c.get("fragment_position") == "句首" else 0,
                       c["fragment_len"]),
        reverse=True)
    return candidates[:top] if top and top > 0 else candidates


def print_candidates(changed_text, candidates, threshold):
    """把候選清單印出來。"""
    head = changed_text if len(changed_text) <= 40 else changed_text[:40] + "…"
    print("\n" + "=" * 60)
    print("修改段落：%s" % head)
    print("=" * 60)

    if not candidates:
        print("沒有找到相似度超過 %.0f%% 的候選條文。" % threshold)
        print("若你認為別的章節應該有對應條文，可以試著 --threshold 35 再跑一次。")
        return

    print("共 %d 筆候選（依相似度排序）：\n" % len(candidates))
    for i, c in enumerate(candidates, 1):
        label = scoped_label(c.get("scope"), c["article_no"], c["line_number"])
        position = c.get("fragment_position", "")
        # 「多半是公文套語」這句話會叫人跳過這一筆。分數已經很高時這樣講是錯的，
        # 而且錯在整份報告最重要的那一筆上。分數低時它才是有效的排除訊號。
        if position == "句首":
            hint = ""
        elif c["similarity"] >= HIGH_CONFIDENCE:
            hint = "（%s起，但整段相似度高，要細看）" % position
        else:
            hint = "（%s起，多半是公文套語）" % position
        print("[候選%d] 相似度 %.1f%% ｜ %s｜ 共同片段 %d 字%s：%s"
              % (i, c["similarity"], label, c["fragment_len"], hint, c["common_fragment"]))
        print("  內容：%s" % c["text"])
        if c.get("coverage"):
            print("  這次加的字：%s" % c["coverage"])
        if c.get("context_before"):
            print("  前一段：%s" % c["context_before"][:60])
        if c.get("context_after"):
            print("  後一段：%s" % c["context_after"][:60])
        if c.get("difference"):
            # 「差在哪」直接回答「這是漏改，還是兩個作業的層級本來就不同」
            print("  兩條的差異：%s" % c["difference"])
        if c.get("synonym_evidence"):
            # 一定要說明是哪一組詞讓它配對上的。法遵場合要能回答
            # 「為什麼系統認為這兩條相關」，只給分數不給理由沒有用。
            print("  經同義詞比對：%s" % "、".join(c["synonym_evidence"]))
        print()


CHANGED_TEXT_COLUMNS = ["異動條號", "修改類型", "異動段全文", "這次改動的片段",
                        "關聯章節", "關聯條號", "關聯段次", "關聯條文",
                        "命中的詞", "是否一併修改（人工填寫）", "搜尋方式",
                        # 最後一欄：帶出這一列的那一處異動在哪一段（新增／修改寫
                        # 「N」，刪除寫「舊版 N」）。決定表要靠它才不會拿共用的
                        # 條號去查表，把別章那處異動的段次也一起帶進來。
                        "異動段次"]


def write_changed_text_csv(rows, output_path):
    """「以改動文字搜尋全文」的結果，另存一份，不跟相似度候選混在一起。

    第 3 欄以前叫「異動後文字」，但刪除型的異動在新版全文裡已經不存在，那一欄
    放的其實是**舊版原文**——欄名說「異動後」，內容卻是異動前，看表的人會以為
    這條還在。改叫「異動段全文」（就是這一處異動那一段的全文），並在前面補一欄
    「修改類型」，讓人一眼看出這一欄該當成新文還是舊文讀。
    """
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(CHANGED_TEXT_COLUMNS)
        for row in rows:
            writer.writerow(row)
    print("已產生異動文字關聯條文：%s" % output_path)


CANDIDATE_COLUMNS = ["修改段落條號", "修改類型", "異動段全文", "候選章節", "候選條號",
                     "候選段次", "候選條文", "相似度", "最長共同片段字數",
                     "片段位置", "最長共同片段", "經同義詞比對",
                     "這次加的字在候選有沒有", "兩條的差異（異動→候選）",
                     "候選前一段", "候選後一段",
                     "是否一併修改（人工填寫）",
                     # 最後一欄，理由同 write_changed_text_csv
                     "異動段次"]

# 候選明細.xlsx 的三張工作表：名字就是以前那三個 CSV 的檔名（去副檔名），
# 人照舊認得出哪一張是哪一件事；退成 csv 時檔名還原成
# 候選明細_重複條文候選清單.csv 之類，跟舊檔名對得起來。
CANDIDATE_SHEETS = ("重複條文候選清單", "異動文字關聯條文", "句子相似候選")


def write_candidate_workbook(base_path, csv_rows, changed_rows, sentence_rows,
                             path_for=None):
    """三種候選寫成一份 候選明細（.xlsx 三張工作表；寫不出來才退三個 .csv）。

    以前是三個各自獨立的 CSV。人拿到產出資料夾要一個一個開，而且只有有資料的
    那幾個檔會出現——「句子相似候選.csv 不在」到底是「這次沒有」還是「這一步
    沒跑」，從資料夾看不出來。併成一份、沒資料的工作表只留表頭，兩者就分得開。

    base_path 不帶副檔名。回傳實際寫出的路徑清單。
    """
    sheets = [
        (CANDIDATE_SHEETS[0], CANDIDATE_COLUMNS, csv_rows or []),
        (CANDIDATE_SHEETS[1], CHANGED_TEXT_COLUMNS, changed_rows or []),
        (CANDIDATE_SHEETS[2], SENTENCE_COLUMNS, sentence_rows or []),
    ]
    written = xw.write_tables_or_csv(base_path, sheets, source="Step 2 候選",
                                     path_for=path_for)
    for path in written:
        # display_path：走 AtomicWrites 時收到的是「正式路徑 + .tmp」，
        # 印原樣會叫人去找一個 候選明細.xlsx.tmp，那個檔案不會留下來。
        print("已產生候選明細：%s" % display_path(path))
    return written


def write_candidates_csv(rows, output_path):
    """把所有修改段落的候選清單寫成一份 CSV，方便逐筆勾選。

    第 3 欄以前叫「修改後文字」，理由同 write_changed_text_csv：刪除型的異動沒有
    「修改後」，那一欄放的是舊版原文。改叫「異動段全文」並補「修改類型」欄。
    """
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(CANDIDATE_COLUMNS)
        for row in rows:
            writer.writerow(row)
    print("\n已產生候選清單：%s" % output_path)


def search_keyword(all_paragraphs, phrase, contexts=None, synonyms=None):
    """
    直接找「含有這個詞」的所有條文。給人指定關鍵詞用。

    --------------------------------------------------------------------
    為什麼需要這條路
    --------------------------------------------------------------------
    相似度比對有一個抓不到的區間：條文被大幅改寫、跟原文幾乎沒有共同字時，
    分數會掉到門檻以下，候選清單裡根本不會出現。實測「契約效力之停止，
    以要保人未於約定期日前完成保險費繳付為要件」對上原句只有 40 分，
    在 45 分門檻下抓不到，同義詞表也救不回來。

    試過用「關鍵詞自動重疊」補這一段，實測不可行：中文沒有斷詞套件可用，
    字元 n-gram 會切出「保人」「險費」這種碎片，974 段的內規裡有 319 段
    命中（33%），等於沒有過濾。

    可行的做法是**讓人指定關鍵詞**。法遵知道自己這次改的是「保存期限」，
    直接搜「留存」就好——人選的詞不會有雜訊問題，而且結果完全可預期。
    """
    hits = []
    phrase = (phrase or "").strip()
    if not phrase:
        return hits
    normalized = normalize_terms(phrase, synonyms)[0] if synonyms else phrase

    for idx, paragraph in enumerate(all_paragraphs):
        body = strip_article_no(paragraph)
        body_norm = normalize_terms(body, synonyms)[0] if synonyms else body
        if phrase not in body and normalized not in body_norm:
            continue
        context = contexts[idx] if contexts else None
        hits.append({
            "line_number": idx + 1,
            "article_no": ((context["ref"] if context else "")
                           or extract_article_no(paragraph)),
            "scope": format_scope(context),
            "text": paragraph,
            "matched_by": "原詞" if phrase in body else "同義詞正規化後",
        })
    return hits


def print_keyword_hits(phrase, hits):
    """把關鍵詞搜尋的結果印出來。"""
    print("")
    print("=" * 60)
    print("關鍵詞搜尋：%s" % phrase)
    print("=" * 60)
    if not hits:
        print("全文找不到含這個詞的條文。")
        print("換個說法再試一次，或確認這個詞在內規裡實際怎麼寫。")
        return
    print("共 %d 條含這個詞：" % len(hits))
    print("")
    for hit in hits:
        label = scoped_label(hit["scope"], hit["article_no"], hit["line_number"])
        print("[%s] %s" % (label, hit["matched_by"]))
        print("  %s" % hit["text"])
        print("")
    print("提醒：這是「含有這個詞」的完整清單，不是相似度比對。")
    print("      改寫幅度大、字面不像的條文，只有這種搜法找得到。")

def _read_change_table(path):
    """修正對照表讀成 list[dict]（第一列是欄名）。.xlsx 與 .csv 都收。

    Step 1 的對照表從 CSV 改成 XLSX 之後，分步流程的
    `--from-csv 修正對照表.xlsx` 還是要讀得回來；使用者手上留著舊的 .csv
    （或 xlsx 寫不出來退成 csv 的那一份）也照樣能跑。
    """
    if str(path).lower().endswith(".xlsx"):
        try:
            return read_xlsx_dicts(path, "修正對照表")
        except ValueError:
            # 工作表不叫這個名字（別的工具產的、或使用者自己另存的）就讀第一張，
            # 欄名一樣對得上就還是讀得到——這一步寧可多試一次也不要整條空跑。
            return read_xlsx_dicts(path)
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def load_changes_from_csv(csv_path, table_format=None):
    """
    從 Step 1 產出的「修正對照表」（.xlsx 或 .csv）讀出所有修改段落。

    只取「新增」跟「修改」兩類：這兩類在新版全文裡有對應文字，可以拿去比對。
    「刪除」類在新版全文裡已經不存在，改用它的原文去比，找出「這條刪了，
    但別章還留著同樣的規定沒刪」的情況——這種漏刪一樣是法規風險。
    """
    # 對照表的欄位標題是可以在 對照表格式.json 改的（「原文」可以印成「原條文」），
    # 所以不能照字面去 row["修改後文字"] 取值——各單位改個標題這一步就讀不到了。
    # 對應來源有兩個：呼叫端傳進來的設定（產這份 CSV 時用的那一份，最準），
    # 以及預設設定。都對不上時還有內部鍵本身當備援。
    title_to_key = {}
    for source in (table_format, load_table_format()):
        for column in (source or {}).get("欄位", []):
            if column.get("標題") and column.get("鍵"):
                title_to_key.setdefault(column["標題"], column["鍵"])

    changes = []
    found_text = False
    for row in _read_change_table(csv_path):
        values = {}
        for header, value in row.items():
            if header is None:
                continue
            values[title_to_key.get(header, header)] = value

        change_type = (values.get("修改類型") or "").strip()
        # 「僅字形／空白差異」列在對照表上只是要讓人看見，內容沒有變，
        # 不該進候選比對——跟單次執行版的 step_duplicates 同一條規則。
        if change_type == COSMETIC_LABEL:
            continue
        if change_type == "刪除":
            text = (values.get("原文") or "").strip()
            line_no = None
        else:
            text = (values.get("修改後文字") or "").strip()
            raw_line = (values.get("新版段次") or "").strip()
            line_no = int(raw_line) if raw_line.isdigit() else None

        if not text or text.startswith("（無"):
            continue
        found_text = True
        changes.append({
            "article_no": (values.get("條號") or "").strip(),
            "type": change_type,
            "text": text,
            # 舊版原文：用來算出「這次加了哪幾段字」
            "old_text": (values.get("原文") or "").strip(),
            "line_number": line_no,
        })

    # 一筆都讀不到有兩種可能：這次真的沒有異動，或是欄位標題被改過而對不上。
    # 後者最危險——整條流程會在最重要的一步安靜地跳過去，畫面上什麼都不會說。
    if not found_text and not changes:
        print("提醒：從 %s 讀不到任何異動段落。" % os.path.basename(csv_path))
        print("      若這份對照表的欄位標題有改過，請用 --format 指定當初產生它的")
        print("      設定檔（例如 --format tables/對照表格式.json），否則這一步會空跑。")
    return changes


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="Step 2：跨章節重複條文抓取（模糊字串比對）")
    parser.add_argument("regulation_file",
                        help="【新版】內規全文檔案（.docx / .txt / .md）")
    parser.add_argument("changed_text", nargs="?", default=None,
                        help="你修改後的那段文字；也可以改用 --changed-line 或 --from-csv")
    parser.add_argument("--changed-line", type=int, default=None,
                        help="修改段落在新版全文裡的段次（Step 1 的 CSV「新版段次」欄）")
    parser.add_argument("--from-csv", default=None,
                        help="Step 1 產出的 修正對照表.xlsx（舊的 .csv 也收），一次比對所有修改段落")
    parser.add_argument("--keyword", default=None,
                        help="直接列出全文所有含這個詞的條文。"
                             "用在相似度抓不到的地方：條文被大幅改寫、"
                             "跟原文幾乎沒有共同字時，改用人指定的關鍵詞去找")
    parser.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD,
                        help="相似度門檻 0~100，預設 %g" % DEFAULT_THRESHOLD)
    parser.add_argument("--top", type=int, default=DEFAULT_TOP,
                        help="每個修改段落最多列幾筆候選，預設 %d，設 0 表示全部列出" % DEFAULT_TOP)
    parser.add_argument("--synonyms", default=None,
                        help="同義詞表路徑，預設用 tables/synonyms.json")
    parser.add_argument("--no-synonyms", action="store_true",
                        help="關閉同義詞正規化，只做純字面比對")
    parser.add_argument("--context", type=int, default=DEFAULT_CONTEXT,
                        help="候選條文附帶前後各幾段，預設 %d；設 0 表示不附"
                             % DEFAULT_CONTEXT)
    parser.add_argument("--format", default=None,
                        help="產生這份對照表時用的版面設定檔；欄位標題改過的話要指定")
    parser.add_argument("--outdir", default="", help="輸出資料夾，預設為目前目錄")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    synonyms = [] if args.no_synonyms else load_synonyms(args.synonyms)
    if synonyms:
        print("已載入同義詞表：%d 組變體" % len(synonyms))
    else:
        print("未使用同義詞表，只做純字面比對。")

    if not HAS_RAPIDFUZZ:
        print("提醒：沒有安裝 rapidfuzz，改用內建 difflib（結果相近，大檔案會慢一些）。")
        print("      要加速請執行：python check_env.py\n")

    print("正在讀取新版內規全文：%s" % args.regulation_file)
    all_paragraphs, kinds = read_paragraphs_with_kinds(args.regulation_file)
    contexts = build_hierarchy(all_paragraphs, kinds)
    print("全文共 %d 段。" % len(all_paragraphs))

    # 關鍵詞模式：不做相似度比對，直接列出含這個詞的條文
    if args.keyword:
        hits = search_keyword(all_paragraphs, args.keyword,
                              contexts=contexts, synonyms=synonyms)
        print_keyword_hits(args.keyword, hits)
        return hits

    # 決定要比對哪些段落
    if args.from_csv:
        changes = load_changes_from_csv(
            args.from_csv,
            table_format=load_table_format(args.format) if args.format else None)
        if not changes:
            raise SystemExit("錯誤：%s 裡沒有讀到任何修改段落，請確認這是 Step 1 產出的對照表。"
                             % args.from_csv)
        print("從對照表讀到 %d 個修改段落，逐一比對（門檻 %.0f%%）..."
              % (len(changes), args.threshold))
    elif args.changed_line is not None:
        if not (1 <= args.changed_line <= len(all_paragraphs)):
            raise SystemExit("錯誤：--changed-line %d 超出範圍，全文只有 %d 段。"
                             % (args.changed_line, len(all_paragraphs)))
        text = all_paragraphs[args.changed_line - 1]
        changes = [{"article_no": extract_article_no(text), "type": "修改",
                    "text": text, "line_number": args.changed_line}]
    elif args.changed_text:
        changes = [{"article_no": extract_article_no(args.changed_text), "type": "修改",
                    "text": args.changed_text, "line_number": None}]
    else:
        raise SystemExit(
            "錯誤：要指定修改了哪一段。三選一：\n"
            "  直接貼文字   python fuzzy_duplicate_finder.py 新版全文.docx \"第三條 ……\"\n"
            "  指定段次     python fuzzy_duplicate_finder.py 新版全文.docx --changed-line 4\n"
            "  整份跑完     python fuzzy_duplicate_finder.py 新版全文.docx --from-csv 修正對照表.xlsx")

    csv_rows = []
    total_candidates = 0
    for change in changes:
        candidates = find_duplicates(
            change["text"], all_paragraphs,
            threshold=args.threshold, top=args.top,
            exclude_index=change["line_number"], contexts=contexts,
            synonyms=synonyms, context_span=args.context,
            changed_old_text=change.get("old_text"),
            # 對照表讀進來的「修改類型」是刪除的話，那一段在新版全文裡已經不見了，
            # 一字不差的孿生條才是要找的東西，不能當成「它自己」跳掉
            is_deleted=(change.get("type") == "刪除"))
        total_candidates += len(candidates)
        print_candidates(change["text"], candidates, args.threshold)
        for c in candidates:
            csv_rows.append([
                change["article_no"], change.get("type") or "", change["text"],
                c.get("scope", ""), c["article_no"], c["line_number"], c["text"],
                c["similarity"], c["fragment_len"],
                c.get("fragment_position", ""), c["common_fragment"],
                "、".join(c.get("synonym_evidence", [])),
                c.get("coverage", ""), c.get("difference", ""),
                c.get("context_before", ""), c.get("context_after", ""), "",
                # 這條路（--from-csv）是從修正對照表讀進來的，沒有段次可寫；
                # 補一格空字串，CSV 才不會少一欄變成參差不齊的表
                "",
            ])

    if csv_rows:
        base = os.path.splitext(
            resolve_output(args.outdir, args.prefix, "候選明細.xlsx"))[0]
        write_candidate_workbook(base, csv_rows, [], [])

    print("\n" + "-" * 60)
    print("比對完成：%d 個修改段落，候選：整段相似 %d 筆。"
          % (len(changes), total_candidates))
    print("提醒：這是 AI 輔助抓取的建議清單，不保證完整覆蓋，最終仍需人工確認。")
    print("-" * 60)

    return csv_rows


if __name__ == "__main__":
    main()
