# -*- coding: utf-8 -*-
"""
連帶決定表的兩個輔助：寫表之前呼叫，程式都不代填「要改嗎」「改成什麼」。

一、異動內容／建議改法（annotate）
    表上以前只有「異動摘要」（新文前一截），看不出這一次到底改了哪幾個字，人要回頭翻
    對照表；「改成什麼」也要自己把整段條文重打一次。這裡補兩欄：
        異動內容   「三日→五日」：那一處異動改了哪幾個字
        建議改法   把同樣的改法套到候選段上的樣子。只給參考，不填進「改成什麼」——
                   決定權在人。套不上去（候選段裡找不到、找到不只一處、異動是整段
                   新增或刪除、一列掛好幾處異動）就留空，不硬猜。

二、沿用上一輪（carry_over）
    草稿改一個字重跑 compare，決定表整張重建，上一輪填的「要改嗎」「改成什麼」全部
    清空——候選卻一模一樣。這裡把上一輪的決定帶過來，只帶「候選全文、異動條文ID、
    異動摘要、掛的那幾處異動的新舊文」完全相同的列（同 review_pack.candidate_sha256
    那一把尺）；有任何一樣變了的列留空，要人重新看。帶過來的列在「沿用上一輪」寫「是」。
    上一輪的表去哪裡找：同一個產出資料夾還在原位的那一份（單本重跑），不在就找
    系統檔案/歷次/ 最新那一輪（「開始」會先把上一輪整包歸檔）。
"""

import csv
import difflib
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import review_pack as rp
from _common import FILL_DIR, SYSTEM_DIR, locate

# 沿用時帶過來的欄：人的決定、AI 三欄（同一段字、同一處異動，AI 判的也是同一件事）、
# 核准方式（那個決定是照哪一條規則核准的；不帶的話重跑開始後看起來像人自己填的，B21）
CARRY_FIELDS = ("要改嗎", "改成什麼", "AI判斷", "AI分數", "AI理由", "核准方式")
MAX_CONTEXT = 8          # 建議改法找唯一位置時，前後最多各多帶幾個字


# ---------------------------------------------------------------------------
# 異動內容／建議改法
# ---------------------------------------------------------------------------

def _hunks(old, new):
    """old → new 的每一處改動：[(舊的那幾個字, 新的那幾個字, 在舊文的起點, 終點)]。"""
    matcher = difflib.SequenceMatcher(None, old, new, autojunk=False)
    return [(old[i1:i2], new[j1:j2], i1, i2)
            for tag, i1, i2, j1, j2 in matcher.get_opcodes() if tag != "equal"]


def describe(change):
    """一處異動改了什麼，給人看的一句話。"""
    kind = change.get("修改類型")
    if kind == "新增":
        return "新增整段"
    if kind == "刪除":
        return "刪除整段"
    old, new = change.get("old_text") or "", change.get("new_text") or ""
    parts = []
    for old_seg, new_seg, i1, i2 in _hunks(old, new):
        # 只改一兩個字時多帶一個字，「三→五」看不出是什麼，「三日→五日」看得出來
        if max(len(old_seg), len(new_seg)) <= 2 and i2 < len(old):
            old_seg, new_seg = old_seg + old[i2], new_seg + old[i2]
        parts.append("%s→%s" % (old_seg or "（無）", new_seg or "（無）"))
    if len(parts) > 4:
        parts = parts[:4] + ["…共 %d 處" % len(parts)]
    return "、".join(parts)


def suggest(candidate, change):
    """把 change 的改法套到 candidate 上；套不上去回 ""。

    每一處改動都要在候選段裡找到「唯一」一處相同的舊字：先比改動本身，找到不只一處
    （「三」在「三、財產保險…三日內」出現兩次）就前後各多帶一個字再找，最多帶
    MAX_CONTEXT 個字；還是找不到唯一的一處就放棄整列——猜錯位置比留空更糟。
    """
    if change.get("修改類型") != "修改":
        return ""
    old, new = change.get("old_text") or "", change.get("new_text") or ""
    text = candidate or ""
    for old_seg, new_seg, i1, i2 in _hunks(old, new):
        for k in range(0 if old_seg else 1, MAX_CONTEXT + 1):
            left, right = old[max(0, i1 - k):i1], old[i2:i2 + k]
            probe = left + old_seg + right
            if not probe:
                continue
            count = text.count(probe)
            if count == 1:
                text = text.replace(probe, left + new_seg + right)
                break
            if count == 0:
                return ""
        else:
            return ""
    return text if text != candidate else ""


def annotate(rows, items, books=None):
    """每一列補上「異動內容」「建議改法」。books：{規章名: {"changes": [...]}}，跨本列用。"""
    book = {"changes": items}
    for row in rows:
        linked = [ch for _, ch in rp.changes_for_row(row, book, books)]
        row["異動內容"] = "；".join(describe(ch) for ch in linked)
        row["建議改法"] = suggest(row.get("候選全文"), linked[0]) if len(linked) == 1 else ""
        outline = row.get(dt.OUTLINE_KEY)
        if outline:
            # 章節引用列（Step 0.5）：異動內容寫哪一處引用要改成什麼；建議改法照位置改寫候選全文。
            # 同一段同時也是相似候選、已經有建議改法時不蓋掉它，章節那幾處寫在異動內容裡。
            notes = [("「%s」→「%s」（%s）" % (f["quote"], f["new_quote"], f.get("tag") or "章節換號"))
                     if f.get("new_quote")
                     else "「%s」指到的地方這次刪掉了，要改指別處或刪掉" % f["quote"] for f in outline]
            row["異動內容"] = "；".join(x for x in [row["異動內容"]] + notes if x)
            if not row["建議改法"]:
                row["建議改法"] = dt.outline_suggestion(row.get("候選全文") or "", outline)
    return rows


# ---------------------------------------------------------------------------
# 沿用上一輪
# ---------------------------------------------------------------------------

def _read(table_path, changes_path):
    if not (os.path.isfile(table_path) and os.path.isfile(changes_path)):
        return None
    try:
        from _common import open_csv
        with open_csv(table_path) as f:
            rows = list(csv.DictReader(f))
        with io.open(changes_path, encoding="utf-8") as f:
            items = json.load(f)
    except (OSError, ValueError, UnicodeDecodeError, csv.Error):
        return None
    return rows, items


def previous_round(outdir):
    """上一輪的 (決定表列, 異動清單)；找不到回 None。

    先看產出資料夾原位（單本 compare 重跑到同一個資料夾，寫表之前舊表還在），
    再看 系統檔案/歷次/ 裡最新的那一輪（「開始」會先歸檔；時間戳資料夾名照字典序
    就是時間順序）。
    """
    here = _read(locate(outdir, "連帶決定表.csv")[0], locate(outdir, "異動清單.json")[0])
    if here:
        return here
    history = os.path.join(outdir, SYSTEM_DIR, "歷次")
    if not os.path.isdir(history):
        return None
    for stamp in sorted(os.listdir(history), reverse=True):
        base = os.path.join(history, stamp)
        found = _read(os.path.join(base, FILL_DIR, "連帶決定表.csv"),
                      os.path.join(base, SYSTEM_DIR, "異動清單.json"))
        if found:
            return found
    return None


def _has_answer(row):
    return any((row.get(field) or "").strip() for field in CARRY_FIELDS)


def carry_over(rows, items, previous):
    """把上一輪填過的決定帶到這一輪相同的列上，回傳帶了幾列。

    相同＝review_pack.candidate_sha256 一樣（候選全文、異動條文ID、異動摘要、掛的
    本本異動新舊文）。上一輪同一把鑰匙有好幾列時照順序一對一配，不會一列配兩次。
    人自己在 Excel 加的欄（承辦註記之類）一起帶過來。
    """
    if not previous:
        return 0
    prev_rows, prev_items = previous
    prev_book = {"changes": prev_items}
    pool = {}
    for row in prev_rows:
        if _has_answer(row):
            # 被 Excel 存過的表，換行會變成 \r\n；比對前收斂，跟 read_table 同一把尺
            key_row = dict(row, 候選全文=dt.normalize_newlines(row.get("候選全文") or ""))
            pool.setdefault(rp.candidate_sha256(key_row, prev_book), []).append(row)
    if not pool:
        return 0
    known = set(dt.COLUMNS) | set(dt.OPTIONAL_COLUMNS)
    book = {"changes": items}
    carried = 0
    for row in rows:
        bucket = pool.get(rp.candidate_sha256(row, book))
        if not bucket:
            continue
        old = bucket.pop(0)
        for field in CARRY_FIELDS:
            row[field] = dt.normalize_newlines(old.get(field) or "")
        for field, value in old.items():
            if field and field not in known and value:
                row[field] = value
        row["沿用上一輪"] = "是"
        carried += 1
    return carried
