# -*- coding: utf-8 -*-
r"""
apply_changes：把「連帶決定表」裡人填的改動寫進新版草稿，每一處用 Word 追蹤修訂標出來。

用法：
    py apply_changes.py 草稿.docx 連帶決定表.csv --outdir 產出

做法沿用 docx_annotate：複製原檔、只動有改的那幾段、格式逐字保留、書籤圖片留原位。
差別是不「塗紅」，而是寫 <w:ins>／<w:del>，Word 打開就是真正的修訂記號，可接受可拒絕。

輸出兩份：
    新版_定稿.docx          帶修訂記號；settings 開了追蹤修訂
    新版_定稿_乾淨版.docx    修訂全部接受；給終比對與切條用

不做的事：不自動新增整條條文（第一版）。
"""

import copy
import datetime
import io
import os
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import docx_annotate as DA
import decision_table as dt
import notices as nt
from _common import run_symbol_text  # noqa: E402
from _common import (ANCHOR_TAGS, AtomicWrites, DELETE_LIKE_TAGS, FORMAT_ONLY_KINDS,
                     TEXT_AFFECTING_KINDS,
                     XML_CLEANUP_NOTICE, accept_revisions, count_tracked_changes,
                     describe_tracked_changes, diff_runs, place,
                     _direct_blocks, cell_paragraphs)

W = DA.W
_W = DA._W
XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"
AUTHOR = "reg"


class ApplyError(ValueError):
    pass


def _clip(text, limit):
    """套用報告裡的引文：換行先換成空白，真的截到字才加「…」。

    硬切 30／40 字不加省略號，看起來像條文的句末標點被刪掉了，人會回頭去翻
    草稿確認；而候選全文帶換行（草稿的 <w:br/> 讀進來是 \\n）直接切下去，
    報告那一列會被撐成兩行，「第 N 列 段次 X 狀態 引文」的欄位全部錯位。
    """
    one_line = re.sub(r"\s+", " ", text or "").strip()
    return (one_line[:limit] + "…") if len(one_line) > limit else one_line


# 「跳過」的每一種狀態，以及人要怎麼接手。這幾列程式一個字都沒改，定稿上也看不到
# 修訂記號——不講的話，人看到沒有紅字就以為那幾列處理好了。
SKIP_REASONS = [
    ("跳過（找不到段）", "候選段次是空的或超出範圍，請確認決定表的段次欄"),
    ("跳過（原文不符）", "草稿那一段的字跟決定表上的候選全文對不起來，草稿可能中途被改過"),
    ("跳過（段落含巢狀內容）", "那一段裡有超連結、域代碼或既有修訂，硬改會把字印兩次，請在 Word 裡自己改"),
    ("跳過（範本鎖定欄位）",
     "那一段被範本的內容控制項鎖起來（Word 的 contentLocked／sdtContentLocked），"
     "範本設計上就不准改；硬寫進去 Word 會擋掉或還原，請找範本管理人解鎖，或在 Word 裡自己改"),
    ("跳過（新舊文字相同）",
     "那幾列的「改成什麼」跟原文一字不差，定稿上不會有任何修訂記號，等於不改；"
     "真的要改請把「改成什麼」寫成改完的樣子，真的不改請把「要改嗎」改成「不改」"),
]

# 「這一列填了改，但填的字等於原文」。它跟其他跳過不一樣：不是程式做不到，
# 是人自己選了跟原文一樣的字。所以驗收時要單獨報一行，不併進「未改到」。
SAME_TEXT_STATUS = "跳過（新舊文字相同）"

# 「程式做不到」的那幾種跳過。這幾列是真的沒改到，要擋結論、算「未改到」；
# 人自己選的「新舊文字相同」不在裡面，那一列是人決定不改，不擋。
SKIP_BLOCKING = frozenset((
    "跳過（找不到段）",
    "跳過（原文不符）",
    "跳過（範本鎖定欄位）",
    "跳過（段落含巢狀內容）",
))

LOCKED_STATUS = "跳過（範本鎖定欄位）"


def blocked_rows(tally):
    """統計裡「程式做不到」那幾種跳過合計幾列。0 就是沒有這一類。"""
    return sum(tally.get(status, 0) for status in SKIP_BLOCKING)


def blocked_message(tally):
    """「程式沒改到」那一句。畫面、提醒.txt、套用報告一律用這一句，人才對得起來。

    為什麼要單獨一句：畫面上「已套用 8 列」跟「跳過（原文不符）1 列」長得一模一樣，
    人看完統計就去跑 finalize，finalize 把那一列算成「未改到」擋下來，人才回頭找
    是哪裡出事。先在 apply 就講明白，順序才對。
    """
    detail = "、".join("%s %d 列" % (status, tally[status])
                       for status, _why in SKIP_REASONS
                       if status in SKIP_BLOCKING and tally.get(status))
    return ("有 %d 列程式沒改到（%s），finalize 會把它們算成「未改到」；"
            "請先照 提醒.txt 的說明在 Word 裡處理" % (blocked_rows(tally), detail))


def _has_edits(runs):
    """diff_runs 的結果裡有沒有真正的增刪。"""
    return any(kind in ("insert", "delete") for kind, _ in runs)


def same_after_normalize(old_text, new_text):
    """apply 判「新舊文字相同（＝這一列等於不改）」用的那一把尺。全案只有這一把。

    收斂換行（Excel 存過的決定表會把 \\n 變成 \\r\\n）、去頭尾空白，其餘逐字比。
    **不是**去掉所有空白：「本公司 應」比「本公司應」多一個半形空格，apply 會真的
    寫進一處修訂，所以它就不是「等於原文」。

    為什麼要抽出來：finalize 的第四問以前用 `decision_table.normalize`（正規表示式
    把所有空白殺光）自己判一次，跟這裡不是同一把尺。只差一個空格的那一列，
    apply 回報「已套用」、定稿上真的有修訂記號，finalize 卻寫「填了但等於原文
    （視為不改）」——人會以為那一列沒改到而回頭再改一次。
    """
    return not _has_edits(diff_runs(dt.normalize_newlines(old_text or "").strip(),
                                    dt.normalize_newlines(new_text or "").strip()))


class RevisionIds(object):
    """修訂元素的 w:id 整份文件不能重複。從既有最大值往上編。"""

    def __init__(self, root=None):
        top = 0
        if root is not None:
            for el in root.iter():
                value = el.get(_W + "id")
                if value and value.isdigit():
                    top = max(top, int(value))
        self.next = top + 1

    def take(self):
        value = self.next
        self.next += 1
        return str(value)


def _now():
    return datetime.datetime.now().replace(microsecond=0).isoformat()


def _rev(tag, ids, author, date):
    el = ET.Element(_W + tag)
    el.set(_W + "id", ids.take())
    el.set(_W + "author", author)
    el.set(_W + "date", date)
    return el


def _del_run(text, rpr):
    run = ET.Element(_W + "r")
    if rpr is not None:
        run.append(copy.deepcopy(rpr))
    # 刪掉的文字裡若有定位點或換行，一樣要還原成 <w:tab/>／<w:br/>，
    # 直接把 \t、\n 寫進 <w:delText> 的話 Word 只會顯示成空白
    DA.append_text_nodes(run, text, tag="delText")
    return run


def _segments_old_coords(parts, rpr_per_char, offset):
    """差異片段配上格式，座標是**舊文**（段落裡現在的字）的第幾個字（A2）。

    標註版（docx_annotate）的段落裡是新文，所以那邊用新文座標；這裡是在舊文段落上寫修訂：
    equal、delete 的字都在舊文裡，照舊文位置拿格式、往前推；insert 的字舊文沒有，
    沿用插入點前一個字的格式（在段首就用第一個字的），位置不動。以前借用新文座標，
    長改短、短改長之後粗體、書籤、分頁符落到錯的字。
    回傳 [(種類, 文字, rPr, 舊文第幾個字), ...]，同一片段中間格式有變就拆開。
    """
    out = []
    pos = offset
    last = len(rpr_per_char) - 1

    def fmt(index):
        return rpr_per_char[min(max(index, 0), last)] if rpr_per_char else None

    for kind, text in parts:
        if not text:
            continue
        if kind == "insert":
            out.append((kind, text, fmt(pos - 1 if pos > offset else pos), pos))
            continue
        start = 0
        while start < len(text):
            rpr = fmt(pos + start)
            end = start + 1
            while end < len(text) and fmt(pos + end) is rpr:
                end += 1
            out.append((kind, text[start:end], rpr, pos + start))
            start = end
        pos += len(text)
    return out


# 欄位（交互參照、頁碼、目錄…）：顯示的字是 Word 算出來的結果，寫進修訂的話
# Word 一更新欄位就還原，還可能把修訂夾進欄位結果裡（B12）。這種段落不自動改。
_FIELD_TAGS = ("fldChar", "instrText", "fldSimple", "delInstrText")


def has_field(paragraph):
    return any(True for tag in _FIELD_TAGS for _ in paragraph.iter(_W + tag))


def tracked_rewrite(paragraph, new_text, ids, author=AUTHOR, date=None):
    """把一段改成 new_text。差異處包 <w:ins>／<w:del>；格式、書籤、圖片留原位。

    回傳實際寫進去的 <w:ins>／<w:del> 節點數：

        None  段落裡有巢狀文字（超連結、域代碼、既有修訂、文字方塊），完全不動，
              由呼叫端回報「跳過（段落含巢狀內容）」
        0     新文跟原文逐字相同（人把「改成什麼」填成原文），段落一個字都沒動，
              由呼叫端回報「跳過（新舊文字相同）」——不能回報「已套用」：
              定稿上看不到任何修訂記號，說「已套用」等於騙人
        >0    真的寫了幾處修訂
    """
    date = date or _now()
    if has_field(paragraph):
        return None       # 欄位（交互參照、頁碼…）的結果文字不能直接改，見 _FIELD_TAGS
    raw, rpr_per_char, keepers = DA._scan_paragraph(paragraph)
    if raw.strip() != DA._paragraph_text(paragraph).strip():
        return None       # 段落裡有超連結、文字方塊等巢狀文字，直接改會把字印兩次
    # 先算差異：一處 ins／del 都沒有就代表新文等於原文，這時候連段落都不要動
    # （動了只是把 runs 重排一次，定稿仍然沒有任何修訂記號，白白冒風險）。
    # 換行先收斂：決定表被 Excel 存過之後，\n 會變成 \r\n，不收斂會被當成有改。
    # raw 這一邊不能再過 normalize_newlines：下面的 rpr_per_char／offset 是以 raw
    # 的字元位置為座標，長度一變格式就會對錯字。raw 來自 <w:t>／<w:br/>，本來就沒有 \r。
    probe = diff_runs(raw.strip(), dt.normalize_newlines(new_text).strip())
    if not _has_edits(probe):       # 跟 same_after_normalize 同一把尺、同一段算式
        return 0
    # 段落裡本來就有的修訂先接受掉。真正需要它的是 <w:pPr> 裡的修訂記錄：
    # 下面重寫時只清 <w:pPr> 以外的子元素，所以行內的舊 ins／del 外殼本來就不會留下
    # （_scan_paragraph 沒把它們收進 keepers），但段落記號的 del／moveFrom 與 pPrChange
    # 會原封不動留在 pPr 裡——定稿因此帶著一個跟這次改動無關的段落記號刪除，
    # 接受修訂後那一段會莫名其妙跟下一段合併。正常流程走不到這裡（守門先擋），這是第二道保險。
    DA.accept_paragraph_revisions(paragraph)
    offset = len(raw) - len(raw.lstrip())
    pieces = _segments_old_coords(probe, rpr_per_char, offset)
    written = 0
    # 前後綴（段首縮排的定位點、換行、空白）不算異動、也不能被吃掉，原樣放回去
    (head, head_rpr), (tail, tail_rpr) = DA.edge_runs(raw, rpr_per_char)

    for child in list(paragraph):
        if child.tag != _W + "pPr":
            paragraph.remove(child)
    kept = list(keepers)

    def flush_before(position):
        while kept and kept[0][0] <= position:
            paragraph.append(kept.pop(0)[1])

    if head:
        paragraph.append(DA._make_run(head, head_rpr, None))

    for kind, text, rpr, start in pieces:
        if kind == "insert":
            # 新增的字舊文沒有：寫在插入點，書籤、圖片照舊文位置排在它前後
            flush_before(start)
            wrapper = _rev("ins", ids, author, date)
            wrapper.append(DA._make_run(text, rpr, None))
            paragraph.append(wrapper)
            written += 1
            continue
        # equal、delete 的字都在舊文裡：遇到書籤、圖片、分頁符的位置就切開，元素放回原位
        cursor, rest = start, text
        while rest:
            flush_before(cursor)
            nxt = kept[0][0] if kept else None
            if nxt is not None and cursor < nxt < cursor + len(rest):
                take = nxt - cursor
            else:
                take = len(rest)
            if kind == "delete":
                wrapper = _rev("del", ids, author, date)
                wrapper.append(_del_run(rest[:take], rpr))
                paragraph.append(wrapper)
                written += 1
            else:
                paragraph.append(DA._make_run(rest[:take], rpr, None))
            cursor += take
            rest = rest[take:]
    if tail:
        paragraph.append(DA._make_run(tail, tail_rpr, None))
    for _, element in kept:
        paragraph.append(element)
    return written


# 刪除一段時可以留在 <w:del> 外面的「錨點」：不帶任何內容，只標一個位置
# （交叉參照指過來的書籤、註解的範圍、拼字檢查記號、編輯權限範圍）。
# 接受修訂後它們跟著段落記號併到下一段，文字與圖片都不會因此多出來。
_BARE_MARKER_TAGS = tuple(ANCHOR_TAGS) + tuple(
    _W + name for name in ("proofErr", "permStart", "permEnd"))


def _is_bare_marker(element):
    """element 是不帶內容的錨點嗎。註解參照是包在 <w:r> 裡的，要看 run 裡面裝什麼。"""
    if element.tag in _BARE_MARKER_TAGS:
        return True
    if element.tag != _W + "r":
        return False
    inner = [child for child in element if child.tag != _W + "rPr"]
    return bool(inner) and all(child.tag in ANCHOR_TAGS for child in inner)


def _as_deleted_run(run):
    """把一個 run（圖片、分頁符、域代碼…）改寫成能放進 <w:del> 的樣子：
    直屬的 <w:t>／<w:instrText> 換成 <w:delText>／<w:delInstrText>。
    只換直屬子元素：圖片裡的文字方塊有自己的段落，不能動。"""
    for child in run:
        if child.tag == _W + "t":
            child.tag = _W + "delText"
        elif child.tag == _W + "instrText":
            child.tag = _W + "delInstrText"
    return run


def tracked_delete(paragraph, ids, author=AUTHOR, date=None):
    """整段標刪除：文字包 <w:del>，段落記號也標刪除。接受修訂後這一段消失。

    按格式分段：相同 rPr 的文字打包在一起，保留各段原有格式。

    段落裡的圖片、分頁符、域代碼這些「不是字但有內容」的 run 一樣包進 <w:del>，
    放在原本的位置。以前它們被排在 <w:del> 外面：Word「接受全部修訂」之後圖片還在
    （跟著段落記號併進下一段），乾淨版（clean_tree）卻把整段連圖一起拿掉——
    同一份定稿，兩種「接受」得到兩個不同的結果。「刪除這一段」的意思是整段消失，
    所以圖片也跟著刪。只有書籤、註解錨點這種不帶內容的標記留在 <w:del> 外面
    （見 _BARE_MARKER_TAGS），交叉參照才不會斷。

    段落裡有巢狀文字（超連結、域代碼、既有修訂、文字方塊）時回傳 False 且完全不動，
    由呼叫端回報「跳過（段落含巢狀內容）」。內容控制項、方程式這類包不進 <w:del>
    的元素也一樣：硬刪的話接受與乾淨版又會不一致，請人在 Word 裡刪。
    """
    date = date or _now()
    raw, rpr_per_char, keepers = DA._scan_paragraph(paragraph)
    if raw.strip() != DA._paragraph_text(paragraph).strip():
        return False      # 段落裡有超連結、域代碼、文字方塊等巢狀文字，直接改會把字印兩次
    if any(element.tag != _W + "r" and not _is_bare_marker(element)
           for _, element in keepers):
        return False      # 內容控制項、方程式、smartTag 等包不進 <w:del> 的內容
    # 既有修訂先接受掉，主要是清掉 <w:pPr> 裡的修訂記錄（理由同 tracked_rewrite）
    DA.accept_paragraph_revisions(paragraph)
    for child in list(paragraph):
        if child.tag != _W + "pPr":
            paragraph.remove(child)

    current = [None]      # 目前正在裝的 <w:del>；遇到留在外面的錨點就收口，後面另開一個

    def deleted(run):
        if current[0] is None:
            current[0] = _rev("del", ids, author, date)
            paragraph.append(current[0])
        current[0].append(run)

    def put(element):
        if _is_bare_marker(element):
            paragraph.append(element)
            current[0] = None
        else:
            deleted(_as_deleted_run(element))

    kept = list(keepers)
    start = 0
    while start < len(raw):
        while kept and kept[0][0] <= start:
            put(kept.pop(0)[1])
        rpr = rpr_per_char[start] if start < len(rpr_per_char) else None
        # 下一個保留元素卡在這段文字中間的話，文字切在那裡，元素才會留在原位
        stop = kept[0][0] if kept and kept[0][0] < len(raw) else len(raw)
        end = start + 1
        while end < stop:
            nxt = rpr_per_char[end] if end < len(rpr_per_char) else None
            if nxt is not rpr:
                break
            end += 1
        deleted(_del_run(raw[start:end], rpr))
        start = end
    for _, element in kept:
        put(element)
    ppr = paragraph.find(_W + "pPr")
    if ppr is None:
        ppr = ET.Element(_W + "pPr")
        paragraph.insert(0, ppr)
    rpr = ppr.find(_W + "rPr")
    if rpr is None:
        # pPr 裡 rPr 要排在 sectPr、pPrChange 前面（B13）：接在最後的話，刪掉分節那一段時
        # 順序違反 Word 的格式規範
        rpr = ET.Element(_W + "rPr")
        tail = [i for i, child in enumerate(ppr) if child.tag in (_W + "sectPr", _W + "pPrChange")]
        ppr.insert(tail[0] if tail else len(ppr), rpr)
    # 段落記號的刪除標記要排在 rPr 最前面：w:del 在 EG_RPrBase 之前，順序錯了 Word 會說檔案損毀
    rpr.insert(0, _rev("del", ids, author, date))
    return True


def accepted_text(paragraph):
    return DA._paragraph_text(paragraph)


def rejected_text(paragraph):
    """拒絕修訂後的文字：跳過 <w:ins>，把 <w:delText> 算回來。

    定位點與換行的處理跟讀檔那邊一致（\\t、\\n），兩種文字才比得起來。
    """
    out = []

    def walk(node):
        for child in node:
            if child.tag in (_W + "ins", _W + "pPr", _W + "rPr", _W + "txbxContent"):
                continue
            if child.tag in (_W + "t", _W + "delText"):
                out.append(child.text or "")
            elif child.tag == _W + "tab":
                out.append("\t")
            elif DA.is_line_break(child):
                out.append("\n")
            elif run_symbol_text(child):
                out.append(run_symbol_text(child))     # 不斷行連字號、符號字：跟讀檔同一把尺
            else:
                walk(child)

    walk(paragraph)
    return "".join(out)


def _delete_marker(container):
    """container（w:rPr／w:trPr）裡的刪除／移出記號，沒有就回 None。"""
    if container is None:
        return None
    for tag in DELETE_LIKE_TAGS:
        found = container.find(tag)
        if found is not None:
            return found
    return None


def clean_tree(root):
    """接受全部修訂，原地修改並回傳。

    節點怎麼處理照 `_common.REVISION_NODES` 那一張表（解開 ins／moveTo、拿掉
    del／moveFrom、拿掉格式修訂記錄與移動的範圍標記、cellIns／cellMerge 只拿記號），
    `accept_revisions` 刻意留下來的三種結構記號由這裡收尾：
        <w:pPr><w:rPr><w:del/>  段落記號被刪 → 併進下一段，整段沒字了就整段消失
        <w:trPr><w:del/>        整列被刪     → 整個 <w:tr> 拿掉
        <w:tcPr><w:cellDel/>    整格被刪     → 整個 <w:tc> 拿掉
    以前這裡只認 ins 與 del，一份「把整項搬到別章」的草稿產出來的乾淨版，
    移動前那一整段的文字還原封不動留在 XML 裡，那不是乾淨版。
    """
    def parent_map():
        return {child: parent for parent in root.iter() for child in parent}

    accept_revisions(root)

    # 整列被標刪除：接受＝那一列整個消失（列裡的格與段落跟著走）。
    # 只拿掉 <w:trPr><w:del/> 記號的話，列會留在表格裡，等於沒接受。
    parents = parent_map()
    for row in list(root.iter(_W + "tr")):
        if _delete_marker(row.find(_W + "trPr")) is None:
            continue
        parent = parents.get(row)
        if parent is not None:
            parent.remove(row)

    # 整格被標刪除（<w:tcPr><w:cellDel/>）：接受＝那一格整個消失。
    # 一列的格被刪光就留不住那一列了（Word 規定一列至少一格），整列一起拿掉。
    parents = parent_map()
    for cell in list(root.iter(_W + "tc")):
        tc_pr = cell.find(_W + "tcPr")
        if tc_pr is None or tc_pr.find(_W + "cellDel") is None:
            continue
        parent = parents.get(cell)
        if parent is not None:
            parent.remove(cell)
    # 「這一列還有沒有格」「這張表還有沒有列」都要用 _direct_blocks 問，不能用 .find()：
    # 內容控制項（<w:sdt>）可以包住整列或整格，.find() 只看直屬子層，看不到 sdt 裡面那幾格，
    # 會把好好的一列、一整張表當成「刪光了」拿掉——空決定表跑 apply，乾淨版整張表消失。
    parents = parent_map()
    for row in list(root.iter(_W + "tr")):
        if next(_direct_blocks(row, "tc"), None) is None:
            parent = parents.get(row)
            if parent is not None:
                parent.remove(row)

    # 整張表的列都被刪光：留下來的 <w:tbl><w:tblPr/><w:tblGrid/></w:tbl> 是一張
    # 0 列的表格，不符合 OOXML 對 w:tbl 的內容模型，Word 可能直接判成「檔案損毀」
    # 而拒絕開啟——乾淨版是要拿去終比對、切條、送審的那一份，開不起來等於整批作廢。
    # 列都沒了就把表格本身一起收掉（巢狀表格也一樣，所以由內往外處理）。
    parents = parent_map()
    for table in reversed(list(root.iter(_W + "tbl"))):
        if next(_direct_blocks(table, "tr"), None) is not None:
            continue
        parent = parents.get(table)
        if parent is None:
            continue
        parent.remove(table)      # 那一格若因此一段都不剩，最後統一補回（見函式結尾）

    # 段落記號被標刪除（或標移出）的段落。接受這種修訂在 Word 裡的意思是
    # 「這一段的段落記號沒了」，也就是跟下一段合併；只有整段文字都被刪掉時，
    # 看起來才像是整段消失。moveFrom 是 del 的同一路，處理方式一模一樣。
    parents = parent_map()
    for para in list(root.iter(_W + "p")):
        ppr = para.find(_W + "pPr")
        rpr = ppr.find(_W + "rPr") if ppr is not None else None
        marker = _delete_marker(rpr)
        if marker is None:
            continue
        rpr.remove(marker)
        if len(rpr) == 0:
            ppr.remove(rpr)

        if ppr.find(_W + "sectPr") is not None:
            # 這一段帶章節設定（紙張、頁首頁尾）。整段拿掉版面就壞了，只清內容。
            for child in list(para):
                if child.tag != _W + "pPr":
                    para.remove(child)
            continue

        parent = parents.get(para)
        if parent is None:
            continue

        if not DA._paragraph_text(para).strip():
            # 整段的字都被刪了（tracked_delete 產生的樣子）：接受後這一段就該消失。
            parent.remove(para)       # 那一格若因此一段都不剩，最後統一補回（見函式結尾）
            continue

        # 還有活著的字：這是 Word 自己標的段落記號刪除，意思是併進下一段。
        siblings = list(parent)
        nxt = None
        for cand in siblings[siblings.index(para) + 1:]:
            if cand.tag == _W + "p":
                nxt = cand
                break
        if nxt is None:
            continue      # 後面沒有段落可以併，標記已拿掉，段落原地留著
        nxt_ppr = nxt.find(_W + "pPr")
        at = (list(nxt).index(nxt_ppr) + 1) if nxt_ppr is not None else 0
        for child in list(para):
            if child.tag == _W + "pPr":
                continue
            para.remove(child)
            nxt.insert(at, child)
            at += 1
        parent.remove(para)

    # 儲存格至少要有一個 <w:p>，不然 Word 會說檔案損毀。拿掉段落或巢狀表格之後，
    # 一格可能一段都不剩；以前只在「被拿掉的東西直接住在 <w:tc> 底下」時補，
    # 段落包在內容控制項（<w:tc><w:sdt><w:sdtContent>）裡時父元素是 sdtContent，
    # 就沒補到。最後統一掃一次每一格，才不會漏掉任何一種包法。
    for cell in root.iter(_W + "tc"):
        if not cell_paragraphs(cell):
            cell.append(ET.Element(_W + "p"))
    return root


# w:settings 的子元素有固定順序；trackRevisions 要放在這些之後、其餘之前，Word 才不會說檔案損毀。
_BEFORE_TRACK = (
    "writeProtection", "view", "zoom", "removePersonalInformation", "removeDateAndTime",
    "doNotDisplayPageBoundaries", "displayBackgroundShape", "printPostScriptOverText",
    "printFractionalCharacterWidth", "printFormsData", "embedTrueTypeFonts", "embedSystemFonts",
    "saveSubsetFonts", "saveFormsData", "mirrorMargins", "alignBordersAndEdges",
    "bordersDoNotSurroundHeader", "bordersDoNotSurroundFooter", "gutterAtTop",
    "hideSpellingErrors", "hideGrammaticalErrors", "activeWritingStyle", "proofState",
    "formsDesign", "attachedTemplate", "linkStyles", "stylePaneFormatFilter",
    "stylePaneSortMethod", "documentType", "mailMerge", "revisionView")


def enable_track_revisions(settings_bytes):
    DA._register_namespaces(settings_bytes)
    root = ET.fromstring(settings_bytes)
    if root.find(_W + "trackRevisions") is not None:
        return settings_bytes
    before = tuple(_W + name for name in _BEFORE_TRACK)
    position = 0
    for index, child in enumerate(list(root)):
        if child.tag in before:
            position = index + 1
    root.insert(position, ET.Element(_W + "trackRevisions"))
    return DA.to_xml_bytes(root, settings_bytes)


# ---------------------------------------------------------------------------
# 檔案層
# ---------------------------------------------------------------------------

def _load_docx(path):
    try:
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            if "word/document.xml" not in names:
                raise ApplyError("不是有效的 .docx：找不到 word/document.xml")
            payload = {n: archive.read(n) for n in names}
            infos = {i.filename: i for i in archive.infolist()}
    except zipfile.BadZipFile:
        raise ApplyError("不是有效的 .docx（不是 zip 格式）：%s" % path)
    except OSError as exc:
        raise ApplyError("讀不到草稿檔：%s（%s）" % (path, exc))
    return names, payload, infos


def _write_docx(path, names, payload, infos):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as out:
        for name in names:
            info = infos[name]
            item = zipfile.ZipInfo(name, date_time=info.date_time)
            item.compress_type = info.compress_type
            item.external_attr = info.external_attr
            out.writestr(item, payload[name])


def apply(draft_docx, decision_csv, outdir, author=AUTHOR):
    """讀決定表、逐列寫進草稿、輸出定稿／乾淨版／報告。回傳摘要 dict。

    每一列的狀態只會是這幾種：
        已套用
        未改（留空）
        未改（不改）
        跳過（找不到段）
        跳過（原文不符）
        跳過（段落含巢狀內容）   段裡有超連結、域代碼、既有修訂，硬改會把字印兩次
        跳過（範本鎖定欄位）     祖先的 w:sdt 上了 w:lock，範本設計上不准改
        跳過（新舊文字相同）     「改成什麼」填得跟原文一字不差，定稿上 0 處修訂
    """
    # 一次 apply 就是一次作業：先清空，這一次的 提醒.txt 才不會混進上一本的提醒
    # （batch-apply 是同一個 process 一本一本跑的）。
    nt.reset()
    sidecar = dt.read_sidecar(dt.sidecar_path_for(decision_csv))
    if dt.file_sha256(draft_docx) != sidecar["草稿"]["SHA256"]:
        raise ApplyError("草稿指紋不符：決定表是對「%s」產生的，這份草稿不是同一個檔。"
                         "草稿在比對之後改過了，要重新比對：工作區重跑「開始」（已填的決定會依內容沿用），"
                         "單本重跑 compare。" % sidecar["草稿"]["檔名"])
    rows = dt.read_table(decision_csv)

    names, payload, infos = _load_docx(draft_docx)
    xml_bytes = payload["word/document.xml"]
    DA._register_namespaces(xml_bytes)
    root = ET.fromstring(xml_bytes)
    body = root.find(_W + "body")
    if body is None:
        raise ApplyError("不是有效的 .docx：找不到 <w:body>")
    # 守門要認五類修訂記號（_common.REVISION_NODES），不能只認 ins／del：
    # 把一整項剪下貼到別章（moveFrom／moveTo）、刪掉表格的一整格（cellDel）
    # 也都是未經複核的條文改動，放行的話乾淨版會把它一併接受，直接進正式基準。
    # 訊息要點名是哪幾類，人才知道去 Word 找什麼。
    #
    # 只有格式修訂（rPrChange／pPrChange 那一類）是例外：它動的是版面，條文一個字
    # 都沒變，擋下來只會逼人為了「行距改過」重跑一次 Word。放行，但一定要講乾淨版
    # 把它接受了——不講的話，人會以為乾淨版的版面跟草稿一模一樣。
    existing = count_tracked_changes(root)
    blocking = sum(existing.get(kind, 0) for kind in TEXT_AFFECTING_KINDS)
    # 頁首、頁尾、註腳、章節附註裡的修訂也要擋（B11）：apply 只改本文，乾淨版會把那些
    # 修訂原封帶著，驗證只看本文照樣說通過
    other_parts = []
    for name in names:
        if re.match(r"^word/(header\d*|footer\d*|footnotes|endnotes)\.xml$", name):
            try:
                part = ET.fromstring(payload[name])
            except ET.ParseError:
                continue
            found = count_tracked_changes(part)
            if sum(found.get(kind, 0) for kind in TEXT_AFFECTING_KINDS):
                other_parts.append("%s（%s）" % (name.split("/")[-1], describe_tracked_changes(found)))
    if other_parts and not blocking:
        message = ("草稿的頁首／頁尾／註腳還有 Word 追蹤修訂：%s。apply 只改本文，乾淨版會把它們原封帶著；"
                   "請先在 Word 接受或拒絕這些修訂、另存新檔，再重跑 compare 與 apply。" % "、".join(other_parts))
        nt.notice(nt.WARNING, "apply 拒絕套用：" + message, "套用")
        raise ApplyError(message)
    if blocking:
        message = ("草稿已含 Word 追蹤修訂（%s）。apply 產生的乾淨版會把它們一併接受，等於未經複核就進正式基準；"
                   "請先在 Word 接受或拒絕這些修訂、另存新檔，再重跑 compare 與 apply。"
                   % describe_tracked_changes(existing))
        # 拒絕套用也要留底：這一次什麼都沒產出，畫面上的「[中止]」是唯一的線索，
        # 而畫面留不住。提醒.txt 由呼叫端（cmd_apply）在中止之後照樣寫出來。
        nt.notice(nt.WARNING, "apply 拒絕套用：" + message, "套用")
        raise ApplyError(message)
    format_only = sum(existing.get(kind, 0) for kind in FORMAT_ONLY_KINDS)
    format_note = ""
    if format_only:
        format_note = ("草稿含 %d 處格式修訂（版面格式，非條文），乾淨版已一併接受"
                       % format_only)
        nt.notice(nt.REMINDER, format_note, "套用")
    slots = DA.collect_slots(body)
    # 祖先查得到才看得出「這一段被範本鎖起來了」。ElementTree 沒有 .getparent()，
    # 所以整棵樹的父節點先建一份，逐列查表，不是每一列重走一次。
    parents = DA.parent_map(root)
    ids = RevisionIds(root)
    date = _now()
    DA.reset_xml_cleanup()
    locked_fields = []

    statuses = []
    for index, row in enumerate(rows, 2):
        action = row["要改嗎"]
        if action == "":
            statuses.append((index, row, "未改（留空）"))
            continue
        if action == "不改":
            statuses.append((index, row, "未改（不改）"))
            continue
        line = (row.get("候選段次") or "").strip()
        if not line.isdigit() or not 1 <= int(line) <= len(slots):
            statuses.append((index, row, "跳過（找不到段）"))
            continue
        slot = slots[int(line) - 1]
        # 兩邊都先把 \r\n 收成 \n 再比：草稿裡的 <w:br/> 讀進來是 \n，決定表被 Excel
        # 存過之後同一個換行會變成 \r\n。不收斂的話這一列會被判成「原文不符」而跳過，
        # 但草稿其實一個字都沒被動過。收斂只用在比對，寫進產出檔的原文不變。
        if (dt.normalize_newlines(DA._paragraph_text(slot["p"])).strip()
                != dt.normalize_newlines(row.get("候選全文") or "").strip()):
            statuses.append((index, row, "跳過（原文不符）"))
            continue
        # 「改成什麼」跟原文一樣：根本沒有要寫的字，鎖不鎖都一樣——先判這個，
        # 跟 finalize 的第四問（等於原文，不擋）說同一句話，不要被當成「範本鎖定」擋下
        if action == "改" and same_after_normalize(row.get("候選全文"), row.get("改成什麼")):
            statuses.append((index, row, "跳過（新舊文字相同）"))
            continue
        # 最後一道守門：範本把這一格鎖起來了就不能寫。公文範本常把核定欄、
        # 發文字號那幾格包在 <w:sdt> 裡再上 w:lock，Word 打開會擋掉或還原，
        # 而套用報告照記「已套用」——人以為改好了，交出去的檔案其實沒改（實測 no 24）。
        alias = DA.locked_sdt_alias(slot["p"], parents)
        if alias:
            locked_fields.append((index, alias))
            statuses.append((index, row, LOCKED_STATUS))
            continue
        if action == "改":
            written = tracked_rewrite(slot["p"], row["改成什麼"], ids, author, date)
            if written is None:
                status = "跳過（段落含巢狀內容）"
            elif written == 0:
                # 人填的「改成什麼」跟原文一字不差：定稿上不會有任何修訂記號。
                # 這時候記「已套用」是最容易讓人漏掉的一種假話。
                status = "跳過（新舊文字相同）"
            else:
                status = "已套用"
        else:
            status = "已套用" if tracked_delete(slot["p"], ids, author, date) else "跳過（段落含巢狀內容）"
        statuses.append((index, row, status))

    # 掉段自檢：乾淨版的段數只能跟草稿一樣，或照「刪除」的決定少掉那幾段。
    # 少得比決定還多，就是 clean_tree 把人沒叫刪的東西刪了（以前內容控制項包住表格的
    # 列或格時，整張表會在乾淨版裡消失，統計卻全空、沒有任何警告）。這時候寧可中止，
    # 也不能把少了一張表的乾淨版交給 finalize 與 cut。
    clean_root = clean_tree(copy.deepcopy(root))
    clean_body = clean_root.find(_W + "body")
    clean_count = len(DA.collect_slots(clean_body)) if clean_body is not None else 0
    deleted = sum(1 for _, row, status in statuses
                  if status == "已套用" and row["要改嗎"] == "刪除")
    if not len(slots) - deleted <= clean_count <= len(slots):
        message = ("乾淨版段數不對：草稿 %d 段、決定刪除 %d 段，乾淨版應為 %d 段，實際 %d 段。"
                   "接受修訂時有段落被多刪或多出來（常見原因是內容控制項包住表格的列或格），"
                   "這份乾淨版不能用，已中止、沒有寫出任何檔。請把草稿與決定表一起回報。"
                   % (len(slots), deleted, len(slots) - deleted, clean_count))
        raise ApplyError(message)      # 提醒.txt 由呼叫端（cmd_apply）照中止流程寫

    os.makedirs(outdir, exist_ok=True)
    # 三件套都是「人要看／要交出去」的檔 → 審閱文件/（見 _common.FILE_HOMES）。
    # place() 會順手把那一格建出來。
    tracked_path = place(outdir, "新版_定稿.docx")
    clean_path = place(outdir, "新版_定稿_乾淨版.docx")
    report_path = place(outdir, "套用報告.txt")
    original_settings = payload.get("word/settings.xml")

    # 定稿、乾淨版、套用報告三件套一起原子寫出（實測 no 12）：舊寫法一份一份
    # 直接覆寫，乾淨版寫到一半失敗時定稿已經是新的、報告還是上一輪的，
    # 人照著舊報告核新定稿，對不上還找不出原因。
    with AtomicWrites() as aw:
        payload["word/document.xml"] = DA.to_xml_bytes(root, xml_bytes)
        if original_settings:
            payload["word/settings.xml"] = enable_track_revisions(original_settings)
        _write_docx(aw.path(tracked_path), names, payload, infos)

        payload["word/document.xml"] = DA.to_xml_bytes(clean_root, xml_bytes)
        if original_settings:
            payload["word/settings.xml"] = original_settings
        _write_docx(aw.path(clean_path), names, payload, infos)

        tally = {}
        lines = ["套用報告", "草稿：%s" % draft_docx, "決定表：%s" % decision_csv, ""]
        for index, row, status in statuses:
            tally[status] = tally.get(status, 0) + 1
            lines.append("第 %d 列  段次 %s  %s  %s" % (
                index, row.get("候選段次") or "-", status, _clip(row.get("候選全文"), 30)))
        # 「跳過」的那幾列是最需要人接手的：程式沒改、Word 裡也看不到修訂記號，
        # 只印在畫面上的話，人看到定稿沒紅字就會以為那幾列已經處理好了。
        for status, why in SKIP_REASONS:
            if tally.get(status):
                nt.notice(nt.REMINDER,
                          "有 %d 列「%s」，程式沒有改到，%s" % (tally[status], status, why),
                          "套用")
        # 上面那幾則是「這一種跳過要怎麼接手」；這一則講的是「不處理會怎樣」，
        # 等級要拉到警告：finalize 的第一問會把這幾列算成「未改到」而擋掉結論。
        # 發在這裡而不是呼叫端（cmd_apply／cmd_batch_apply）：apply 一回去，
        # 下面的 write_notices 就把清單收掉了。寫在這裡才會同時進 套用報告.txt
        # 與 提醒.txt，批次那條路（同樣呼叫 apply）也一樣有。
        # 畫面那一行由呼叫端印，用的是同一句 blocked_message()。
        if blocked_rows(tally):
            nt.notice(nt.WARNING, blocked_message(tally), "套用")
        lines += ["", "統計："] + ["  %-14s %d 列" % (k, v) for k, v in sorted(tally.items())]
        # 「填了改但填的字等於原文」單獨再列一次：這一種混在上面幾十列裡最看不出來，
        # 而它正是最容易被當成「已經改好了」的一種。
        same = [(index, row) for index, row, status in statuses if status == SAME_TEXT_STATUS]
        if same:
            lines += ["", "填了「改」但「改成什麼」等於原文（視為不改，定稿上 0 處修訂）："]
            lines += ["  第 %d 列  段次 %s  %s" % (index, row.get("候選段次") or "-",
                                                  _clip(row.get("候選全文"), 40))
                      for index, row in same]
        # 被範本鎖住的那幾列單獨列一次，連欄位名一起寫出來：人拿著欄位名才找得到
        # 是哪一格、才知道要去找誰解鎖。
        if locked_fields:
            lines += ["", "被範本鎖住、程式不能改的欄位（請在 Word 裡自己改或請範本管理人解鎖）："]
            lines += ["  第 %d 列  鎖定欄位「%s」" % (index, alias)
                      for index, alias in locked_fields]
        # 原稿裡的 XML 不合法字元：清掉了幾個一定要講，那是使用者原稿裡真的存在的字。
        cleaned = DA.xml_cleanup_count()
        if cleaned:
            nt.notice(nt.REMINDER, XML_CLEANUP_NOTICE % cleaned, "套用")
        lines += ["", "定稿（帶追蹤修訂）：%s" % tracked_path, "定稿乾淨版：%s" % clean_path, ""]
        if format_note:
            # 畫面上講過一次，報告裡也要有一份：印在畫面上的提醒會被往上捲走，
            # 交付的檔案才是複核時會再看一次的東西。
            lines.append("提醒：" + format_note)
        lines += ["提醒：第一版不會自動新增整條條文。要新增的條文請在 Word 裡自己加，再跑 finalize。",
                  "提醒：定稿請在有 Word 的電腦開一次，確認修訂看得到、接受與拒絕都正常。"]
        # 這次累積的提醒整段抄進套用報告，另外再寫一份獨立的 提醒.txt
        lines += [""] + nt.report_lines()
        with io.open(aw.path(report_path), "w", encoding="utf-8-sig") as f:
            f.write("\n".join(lines) + "\n")
    # append：compare 多半已經在同一個產出資料夾寫過一份 提醒.txt，覆寫會把它那幾則
    # 洗掉（apply 開頭 reset() 過，清單裡只剩 apply 自己的）。接在後面，兩段各有檔頭。
    notice_path = nt.write_notices(outdir, append=True, title="apply（第 3 步　套用）")
    return {"統計": tally, "定稿": tracked_path, "乾淨版": clean_path,
            "報告": report_path, "提醒": notice_path}


def main(argv=None):
    import argparse
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    parser = argparse.ArgumentParser(description="把連帶決定表寫進草稿，開追蹤修訂")
    parser.add_argument("draft")
    parser.add_argument("decisions")
    parser.add_argument("--outdir", default="")
    args = parser.parse_args(argv)
    try:
        summary = apply(args.draft, args.decisions, args.outdir or os.path.dirname(os.path.abspath(args.decisions)))
    except (ApplyError, dt.DecisionTableError) as exc:
        print("[中止] %s" % exc, flush=True)
        return 1
    for key, value in sorted(summary["統計"].items()):
        print("  %-14s %d 列" % (key, value), flush=True)
    print("定稿：%s" % summary["定稿"], flush=True)
    print("乾淨版：%s" % summary["乾淨版"], flush=True)
    print("報告：%s" % summary["報告"], flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
