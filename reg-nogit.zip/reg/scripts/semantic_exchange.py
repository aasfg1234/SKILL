# -*- coding: utf-8 -*-
"""
語意交換包：這台電腦算不了 BGE-M3，要到有模型的電腦算的時候，只帶一個檔來回。

以前要把整個工作區複製過去、再整個帶回來：工作區可能很大，而且整個帶回來會把這段時間
在這台填的決定表蓋掉。現在：

    這台   開始 把每一本的語意輸入打包成 產出/系統檔案/語意候選/語意交換包.zip
    那台   python scripts/semantic_candidates.py --交換包 "<語意交換包.zip>" --model "<模型資料夾>"
           算完把 <規章名>.csv 寫回同一個 zip（向量快取留在那台的 reg/語意快取/，下次沒改的段落不重算）
    這台   把 zip 放回原位（或直接放進 匯入/），跑 繼續（或 batch-semantic）：取出結果、逐本併入

zip 裡：交換包.json（輪次、參數、規章名）、<規章名>_語意輸入.json；算完多了 <規章名>.csv。
輪次每次打包都換新的，這台另記一份在 語意候選/交換包紀錄.json：帶回來的是上一輪（重跑開始之前）
的包，就講清楚要拿這一輪的包重算，不拿舊結果去併（草稿指紋也會擋，但那一句看不出是拿錯包）。
"""

import csv
import datetime
import io
import json
import os
import shutil
import sys
import uuid
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.dirname(HERE)
for _path in (HERE, os.path.join(HERE, "regdiff")):
    if _path not in sys.path:
        sys.path.insert(0, _path)

PACK_NAME = "語意交換包.zip"
MANIFEST = "交換包.json"
RECORD = "交換包紀錄.json"
INPUT_SUFFIX = "_語意輸入.json"
# 有模型的那台電腦上，向量快取的預設位置（跟著那台的 reg 走，不跟著交換包走：快取只有算的那台用得到）
DEFAULT_CACHE = os.path.join(REG, "語意快取")


class ExchangeError(ValueError):
    pass


def _now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M")


def pack(folder, params=None):
    """把 folder 裡每一個 <規章名>_語意輸入.json 打包成 folder/語意交換包.zip，回傳 zip 路徑
    （沒有任何輸入回 None）。params：這台設定的門檻、每處最多幾筆、粗篩，那台照這一份算。"""
    names = sorted(n[:-len(INPUT_SUFFIX)] for n in os.listdir(folder) if n.endswith(INPUT_SUFFIX))
    if not names:
        return None
    round_id = uuid.uuid4().hex
    manifest = {"版本": 1, "輪次": round_id, "打包": _now(), "參數": params or {}, "規章": names}
    path = os.path.join(folder, PACK_NAME)
    tmp = path + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(MANIFEST, json.dumps(manifest, ensure_ascii=False, indent=2))
        for name in names:
            z.write(os.path.join(folder, name + INPUT_SUFFIX), name + INPUT_SUFFIX)
    os.replace(tmp, path)
    with io.open(os.path.join(folder, RECORD), "w", encoding="utf-8") as f:
        json.dump({"輪次": round_id, "規章": names}, f, ensure_ascii=False)
    return path


def read_manifest(path):
    """回傳 (交換包.json 的內容, zip 裡的檔名 set)。讀不出來丟 ExchangeError。"""
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            manifest = json.loads(z.read(MANIFEST).decode("utf-8"))
    except (OSError, KeyError, ValueError, zipfile.BadZipFile) as exc:
        raise ExchangeError("語意交換包讀不出來：%s（%s）" % (path, exc))
    return manifest, names


def _record(folder):
    path = os.path.join(folder, RECORD)
    if not os.path.isfile(path):
        return {}
    try:
        with io.open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def places(folder, workspace_root=None):
    """放回來的交換包可能在哪：原位（語意候選/），或工作區的 匯入/（瀏覽器下載常改名成
    「語意交換包 (1).zip」，開頭對得上就算）。"""
    found = [os.path.join(folder, PACK_NAME)]
    if workspace_root:
        imp = os.path.join(workspace_root, "匯入")
        if os.path.isdir(imp):
            found += [os.path.join(imp, n) for n in sorted(os.listdir(imp))
                      if n.startswith(os.path.splitext(PACK_NAME)[0]) and n.lower().endswith(".zip")]
    return [p for p in found if os.path.isfile(p)]


def returned(folder, workspace_root=None):
    """找已經算好（zip 裡有結果）、而且是這一輪的交換包：回傳 (路徑, 有結果的規章 list) 或 None。
    只找到上一輪算好的包 → ExchangeError（講清楚要拿這一輪的包重算）。"""
    current = _record(folder).get("輪次")
    stale = None
    for path in places(folder, workspace_root):
        manifest, names = read_manifest(path)
        done = [n for n in manifest.get("規章") or [] if n + ".csv" in names]
        if not done:
            continue
        if current and manifest.get("輪次") != current:
            stale = path
            continue
        return path, done
    if stale:
        raise ExchangeError("%s 是上一輪（重跑開始之前）的語意交換包，結果對不上這一輪；"
                            "請把這一輪的 %s 帶去有模型的電腦重算" % (stale, os.path.join(folder, PACK_NAME)))
    return None


def unpack(path, folder, names):
    """把 zip 裡算好的 <規章名>.csv 取出到 folder（蓋掉舊的）。zip 放在 匯入/ 的話收回原位，
    匯入/ 只留規章。回傳取出的規章名 list。"""
    with zipfile.ZipFile(path) as z:
        for name in names:
            with open(os.path.join(folder, name + ".csv"), "wb") as f:
                f.write(z.read(name + ".csv"))
    home = os.path.join(folder, PACK_NAME)
    if os.path.normcase(os.path.abspath(path)) != os.path.normcase(os.path.abspath(home)):
        shutil.copy2(path, home)
        try:
            os.remove(path)
        except OSError:
            pass
    return names


def _results_text(rows, draft_sha):
    import semantic_candidates as sc
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["#草稿SHA256", draft_sha])
    writer.writerow(sc.COLUMNS)
    for row in rows:
        writer.writerow([row.get(c, "") for c in sc.COLUMNS])
    return buf.getvalue()


def compute(path, model, cache_dir=None, threshold=None, top=None, recall_top=None, say=print):
    """有模型的那台：算交換包裡每一本，結果寫回同一個 zip。回傳離開代碼（0 成功、1 包有問題、2 載不起模型）。
    門檻、每處最多幾筆、粗篩沒給就照包裡記的（打包那台的設定），兩台算法才一致。"""
    import semantic_candidates as sc
    try:
        manifest, names = read_manifest(path)
    except ExchangeError as exc:
        say("[中止] %s" % exc)
        return 1
    params = manifest.get("參數") or {}
    threshold = threshold if threshold is not None else params.get("門檻")
    top = top if top is not None else (params.get("最多幾筆") or sc.DEFAULT_TOP)
    recall_top = recall_top if recall_top is not None else params.get("粗篩")
    inputs = []
    with zipfile.ZipFile(path) as z:
        for name in manifest.get("規章") or []:
            entry = name + INPUT_SUFFIX
            if entry not in names:
                say("[中止] 交換包裡少了 %s" % entry)
                return 1
            data = json.loads(z.read(entry).decode("utf-8-sig"))
            if data.get("格式版本") != 1 or "段落" not in data or "異動" not in data:
                say("[中止] 交換包裡的 %s 格式不對" % entry)
                return 1
            inputs.append((name, data))
    if cache_dir is None:
        cache_dir = DEFAULT_CACHE
        try:
            os.makedirs(cache_dir, exist_ok=True)
        except OSError:
            cache_dir = None
    say("載入模型：%s" % model)
    scorer = sc.load_model(model, recall_top=recall_top, cache_dir=cache_dir)
    if scorer is None:
        say("[跳過] 這個環境載不起 BGE-M3。請在有模型的電腦執行這支程式。")
        return 2
    used = threshold if threshold is not None else getattr(scorer, "default_threshold", sc.DEFAULT_THRESHOLD)
    results = {}
    for name, data in inputs:
        rows = sc.find_candidates(scorer, data["異動"], data["段落"], threshold, top, data.get("目標規章", ""))
        results[name] = _results_text(rows, data["草稿"]["SHA256"])
        say("%s：語意候選 %d 列（門檻 %.2f）" % (name, len(rows), used))
    manifest["算完"] = _now()
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as src, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as dst:
        dst.writestr(MANIFEST, json.dumps(manifest, ensure_ascii=False, indent=2))
        for item in src.infolist():
            replaced = item.filename.endswith(".csv") and item.filename[:-4] in results
            if item.filename == MANIFEST or replaced:
                continue
            dst.writestr(item, src.read(item.filename))
        for name, text in results.items():
            dst.writestr(name + ".csv", text.encode("utf-8-sig"))
    os.replace(tmp, path)
    cache = getattr(scorer, "cache", None)
    if cache is not None:
        say("向量快取：沿用 %d 個、新算 %d 個（%s）" % (cache.hits, cache.misses, cache.path))
    say("算完 %d 本，結果已寫回 %s。把這個檔帶回原本那台電腦，放回原位（或放進工作區的 匯入/），"
        "跑 繼續（或 batch-semantic）併入" % (len(inputs), path))
    return 0
