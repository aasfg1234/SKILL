# -*- coding: utf-8 -*-
r"""
reg 總入口：把「切條」與「改內規」兩條線串成一條。

    py run_all.py check    舊版.docx 發布根目錄
    py run_all.py compare  舊版.docx 草稿.docx --baseline-release R --outdir O
    py run_all.py apply    草稿.docx 連帶決定表.csv --outdir O
    py run_all.py finalize 舊版.docx 乾淨版.docx --baseline-release R --decisions 表 --outdir O
    py run_all.py semantic 連帶決定表.csv 語意候選.csv
    py run_all.py cut      工作區 --source 原檔 [--inherit 舊發布根目錄] [--decisions 表 ...]

設計守則（SPADE 實測得來）：
- 工作資料夾每次都換，所以每個子命令先把輸入檔複製進 <outdir>/系統檔案/輸入/。
- 畫面會截斷（留尾巴切開頭），所以完整報告寫檔，摘要印在最後。
- 沒有鍵盤輸入；失敗一律 exit 1。
- 不寫死磁碟路徑，不碰家目錄。
"""

import argparse
import contextlib
import datetime
import hashlib
import importlib.util
import io
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.dirname(HERE)
DIFFCUT = os.path.join(HERE, "diffcut")
REGDIFF = os.path.join(HERE, "regdiff")
SETTINGS_PATH = os.path.join(REG, "設定.json")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

# 產出檔的去向只有一張表（_common.FILE_HOMES）：寫檔走 place、讀檔走 locate。
# 不要在這支自己 os.path.join(outdir, "連帶決定表.csv")——那樣去向表改了這裡不會跟著動。
from _common import place, locate, warn_legacy_layout, book_dir  # noqa: E402


def setup_stdout():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def say(text=""):
    print(text, flush=True)


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_settings():
    if not os.path.isfile(SETTINGS_PATH):
        return {}
    try:
        with io.open(SETTINGS_PATH, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError) as exc:
        # notice_pending 而不是 notice：這一則在任何一次 compare／apply 開始之前
        # 就發生了，run_compare 開頭的 reset() 會把它清掉。pending 的那幾則
        # reset() 不碰，等第一次 write_notices 寫進檔案才算交付。
        import notices as nt
        nt.notice_pending(nt.REMINDER,
                          "設定.json 讀不出來（%s），工作區根目錄、語意模型路徑等"
                          "全部用預設值" % exc, "設定檔")
        return {}


def resolve_outdir(args, settings):
    """--outdir 優先；其次 --workspace 或設定檔的工作區根目錄；都沒有就用目前目錄。"""
    if getattr(args, "outdir", ""):
        return os.path.abspath(args.outdir)
    root = getattr(args, "workspace", "") or settings.get("工作區根目錄", "")
    if not root:
        return os.path.abspath("reg_產出")
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    return os.path.join(os.path.abspath(root), "reg_產出_" + stamp)


ROLE_PREFIXES = ("舊版", "新版")
ROLE_KEY = "角色"


PROBE_NAME = ".reg_寫入測試"


def check_outdir_writable(outdir):
    """產出資料夾前置檢查：不是既有檔案、建得起來、而且真的寫得進去。

    為什麼要「真的寫一個檔再刪掉」而不是看權限位元：Windows 的唯讀屬性、
    網路磁碟機（UNC）掉線、OneDrive 的「僅線上」資料夾，用 os.access 全都
    看起來沒問題，真的寫下去才會噴 OSError——而那時候 輸入/ 已經建好、
    原始檔也複製進去了（no 10）。

    失敗一律丟 _common.InputError，由呼叫端統一印「[中止]」。
    """
    from _common import InputError
    if os.path.isfile(outdir):
        raise InputError("產出資料夾指到一個既有檔案：%s；請把 --outdir 改成資料夾路徑" % outdir)
    try:
        os.makedirs(outdir, exist_ok=True)
    except OSError as exc:
        raise InputError("產出資料夾建不起來：%s（%s）" % (outdir, exc))
    probe = os.path.join(outdir, PROBE_NAME)
    try:
        with io.open(probe, "w", encoding="utf-8") as f:
            f.write("x")
    except OSError as exc:
        raise InputError("產出資料夾不能寫入：%s（%s）；請改用別的 --outdir 或關掉開著的檔案"
                         % (outdir, exc))
    finally:
        try:
            os.remove(probe)
        except OSError:
            pass


# 「這個產出資料夾是舊排法嗎」看哪幾個檔：compare 一定會寫這兩個，
# 而且一個在 填寫表單/、一個在 系統檔案/，兩格都驗到。
_LAYOUT_PROBES = ("連帶決定表.csv", "異動清單.json")


def warn_if_legacy_outdir(outdir):
    """產出資料夾是舊排法（檔案平鋪、沒分三格）就提醒一次；回傳有沒有提醒。

    讀端照舊讀得到（locate 會退回平鋪），**寫端仍然寫進新格**——把新檔寫回平鋪
    等於把舊排法一直養下去，而且同一個資料夾會半新半舊，人更分不出哪個是這一輪的。

    單本子命令（review-pack／review-import／apply／finalize／semantic）直接接這一支；
    批次那幾支接下面的 warn_if_legacy_books（批次的產出是一本一個子資料夾，
    要驗的是每一本，不是產出根目錄——根目錄底下只有批次自己那幾個檔，
    沒有 _LAYOUT_PROBES 這兩個探針）。
    """
    if not outdir or not os.path.isdir(outdir):
        return False
    if any(locate(outdir, name)[1] for name in _LAYOUT_PROBES):
        warn_legacy_layout(outdir)
        return True
    return False


def warn_if_legacy_books(outdir, names):
    """批次版：逐本驗一次舊排法，回傳有幾本是舊排法。

    每本各發一則（warn_legacy_layout 自己用 outdir 去重），因為一批裡很可能只有
    幾本是上一個版本跑的；只講「這個產出根目錄是舊排法」的話，人不知道要回頭
    重跑哪幾本。
    """
    from _common import book_dir
    return sum(1 for name in names if warn_if_legacy_outdir(book_dir(outdir, name)))


def outdir_of_table(table_path):
    """從一張表的路徑回推它的產出資料夾：在三格裡就是上一層，平鋪就是同一層。

    多剝一層 系統檔案/輸入/：留底資料夾裡也會有一份決定表（stage_inputs 複製的），
    人拿那一份去跑 semantic／finalize 時，只剝一層會停在「系統檔案/輸入」，
    接著 locate 在那裡找到平鋪的表，於是提醒會說「…系統檔案/輸入 是舊排法的產出
    資料夾」——那是留底資料夾，本來就該平鋪，這句是假警報。
    """
    folder = os.path.dirname(os.path.abspath(table_path))
    from _common import OUTPUT_DIRS, SYSTEM_DIR
    parent = os.path.dirname(folder)
    if os.path.basename(folder) == "輸入" and os.path.basename(parent) == SYSTEM_DIR:
        return os.path.dirname(parent)
    if os.path.basename(folder) in OUTPUT_DIRS:
        return parent
    return folder


def precheck(outdir, doc_paths=(), other_paths=(), docx_only=()):
    """動任何檔案之前先驗一輪：輸入檔存在＋格式白名單，再驗產出資料夾可寫。

    回傳 None 代表過關；否則回傳要印在「[中止]」後面的那句話。

    順序不能反（no 10）：輸入檔先驗，過了才 makedirs——不然「草稿路徑打錯」
    這種最常見的手誤會留下一個空的產出資料夾，下一輪的過期檢查、歸檔都要
    跟這些殘骸打架。同理，docx_only 也要排在 check_outdir_writable 之前。

    doc_paths   要當內規全文讀的檔（走 SUPPORTED_EXTS 白名單）
    other_paths 只要求存在的檔（決定表 .csv、sidecar .json 這類）
    docx_only   除了白名單以外還必須是 .docx 的檔（M5：apply 的草稿）
    """
    from _common import InputError, check_input_file
    for path in doc_paths:
        if not path:
            continue
        try:
            check_input_file(path)
        except InputError as exc:
            return str(exc)
    for path in docx_only:
        # M5：apply 是把決定表的修改寫成 Word 追蹤修訂再存回 .docx——.txt／.md
        # 根本沒有修訂記號這種東西，硬跑只會產出一份「看起來成功但沒有任何
        # 修訂痕跡」的檔。compare 吃得下不代表 apply 吃得下，這一步要講清楚。
        if path and os.path.splitext(path)[1].lower() != ".docx":
            return ("apply 的草稿必須是 .docx（目前：%s）；.txt/.md 只能用來 compare"
                    % os.path.basename(path))
    for path in other_paths:
        if path and not os.path.isfile(path):
            return ("錯誤：找不到檔案 %s\n"
                    "請確認路徑有沒有打錯，含空白的路徑要用雙引號括起來。" % path)
    try:
        check_outdir_writable(outdir)
    except InputError as exc:
        return str(exc)
    return None


def stage_inputs(outdir, paths, roles=None, overwrite_level=None):
    """輸入檔複製進 <outdir>/輸入/ 並記 SHA-256。SPADE 的上傳檔跑完就不見，這是唯一留底。
    同一個產出資料夾可能被多個子命令接力使用，所以指紋檔採合併寫入，不覆蓋既有項目。

    overwrite_level（選填）：同一角色留底被不同內容覆寫時要用的提醒等級。預設「警告」；
    compare 會整套重算下游產出，換草稿重跑是正常流程，所以 compare 傳「提醒」就好。
    roles（選填）：跟 paths 等長的角色清單，或 {路徑: 角色} 對照表。角色是「舊版」
    或「新版」時，留底檔名變成 `舊版_<原檔名>`／`新版_<原檔名>`，指紋鍵同名，並在
    指紋檔多記一個「角色」對照。

    為什麼要分：法遵手上的舊版與新版常常就是同一個檔名（放在「匯入/現行規章」「匯入/修訂規章」
    兩個資料夾裡）。照原檔名留底的話，後複製的新版會直接蓋掉舊版，指紋檔也只剩一筆——
    留底看起來有兩個檔其實只有一個，而 review-pack 會把草稿當成舊版讀，刪除段的前後文
    整段對錯人。角色清單不能用單純的 dict 由呼叫端組（沒有草稿的那一本，舊版與新版
    是同一個路徑，當鍵會撞在一起），所以這裡也接受跟 paths 等長的清單。
    """
    import notices as nt
    # 留底是「程式接力用」的東西，進 系統檔案/輸入/（見 _common.FILE_HOMES）。
    # 舊排法的資料夾已經有平鋪的 輸入/（裡面有 舊版_／新版_ 與帶「角色」的指紋）時
    # 沿用它：另開 系統檔案/輸入/ 會把舊的那份遮掉，review-pack 從此找不到舊版檔，
    # 只能用檔名猜、把草稿當舊版（全波審查發現）。
    target, is_legacy = locate(outdir, "輸入")
    if not is_legacy:
        target = place(outdir, "輸入")
    os.makedirs(target, exist_ok=True)
    record_path = os.path.join(target, "輸入指紋.json")
    record = {}
    if os.path.isfile(record_path):
        try:
            with io.open(record_path, encoding="utf-8-sig") as f:
                record = json.load(f)
        except (OSError, ValueError) as exc:
            # 靜默清空是最糟的處理：檔案壞掉（磁碟滿了寫到一半、被人手動編輯過）
            # 之後，前面幾個子命令留下的指紋全部消失，而「輸入指紋.json 存在且
            # 看起來完整」正是之後回答「這份產出是拿哪幾個檔跑的」的唯一依據。
            # 重建可以，但一定要有人知道舊紀錄不見了。
            nt.notice(nt.WARNING,
                      "輸入指紋.json 讀不出來（%s），已重建；"
                      "之前的留底紀錄遺失，這個產出資料夾先前留底過哪些檔要另外查" % exc,
                      "留底")
            record = {}
    role_map = dict(record.get(ROLE_KEY) or {})
    for index, path in enumerate(paths):
        if not path or not os.path.isfile(path):
            continue
        if isinstance(roles, dict):
            role = roles.get(path) or ""
        elif roles is not None and index < len(roles):
            role = roles[index] or ""
        else:
            role = ""
        name = os.path.basename(path)
        if role in ROLE_PREFIXES:
            name = "%s_%s" % (role, name)
            role_map[role] = name
        dest = os.path.join(target, name)
        digest = file_sha256(path)
        previous = record.get(name)
        if previous and previous != digest:
            # 同一個產出資料夾被多個子命令接力使用，留底檔名一樣但內容不一樣，
            # 代表「同一個角色的檔案中途換過」（草稿又改了一版、舊版拿錯檔）。
            # 直接覆寫的話，留底剩下最後那一份，而決定表、指紋、段次全是前一份
            # 算出來的——回頭稽核時對不起來，卻沒有任何一行講過這件事。
            nt.notice(overwrite_level or nt.WARNING,
                      "留底 %s 被不同內容覆寫（SHA %s → %s）："
                      "同一個產出資料夾這個角色前後拿到兩個不同的檔，"
                      "先前步驟的產出是用舊的那一份算的，請確認是不是拿錯檔"
                      % (name, previous[:8], digest[:8]), "留底")
        if os.path.abspath(path) != os.path.abspath(dest):
            shutil.copy2(path, dest)
        record[name] = digest
    if role_map:
        record[ROLE_KEY] = role_map
    with io.open(record_path, "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return record


def load_regdiff_runner():
    """regdiff/run_all.py 跟這支同名，不能直接 import，改用檔案路徑載入。"""
    path = os.path.join(REGDIFF, "run_all.py")
    spec = importlib.util.spec_from_file_location("regdiff_run_all", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------------------
# check
# ---------------------------------------------------------------------------

def cmd_check(args, settings):
    from baseline_release import BaselineReleaseError, load_baseline_release
    from _common import read_paragraphs
    say("=" * 60)
    say("第 0 步　核對舊版 Word 與規格包")
    say("=" * 60)
    try:
        paragraphs = read_paragraphs(args.old_file)
        baseline = load_baseline_release(args.release_root, args.old_file,
                                         old_paragraphs=paragraphs)
    except BaselineReleaseError as exc:
        say("[不過] %s" % exc)
        return 1
    say("[過] 正式基準 %s：條文 %d 筆，內容定位 %d，無法定位 %d"
        % (baseline.version, len(baseline.items),
           baseline.binding_stats["已定位"], baseline.binding_stats["無法定位"]))
    return 0


# ---------------------------------------------------------------------------
# apply
# ---------------------------------------------------------------------------

def _verify_applied(outdir, draft, summary):
    """apply 寫完就驗帶修訂的定稿（見 verify_tracked）：驗過就不用逐本開 Word。
    結果記在 系統檔案/修訂驗證.json（人工待辦清單讀它）；沒過的另發一則警告留底。"""
    import notices as nt
    import verify_tracked as vt
    applied = summary["統計"].get("已套用", 0)
    try:
        result = vt.verify(summary["定稿"], summary["乾淨版"], draft, applied)
    except Exception as exc:          # 驗不了（檔案壞、讀不到）不能讓 apply 本身失敗
        result = {"通過": False, "問題": ["驗不了（%s：%s）" % (type(exc).__name__, exc)], "修訂": ""}
    with io.open(place(outdir, "修訂驗證.json"), "w", encoding="utf-8") as f:
        json.dump(dict(result, 定稿=os.path.basename(summary["定稿"])), f, ensure_ascii=False, indent=2)
    if result["通過"]:
        say("  修訂自動驗過：全部接受＝乾淨版、全部拒絕＝草稿（%s）" % result["修訂"])
    else:
        text = "修訂自動驗證沒過：%s；請用 Word 開 新版_定稿.docx 看修訂" % "；".join(result["問題"])
        say("[警告] " + text)
        nt.write_notices(outdir, append=True, title="修訂驗證",
                         entries=[{"等級": nt.WARNING, "來源": "修訂驗證", "文字": text}])
    return result


def _warn_if_unverified(outdir):
    """套用後的修訂自動驗證沒過（系統檔案/修訂驗證.json）：驗收也要算這一則警告（A4）。
    以前只寫進套用那一次的提醒，驗收不知道，三問皆零就說改好——人根本沒看過修訂。
    文字跟套用時那一則一樣，人工確認表的警告列對得回去；人看過填「已確認」才算改好。"""
    import notices as nt
    path = locate(outdir, "修訂驗證.json")[0]
    try:
        with io.open(path, encoding="utf-8") as f:
            result = json.load(f)
    except (OSError, ValueError):
        return
    if not result.get("通過"):
        nt.notice(nt.WARNING, "修訂自動驗證沒過：%s；請用 Word 開 新版_定稿.docx 看修訂"
                  % "；".join(result.get("問題") or ["（沒有記原因）"]), "修訂驗證")


def cmd_apply(args, settings):
    import apply_changes as ac
    import decision_table as dt
    import notices as nt
    outdir = resolve_outdir(args, settings)
    # I1：算出來的產出資料夾要寫回 args——沒有 --outdir 的時候 args.outdir 一直是空的，
    # main() 的 _abort_notice 就找不到資料夾可以接寫 提醒.txt，中止原因只剩畫面上
    # 那一行。_compare_core 早就這樣做了，apply 這邊漏了。
    args.outdir = outdir
    # no 10／11：先驗草稿格式、決定表存在、產出資料夾可寫，過了才動檔案。
    # sidecar 不列進 other_paths：它由 dt 自己容錯（舊的決定表可能根本沒有）。
    problem = precheck(outdir, doc_paths=[args.draft], other_paths=[args.decisions],
                       docx_only=[args.draft])
    if problem:
        say("[中止] %s" % problem)
        return 1
    # 舊排法的產出資料夾照舊讀得到，但要講一聲；三件套仍寫進 審閱文件/。
    # 這一則走 notice_pending（見 _common.warn_legacy_layout），ac.apply 開頭的
    # nt.reset() 清不掉它，提醒.txt 裡才留得住。
    warn_if_legacy_outdir(outdir)
    stage_inputs(outdir, [args.draft, args.decisions, dt.sidecar_path_for(args.decisions)])
    try:
        summary = ac.apply(args.draft, args.decisions, outdir)
    except (ac.ApplyError, dt.DecisionTableError) as exc:
        say("[中止] %s" % exc)
        # 中止時 apply 沒有寫任何產出檔，但「為什麼中止」一定要留下來：
        # 畫面上的這一行是唯一的線索，而畫面留不住。
        # 先記成一則警告再寫檔——有些中止（例如草稿指紋不符）是在 apply 發任何
        # 提醒之前就丟出來的，不記的話 提醒.txt 會寫著「本次沒有提醒」，
        # 那份檔案等於在說「這次沒事」。
        nt.notice(nt.WARNING, "apply 中止：%s" % exc, "套用")
        # 跟成功路徑一樣接寫：中止也不可以把 compare 那一段洗掉。
        say("提醒留底：%s" % nt.write_notices(outdir, append=True,
                                             title="apply（第 3 步　套用，中止）"))
        return 1
    say("=" * 60)
    say("第 3 步　套用完成")
    say("=" * 60)
    tally = summary["統計"]
    for key, value in sorted(tally.items()):
        say("  %-14s %d 列" % (key, value))
    # 跳過有兩類，畫面上長得一樣，人要分得出來（no 35）：
    #   程式做不到的（SKIP_BLOCKING）＝真的沒改到，finalize 第一問會擋；
    #   人自己填了「改」但填的字等於原文＝人決定不改，不擋。
    # 警告那一則 ac.apply 已經記進 提醒.txt 與 套用報告.txt，這裡印的是同一句。
    blocked = ac.blocked_rows(tally)
    chosen = tally.get(ac.SAME_TEXT_STATUS, 0)
    if blocked:
        say("[警告] " + ac.blocked_message(tally))
    if chosen:
        say("[提醒] 有 %d 列填了改但等於原文，視為不改，不擋驗收" % chosen)
    say("定稿：%s" % summary["定稿"])
    say("乾淨版：%s" % summary["乾淨版"])
    say("報告：%s" % summary["報告"])
    say("提醒留底：%s（%d 則）" % (summary["提醒"], len(nt.collected())))
    verified = _verify_applied(outdir, args.draft, summary)
    fin = _cmd("finalize", "<舊版.docx>", summary["乾淨版"], "--decisions", args.decisions,
               "--outdir", outdir)
    if blocked:
        say("下一步：先處理上面 %d 列，然後跑 %s" % (blocked, fin))
    elif verified["通過"]:
        say("下一步：修訂已自動驗過，直接跑 %s（送簽前用 Word 開 審閱文件/新版_定稿.docx 看一次版面即可）" % fin)
    else:
        say("下一步：修訂自動驗證沒過，請用 Word 開 審閱文件/新版_定稿.docx 看修訂，然後跑 %s" % fin)
    say("最終仍需人工複核。")
    return 0


# ---------------------------------------------------------------------------
# compare / finalize 共用
# ---------------------------------------------------------------------------

# Step 2 四個門檻旗標：終比對（finalize／batch-finalize）沒有在命令列另外指定時，
# 要沿用初比對指紋檔記的「比對參數」，不是悄悄退回這裡的硬預設。
_COMPARE_PARAM_KEYS = ("threshold", "top", "changed_top", "sentence_threshold")


def _compare_param_fallbacks(runner):
    """真的什麼都沒有時（指紋檔是這個功能之前產生的、或根本沒有 recorded）才用的
    最後一層預設值，跟 regdiff 自己的常數一致。"""
    return {"threshold": runner.fuzzy.DEFAULT_THRESHOLD, "top": runner.fuzzy.DEFAULT_TOP,
           "changed_top": 8, "sentence_threshold": runner.fuzzy.DEFAULT_SENTENCE_THRESHOLD}


def _compare_params_with_fallback(runner, recorded=None):
    """recorded（通常是某本指紋檔的「比對參數」）有記的鍵就用它，沒記的鍵（或整個
    沒給）退回 _compare_param_fallbacks。回傳四個鍵都有值的完整 dict。"""
    out = _compare_param_fallbacks(runner)
    if recorded:
        for key in _COMPARE_PARAM_KEYS:
            if key in recorded:
                out[key] = recorded[key]
    return out


def _fill_compare_defaults(args, runner, recorded=None):
    """把 args 上這四個旗標裡使用者命令列沒給的（build_parser 把它們 default 設
    None）補上值：recorded 有記就沿用，沒記就退回 regdiff 的硬預設。回傳「這次
    真的是從 recorded 沿用過來」的那幾個鍵值（呼叫端拿這個判斷要不要印「沿用」
    訊息——使用者自己在命令列指定的、或 recorded 根本沒有記錄的，都不算沿用）。"""
    resolved = _compare_params_with_fallback(runner, recorded)
    inherited = {}
    for key in _COMPARE_PARAM_KEYS:
        if getattr(args, key, None) is None:
            setattr(args, key, resolved[key])
            if recorded and key in recorded:
                inherited[key] = resolved[key]
    return inherited


def _compare_params_from_args(args):
    return dict((key, getattr(args, key)) for key in _COMPARE_PARAM_KEYS)


def _say_inherited_params(prefix, params):
    say("%s：相似 %g、前幾筆 %d、改動文字前 %d 筆、句 %g"
        % (prefix, params["threshold"], params["top"], params["changed_top"],
           params["sentence_threshold"]))


DEFAULT_TABLE_TITLE = "修正對照表"


def table_title(name):
    """修正對照表 Word 版的標題：「<規章名>修正對照表」（規章名見 workspace.display_name）。
    以前每一本都只寫「修正對照表」，一批十本印出來分不出哪張是哪一本。"""
    import workspace as wsm
    text = wsm.display_name(name)
    return (text + DEFAULT_TABLE_TITLE) if text else DEFAULT_TABLE_TITLE


def _abort_notices(outdir, args, reason):
    """比對中止也要寫 提醒.txt（B9）：中止前已經印過的提醒（追蹤修訂、自動編號…）加上中止原因，
    一句都不能只留在畫面上。"""
    import notices as nt
    nt.notice(nt.WARNING, "比對中止：%s" % reason, "比對")
    try:
        nt.write_notices(outdir, getattr(args, "prefix", "") or "", title="比對（中止）")
    except OSError:
        pass


def _compare_core(args, settings, final, write_table=True):
    """跑 regdiff 的 Step 0.5→1→1.2→1.6→2，再合成連帶決定表。回傳 (rc, outcome, rows, outdir)。

    write_table=False 時只算不寫表：batch 要等所有本的第 0、1 步都過了才寫，
    中途中止才不會在產出資料夾留下前幾本的決定表。"""
    import decision_table as dt
    runner = load_regdiff_runner()
    if (getattr(args, "title", "") or DEFAULT_TABLE_TITLE) == DEFAULT_TABLE_TITLE:
        # 沒給 --title：用舊版檔名當規章名（批次的規章名就是舊版檔名去掉副檔名）
        args.title = table_title(os.path.splitext(os.path.basename(args.old_file or ""))[0])
    outdir = resolve_outdir(args, settings)
    # no 10／11：舊版、新版的存在與格式，還有產出資料夾能不能寫，全部在
    # makedirs／stage_inputs 之前驗完。以前這幾件事要等 read_paragraphs
    # （比對跑到一半）才發現，那時候殘骸已經留在硬碟上了。
    problem = precheck(outdir, doc_paths=[args.old_file, args.new_file])
    if problem:
        say("[中止] %s" % problem)
        return 1, None, [], outdir
    # 舊版與新版常常同檔名，一定要帶角色留底，不然後複製的會蓋掉先複製的
    # compare 換檔重跑會整套重算，覆寫留底是正常流程，只用「提醒」不用「警告」。
    import notices as nt
    stage_inputs(outdir, [args.old_file, args.new_file], roles=["舊版", "新版"],
                 overwrite_level=nt.REMINDER)
    nt.carry_over()          # run_compare 開頭的 reset() 不能把留底的提醒清掉（B9）
    args.outdir = outdir
    if not final:
        _retire_previous_results(outdir)
    if final:
        args.prefix = "最終版"
        # 終比對比的是「原始草稿 → 套用後的乾淨版」：決定表一列都沒填時 0 異動是
        # 正常結果，不是「拿錯檔」，這裡不發零異動提醒（裁定 7 只講單本 compare）。
        args.zero_change_level = None
    try:
        outcome = runner.run_compare(args)
    except runner.BaselineReleaseError as exc:
        say("[中止] 正式基準驗證失敗：%s" % exc)
        _abort_notices(outdir, args, "正式基準驗證失敗：%s" % exc)
        return 1, None, [], outdir
    except runner.CompareAbort as exc:
        # 讀檔防呆沒過（例如任一邊 0 段）。這裡就收掉，不能讓後面的步驟
        # 拿著空的一邊產出一份「整本條文全部刪除」的正式對照表還 exit 0。
        say("[中止] %s" % exc)
        _abort_notices(outdir, args, str(exc))
        return 1, None, [], outdir

    _settle_unchanged_book(outdir, outcome)
    results = outcome["results"]
    baseline = outcome["baseline"]
    new_line_ids = baseline.annotate_results(results) if baseline else {}
    semantic_rows = []
    if getattr(args, "semantic", None):
        import semantic_candidates as sc
        try:
            semantic_rows = sc.read_results(args.semantic, expected_sha=file_sha256(args.new_file))
        except sc.SemanticError as exc:
            say("[中止] 語意候選檔不能用：%s" % exc)
            return 1, None, [], outdir
    rows = dt.build_rows(outcome["csv_rows"], outcome["changed_rows"],
                         outcome["review_rows"], new_line_ids,
                         outcome["new_paragraphs"], semantic_rows,
                         sentence_rows=outcome.get("sentence_rows"),
                         change_types=dt.change_type_map(results, baseline),
                         change_positions=dt.change_position_map(results, baseline))
    # 章節重編後指錯的引用（Step 0.5）也是要人決定改不改的一段：進決定表，
    # 「建議改法」由 row_assist.annotate 照位置改寫好，填「改」就能 apply
    rows = dt.add_outline(rows, outcome.get("章節引用"))
    if write_table:
        changed_texts = [r["new_text"] for r in results if r["type"] in ("added", "modified")]
        if final:
            # 終比對候選表是「人只要看」的表（三問的佐證），不回頭被程式讀 → 審閱文件/、
            # 而且改出 xlsx（欄寬、換行、粗體標題列留得住）。指紋檔照舊是中繼檔 →
            # 系統檔案/（sidecar_path_for 會從 審閱文件/ 往上找一層）。
            table_path = place(outdir, "終比對候選表.xlsx")
            json_path = dt.sidecar_path_for(table_path)
            fmt = "xlsx"
        else:
            # 連帶決定表是「人要填、程式回頭讀」的表 → 填寫表單/，格式不能變（csv）；
            # 它的指紋檔是程式接力用的中繼檔 → 系統檔案/（不放在表旁邊）。
            # 寫之前先補「異動內容／建議改法」，並把上一輪填過的決定帶過來——
            # 一定要在寫檔之前：單本重跑到同一個資料夾時，上一輪的表就是即將被蓋掉的那一份。
            carried, had_previous = _assist_rows(rows, outdir, dt.change_items(results))
            outcome["沿用"] = carried if had_previous else None
            table_path = place(outdir, "連帶決定表.csv")
            json_path = place(outdir, "連帶決定表.json")
            fmt = "csv"
        written = []
        dt.write_table(rows, table_path, json_path, args.new_file, changed_texts,
                       params=_compare_params_from_args(args), fmt=fmt, written=written,
                       old_path=args.old_file)
        # 產出清單印的是**真的寫出來的**那幾個檔：xlsx 寫不出來時退成 csv，
        # 檔名跟 table_path 不一樣，印 table_path 會叫人去找一個不存在的檔。
        outcome["produced"].extend(written)
        # 指紋檔跟 異動清單.json／語意輸入.json 一樣是系統檔案，清單也列出來（全波審查：
        # 三份 json 只列兩份沒道理）。
        if os.path.isfile(json_path):
            outcome["produced"].append(json_path)
        if not final:
            # finalize（final=True）的新舊版是「原始草稿→套用後的乾淨版」，跟第 1 步初比對
            # 記的「異動清單.json」是完全不同的一組異動；finalize 若也覆寫它，review-pack／
            # review-import 已經做過的第 1.5 步就對不上了（表和 AI 判斷指的是舊的異動清單）。
            # 這裡只在初比對時寫，finalize 沿用同一個 outdir 時異動清單.json 維持原樣。
            change_list_path = place(outdir, "異動清單.json")
            dt.write_change_list(results, change_list_path)
            outcome["produced"].append(change_list_path)
    return 0, outcome, rows, outdir


def _assist_rows(rows, outdir, items, books=None):
    """寫決定表之前：補「異動內容／建議改法」，並沿用上一輪的決定。
    回傳 (沿用了幾列, 有沒有上一輪的表)。沒有上一輪（第一次跑）時不必講「沿用 0 列」。
    沿用幾列由呼叫端印在畫面與批次摘要上（這時候各本的 提醒.txt 已經寫完了）。"""
    import row_assist as ra
    ra.annotate(rows, items, books)
    previous = ra.previous_round(outdir)
    return ra.carry_over(rows, items, previous), previous is not None


def source_distribution(rows):
    """{來源組合: 列數}。**一列只算一次**（小瑕疵 13）。

    以前是把每一列的「來源」用「；」拆開、每個標籤各記一次，於是同時被相似度與
    語意抓到的那一列會在兩個桶子裡各算一遍，括號裡的數字加起來大於「候選 N 列」。
    人看到「候選 12 列（相似 9、語意 6）」會以為自己數錯，或以為表上少了幾列。
    改成一列只進一個桶子，桶名就是它的來源組合（相似＋語意），加起來剛好是列數。
    """
    dist = {}
    for row in rows:
        labels = [s for s in (row.get("來源") or "").split("；") if s]
        key = "＋".join(labels) if labels else "無來源"
        dist[key] = dist.get(key, 0) + 1
    return dist


def under_outdir(outdir, path):
    """產出檔印給人看的位置：產出資料夾底下的相對路徑，例如 結果彙整/修正對照表.xlsx。

    以前印 os.path.basename(path)，那是檔案平鋪時代的寫法——現在檔案分在三格裡，
    只印檔名的話人拿著「修正對照表.xlsx」在產出資料夾第一層翻不到。
    分隔符一律印「/」：這幾行是「在哪一格」的指路，不是要人複製貼上的完整路徑
    （完整路徑另外有一行「產出資料夾：」）。
    """
    try:
        rel = os.path.relpath(path, outdir)
    except ValueError:      # Windows 跨磁碟機
        return path
    if rel.startswith(".."):
        return path
    return rel.replace(os.sep, "/")


def _print_compare_summary(title, outcome, rows, outdir):
    counts = {}
    for r in outcome["results"]:
        counts[r["type"]] = counts.get(r["type"], 0) + 1
    sources = source_distribution(rows)
    say("")
    say("=" * 60)
    say(title)
    say("=" * 60)
    # 「僅字形／空白差異」要單獨報一個數：它不是實質異動、也不是編號調整，
    # 併進任何一邊都會讓人以為有東西真的改了。
    say("實質異動 %d 處（新增 %d、刪除 %d、修改 %d），編號調整 %d 處，僅字形／空白差異 %d 處"
        % (counts.get("added", 0) + counts.get("deleted", 0) + counts.get("modified", 0),
           counts.get("added", 0), counts.get("deleted", 0), counts.get("modified", 0),
           counts.get("renumbered", 0), counts.get("cosmetic", 0)))
    say("候選 %d 列（%s）" % (len(rows), "、".join("%s %d" % kv for kv in sorted(sources.items())) or "無"))
    say("產出資料夾：%s" % outdir)
    for path in outcome["produced"]:
        say("  " + under_outdir(outdir, path))


# 工作區模式時，畫面上的路徑印成「工作區/」底下的相對路徑（工作區根目錄在開頭印一次）。
# 以前每個路徑都印完整絕對路徑，一行歸檔訊息就占四行，要看的字被擠到畫面外。
_DISPLAY_ROOT = [None]


def _set_display_root(root):
    if root and _DISPLAY_ROOT[0] != os.path.abspath(root):
        _DISPLAY_ROOT[0] = os.path.abspath(root)
        say("工作區：%s" % _DISPLAY_ROOT[0])


def show_path(path):
    """工作區底下的路徑印相對路徑（例：產出/審閱文件/批次摘要.txt），其餘照印完整路徑。"""
    root = _DISPLAY_ROOT[0]
    if root and path:
        try:
            rel = os.path.relpath(os.path.abspath(path), root)
        except ValueError:          # Windows 跨磁碟機
            return path
        if not rel.startswith(".."):
            return rel.replace(os.sep, "/")
    return path


def archive_line(moved):
    """「已歸檔上一輪」那一行：不再逐一列出每個目的地的完整路徑（位置都是固定的）。"""
    stamp = os.path.basename(moved[0])
    return "已歸檔上一輪：%s（%d 處，都在各自的 系統檔案/歷次/%s/）" % (stamp, len(moved), stamp)


def workspace_flag(args):
    """印給人複製的指令要不要帶 --workspace：工作區就是設定檔（或預設）那一個時不用帶。"""
    given = getattr(args, "workspace", "") or ""
    if not given:
        return ""
    try:
        import workspace as wsm
        default = wsm.resolve_root("", load_settings())
    except Exception:
        default = ""
    if default and os.path.normcase(os.path.abspath(given)) == os.path.normcase(os.path.abspath(default)):
        return ""
    return '--workspace "%s"' % given


def _cmd(name, *parts):
    """印給人複製貼上的指令：含空白的路徑加雙引號，不然會被拆成兩段。"""
    return _script_cmd("run_all.py", name, *parts)


def _script_cmd(script, *parts):
    """scripts/ 底下任一支的指令，寫法跟 _cmd 一樣（一律 python scripts/…，從 reg 根目錄照抄就能跑）。"""
    out = ["python scripts/%s" % script]
    for part in parts:
        if not part:
            continue
        out.append('"%s"' % part if (" " in part and not part.startswith("--")) else part)
    return " ".join(out)


def _say_semantic_manual(why, input_path, result_path, table_path):
    """單本：這台電腦算不了語意候選時，印兩行照抄就能跑的指令（路徑都填好）。"""
    say("")
    say("語意候選（BGE-M3）：%s，跳過。要用的話在有模型的電腦跑：" % why)
    say("  " + _script_cmd("semantic_candidates.py", input_path, result_path, "--model", "<模型資料夾>"))
    say("算好之後回到這台併入（已填的決定不動）：")
    say("  " + _cmd("semantic", table_path, result_path))


def say_next_after_compare(batch=False, ws="", outdir="", old_file="", draft=""):
    """初比對之後的「下一步」：全案只有這一組，照做的順序寫，岔路講清楚。

    以前 compare／batch／開始 各講各的：batch 說「填決定再 batch-apply」，開始又列
    review-pack → review-import → apply → finalize 四個指令，人看不出 AI 審查是選配、
    決定要在哪一步之後填。ws：workspace_flag() 的結果（要不要帶 --workspace）。
    """
    say("")
    if batch:
        # 批次的下一步只有一個來源：最後印的「下一步（人工待辦）」那一段（見 todo.SCREEN_HEADER）。
        # 以前這裡另列一組，跟人工待辦講的順序不一樣，人不知道照哪一組
        say("最終仍需人工複核。")
        return
    pack, imp = _cmd("review-pack", outdir), _cmd("review-import", outdir)
    table = "填寫表單/連帶決定表.csv"
    table_path = os.path.join(outdir, "填寫表單", "連帶決定表.csv")
    apply_cmd = _cmd("apply", draft, table_path, "--outdir", outdir)
    clean = "審閱文件/新版_定稿.docx"
    fin = _cmd("finalize", old_file, os.path.join(outdir, "審閱文件", "新版_定稿_乾淨版.docx"),
               "--decisions", table_path, "--outdir", outdir)
    say("下一步（照順序）：")
    approve_cmd = _cmd("核准", table_path, "--預覽")
    say("  1. AI 審查（建議）：跑 %s，AI 填好 AI 表後跑 %s；不用 AI 就跳過" % (pack, imp))
    say("  2. 用 Excel 開 %s 填「要改嗎」：填「改」、「改成什麼」留空就照「建議改法」改；"
        "AI 建議很明確的列可以先跑 %s 看，確認後拿掉 --預覽 一次決定；"
        "「沿用上一輪」寫「是」的列已帶入上一輪的決定" % (table, approve_cmd))
    say("  3. %s（套用完會自動驗修訂：全部接受＝乾淨版、全部拒絕＝草稿）" % apply_cmd)
    say("  4. %s（修訂自動驗證沒過的才要用 Word 開 %s 看）" % (fin, clean))
    say("最終仍需人工複核。")


def cmd_compare(args, settings):
    import decision_table as dt
    runner = load_regdiff_runner()
    _fill_compare_defaults(args, runner)  # 初比對沒有可沿用的來源，沒給的旗標一律用硬預設
    rc, outcome, rows, outdir = _compare_core(args, settings, final=False)
    if rc:
        return rc
    semantic_rows = _write_semantic_input(args, outcome, outdir, settings)
    if semantic_rows:
        import row_assist as ra
        rows = dt.add_semantic(rows, semantic_rows)
        # 語意列是新加的，也要有異動內容／建議改法（沿用上一輪在 _compare_core 已經做過）
        ra.annotate(rows, dt.change_items(outcome["results"]))
        csv_path = place(outdir, "連帶決定表.csv")
        changed_texts = [r["new_text"] for r in outcome["results"] if r["type"] in ("added", "modified")]
        dt.write_table(rows, csv_path, place(outdir, "連帶決定表.json"),
                       args.new_file, changed_texts,
                       params=_compare_params_from_args(args), old_path=args.old_file)
    _print_compare_summary("第 1 步　初比對完成", outcome, rows, outdir)
    carried = outcome.get("沿用")
    if carried is not None:
        say("沿用上一輪決定 %d 列（候選與異動都沒變）；其餘 %d 列是新的或有變，要重新看"
            % (carried, len(rows) - carried))
    if outcome.get("零異動"):
        # 0 異動時叫人去填一張空表是最糟的收尾：他會以為是自己看不懂。
        # 警告在上面（run_compare 裡）已經發過、也留了底，這裡只把下一步換掉。
        say("下一步：確認檔案沒拿錯；若確實沒改，這本不需要處理。")
    else:
        say_next_after_compare(outdir=outdir, old_file=args.old_file, draft=args.new_file)
    return 0


def _semantic_recall_top(settings):
    """設定檔的「語意粗篩」：留空（null／""）就全排名；填數字 N 就只對純語意前 N 名算三種分數。"""
    value = settings.get("語意粗篩")
    if value in (None, "", 0, "0"):
        return None
    return int(value)


def _semantic_threshold(settings):
    """設定檔的「語意門檻」：留空（null／""）就交給分數器用自己的預設
    （三分數合併 0.70、只有 dense 0.75，見 semantic_candidates）。"""
    value = settings.get("語意門檻")
    if value in (None, ""):
        return None
    return float(value)


def _write_semantic_input(args, outcome, outdir, settings):
    """一律寫語意輸入.json；模型載得起就當場算並併入，否則印手動指令。回傳語意列。"""
    import semantic_candidates as sc
    # 「舊全文」給語意那邊找「改到的那幾句」用（沒有就整段去比）。
    changes = [{"段次": r["new_index"], "全文": r["new_text"], "舊全文": r.get("old_text") or "",
                "條文ID": "、".join(r.get("spec_ids") or [])}
               for r in outcome["results"]
               if r["type"] in ("added", "modified") and r.get("new_index")]
    draft_sha = file_sha256(args.new_file)
    input_path = place(outdir, "語意輸入.json")
    sc.write_input(input_path, args.new_file, draft_sha, changes, outcome["new_paragraphs"])
    outcome["produced"].append(input_path)
    if getattr(args, "semantic", None):
        return []      # 使用者已經給了算好的檔，_compare_core 併過了
    model_path = settings.get("語意模型路徑", "")
    manual = (input_path, place(outdir, "語意候選.csv"), place(outdir, "連帶決定表.csv"))
    if not model_path:
        _say_semantic_manual("這台電腦沒設定模型", *manual)
        return []
    say("語意候選（BGE-M3）：載入 %s" % model_path)
    embed = sc.load_model(model_path, recall_top=_semantic_recall_top(settings))
    if embed is None:
        # 以前這裡寫「見上面兩行指令」，但那兩行只有在沒設模型路徑時才印，人找不到
        _say_semantic_manual("模型載不起來（沒裝 FlagEmbedding／sentence_transformers，或路徑不對）", *manual)
        return []
    rows = sc.find_candidates(embed, changes, outcome["new_paragraphs"],
                              _semantic_threshold(settings),
                              int(settings.get("語意最多幾筆", sc.DEFAULT_TOP)))
    result_path = place(outdir, "語意候選.csv")
    sc.write_results(result_path, rows, draft_sha)
    outcome["produced"].append(result_path)
    return rows


def _warn_if_clean_has_revisions(path):
    """終比對的「新版」是定稿乾淨版。它還帶著追蹤修訂就是出事了。

    乾淨版的定義就是「修訂全部接受過」。還有修訂記號代表這份檔不是 apply 產的，
    或是有人在 apply 之後又在 Word 裡改過——而本程式一律以「已接受修訂」的內容
    比對，三問會全部是零、結論寫「改好」，那份帶著修訂記號的檔卻會直接被拿去切條。
    只提醒不擋：確實有人需要拿別的檔跑終比對。
    """
    import notices as nt
    if not str(path or "").lower().endswith(".docx") or not os.path.isfile(path):
        return
    import xml.etree.ElementTree as ET
    import zipfile
    from _common import count_tracked_changes, describe_tracked_changes
    try:
        with zipfile.ZipFile(path) as archive:
            root = ET.fromstring(archive.read("word/document.xml"))
    except (OSError, KeyError, zipfile.BadZipFile, ET.ParseError) as exc:
        # 「沒印警告」跟「檢查過、沒有修訂」在畫面上長得一模一樣。讀不動的時候
        # 什麼都不說，等於默默把這一項降級成「沒問題」——而這一項要擋的正是
        # 「一份還帶著追蹤修訂的定稿被直接送出」。所以改印「未檢查」。
        nt.notice(nt.REMINDER,
                  "定稿追蹤修訂檢查：未檢查（讀不到 %s：%s）；"
                  "這一項沒跑到，不代表定稿沒有追蹤修訂"
                  % (os.path.basename(str(path)), exc), "第 4 步")
        return
    counts = count_tracked_changes(root)
    if any(counts.values()):
        nt.notice(nt.WARNING,
                  "定稿仍含追蹤修訂（%s）：終比對是以「已接受修訂」的內容比對的，"
                  "三問的結論不涵蓋這些還沒被接受或拒絕的修訂；"
                  "請在 Word 裡處理掉再另存乾淨版" % describe_tracked_changes(counts),
                  "第 4 步")


# 初比對產生、終比對之後會有「最終版_」對應版本的成品
_FIRST_ROUND_RESULTS = ("修正對照表.xlsx", "修正對照表.docx", "修正對照表.csv",
                        "標註版全文.docx", "標註版全文.txt")


def _settle_result_folder(outdir, clean_path):
    """終比對之後整理 結果彙整/：只留要交的那一套。

    - 初比對那一套（草稿對舊版）改名「初比對_」移進 審閱文件/ 當紀錄——只移已經有
      「最終版_」對應檔的那幾個，終比對沒產出的就照舊留著。
    - 新版定稿複製一份進來：乾淨版（要發布的那一份）與帶追蹤修訂的那一份（要送簽的
      那一份）。原檔留在 審閱文件/：finalize 重跑、下一輪切條都還要讀它。
    以前終比對之後 結果彙整/ 同時有兩套對照表、兩套標註版，要交的定稿卻不在裡面。
    """
    from _common import result_home
    folder = result_home(outdir)
    if os.path.isfile(os.path.join(folder, UNCHANGED_NOTE)):
        return []         # 整本沒改：定稿跟舊版一樣，不放一份會被誤當成要送核的定稿
    # 要交的那一套一律用原本的檔名（修正對照表.xlsx、標註版全文.docx），不帶「最終版_」：
    # 結果彙整裡只會有一套，前綴只會讓人以為還有別的版本。終比對寫出來的是「最終版_」，
    # 這裡改回原名。已經整理過一次（重跑 finalize）時，原名那一份是上一次的最終版，直接蓋掉，
    # 不能當成初比對那一套搬走——那樣會把真正的初比對紀錄蓋掉。
    already_final = _is_final_set(folder)
    for name in _FIRST_ROUND_RESULTS:
        final = os.path.join(folder, "最終版_" + name)
        if not os.path.isfile(final):
            continue
        plain = os.path.join(folder, name)
        if os.path.isfile(plain) and not already_final:
            os.replace(plain, place(outdir, "初比對_" + name))
        os.replace(final, plain)
    pairs = [(clean_path, "新版定稿_乾淨版.docx")]
    if os.path.basename(clean_path) == "新版_定稿_乾淨版.docx":
        pairs.append((os.path.join(os.path.dirname(clean_path), "新版_定稿.docx"), "新版定稿_追蹤修訂.docx"))
    copied = []
    for src, name in pairs:
        if os.path.isfile(src):
            dest = place(outdir, name)
            if os.path.abspath(src) != os.path.abspath(dest):
                shutil.copy2(src, dest)
            copied.append(dest)
    return copied


UNCHANGED_NOTE = "本次未修改.txt"
_CHANGE_TYPES = ("added", "deleted", "modified", "renumbered", "cosmetic")


def _settle_unchanged_book(outdir, outcome):
    """批次裡這一本新舊版一處都沒變（多半是清單裡沒放新版草稿、別本的連帶也決定不改）：
    這一本內部的 結果彙整/ 只放一張「本次未修改」說明（產出/結果彙整/本次未修改.txt 由 result_publish 列出是哪幾本）。

    以前照樣產一整套：沒有任何一列的修正對照表、沒有任何標註的標註版全文、內容跟舊版
    一模一樣的兩份新版定稿。人打開結果彙整看到齊全的一套，會以為這一本也要送核。
    那幾份空的改名「無異動_」移進 審閱文件/ 當紀錄。單本 compare 不走這裡：只比一本時
    0 異動多半是拿錯檔，那一份寫著「本次無實質異動」的對照表本身就是證據（小瑕疵 3）。
    後來又有改動（重跑之後不再是 0）就把說明拿掉。"""
    from _common import batch_root_of, result_home
    if not batch_root_of(outdir):
        return
    folder = result_home(outdir)
    note = os.path.join(folder, UNCHANGED_NOTE)
    if any(r["type"] in _CHANGE_TYPES for r in outcome["results"]):
        if os.path.isfile(note):
            os.remove(note)
        return
    moved = {}
    if os.path.isdir(folder):
        for name in sorted(os.listdir(folder)):
            if name != UNCHANGED_NOTE:
                dest = place(outdir, "無異動_" + name)
                os.replace(os.path.join(folder, name), dest)
                moved[os.path.normcase(os.path.abspath(os.path.join(folder, name)))] = dest
    name = os.path.basename(os.path.abspath(outdir))
    os.makedirs(folder, exist_ok=True)
    with io.open(note, "w", encoding="utf-8-sig") as f:
        f.write("%s：本次沒有修改\n\n"
                "新版與舊版內容完全相同，這一本不需要送核，所以這裡沒有修正對照表、標註版全文與新版定稿。\n"
                "這一本仍有比對過：別本的改動要不要帶過來，看 產出/系統檔案/%s/填寫表單/連帶決定表.csv"
                "（填「改」重跑 batch-apply、batch-finalize 之後，這裡就會換成正式的一套）。\n"
                "比對紀錄在 產出/系統檔案/%s/審閱文件/（檔名開頭「無異動_」的是這一輪的空白對照表）。\n"
                % (name, name, name))
    produced = []
    for path in outcome.get("produced") or []:
        key = os.path.normcase(os.path.abspath(path))
        produced.append(moved.get(key, path))
    outcome["produced"] = produced + [note]


def _retire_previous_results(outdir):
    """重跑初比對時，上一輪留在 結果彙整/ 的最終版與定稿改名「上一輪_」移進 審閱文件/。
    不移的話，新一輪的對照表旁邊擺著上一輪的最終版，人分不出哪一套是現在的。"""
    from _common import result_home
    folder = result_home(outdir)
    if not os.path.isdir(folder):
        return
    # 終比對整理過的那一套用的是原本的檔名（見 _settle_result_folder），靠「新版定稿_乾淨版.docx
    # 在不在」認出來；改名成「上一輪_最終版_」，跟以前留下的紀錄同一個名字
    final_set = _is_final_set(folder)
    for name in sorted(os.listdir(folder)):
        if name.startswith(("最終版_", "新版定稿_")):
            os.replace(os.path.join(folder, name), place(outdir, "上一輪_" + name))
        elif final_set and name in _FIRST_ROUND_RESULTS:
            os.replace(os.path.join(folder, name), place(outdir, "上一輪_最終版_" + name))


FINAL_MARKER = "新版定稿_乾淨版.docx"


def _is_final_set(folder):
    """這個 結果彙整 資料夾裡放的是不是終比對整理過的那一套（新版定稿只在終比對之後才會放進來）。"""
    return os.path.isfile(os.path.join(folder, FINAL_MARKER))


def _external_counts_text(counts):
    """「有誤 1 處、漏抓 0 處、需查證 2 處、沒問題 5 處」"""
    import scoring_rubric as sr
    return "、".join("%s %d 處" % (v, counts.get(v, 0)) for v in sr.EXTERNAL_VERDICTS)


def _confirm_suffix(answers):
    """驗收摘要那一行的「、人工待確認 N」：沒有待確認的就不加，沒跑 AI 審查的人看不到這個詞。"""
    import finalize_check as fc
    pending = len(answers.get(fc.CONFIRM_KEY) or [])
    return "、人工待確認 %d（人工確認.csv）" % pending if pending else ""


def _confirm_next_step(pending, where="填寫表單/人工確認.csv"):
    """review-import 之後，AI 查不到答案的（異動本身、條文檢查高風險、外部引用無法查證），
    要人回覆才算結案。"""
    if pending:
        say("另外：AI 查證後還有 %d 項要人確認（異動本身、條文檢查高風險、外部引用無法查證）——到 %s "
            "的「人工確認」欄填「已確認」（處理好之後；怎麼處理寫在「說明」欄）；沒填「已確認」的，驗收不會判改好。"
            % (pending, where))


def _rulecheck_counts_text(counts):
    import review_import as ri
    import scoring_rubric as sr
    return "、".join("%s %d 項" % (v, counts.get(v, 0))
                     for v in sr.RULECHECK_VERDICTS + (ri.NOT_REVIEWED,) if counts.get(v) or v != ri.NOT_REVIEWED)


def _staged_draft_paragraphs(decisions_path, sidecar):
    """決定表對應的那份草稿的段落（段次的座標系）；回傳 (段落 list 或 None, 找不到的原因)。

    草稿本身 finalize 拿不到（命令列只給舊版與乾淨版），但 compare 會把它留底在
    <產出>/系統檔案/輸入/。不猜檔名：跟 review-pack 共用 review_pack.staged_file_by_sha，
    找 SHA-256 跟決定表指紋檔記的草稿一模一樣的那一份。對不上就不用——
    拿錯的草稿算出來的「應有樣子」只會讓第一問亂報。
    呼叫端一定要在 finalize 自己的 stage_inputs 之前呼叫：同一個產出資料夾裡，
    乾淨版跟草稿同檔名時，留底會被乾淨版蓋掉。
    """
    import review_pack as rp
    from _common import read_paragraphs
    want = (sidecar.get("草稿") or {}).get("SHA256") or ""
    if not want:
        return None, "決定表的指紋檔沒有記草稿指紋"
    outdir = outdir_of_table(decisions_path)
    inputs_dir = locate(outdir, "輸入")[0]
    if not os.path.isdir(inputs_dir):
        return None, ("決定表所在的資料夾（%s）沒有 系統檔案/輸入/——請用產出資料夾裡的那一份"
                      "決定表（連同它的指紋檔）跑 finalize，不要用複製到別處的那一份" % outdir)
    path = rp.staged_file_by_sha(inputs_dir, want)
    if path is None:
        return None, ("系統檔案/輸入/ 裡找不到跟決定表指紋相符的草稿留底（留底被覆寫或修改過）；"
                      "請重跑 compare，再照順序 apply、finalize")
    try:
        return read_paragraphs(path), ""
    except (ValueError, OSError) as exc:
        return None, "草稿留底讀不出來（%s）" % exc


def _finalize_core(args, settings, extra=None):
    """第 4 步核心。回傳 (rc, answers, report_path, outdir)；rc 非 0 時其餘為 None。

    extra 給 dict 時，把這一本的中間結果填進去：「outcome」（比對結果，含
    results／new_paragraphs／baseline）、「final_rows」（終比對候選列）、
    「decision_rows」「sidecar」（初比對決定表與它的指紋檔）、「report_path」。
    batch-finalize 要等所有本都終比對完才算得出跨本連帶（來源是別本的定稿），
    那時候這些東西已經被這一支算過一次了，不給呼叫端拿就只能整本重跑一次比對。
    回傳值不動：單本 finalize 不必知道有這回事。"""
    import decision_table as dt
    import finalize_check as fc
    try:
        decision_rows = dt.read_table(args.decisions)
        sidecar = dt.read_sidecar(dt.sidecar_path_for(args.decisions))
    except dt.DecisionTableError as exc:
        say("[中止] %s" % exc)
        return 1, None, None, None
    # Step 2 四個門檻旗標：命令列沒給的（build_parser 把 compare／finalize 這幾個旗標
    # default 設 None）沿用初比對指紋檔記的「比對參數」，不是悄悄退回程式的硬預設——
    # 不然終比對候選表列出的候選會跟初比對兜不起來（見 decision_table.write_table）。
    runner = load_regdiff_runner()
    inherited = _fill_compare_defaults(args, runner, sidecar.get("比對參數"))
    if inherited:
        _say_inherited_params("終比對沿用初比對門檻", _compare_params_from_args(args))
    # 草稿留底要在 _compare_core 之前找：它會把乾淨版留底成「新版_<檔名>」，
    # 乾淨版跟草稿同檔名、又用同一個產出資料夾時，草稿留底就被蓋掉了。
    draft_paragraphs, no_draft_reason = _staged_draft_paragraphs(args.decisions, sidecar)
    # 修正對照表的「修改依據／理由」：只草擬查得到依據的，其餘寫「請補修正理由」
    import change_reasons as cr
    args.reason_fn = cr.make_drafter(args.decisions, outdir_of_table(args.decisions))
    try:
        rc, outcome, final_rows, outdir = _compare_core(args, settings, final=True)
    finally:
        reason_stats = dict(args.reason_fn.stats)
        args.reason_fn = None
    if rc:
        return rc, None, None, outdir
    cr.write_summary(outdir, reason_stats)
    stage_inputs(outdir, [args.decisions, dt.sidecar_path_for(args.decisions)])
    import notices as nt
    # 這一則要在 _compare_core 之後才發：run_compare 開頭會清空提醒清單。
    _warn_if_clean_has_revisions(args.new_file)
    _warn_if_unverified(outdir_of_table(args.decisions))
    # 決定表所在的那個產出資料夾（多半是初比對那一輪）是不是舊排法。
    # 終比對自己的產出（--outdir）一律寫進新格。
    warn_if_legacy_outdir(outdir_of_table(args.decisions))
    # 乾淨版一律讀原檔：outcome["new_paragraphs"] 可能被 --apply-renumber 改寫過，
    # 而決定表的段次、apply 寫進乾淨版的字，都是對著原檔算的。
    from _common import read_paragraphs
    answers = fc.three_questions(decision_rows, sidecar, read_paragraphs(args.new_file),
                                 final_rows, draft_paragraphs=draft_paragraphs)
    # AI 查不到答案、人還沒回覆的：也擋「改好」（見 review_import 的人工確認）
    import review_import as ri
    answers[fc.CONFIRM_KEY] = ri.pending_confirmations(outdir_of_table(args.decisions))
    if not answers.get("對位"):
        nt.notice(nt.WARNING,
                  "第一問沒有做對位檢查（%s），只能退回「改成什麼在乾淨版全文找不找得到」——"
                  "改成的字別處剛好已有時，沒改到的那一列也會被放行" % no_draft_reason,
                  "終比對")
    vanished = answers.get(fc.VANISHED_KEY) or []
    if vanished:
        nt.notice(nt.WARNING,
                  "有 %d 段草稿裡的條文在乾淨版裡對不上，決定表也沒有叫改或刪（例：%s）："
                  "可能是接受修訂時掉段、或有人在 Word 裡手改了；請逐段確認再送出"
                  % (len(vanished), fc.clip(vanished[0], 30)), "終比對")
    same_text = answers.get(fc.SAME_TEXT_KEY) or []
    if same_text:
        # 不擋結論，但一定要留底：這幾列在定稿上看不到任何修訂記號，
        # 只有這一則提醒說得出「它們是被人選成不改的，不是漏改」。
        nt.notice(nt.REMINDER,
                  "有 %d 列填了「改」但「改成什麼」跟原文一字不差（段次 %s），"
                  "定稿上沒有修訂記號，視為不改；真的要改請回決定表把「改成什麼」寫成改完的樣子"
                  % (len(same_text),
                     "、".join((r.get("候選段次") or "-") for r in same_text)),
                  "終比對")
    # 驗收冒出的新候選接進決定表（人在同一張表上決定，填完再套用、驗收）
    placed, unplaced = _append_fresh_rows(args.decisions, answers["新候選"], draft_paragraphs)
    answers[fc.APPENDED_KEY], answers[fc.UNPLACED_KEY] = placed, unplaced
    # 警告寫進人工確認表（類別「警告」），人回覆看過，結論才會是改好（見 fc.verdict）
    acknowledged = ri.sync_warnings(outdir_of_table(args.decisions), nt.warnings(nt.collected()))
    report_path = place(outdir, "終比對驗收報告.txt")
    # 這一輪的提醒整段抄進驗收報告：三問都是零、結論寫「改好」時，那個「改好」的
    # 前提（有幾處標不上去、有幾列跳過）一定要在同一張紙上看得到。
    fc.write_report(answers, report_path, notices=nt.collected(), acknowledged=acknowledged)
    # 重寫一次 最終版_提醒.txt：run_compare 在比對結束時寫過一份，但「定稿仍含
    # 追蹤修訂」是比對之後才判的，那一份還沒有它。
    nt.write_notices(outdir, "最終版")
    outcome["produced"].append(report_path)
    outcome["produced"].extend(_settle_result_folder(outdir, args.new_file))
    if extra is not None:
        extra.update({"outcome": outcome, "final_rows": final_rows,
                      "decision_rows": decision_rows, "sidecar": sidecar,
                      "report_path": report_path, "draft_paragraphs": draft_paragraphs,
                      "acknowledged": acknowledged})
    _print_compare_summary("第 4 步　終比對完成", outcome, final_rows, outdir)
    say("三問：未改到 %d、未決定 %d、新候選 %d%s" % (
        len(answers["未改到"]), len(answers["未決定"]), len(answers["新候選"]),
        _confirm_suffix(answers)))
    say("填了但等於原文 %d 列（視為不改）" % len(same_text))
    if reason_stats:
        say("修正對照表「修改依據／理由」：依據查得到的已草擬 %d 列（xlsx 最後一欄是依據來源），"
            "其餘 %d 列寫「%s」，送簽前要補" % (reason_stats.get("草擬", 0), reason_stats.get("請補", 0),
                                          cr.PLEASE_FILL))
    if nt.collected():
        say("本輪提醒 %d 則，見 終比對驗收報告.txt 的提醒段與 最終版_提醒.txt" % len(nt.collected()))
    return 0, answers, report_path, outdir


UNLISTED_FILE = "跨本未列.json"


def _write_unlisted(outdir_doc, entries):
    """「開始」時因為跨本上限沒列出來的段（見 batch.select_cross）：驗收不把它們算成新候選。"""
    with io.open(place(outdir_doc, UNLISTED_FILE), "w", encoding="utf-8") as f:
        json.dump(entries or [], f, ensure_ascii=False)


def _read_unlisted(outdir_doc):
    path = locate(outdir_doc, UNLISTED_FILE)[0]
    if not os.path.isfile(path):
        return set()
    try:
        with io.open(path, encoding="utf-8") as f:
            return set(entry.get("候選全文SHA256") for entry in json.load(f))
    except (OSError, ValueError, AttributeError):
        return set()


def _append_fresh_rows(table_path, fresh, draft_paragraphs):
    """驗收冒出的新候選（段次是定稿的）換成草稿的段次，接進連帶決定表。
    回傳 (接進去的列數, 草稿裡找不到同樣文字的列數)。找不到的（多半是套用之後才長出來的字）
    留在第三問，報告請人用 Word 直接看。"""
    import decision_table as dt
    if not fresh or not table_path or draft_paragraphs is None:
        return 0, len(fresh or [])
    positions = {}
    for i, text in enumerate(draft_paragraphs, 1):
        positions.setdefault(dt.normalize(text), []).append(i)
    placed, unplaced = [], 0
    for row in fresh:
        hits = positions.get(dt.normalize(row.get("候選全文") or ""), [])
        if not hits:
            unplaced += 1
            continue
        final_line = dt.line_of(row.get("候選段次"))
        line = min(hits, key=lambda i: abs(i - final_line)) if final_line else hits[0]
        placed.append(dict(row, 候選段次=str(line), 候選全文=draft_paragraphs[line - 1]))
    if placed:
        dt.append_rows(table_path, placed)
    return len(placed), unplaced


def cmd_finalize(args, settings):
    import finalize_check as fc
    import notices as nt
    rc, answers, report_path, _ = _finalize_core(args, settings)
    if rc:
        return rc
    total = fc.blocking_total(answers)
    # 檢視報告在結論之前彙整（main() 的收尾會印在結論後面，finalize 不走那一條）
    _refresh_one_report(args.outdir, args.decisions, announce=True)
    # 結論那一行跟報告檔共用 fc.verdict：三問皆零但有警告時不准只寫「改好」。
    # 路徑先印、結論擺最後：畫面被截斷時留在最後的要是結論。
    if total or nt.warnings():
        say("詳見 %s" % report_path)
    import review_import as ri
    acknowledged = ri.sync_warnings(outdir_of_table(args.decisions), nt.warnings(nt.collected()))
    say(fc.verdict(total, nt.collected(), acknowledged))
    return 0


def cmd_semantic(args, settings):
    """把手動算好的語意候選併進既有的連帶決定表；表裡已填的決定不動。"""
    import decision_table as dt
    import semantic_candidates as sc
    # 決定表是就地改寫（人填到一半的欄不能動），所以這一步不會把表搬進新格；
    # 資料夾是舊排法就講一聲，讓人知道整個產出資料夾該重跑一次 compare。
    warn_if_legacy_outdir(outdir_of_table(args.decisions))
    try:
        before, after, count = _merge_semantic(args.decisions, args.semantic)
    except (dt.DecisionTableError, sc.SemanticError) as exc:
        say("[中止] %s" % exc)
        return 1
    say("語意候選併入完成：原 %d 列 → %d 列（語意 %d 筆）" % (before, after, count))
    say("表：%s" % args.decisions)
    return 0


def _merge_semantic(decisions, semantic_path):
    """把算好的語意候選檔併進一張決定表；已填的決定不動。回傳 (原列數, 併入後列數, 語意筆數)。
    讀不了表或檔（指紋不符）丟 DecisionTableError／SemanticError，由呼叫端印「[中止]」。"""
    import decision_table as dt
    import semantic_candidates as sc
    rows = dt.read_table(decisions)
    sidecar = dt.read_sidecar(dt.sidecar_path_for(decisions))
    semantic_rows = sc.read_results(semantic_path, expected_sha=sidecar["草稿"]["SHA256"])
    import review_import as ri
    before = len(rows)
    # 指紋檔的「列」只增不減：既有的每一筆原封不動留著（連表上已經被刪掉的列也留著），
    # 只替這次 add_semantic 新增的列補一筆。
    # 不能拿表上現在的樣子重建：候選全文被手改過的列，重算一次指紋就跟著被改過的字走，
    # review-import 從此驗不出來；被刪掉的列，指紋一消失，finalize 第二問就再也看不到它
    # （跑一次 semantic、就算零筆語意候選，竄改與刪列都被洗白了）。
    bad_idx, _ = ri.check_row_texts(rows, sidecar)
    if bad_idx:
        say("[警告] 有 %d 列候選全文跟初比對指紋不符（段次 %s）：指紋照舊，"
            "review-import 仍會擋下它們；請還原決定表或重跑 compare"
            % (len(bad_idx), "、".join(rows[i].get("候選段次") or "-" for i in sorted(bad_idx))))
    entries = list(sidecar.get("列") or [])
    _, unused = dt.match_sidecar(rows, entries)
    free = [(entries[k].get("候選段次") or 0, entries[k].get("候選全文SHA256")) for k in unused]
    existing = set(id(r) for r in rows)
    rows = dt.add_semantic(rows, semantic_rows)
    # 重寫表與指紋檔；草稿指紋與異動段落指紋沿用原值。
    # 先寫 .tmp 再 os.replace：中途被中斷也不會把人填了一半的表洗掉。
    dt.write_rows_csv(decisions, rows)
    for r in rows:
        if id(r) in existing:
            continue
        key = (dt.line_of(r["候選段次"]), dt.text_sha256(r["候選全文"]))
        if key in free:
            free.remove(key)      # 人刪掉的那一列被語意又帶回表上：沿用那一筆，不重複記
        else:
            entries.append({"候選段次": key[0], "候選全文SHA256": key[1]})
    sidecar["列"] = entries
    side_path = dt.sidecar_path_for(decisions)
    tmp = side_path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(sidecar, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, side_path)
    return before, len(rows), len(semantic_rows)


def cmd_approve(args, settings):
    """核准：人下一次指令，照規則把決定表裡 AI 建議明確的列一次決定掉（見 approve.py）。
    給決定表路徑就只處理那一張；不給就處理工作區批次產出的每一本（開始前、結束後自動同步
    產出/填寫表單/連帶決定表.csv）。--預覽 只列出會怎麼決定，不寫表。"""
    import approve as ap
    import batch as bt
    import decision_table as dt
    change = ap.parse_rules(args.change, ap.DEFAULT_CHANGE)
    keep = ap.parse_rules(args.keep, ap.DEFAULT_KEEP)
    if args.decisions:
        tables = [("", os.path.abspath(args.decisions))]
    else:
        _apply_workspace_defaults(args, settings)
        # 平常只會提醒（AI 審查還沒匯入）；印了「[順序]」（還沒有比對結果、結果已過期）就真的擋（第三批）
        if _order_problem(args, "approve"):
            return 1
        try:
            tables = [(name, locate(outdir_doc, "連帶決定表.csv")[0])
                      for name, outdir_doc in bt.list_books(args.outdir)]
        except bt.BatchError as exc:
            say("[中止] %s" % exc)
            return 1
    say("核准規則：照建議改＝%s；不改＝%s%s" % ("、".join(change), "、".join(keep),
                                         "（預覽，不寫表）" if args.preview else ""))
    total = {"改": 0, "不改": 0, "留給人": 0}
    for name, table in tables:
        try:
            rows = dt.read_table(table)
        except dt.DecisionTableError as exc:
            say("[中止] %s：%s" % (name or table, exc))
            return 1
        done = ap.approve(rows, change, keep, apply=not args.preview)
        if not args.preview and (done["改"] or done["不改"]):
            dt.write_rows_csv(table, rows)
        for key in total:
            total[key] += len(done[key]) if key != "留給人" else done[key]
        for line in ap.result_lines(name, done):
            say(line)
    if args.preview:
        say("這是預覽，決定表沒有動。確認後拿掉 --預覽 再跑一次就會寫進去（每一列「核准方式」欄會記下規則）。")
    else:
        say("已寫進決定表：照建議改 %d 列、不改 %d 列（「核准方式」欄記下是照哪一條規則）。"
            "還要人決定 %d 列。" % (total["改"], total["不改"], total["留給人"]))
    return 0


def _pull_in_by_semantic(args, settings, folder):
    """batch-semantic 用：這一輪只讀過全文的本，語意交回檔裡有候選的，整套初比對拉進流程。
    回傳拉進來的規章名 list；中止回 None（已印原因）。"""
    import batch as bt
    import semantic_candidates as sc
    docs = bt.unaffected_docs(args.outdir)
    skip = set(docs)
    hits = []
    for name in sorted(skip):
        path = os.path.join(folder, "%s.csv" % name)
        if not os.path.isfile(path):
            continue
        try:
            if sc.read_results(path):
                hits.append(name)
        except sc.SemanticError as exc:
            say("[中止] %s：%s" % (name, exc))
            return None
    if not hits:
        return []
    runner = load_regdiff_runner()
    # 門檻沿用這一輪其他本的初比對（指紋檔的「比對參數」），找不到才退回預設
    params = _compare_params_with_fallback(runner, _batch_params(args.outdir))
    pulled = []
    for name in hits:
        doc = docs[name]
        if not os.path.isfile(doc["舊版"]):
            say("[中止] %s 語意有候選，但它的舊版不見了：%s" % (name, doc["舊版"]))
            return None
        t = _batch_full_compare(doc, args.outdir, args, settings, runner, params)
        if t is None:
            return None
        _write_batch_table(t, name, params)
        pulled.append(name)
        say("%s：本次沒放修訂版，但語意比對找到可能受影響的段落，已拉進流程（決定表裡看這幾列）" % name)
    bt.write_unaffected(args.outdir, [docs[n] for n in sorted(skip - set(pulled))])
    return pulled


def _batch_params(root):
    """這一輪批次初比對用的門檻（從任何一本決定表的指紋檔讀「比對參數」）。"""
    import batch as bt
    import decision_table as dt
    try:
        books = bt.list_books(root)
    except bt.BatchError:
        return None
    for _, outdir_doc in books:
        try:
            side = dt.read_sidecar(dt.sidecar_path_for(locate(outdir_doc, "連帶決定表.csv")[0]))
        except dt.DecisionTableError:
            continue
        params = side.get("比對參數") or {}
        if all(k in params for k in ("threshold", "top", "changed_top", "sentence_threshold")):
            return dict((k, params[k]) for k in ("threshold", "top", "changed_top", "sentence_threshold"))
    return None


SEMANTIC_SKIP = "略過.txt"


def cmd_batch_semantic(args, settings):
    """批次：把在別台電腦算好的語意候選一次併回各本（產出/系統檔案/語意候選/<規章名>.csv）。

    以前要逐本跑 semantic，而且要先跑一次批次指令把合一表上的決定寫回各本、併完再跑一次
    合回合一表。這一支本身就是批次指令：開始前、結束後會自動同步 產出/填寫表單/（見 main）。"""
    import batch as bt
    import decision_table as dt
    import semantic_candidates as sc
    _apply_workspace_defaults(args, settings)
    folder = os.path.abspath(args.semantic_dir) if args.semantic_dir else semantic_folder(args.outdir)
    skip_marker = os.path.join(semantic_folder(args.outdir), SEMANTIC_SKIP)
    if getattr(args, "skip", False):
        os.makedirs(os.path.dirname(skip_marker), exist_ok=True)
        with io.open(skip_marker, "w", encoding="utf-8") as f:
            f.write("這一輪不做語意比對（batch-semantic --略過）\n")
        say("這一輪不做語意比對：人工待辦不會再提醒；之後算好了照樣可以跑 %s 併入"
            % _cmd("語意併入", workspace_flag(args)))
        return 0
    if os.path.isfile(skip_marker):
        os.remove(skip_marker)
    import semantic_exchange as se
    import todo
    if not args.semantic_dir:
        # 帶回來的語意交換包（原位或 匯入/）：先把算好的 <規章名>.csv 取出來，底下照原本的做法併入
        try:
            back = se.returned(folder, todo.workspace_of(args.outdir))
        except se.ExchangeError as exc:
            say("[中止] %s" % exc)
            return 1
        if back:
            se.unpack(back[0], folder, back[1])
            say("從語意交換包取出 %d 本的結果：%s" % (len(back[1]), "、".join(back[1])))
    # 沒放修訂版、跨本也沒找到的本（這一輪只讀過全文）：語意在別台算出有候選的話，它就受影響了，
    # 先整套初比對、寫好決定表，拉進流程，下面再照常併入
    pulled = _pull_in_by_semantic(args, settings, folder)
    if pulled is None:
        return 1
    try:
        books = bt.list_books(args.outdir)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    done, missing = [], []
    for name, outdir_doc in books:
        path = os.path.join(folder, "%s.csv" % name)
        if not os.path.isfile(path):
            missing.append(name)
            continue
        table = locate(outdir_doc, "連帶決定表.csv")[0]
        try:
            before, after, count = _merge_semantic(table, path)
        except (dt.DecisionTableError, sc.SemanticError) as exc:
            say("[中止] %s：%s（前面 %d 本已併入）" % (name, exc, len(done)))
            return 1
        say("%s：語意候選 %d 筆，決定表 %d 列 → %d 列" % (name, count, before, after))
        done.append(name)
    if missing:
        say("沒有找到算好的檔，略過：%s（要的檔名是 %s/<規章名>.csv）"
            % ("、".join(missing), show_path(folder)))
    if not done:
        say("[中止] 一本都沒有併入")
        if os.path.isfile(os.path.join(folder, se.PACK_NAME)):
            say("語意交換包（%s）還沒算：先帶到有模型的電腦跑批次摘要最後那一行，算完帶回來再跑"
                % os.path.join(folder, se.PACK_NAME))
        return 1
    say("新併進來的列在 產出/填寫表單/連帶決定表.csv，「來源」寫「語意」；已填的決定沒有動。")
    return 0


def cmd_review_pack(args, settings):
    """第 1.5 步：把候選與異動打包成給 AI 看的審查包。"""
    import notices as nt
    import review_pack as rp
    nt.reset()
    warn_if_legacy_outdir(args.outdir)
    try:
        info = rp.write_pack(args.outdir, args.per_file,
                             max_chars=getattr(args, "max_chars", rp.DEFAULT_MAX_CHARS))
    except rp.ReviewPackError as exc:
        say("[中止] %s" % exc)
        # 中止的理由與這一步發過的提醒（例如舊式留底、舊版是猜的）都要留底：
        # 畫面留不住，產出資料夾裡的那一份才是。
        nt.notice(nt.WARNING, "review-pack 中止：%s" % exc, "審查包")
        say("提醒留底：%s" % nt.write_notices(args.outdir, "審查包",
                                              title="review-pack（第 1.5 步）"))
        return 1
    say("提醒留底：%s（%d 則）"
        % (nt.write_notices(args.outdir, "審查包", title="review-pack（第 1.5 步）"),
           len(nt.collected())))
    # 路徑一律帶格子名：光講檔名的話，人在產出資料夾第一層翻不到任何一個檔
    # （審查包在 系統檔案/、要填的兩張表在 填寫表單/）。
    say("下一步：讀 系統檔案/LLM審查包_*.md、系統檔案/LLM異動清單.md、系統檔案/LLM外部引用清單.md、"
        "系統檔案/LLM條文檢查清單.md，填 填寫表單/AI候選判斷.csv、填寫表單/AI異動審查.csv、"
        "填寫表單/AI外部引用.csv、填寫表單/AI條文檢查.csv，再跑 review-import。")
    return 0


def cmd_review_import(args, settings):
    """第 1.5 步：驗證 AI 判斷檔、寫回連帶決定表、產出審查報告。"""
    import notices as nt
    import review_import as ri
    import review_pack as rp
    nt.reset()
    warn_if_legacy_outdir(args.outdir)

    def keep_notices():
        # 驗原文的警告（有幾列候選全文被手改過、沒有匯入）一定要留底：
        # 畫面會被後面的統計與「下一步」洗掉，這份檔案才留得住。
        say("提醒留底：%s（%d 則）"
            % (nt.write_notices(args.outdir, "審查匯入",
                                title="review-import（第 1.5 步）"),
               len(nt.collected())))

    try:
        result = ri.import_review(args.outdir)
    except ri.ReviewError as exc:
        say("[中止] AI 判斷檔有問題，什麼都沒寫：")
        for line in str(exc).splitlines():
            say("  " + line)
        return 1
    except rp.ReviewPackError as exc:
        # import_review 一開始就靠 review_pack.load_book 讀連帶決定表／異動清單／輸入指紋，
        # 這三個檔缺一不可；缺檔是 review_pack.ReviewPackError，不是 ri.ReviewError，
        # 沒接住就會直接噴 traceback，跟其他子命令的「[中止]」風格不一致。
        say("[中止] %s" % exc)
        return 1
    except OSError as exc:
        # import_review 先把 AI 三欄寫回連帶決定表.csv，才產 LLM審查報告.xlsx；
        # 報告那一步常見失敗是檔案還開在 Excel 裡（Windows 鎖檔）——這是 OSError，
        # 不是 ri.ReviewError／rp.ReviewPackError，沒接住就直接噴 traceback。
        say("[中止] 報告寫入失敗：%s" % exc)
        say("連帶決定表已寫回；報告未產生（可能開在 Excel），關掉後重跑 review-import")
        keep_notices()
        return 1
    cand, change = result["候選"], result["異動"]
    say("候選：%s" % "、".join("%s %d 筆" % (v, cand[v]) for v in ri.CAND_VERDICTS))
    say("異動：%s" % "、".join("%s %d 筆" % (v, change[v]) for v in ri.CHANGE_VERDICTS))
    if result.get("外部引用"):
        say("外部引用：%s" % _external_counts_text(result["外部引用"]))
    if result.get("條文檢查"):
        say("條文檢查高風險：%s" % _rulecheck_counts_text(result["條文檢查"]))
    if result.get("原文不符"):
        say("原文不符 %d 列未匯入（列ID %s）；見報告的「%s」表"
            % (len(result["原文不符"]), "、".join(result["原文不符"]), ri.MISMATCH_SHEET))
    if result.get("AI過期"):
        say("AI 判斷不是這一輪的 %d 列未匯入（列ID %s）；請重跑 review-pack 讓 AI 重判"
            % (len(result["AI過期"]), "、".join(result["AI過期"])))
    # 報告只出一種格式：xlsx 寫得出來就只有 xlsx，寫不出來才退成幾份 csv
    # （write_report 會發一則「已改出 csv」的提醒）。印實際寫出來的那個檔名就好，
    # 不要再叫人去找一堆不存在的 _候選.csv。
    say("報告：%s" % result["報告"])
    keep_notices()
    say("下一步：用 Excel 開 填寫表單/連帶決定表.csv，參考 AI 三欄與「建議改法」填「要改嗎」"
        "「改成什麼」，填完跑 apply。AI 只是建議，最終仍需人工複核。")
    _confirm_next_step(result.get("人工待確認"))
    return 0


# ---------------------------------------------------------------------------
# batch：多本一起改
# ---------------------------------------------------------------------------

def _apply_workspace_defaults(args, settings):
    """batch、batch-apply、batch-finalize、batch-review-pack、batch-review-import
    共用：manifest／outdir（review 類是 outdir 那個位置參數）沒給時，退回工作區的
    固定路徑（匯入/規章清單.csv、產出/，見 workspace.paths）；有給就照給的，只補成
    絕對路徑。回傳這次解出來的 workspace.paths() 字典，呼叫端通常用不到，但「開始」
    要沿用同一份 p 印下一步指令，就不用自己再算一次。"""
    import workspace as ws
    root = ws.resolve_root(getattr(args, "workspace", ""), settings)
    p = ws.paths(root)
    _set_display_root(root)
    if not getattr(args, "manifest", None):
        args.manifest = p["清單"]
    if not getattr(args, "outdir", None):
        args.outdir = p["產出"]
    else:
        args.outdir = os.path.abspath(args.outdir)
    return p


def _add_workspace_flag(p):
    """讓 --workspace 也能接在子命令名稱後面，不是只能放在最前面（配對／開始／批次類
    子命令印出的下一步指令都是「子命令 --workspace 根」這種順序）。預設用
    argparse.SUPPRESS：子命令自己的解析器如果沒吃到 --workspace，就不要去蓋掉最前面
    （頂層 parser）已經解出來的值——頂層與子解析器共用同一個 Namespace，子解析器
    自己的一般預設值（例如 ""）原本會在沒給的時候覆蓋掉頂層已經設好的值。"""
    p.add_argument("--workspace", default=argparse.SUPPRESS,
                   help="工作區根目錄；沒給就看設定.json（可放在子命令名稱前或後）")


def _add_max_chars_flag(p):
    """review-pack／batch-review-pack 的 --max-chars：一份審查包的字元數上限。

    只數區塊數（--per-file）切不住檔案大小：一個候選掛十幾處異動時，單一區塊就
    好幾萬字（實測單檔 13.7 萬字），貼進 AI 直接爆脈絡長度。0 表示不看字數。"""
    import review_pack as rp
    p.add_argument("--max-chars", dest="max_chars", type=int, default=rp.DEFAULT_MAX_CHARS,
                   help="一份 LLM審查包_NN.md 的字元數上限，預設 %d（0＝不限）"
                        % rp.DEFAULT_MAX_CHARS)


def _add_verbose_flag(p):
    p.add_argument("--詳細", "--verbose", dest="verbose", action="store_true",
                   help="每一本的比對過程照舊全部印在畫面上（預設只印每本一行，細節寫進 "
                        "各本的 產出/系統檔案/<規章名>/審閱文件/執行紀錄.txt）")


class BookLog(object):
    """批次裡一本的詳細輸出：預設收進 <本>/審閱文件/執行紀錄.txt，畫面只印一行進度。

    兩本各幾段的小規章，「開始」以前就印兩百多行，真正要看的彙總被淹在最後；
    十本就是上千行。每本的過程（Step 0.5～2 的報告、候選清單）改寫進各本自己的
    執行紀錄，畫面只留進度與最後的彙總。失敗時把那一本的最後幾行印出來，
    不用人去翻檔也看得到為什麼停。--詳細 照舊全部印在畫面上。
    """

    def __init__(self, outdir_doc, title, verbose=False):
        self.outdir_doc, self.title, self.verbose = outdir_doc, title, verbose
        self.buffer = io.StringIO()
        self._redirect = None

    def __enter__(self):
        if self.verbose:
            say("=" * 60)
            say(self.title)
            say("=" * 60)
        else:
            say("%s……" % self.title)
            self._redirect = contextlib.redirect_stdout(self.buffer)
            self._redirect.__enter__()
        return self

    def __exit__(self, *exc):
        if self._redirect is not None:
            self._redirect.__exit__(*exc)
            text = self.buffer.getvalue()
            try:
                path = place(self.outdir_doc, "執行紀錄.txt")
                with io.open(path, "a", encoding="utf-8-sig") as f:
                    f.write("%s\n%s　%s\n%s\n%s\n" % ("=" * 60, self.title,
                                                      datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                                                      "=" * 60, text))
            except OSError:
                pass      # 紀錄寫不進去不能讓這一本失敗；失敗時照樣會印最後幾行
        return False

    def show_tail(self, n=15):
        """失敗時把這一本最後幾行印到畫面上（--詳細 時本來就印過了）。"""
        if self.verbose:
            return
        for line in self.buffer.getvalue().rstrip().splitlines()[-n:]:
            say("    " + line)
        say("    （完整過程見 系統檔案/%s/審閱文件/執行紀錄.txt）" % os.path.basename(self.outdir_doc))


def _add_batch_flags(p, runner):
    """batch、開始 共用的旗標（跨本連帶門檻）；同一份定義兩邊都掛，避免以後改一邊
    漏改另一邊。"""
    p.add_argument("--semantic-dir", dest="semantic_dir", default=None,
                   help="放 <規章名>.csv 的資料夾（手動算好的語意候選）")
    p.add_argument("--threshold", type=float, default=None)
    p.add_argument("--top", type=int, default=None)
    p.add_argument("--changed-top", dest="changed_top", type=int, default=8)
    p.add_argument("--sentence-threshold", dest="sentence_threshold", type=float,
                   default=runner.fuzzy.DEFAULT_SENTENCE_THRESHOLD)


def _doc_args(runner, doc, outdir_doc, extra_argv=(), **overrides):
    """用 regdiff 的參數定義做一個 Namespace，跟單本 compare／finalize 同一套預設值。"""
    parser = argparse.ArgumentParser()
    runner.add_compare_arguments(parser)
    argv = [doc["舊版"], doc["草稿"], "--outdir", outdir_doc]
    if doc["發布根目錄"]:
        argv += ["--baseline-release", doc["發布根目錄"]]
    ns = parser.parse_args(argv + list(extra_argv))
    ns.semantic = None
    ns.workspace = ""
    for key, value in overrides.items():
        setattr(ns, key, value)
    return ns


SEMANTIC_FOLDER = "語意候選"


def semantic_folder(root):
    """批次手動語意的交換資料夾：產出/系統檔案/語意候選/（<規章名>_語意輸入.json 與算好的 <規章名>.csv）。"""
    return os.path.join(root, "系統檔案", SEMANTIC_FOLDER)


def _semantic_manual_lines(root, names, ws, exchange=None):
    """這台電腦算不了語意候選時要印的步驟：只帶一個交換包去有模型的電腦（見 semantic_exchange），
    算完結果寫回同一個檔，帶回來一行併入。以前要把整個工作區複製過去再帶回來：又大，帶回來時還會
    把這段時間在這台填的決定表蓋掉。"""
    import semantic_exchange as se
    import todo
    workspace = todo.workspace_of(root)
    exchange = exchange or os.path.join(semantic_folder(root), se.PACK_NAME)
    # 指令裡不寫這台電腦的路徑：換到有模型的電腦，路徑一定不一樣，照抄就跑不了（兩個 <…> 換成那台的位置）
    merge = _cmd("繼續", ws) if workspace else _cmd("語意併入", root)
    skip = _cmd("語意併入", ws if workspace else root, "--略過")
    return ["語意候選（BGE-M3）：這台電腦沒有模型（或載不起來），這一輪沒算（%d 本）。到有模型的電腦做：" % len(names),
            "  1. 把這一個檔帶過去：%s" % exchange,
            "  2. 在那台的 reg 資料夾執行這一行（兩個 <…> 換成那台電腦上的位置）：",
            "     " + _script_cmd("semantic_candidates.py", "--交換包", '"<語意交換包.zip>"',
                                  "--model", '"<模型資料夾>"'),
            "     一次算完 %d 本，結果寫回同一個檔；向量快取留在那台的 reg/語意快取，下次沒改的段落不重算" % len(names),
            "  3. 把這個檔帶回來放回原位（蓋掉）%s，回到這台跑：" % ("、或直接放進 匯入/" if workspace else ""),
            "     " + merge,
            "  這一輪不做語意比對就跑：" + skip]


def _batch_semantic(target, all_changes, tname, settings, args, outdir_doc, input_path=None):
    """每本寫語意輸入.json（異動＝所有本）；依序試 --semantic-dir 交回檔、本機模型。

    回傳 (rows, needs_manual)。needs_manual 只有在「沒用到 --semantic-dir 的檔，
    而且這台電腦沒設模型路徑或模型載不起來」時才是真；模型跑過但一筆都沒中不算。
    input_path／outdir_doc=None：沒改的本還沒有自己的資料夾（只當被查對象），語意輸入直接寫進
    語意候選交換資料夾，算出來的結果不落檔（有中的話呼叫端會把它拉進流程）。"""
    import semantic_candidates as sc
    draft = target["doc"]["草稿"]
    draft_sha = file_sha256(draft)
    # 語意輸入／語意候選是程式接力用的中繼檔 → 系統檔案/（跟單本 compare 一致）
    input_path = input_path or place(outdir_doc, "語意輸入.json")
    sc.write_input(input_path, draft, draft_sha, all_changes, target["outcome"]["new_paragraphs"], target_name=tname)
    if getattr(args, "semantic_dir", None):
        path = os.path.join(args.semantic_dir, tname + ".csv")
        if os.path.isfile(path):
            try:
                rows = sc.read_results(path, expected_sha=draft_sha)
                say("  語意候選：讀入 %s（%d 筆）" % (path, len(rows)))
                return rows, False
            except sc.SemanticError as exc:
                say("  [中止] 語意候選檔不能用：%s" % exc)
                raise
    model_path = settings.get("語意模型路徑", "")
    if not model_path:
        return [], True
    embed = sc.load_model(model_path, recall_top=_semantic_recall_top(settings),
                          cache_dir=getattr(args, "cache_dir", "") or None)
    if embed is None:
        return [], True
    rows = sc.find_candidates(embed, all_changes, target["outcome"]["new_paragraphs"],
                              _semantic_threshold(settings),
                              int(settings.get("語意最多幾筆", sc.DEFAULT_TOP)), target_name=tname)
    if outdir_doc:
        sc.write_results(place(outdir_doc, "語意候選.csv"), rows, draft_sha)
    return rows, False


def _batch_full_compare(doc, outdir, args, settings, runner, params, verbose=False):
    """批次裡整套初比對一本（寫這一本自己的過程檔，還不寫決定表）。回傳這一本的狀態；
    失敗回 None（已印「[中止]」）。cmd_batch 與 batch-semantic（語意找到沒改的本受影響時）共用。"""
    import notices as nt
    name = doc["規章名"]
    outdir_doc = book_dir(outdir, name, legacy=False)
    log = BookLog(outdir_doc, "批次　%s" % name + ("" if doc["有草稿"] else "（本次不修改，只看別本的改動）"),
                  verbose)
    ns = _doc_args(runner, doc, outdir_doc, ["--threshold", str(params["threshold"]), "--top", str(params["top"]),
                                             "--changed-top", str(params["changed_top"]),
                                             "--sentence-threshold", str(params["sentence_threshold"])],
                   title=table_title(name))
    # 裁定 7：批次裡沒改的本用「提醒」不用「警告」——十本裡有兩本這次沒動很正常，
    # 用警告會讓整批的結論被一件正常的事翻掉。沒有草稿的本另外講清楚原因，
    # 不然那則提醒會寫成「可能拿錯檔」，但它其實是照設計拿舊版當草稿在跑。
    ns.zero_change_level = nt.REMINDER
    if not doc["有草稿"]:
        # 清單裡沒放新版草稿＝這一本本次不修改（配對時標「沒改」），0 異動是預期的，
        # 不發提醒。以前發「草稿出來之後要再跑一次」，跟配對講的「沒改」互相矛盾，
        # 人會以為自己漏放了檔。這件事改由批次摘要的「本次不修改 N 本」講。
        ns.zero_change_level = None
    # 這裡先不寫表：整批任何一本的第 0、1 步沒過就中止，不留半套決定表。
    with log:
        rc, outcome, rows, _ = _compare_core(ns, settings, final=False, write_table=False)
    if rc:
        log.show_tail()
        say("[中止] %s 初比對失敗，整批停止。" % name)
        return None
    baseline = outcome["baseline"]
    results = outcome["results"]
    new_line_ids = baseline.annotate_results(results) if baseline else {}
    changes = []
    for r in results:
        if r["type"] in ("added", "modified") and r.get("new_text"):
            ids = r.get("spec_ids") or []
            changes.append({"條文ID": "、".join(ids), "ref": r.get("ref") or "",
                            "old_text": r.get("old_text") or "", "new_text": r["new_text"],
                            "段次": r.get("new_index") or 0,
                            "positions": [baseline._position(i) for i in ids] if baseline else []})
    # 這一本的提醒收走（各本的 提醒.txt 已經由 run_compare 寫進各自的子資料夾）。
    # 不收走的話下一本的提醒會連著前一本一起算，批次摘要的數字就對不上。
    return {"doc": doc, "outdir": outdir_doc, "outcome": outcome, "rows": rows,
            "baseline": baseline, "new_line_ids": new_line_ids, "changes": changes,
            "跨本來自": set(), "提醒": nt.drain()}


def _write_batch_table(t, name, params, changed_texts=None):
    """寫一本的連帶決定表（與指紋檔）和異動清單。各本的產出跟單本 compare 走同一套去向：
    決定表 → 填寫表單/，指紋與異動清單 → 系統檔案/。"""
    import decision_table as dt
    if changed_texts is None:
        changed_texts = [r["new_text"] for r in t["outcome"]["results"] if r["type"] in ("added", "modified")]
    csv_path = place(t["outdir"], "連帶決定表.csv")
    dt.write_table(t["rows"], csv_path, dt.sidecar_path_for(csv_path), t["doc"]["草稿"],
                   changed_texts, extra={"規章": name}, params=params, old_path=t["doc"]["舊版"])
    dt.write_change_list(t["outcome"]["results"], place(t["outdir"], "異動清單.json"))
    # 這一本的現行規章、修訂版在哪裡：人工待辦拿它跟決定表指紋比，發現「開始」之後被改過就叫人重跑開始
    # （以前改了修訂版，套用會失敗，人工待辦卻一直叫人重跑套用）
    with io.open(place(t["outdir"], "輸入來源.json"), "w", encoding="utf-8") as f:
        json.dump({"舊版": os.path.abspath(t["doc"]["舊版"]), "草稿": os.path.abspath(t["doc"]["草稿"])},
                  f, ensure_ascii=False)
    return csv_path


def cmd_batch(args, settings):
    import batch as bt
    import decision_table as dt
    import fuzzy_duplicate_finder as fuzzy
    import notices as nt
    import semantic_candidates as sc
    import workspace as ws
    from _common import load_synonyms, read_paragraphs_with_kinds
    # item3：outdir 是不是「呼叫端明給的」，要在 _apply_workspace_defaults 把它補成
    # 工作區預設值*之前*判斷——判斷完才能補。cmd_start 呼叫這裡之前已經自己歸檔過
    # 一次（archive_previous），且會把 ns.outdir 明確設成 p["產出"]（見 cmd_start），
    # 所以從 cmd_start 進來時 outdir_was_explicit 一定是 True，不會落進下面「省略
    # outdir」的分支、不會歸檔第二次；只有使用者直接跑 `batch`（不給 --outdir）
    # 才會落到這裡幫忙歸檔上一輪，不然直接跑 batch 會把上一輪的產出整個蓋掉。
    outdir_was_explicit = bool(getattr(args, "outdir", ""))
    p = _apply_workspace_defaults(args, settings)
    try:
        docs = bt.read_manifest(args.manifest)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    outdir = args.outdir
    # no 10：批次的每一本輸入檔由 bt.read_manifest 驗過了，產出根目錄這裡驗一次
    # 就夠——不然歸檔完、第一本跑到一半才發現整個產出根目錄寫不進去。
    problem = precheck(outdir)
    if problem:
        say("[中止] %s" % problem)
        return 1
    if not outdir_was_explicit:
        names = [doc["規章名"] for doc in docs]
        try:
            moved = ws.archive_previous(p["根"], names)
        except ws.WorkspaceError as exc:
            say("[中止] %s" % exc)
            return 1
        if moved:
            say(archive_line(moved))
    stage_inputs(outdir, [args.manifest])
    # batch.list_books（batch-review-pack／batch-review-import 用）固定讀
    # <outdir>/系統檔案/輸入/規章清單.csv；stage_inputs 只是把使用者的原始檔複製進去，
    # 檔名照抄。使用者的清單如果不叫這個名字，後面兩支子命令會直接找不到檔案。
    # 這裡另存一份固定檔名，來源檔名本來就是它就不用再複製一次。
    manifest_name = os.path.basename(args.manifest)
    if manifest_name != "規章清單.csv":
        staged = place(outdir, "輸入")
        shutil.copy2(os.path.join(staged, manifest_name),
                     os.path.join(staged, "規章清單.csv"))
    runner = load_regdiff_runner()
    synonyms = load_synonyms()
    threshold = args.threshold if args.threshold is not None else fuzzy.DEFAULT_THRESHOLD
    top = args.top if args.top is not None else fuzzy.DEFAULT_TOP

    state = {}
    # 沒放修訂版（也沒有規格包）的本：只讀全文，當別本改動的「被查對象」。
    # 以前每一本都整套跑（自己比自己、條文檢查、對照表……），五十本只改三本時大部分時間都在白跑；
    # 它們唯一要做的事是讓別本的改動找得到它（連帶、引用）。找到了才整套拉進流程，見下面。
    light = {}
    verbose = getattr(args, "verbose", False)
    params = {"threshold": threshold, "top": top, "changed_top": args.changed_top,
              "sentence_threshold": args.sentence_threshold}
    # 快取（語意向量、AI 查證結果）放在現行規章資料夾底下的 系統快取/（見 batch.cache_dir_for_docs）
    args.cache_dir = bt.cache_dir_for_docs(docs)
    bt.write_cache_pointer(outdir, args.cache_dir)
    for doc in docs:
        name = doc["規章名"]
        if not doc["有草稿"] and not doc["發布根目錄"]:
            try:
                paragraphs, kinds = read_paragraphs_with_kinds(doc["舊版"])
            except (ValueError, OSError, UnicodeDecodeError) as exc:
                say("[中止] %s 舊版讀不出來：%s，整批停止。" % (name, exc))
                return 1
            nt.drain()
            if not paragraphs:
                say("[中止] %s 舊版一段文字都讀不到（%s），整批停止。" % (name, doc["舊版"]))
                return 1
            light[name] = {"doc": doc, "outcome": {"new_paragraphs": paragraphs, "new_kinds": kinds,
                                                   "results": []},
                           "baseline": None, "new_line_ids": {}, "changes": [], "跨本來自": set()}
            continue
        t = _batch_full_compare(doc, outdir, args, settings, runner, params, verbose)
        if t is None:
            return 1
        state[name] = t

    source_indexes = {}
    cross_found = {}
    # 被查對象＝每一本（含只讀全文的）；來源＝有整套跑的本（只讀全文的本沒有改動，當來源找不到東西）
    for tname, t in list(state.items()) + list(light.items()):
        cross = []
        for sname, s in state.items():
            if sname == tname:
                continue
            found = []
            if s["changes"]:
                found = bt.cross_candidates(sname, s["changes"], t["outcome"]["new_paragraphs"],
                                            synonyms, threshold, top, args.changed_top,
                                            sentence_threshold=args.sentence_threshold,
                                            target_kinds=t["outcome"].get("new_kinds"))
            if t["baseline"]:
                if s["changes"]:
                    found += bt.citation_links(sname, s["changes"], t["baseline"], t["new_line_ids"],
                                               t["outcome"]["new_paragraphs"])
            else:
                # 沒有規格包：直接讀 B 本的字找「A 本名稱＋第X條／第X點／章節」（連只刪不改的 A 本也要看）
                if sname not in source_indexes:
                    source_indexes[sname] = bt.SourceIndex(s["outcome"])
                found += bt.text_citation_links(sname, source_indexes[sname], t["outcome"]["new_paragraphs"])
            if found:
                t["跨本來自"].add(sname)
            cross += found
        cross_found[tname] = cross
    # 跨本候選分層＋全域上限（見 batch.select_cross）：規章本數再多，列數只跟改了幾處有關
    unlisted = {}
    cross_found, cross_dropped = bt.select_cross(
        cross_found, dict((name, s["changes"]) for name, s in state.items()),
        int(settings.get("跨本每處上限", bt.CROSS_TOP) or 0), unlisted=unlisted,
        strong_cap=int(settings.get("跨本舊值上限", bt.CROSS_STRONG_TOP) or 0))
    for name in list(light):
        light[name]["跨本來自"] = set(r["異動條文ID"].split("：")[0] for r in cross_found[name]
                                  if r.get("異動條文ID"))
    for tname, t in state.items():
        t["跨本來自"] = set(r["異動條文ID"].split("：")[0] for r in cross_found[tname] if r.get("異動條文ID")) \
            if cross_found[tname] else set()
        t["rows"] = dt.add_cross(t["rows"], cross_found[tname])

    all_changes = [{"段次": c["段次"], "全文": c["new_text"], "舊全文": c.get("old_text") or "",
                    "條文ID": c["條文ID"] or c.get("ref") or "", "規章": name}
                   for name, s in state.items() for c in s["changes"]]
    manual = []
    # 只讀全文的本也要給語意比對找：沒有自己的資料夾，語意輸入直接寫進語意候選交換資料夾
    for lname, t in light.items():
        t["語意"] = []
        if not all_changes:
            continue
        folder = semantic_folder(outdir)
        os.makedirs(folder, exist_ok=True)
        try:
            t["語意"], needs_manual = _batch_semantic(
                t, all_changes, lname, settings, args, None,
                input_path=os.path.join(folder, "%s_語意輸入.json" % lname))
        except sc.SemanticError:
            return 1
        if needs_manual:
            manual.append(lname)
    # 被別本的改動找到（跨本連帶、引用、語意）的才整套拉進流程：它這次也可能要跟著改
    for lname, t in light.items():
        if not (cross_found[lname] or t["語意"]):
            continue
        full = _batch_full_compare(t["doc"], outdir, args, settings, runner, params, verbose)
        if full is None:
            return 1
        full["rows"] = dt.add_cross(full["rows"], cross_found[lname])
        full["跨本來自"] = t["跨本來自"]
        full["語意"] = t["語意"]
        staged_input = os.path.join(semantic_folder(outdir), "%s_語意輸入.json" % lname)
        if os.path.isfile(staged_input):
            shutil.copy2(staged_input, place(full["outdir"], "語意輸入.json"))
        state[lname] = full
    # 這台已經算完語意的本，語意輸入不能留在交換資料夾：留著就被當成「要帶去別台算、還沒帶回來」，
    # 繼續永遠停在「語意比對還沒做」（B20）。要人工算的（manual）才留著
    for lname in light:
        staged_input = os.path.join(semantic_folder(outdir), "%s_語意輸入.json" % lname)
        if lname not in manual and os.path.isfile(staged_input):
            os.remove(staged_input)
    untouched = [name for name in light if name not in state]
    bt.write_unaffected(outdir, [light[name]["doc"] for name in untouched])
    state = dict((doc["規章名"], state[doc["規章名"]]) for doc in docs if doc["規章名"] in state)
    stats = []
    # 跨本列的「異動內容」要到來源本查那一處異動
    change_books = dict((name, {"changes": dt.change_items(s["outcome"]["results"])})
                        for name, s in state.items())
    for tname, t in state.items():
        if "語意" in t:
            sem_rows, needs_manual = t["語意"], False      # 拉進流程之前已經算過（手動的也已登記）
        else:
            try:
                sem_rows, needs_manual = _batch_semantic(t, all_changes, tname, settings, args, t["outdir"])
            except sc.SemanticError:
                return 1
        if sem_rows:
            t["rows"] = dt.add_semantic(t["rows"], sem_rows)
        if needs_manual and all_changes:
            manual.append(tname)
            # 語意輸入另外放一份進 產出/系統檔案/語意候選/：換到有模型的電腦算時整個資料夾帶過去，
            # 算好的 <規章名>.csv 放回同一個資料夾，batch-semantic 一行併入
            folder = semantic_folder(outdir)
            os.makedirs(folder, exist_ok=True)
            shutil.copy2(place(t["outdir"], "語意輸入.json"),
                         os.path.join(folder, "%s_語意輸入.json" % tname))
        carried, had_previous = _assist_rows(t["rows"], t["outdir"],
                                             change_books[tname]["changes"], change_books)
        changed_texts = [r["new_text"] for r in t["outcome"]["results"] if r["type"] in ("added", "modified")]
        # 各本的產出跟單本 compare 走同一套去向：決定表 → 填寫表單/，
        # 指紋與異動清單 → 系統檔案/。（批次自己那幾個根層級的檔留給 Task 4。）
        _write_batch_table(t, tname, params, changed_texts)
        _write_unlisted(t["outdir"], unlisted.get(tname, []))
        # 一列只算一次（小瑕疵 13）：跟單本 compare 共用 source_distribution，
        # 批次摘要與畫面上那一行括號內的數字加起來才等於候選列數。
        # 以前這裡是「每列的來源逐個標籤各記一次」，同時被相似度與語意抓到的列
        # 會被算兩遍，總和大於候選數，人會以為表上少了幾列。
        dist = source_distribution(t["rows"])
        # 實質異動要連刪除一起算（t["changes"] 只收 added／modified，見下面那段註解）：
        # 以前整本只刪了一點的那一本，摘要寫「實質異動 0」
        substantive = sum(1 for r in t["outcome"]["results"]
                          if r["type"] in ("added", "deleted", "modified"))
        stats.append({"規章名": tname, "有草稿": t["doc"]["有草稿"], "實質異動": substantive,
                      "候選": len(t["rows"]), "來源分佈": dist, "跨本來自": sorted(t["跨本來自"]),
                      # t["changes"] 只收 added／modified（跨本比對要新文），刪除型不在裡面，
                      # 拿它判「這本有沒有改」會把「整本只刪了幾條」誤報成沒改。
                      # 零異動一律用 run_compare 自己算的那一個旗標。
                      "零異動": bool(t["outcome"].get("零異動")),
                      "沿用": carried if had_previous else None,
                      "提醒": t["提醒"]})

    # 批次摘要是「人要看」的那一份 → 產出根目錄的 審閱文件/（見 _common.FILE_HOMES）。
    # write_batch_summary 的簽名不變（呼叫端給路徑），去向一律由 place 決定。
    summary_path = bt.write_batch_summary(place(outdir, "批次摘要.txt"), stats)
    dropped_total = sum(cross_dropped.values())
    dropped_line = ""
    if dropped_total:
        dropped_line = ("跨本分數較低的候選另有 %d 段沒列（每一處異動、每一種找法，全部規章合計只列前 %d 段；"
                        "舊值原樣還在的每處最多 %d 段；明確引用一律列）"
                        % (dropped_total, int(settings.get("跨本每處上限", bt.CROSS_TOP) or 0),
                           int(settings.get("跨本舊值上限", bt.CROSS_STRONG_TOP) or 0)))
        with io.open(summary_path, "a", encoding="utf-8-sig") as f:
            f.write("\n" + dropped_line + "\n")
    untouched_line = ""
    if untouched:
        untouched_line = ("沒放修訂版、也沒有被別本的改動影響到 %d 本：%s（只讀過全文找連帶與引用，"
                          "一處都沒找到，後面的步驟不處理）" % (len(untouched), "、".join(untouched)))
        with io.open(summary_path, "a", encoding="utf-8-sig") as f:
            f.write("\n" + untouched_line + "\n")
    exchange = None
    if manual:
        # 這台算不了：每一本的語意輸入打成一個交換包，只帶這一個檔去有模型的電腦（見 semantic_exchange）
        import semantic_exchange as se
        exchange = se.pack(semantic_folder(outdir), {"門檻": _semantic_threshold(settings),
                                                     "最多幾筆": int(settings.get("語意最多幾筆", sc.DEFAULT_TOP)),
                                                     "粗篩": _semantic_recall_top(settings)})
    manual_lines = _semantic_manual_lines(outdir, manual, workspace_flag(args), exchange) if manual else []
    if manual_lines:
        # 每一本一行、路徑都填好，照抄就能跑；畫面與批次摘要印同一份
        with io.open(summary_path, "a", encoding="utf-8-sig") as f:
            f.write("\n" + "\n".join(manual_lines) + "\n")
    say("")
    say("=" * 60)
    say("批次初比對完成")
    say("=" * 60)
    for s in stats:
        # 警告（例如章節重編後指錯的引用）要在這一行就看得到，不能跟一般提醒混成一個數字
        warned = len(nt.warnings(s.get("提醒") or []))
        say("%s：實質異動 %d、候選 %d（%s）%s%s，提醒 %d 則%s" % (
            s["規章名"], s["實質異動"], s["候選"],
            "、".join("%s %d" % kv for kv in sorted(s["來源分佈"].items())) or "無",
            "，跨本來自 " + "、".join(s["跨本來自"]) if s["跨本來自"] else "",
            "，沿用上一輪決定 %d 列" % s["沿用"] if s.get("沿用") is not None else "",
            len(s.get("提醒") or []),
            "（其中警告 %d 則，要處理）" % warned if warned else ""))
    kept = [s["規章名"] for s in stats if not s.get("有草稿", True)]
    zero_books = [s["規章名"] for s in stats if s.get("零異動") and s.get("有草稿", True)]
    if kept:
        say("本次不修改、但被別本的改動影響到 %d 本：%s（沒放修訂版；決定表裡有它們的列，要不要跟著改看那幾列）"
            % (len(kept), "、".join(kept)))
    if untouched_line:
        say(untouched_line)
    if dropped_line:
        say(dropped_line)
    if zero_books:
        say("有新版草稿卻一處都沒改 %d 本：%s——請確認草稿有沒有放對" % (len(zero_books), "、".join(zero_books)))
    for line in manual_lines:
        say(line)
    say("摘要：%s（含各本提醒彙整）" % show_path(summary_path))
    if not getattr(args, "verbose", False):
        say("各本的比對過程在 產出/系統檔案/<規章名>/審閱文件/執行紀錄.txt（要印在畫面上就加 --詳細）")
    say_next_after_compare(batch=True, ws=workspace_flag(args))
    return 0


def cmd_batch_apply(args, settings):
    import notices as nt
    import apply_changes as ac
    import batch as bt
    import decision_table as dt
    _apply_workspace_defaults(args, settings)
    if _order_problem(args, "batch-apply"):
        return 1
    try:
        docs = bt.read_manifest(args.manifest)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    outdir = args.outdir
    docs = bt.active_docs(docs, outdir)
    ok, failed = [], []
    blocked_books = []        # [(規章名, 程式做不到的跳過列數)]
    unverified = []
    for doc in docs:
        name = doc["規章名"]
        outdir_doc = book_dir(outdir, name)
        # 這一則要在這本的 ac.apply 之前發：apply 一開頭 nt.reset()，結束時
        # nt.write_notices(outdir_doc) 才會把它寫進**這一本**的 提醒.txt。
        # 放在迴圈外的話，第二本的那一則會被寫進第一本的檔案裡。
        warn_if_legacy_books(outdir, [name])
        csv_path = locate(outdir_doc, "連帶決定表.csv")[0]
        say("=" * 60)
        say("batch-apply　%s" % name)
        say("=" * 60)
        # 跳過與失敗的兩條路都沒有走到 ac.apply 的 write_notices：上面那一則
        # 舊排法提醒會留在 pending 裡，被下一本的 apply 寫進**下一本**的 提醒.txt
        # （審查發現）。所以這兩條路要自己把這一本的提醒寫掉再 continue。
        if not os.path.isfile(csv_path):
            say("[跳過] 找不到 %s" % csv_path)
            failed.append(name)
            # entries=nt.drain()：連 apply 失敗時已經收進清單的那幾則一起帶走並清空，
            # 不然下一本被跳過時（沒有 apply 來 reset）會把上一本的警告寫進自己的檔案。
            nt.write_notices(outdir_doc, append=True, title="batch-apply（跳過）",
                             entries=nt.drain())
            continue
        try:
            summary = ac.apply(doc["草稿"], csv_path, outdir_doc)
        except (ac.ApplyError, dt.DecisionTableError) as exc:
            # 原因只印一次：這一行只標哪一本失敗，原因由下面那則警告印（也會留底）
            say("[失敗] %s" % name)
            failed.append(name)
            # 跟單本 cmd_apply 一樣先記一則警告：中止原因不記進清單的話，
            # 這一本的 提醒.txt 會寫「本次沒有提醒」，等於在說這次沒事。
            nt.notice(nt.WARNING, "apply 中止：%s" % exc, "套用")
            nt.write_notices(outdir_doc, append=True, title="batch-apply（失敗）",
                             entries=nt.drain())
            continue
        for key, value in sorted(summary["統計"].items()):
            say("  %-14s %d 列" % (key, value))
        blocked = ac.blocked_rows(summary["統計"])
        if blocked:
            say("[警告] " + ac.blocked_message(summary["統計"]))
            blocked_books.append((name, blocked))
        if not _verify_applied(outdir_doc, doc["草稿"], summary)["通過"]:
            unverified.append(name)
        ok.append(name)
    say("")
    say("batch-apply 完成：成功 %s；失敗 %s" % ("、".join(ok) or "無", "、".join(failed) or "無"))
    # 「成功」是指 apply 跑完沒例外，不是「每一列都改到了」。哪幾本有程式沒改到的
    # 列要在結尾再列一次：一次十幾本，中間那一行 [警告] 早就被捲走了（no 35）。
    if blocked_books:
        say("程式沒改到：%s（finalize 會算成未改到）"
            % "、".join("%s %d 列" % (name, count) for name, count in blocked_books))
    go = _cmd("繼續", workspace_flag(args))
    if failed:
        # 有一本失敗就不能說「直接跑驗收」：那一本根本沒有定稿（人工待辦只看得到「還沒套用」，原因要在這裡講）
        say("[失敗] %s 沒有套用（原因在「[警告] apply 中止」那一行）：處理好再跑 %s；成功的那幾本重跑也沒關係"
            % ("、".join(failed), go))
    elif unverified:
        # 驗證沒過就不接著驗收：人要先用 Word 看那幾本（人工待辦會講，看完跑 繼續 才驗收）
        say("[警告] %s 的修訂自動驗證沒過：這次不接著驗收" % "、".join(unverified))
    elif getattr(args, "apply_only", False):
        say("修訂已自動驗過（全部接受＝乾淨版、全部拒絕＝草稿）；照 --只套用，這次不驗收")
    else:
        # 以前這裡叫人再下一個 batch-finalize；修訂都驗過了，沒有要人看的，直接接著驗收
        say("修訂已自動驗過（全部接受＝乾淨版、全部拒絕＝草稿），接著驗收")
        say("")
        args.report_done = True          # 驗收自己會更新檢視報告，main 收尾不用再更新一次
        return cmd_batch_finalize(args, settings)
    say("最終仍需人工複核。")
    return 1 if failed else 0


def cmd_batch_finalize(args, settings):
    """批次第 4 步。兩階段：先逐本終比對，全部跑完再拿各本定稿重算跨本連帶。

    為什麼一定要有第 2 階段：batch 第 1 步算過一次跨本連帶，但那是拿各本**草稿**
    算的。定稿是套用決定之後的東西——改掉的字跟草稿不一樣，也可能整段是新增的；
    草稿那一輪的跨本候選在定稿上不一定還成立，定稿之間也可能撞出新的一組。
    不重算的話，第三問「新候選」在批次這條產線上永遠不含跨本，而三問全部是零
    會被讀成「跨本也沒事」——那正是這一步要擋的誤會。
    """
    import batch as bt
    import decision_table as dt
    import notices as nt
    _apply_workspace_defaults(args, settings)
    if _order_problem(args, "batch-finalize"):
        return 1
    try:
        docs = bt.read_manifest(args.manifest)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    runner = load_regdiff_runner()
    outdir = args.outdir
    docs = bt.active_docs(docs, outdir)
    # 這裡不用另外接舊排法提醒：每一本都走 _finalize_core，那一支已經用
    # outdir_of_table(決定表) 驗過這本的產出資料夾，各本的提醒也寫在各本的檔裡。
    failed = []
    stopped = {}       # 規章名 -> 摘要那一行（跳過／失敗的本，第 2 階段不參與）
    state = {}
    verbose = getattr(args, "verbose", False)
    for doc in docs:
        name = doc["規章名"]
        outdir_doc = book_dir(outdir, name)
        clean = locate(outdir_doc, "新版_定稿_乾淨版.docx")[0]
        csv_path = locate(outdir_doc, "連帶決定表.csv")[0]
        if not os.path.isfile(clean) or not os.path.isfile(csv_path):
            say("[跳過] 缺乾淨版或決定表：%s" % outdir_doc)
            failed.append(name)
            stopped[name] = "%s：跳過（缺乾淨版或決定表）" % name
            continue
        # batch-finalize 的 CLI 沒開放 --threshold／--top／--changed-top／
        # --sentence-threshold 這幾個旗標（跟單本 finalize 不一樣），一律讀這本自己
        # 初比對指紋檔的「比對參數」沿用；指紋檔是這個功能之前產生的、沒記這個鍵，
        # 才退回 regdiff 的硬預設（_compare_params_with_fallback 處理）。
        try:
            init_sidecar = dt.read_sidecar(dt.sidecar_path_for(csv_path))
        except dt.DecisionTableError as exc:
            say("[跳過] %s：%s" % (name, exc))
            failed.append(name)
            stopped[name] = "%s：跳過（指紋檔讀不出來）" % name
            continue
        recorded_params = init_sidecar.get("比對參數")
        params = _compare_params_with_fallback(runner, recorded_params)
        extra_argv = ["--threshold", str(params["threshold"]), "--top", str(params["top"]),
                     "--changed-top", str(params["changed_top"]),
                     "--sentence-threshold", str(params["sentence_threshold"])]
        ns = _doc_args(runner, dict(doc, 草稿=clean), outdir_doc, extra_argv, decisions=csv_path,
                       title=table_title(name))
        info = {}
        log = BookLog(outdir_doc, "batch-finalize　%s" % name, verbose)
        with log:
            if recorded_params:
                _say_inherited_params("終比對沿用初比對門檻", params)
            rc, answers, report_path, _ = _finalize_core(ns, settings, extra=info)
        if rc:
            log.show_tail()
            failed.append(name)
            stopped[name] = "%s：失敗" % name
            continue
        # 這一本的提醒收走再算下一本，數字才不會累加（run_compare 會 reset，
        # 但 _warn_if_clean_has_revisions 是比對之後才發的，要在這裡收）。
        state[name] = {"doc": doc, "outdir": outdir_doc, "clean": clean, "info": info,
                       "answers": answers, "report_path": report_path,
                       "提醒": nt.drain(), "params": params, "csv": csv_path}

    _batch_finalize_cross(state, settings)
    # 各本的驗收報告都定案之後才彙整檢視報告（多本合一）；在這裡做而不是交給 main() 的
    # 收尾，是因為批次驗收的結論要是畫面最後幾行。
    report = _refresh_batch_report(outdir)

    lines = ["批次驗收摘要", "",
             "跨本連帶已用各本定稿重算：每一本第三問的「新候選」都含跨本候選"
             "（括號裡是其中幾列來自跨本）。", ""]
    for doc in docs:
        name = doc["規章名"]
        lines.append(state[name]["摘要行"] if name in state else stopped[name])
    path = place(outdir, "批次驗收摘要.txt")
    with io.open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")
    # 各本的提醒寫在各自子資料夾（run_compare 寫的 最終版_提醒.txt）；各本的提醒在
    # 第 1 階段就 drain 走了，這裡剩下的是跨本那一階段自己發的（正常情況一則都沒有，
    # 照樣寫一份空的：「這次沒有提醒」跟「這個功能沒跑到」要看得出差別）。
    # 檔名不能跟各本的 提醒.txt 撞名，不然人分不出這一份講的是哪一個範圍。
    nt.write_notices(outdir, "批次", title="batch-finalize（批次驗收）", entries=nt.drain())
    say("")
    if report:
        say("檢視報告：%s（各本合一，第一欄是規章名）" % show_path(report))
    for line in lines[2:]:
        say(line)
    say("摘要：%s" % show_path(path))
    say("最終仍需人工複核後才能送出。")
    return 1 if failed else 0


def _batch_finalize_cross(state, settings=None):
    """batch-finalize 第 2 階段：拿各本定稿重算跨本連帶，補進各本的第三問。

    每一本補完之後要重寫兩份已經寫過的產出，不能只改畫面上的數字：
    終比對驗收報告.txt（那是「可不可以送出」的那張紙）與 終比對候選表.xlsx
    （報告說第三問有幾列，表上就要找得到那幾列）。

    一本都沒成功、或只剩一本成功時，這裡自然湊不出來源本，每本照樣寫「含跨本 0」。
    """
    import batch as bt
    import decision_table as dt
    import finalize_check as fc
    import notices as nt
    from _common import load_synonyms
    synonyms = load_synonyms()
    for book in state.values():
        outcome = book["info"]["outcome"]
        results = outcome["results"]
        baseline = outcome["baseline"]
        book["baseline"] = baseline
        # annotate_results 在 _compare_core 裡已經對同一份 results 跑過一次，
        # 這裡再叫一次只是為了拿 new_line_ids（引用連帶要用），跟 cmd_batch 一樣。
        book["new_line_ids"] = baseline.annotate_results(results) if baseline else {}
        # 跨本比對要的是「改成什麼樣子」，所以只收 added／modified 且有新文的；
        # 欄位與 cmd_batch 第 1 步組 changes 的那一段一模一樣。
        changes = []
        for r in results:
            if r["type"] in ("added", "modified") and r.get("new_text"):
                ids = r.get("spec_ids") or []
                changes.append({"條文ID": "、".join(ids), "ref": r.get("ref") or "",
                                "old_text": r.get("old_text") or "", "new_text": r["new_text"],
                                "段次": r.get("new_index") or 0,
                                "positions": [baseline._position(i) for i in ids] if baseline else []})
        book["changes"] = changes

    final_indexes = {}
    found_by = {}
    for tname, t in state.items():
        outcome = t["info"]["outcome"]
        params = t["params"]
        cross = []
        for sname, s in state.items():
            if sname == tname:
                continue
            found = []
            if s["changes"]:
                found = bt.cross_candidates(sname, s["changes"], outcome["new_paragraphs"],
                                            synonyms, params["threshold"], params["top"],
                                            params["changed_top"],
                                            sentence_threshold=params["sentence_threshold"],
                                            target_kinds=outcome.get("new_kinds"))
            if t["baseline"]:
                if s["changes"]:
                    found += bt.citation_links(sname, s["changes"], t["baseline"],
                                               t["new_line_ids"], outcome["new_paragraphs"])
            else:
                if sname not in final_indexes:
                    final_indexes[sname] = bt.SourceIndex(s["info"]["outcome"])
                found += bt.text_citation_links(sname, final_indexes[sname], outcome["new_paragraphs"])
            cross += found
        found_by[tname] = cross
    # 跟「開始」同一套分層＋全域上限（batch.select_cross）：驗收時一樣只列證據強的與分數最高的
    cap = int((settings or {}).get("跨本每處上限", bt.CROSS_TOP) or 0)
    found_by, _ = bt.select_cross(found_by, dict((n, s["changes"]) for n, s in state.items()), cap,
                                  strong_cap=int((settings or {}).get("跨本舊值上限", bt.CROSS_STRONG_TOP) or 0))
    import review_import as ri
    for tname, t in state.items():
        outcome = t["info"]["outcome"]
        params = t["params"]
        cross = found_by[tname]
        sources = set(r["異動條文ID"].split("：", 1)[0] for r in cross if "：" in (r.get("異動條文ID") or ""))
        info = t["info"]
        # 跨本列也要過第三問那把尺（fc.fresh_rows）：初比對決定表列過的、初比對的
        # 異動段落、人填「改」時指定的「改成什麼」，都不算「定稿冒出來的新候選」。
        # 兩邊共用同一支，才不會同一列在單本報告算新候選、在批次不算。
        fresh_cross = fc.fresh_rows(info["decision_rows"], info["sidecar"],
                                    dt.add_cross([], cross))
        # 「開始」時因為跨本上限沒列出來的段（系統檔案/跨本未列.json）：人本來就不用看，
        # 不能到驗收才冒出來變成新候選（以前被拉進流程的每一本都卡在「還有 N 處要看」）
        unlisted = _read_unlisted(t["outdir"])
        fresh_cross = [r for r in fresh_cross if dt.text_sha256(r.get("候選全文") or "") not in unlisted]
        answers = t["answers"]
        # 同一段在第一階段已經是「新候選」（這本自己的終比對抓到的）時不再加一次：
        # 候選表那邊 add_cross 是併進同一列，第三問這邊不去重就會同一段算兩筆。
        seen_lines = {(r.get("候選段次") or "").strip() for r in answers["新候選"]}
        fresh_cross = [r for r in fresh_cross
                       if (r.get("候選段次") or "").strip() not in seen_lines]
        answers["新候選"] = list(answers["新候選"]) + fresh_cross
        # 新鍵，只給摘要那一行用；不在 fc.BLOCKING_KEYS 裡，不會被重複計入結論。
        answers["跨本新候選數"] = len(fresh_cross)
        placed, unplaced = _append_fresh_rows(t["csv"], fresh_cross, info.get("draft_paragraphs"))
        answers[fc.APPENDED_KEY] = (answers.get(fc.APPENDED_KEY) or 0) + placed
        answers[fc.UNPLACED_KEY] = (answers.get(fc.UNPLACED_KEY) or 0) + unplaced
        info["final_rows"] = dt.add_cross(info["final_rows"], cross)
        # 跟單本終比對（_compare_core 的 final=True）走同一條路：表進 審閱文件/ 的
        # 終比對候選表.xlsx，指紋 .json 進 系統檔案/。兩邊寫法不一樣的話，
        # batch-finalize 補完跨本列會在同一個資料夾裡多長出一張舊格式的 csv。
        table_path = place(t["outdir"], "終比對候選表.xlsx")
        changed_texts = [r["new_text"] for r in outcome["results"]
                         if r["type"] in ("added", "modified")]
        try:
            dt.write_table(info["final_rows"], table_path, dt.sidecar_path_for(table_path),
                           t["clean"], changed_texts, params=params, fmt="xlsx")
        except OSError as exc:
            # 表寫不進去（最常見是還開在 Excel 裡）不能就這樣算了：報告會說第三問有
            # 幾列跨本，表上卻找不到那幾列。降級成警告留底，結論也會跟著保留。
            nt.notice(nt.WARNING,
                      "%s 的 終比對候選表 補跨本列時寫不進去（%s）；報告的第三問已含跨本，"
                      "但這張表還是補跨本之前的版本，關掉檔案後重跑 batch-finalize"
                      % (tname, exc), "batch-finalize")
        # 成功也要收：write_table 內部退成 csv 時（xlsx 被鎖住）會自己發一則
        # 「xlsx 寫不出來…已改出 csv」，那一則屬於**這一本**。不收走的話它會留在
        # 全域清單裡，被下一本的收提醒動作掃進下一本的報告，或一路漏到最後的
        # 批次_提醒.txt——講的是甲的表，卻寫在乙的那張紙上。
        t["提醒"] = t["提醒"] + nt.drain()
        acknowledged = ri.sync_warnings(outdir_of_table(t["csv"]), nt.warnings(t["提醒"]))
        # 報告要在表之後才重寫：上面那幾則也要出現在這一本的報告裡。
        fc.write_report(answers, info["report_path"], notices=t["提醒"], acknowledged=acknowledged)
        total = fc.blocking_total(answers)
        alerts = fc.unacknowledged(t["提醒"], acknowledged)
        if total == 0 and alerts:
            verdict = "三問皆零，但有 %d 則警告還沒人看過，要到人工確認表回覆" % len(alerts)
        elif total == 0:
            verdict = "改好" + ("（%d 則警告已確認）" % len(nt.warnings(t["提醒"])) if nt.warnings(t["提醒"]) else "")
        else:
            verdict = "還有 %d 處要看，請勿送出" % total
        t["摘要行"] = ("%s：%s（未改到 %d、未決定 %d、新候選 %d（含跨本 %d）、填了但等於原文 %d%s）"
                      "／提醒 %d 則／警告 %d 則%s" % (
                          tname, verdict, len(answers["未改到"]), len(answers["未決定"]),
                          len(answers["新候選"]), len(fresh_cross),
                          len(answers.get(fc.SAME_TEXT_KEY) or []), _confirm_suffix(answers),
                          len(t["提醒"]), len(alerts),
                          "／跨本來自 " + "、".join(sorted(sources)) if sources else ""))
        import change_reasons as cr
        reasons = cr.read_summary(t["outdir"])
        if reasons and (reasons.get("草擬") or reasons.get("請補")):
            reused = ["沿用上一版 %d 列" % reasons["沿用"]] if reasons.get("沿用") else []
            reused += ["人工確認的說明 %d 列" % reasons["人工確認"]] if reasons.get("人工確認") else []
            t["摘要行"] += "／修改依據 草擬 %d 列%s、請補 %d 列" % (
                reasons.get("草擬", 0), "（其中%s）" % "、".join(reused) if reused else "", reasons.get("請補", 0))


AI_REVIEW_SKIP = "AI審查略過.txt"


def cmd_batch_review_pack(args, settings):
    """批次第 1.5 步：逐本把候選與異動打包成審查包；loaded 讓跨本候選（異動條文ID
    是「A名：ref」那種）能到來源本查到異動全文，不用只看自己這本。

    兩階段：先逐本 rp.load_book 收集錯誤，任何一本讀不出來就整批「[中止]」、
    一個字都不寫；全部讀成功才逐本 write_pack。這樣「某本半路才發現壞掉」不會
    連累前面已經成功寫出的審查包（write_pack 是覆寫，半路中止會留下新舊混雜的
    產出）。loaded_books 傳給 write_pack 後，每本只在這裡 load_book 一次
    （不管是當自己還是被別本拿去跨本引用），不再是 N 本 N² 次讀檔。"""
    import batch as bt
    import notices as nt
    import review_pack as rp
    _apply_workspace_defaults(args, settings)
    nt.reset()
    outdir = args.outdir
    marker = os.path.join(outdir, "系統檔案", AI_REVIEW_SKIP)
    if getattr(args, "skip", False):
        os.makedirs(os.path.dirname(marker), exist_ok=True)
        with io.open(marker, "w", encoding="utf-8") as f:
            f.write("這一輪不做 AI 審查（batch-review-pack --略過）；要做就直接跑 batch-review-pack\n")
        say("這一輪不做 AI 審查：人工待辦不會再提醒；之後想做，直接跑 %s 就好" % _cmd("審查打包", workspace_flag(args)))
        return 0
    if os.path.isfile(marker):
        os.remove(marker)
    if _order_problem(args, "batch-review-pack"):     # 語意還沒併入只提醒；「[順序]」才擋（第三批）
        return 1
    try:
        book_list = bt.list_books(outdir)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    warn_if_legacy_books(outdir, [name for name, _ in book_list])
    # AI 填在合一表（產出/系統檔案/AI審查/）上的答案先寫回各本，重新打包才沿用得到
    if not _split_ai_tables(outdir, book_list):
        return 1

    all_errors = []
    loaded = {}
    for name, outdir_doc in book_list:
        try:
            loaded[name] = rp.load_book(outdir_doc)
        except rp.ReviewPackError as exc:
            all_errors.append("%s：%s" % (name, exc))
    if all_errors:
        say("[中止] 有本讀不到，整批沒寫：")
        for line in all_errors:
            say("  " + line)
        return 1

    # load_book 那一輪與底下 write_pack 那一輪都可能發提醒（某本是舊式留底、
    # 舊版是用檔名猜的、AI CSV 已有填答沒覆寫……）。畫面上印過了，但批次的畫面
    # 特別長，一定要同時留一份在產出根目錄——所以留底要等 write_pack 跑完才寫，
    # 中途中止也要先寫再走。
    def keep_notices():
        say("提醒留底：%s（%d 則）"
            % (show_path(nt.write_notices(outdir, "批次審查包",
                                          title="batch-review-pack（批次第 1.5 步）")),
               len(nt.collected())))

    # 第二階段一本失敗就整批停在那裡：前面幾本的審查包已經是新的、後面幾本還沒動，
    # 一定要講清楚是哪幾本更新了（實測 no 25：舊寫法沒有 try，直接噴 traceback，
    # 人看不出前面幾本到底寫了沒）。
    done = []
    for name, outdir_doc in book_list:
        try:
            info = rp.write_pack(outdir_doc, args.per_file, loaded_books=loaded, quiet=True,
                                 max_chars=getattr(args, "max_chars", rp.DEFAULT_MAX_CHARS))
        except (rp.ReviewPackError, OSError) as exc:
            say("[中止] %s 寫審查包失敗：%s；已完成 %d 本（%s），"
                "這幾本的審查包已更新，其餘 %d 本沒動"
                % (name, exc, len(done), "、".join(done),
                   len(book_list) - len(done) - 1))
            keep_notices()
            return 1
        done.append(name)
        line = ("%s：候選 %d 筆、異動 %d 處、審查包 %d 份"
                % (name, info["候選數"], info["異動數"], len(info["包"])))
        if info.get("保留填答"):
            line += "（沿用 AI 已判過的：%s）" % "、".join(info["保留填答"])
        say(line)
    keep_notices()
    import ai_tables as at
    counts = at.merge(outdir, book_list)
    waiting = sum(w for _, w in counts.values())
    say("AI 表：產出/系統檔案/%s/ 四張（全部規章合一，第一欄是規章），要填 %d 列%s；每一本要讀的審查包列在 "
        "產出/系統檔案/%s/%s" % (at.FOLDER, waiting, "（其餘沿用 AI 已判過的）" if any(t - w for t, w in counts.values())
                              else "", at.FOLDER, at.INDEX))
    return 0


def _split_ai_tables(outdir, book_list):
    """合一的 AI 表（產出/系統檔案/AI審查/）上 AI 改過的格寫回各本；有錯印「[中止]」回 False。"""
    import ai_tables as at
    errors, written, notes = at.split(outdir, book_list)
    for line in notes:
        say("[提醒] " + line)
    if errors:
        say("[中止] 產出/系統檔案/%s/ 的 AI 表有問題（改好再跑）：" % at.FOLDER)
        for line in errors:
            say("  " + line)
        return False
    if written:
        say("已把 產出/系統檔案/%s/ 上 AI 填的答案寫回各本：%s"
            % (at.FOLDER, "、".join("%s %d 格" % kv for kv in sorted(written.items()))))
    return True


def cmd_batch_review_import(args, settings):
    """批次第 1.5 步：先逐本只驗證兩張 AI CSV，任何一本有錯就整批中止、什麼都不寫；
    全部過了才逐本把三欄寫回連帶決定表、產各本報告，最後把三張表跨本併成
    LLM審查總表.xlsx（每列都帶「規章」欄，看得出是哪一本）。"""
    import batch as bt
    import notices as nt
    import review_import as ri
    import review_pack as rp
    _apply_workspace_defaults(args, settings)
    nt.reset()
    outdir = args.outdir
    if _order_problem(args, "batch-review-import"):
        return 1

    def keep_notices():
        # 驗原文的警告（哪幾本的哪幾列候選全文被手改過）一定要留底：批次的畫面
        # 特別長，這幾則最容易被後面的逐本統計洗掉。
        say("提醒留底：%s（%d 則）"
            % (show_path(nt.write_notices(outdir, "批次審查匯入",
                                          title="batch-review-import（批次第 1.5 步）")),
               len(nt.collected())))

    try:
        book_list = bt.list_books(outdir)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    warn_if_legacy_books(outdir, [name for name, _ in book_list])
    if not _split_ai_tables(outdir, book_list):
        return 1

    all_errors = []
    loaded = {}
    for name, outdir_doc in book_list:
        try:
            book = rp.load_book(outdir_doc)
            ai_cand, ai_change, ai_meta = ri.load_ai_files(outdir_doc)
        except (rp.ReviewPackError, ri.ReviewError) as exc:
            all_errors.append("%s：%s" % (name, exc))
            continue
        loaded[name] = book
        errors = ri.validate(book["rows"], book["changes"], ai_cand, ai_change, ai_meta)
        errors += ri.check_external(book, ri.load_external(outdir_doc))[0]
        # AI條文檢查 也在這一關驗：以前要到第二階段才擋，前面幾本已經寫進去了
        errors += ri.check_rulecheck(rp.rulecheck_items(outdir_doc), ri.load_rulecheck(outdir_doc))[0]
        all_errors += ["%s：%s" % (name, e) for e in errors]
    if all_errors:
        say("[中止] AI 判斷檔有問題，整批沒寫：")
        for line in all_errors:
            say("  " + line)
        import ai_tables as at
        if os.path.isdir(at.folder(outdir)):
            say("（AI 表在 產出/系統檔案/%s/，第一欄是規章：照上面的規章與編號找那一列改）" % at.FOLDER)
        return 1

    # 「原文已修改未匯入」只有在某本真的驗到不符時才會出現，所以工作表清單不能寫死
    # 三張：用 sheet_order 記實際出現過的順序，rows_by_sheet 也跟著 setdefault。
    # （寫死三張時，某本多出第四張表會讓總表這一段 KeyError 噴 traceback。）
    sheet_order = []
    headers = {}
    rows_by_sheet = {}
    mismatch_total = 0
    pending_total = 0
    done_count = 0
    name = None
    try:
        for name, outdir_doc in book_list:
            # book=loaded[name]：這本第一階段（驗證）已經 load_book 過一次，
            # 這裡不用再重讀一次連帶決定表／異動清單／docx。
            result = ri.import_review(outdir_doc, book_name=name, books=loaded, book=loaded[name])
            for sheet, header, rows in result["表"]:
                if sheet in headers and headers[sheet] != header:
                    raise bt.BatchError("總表欄位不一致：%s" % sheet)
                if sheet not in headers:
                    sheet_order.append(sheet)
                headers.setdefault(sheet, header)
                rows_by_sheet.setdefault(sheet, []).extend(rows)
            cand, change = result["候選"], result["異動"]
            line = ("%s：候選 %s；異動 %s" % (
                name, "、".join("%s %d 筆" % (v, cand[v]) for v in ri.CAND_VERDICTS),
                "、".join("%s %d 筆" % (v, change[v]) for v in ri.CHANGE_VERDICTS)))
            if result.get("外部引用"):
                line += "；外部引用 %s" % _external_counts_text(result["外部引用"])
            if result.get("條文檢查"):
                line += "；條文檢查高風險 %s" % _rulecheck_counts_text(result["條文檢查"])
            if result.get("原文不符"):
                line += "；原文不符 %d 列未匯入（列ID %s）" % (
                    len(result["原文不符"]), "、".join(result["原文不符"]))
                mismatch_total += len(result["原文不符"])
            if result.get("AI過期"):
                line += "；AI 判斷不是這一輪的 %d 列未匯入（列ID %s）" % (
                    len(result["AI過期"]), "、".join(result["AI過期"]))
                mismatch_total += len(result["AI過期"])
            if result.get("人工待確認"):
                line += "；待人工確認 %d 項" % result["人工待確認"]
                pending_total += result["人工待確認"]
            say(line)
            done_count += 1
    except (ri.ReviewError, rp.ReviewPackError, OSError, bt.BatchError) as exc:
        # 這本已經在第一階段驗證過，理論上不會再失敗；防禦式地照樣中止，別讓
        # traceback 洩出去。前面成功匯入的本，決定表與各本報告已經真的寫了
        # （import_review 一本一本各自獨立寫），總表沒寫出來，整批視為沒完成，
        # 下次重跑 batch-review-import 會照 import_review 的寫回邏輯整批重寫。
        say("[中止] %s 寫入失敗：%s" % (name, exc))
        say("前面 %d 本已寫入（AI 三欄與各本報告），總表未產生；修正後重跑 batch-review-import 會整批重寫。"
            % done_count)
        keep_notices()
        return 1

    # 逐本迴圈與總表寫入分開接：迴圈跑完 name 還留著最後一本的值，如果總表寫入
    # （迴圈外）本身失敗，跟上面那段共用同一個 except 會把總表的失敗講成是最後
    # 一本的失敗——但那本其實已經成功寫完了，錯的是總表這一步，要單獨講清楚。
    tables_all = [(sheet, headers[sheet], rows_by_sheet[sheet]) for sheet in sheet_order]
    try:
        # 總表跟各本的 LLM審查報告 一樣是人要看的 → 審閱文件/。place 回傳帶副檔名的
        # 路徑，write_report 要的是不帶副檔名的 base（它自己決定寫 xlsx 還是退 csv）。
        xlsx_path = ri.write_report(
            os.path.splitext(place(outdir, "LLM審查總表.xlsx"))[0], tables_all)
    except OSError as exc:
        say("[中止] 總表寫入失敗：%s" % exc)
        say("各本已寫入（%d 本）；只有總表沒產生，關掉 LLM審查總表.xlsx 再重跑" % done_count)
        keep_notices()
        return 1
    if mismatch_total:
        say("原文不符或 AI 判斷不是這一輪的共 %d 列未匯入（跨 %d 本合計）；見總表的「%s」表"
            % (mismatch_total, done_count, ri.MISMATCH_SHEET))
    say("總表：%s" % show_path(xlsx_path))
    keep_notices()
    # 核准預覽跟著匯入一起出來：人不用再另外下一次 核准 --預覽 才知道 AI 建議明確的有哪幾列
    import approve as ap
    import decision_table as dt
    tables = []
    for name, outdir_doc in book_list:
        try:
            tables.append((name, dt.read_table(locate(outdir_doc, "連帶決定表.csv")[0])))
        except dt.DecisionTableError:
            continue
    change, keep = ap.write_preview(place(outdir, ap.PREVIEW_FILE), tables, _cmd("核准", workspace_flag(args)))
    if change or keep:
        say("AI 建議很明確、可以一次決定的：照建議改 %d 列、不改 %d 列（明細：產出/審閱文件/%s）"
            % (change, keep, ap.PREVIEW_FILE))
    if pending_total:
        say("AI 查證後還有 %d 項要人確認：在 產出/填寫表單/人工確認.csv（全部規章一張）" % pending_total)
    say("AI 只是建議，要不要改由人決定；最終仍需人工複核。")
    return 0


# ---------------------------------------------------------------------------
# 工作區：配對／開始
# ---------------------------------------------------------------------------

def cmd_pair(args, settings):
    """配對：把 匯入/現行規章、匯入/修訂規章 的檔名配對，寫 匯入/規章清單.csv 給人確認。

    寫清單前先讀既有清單（有的話），把「手動」列蓋回這次重算的結果
    （workspace.merge_manual），人填過的舊版／新版草稿／發布根目錄／備註才不會
    被自動配對整份覆蓋。"""
    import workspace as ws
    root = ws.resolve_root(args.workspace, settings)
    for note in ws.migrate_legacy(root):
        say(note)
    return _pair(root)


def _pair(root, from_start=False):
    """配對本體（配對、開始 共用）。回傳 0＝清單可以用；1＝有要人處理的列、或清單寫不出來。
    from_start：「開始」自己叫的（還沒有清單、或清單過期）——配得乾淨就直接往下跑，
    最後那一句不叫人「對了就跑開始」。"""
    import batch as bt
    import notices as nt
    import workspace as ws
    from _common import SUPPORTED_EXTS
    created = ws.ensure_layout(root)
    if created:
        say("已建立工作區：%s" % root)
    p = ws.paths(root)
    old_names, old_skipped = ws.list_inputs(p["舊版"])
    new_names, new_skipped = ws.list_inputs(p["新版"])
    # no 14：不支援的副檔名以前是安靜跳過的——使用者丟十本進來，畫面寫「配對 8 本」，
    # 少的那兩本（.doc、.pdf）連一行字都沒有。走 notices 才會同時上畫面與留底。
    skipped = (["%s/%s" % (ws.OLD_DIR, n) for n in old_skipped]
               + ["%s/%s" % (ws.NEW_DIR, n) for n in new_skipped])
    if skipped:
        nt.notice(nt.REMINDER,
                  "略過 %d 個不支援的檔：%s（只認 %s）"
                  % (len(skipped), "、".join(skipped), "/".join(SUPPORTED_EXTS)), "配對")
    # M3：白名單放寬之後，匯入夾裡的 .txt／.md 會變成一本規章——這對「草稿就是
    # 純文字」的人是對的，對「放了一張備忘或說明檔」的人是驚嚇（清單突然多一本、
    # 過期檢查還會要求把它列進去）。所以只要真的收了 .txt／.md 就講一聲。
    texts = (["%s/%s" % (ws.OLD_DIR, n) for n in old_names if not n.lower().endswith(".docx")]
             + ["%s/%s" % (ws.NEW_DIR, n) for n in new_names if not n.lower().endswith(".docx")])
    if texts:
        nt.notice(nt.REMINDER,
                  "匯入/ 有 %d 個 .txt/.md 檔已當成規章：%s；若是備忘或說明檔請移走"
                  % (len(texts), "、".join(texts)), "配對")
    spec_names = ws.list_spec_names(p["規格包"])
    auto_rows = ws.match(old_names, new_names, spec_names)
    try:
        old_rows = ws.read_manifest_rows(p["清單"]) if os.path.isfile(p["清單"]) else []
    except ws.WorkspaceError as exc:
        # item5：既有清單本身壞掉（缺欄位、配對方式亂填）不該噴 traceback——跟其他
        # 子命令一致，印「[中止]」、exit 1，讓人去看清單哪裡壞了。
        say("[中止] %s" % exc)
        return 1
    rows, kept_names, dropped_names, draft_missing = ws.merge_manual(auto_rows, old_rows, root)
    try:
        ws.write_manifest(rows, p["清單"])
    except OSError as exc:
        # item5：清單常見的失敗是檔案開在 Excel 裡（Windows 鎖檔）——這是 OSError，
        # 沒接住會直接噴 traceback。寫檔失敗這裡就中止，不要再往下印「請確認
        # 匯入/規章清單.csv」之類的下一步提示，因為這次根本沒寫成。
        say("[中止] 規章清單寫入失敗：%s（可能開在 Excel）；請關掉後重跑 配對" % exc)
        return 1
    ws.print_table(rows)
    if kept_names:
        say("沿用手動列 %d 筆：%s" % (len(kept_names), "、".join(kept_names)))
    if dropped_names:
        say("手動列 %s 的檔不存在，已改回自動配對" % "、".join(dropped_names))
    if draft_missing:
        # no 16：手動列的草稿被刪掉時，以前整列原樣寫回去，要跑到「開始」的過期檢查
        # 才被擋；欄位已經清空了，這裡得講一聲，不然人只會看到草稿欄莫名其妙變空。
        nt.notice(nt.WARNING,
                  "%d 個手動列的新版草稿不存在，已清空草稿欄並標「%s」：%s"
                  % (len(draft_missing), ws.DRAFT_MISSING_NOTE,
                     "、".join("%s（%s）" % (name, rel) for name, rel in draft_missing)),
                  "配對")
    need_human = [r for r in rows if not r["舊版"]]
    # 修正回合 1（I1）：草稿不存在的手動列跟「未配對／多個候選」是同一級的「還沒配好」。
    # 只發警告不擋的話，使用者照畫面跑「開始」，那一列草稿欄是空的，整條流程會把它
    # 當成「這本沒改」安靜跳過——人明明改過這本，對照表卻一個字都沒有。判斷看的是
    # 清單裡留下來的備註（不是這一輪才偵測到的 draft_missing），所以重跑配對還是會擋，
    # 直到人真的去補檔或把那一列改回一般的「沒改」列。
    draft_rows = [r for r in rows
                  if r["舊版"] and r.get("備註") == ws.DRAFT_MISSING_NOTE]
    if not need_human:
        # no 15：清單寫出去了，但「開始」還會再跑一次 batch.read_manifest——規章名重複、
        # 同一份舊版／草稿被兩列引用，這三件事以前要等使用者照畫面指示跑「開始」才會
        # 被擋（畫面上剛剛還寫著「對了就跑 開始」）。同一套驗證在這裡先跑一次，錯就
        # 中止並把列號原樣印出來。未配對／多個候選走原本那條路（read_manifest 也會擋，
        # 但它的訊息沒有下面那句「請改檔名或補舊版」的指引）。
        try:
            bt.read_manifest(p["清單"])
        except bt.BatchError as exc:
            say("[中止] 清單有問題：%s" % exc)
            return 1
    if from_start:
        say(ws.summarize(rows, skipped=len(skipped))
            + "。配錯了就改 匯入/規章清單.csv（那一列「配對方式」寫「手動」）再跑 繼續（或 開始）")
    else:
        say(ws.summarize(rows, skipped=len(skipped)) + "。請確認 匯入/規章清單.csv，對了就跑 開始")
    todo = need_human + draft_rows
    if todo:
        text = ("有 %d 本要人處理：未配對的請改檔名或補舊版；多個候選的請在清單填「舊版」"
                "並把「配對方式」寫「手動」" % len(todo))
        if draft_rows:
            text += ("；草稿不存在的（%s）請補檔或清掉草稿欄並把「配對方式」改回空白"
                     % "、".join(r["規章名"] for r in draft_rows))
        say(text)
    return 1 if todo else 0


def _previous_round_leftovers(out_root, docs):
    """上一輪驗收已經「改好」的規章，匯入/ 裡還是上一輪的檔：回傳要講給人聽的句子。

        現行規章、修訂版都跟上一輪一樣        → 現行規章沒換成定稿、修訂版也沒換
        現行規章已經是上一輪的定稿、修訂版沒換 → 修訂規章裡還是上一輪的草稿
    """
    import decision_table as dt
    from _common import result_home
    lines = []
    for doc in docs:
        if not doc["有草稿"]:
            continue
        name = doc["規章名"]
        folder = book_dir(out_root, name)
        table = locate(folder, "連帶決定表.csv")[0]
        report = locate(folder, "終比對驗收報告.txt")[0]
        if not (os.path.isfile(table) and os.path.isfile(report)):
            continue
        try:
            side = dt.read_sidecar(dt.sidecar_path_for(table))
            with io.open(report, encoding="utf-8-sig") as f:
                verdict = [line for line in f if line.startswith("結論：")]
        except (OSError, ValueError, dt.DecisionTableError):
            continue
        if not (verdict and verdict[-1].startswith("結論：改好")):
            continue
        draft_same = dt.file_sha256(doc["草稿"]) == (side.get("草稿") or {}).get("SHA256")
        old_same = dt.file_sha256(doc["舊版"]) == (side.get("舊版") or {}).get("SHA256")
        clean = os.path.join(result_home(folder), "新版定稿_乾淨版.docx")
        old_is_final = os.path.isfile(clean) and dt.file_sha256(doc["舊版"]) == dt.file_sha256(clean)
        if draft_same and old_same:
            lines.append("%s：上一輪已經定稿（驗收改好），但 匯入/現行規章 還是修正前的版本、匯入/修訂規章 還是上一輪的修訂版。"
                         "把 產出/結果彙整/新版定稿（乾淨版）/%s_新版定稿_乾淨版.docx 複製到 匯入/現行規章/、改名成 %s"
                         "（取代舊的），再把 匯入/修訂規章/%s 換成這一輪的修訂版（這一輪不改就拿掉）"
                         % (name, name, os.path.basename(doc["舊版"]), os.path.basename(doc["草稿"])))
        elif draft_same and old_is_final:
            lines.append("%s：匯入/現行規章 已經換成上一輪的定稿，但 匯入/修訂規章/%s 還是上一輪的修訂版："
                         "換成這一輪的修訂版，這一輪不改就拿掉" % (name, os.path.basename(doc["草稿"])))
    return lines


def cmd_start(args, settings):
    """開始：讀清單 → 過期檢查 → 清單本身可用（未配對就先擋，不能歸檔）→
    歸檔上一輪 → 一律走批次機制（等同 batch，路徑固定）。"""
    import batch as bt
    import workspace as ws
    root = ws.resolve_root(args.workspace, settings)
    for note in ws.migrate_legacy(root):
        say(note)
    p = ws.paths(root)
    _set_display_root(root)
    # 以前沒有清單就叫人先跑配對、清單過期就叫人重跑配對，多一個指令；現在直接配。
    # 配得乾淨就往下跑（配對表照樣印出來給人看），有未配對／多個候選才停下來請人處理。
    if not os.path.isfile(p["清單"]):
        say("還沒有 匯入/規章清單.csv：先配對")
        if _pair(root, from_start=True):
            return 1
    try:
        rows = ws.read_manifest_rows(p["清單"])
    except ws.WorkspaceError as exc:
        say("[中止] %s" % exc)
        return 1

    reasons = ws.stale_reasons(rows, root)
    if reasons:
        say("清單過期（匯入/ 的檔跟清單不一樣），重新配對：")
        for reason in reasons:
            say("  " + reason)
        if _pair(root, from_start=True):
            return 1
        try:
            rows = ws.read_manifest_rows(p["清單"])
        except ws.WorkspaceError as exc:
            say("[中止] %s" % exc)
            return 1

    # C1：清單本身要能用（沒有「未配對」列）才可以歸檔上一輪——bt.read_manifest
    # 就是 cmd_batch 稍後會跑的同一道檢查，這裡先跑一次是為了在歸檔（搬動
    # 產出/、批次摘要.txt）之前就擋下來；不然「未配對」列讓 cmd_batch 中止時，
    # 上一輪的產出已經被搬進 歷次/，沒東西可看也退不回去。
    try:
        docs = bt.read_manifest(p["清單"])
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    # 上一輪已經定稿的規章，匯入/ 裡的檔還沒換：照跑的話同樣的修改會被當成新異動再處理一次
    # （要在歸檔之前查：上一輪的驗收報告、定稿還在原位）
    leftovers = [] if getattr(args, "force_rerun", False) else _previous_round_leftovers(p["產出"], docs)
    if leftovers:
        say("[中止] 上一輪已經定稿的規章，匯入/ 裡的檔還沒換：")
        for line in leftovers:
            say("  - " + line)
        say("換好之後再跑 開始；確定要照現在的檔重跑，就加 --照跑")
        return 1

    names = [r["規章名"] for r in rows if r["舊版"]]
    try:
        moved = ws.archive_previous(root, names)
    except ws.WorkspaceError as exc:
        say("[中止] %s" % exc)
        return 1
    if moved:
        say(archive_line(moved))

    ns = argparse.Namespace(**vars(args))
    ns.manifest = p["清單"]
    # item3：這裡已經自己歸檔過一次（上面那段），cmd_batch 不能再歸檔一次，不然
    # 同一輪「開始」會把剛歸檔好的東西又搬進 歷次/ 一次。cmd_batch 用
    # `bool(args.outdir)`（在它補上工作區預設值之前）判斷 outdir 是不是「呼叫端
    # 明給的」；這裡明確把 ns.outdir 設成 p["產出"]，讓它看起來就是明給的，
    # 自然跳過歸檔那一段——不需要另外加旗標。
    ns.outdir = p["產出"]
    # main() 收尾要靠 args.outdir 找各本更新檢視報告；ns 是複本，原本那份也要補上
    args.outdir = p["產出"]
    # 下一步由 cmd_batch 結尾統一印（say_next_after_compare）：以前這裡另外再印一組，
    # 跟 batch 自己那一句講的順序不一樣，人不知道該照哪一組做。
    return cmd_batch(ns, settings)


# ---------------------------------------------------------------------------
# 繼續：照人工待辦同一套判斷，程式能做的站一站接一站跑
# ---------------------------------------------------------------------------

CONTINUE_MAX_STEPS = 8
# 批次指令的中文名（第四批 28；英文名照樣能用）。繼續、人工待辦印給人看的一律用中文名
CHINESE_NAMES = {"batch": "批次比對", "batch-semantic": "語意併入", "batch-review-pack": "審查打包",
                 "batch-review-import": "審查匯入", "batch-apply": "套用", "batch-finalize": "驗收",
                 "cut": "切條"}


def cmd_continue(args, settings):
    """繼續：看各本走到哪（todo.next_step，跟人工待辦同一套判斷），程式能做的站接著做——
    重跑開始、併入帶回來的語意交換包、產審查包、匯入 AI 填好的表、套用、驗收——做到要人
    （或 AI）動手的那一站就停。不替人做決定：填決定表、核准、人工確認、語意要不要略過，一律停下來。
    AI 審查那一站要四張 AI 表都填完才匯入（沒填完就停，講還差幾列）。"""
    import ai_tables as at
    import batch as bt
    import todo
    import workspace as wsm
    root = wsm.resolve_root(getattr(args, "workspace", ""), settings)
    for note in wsm.migrate_legacy(root):
        say(note)
    if wsm.ensure_layout(root):
        say("已建立工作區：%s（現行規章放 匯入/現行規章/、這次的修訂版放 匯入/修訂規章/）" % root)
    p = wsm.paths(root)
    _set_display_root(root)
    args.outdir = p["產出"]
    import publish_round as pr
    if pr.retry_manifest(p["產出"], root):
        say("上一次發布時規章清單開著沒改到，已經補改")
    last = None
    for _ in range(CONTINUE_MAX_STEPS):
        step = todo.next_step(p["產出"], root)
        command = step["指令"]
        if not command:
            say("")
            say("繼續：停在這一站——%s" % step["說明"])
            return 0
        if step.get("先看AI"):
            try:
                books = bt.list_books(p["產出"])
            except bt.BatchError as exc:
                say("[中止] %s" % exc)
                return 1
            errors, _, notes = at.split(p["產出"], books)
            for line in notes:
                say("[提醒] " + line)
            if errors:
                say("[中止] 產出/系統檔案/%s/ 的 AI 表有問題（改好再跑 繼續）：" % at.FOLDER)
                for line in errors:
                    say("  " + line)
                return 1
            missing = at.unanswered(books)
            if missing:
                say("")
                say("繼續：停在 AI 審查——還有 %s 沒填「AI判斷」：AI 讀 產出/系統檔案/%s/%s，填好那裡的表再跑 繼續"
                    % ("、".join("%s %d 列" % kv for kv in sorted(missing.items())), at.FOLDER, at.INDEX))
                return 0
        if command == last:
            say("繼續：%s 跑完了，下一站還是它（原因見上面），先停下來" % command)
            return 1
        if step.get("看修訂") and last == "batch-apply":
            # 這一次才剛套用、修訂自動驗證就沒過：一定要人先用 Word 看過，不能同一次就接著驗收（A4）。
            # 人看完再跑 繼續（那是新的一次）才驗收；驗收會把這一則警告列進人工確認表，填「已確認」才算改好
            say("")
            say("繼續：停在看修訂——%s" % step["說明"])
            return 0
        say("")
        say("── 繼續：%s（%s）──" % (step["說明"], CHINESE_NAMES.get(command, command)))
        argv = [command] + (["--workspace", root] if getattr(args, "workspace", "") else [])
        sub = build_parser().parse_args(argv)
        sub.in_continue = True
        rc = _run_command(sub, settings, show_todo=False)
        if rc:
            args.start_failed = command == "開始"
            return rc
        last = command
    say("繼續：已經連跑 %d 站，先停下來" % CONTINUE_MAX_STEPS)
    return 0


# ---------------------------------------------------------------------------
# 發布（簽完之後）與公文草稿（選用）
# ---------------------------------------------------------------------------

def cmd_publish(args, settings):
    """發布：簽完之後，驗收改好的新版定稿換成 匯入/現行規章 的那一份、修訂版收走（見 publish_round）。
    換下來的先備份到 產出/系統檔案/歷次/發布_<時間>/。--預覽 只列出會怎麼換、什麼都不動。"""
    import batch as bt
    import publish_round as pr
    import workspace as wsm
    root = wsm.resolve_root(getattr(args, "workspace", ""), settings)
    p = wsm.paths(root)
    _set_display_root(root)
    args.outdir = p["產出"]
    if pr.retry_manifest(p["產出"], root):
        say("上一次發布時規章清單開著沒改到，已經補改")
    try:
        ready, skipped = pr.plan(p["產出"], root)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    for name, why in skipped:
        say("%s：不發布（%s）" % (name, why))
    if not ready:
        settled = ("已經發布過了", "本次沒有修改，現行規章不用換")
        if any(why == settled[0] for _, why in skipped) and all(why in settled for _, why in skipped):
            say("這一輪要發布的都已經發布過了")
            return 0
        say("沒有可以發布的規章：驗收改好的才發布（照人工待辦把這一輪做完）")
        return 1
    say("%s %d 本：" % ("預覽——會發布" if args.preview else "發布", len(ready)))
    for item in ready:
        say("  %s：%s ← %s" % (item["規章"], show_path(item["新現行"]), show_path(item["定稿"])))
        if item["修訂版"]:
            say("      修訂版 %s 收走" % show_path(item["修訂版"]))
        if item["請補"]:
            say("      [提醒] 修正對照表還有 %d 列寫「請補修正理由」：簽核的那一份應該已經補了，確認一下" % item["請補"])
        if item["規格包"]:
            say("      [提醒] 這一本有規格包：發布後舊的規格包對不上新的現行規章，發布完跑 建基準 重建，下一輪比對才對得上")
    if args.preview:
        say("這是預覽，什麼都沒動。使用者看過、說好，才跑 %s（換下來的舊版與修訂版會先備份）"
            % _cmd("發布", workspace_flag(args)))
        return 0
    try:
        backup, done = pr.execute(p["產出"], ready, workspace_root=root)
    except pr.PublishError as exc:
        say("[中止] %s" % exc)
        return 1
    say("發布完成 %d 本：%s" % (len(done), "、".join(d["規章"] for d in done)))
    record = pr.load_record(p["產出"]).get("規章") or {}
    for d in done:
        left = (record.get(d["規章"]) or {}).get("沒收走")
        if left:
            say("[提醒] %s 已經發布，但 %s 沒收走（可能開著）：關掉後手動刪掉，備份裡有一份"
                % (d["規章"], "、".join(left)))
    say("換下來的現行規章與收走的修訂版在 %s（要找回來從那裡拿）；紀錄在 產出/審閱文件/%s"
        % (show_path(backup), pr.LOG))
    return 0


def cmd_official(args, settings):
    """公文（選用）：替驗收改好的每一本寫一份簽稿草稿（見 official_draft）。只放對照表上查得到的事實，
    依據、生效日期、還沒補的修正理由留給人。"""
    import official_draft as od
    import publish_round as pr
    import todo
    import workspace as wsm
    root = wsm.resolve_root(getattr(args, "workspace", ""), settings)
    p = wsm.paths(root)
    _set_display_root(root)
    out = p["產出"]
    published = set((pr.load_record(out).get("規章") or {}))
    names = [s["規章"] for s in todo.statuses_of(out)
             if not s["本次未修改"] and (s["階段"] == "送簽前" or s["規章"] in published)]
    if not names:
        say("還沒有驗收改好的規章：簽稿草稿要等改好再產（照人工待辦把這一輪做完）")
        return 1
    for name in names:
        rows = od.table_rows(out, name)
        if rows is None:
            say("%s：找不到修正對照表，略過" % name)
            continue
        say("%s：%s" % (name, show_path(od.write(out, name, od.lines_for(name, rows)))))
    say("簽稿草稿是骨架：依據、生效日期、還寫「請補修正理由」的，要承辦補上；改寫、核對後再用。")
    return 0


# ---------------------------------------------------------------------------
# 建基準（批次切條）：發布之後重建規格包
# ---------------------------------------------------------------------------

def _cut_args(folder, source, **extra):
    ns = argparse.Namespace(folder=folder, source=source, inherit=None, decisions=None, version=None,
                            name=None, release_root=None, org="", ver="", min_align=0.95, toc=None)
    for key, value in extra.items():
        setattr(ns, key, value)
    return ns


def cmd_baseline(args, settings):
    """建基準：改內規發布出去的新版，接著切條、重建規格包（見 baseline_batch）。
    第一趟切到複核表停下來（AI 填 AI建議、人填決定）；決定都填完再跑一次，就切完、發布到 匯入/規格包/<規章名>/。"""
    import baseline_batch as bb
    import batch as bt
    import workspace as wsm
    root = wsm.resolve_root(getattr(args, "workspace", ""), settings)
    p = wsm.paths(root)
    _set_display_root(root)
    if args.follow_ai:
        try:
            done = bb.follow_ai(root, apply=not args.preview)
        except bb.BaselineError as exc:
            say("[中止] %s" % exc)
            return 1
        for name, item_id, text in done:
            say("  %s %s　保留　%s" % (name, item_id, text))
        if args.preview:
            say("預覽：AI 建議「保留」、決定還空著的 %d 列會填「保留」（複核表沒有動）。使用者看過說好，才拿掉 --預覽 再跑" % len(done))
        else:
            say("照 AI 建議填了 %d 列「保留」（決定欄寫明依 AI 建議、人核准）" % len(done))
        return 0
    state = bb.load_state(root)
    status = bb.form_status(root)
    if state and status and not args.restart:
        total, blank, no_ai, bad, conflicts = status
        for line in bad:
            say("[中止] " + line)
        if bad:
            return 1
        changed = [n for n, info in state.items() if bb._sha(info["來源"]) != info["來源SHA256"]]
        if changed:
            say("現行規章在第一趟之後又換過（%s）：重新跑第一趟" % "、".join(changed))
        elif conflicts:
            say("有 %d 列沿用上一版的決定、AI 卻建議別的，要人決定：" % len(conflicts))
            for line in conflicts:
                say("  " + line)
            say("人決定完再跑 %s" % _cmd("建基準", workspace_flag(args)))
            return 0
        elif blank:
            say("複核表還有 %d 列沒填「決定」（%s）：%s/%s/%s"
                % (sum(blank.values()), "、".join("%s %d" % kv for kv in sorted(blank.items())),
                   show_path(root), bb.FOLDER, bb.FORM))
            if no_ai:
                say("其中 %d 列 AI 還沒填「AI建議」：AI 照 %s/%s/%s 填好再請人決定"
                    % (no_ai, show_path(root), bb.FOLDER, bb.INDEX))
            say("人填完「決定」（或看過預覽說好後跑 %s）再跑 %s"
                % (_cmd("建基準", workspace_flag(args), "--照AI建議"), _cmd("建基準", workspace_flag(args))))
            return 0
        else:
            return _baseline_publish(args, settings, root, state)
    # 第一趟
    try:
        names = [x.strip() for x in (args.books or "").replace("、", ",").split(",") if x.strip()]
        docs, skipped = bb.pick(root, names, args.all)
    except (bb.BaselineError, bt.BatchError) as exc:
        say("[中止] %s" % exc)
        return 1
    for name, why in skipped:
        say("%s：不建（%s）" % (name, why))
    if not docs:
        say("沒有要重建的規格包：規格包都跟現行規章對得上。第一次建基準用 --規章 甲要點,乙手冊 或 --全部")
        return 0
    state = {}
    base = bb.base_dir(root)
    for doc in docs:
        name = doc["規章名"]
        folder = os.path.join(base, name)
        if os.path.isdir(folder):
            shutil.rmtree(folder)              # 上一次的切條檔：來源換了，整份重切
        os.makedirs(folder)
        release = bb.release_root_of(root, doc)
        inherit = release if bb.spec_source_sha(release) else None
        say("")
        say("── 建基準：%s（%s）──" % (name, "沿用上一版的複核決定" if inherit else "第一次建，全部由人複核"))
        rc = cmd_cut(_cut_args(folder, doc["舊版"], inherit=inherit), settings)
        if rc:
            say("[停] %s 第一趟沒過（原因見上面）：這一本這次不建" % name)
            continue
        state[name] = {"來源": doc["舊版"], "來源SHA256": bb._sha(doc["舊版"]), "資料夾": folder,
                       "舊規格包": inherit or "", "規格包": release}
    if not state:
        say("[中止] 沒有一本過得了第一趟")
        return 1
    bb.save_state(root, state)
    total, blank = bb.merge_forms(root, state)
    say("")
    say("第一趟完成 %d 本：%s" % (len(state), "、".join(sorted(state))))
    say("複核表：%s/%s/%s（全部規章一張，第一欄是規章）共 %d 列，要填「決定」%d 列"
        % (show_path(root), bb.FOLDER, bb.FORM, total, blank))
    say("AI 先照 %s/%s/%s 填「AI建議」「AI理由」；人填「決定」，填完再跑 %s"
        % (show_path(root), bb.FOLDER, bb.INDEX, _cmd("建基準", workspace_flag(args))))
    return 0


def _baseline_publish(args, settings, root, state):
    """建基準第二趟：複核表拆回各本 → cut 第二趟（S6 套用 → S7–S12）→ 發布到各本的規格包。"""
    import baseline_batch as bb
    import workspace as wsm
    try:
        filled = bb.split_forms(root, state)
    except bb.BaselineError as exc:
        say("[中止] %s" % exc)
        return 1
    done, failed = [], []
    for name in sorted(state):
        info = state[name]
        release = info["規格包"]
        version = args.version or bb.next_version(release)
        say("")
        say("── 建基準：%s 第二趟，發布版號 %s ──" % (name, version))
        rc = cmd_cut(_cut_args(info["資料夾"], info["來源"], decisions=filled[name], version=version,
                               name=name, release_root=release), settings)
        if rc:
            failed.append(name)
            continue
        done.append((name, version, release))
    if done:
        # 清單的「發布根目錄」補上：下一輪開始就帶這一份規格包比對
        p = wsm.paths(root)
        if os.path.isfile(p["清單"]):
            rows = wsm.read_manifest_rows(p["清單"])
            for row in rows:
                for name, _, release in done:
                    if row["規章名"] == name and not row["發布根目錄"]:
                        row["發布根目錄"] = os.path.relpath(release, p["匯入"]).replace(os.sep, "/")
            wsm.write_manifest(rows, p["清單"])
        for name, _, _ in done:
            state.pop(name, None)
        if state:
            bb.save_state(root, state)
        else:
            shutil.rmtree(bb.base_dir(root), ignore_errors=True)   # 全部發布完：工作檔收掉（正式版在規格包裡）
    say("")
    for name, version, release in done:
        say("%s：規格包發布完成（版號 %s）：%s" % (name, version, show_path(release)))
    if failed:
        say("[停] %s 第二趟沒過（原因見上面）：處理好再跑 %s" % ("、".join(failed), _cmd("建基準", workspace_flag(args))))
        return 1
    say("下一輪改內規會自動帶這一份規格包比對（匯入/規格包/<規章名>/）。")
    return 0


# ---------------------------------------------------------------------------
# cut：切條產線 S2 → S12
# ---------------------------------------------------------------------------

STAGES_FIRST = ["S2_驗收.py", "S3_切條.py", "S4_二次切分.py", "QA_法遵稽核.py", "S5_品質旗標.py"]
GATES = {"S2_驗收.py", "QA_法遵稽核.py", "S6_套用決定.py", "S10_還原對帳.py", "S12_發布版本.py"}


def run_script(name, argv, log_dir):
    """跑一支 diffcut 腳本。完整輸出寫 logs/，畫面只印最後 12 行。"""
    import subprocess
    path = os.path.join(DIFFCUT, name)
    result = subprocess.run([sys.executable, path] + list(argv), capture_output=True,
                            text=True, encoding="utf-8", errors="replace")
    os.makedirs(log_dir, exist_ok=True)
    with io.open(os.path.join(log_dir, name[:-3] + ".log"), "w", encoding="utf-8") as f:
        f.write(result.stdout or "")
        if result.stderr:
            f.write("\n--- stderr ---\n" + result.stderr)
    for line in (result.stdout or "").strip().splitlines()[-12:]:
        say("  " + line)
    say("--- %s：%s ---" % (name, "過" if result.returncode == 0 else "沒過（exit %d）" % result.returncode))
    return result.returncode


def check_source_alignment(folder, source):
    """01_paragraphs.csv 的全文對上 --source 讀出的段落，回傳對齊比例。

    兩個方向都要對：「來源有多少被 S1 匯出來了」（分母是來源）與「匯出的有多少來自
    來源」（分母是 01），取小的那個。只看一邊都會漏：
        分母只用 01    匯出漏了幾段時，01 的每一列都對得到來源，比例照樣 100%
        分母只用來源   S1 切的是草稿（多出定稿刪掉的段落）時照樣 100%，多出來的段落
                       一路進到正式版，manifest 卻記著定稿的雜湊
    01 裡的表格／圖形記號列（[[TABLE:001]]）來源本來就沒有，不算進 01 那一邊的分母。
    """
    import csv as _csv
    import difflib
    import re as _re
    from _common import read_paragraphs
    import decision_table as dt
    marker = _re.compile(r"^(?:\[\[(?:TABLE|SHAPE):\d+\]\])+$")
    with io.open(os.path.join(folder, "01_paragraphs.csv"), encoding="utf-8-sig", newline="") as f:
        reader = _csv.DictReader(f)
        if "全文" not in (reader.fieldnames or []):
            return None      # 01 不是 S1 的格式，讓呼叫端印中文提示，不要噴 KeyError
        exported = [dt.normalize(row["全文"]) for row in reader]
    exported = [t for t in exported if not marker.match(t)]
    actual = [dt.normalize(p) for p in read_paragraphs(source)]
    if not exported or not actual:
        return 0.0
    matcher = difflib.SequenceMatcher(None, exported, actual, autojunk=False)
    matched = sum(block.size for block in matcher.get_matching_blocks())
    return matched / float(max(len(actual), len(exported)))


def cmd_cut(args, settings, runner=None):
    folder = os.path.abspath(args.folder)
    log_dir = os.path.join(folder, "logs")
    runner = runner or (lambda name, argv: run_script(name, argv, log_dir))
    say("=" * 60)
    say("第 5 步　切條產線　資料夾：%s" % folder)
    say("=" * 60)
    if not args.source or not os.path.isfile(args.source):
        say("[中止] --source 必須指向 S1 切的那份原檔（定稿乾淨版）。")
        return 1
    if not os.path.isfile(os.path.join(folder, "01_paragraphs.csv")):
        if not args.source.lower().endswith(".docx"):
            say("[中止] 找不到 01_paragraphs.csv。來源不是 .docx，要先在有 Word 的電腦跑 S1 巨集，把產出放進這個資料夾。")
            return 1
        # 以前一定要到有 Word 的電腦跑 S1 巨集；docx 本身讀得到段落、表格、文字方塊、自動編號，直接匯出
        # （後面 S2、QA、S10 照樣把關）。算不出來的編號格式才退回巨集。
        sys.path.insert(0, os.path.join(HERE, "diffcut"))
        import importlib
        s1p = importlib.import_module("S1P_docx匯出")
        try:
            stats = s1p.export(args.source, folder)
        except s1p.ExportError as exc:
            say("[中止] S1P 匯出不了：%s。這一份請改用 S1 巨集（scripts/diffcut/S1_匯出全文.bas）在 Word 裡匯出。" % exc)
            return 1
        say("S1P：直接從 docx 匯出（不用 Word）：章 %d、節 %d、表格 %d、圖形 %d、總列數 %d"
            % (stats["章"], stats["節"], stats["表格"], stats["圖形"], stats["總列數"]))
    ratio = check_source_alignment(folder, args.source)
    if ratio is None:
        say("[中止] 01_paragraphs.csv 沒有「全文」欄，不是 S1 巨集匯出的格式。請用最新版 S1_匯出全文.bas 重新匯出。")
        return 1
    say("來源核對：01_paragraphs.csv 與 %s 對齊 %.1f%%" % (os.path.basename(args.source), ratio * 100))
    if ratio < args.min_align:
        say("[中止] 對齊低於 %.0f%%。S1 切的不是這個檔。切條一定要用定稿乾淨版，不能用草稿。" % (args.min_align * 100))
        return 1

    for name in STAGES_FIRST:
        if runner(name, [folder]):
            say("[停] %s 沒過。%s" % (name, "這是關卡，請看 logs 裡的完整報告。" if name in GATES else ""))
            return 1

    review = os.path.join(folder, "06_複核表.csv")
    if not args.decisions:
        if args.inherit:
            rc = runner("S6_沿用決定.py", [folder, args.inherit, review])
        else:
            rc = runner("S6_產生複核表.py", [folder, review])
        if rc:
            return 1
        say("")
        say("停：把 %s 交給使用者填「決定」欄。" % review)
        say("填完再跑：run_all.py cut %s --source <同一份原檔> --decisions <填好的表> --version <版號> --name <規章名> --release-root <發布根目錄>" % folder)
        return 0

    if runner("S6_套用決定.py", [folder, args.decisions]):
        say("[停] S6 沒過。每一筆需人工看的都要有明確決定，程式不代填。")
        return 1
    for name in ("S7_找重複.py", "S8_抓引用.py", "S9_連帶清單.py"):
        if runner(name, [folder]):
            return 1
    s10_source = args.source
    if not args.source.lower().endswith(".txt"):
        # 逐字對帳是切條線最強的一道保險。來源是 docx 時，用 read_paragraphs 把段落抽成一行一段的 txt
        # 交給 S10（它逐行照順序對齊），關卡才不會因為檔案格式而整個跳過。
        from _common import read_paragraphs
        s10_source = os.path.join(folder, "來源全文_由docx產生.txt")
        lines = []
        for para in read_paragraphs(args.source):
            lines.extend(x for x in para.split("\n") if x.strip())
        with io.open(s10_source, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        say("S10：來源是 .docx，已由 docx 抽出 %d 行文字做逐字對帳（%s）。" % (len(lines), os.path.basename(s10_source)))
        say("     目錄區若被點名找不到，用 --toc 起-迄 行號排除。")
    # --source-file：對帳證明要記「原檔」的雜湊（docx 時 s10_source 是抽出來的 txt），
    # S12 才比得出 --source 是不是對帳過的那一份。
    s10_args = [folder, s10_source, "--source-file", args.source]
    if args.toc:
        s10_args += ["--toc", args.toc]
    if runner("S10_還原對帳.py", s10_args):
        say("[停] S10 逐字對帳沒過。")
        return 1
    missing = [flag for flag, value in (("--version", args.version), ("--name", args.name)) if not value]
    if missing:
        say("[中止] 正式發布還缺參數：%s。09_規章總表.csv 只是中間產物，不是正式版。" % "、".join(missing))
        return 1
    release_root = args.release_root or os.path.join(folder, "releases")
    release_args = [folder, release_root, "--version", args.version, "--source", args.source,
                    "--name", args.name]
    if args.org:
        release_args += ["--org", args.org]
    if args.ver:
        release_args += ["--ver", args.ver]
    if runner("S12_發布版本.py", release_args):
        say("[停] S12 沒過，沒有正式版本。")
        return 1
    say("")
    say("正式發布完成。唯一入口：%s" % os.path.join(release_root, "LATEST.json"))
    say("下一輪改內規時，舊版 Word ＝ 這次的 --source，舊版規格包 ＝ 這個發布根目錄。")
    return 0


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------

def build_parser():
    parser = argparse.ArgumentParser(description="reg 總入口")
    parser.add_argument("--workspace", default="",
                        help="工作區根目錄；沒給就看設定.json。批次類、配對、開始 可放在子命令前或後；"
                             "單本指令請放在子命令前")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("check", help="第 0 步：核對舊版 Word 與規格包")
    p.add_argument("old_file")
    p.add_argument("release_root")
    p.set_defaults(func=cmd_check)

    runner = load_regdiff_runner()
    p = sub.add_parser("compare", help="第 1 步：初比對，產連帶決定表")
    runner.add_compare_arguments(p)
    p.add_argument("--semantic", default=None, help="已算好的語意候選.csv，直接併入")
    # 這四個門檻改成 None：跟「使用者沒給、用哪個預設」分開看，finalize 才能判斷
    # 要不要沿用初比對指紋（見 _fill_compare_defaults）；cmd_compare 自己沒有可沿用
    # 的來源，None 一律補回 regdiff 的硬預設，行為跟改之前一樣。
    p.set_defaults(func=cmd_compare, threshold=None, top=None, changed_top=None,
                   sentence_threshold=None)

    p = sub.add_parser("review-pack", help="第 1.5 步：把候選與異動打包給 AI 審查")
    p.add_argument("outdir")
    p.add_argument("--per-file", dest="per_file", type=int, default=40)
    _add_max_chars_flag(p)
    p.set_defaults(func=cmd_review_pack)

    p = sub.add_parser("review-import", help="第 1.5 步：驗證 AI 判斷、寫回決定表、產報告")
    p.add_argument("outdir")
    p.set_defaults(func=cmd_review_import)

    p = sub.add_parser("semantic", help="把手動算好的語意候選併進連帶決定表")
    p.add_argument("decisions")
    p.add_argument("semantic")
    p.set_defaults(func=cmd_semantic)

    p = sub.add_parser("apply", help="第 3 步：把決定表寫進草稿，開追蹤修訂")
    p.add_argument("draft")
    p.add_argument("decisions")
    p.add_argument("--outdir", default="")
    p.set_defaults(func=cmd_apply)

    p = sub.add_parser("finalize", help="第 4 步：終比對與三問")
    runner.add_compare_arguments(p)
    p.add_argument("--decisions", required=True, help="第 2 步填好的連帶決定表.csv")
    p.add_argument("--semantic", default=None, help="對乾淨版算好的語意候選.csv")
    # None：命令列沒給就沿用初比對指紋檔的「比對參數」，見 _finalize_core／
    # _fill_compare_defaults；使用者自己指定的旗標仍然優先。
    p.set_defaults(func=cmd_finalize, threshold=None, top=None, changed_top=None,
                   sentence_threshold=None)

    p = sub.add_parser("batch", aliases=["批次比對"], help="多本一起改：逐本初比對＋跨本連帶（工作區請用 開始）")
    p.add_argument("manifest", nargs="?", default=None,
                   help="規章清單.csv；省略時用工作區的 匯入/規章清單.csv")
    p.add_argument("--outdir", default="", help="省略時用工作區的 產出/")
    _add_batch_flags(p, runner)
    _add_verbose_flag(p)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch)

    p = sub.add_parser("batch-apply", aliases=["套用"], help="逐本套用連帶決定表（修訂都驗過就接著驗收）")
    p.add_argument("manifest", nargs="?", default=None,
                   help="規章清單.csv；省略時用工作區的 匯入/規章清單.csv")
    p.add_argument("--outdir", default="", help="省略時用工作區的 產出/")
    p.add_argument("--只套用", "--apply-only", dest="apply_only", action="store_true",
                   help="套用完不接著驗收")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_apply)

    p = sub.add_parser("batch-finalize", aliases=["驗收"], help="逐本終比對，彙整三問")
    p.add_argument("manifest", nargs="?", default=None,
                   help="規章清單.csv；省略時用工作區的 匯入/規章清單.csv")
    p.add_argument("--outdir", default="", help="省略時用工作區的 產出/")
    _add_verbose_flag(p)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_finalize)

    p = sub.add_parser("batch-review-pack", aliases=["審查打包"], help="批次第 1.5 步：逐本打包審查包給 AI 看")
    p.add_argument("outdir", nargs="?", default=None, help="省略時用工作區的 產出/")
    p.add_argument("--略過", "--skip", dest="skip", action="store_true",
                   help="這一輪不做 AI 審查（人工待辦不再提醒；之後想做直接再跑一次不加這個旗標）")
    p.add_argument("--per-file", dest="per_file", type=int, default=40)
    _add_max_chars_flag(p)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_review_pack)

    p = sub.add_parser("batch-review-import", aliases=["審查匯入"],
                       help="批次第 1.5 步：逐本驗證匯入、彙整 LLM 審查總表")
    p.add_argument("outdir", nargs="?", default=None, help="省略時用工作區的 產出/")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_review_import)

    p = sub.add_parser("核准",
                       help="照規則把決定表裡 AI 建議明確的列一次決定掉（人授權的批次核准）")
    p.add_argument("decisions", nargs="?", default=None,
                   help="決定表；省略時處理工作區批次產出的每一本")
    p.add_argument("--預覽", "--preview", dest="preview", action="store_true",
                   help="只列出會怎麼決定，不寫表")
    p.add_argument("--改", "--change", dest="change", default=None,
                   help="照建議改的規則（來源或評分標籤，逗號隔開），預設 章節引用,跨本引用,外部引用,引用換號,同義務舊值")
    p.add_argument("--不改", "--keep", dest="keep", default=None,
                   help="判不改的評分標籤（逗號隔開），預設 套語命中,無關")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_approve)

    p = sub.add_parser("batch-semantic", aliases=["語意併入"],
                       help="批次：把別台電腦算好的語意候選（產出/系統檔案/語意候選/<規章名>.csv）一次併回各本")
    p.add_argument("outdir", nargs="?", default=None, help="省略時用工作區的 產出/")
    p.add_argument("--dir", dest="semantic_dir", default=None,
                   help="算好的 <規章名>.csv 放在哪；省略時用 產出/系統檔案/語意候選/")
    p.add_argument("--略過", "--skip", dest="skip", action="store_true",
                   help="這一輪不做語意比對（人工待辦不再提醒）")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_semantic)

    p = sub.add_parser("配對", help="配對 匯入/現行規章、匯入/修訂規章 的檔名，寫 匯入/規章清單.csv")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_pair)

    p = sub.add_parser("發布", aliases=["publish"],
                       help="簽完之後：驗收改好的新版定稿換成現行規章、修訂版收走（先跑 --預覽）")
    p.add_argument("--預覽", "--preview", dest="preview", action="store_true", help="只列出會怎麼換，不動任何檔")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_publish)

    p = sub.add_parser("公文", aliases=["memo"], help="（選用）替驗收改好的每一本寫簽稿草稿")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_official)

    p = sub.add_parser("建基準", aliases=["baseline"],
                       help="發布之後重建規格包：批次切條（不用 Word），停在複核表；填完再跑一次就發布")
    p.add_argument("--規章", dest="books", default="", help="指定要建的本（逗號隔開）；第一次建基準用")
    p.add_argument("--全部", dest="all", action="store_true", help="清單裡每一本都建")
    p.add_argument("--照AI建議", dest="follow_ai", action="store_true",
                   help="決定空著、AI 建議「保留」的列照 AI 建議填（先加 --預覽）")
    p.add_argument("--預覽", "--preview", dest="preview", action="store_true")
    p.add_argument("--版號", dest="version", default="", help="發布的版號；不給就用今天日期")
    p.add_argument("--重來", dest="restart", action="store_true", help="不管現在的複核表，重跑第一趟")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_baseline)

    p = sub.add_parser("繼續", aliases=["continue"],
                       help="照人工待辦接著跑：程式能做的站一站接一站做，做到要人（或 AI）動手的那一站停")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_continue)

    p = sub.add_parser("開始", help="讀 規章清單.csv → 過期檢查 → 歸檔上一輪 → 批次初比對")
    p.add_argument("--照跑", dest="force_rerun", action="store_true",
                   help="上一輪已定稿、匯入/ 的檔還沒換也照跑（預設會先停下來講怎麼換）")
    _add_batch_flags(p, runner)
    _add_verbose_flag(p)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_start)

    p = sub.add_parser("cut", aliases=["切條"], help="第 5 步／情況一：切條產線 S2 → S12")
    p.add_argument("folder", help="工作區，裡面要有 S1 產出的 01_paragraphs.csv 等")
    p.add_argument("--source", required=True, help="S1 切的那份原檔（定稿乾淨版 .docx 或 .txt）")
    p.add_argument("--inherit", default=None, help="舊發布根目錄；給了就沿用上一版人工決定")
    p.add_argument("--decisions", default=None, help="填好的複核表；給了就跑第二趟到正式發布")
    p.add_argument("--version", default=None)
    p.add_argument("--name", default=None)
    p.add_argument("--release-root", dest="release_root", default=None)
    p.add_argument("--org", default="")
    p.add_argument("--ver", default="")
    p.add_argument("--min-align", dest="min_align", type=float, default=0.95)
    p.add_argument("--toc", default=None, help="S10 逐字對帳要排除的目錄區行號，例如 3-40")
    p.set_defaults(func=cmd_cut)
    return parser


DEBUG_ENV = "REG_DEBUG"


def debug_mode():
    """REG_DEBUG=1 時 main() 不收例外，直接讓 traceback 噴出來。

    「[中止] 一行字」對使用者是對的，對要修 bug 的人是災難——堆疊、哪一行、
    哪個檔全部被吃掉。留一個環境變數當逃生門，請使用者回報問題時重跑一次。
    """
    return (os.environ.get(DEBUG_ENV, "") or "").strip() not in ("", "0", "false", "False")


def _command_label(args):
    """從 args.func 反推子命令名（cmd_apply → apply），純粹是為了提醒文字好讀。"""
    name = getattr(getattr(args, "func", None), "__name__", "") or ""
    if name.startswith("cmd_"):
        name = name[4:]
    return name.replace("_", "-") or "執行"


def _abort_notice(args, text):
    """中止時把「為什麼中止」留下來：畫面那一行留不住（no 11）。

    只在產出資料夾*已經存在*的時候才接寫 提醒.txt——前置驗證擋下來的中止本來
    就沒建任何東西，為了寫一則提醒反而生出一個空資料夾，等於把剛擋掉的殘骸
    自己補回去。資料夾還不存在時就只有畫面那一行，跟以前一樣。
    """
    label = _command_label(args)
    try:
        import notices as nt
        nt.notice(nt.WARNING, "%s 中止：%s" % (label, text), label)
        outdir = getattr(args, "outdir", "") or ""
        if outdir and os.path.isdir(outdir):
            say("提醒留底：%s" % nt.write_notices(outdir, append=True,
                                                title="%s（中止）" % label))
    except Exception:
        # 留底失敗不能蓋掉「[中止]」那一行——那是使用者唯一看得到的線索。
        pass


# 跑完要更新 結果彙整/檢視報告.xlsx 的子命令：單本的直接看 outdir，批次的看產出根目錄底下每一本。
# finalize／batch-finalize 不在這裡：它們的結論要是畫面最後一行，自己在印結論之前更新。
_SINGLE_REPORT_COMMANDS = ("compare", "apply", "review-import", "semantic")
_BATCH_REPORT_COMMANDS = ("batch", "batch-apply", "batch-review-import", "start", "batch-semantic", "approve")


def _refresh_one_report(outdir, decisions=None, announce=False):
    """重建一本的 結果彙整/檢視報告.xlsx。檢視報告是附帶產物：出錯只印一行，
    不能讓這一步真正的產出（對照表、定稿、驗收報告）跟著失敗。"""
    import review_report as rr
    try:
        if outdir and os.path.isdir(outdir):
            path = rr.refresh(outdir, decisions)
            if path and announce:
                say("檢視報告：%s" % path)
            return path
    except Exception as exc:
        say("提醒：檢視報告沒有更新（%s：%s）" % (type(exc).__name__, exc))
    return None


def _refresh_batch_report(root):
    """重建 <產出根>/結果彙整/檢視報告.xlsx（多本合一）。出錯只印一行，理由同 _refresh_one_report。"""
    import review_report as rr
    try:
        if root and os.path.isdir(root):
            return rr.refresh_batch(root)
    except Exception as exc:
        say("提醒：檢視報告沒有更新（%s：%s）" % (type(exc).__name__, exc))
    return None


def _refresh_review_reports(args):
    """每一步跑完就重建一次檢視報告：它是彙整各步驟報告的那一份，永遠要是當下最新的。
    不管這一步成功或中止都重建（中止也可能留下新的提醒）。"""
    if getattr(args, "report_done", False):
        return                           # 這一步自己已經更新過（batch-apply 接著驗收）
    label = _command_label(args)
    if label in _SINGLE_REPORT_COMMANDS:
        outdir = getattr(args, "outdir", "") or ""
        decisions = getattr(args, "decisions", None)
        if label == "semantic" or not outdir:
            outdir = outdir_of_table(decisions) if decisions else ""
        _refresh_one_report(outdir, decisions, announce=True)
    elif label in _BATCH_REPORT_COMMANDS:
        path = _refresh_batch_report(getattr(args, "outdir", "") or "")
        if path:
            say("檢視報告：%s（各本合一，第一欄是規章名）" % show_path(path))


# 批次子命令：人要填的表與要看的定稿集中在 產出/填寫表單/（見 fill_sync）。
# 開始前把合一表上人改過的寫回各本，結束後再合成一張、定稿複製上來。
_FILL_SYNC_COMMANDS = ("batch", "start", "batch-apply", "batch-finalize",
                       "batch-review-pack", "batch-review-import", "batch-semantic", "approve", "continue",
                       "publish")


def _batch_root_for(args, settings):
    """這個批次子命令要動的產出根目錄（還沒補工作區預設值時也算得出來）；算不出來回空字串。"""
    decisions = getattr(args, "decisions", None)
    if decisions and _command_label(args) == "approve":
        # 指定了某一張決定表：只同步它所在的那個批次（單本 compare 的表就不同步），
        # 不能去動預設工作區
        from _common import batch_root_of
        return batch_root_of(outdir_of_table(os.path.abspath(decisions))) or ""
    outdir = getattr(args, "outdir", "") or ""
    if outdir:
        return os.path.abspath(outdir)
    try:
        import workspace as ws
        return ws.paths(ws.resolve_root(getattr(args, "workspace", ""), settings))["產出"]
    except Exception:
        return ""


def _fill_sync(args, settings, stage):
    """stage＝"pull"／"push"。合一表寫錯（要改嗎填了認不得的字）時 pull 丟
    DecisionTableError，由呼叫端印「[中止]」；push 出錯只印一行，不擋這一步的結果。"""
    import fill_sync as fs
    if _command_label(args) not in _FILL_SYNC_COMMANDS:
        return
    root = _batch_root_for(args, settings)
    if stage == "pull":
        for name, book in fs.pull(root, say=say):
            say("已套用 產出/填寫表單/%s 上「%s」的修改" % (name, book))
        return
    try:
        fs.push(root, say=say)
    except Exception as exc:
        say("提醒：填寫表單/ 的合一表沒有更新（%s：%s）" % (type(exc).__name__, exc))
    # 各本的送簽文件排到 產出/結果彙整/（先分種類、同種類各規章放一起），見 result_publish
    import result_publish as rpub
    try:
        rpub.publish(root, say=say)
    except Exception as exc:
        say("提醒：結果彙整/ 沒有更新（%s：%s）" % (type(exc).__name__, exc))


def _refresh_todo(args, settings, rc=0):
    """批次指令跑完，重寫 產出/審閱文件/人工待辦.txt，畫面最後印「現在要做」（見 todo.py）。
    待辦清單是附帶產物：出錯只印一行，不擋這一步。
    「開始」中止（清單過期、上一輪的檔沒換……）時不印：那時候清單講的還是上一輪的事
    （以前開始中止了，最後一行還叫人去跑套用）。"""
    label = _command_label(args)
    if label not in _FILL_SYNC_COMMANDS:
        return
    if rc and (label in ("start", "batch") or getattr(args, "start_failed", False)):
        say("")
        say("人工待辦：這一步沒有跑完（原因見上面），處理好再跑一次 %s"
            % {"start": "開始", "batch": "batch"}.get(label, "繼續"))
        return
    root = _batch_root_for(args, settings)
    import fill_sync as fs
    if not fs.is_batch_root(root):
        return
    import todo
    try:
        for line in todo.refresh(root, workspace_flag(args), _cmd):
            say(line)
    except Exception as exc:
        say("提醒：人工待辦清單沒有更新（%s：%s）" % (type(exc).__name__, exc))


def _order_problem(args, command):
    """批次指令跑錯站（見 todo.order_problem）：印一句話；該擋的回 True，呼叫端 return 1。"""
    if getattr(args, "in_continue", False) or getattr(args, "report_done", False):
        return False                       # 繼續／套用後接著驗收：本來就照順序
    import fill_sync as fs
    import todo
    root = getattr(args, "outdir", "") or ""
    if not root or not fs.is_batch_root(root):
        return False
    try:
        found = todo.order_problem(root, command)
    except Exception:
        return False                       # 判斷不了（產出壞了）：交給指令自己講清楚錯在哪
    if not found:
        return False
    stop, sentence = found
    say(("[順序] %s" if stop else "[提醒] %s") % sentence)
    return stop


def _run_command(args, settings, show_todo=True):
    """跑一個子命令：開始前把合一表上人改的寫回各本、跑、結束後合回去，更新檢視報告與人工待辦。
    main 與「繼續」（一次接著跑好幾個子命令，只在最後印一次人工待辦）共用。"""
    import decision_table as dt
    try:
        _fill_sync(args, settings, "pull")
    except dt.DecisionTableError as exc:
        say("[中止] 產出/填寫表單/連帶決定表.csv 有問題：%s" % exc)
        return 1
    rc = args.func(args, settings)
    _fill_sync(args, settings, "push")
    _refresh_review_reports(args)
    if show_todo:
        _refresh_todo(args, settings, rc)
    return rc


def main(argv=None):
    setup_stdout()
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 1
    from _common import InputError
    try:
        settings = load_settings()
        return _run_command(args, settings)
    except KeyboardInterrupt:
        # Ctrl+C 不是程式壞了，照原樣往上丟，不要偽裝成「[中止]」。
        raise
    except (OSError, UnicodeDecodeError, InputError) as exc:
        # no 11：以前這裡只有 return args.func(...)。檔案開在 Word 裡（Windows 鎖檔）、
        # outdir 指到檔案、UNC 掉線、唯讀磁碟、編碼猜錯——使用者看到的一律是
        # 一坨 Python traceback，跟專案其他地方的「[中止] …」完全不同調，
        # 根本分不出是自己弄錯還是程式有 bug。
        if debug_mode():
            # I2：要修 bug 的人自己開的逃生門，原樣噴 traceback。
            raise
        # I2：例外類別名一定要印出來。「[中止] [Errno 13] 拒絕存取」看不出是權限
        # 問題還是檔案被鎖，寫成「PermissionError：…」回報的人不用附 traceback
        # 就講得清楚是哪一類。
        say("[中止] %s：%s（要看完整錯誤請設 %s=1 重跑）"
            % (type(exc).__name__, exc, DEBUG_ENV))
        _abort_notice(args, "%s：%s" % (type(exc).__name__, exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
