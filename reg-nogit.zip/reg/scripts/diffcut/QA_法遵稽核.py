# -*- coding: utf-8 -*-
r"""
QA：法遵角度的稽核

用法：
    py QA_法遵稽核.py <資料夾>

跟 S2 到 S5 的自我檢查不一樣。
那些查的是「程式有沒有跑對」。
這一支查的是「這份東西能不能拿去做內規修正」。

七項：
  1 完整性    全文是不是都收進來了，有沒有整類被丟掉
  2 可追溯    每一條回得去原檔的哪個位置
  3 定位唯一  用文字回原檔尋找取代，會不會改到別的地方
  4 切點      有沒有條文開頭不是編號，代表切在半路
  5 前言歸屬  章前言有沒有跟第一條黏在一起
  6 附件歸屬  表格與流程圖有沒有掛在正確的條文底下
  7 編號穩定  條文ID 換版之後還對得上嗎
  8 切點品質  該切沒切、子項編號、00 子項標示、腰斬偵測
"""

import csv
import io
import os
import re
import sys
import collections

HEAD = re.compile(
    r"^(?:\s*\[\[(?:TABLE|SHAPE):\d{3}\]\])*\s*"
    r"(第[一二三四五六七八九十]{1,3}[章節]"
    r"|[一二三四五六七八九十]{1,3}[、]"
    r"|[（(][一二三四五六七八九十\d]{1,3}[）)]"
    r"|\d{1,3}[、.．]"
    r"|[A-Za-z][.．])")

lines = []
issues = []


def say(s=""):
    lines.append(s)


def issue(level, title, detail):
    issues.append((level, title))
    say("   [%s] %s" % (level, title))
    for d in detail:
        say("        " + d)


def load(folder, name):
    p = os.path.join(folder, name)
    if not os.path.isfile(p):
        return None
    with open(p, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _newest_items(folder):
    """條文檔挑最新的那一份（B22）：QA 跑在 S4 之後、S5 之前，同一個資料夾重跑時
    上一輪的 05_flagged.csv 還在——以前一律先讀 05，這一輪的 04 被腰斬也照樣過。"""
    found = [(os.path.getmtime(os.path.join(folder, n)), -k, n)
             for k, n in enumerate(("05_flagged.csv", "04_items2.csv", "03_items.csv"))
             if os.path.isfile(os.path.join(folder, n))]
    if not found:
        return None, ""
    name = max(found)[2]
    return load(folder, name), name


def main(folder):
    P = load(folder, "01_paragraphs.csv")
    I, items_name = _newest_items(folder)
    if not P or not I:
        say("找不到 01_paragraphs.csv 或條文檔，先跑完 S1 到 S5。")
        return False

    doc = "".join(r["全文"] for r in P)
    tot = len(doc)
    item_txt = "".join(r["全文"] for r in I)

    say("=" * 62)
    say("法遵稽核報告")
    say("資料夾：" + folder)
    say("條文檔：%s，%d 筆" % (items_name, len(I)))
    say("=" * 62)

    # ---------- 1 完整性 ----------
    say()
    say("1. 完整性")
    by = collections.Counter()
    for r in P:
        by[r["類型"]] += len(r["全文"])
    for k, v in by.most_common():
        say("   %-6s %6d 字  %5.1f%%" % (k, v, 100.0 * v / tot))
    say("   條文檔收了 %d 字，占全文 %.1f%%" % (len(item_txt),
                                        100.0 * len(item_txt) / tot))
    att = sum(int(r.get("附件字數") or 0) for r in I)
    say("   附件欄另外收了 %d 字（表格與流程圖內容）" % att)
    if by["表格內"] and att == 0:
        issue("重大", "表格內容沒有進條文檔",
              ["表格內文字 %d 字，占全文 %.1f%%" % (by["表格內"],
                                          100.0 * by["表格內"] / tot),
               "條文檔裡只有 [[TABLE:nnn]] 記號，沒有表格的字",
               "拿這份當「全部條文」做修正對照表，會漏掉這些內容"])
    elif by["表格內"]:
        covered = set()
        for r in I:
            if r.get("含表格標記"):
                covered.update(r["含表格標記"].split(";"))
        say("   條文檔涵蓋 %d 張表" % len(covered))
    if by["目錄"]:
        say("   目錄 %d 字被排除，這是對的（導讀表重複列章名）" % by["目錄"])
    # 條文依序串起來要等於原檔本文（章、節、內文、表格圖形記號），一字不差（B22）：
    # 少了一截、多了一截、順序錯了，後面每一站都是錯的
    body = "".join(r["全文"] for r in P if r["類型"] in ("章", "節", "內文", "表格標記", "圖形標記"))
    if item_txt != body:
        at = next((k for k in range(min(len(body), len(item_txt))) if body[k] != item_txt[k]),
                  min(len(body), len(item_txt)))
        issue("重大", "條文串起來跟原檔本文不一樣",
              ["原檔本文 %d 字、條文檔 %d 字，第 %d 個字開始不同" % (len(body), len(item_txt), at + 1),
               "原：" + body[max(0, at - 20):at + 20],
               "條：" + item_txt[max(0, at - 20):at + 20]])
    else:
        say("   條文依序串起來跟原檔本文一字不差")

    # ---------- 2 可追溯 ----------
    say()
    say("2. 可追溯（每一條回得去原檔哪裡）")
    has_pos = "起始序號" in I[0] and "結束序號" in I[0]
    if not has_pos:
        issue("重大", "條文檔沒有原檔位置",
              ["01_paragraphs.csv 有「序號」「位置」，但 S3 之後沒帶下來",
               "後面要用 VBA 回原檔改字，只能靠文字比對定位",
               "建議 S3 加兩欄：起始序號、結束序號"])
    else:
        JOIN = ("章", "節", "內文", "表格標記", "圖形標記")
        para = dict((int(r["序號"]), r["全文"]) for r in P
                    if r["類型"] in JOIN)
        blank = [r["條文ID"] for r in I if not str(r["起始序號"]).strip()]
        wrong = []
        for r in I:
            a, b = str(r["起始序號"]), str(r["結束序號"])
            if not a.isdigit() or not b.isdigit():
                continue
            span = "".join(para.get(n, "") for n in range(int(a), int(b) + 1))
            if r["全文"] not in span:
                wrong.append(r["條文ID"])
        say("   有「起始序號」「結束序號」兩欄")
        say("   有值的 %d 筆，空的 %d 筆" % (len(I) - len(blank), len(blank)))
        say("   逐筆回原檔核對：對不上的 %d 筆" % len(wrong))
        if wrong:
            issue("重大", "起訖序號指到錯的地方",
                  ["例如 " + "、".join(wrong[:5]),
                   "位置欄不可信，等於沒有定位"])
        elif blank:
            nonzero = [i for i in blank
                       if next(r for r in I if r["條文ID"] == i)["全文"]]
            if nonzero:
                issue("中", "有條文沒有位置",
                      ["%d 筆有內容卻沒有起訖序號" % len(nonzero)])
            else:
                say("   空的那 %d 筆都是 0 字的空筆，正常" % len(blank))

    # ---------- 3 定位唯一 ----------
    say()
    say("3. 定位唯一（尋找取代會不會改錯地方）")
    full_dup = [r["條文ID"] for r in I
                if len(r["全文"].strip()) >= 15
                and doc.count(r["全文"].strip()) > 1]
    say("   用整條全文定位，重複的：%d 筆" % len(full_dup))
    for i in full_dup[:10]:
        say("      " + i)
    head_dup = [(r["條文ID"], doc.count(r["全文"].strip()[:30]))
                for r in I if len(r["全文"].strip()) >= 30
                and doc.count(r["全文"].strip()[:30]) > 1]
    say("   只用前 30 字定位，重複的：%d 筆" % len(head_dup))
    if full_dup and not has_pos:
        issue("重大", "有條文的全文在文件裡出現不只一次",
              ["尋找取代會改到別的地方", "而且沒有位置欄可以消歧"])
    elif full_dup:
        issue("中", "有條文的全文在文件裡出現不只一次",
              ["共 %d 筆，例如 %s" % (len(full_dup), "、".join(full_dup[:4])),
               "純靠文字尋找取代會改錯地方",
               "已有起訖序號可以消歧，VBA 改檔時必須先跳到那個序號再取代",
               "不可以用 Selection.Find 從頭掃"])
    elif head_dup:
        issue("中", "短前綴定位不可靠",
              ["有 %d 筆的前 30 字在文件裡重複" % len(head_dup),
               "VBA 尋找取代要用整條全文，不可以只取開頭"])

    # ---------- 4 切點 ----------
    say()
    say("4. 切點（開頭不是編號也不是標題的條文）")
    bad = [r for r in I if r["全文"].strip() and not HEAD.match(r["全文"])]
    say("   共 %d 筆" % len(bad))
    for r in bad[:15]:
        say("      %-18s %s" % (r["條文ID"], r["全文"][:36]))
    weird = [r for r in bad if r["全文"][0] in "、，。；：）)」』】"]
    if weird:
        issue("重大", "有條文開頭是標點，切在句子中間",
              ["%s 等 %d 筆" % (weird[0]["條文ID"], len(weird))])
    elif bad:
        say("   這些多半是章前言或篇名，不是切錯。往下看第 5 項")

    # ---------- 5 前言歸屬 ----------
    say()
    say("5. 前言歸屬")
    merged = []
    for r in I:
        t = r["全文"]
        if not r["條文ID"].endswith("-000") and not HEAD.match(t):
            m = re.search(r"[一二三四五六七八九十]{1,3}、|[（(][一二三四五六七八九十]{1,3}[）)]", t)
            if m and m.start() >= 10:
                merged.append((r["條文ID"], m.start(), len(t)))
    say("   前言跟第一條黏在同一筆的：%d 筆" % len(merged))
    for i, a, b in merged[:12]:
        say("      %-18s 前言 %d 字 ＋ 條文 %d 字" % (i, a, b - a))
    if merged:
        issue("重大", "章前言沒有獨立成一筆",
              ["前言本身就是規範文字，例如「本章規範…」",
               "現在跟第一條合併，修正對照表會把兩者當一條",
               "S4 已經有「前言獨立成 00」的規則，S3 卻沒有，兩階段不一致",
               "也因為這樣，完全相同的兩段前言比對不出來"])

    # ---------- 6 附件歸屬 ----------
    say()
    say("6. 附件歸屬（表格與流程圖掛在哪一條）")
    multi = [(r["條文ID"], r["含表格標記"]) for r in I
             if r["含表格標記"] and len(r["含表格標記"].split(";")) >= 2]
    for i, t in multi:
        say("      %-18s 一次掛了 %d 張：%s" % (i, len(t.split(";")), t))
    if multi:
        issue("中", "多張表格擠在同一條",
              ["表格排在章標題之後、第一個編號之前，就全部掛到第一條",
               "實際上這些表分屬不同條文，改表時會找錯條",
               "建議：表格記號自己獨立成一筆，或用位置重新配對"])

    # ---------- 7 編號穩定 ----------
    say()
    say("7. 編號穩定")
    say("   條文ID 目前是「章-節-流水號」，流水號照位置排。")
    issue("中", "條文ID 換版之後會整批位移",
          ["中間插一條新的，後面所有 ID 全部往後移一號",
           "跨版本比對會對到錯的條文",
           "建議：對照表同時記錄「條文ID」與「條文開頭 20 字」兩個定位點"])

    # ---------- 8 切點品質 ----------
    say()
    say("8. 切點品質")
    SYM = {"A": re.compile(r"([一二三四五六七八九十]{1,3})、"),
           "B": re.compile(r"[（(]([一二三四五六七八九十]{1,3})[）)]"),
           "C": re.compile(r"(\d{1,3})(?:、|[.．](?![0-9０-９]))"),
           "D": re.compile(r"[（(](\d{1,3})[）)]"),
           "E": re.compile(r"([A-Za-z])[.．]")}

    def val(s):
        s = s.strip()
        if s.isdigit():
            return int(s)
        if re.match(r"^[A-Za-z]$", s):
            return ord(s.upper()) - 64
        if "十" in s:
            l, _, r2 = s.partition("十")
            base = "一二三四五六七八九十"
            return ((base.index(l) + 1) if l else 1) * 10 +                    ((base.index(r2) + 1) if r2 else 0)
        base = "一二三四五六七八九十"
        return base.index(s) + 1 if s in base else None

    # 甲：該切沒切
    miss_cut = []
    for r in I:
        k = r["符號類型"]
        if k not in SYM or not r["符號原文"]:
            continue
        m = re.search(r"([一二三四五六七八九十]{1,3}|\d{1,3}|[A-Za-z])", r["符號原文"])
        v0 = val(m.group(1)) if m else None
        if v0 is None:
            continue
        body = r["全文"][len(r["符號原文"]):]
        for mm in SYM[k].finditer(body):
            if val(mm.group(1)) == v0 + 1:
                miss_cut.append(r["條文ID"])
                break
    say("   該切沒切（條文內部又出現同級下一號）：%d 筆" % len(miss_cut))
    if miss_cut:
        issue("重大", "有條文該切沒切",
              ["例如 " + "、".join(miss_cut[:5]),
               "一筆裡面包了兩條以上，對照表會把兩條當一條改"])

    # 己：被切母條文的子項編號連不連續
    split_ids = set(r["父ID"] for r in I if r.get("父ID"))
    par = collections.defaultdict(list)
    seen = set()
    for r in I:
        if r.get("父ID"):
            par[r["父ID"]].append(int(r["條文ID"].rsplit("-", 1)[1]))
            seen.add(r["條文ID"])
    # 被再切一輪的子項，本人已經不在表上，用父ID補回來
    for sid in split_ids:
        if sid in seen or "-" not in sid:
            continue
        head, _, tail = sid.rpartition("-")
        if head in par and tail.isdigit() and len(tail) == 2:
            par[head].append(int(tail))
    broke = [p for p, v in par.items()
             if sorted(v) != list(range(min(v), min(v) + len(v)))]
    say("   母條文 %d 組，子項編號不連續的 %d 組" % (len(par), len(broke)))
    if broke:
        issue("重大", "子項編號不連續", ["例如 " + "、".join(broke[:5])])

    # 庚：00 子項有沒有標出母條文的編號
    z = [r for r in I if r["條文ID"].endswith("-00")]
    lost = [r["條文ID"] for r in z
            if not r["符號原文"]
            and re.match(r"^\s*[（(]?[一二三四五六七八九十\d]{1,3}[）)、.]", r["全文"])]
    say("   00 子項 %d 筆，帶著母條文編號卻沒標出來的 %d 筆" % (len(z), len(lost)))
    if lost:
        issue("重大", "00 子項沒有標出母條文編號",
              ["例如 " + "、".join(lost[:5]),
               "對照表上看不出這是第幾條，覆核時無法定位"])

    # 辛：腰斬偵測
    end_ok = "。；：」』】）)"
    tail = [r for r in I
            if r["全文"].strip()
            and r["全文"].strip()[-1] not in end_ok
            and r["符號類型"] not in ("表格", "圖形")]
    say("   結尾不是句末標點：%d 筆（%.0f%%）" % (len(tail), 100.0 * len(tail) / len(I)))

    # 真正的腰斬：結尾落在原檔某一行的「中間」，代表切在句子裡
    para2 = dict((int(r["序號"]), r["全文"]) for r in P
                 if r["類型"] in ("章", "節", "內文", "表格標記", "圖形標記"))
    cut_mid = []
    for r in tail:
        b = str(r["結束序號"])
        if not b.isdigit():
            continue
        last = para2.get(int(b), "")
        if last and not r["全文"].endswith(last):
            cut_mid.append(r["條文ID"])
    say("   其中結尾切在原檔行中間的：%d 筆" % len(cut_mid))
    say("      沒切在行中間，就代表原文那一行本來就沒有句號，不是切壞。")
    if cut_mid:
        issue("重大", "有條文被切在句子中間",
              ["例如 " + "、".join(cut_mid[:5]),
               "多半是句子裡的代號被當成編號，例如「IR1、IR2、IR3」",
               "要回頭看 S4 的排除規則"])

    # ---------- 結論 ----------
    say()
    say("=" * 62)
    big = [t for lv, t in issues if lv == "重大"]
    mid = [t for lv, t in issues if lv == "中"]
    if big:
        say("結論：不可以直接拿去做內規修正。重大 %d 項、中度 %d 項。"
            % (len(big), len(mid)))
    elif mid:
        say("結論：可用，但有 %d 項要先補。" % len(mid))
    else:
        say("結論：七項全過。")
    for lv, t in issues:
        say("   [%s] %s" % (lv, t))
    say("=" * 62)
    return not big


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py QA_法遵稽核.py <資料夾>")
        sys.exit(1)

    folder = sys.argv[1]
    ok = main(folder)

    report = "\n".join(lines)
    with open(os.path.join(folder, "QA_法遵稽核報告.txt"), "w",
              encoding="utf-8-sig") as f:
        f.write(report + "\n")

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if ok else 1)
