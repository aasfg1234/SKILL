# -*- coding: utf-8 -*-
r"""
S6：套用人工決定，產出最終條文檔

用法：
    py S6_套用決定.py <資料夾> <你填好的CSV>

例：
    py S6_套用決定.py data "..\未命名的試算表 - 切條結果_模擬資料_20260828 - 複製.csv"

輸入：<資料夾>\05_flagged.csv        （原始，當作對照的底本）
      你填好的 CSV                    （在「建議動作」欄寫決定）
輸出：<資料夾>\06_final.csv          （留下來的條文）
      <資料夾>\06_deleted.csv        （刪掉的，留底備查，不可以直接丟掉）
      <資料夾>\S6_套用報告.txt

認得的決定（寫在「建議動作」欄）：
    保留 / 留              原樣留著
    刪除 / 刪 / 刪掉這一筆   移到 06_deleted.csv
    併入上一筆 / 併         文字併進前一筆留著的條文
    待改 / 改               留著，但標記起來下一輪處理

出現在複核表的條文必須全部列在決定檔並明確填決定；漏列、留空白或寫別的字
都會停下來，不會亂猜。決定檔也必須保留原複核表的「全文」與「旗標」欄供對帳。
未被挑進複核表的條文才會預設保留。

法遵重點：刪掉的不會消失，會存進 06_deleted.csv。
          程式會對帳：留下的字 ＋ 刪掉的字 ＝ 原本的字。不平就不寫檔。
          通過後另存 S6_複核證明.json，供正式發布閘門核對。
"""

import csv
import datetime
import hashlib
import json
import os
import sys
import collections

# 認得的決定。第一行寫關鍵字，後面可以接說明，說明會存進「決定備註」
KEEP = ("保留", "留",
        "沒漏", "沒問題", "無誤", "正常", "無異常", "ok", "OK", "Ok")
DROP = ("刪除", "刪", "刪掉這一筆", "刪掉")
MERGE = ("併入上一筆", "併", "併入前一筆")
TODO = ("待改", "改", "待處理")

DEC_COLS = ("決定", "建議動作")   # 優先看「決定」欄，沒有才看「建議動作」
NEW_COLS = ["人工決定", "決定備註"]

lines = []
invalidate_outputs = False


def say(s=""):
    lines.append(s)


def read(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def quarantine_outputs(folder):
    """驗證失敗時移開舊的 canonical 輸出，避免下游誤吃上一輪結果。"""
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    moved = []
    for name in ("06_final.csv", "06_deleted.csv", "S6_複核證明.json"):
        src = os.path.join(folder, name)
        if not os.path.isfile(src):
            continue
        stem, ext = os.path.splitext(name)
        dst = os.path.join(folder, "%s_上次成功_%s%s" % (stem, stamp, ext))
        os.replace(src, dst)
        moved.append(os.path.basename(dst))
    if moved:
        say()
        say("舊輸出已移開，避免誤用：" + "、".join(moved))


def main(folder, dec_path):
    global invalidate_outputs
    base_path = os.path.join(folder, "05_flagged.csv")
    if not os.path.isfile(base_path):
        say("找不到 " + base_path)
        return False
    if not os.path.isfile(dec_path):
        say("找不到 " + dec_path)
        return False

    # 兩份輸入都存在，代表這次已開始一次真正的套用嘗試。
    invalidate_outputs = True

    base = read(base_path)
    with open(dec_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        dec_fields = reader.fieldnames or []
        dec = list(reader)

    say("=" * 62)
    say("S6 套用決定報告")
    say("底本：" + base_path)
    say("決定：" + dec_path)
    say("=" * 62)

    # ---------- 1 兩份檔要對得上 ----------
    say()
    say("1. 檔案核對")
    if not base:
        say("   [中止] 05_flagged.csv 沒有任何資料")
        return False
    required_ids = [r["條文ID"] for r in base if r.get("需人工看") == "Y"]
    if not dec and required_ids:
        say("   [中止] 複核表沒有任何資料")
        return False
    if "條文ID" not in dec_fields:
        say("   [中止] 你的檔案沒有「條文ID」欄")
        return False
    for required_col in ("全文", "旗標"):
        if required_col not in dec_fields:
            say("   [中止] 你的檔案沒有「%s」欄。" % required_col)
            say("   必須使用本輪 S6 產生的完整複核表，不能只交條文ID與決定。")
            return False

    col = next((c for c in DEC_COLS if c in dec_fields), None)
    if not col:
        say("   [中止] 你的檔案沒有「決定」欄，也沒有「建議動作」欄")
        return False
    say("   決定寫在「%s」欄" % col)
    say("   底本 %d 筆，你的檔 %d 筆" % (len(base), len(dec)))

    dmap = {}
    duplicate_ids = []
    for r in dec:
        item_id = (r.get("條文ID") or "").strip()
        if not item_id:
            say("   [中止] 複核表有空白的「條文ID」")
            return False
        if item_id in dmap:
            duplicate_ids.append(item_id)
        dmap[item_id] = r
    if duplicate_ids:
        say("   [中止] 複核表有重複條文ID：%s"
            % "、".join(sorted(set(duplicate_ids))[:10]))
        return False

    base_ids = set(x["條文ID"] for x in base)
    extra = [r["條文ID"] for r in dec if r["條文ID"] not in
             base_ids]
    if extra:
        say("   [中止] 你的檔有 %d 筆不在底本裡：%s"
            % (len(extra), "、".join(extra[:5])))
        return False
    missing_required = [item_id for item_id in required_ids if item_id not in dmap]
    if missing_required:
        say("   [中止] 需人工複核 %d 筆，但你的檔漏了 %d 筆："
            % (len(required_ids), len(missing_required)))
        say("      " + "、".join(missing_required[:10]))
        say("   必須使用本輪 S6 產生的完整複核表，每一筆都明確填決定。")
        return False

    base_by_id = dict((r["條文ID"], r) for r in base)
    stale_rows = []
    for item_id in required_ids:
        expected = base_by_id[item_id]
        actual = dmap[item_id]
        if actual.get("全文", "") != expected.get("全文", ""):
            stale_rows.append((item_id, "全文"))
        elif actual.get("旗標", "") != expected.get("旗標", ""):
            stale_rows.append((item_id, "旗標"))
    if stale_rows:
        say("   [中止] 複核表有 %d 筆不是本輪產生的內容：%s"
            % (len(stale_rows), "、".join("%s(%s)" % x for x in stale_rows[:10])))
        say("   請重新執行 S6_產生複核表.py，再逐筆填寫新的複核表。")
        return False

    optional_missing = [r["條文ID"] for r in base
                        if r["條文ID"] not in dmap and r.get("需人工看") != "Y"]
    say("   需人工複核 %d 筆，決定檔完整涵蓋 %d 筆"
        % (len(required_ids), len(required_ids)))
    if optional_missing:
        say("   其餘未列出的 %d 筆不需人工看，依規則保留"
            % len(optional_missing))

    changed = [r["條文ID"] for r in base
               if r["條文ID"] in dmap
               and dmap[r["條文ID"]].get("全文", "") != r["全文"]]
    if changed:
        say("   [中止] 有 %d 筆的「全文」被動過：%s"
            % (len(changed), "、".join(changed[:5])))
        say("   S6 只收決定，不收改字。改字要在 S8 用追蹤修訂做。")
        return False
    say("   全文一個字都沒被動過")

    # Excel 會把 004 存成 4，這裡用底本補回來
    fixed = 0
    for r in base:
        d = dmap.get(r["條文ID"])
        if not d:
            continue
        for c in ("章序號", "節序號", "起始序號", "結束序號"):
            if c in d and d[c] != r[c]:
                fixed += 1
    if fixed:
        say("   注意：有 %d 個欄位值被 Excel 改過格式（例如 004 變成 4）" % fixed)
        say("   已用底本的值為準，你的檔不受影響")

    # ---------- 2 讀決定 ----------
    say()
    say("2. 決定統計")
    tally = collections.Counter()
    unknown = []
    blanks = []
    verdict = {}
    notes = {}
    for r in base:
        d = dmap.get(r["條文ID"])
        cell = ((d.get(col) if d else "") or "").strip()
        # 第一行當決定，後面全部當說明留存
        head, _, rest = cell.partition(chr(10))
        raw = head.strip()
        if rest.strip():
            notes[r["條文ID"]] = rest.strip()
        if not d:
            v = "保留"
        elif not raw:
            blanks.append(r["條文ID"])
            v = None
        elif raw in KEEP:
            v = "保留"
        elif raw in DROP:
            v = "刪除"
        elif raw in MERGE:
            v = "併入上一筆"
        elif raw in TODO:
            v = "待改"
        else:
            unknown.append((r["條文ID"], raw))
            v = None
        verdict[r["條文ID"]] = v
        if v:
            tally[v] += 1

    for k, n in tally.most_common():
        say("   %-8s %d 筆" % (k, n))

    if unknown:
        say()
        say("   [中止] 有 %d 筆寫了認不得的決定：" % len(unknown))
        for i, t in unknown[:10]:
            say("      %s -> 「%s」" % (i, t))
        say("   認得的只有：保留 / 刪除 / 併入上一筆 / 待改")
        return False

    if blanks:
        say()
        say("   [中止] 複核表有 %d 筆「決定」留空：" % len(blanks))
        say("      " + "、".join(blanks[:10]))
        say("   需人工看的每一筆都要明確填：保留 / 刪除 / 併入上一筆 / 待改")
        return False

    # ---------- 3 套用 ----------
    kept = []
    dropped = []
    for r in base:
        v = verdict[r["條文ID"]]
        rec = dict(r)
        rec["人工決定"] = v
        rec["決定備註"] = notes.get(r["條文ID"], "")
        if v == "刪除":
            dropped.append(rec)
        elif v == "併入上一筆":
            if not kept:
                say()
                say("   [中止] %s 要併入上一筆，但它前面沒有留著的條文"
                    % r["條文ID"])
                return False
            prev = kept[-1]
            prev["全文"] = prev["全文"] + rec["全文"]
            prev["字數"] = len(prev["全文"])
            prev["決定備註"] = (prev["決定備註"] + " 併入 " +
                            rec["條文ID"]).strip()
            if rec["結束序號"]:
                prev["結束序號"] = rec["結束序號"]
            rec["決定備註"] = "已併入 " + prev["條文ID"]
            dropped.append(rec)
        else:
            if v == "待改":
                rec["決定備註"] = ("待下一輪處理 " + rec["決定備註"]).strip()
            kept.append(rec)

    # ---------- 4 對帳 ----------
    say()
    say("3. 對帳（留下的字 ＋ 刪掉的字 ＝ 原本的字）")
    a = "".join(r["全文"] for r in base)
    b = "".join(r["全文"] for r in kept)
    c = "".join(r["全文"] for r in dropped if r["人工決定"] == "刪除")
    say("   原本 %d 字" % len(a))
    say("   留下 %d 字" % len(b))
    say("   刪掉 %d 字" % len(c))
    if len(b) + len(c) != len(a):
        say("   [中止] 帳不平，差 %d 字。沒有寫出任何檔案。"
            % (len(a) - len(b) - len(c)))
        return False
    say("   帳平")

    say()
    say("4. 刪掉的明細（已存進 06_deleted.csv 備查）")
    for r in dropped:
        say("   %-24s %s 字  決定=%s  %s"
            % (r["條文ID"], r["字數"], r["人工決定"],
               (r["全文"][:30] or "（空）")))

    say()
    withnote = [r for r in kept if r["決定備註"]]
    if withnote:
        say()
        say("5. 你有寫說明的條文（已存進「決定備註」欄）")
        for r in withnote:
            say("   %-24s 決定=%s" % (r["條文ID"], r["人工決定"]))
            for ln in r["決定備註"].split(chr(10))[:6]:
                say("      " + ln[:70])

    say()
    say("6. 產出")
    say("   06_final.csv    %d 筆" % len(kept))
    say("   06_deleted.csv  %d 筆" % len(dropped))
    todo = [r["條文ID"] for r in kept if r["人工決定"] == "待改"]
    if todo:
        say("   標「待改」還沒處理的 %d 筆：%s"
            % (len(todo), "、".join(todo[:8])))

    proof = {
        "格式版本": 1,
        "產生時間": datetime.datetime.now().astimezone().isoformat(),
        "底本": {
            "檔名": os.path.basename(base_path),
            "SHA256": file_sha256(base_path),
            "總筆數": len(base),
        },
        "決定檔": {
            "檔名": os.path.basename(dec_path),
            "SHA256": file_sha256(dec_path),
            "列數": len(dec),
        },
        "完整複核": {
            "應複核筆數": len(required_ids),
            "已明確決定筆數": len(required_ids),
            "未複核筆數": 0,
        },
        "逐筆複核": [
            {
                "條文ID": item_id,
                "決定": verdict[item_id],
                "旗標": base_by_id[item_id].get("旗標", ""),
                "全文SHA256": hashlib.sha256(
                    base_by_id[item_id].get("全文", "").encode("utf-8")
                ).hexdigest(),
            }
            for item_id in required_ids
        ],
        "決定統計": dict(tally),
        "輸出統計": {"保留": len(kept), "刪除或併入": len(dropped)},
    }
    return kept, dropped, list(base[0].keys()) + NEW_COLS, proof


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法：py S6_套用決定.py <資料夾> <你填好的CSV>")
        sys.exit(1)

    folder, dec_path = sys.argv[1], sys.argv[2]
    result = main(folder, dec_path)

    ok = isinstance(result, tuple)
    if ok:
        kept, dropped, cols, proof = result
        for name, rows in (("06_final.csv", kept), ("06_deleted.csv", dropped)):
            with open(os.path.join(folder, name), "w",
                      encoding="utf-8-sig", newline="") as f:
                w = csv.DictWriter(f, fieldnames=cols, quoting=csv.QUOTE_ALL)
                w.writeheader()
                for r in rows:
                    w.writerow(dict((c, r.get(c, "")) for c in cols))
        proof["輸出"] = {}
        for name in ("06_final.csv", "06_deleted.csv"):
            path = os.path.join(folder, name)
            proof["輸出"][name] = {
                "SHA256": file_sha256(path),
                "位元組": os.path.getsize(path),
            }
        proof_path = os.path.join(folder, "S6_複核證明.json")
        with open(proof_path, "w", encoding="utf-8") as f:
            json.dump(proof, f, ensure_ascii=False, indent=2)
            f.write("\n")
        say()
        say("=" * 62)
        say("結論：S6 完成。")
        say("完整複核證明：%s" % proof_path)
        say("=" * 62)
    else:
        if invalidate_outputs:
            quarantine_outputs(folder)
        say()
        say("=" * 62)
        say("結論：沒有通過，沒有寫出任何檔案。")
        say("=" * 62)

    report = "\n".join(lines)
    with open(os.path.join(folder, "S6_套用報告.txt"), "w",
              encoding="utf-8-sig") as f:
        f.write(report + "\n")

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if ok else 1)
