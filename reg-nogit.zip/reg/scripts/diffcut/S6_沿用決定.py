# -*- coding: utf-8 -*-
r"""
S6 沿用：產生複核表，但沒改的條文直接預填上一版的人工決定

用法：
    py S6_沿用決定.py <資料夾> <舊發布根目錄> [輸出檔]

輸入：<資料夾>\05_flagged.csv
      <舊發布根目錄>\LATEST.json → 版本目錄\06_final.csv、06_deleted.csv、05_flagged.csv
      （05_flagged.csv 是合併前的底本，拿來比全文；舊版 S12 發布的沒有這份，照舊用 06）
輸出：<資料夾>\06_複核表.csv        （欄位＝原複核表 ＋ 沿用自、沿用狀態）
      <資料夾>\06_沿用報告.txt
      <資料夾>\06_複核表_怎麼填.txt

規則：
    全文（去空白）在舊版唯一命中、旗標相同      → 預填舊決定，狀態「沿用」
    唯一命中、旗標不同                          → 預填舊決定，狀態「旗標有變，請再看一眼」
    無命中或多筆命中                            → 空白，狀態「要人看」
    舊決定是「併入上一筆」但上一筆對不上         → 空白，狀態「要人看（上一筆不同）」

預填的決定寫兩行：第一行決定字，第二行「沿用自 舊ID」。
S6_套用決定.py 只看第一行，第二行會存進「決定備註」。人可以改掉預填值。
這支不改 S6_套用決定.py 的任何規則：每一筆需人工看的仍必須有明確決定。
"""

import collections
import csv
import hashlib
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from S6_產生複核表 import OUT_COLS, HOWTO   # noqa: E402

COLS = OUT_COLS + ["沿用自", "沿用狀態"]
lines = []


def say(text=""):
    lines.append(text)


def normalize(text):
    return re.sub(r"\s+", "", text or "")


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path):
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def open_release(release_root):
    """LATEST.json 指到的版本目錄，與 manifest 記的 {路徑: SHA256}。

    跟 reg-diff 讀正式基準（regdiff/baseline_release.py）同一套門檻：
    LATEST 的相對路徑要等於版本號、不能跑出發布根目錄，manifest.json 的 SHA-256 要等於
    LATEST 記的 manifest_SHA256。只信 manifest 的話，改一個發布檔再改 manifest 裡那一行，
    沿用就照單全收。
    """
    latest_path = os.path.join(release_root, "LATEST.json")
    if not os.path.isfile(latest_path):
        raise ValueError("找不到 %s；只接受 S12 發布根目錄" % latest_path)
    with io.open(latest_path, encoding="utf-8-sig") as f:
        latest = json.load(f)
    relative = latest.get("相對路徑", "")
    root = os.path.abspath(release_root)
    version_dir = os.path.abspath(os.path.join(root, relative))
    if not relative or relative != latest.get("正式版本") or \
            os.path.dirname(version_dir) != root:
        raise ValueError("LATEST.json 的相對路徑不對（%r），只接受 S12 發布的版本目錄" % relative)
    manifest_path = os.path.join(version_dir, "manifest.json")
    if not os.path.isfile(manifest_path):
        raise ValueError("正式版本缺少 manifest.json：%s" % version_dir)
    if file_sha256(manifest_path) != latest.get("manifest_SHA256"):
        raise ValueError("manifest.json 與 LATEST.json 記錄的 SHA-256 不符，舊發布檔被改過，不能沿用")
    with io.open(manifest_path, encoding="utf-8-sig") as f:
        manifest = json.load(f)
    return version_dir, {e.get("路徑"): e.get("SHA256") for e in manifest.get("發布檔案", [])}


def read_release_csv(release, name, optional=False):
    """讀正式版裡的一份 CSV，先核對 manifest 的 SHA。

    optional=True：manifest 根本沒列這個檔（更早的 S12 發布的）才回 None；
    manifest 列了、檔案卻不見，一樣是發布檔壞了，要擋，不能當成舊版悄悄退回。
    """
    version_dir, expected = release
    if optional and name not in expected:
        return None
    path = os.path.join(version_dir, name)
    if not os.path.isfile(path):
        raise ValueError("正式版本缺少 %s" % name)
    if expected.get(name) != file_sha256(path):
        raise ValueError("%s 的 SHA-256 與 manifest 不符，舊發布檔被改過，不能沿用" % name)
    rows = read_csv(path)
    for row in rows:
        row["_來源檔"] = name
    return rows


def load_old(release):
    """讀舊決定（06_final.csv＋06_deleted.csv）。回傳依條文ID排列的列。"""
    rows = read_release_csv(release, "06_final.csv") + read_release_csv(release, "06_deleted.csv")
    rows.sort(key=lambda r: r["條文ID"])
    return rows


def load_old_base(release, decided_rows):
    """舊版合併前的底本（05_flagged.csv），每一列補上它在舊版的人工決定；沒有就回 None。

    沿用要拿「合併前」的全文比：06_final.csv 裡被併過的那一筆，全文已經接上了
    被併進來的字，跟這一輪 05_flagged.csv 同一筆的全文（合併前）必然不同——
    「併入上一筆」的上一筆永遠對不上，上一筆自己也配不到。
    S12 從這一版起把 05_flagged.csv 一起發布；更早的正式版沒有，回 None 由呼叫端照舊做法。
    """
    base = read_release_csv(release, "05_flagged.csv", optional=True)
    if base is None:
        return None
    decision_of = dict((r["條文ID"], r.get("人工決定") or "") for r in decided_rows)
    for row in base:
        row["人工決定"] = decision_of.get(row["條文ID"], "")
    return base


# S6_套用決定 把「併入上一筆」接到「前一個留下來的筆」（kept[-1]）：留下來的是保留與待改，
# 刪除與併入上一筆的都不算。
KEPT = ("保留", "待改")


def _merge_host(rows, index, decision_at):
    """rows[index] 若是「併入上一筆」，會被接到哪一筆：往前找第一筆決定是保留／待改的。

    decision_at(j) 回傳第 j 筆的決定；回傳 None 代表還不知道（要人看），這時候
    說不準接到誰，回傳 None。找到就回那一筆的全文（去空白），前面沒有留下來的筆回 ""。
    以前只看緊鄰的前一筆：中間夾一筆刪除時比的是那筆刪除，真正的接點換過了也照樣沿用。
    """
    for j in range(index - 1, -1, -1):
        decision = decision_at(j)
        if decision is None:
            return None
        if decision in KEPT:
            return normalize(rows[j].get("全文"))
    return ""


def inherit(new_rows, old_rows):
    """回傳 [(新列, 決定, 沿用自, 狀態)]，只含需人工看=Y 的列。"""
    by_text = collections.defaultdict(list)
    for row in old_rows:
        by_text[normalize(row.get("全文"))].append(row)
    old_index = dict((row["條文ID"], i) for i, row in enumerate(old_rows))

    def old_decision(j):
        return (old_rows[j].get("人工決定") or "").strip()

    new_decision = {}          # 新列索引 → 決定（沿用得到的）；要人看的記 None

    def decision_now(j):
        if new_rows[j].get("需人工看") != "Y":
            return "保留"          # 不需人工看的列 S6 一律留下
        return new_decision.get(j)

    new_count = collections.Counter(normalize(row.get("全文")) for row in new_rows)

    result = []
    for index, row in enumerate(new_rows):
        if row.get("需人工看") != "Y":
            continue
        text = normalize(row.get("全文"))
        matches = by_text.get(text, [])
        if len(matches) != 1:
            result.append((row, "", "", "要人看" if not matches else "要人看（舊版有多筆同文）"))
            new_decision[index] = None
            continue
        if new_count[text] > 1:
            # 舊版只有一筆、新版有好幾筆同文（新增了同文條文）：不知道舊決定是哪一筆的（A7）
            result.append((row, "", "", "要人看（新版有多筆同文）"))
            new_decision[index] = None
            continue
        old = matches[0]
        if ((old.get("章標題") or "").strip(), (old.get("節標題") or "").strip()) != \
                ((row.get("章標題") or "").strip(), (row.get("節標題") or "").strip()):
            # 同一段字搬到別章別節：舊版在原位置判的（例如「刪除」重複的那一筆），搬過去不一定成立（A7）
            result.append((row, "", old["條文ID"], "要人看（搬到別的章節）"))
            new_decision[index] = None
            continue
        decision = (old.get("人工決定") or "").strip()
        if decision not in ("保留", "刪除", "併入上一筆", "待改"):
            result.append((row, "", old["條文ID"], "要人看（舊決定無法辨識）"))
            new_decision[index] = None
            continue
        if decision == "併入上一筆":
            host_new = _merge_host(new_rows, index, decision_now)
            host_old = _merge_host(old_rows, old_index[old["條文ID"]], old_decision)
            if not host_new or host_new != host_old:
                result.append((row, "", old["條文ID"], "要人看（上一筆不同）"))
                new_decision[index] = None
                continue
        status = "沿用" if (old.get("旗標") or "") == (row.get("旗標") or "") else "旗標有變，請再看一眼"
        result.append((row, decision, old["條文ID"], status))
        new_decision[index] = decision
    return result


def main(folder, release_root, out_path):
    src = os.path.join(folder, "05_flagged.csv")
    if not os.path.isfile(src):
        say("找不到 " + src)
        return False
    try:
        release = open_release(release_root)
        old_rows = load_old(release)
        old_base = load_old_base(release, old_rows)
    except ValueError as exc:
        say("[中止] %s" % exc)
        return False
    new_rows = read_csv(src)
    # 有合併前的底本就用它比（全文與「上一筆」都是合併前的樣子，跟這一輪的 05 同一種）；
    # 沒有（舊版 S12 發布的）才退回 06_final＋06_deleted，並講清楚「併入上一筆」沿用不了。
    decided = inherit(new_rows, old_base if old_base is not None else old_rows)

    order = {"空白": 0, "過短": 1, "符號跳號": 2, "完全重複": 3, "開頭相同": 4, "含表格圖形": 5}

    def key(item):
        row, decision, _, status = item
        flags = [f for f in (row.get("旗標") or "").split(";") if f]
        return (0 if not decision else 1, min([order.get(f, 9) for f in flags] or [9]), row["條文ID"])

    decided.sort(key=key)
    with io.open(out_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS, quoting=csv.QUOTE_ALL)
        w.writeheader()
        for row, decision, source_id, status in decided:
            w.writerow({
                "決定": (decision + "\n沿用自 " + source_id) if decision else "",
                "條文ID": row["條文ID"], "旗標": row.get("旗標", ""),
                "系統建議": row.get("建議動作", ""), "字數": row.get("字數", ""),
                "章標題": row.get("章標題", ""), "節標題": row.get("節標題", ""),
                "符號原文": row.get("符號原文", ""), "全文": row.get("全文", ""),
                "重複組": row.get("重複組", ""), "附屬於": row.get("附屬於", ""),
                "含表格標記": row.get("含表格標記", ""),
                "起始序號": row.get("起始序號", ""), "結束序號": row.get("結束序號", ""),
                "附件全文": (row.get("附件全文") or "")[:300],
                "沿用自": source_id, "沿用狀態": status,
            })
    with io.open(os.path.join(folder, "06_複核表_怎麼填.txt"), "w", encoding="utf-8-sig") as f:
        f.write(HOWTO)
        f.write("\n九、這張表有「沿用自」「沿用狀態」兩欄：狀態「沿用」的已預填上一版決定，\n"
                "    看過覺得對就不用動；「要人看」的一定要填；「旗標有變」的請再看一眼。\n")

    tally = collections.Counter()
    for _, decision, _, status in decided:
        tally["沿用" if status == "沿用" else ("旗標有變" if status.startswith("旗標有變") else "要人看")] += 1
    say("=" * 62)
    say("S6 沿用報告")
    say("舊版：%s" % release_root)
    say("=" * 62)
    if old_base is None:
        say("提醒：舊版沒有發布合併前的底本（05_flagged.csv，舊版 S12 發布的正式版）。"
            "「併入上一筆」的條文與被併過的上一筆拿不到合併前的全文，會落到「要人看」；"
            "用這一版 S12 重新發布一次，下一輪就沿用得到")
    say("全部條文 %d 筆，需人工看 %d 筆" % (len(new_rows), len(decided)))
    say("  沿用 %d 筆（已預填，可不動）" % tally["沿用"])
    say("  旗標有變 %d 筆（已預填，請再看一眼）" % tally["旗標有變"])
    say("  要人看 %d 筆（空白，一定要填）" % tally["要人看"])
    say("複核表：%s" % out_path)
    return True


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法：py S6_沿用決定.py <資料夾> <舊發布根目錄> [輸出檔]")
        sys.exit(1)
    folder, release_root = sys.argv[1], sys.argv[2]
    out = sys.argv[3] if len(sys.argv) > 3 else os.path.join(folder, "06_複核表.csv")
    ok = main(folder, release_root, out)
    report = "\n".join(lines)
    with io.open(os.path.join(folder, "06_沿用報告.txt"), "w", encoding="utf-8-sig") as f:
        f.write(report + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    print(report, flush=True)
    sys.exit(0 if ok else 1)
