# -*- coding: utf-8 -*-
"""章、節標題怎麼認：S1P、S2、S3 共用同一把尺（S1 巨集的 IsChapter／IsSection 照同一套寫）。

以前各支各寫一套：S1 巨集「第一個字是第、前 8 個字有章」就算章，S3、S2 只認一到十的國字。
結果「第壹章」「第2章」「第十一章」切出來章序號都是 000（ID 重複），內文「第三款依第二章規定…」
被當成一章，關卡都不擋。現在：

    標題 = 第 ＋ 數字（國字一二三…、大寫壹貳參…、阿拉伯、全形）＋ 章／節 ＋ 標題文字
    標題文字：可以沒有；有的話不超過 30 字、不含句號，而且第一個字不是接續語
             （所、之、的、規定、第、及、或、與、至、中所、內所、，、；、。）——標題本身可能是「內部控制」「目的」，
             所以只擋這幾個接續語，不擋單一個「內」「目」
             「第二章所定之表單」「第三章第二節規定」是內文在引用，不是標題。
"""

import re

_DIGITS = "〇零一二三四五六七八九"
_VALUE = dict(zip("〇零一二三四五六七八九", (0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9)))
_UPPER = {"壹": "一", "貳": "二", "參": "三", "叁": "三", "肆": "四", "伍": "五", "陸": "六",
          "柒": "七", "捌": "八", "玖": "九", "拾": "十", "佰": "百", "兩": "二", "廿": "二十"}
NUM_CHARS = "〇零一二三四五六七八九十百壹貳參叁肆伍陸柒捌玖拾佰兩廿0-9０-９"
HEAD_RE = re.compile(r"^第\s*([%s]+)\s*([章節])" % NUM_CHARS)
SEPARATORS = "、：:．. 　"
CONTINUATION = ("所", "之", "的", "規定", "第", "及", "或", "與", "至", "中所", "內所", "，", ",", "；", ";", "。")
MAX_TITLE = 30


def cn_num(s):
    """國字、大寫、阿拉伯、全形數字 → int；認不出來回 None。認到 999。"""
    s = (s or "").strip()
    if not s:
        return None
    s = "".join(chr(ord(c) - 0xFEE0) if "０" <= c <= "９" else c for c in s)
    if s.isdigit():
        return int(s)
    for k, v in _UPPER.items():
        s = s.replace(k, v)
    if any(c not in _DIGITS + "十百" for c in s):
        return None
    if "十" not in s and "百" not in s:
        # 逐位寫法：一〇五
        if len(s) == 1:
            return _VALUE[s] or None
        return int("".join(str(_VALUE[c]) for c in s))
    total = 0
    rest = s
    if "百" in rest:
        left, _, rest = rest.partition("百")
        if len(left) > 1 or "十" in left:
            return None
        total += (_VALUE[left] if left else 1) * 100
        rest = rest.lstrip("〇零")
    if "十" in rest:
        left, _, rest = rest.partition("十")
        if len(left) > 1:
            return None
        total += (_VALUE[left] if left else 1) * 10
    if rest:
        if len(rest) > 1:
            return None
        total += _VALUE[rest]
    return total or None


def heading(text):
    """(「章」或「節」, 序號)；不是章節標題回 None。"""
    text = (text or "").strip()
    m = HEAD_RE.match(text)
    if not m:
        return None
    rest = text[m.end():].lstrip(SEPARATORS)
    if rest and (rest.startswith(CONTINUATION) or "。" in rest or len(rest) > MAX_TITLE):
        return None
    n = cn_num(m.group(1))
    if not n:
        return None
    return m.group(2), n


# 條文式編排（第一條、第五條之一）：S3 拿它當最上層的切點（符號類型 F，A8）。
# 後面接「規定」「所定」「至」「、第」這種的是句子在引用別條，不是條號本身。
ARTICLE_RE = re.compile(r"^第\s*[%s]+\s*條(?:\s*之\s*[%s]+)?(?!\s*(?:規定|所|至|及|或|與|之|中|內|第|，|,|。|、))"
                        % (NUM_CHARS, NUM_CHARS))


def article(text):
    """段首的條號（「第五條之一」）；不是條號開頭回空字串。"""
    m = ARTICLE_RE.match((text or "").strip())
    return m.group(0).strip() if m else ""


def is_chapter(text):
    h = heading(text)
    return bool(h) and h[0] == "章"


def is_section(text):
    h = heading(text)
    return bool(h) and h[0] == "節"


def number_of(text, kind):
    """章或節標題的序號；不是這一種標題回 None。"""
    h = heading(text)
    return h[1] if h and h[0] == kind else None
