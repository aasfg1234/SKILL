# -*- coding: utf-8 -*-
r"""
S1T：把 Word 另存的 txt 轉成 S1 格式的匯出檔

用法：
    py S1T_txt轉匯出.py <全文.txt> <輸出資料夾>

產出跟 S1 VBA 一樣的三樣東西，讓 S3 到 S7 可以直接吃：
    01_paragraphs.csv
    02_shapes.csv
    tables\T001.md ... T018.md

===========================================================
這不是 S1 的替代品，是 S1 的「代打」
===========================================================
真正要交件還是要回公司跑 S1_匯出全文.bas。
txt 這條路有三個先天缺陷，對話紀錄裡都記過：

  F15 表格被壓平，欄與列的對應關係救不回來。
      這支程式只能把表格的字「圈回來」放進 Tnnn.md，
      排成一格一行，不是真的表格。
  F19 流程圖裡的字撈不到。txt 只留下「【流程圖】」四個字。
  F5  沒有樣式，章節只能靠文字判斷。

===========================================================
表格怎麼定位
===========================================================
用當初 VBA 盤點出來的 18 張表當答案卷：
每張表的所在章節、非空格數、總字數都是已知的。

程式先找出「連續短行、開頭沒有編號」的區塊當候選，
再用盤點的字數去修邊界。跑完會印出「實際 vs 盤點」給你對。

===========================================================
唯一一處改字，先講
===========================================================
第五章在 txt 裡是「五章 商品適合度管理」，掉了「第」字（F4）。
那是 Word 另存 txt 的災情，原始 Word 裡有「第」。
程式會把它補回來，並在報告裡標明。這是全篇唯一一處改字。
"""

import csv
import io
import os
import re
import sys

# 表格盤點結果（當初 VBA 在真 Word 上數出來的，當答案卷用）
#  (表號, 起始行, 所在章, 所在節關鍵字, 盤點非空格, 盤點字數)
TABLES = [
    (1,   63, "",   "",              22, 1550),
    (2,  340, "4",  "第一節",          3,  258),
    (3,  460, "4",  "第二節",         16,   85),
    (4,  477, "4",  "第二節",          8,   27),
    (5,  534, "5",  "第一節",         19, 1215),
    (6,  865, "6",  "第一節",          8,   70),
    (7, 1162, "10", "",               3,   46),
    (8, 1230, "10", "",              12,  346),
    (9, 1247, "10", "",               6,  165),
    (10, 1256, "10", "",             20,  179),
    (11, 1285, "10", "",             12,  370),
    (12, 1301, "10", "",              6,  173),
    (13, 1314, "10", "",             10,  415),
    (14, 1400, "12", "",            120,  731),
    (15, 1543, "12", "",              5,  152),
    (16, 1556, "12", "",              5,  205),
    (17, 1571, "12", "",              5,  238),
    (18, 1590, "12", "",              6,  265),
]

# 兩張流程圖的錨點行（txt 只留下「【流程圖】」，圖裡的字取不到）
SHAPES = [(1, 342, "4", "第一節"), (2, 1164, "10", "")]

TOC_FROM, TOC_TO = 19, 58          # 目錄區（含）
BODY_FROM = 225                     # 正文從第一章開始

TOP = re.compile(r"^\s*(第[一二三四五六七八九十]{1,3}[章節]"
                 r"|[一二三四五六七八九十]{1,3}章\s"
                 r"|[一二三四五六七八九十]{1,3}、)")
CH_PAT = re.compile(r"^第([一二三四五六七八九十]{1,3})章")
SE_PAT = re.compile(r"^第([一二三四五六七八九十]{1,3})節")

CN = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5,
      "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}

COLS = ["序號", "位置", "類型", "所在章", "所在節",
        "樣式", "在表格內", "自動編號", "全文", "字數"]

lines = []


def say(s=""):
    lines.append(s)


def clean(s):
    """跟 S1 VBA 的 CleanText 同一套：控制字元換空白，多空白併一個。"""
    for ch in (7, 9, 10, 11, 12, 13, 30, 31):
        s = s.replace(chr(ch), " ")
    s = s.replace(" ", " ").replace("　", " ")
    s = s.replace("﻿", "").replace("​", "")
    while "  " in s:
        s = s.replace("  ", " ")
    return s.strip()


def cn2int(s):
    if "十" in s:
        left, _, right = s.partition("十")
        return (CN.get(left, 1) if left else 1) * 10 + (CN.get(right, 0) if right else 0)
    return CN.get(s, 0)


def table_end(L, start, target, stops):
    """從 start 往下收，收到字數接近盤點值就停。"""
    total = 0
    end = start
    for j in range(start, len(L)):
        if j != start and j in stops:
            break
        s = L[j].strip()
        if j != start and s and TOP.match(s) and total >= target * 0.6:
            break
        if s and total and total + len(s) > target * 1.25:
            break
        total += len(s)
        end = j + 1
        if total >= target:
            break
    return end, total


def main(txt_path, out_dir):
    raw = io.open(txt_path, encoding="utf-8-sig").read()
    L = [clean(l) for l in raw.split("\n")]
    # 表格位置、目錄區、正文起點都是那一份手冊寫死的：別份 txt 丟進來會切出一堆錯的表，
    # 後面的關卡不一定擋得住。對不上就停（B32）
    if len(L) <= max(t[1] for t in TABLES) or not CH_PAT.match(L[BODY_FROM].strip()):
        raise SystemExit("[中止] S1T 是特定那一份手冊專用的（表格位置寫死在程式裡），這一份 txt 對不上。"
                         ".docx 請直接跑 cut（會自動用 S1P 匯出，不用 Word）；只有 txt 的請先轉成 .docx")

    say("=" * 64)
    say("S1T：txt 轉 S1 匯出格式")
    say("來源：%s（%d 行）" % (txt_path, len(L)))
    say("=" * 64)

    # ---------- 第五章補「第」字（F4，全篇唯一一處改字）----------
    fixed = 0
    for i, l in enumerate(L):
        if l.strip().startswith("五章 商品適合度"):
            L[i] = l.replace("五章", "第五章", 1)
            fixed += 1
            say()
            say("1. 已修：第 %d 行「%s」" % (i, L[i].strip()))
            say("   原本掉了「第」字（F4）。原始 Word 裡有，是 txt 匯出弄掉的。")
    if not fixed:
        say()
        say("1. 沒有發現第五章掉字")

    # ---------- 圈出 18 張表 ----------
    starts = set(t[1] for t in TABLES)
    tbl_range = {}
    say()
    say("2. 表格定位（實際 vs 當初 VBA 盤點）")
    say("   表號   行範圍          實際字數  盤點字數  差")
    # T005 的最後三行仍是表格內容，但累計字數已達盤點值，通用的
    # table_end 會提早停在「（1）就前四項…」。明確收到第二節標題前。
    HARD_END = {1: BODY_FROM - 1, 5: 609, 13: 1339, 18: len(L)}
    for tid, st, ch, se, want_n, want_c in TABLES:
        stop = set(s for s in starts if s > st) | set([BODY_FROM] if st < BODY_FROM else [])
        if tid in HARD_END:
            en = HARD_END[tid]
            got = sum(len(L[j].strip()) for j in range(st, en))
        else:
            en, got = table_end(L, st, want_c, stop)
        tbl_range[tid] = (st, en)
        say("   T%03d  %5d-%-5d  %7d  %8d  %+d"
            % (tid, st, en, got, want_c, got - want_c))

    in_table = {}
    for tid, (a, b) in tbl_range.items():
        for j in range(a, b):
            in_table[j] = tid

    shape_at = dict((ln, sid) for sid, ln, ch, se in SHAPES)

    # ---------- 一行一列，逐行判類型 ----------
    rows = []
    pos = 0
    cur_ch, cur_se = "", ""
    done_tbl, done_shp = set(), set()

    def add(kind, text, style="內文", in_tbl="N", auto=""):
        nonlocal pos
        pos += max(len(text), 1) + 1
        rows.append({"序號": len(rows) + 1, "位置": pos, "類型": kind,
                     "所在章": cur_ch, "所在節": cur_se, "樣式": style,
                     "在表格內": in_tbl, "自動編號": auto,
                     "全文": text, "字數": len(text)})

    for i, raw_line in enumerate(L):
        s = raw_line.strip()

        # 表格：先放記號，再把整塊當表格內
        if i in in_table:
            tid = in_table[i]
            if tid not in done_tbl:
                if i in shape_at or (tbl_range[tid][0] <= shape_at.get(-1, -1)):
                    pass
                for sid, ln, sch, sse in SHAPES:
                    if tbl_range[tid][0] <= ln < tbl_range[tid][1] and sid not in done_shp:
                        add("圖形標記", "[[SHAPE:%03d]]" % sid)
                        done_shp.add(sid)
                add("表格標記", "[[TABLE:%03d]]" % tid)
                done_tbl.add(tid)
            if s:
                add("表格內", s, in_tbl="Y")
            continue

        if not s:
            continue

        if TOC_FROM <= i <= TOC_TO:
            add("目錄", s, style="目錄 1")
            continue

        if i >= BODY_FROM and len(s) <= 40 and CH_PAT.match(s):
            cur_ch, cur_se = s, ""
            add("章", s, style="標題 1")
            continue

        if i >= BODY_FROM and len(s) <= 60 and SE_PAT.match(s):
            cur_se = s
            add("節", s, style="標題 2")
            continue

        add("內文", s, style="清單段落" if TOP.match(s) else "內文")

    # ---------- 寫表格檔 ----------
    tdir = os.path.join(out_dir, "tables")
    if not os.path.isdir(tdir):
        os.makedirs(tdir)
    for tid, (a, b) in sorted(tbl_range.items()):
        cells = [L[j].strip() for j in range(a, b) if L[j].strip()]
        with io.open(os.path.join(tdir, "T%03d.md" % tid), "w",
                     encoding="utf-8-sig", newline="\n") as f:
            f.write("# T%03d\n\n" % tid)
            f.write("> 來源：Word 另存的 txt。欄列結構已被壓平，救不回來（F15）。\n")
            f.write("> 下面一行等於原本表格的一格，順序照原文，但分不出哪格是哪一列哪一欄。\n\n")
            for c in cells:
                f.write("- " + c + "\n")

    # ---------- 寫圖形檔 ----------
    with io.open(os.path.join(out_dir, "02_shapes.csv"), "w",
                 encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(["圖形編號", "子項", "錨點位置", "所在章", "所在節",
                    "圖形名稱", "左", "上", "寬", "高", "文字", "字數"])
        for sid, ln, ch, se in SHAPES:
            txt = L[ln].strip() or "【流程圖】"
            w.writerow(["%03d" % sid, 1, ln, "第%s章" % ch, se,
                        "流程圖", 0, 0, 0, 0, txt, len(txt)])

    # ---------- 寫段落檔 ----------
    with io.open(os.path.join(out_dir, "01_paragraphs.csv"), "w",
                 encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS, quoting=csv.QUOTE_ALL)
        w.writeheader()
        w.writerows(rows)

    # ---------- 報告 ----------
    say()
    say("3. 產出")
    kinds = {}
    for r in rows:
        kinds[r["類型"]] = kinds.get(r["類型"], 0) + 1
    say("   01_paragraphs.csv  %d 列" % len(rows))
    for k in ("目錄", "章", "節", "內文", "表格標記", "表格內", "圖形標記"):
        say("      %-6s %d" % (k, kinds.get(k, 0)))
    say("   02_shapes.csv      %d 張圖" % len(SHAPES))
    say("   tables\\            18 個檔")

    ch = [r["全文"] for r in rows if r["類型"] == "章"]
    se = [r["全文"] for r in rows if r["類型"] == "節"]
    say()
    say("4. 章節")
    say("   章 %d 個（應該 12）" % len(ch))
    for c in ch:
        say("      " + c[:44])
    say("   節 %d 個（應該 25）" % len(se))

    say()
    say("5. 取不到的東西（txt 先天缺陷，不是程式漏做）")
    say("   表格的欄列結構：救不回來（F15）")
    say("   流程圖裡的字：txt 只有「【流程圖】」四個字（F19）")
    say("   樣式：沒有，章節靠文字判斷（F5）")
    say("   要拿到這三樣，只能回公司跑 S1_匯出全文.bas")

    return rows


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法：py S1T_txt轉匯出.py <全文.txt> <輸出資料夾>")
        sys.exit(1)

    src, dst = sys.argv[1], sys.argv[2]
    if not os.path.isdir(dst):
        os.makedirs(dst)
    main(src, dst)

    report = "\n".join(lines)
    with io.open(os.path.join(dst, "S1T_轉換報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
