# -*- coding: utf-8 -*-
r"""
S11：把 S1 到 S9 的成果打包成「這本規章的規格表」，給 reg-diff 用

用法：
    py S11_規格包.py <資料夾> <輸出資料夾>

例：
    py S11_規格包.py data_real "..\規格包_業務管理篇"

===========================================================
這包東西是什麼
===========================================================
reg-diff 現在的做法是：拿舊版跟新版兩個檔，當場算差異、當場算重複。
每次都從零開始，條號要重認、重複要重算、門檻要重猜。

規格包是「這本規章的答案卷」：
    這本規章有幾條、每條的編號與層級、在原檔第幾列
    哪幾條由程式判定為重複或相似（仍須人工判斷）
    哪幾條互相引用、引用了哪些外部法規
    改哪一條要連帶看哪些

有了它，reg-diff 不用再猜這三件事，判斷會準很多。

===========================================================
產出
===========================================================
    規格.json            這本規章的基本資料與章節樹
    條文.csv             一條一列，含編號、層級、原檔位置
    重複組.csv           已算出的重複與相似候選
    引用.csv             規章內引用與外部法規引用
    連帶.csv             改這條要連帶看哪些
    synonyms_建議.json   跟 reg-diff 現有詞表比對後的增補建議
    README.md            怎麼接進 reg-diff
"""

import csv
import io
import json
import os
import sys
import collections

TABLES = os.path.normpath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", "tables"))

# 這三個是文件的門面資料，執行時給：
#     py S11_規格包.py <來源> <輸出> --name "..." --org "..." --ver "115.06"
NAME = "（未指定規章名）"
ORG = ""
VER = ""

lines = []


def say(s=""):
    lines.append(s)


def load(folder, name):
    p = os.path.join(folder, name)
    if not os.path.isfile(p):
        return None
    with io.open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def dump_csv(path, cols, rows):
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, quoting=csv.QUOTE_ALL)
        w.writeheader()
        for r in rows:
            w.writerow(dict((c, r.get(c, "")) for c in cols))


README = """# 規格包：{name}

這是 `diff-cut` 流水線跑完之後產出的「規格表」，給 `reg-diff` 用來提高判斷精準度。

版本日：{ver}
產生日：{today}
資料來源：{src}

---

## reg-diff 正式接法

不要把這個資料夾單獨交給 reg-diff。先由 S12 放進不可覆寫的正式版本，再把
**發布根目錄**交給 reg-diff：

    python scripts/run_all.py 舊版.docx 新版.docx --outdir 產出 --baseline-release <diff-cut發布根目錄>

reg-diff 只從 `LATEST.json` 取版本，會核對 manifest、所有發布檔 SHA-256，並確認
舊版檔案就是產生這份規格包的原始檔。通過後會：

- 用 `條文.csv` 的條文 ID 與段次定位本次異動，不再只靠文字猜條號。
- 用 `連帶.csv` 產生 `規格包連帶複核.csv`，直接列出已知重複、相似、引用與外規。
- Step 2 仍照常運算，補抓基準建立後才出現的新關係。

## 其他可人工使用的資料

### 一、換掉同義詞表

`synonyms_建議.json` 列出 diff-cut 在這本規章實際用到、
而 reg-diff 現有詞表沒有的組。看過覺得可以就併進：

    tables/synonyms.json

**併之前一定要自己看過。** reg-diff 的維護原則寫得很清楚：
有疑慮就不要放，錯配會讓人不信任整份清單。

### 二、當 Step 2 候選清單的對照答案

`重複組.csv` 是本次產線已算出的重複與相似清單，仍須人工判斷。
reg-diff 跑完 Step 2 之後，拿它對一下：

- reg-diff 抓到而這裡沒有 → 可能是新發現，也可能是雜訊
- 這裡有而 reg-diff 沒抓到 → **門檻太高，要調低重跑**

### 三、當條號與位置的權威來源

`條文.csv` 每一條都帶「起始序號、結束序號」，指到原檔第幾段。
reg-diff 要回原檔改字時，先跳到那一段再取代，
不要用尋找取代從頭掃 — 這本規章有 {dup} 筆條文的文字在文件裡重複出現。

---

## 檔案說明

| 檔名 | 筆數 | 內容 |
|---|---|---|
| `規格.json` | — | 章節樹、統計、外部規章清單 |
| `條文.csv` | {n_item} | 一條一列，含編號、層級、原檔位置 |
| `重複組.csv` | {n_rel} | 已算出的重複與相似候選，仍須人工判斷 |
| `引用.csv` | {n_cit} | 有引用的條文 |
| `連帶.csv` | {n_imp} | 有連帶關係的條文 |

---

## 這包東西的限制

- 目前的資料由 Word 另存的 txt 轉出，**表格欄列結構是壓平的**，流程圖只剩文字。
  正式使用前要回公司用 `S1_匯出全文.bas` 從原始 Word 重做一遍。
- 「起始序號」只對「產生這包資料的那一份 Word」有效。
  那份檔被人動過，序號就會位移，要整套重跑。
- 重複與連帶是程式算的、人複核過的，但仍是輔助。**送出前要人工複核。**
"""


def main(src_dir, out_dir):
    items = load(src_dir, "06_final.csv") or load(src_dir, "05_flagged.csv")
    rels = load(src_dir, "07_relations.csv") or []
    cits = load(src_dir, "08_citations.csv") or []
    imps = load(src_dir, "09_impact.csv") or []
    if not items:
        say("找不到 06_final.csv，先把 S1 到 S9 跑完")
        return False

    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)

    say("=" * 64)
    say("S11 規格包")
    say("來源：%s" % src_dir)
    say("輸出：%s" % out_dir)
    say("=" * 64)

    # ---------- 章節樹 ----------
    tree = collections.OrderedDict()
    for r in items:
        ci = r["章序號"]
        if ci == "000":
            continue
        node = tree.setdefault(ci, {"章序號": ci, "章標題": r["章標題"],
                                    "節": collections.OrderedDict(),
                                    "條文數": 0})
        node["條文數"] += 1
        if r["節序號"] != "000":
            node["節"].setdefault(r["節序號"],
                                  {"節序號": r["節序號"],
                                   "節標題": r["節標題"], "條文數": 0})
            node["節"][r["節序號"]]["條文數"] += 1

    chapters = []
    for ci, node in tree.items():
        chapters.append({"章序號": ci, "章標題": node["章標題"],
                         "條文數": node["條文數"],
                         "節": list(node["節"].values())})

    # ---------- 條文.csv ----------
    ITEM_COLS = ["條文ID", "章序號", "章標題", "節序號", "節標題",
                 "符號類型", "符號原文", "本範圍層級", "附屬於",
                 "起始序號", "結束序號", "字數", "全文",
                 "含表格標記", "含圖形標記", "附件全文"]
    dump_csv(os.path.join(out_dir, "條文.csv"), ITEM_COLS, items)

    # ---------- 重複組.csv ----------
    REL_COLS = ["關係編號", "關係判定", "條文A", "位置A", "條文B", "位置B",
                "原文相似度", "換詞後相似度", "命中同義詞組", "差在哪裡",
                "比對對象", "A內容", "B內容"]
    keep_rel = [r for r in rels if r["關係判定"] in ("完全相同", "高度相似")]
    dump_csv(os.path.join(out_dir, "重複組.csv"), REL_COLS, keep_rel)

    # ---------- 引用.csv ----------
    CIT_COLS = ["條文ID", "章標題", "節標題", "規章內引用", "引用ID",
                "內引用原文", "規章外引用", "規章名", "條號", "外引用原文"]
    keep_cit = [r for r in cits
                if r["規章內引用"] == "Y" or r["規章外引用"] == "Y"]
    dump_csv(os.path.join(out_dir, "引用.csv"), CIT_COLS, keep_cit)

    # ---------- 連帶.csv ----------
    IMP_COLS = ["條文ID", "風險", "連帶總數", "章標題", "節標題",
                "重複條文", "相似條文", "被誰引用", "我引用誰",
                "外部規章", "條號", "一句話說明"]
    keep_imp = [r for r in imps if r["風險"] != "無"]
    dump_csv(os.path.join(out_dir, "連帶.csv"), IMP_COLS, keep_imp)

    # ---------- 同義詞比對 ----------
    mine = collections.OrderedDict()
    syn_path = os.path.join(TABLES, "S7_同義詞表.csv")
    if os.path.isfile(syn_path):
        with io.open(syn_path, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                mine.setdefault(r["組別"].strip(), []).append(r["詞"].strip())

    theirs = {}
    rd = os.path.join(TABLES, "synonyms.json")
    if os.path.isfile(rd):
        theirs = json.load(io.open(rd, encoding="utf-8")).get("詞組", {})

    # 每個詞屬於 reg-diff 的哪一組
    owner = {}
    for k, v in theirs.items():
        owner[k] = k
        for w in v:
            owner[w] = k

    RISKY = {"通路": "銀行通路與證券通路不是同義詞，是不同通路。"
                     "diff-cut 用它配對「同一張表的不同通路版本」有效，"
                     "但放進 reg-diff 可能製造假陽性。建議先不要放。"}

    add_to = {}      # 加到 reg-diff 現有的哪一組
    brand_new = {}   # reg-diff 完全沒有的新組
    already = []
    risky = {}

    for g, words in mine.items():
        if g in RISKY:
            risky[g] = RISKY[g]
            continue
        # 這組的詞落在 reg-diff 哪一組
        hosts = [owner[w] for w in [g] + words if w in owner]
        new_words = [w for w in words
                     if w != g and w not in owner]
        if hosts:
            host = hosts[0]
            if new_words:
                add_to[host] = new_words
            else:
                already.append("%s（reg-diff 叫「%s」）" % (g, host)
                               if host != g else g)
        elif new_words or g not in owner:
            brand_new[g] = [w for w in words if w != g]

    suggest = dict(brand_new)

    with io.open(os.path.join(out_dir, "synonyms_建議.json"), "w",
                 encoding="utf-8") as f:
        json.dump({
            "_說明": [
                "這是 diff-cut 在這本規章實際用到、而 reg-diff 現有詞表沒有的組。",
                "格式跟 reg-diff 的 synonyms.json 一樣：\"代表詞\": [變體...]",
                "併進 tables/synonyms.json 之前請自己看過。",
                "reg-diff 的維護原則：有疑慮就不要放，錯配會讓人不信任整份清單。",
            ],
            "一_加到現有的組": add_to,
            "二_全新的組": brand_new,
            "三_有疑慮先不要放": risky,
            "四_reg-diff已經有了": already,
        }, f, ensure_ascii=False, indent=2)

    # ---------- 規格.json ----------
    ext = collections.Counter()
    for r in cits:
        for nm in (r.get("規章名") or "").split(";"):
            if nm.strip():
                ext[nm.strip()] += 1

    spec = {
        "格式版本": 1,
        "規章名": NAME,
        "所屬機構": ORG,
        "版本日": VER,
        "資料來源": os.path.basename(os.path.abspath(src_dir)),
        "統計": {
            "章": len(chapters),
            "節": sum(len(c["節"]) for c in chapters),
            "條文": len(items),
            "表格": len(set(t for r in items
                            for t in (r.get("含表格標記") or "").split(";") if t)),
            "流程圖": len(set(t for r in items
                            for t in (r.get("含圖形標記") or "").split(";") if t)),
            "總字數": sum(int(r["字數"] or 0) for r in items),
            "重複與相似組": len(keep_rel),
            "有引用的條文": len(keep_cit),
            "有連帶的條文": len(keep_imp),
        },
        "章節樹": chapters,
        "引用到的外部規章": [{"規章名": k, "次數": v}
                       for k, v in ext.most_common()],
        "注意事項": [
            "起始序號、結束序號只對產生這包資料的那一份 Word 有效。原檔被動過就要整套重跑。",
            "目前資料由 Word 另存的 txt 轉出，表格欄列結構已壓平，流程圖只剩文字。",
            "所有產出都是輔助，送出前仍需人工複核。",
        ],
    }
    with io.open(os.path.join(out_dir, "規格.json"), "w",
                 encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, indent=2)

    # ---------- README ----------
    import datetime
    dup = sum(1 for r in imps if r.get("重複條文"))
    with io.open(os.path.join(out_dir, "README.md"), "w",
                 encoding="utf-8") as f:
        f.write(README.format(
            name=spec["規章名"], ver=spec["版本日"],
            today=datetime.date.today().isoformat(),
            src=spec["資料來源"], dup=dup,
            n_item=len(items), n_rel=len(keep_rel),
            n_cit=len(keep_cit), n_imp=len(keep_imp)))

    # ---------- 報告 ----------
    say()
    say("1. 產出")
    for n in ("規格.json", "條文.csv", "重複組.csv", "引用.csv",
              "連帶.csv", "synonyms_建議.json", "README.md"):
        p = os.path.join(out_dir, n)
        say("   %-22s %d 位元組" % (n, os.path.getsize(p)))

    say()
    say("2. 規格摘要")
    for k, v in spec["統計"].items():
        say("   %-12s %s" % (k, v))

    say()
    say("3. 同義詞比對（跟 reg-diff 現有 %d 組比）" % len(theirs))
    say("   一、加到 reg-diff 現有的組（%d 處）" % len(add_to))
    for g, w in add_to.items():
        say("      「%s」那一組，加上：%s" % (g, "、".join(w)))
    say("   二、全新的組（%d 組）" % len(brand_new))
    for g, w in brand_new.items():
        say("      %-6s -> %s" % (g, "、".join(w)))
    say("   三、有疑慮先不要放（%d 組）：%s" % (len(risky), "、".join(risky)))
    for g, why in risky.items():
        say("      %s：%s" % (g, why))
    say("   四、reg-diff 已經有了（%d 組）：%s" % (len(already), "、".join(already)))

    say()
    say("4. 這包東西怎麼用，看 %s" % os.path.join(out_dir, "README.md"))
    return True


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print('用法：py S11_規格包.py <資料夾> <輸出資料夾> '
              '[--name 規章名] [--org 機構] [--ver 版本日]')
        sys.exit(1)
    for i, a in enumerate(sys.argv):
        if a == "--name" and i + 1 < len(sys.argv):
            NAME = sys.argv[i + 1]
        if a == "--org" and i + 1 < len(sys.argv):
            ORG = sys.argv[i + 1]
        if a == "--ver" and i + 1 < len(sys.argv):
            VER = sys.argv[i + 1]
    ok = main(sys.argv[1], sys.argv[2])
    report = "\n".join(lines)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if ok else 1)
