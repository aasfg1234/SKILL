# -*- coding: utf-8 -*-
r"""
S1P：不用 Word，直接從 .docx 匯出跟 S1 巨集一模一樣格式的三種檔。

用法：
    py S1P_docx匯出.py <原檔.docx> <資料夾> [--安靜]

產出（寫在 <資料夾>）：
    01_paragraphs.csv   全文，一段一列，含表格與圖形標記（欄位、類型、清理規則照 S1_匯出全文.bas）
    02_shapes.csv       浮動圖形（文字方塊、群組）裡的文字
    tables\T001.md ...  一張表一個檔（合併儲存格由上方值往下填滿）

為什麼要有這一支：S1 巨集要在有 Word 的電腦上手動貼進 VBA 跑，建基準每一本、每一版都要人跑一次。
.docx 本身就是 XML，段落、表格、文字方塊、自動編號都讀得到。讀完之後照樣要過 S2（驗收）、QA、
S10（逐字對帳）三道關卡——這一支匯錯，後面的關卡會擋下來，不會悄悄發布。

跟巨集不一樣的地方（寧可停下來，也不要猜）：
    Word 自動編號由這裡照 numbering.xml 算（十進位、一二三、甲乙丙、羅馬數字、英文字母、①…）；
    遇到算不出來的編號格式就停，請改用 S1 巨集。
    還有追蹤修訂沒接受的檔也停：切條一定要用定稿乾淨版。
"""

import csv
import io
import os
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {
    "w": W,
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
    "v": "urn:schemas-microsoft-com:vml",
    "wps": "http://schemas.microsoft.com/office/word/2010/wordprocessingShape",
    "wpg": "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup",
}
P_COLS = ["序號", "位置", "類型", "所在章", "所在節", "樣式", "在表格內", "自動編號", "全文", "字數"]
S_COLS = ["圖形編號", "子項", "錨點位置", "所在章", "所在節", "圖形名稱", "左", "上", "寬", "高", "文字", "字數"]


def q(tag):
    prefix, _, local = tag.partition(":")
    return "{%s}%s" % (NS[prefix], local)


class ExportError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 文字清理：照巨集的 CleanText
# ---------------------------------------------------------------------------

_SPACE_CHARS = [chr(c) for c in (7, 9, 10, 11, 12, 13, 30, 31)] + [" ", "　"]


def clean_text(s):
    for ch in _SPACE_CHARS:
        s = s.replace(ch, " ")
    s = s.replace("﻿", "").replace("​", "")
    s = re.sub(r"[\x00-\x1f]", " ", s)          # 其他控制字元（S2 會擋）一律當空白
    while "  " in s:
        s = s.replace("  ", " ")
    return s.strip()


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _heading import is_chapter, is_section   # noqa: E402  章節怎麼認：跟 S2、S3 同一把尺


def is_toc(style):
    return "目錄" in style or "toc" in style.lower()


# ---------------------------------------------------------------------------
# 自動編號：照 numbering.xml 算出 Word 的 ListString
# ---------------------------------------------------------------------------

_CN = "〇一二三四五六七八九"
_TIANGAN = "甲乙丙丁戊己庚辛壬癸"
_DIZHI = "子丑寅卯辰巳午未申酉戌亥"


def _cn_count(n):
    """一、二……十、十一……二十、二十一……九十九（taiwaneseCounting／chineseCounting）。"""
    if n <= 0 or n >= 1000:
        raise ExportError("編號 %d 超出能換成中文數字的範圍" % n)
    hundreds, rest = divmod(n, 100)
    tens, ones = divmod(rest, 10)
    out = ""
    if hundreds:
        out += _CN[hundreds] + "百"
        if rest and tens == 0:
            out += "〇"
    if tens:
        out += ("" if tens == 1 and not hundreds else _CN[tens]) + "十"
    if ones:
        out += _CN[ones]
    return out


def _roman(n):
    pairs = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
             (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
    out = ""
    for value, sym in pairs:
        while n >= value:
            out += sym
            n -= value
    return out


def _letter(n):
    return chr(ord("A") + (n - 1) % 26) * ((n - 1) // 26 + 1)


def format_number(n, fmt):
    if fmt in ("decimal", "decimalZero"):
        return ("%02d" % n) if fmt == "decimalZero" else str(n)
    if fmt == "decimalFullWidth":
        return "".join(chr(ord(c) - ord("0") + 0xFF10) for c in str(n))
    if fmt in ("taiwaneseCounting", "taiwaneseCountingThousand", "chineseCounting",
               "chineseCountingThousand"):
        return _cn_count(n)
    if fmt in ("ideographDigital", "taiwaneseDigital"):
        return "".join(_CN[int(c)] for c in str(n))      # 逐位：10 → 一〇
    if fmt in ("ideographTraditional",):
        return _TIANGAN[(n - 1) % 10]
    if fmt in ("ideographZodiac",):
        return _DIZHI[(n - 1) % 12]
    if fmt == "upperRoman":
        return _roman(n)
    if fmt == "lowerRoman":
        return _roman(n).lower()
    if fmt == "upperLetter":
        return _letter(n)
    if fmt == "lowerLetter":
        return _letter(n).lower()
    if fmt == "decimalEnclosedCircle" and 1 <= n <= 20:
        return chr(0x2460 + n - 1)
    if fmt == "decimalEnclosedCircleChinese" and 1 <= n <= 10:
        return chr(0x3280 + n - 1)
    if fmt == "none":
        return ""
    raise ExportError("有 Word 自動編號用了這裡算不出來的格式「%s」" % fmt)


class Numbering(object):
    """numbering.xml：每一個 numId 各自一串計數（Word 的「清單」）。"""

    def __init__(self, root):
        self.abstract = {}
        self.nums = {}
        self.counters = {}
        if root is None:
            return
        for an in root.findall(q("w:abstractNum")):
            levels = {}
            for lvl in an.findall(q("w:lvl")):
                ilvl = int(lvl.get(q("w:ilvl")) or 0)
                levels[ilvl] = {
                    "start": int(_val(lvl.find(q("w:start"))) or 1),
                    "fmt": _val(lvl.find(q("w:numFmt"))) or "decimal",
                    "text": _val(lvl.find(q("w:lvlText"))) or "",
                    "legal": lvl.find(q("w:isLgl")) is not None,
                }
            self.abstract[an.get(q("w:abstractNumId"))] = levels
        for num in root.findall(q("w:num")):
            overrides = {}
            for ov in num.findall(q("w:lvlOverride")):
                start = ov.find(q("w:startOverride"))
                if start is not None:
                    overrides[int(ov.get(q("w:ilvl")) or 0)] = int(_val(start) or 1)
            self.nums[num.get(q("w:numId"))] = (_val(num.find(q("w:abstractNumId"))), overrides)

    def list_string(self, num_id, ilvl):
        if not num_id or num_id == "0" or num_id not in self.nums:
            return ""
        abstract_id, overrides = self.nums[num_id]
        levels = self.abstract.get(abstract_id) or {}
        if ilvl not in levels:
            return ""
        counts = self.counters.setdefault(num_id, {})
        start = overrides.get(ilvl, levels[ilvl]["start"])
        counts[ilvl] = counts.get(ilvl, start - 1) + 1
        for deeper in [k for k in counts if k > ilvl]:
            del counts[deeper]                      # 上一層往前走，下層重新起算
        level = levels[ilvl]
        if level["fmt"] == "bullet":
            return level["text"]
        text = level["text"]
        for k in range(9):
            token = "%%%d" % (k + 1)
            if token not in text:
                continue
            value = counts.get(k, overrides.get(k, (levels.get(k) or {}).get("start", 1)))
            fmt = "decimal" if level["legal"] else (levels.get(k) or {}).get("fmt", "decimal")
            text = text.replace(token, format_number(value, fmt))
        return text


def _val(el):
    return el.get(q("w:val")) if el is not None else None


# ---------------------------------------------------------------------------
# 讀 docx
# ---------------------------------------------------------------------------

class Styles(object):
    def __init__(self, root):
        self.names, self.numpr, self.based = {}, {}, {}
        self.default = "Normal"
        if root is None:
            return
        for st in root.findall(q("w:style")):
            sid = st.get(q("w:styleId"))
            self.names[sid] = _val(st.find(q("w:name"))) or sid
            self.based[sid] = _val(st.find(q("w:basedOn")))
            numpr = st.find(q("w:pPr") + "/" + q("w:numPr"))
            if numpr is not None:
                self.numpr[sid] = numpr
            if st.get(q("w:type")) == "paragraph" and st.get(q("w:default")) in ("1", "true"):
                self.default = sid

    def numbering_of(self, sid):
        seen = set()
        while sid and sid not in seen:
            seen.add(sid)
            if sid in self.numpr:
                return self.numpr[sid]
            sid = self.based.get(sid)
        return None


def _paragraph_text(p):
    """段落本身的文字（不含文字方塊、欄位代碼、刪除的字；Fallback 那一份不重複算）。"""
    out = []

    def walk(el):
        tag = el.tag
        if tag in (q("w:txbxContent"), q("mc:Fallback"), q("w:del"), q("w:instrText"),
                   q("w:delInstrText"), q("w:pPr"), q("w:rPr")):
            return
        if tag == q("w:t"):
            out.append(el.text or "")
        elif tag in (q("w:tab"), q("w:ptab")):
            out.append("\t")
        elif tag in (q("w:br"), q("w:cr")):
            out.append("\v")
        elif tag == q("w:noBreakHyphen"):
            out.append("-")
        for child in el:
            walk(child)
    walk(p)
    return "".join(out)


def _shapes_in(p):
    """段落裡錨定的浮動圖形（Word 的 doc.Shapes：浮動的 drawing 與 VML；內嵌圖不算）。
    回傳 [(名稱, 左, 上, 寬, 高, [文字...])]，群組的每一個子圖各一段文字。"""
    shapes = []

    def texts(el):
        found = []
        for box in el.iter(q("w:txbxContent")):
            parts = [clean_text(_paragraph_text(bp)) for bp in box.iter(q("w:p"))]
            text = clean_text(" ".join(x for x in parts if x))
            found.append(text)
        return found

    def walk(el):
        if el.tag == q("mc:Fallback"):
            return
        if el.tag == q("wp:anchor"):
            doc_pr = el.find(q("wp:docPr"))
            name = doc_pr.get("name") if doc_pr is not None else ""
            ext = el.find(q("wp:extent"))
            cx = int(ext.get("cx")) / 12700.0 if ext is not None else 0
            cy = int(ext.get("cy")) / 12700.0 if ext is not None else 0
            left = top = 0.0
            for axis, key in ((q("wp:positionH"), "left"), (q("wp:positionV"), "top")):
                pos = el.find(axis + "/" + q("wp:posOffset"))
                if pos is not None and pos.text:
                    if key == "left":
                        left = int(pos.text) / 12700.0
                    else:
                        top = int(pos.text) / 12700.0
            shapes.append((name, left, top, cx, cy, texts(el)))
            return
        if el.tag == q("w:pict"):
            shapes.append(("", 0, 0, 0, 0, texts(el)))
            return
        if el.tag == q("wp:inline"):
            # 內嵌的圖形（跟著文字排的流程圖、群組）：裡面有文字方塊的字就當一個圖形匯出、留記號（B27）；
            # 純圖片沒有字，照舊不算
            found = texts(el)
            if any(found):
                doc_pr = el.find(q("wp:docPr"))
                ext = el.find(q("wp:extent"))
                cx = int(ext.get("cx")) / 12700.0 if ext is not None else 0
                cy = int(ext.get("cy")) / 12700.0 if ext is not None else 0
                shapes.append((doc_pr.get("name") if doc_pr is not None else "", 0, 0, cx, cy, found))
            return
        for child in el:
            walk(child)
    walk(p)
    return shapes


class Exporter(object):
    def __init__(self, path):
        try:
            z = zipfile.ZipFile(path)
        except (OSError, zipfile.BadZipFile) as exc:
            raise ExportError("讀不出 docx：%s（%s）" % (path, exc))
        with z:
            names = set(z.namelist())
            self.doc = ET.fromstring(z.read("word/document.xml"))
            self.styles = Styles(ET.fromstring(z.read("word/styles.xml")) if "word/styles.xml" in names else None)
            self.numbering = Numbering(ET.fromstring(z.read("word/numbering.xml"))
                                       if "word/numbering.xml" in names else None)
        self.name = os.path.basename(path)
        # 新增、刪除之外，「移動」（moveFrom／moveTo）也是追蹤修訂：移出去的字還留在原處，
        # 照讀會整段出現兩次；表格的列／格增刪也算。一律停，請人接受全部修訂後另存。
        revisions = ("w:ins", "w:del", "w:moveFrom", "w:moveTo", "w:moveFromRangeStart",
                     "w:moveToRangeStart", "w:cellIns", "w:cellDel", "w:cellMerge")
        if any(True for tag in revisions for _ in self.doc.iter(q(tag))):
            raise ExportError("這份還有追蹤修訂沒接受：切條一定要用定稿乾淨版（在 Word 接受全部修訂後另存）")
        self.paras = []      # {start, style, in_tbl, lead, text, chap, sect}
        self.tables = []     # (start, tbl element)
        self.shapes = []     # (start, 名稱, 左, 上, 寬, 高, [文字])
        self.offset = 0
        self.chap = self.sect = ""

    def run(self):
        body = self.doc.find(q("w:body"))
        self._block(body, in_tbl=False)
        return self

    def _block(self, parent, in_tbl):
        for el in parent:
            if el.tag == q("w:p"):
                self._paragraph(el, in_tbl)
            elif el.tag == q("w:tbl"):
                if not in_tbl:
                    self.tables.append((self.offset, el))
                for tr in el.findall(q("w:tr")):
                    for tc in tr.findall(q("w:tc")):
                        self._block(tc, in_tbl=True)
            elif el.tag in (q("w:sdt"),):
                content = el.find(q("w:sdtContent"))
                if content is not None:
                    self._block(content, in_tbl)
            elif el.tag in (q("w:customXml"), q("w:smartTag")):
                self._block(el, in_tbl)

    def _paragraph(self, p, in_tbl):
        ppr = p.find(q("w:pPr"))
        sid = _val(ppr.find(q("w:pStyle"))) if ppr is not None else None
        sid = sid or self.styles.default
        style = self.styles.names.get(sid, sid or "")
        numpr = ppr.find(q("w:numPr")) if ppr is not None else None
        if numpr is None:
            numpr = self.styles.numbering_of(sid)
        lead = ""
        if numpr is not None:
            num_id = _val(numpr.find(q("w:numId")))
            ilvl = int(_val(numpr.find(q("w:ilvl"))) or 0)
            lead = clean_text(self.numbering.list_string(num_id, ilvl))
        raw = _paragraph_text(p)
        body = clean_text(raw)
        full = (lead + " " + body) if lead and body else (lead or body)
        start = self.offset
        for shape in _shapes_in(p):
            self.shapes.append((start,) + shape)
        if not in_tbl and not is_toc(style):
            if is_chapter(full):
                self.chap, self.sect = full, ""
            elif is_section(full):
                self.sect = full
        self.paras.append({"start": start, "style": style, "in_tbl": in_tbl, "lead": lead,
                           "text": full, "chap": self.chap, "sect": self.sect})
        self.offset += len(raw) + 1

    # -- 輸出 ---------------------------------------------------------------

    def _anchor(self, pos):
        chap = sect = ""
        for para in self.paras:
            if para["start"] < pos:
                chap, sect = para["chap"], para["sect"]
            else:
                break
        return chap, sect

    def paragraph_rows(self):
        rows, t, s = [], 0, 0

        def marker(kind, pos, text):
            chap, sect = self._anchor(pos)
            rows.append([len(rows) + 1, pos, kind, chap, sect, "", "N", "", text, len(text)])

        for para in self.paras:
            while t < len(self.tables) and self.tables[t][0] <= para["start"]:
                marker("表格標記", self.tables[t][0], "[[TABLE:%03d]]" % (t + 1))
                t += 1
            while s < len(self.shapes) and self.shapes[s][0] <= para["start"]:
                marker("圖形標記", self.shapes[s][0], "[[SHAPE:%03d]]" % (s + 1))
                s += 1
            if is_toc(para["style"]):
                kind = "目錄"
            elif para["in_tbl"]:
                kind = "表格內"
            elif is_chapter(para["text"]):
                kind = "章"
            elif is_section(para["text"]):
                kind = "節"
            else:
                kind = "內文"
            rows.append([len(rows) + 1, para["start"], kind, para["chap"], para["sect"], para["style"],
                         "Y" if para["in_tbl"] else "N", para["lead"], para["text"], len(para["text"])])
        while t < len(self.tables):
            marker("表格標記", self.tables[t][0], "[[TABLE:%03d]]" % (t + 1))
            t += 1
        while s < len(self.shapes):
            marker("圖形標記", self.shapes[s][0], "[[SHAPE:%03d]]" % (s + 1))
            s += 1
        return rows

    def shape_rows(self):
        rows = []
        for n, (pos, name, left, top, width, height, texts) in enumerate(self.shapes, 1):
            chap, sect = self._anchor(pos)
            many = len(texts) > 1
            for sub, text in enumerate(texts, 1):
                if not text:
                    continue
                rows.append(["%03d" % n, sub if many else 0, pos, chap, sect, name,
                             "%d" % left, "%d" % top, "%d" % width, "%d" % height, text, len(text)])
        return rows

    def table_markdown(self, number):
        pos, tbl = self.tables[number - 1]
        chap, sect = self._anchor(pos)
        grid, merged = [], False
        for tr in tbl.findall(q("w:tr")):
            cells = []
            for tc in tr.findall(q("w:tc")):
                tcpr = tc.find(q("w:tcPr"))
                span = int(_val(tcpr.find(q("w:gridSpan"))) or 1) if tcpr is not None and tcpr.find(q("w:gridSpan")) is not None else 1
                vmerge = tcpr.find(q("w:vMerge")) if tcpr is not None else None
                if span > 1 or vmerge is not None:
                    merged = True
                if vmerge is not None and _val(vmerge) != "restart":
                    cells.append(None)            # 被上面合併掉的格：由上方值往下填
                    continue
                parts = [clean_text(_paragraph_text(cp)) for cp in tc.iter(q("w:p"))]
                cells.append(clean_text(" ".join(x for x in parts if x)))
            grid.append(cells)
        max_c = max([len(r) for r in grid] or [0])
        non_empty = sum(1 for r in grid for c in r if c)
        total = sum(len(c) for r in grid for c in r if c)
        filled = []
        for i, row in enumerate(grid):
            # 列尾補的是橫向合併少掉的格：留空，不能拿上一列的值來填（第三批）；
            # 只有 vMerge 接續的格（None）才由上方往下填
            row = row + [""] * (max_c - len(row))
            filled.append([(c if c is not None else (filled[i - 1][k] if i else "")).replace("|", "\\|")
                           for k, c in enumerate(row)])
        tid = "T%03d" % number
        lines = ["# " + tid, "",
                 "- 來源文件：" + self.name,
                 "- 所在章：" + (chap or "（無）"),
                 "- 所在節：" + (sect or "（無）"),
                 "- 規模：%d 列 x %d 欄" % (len(grid), max_c),
                 "- 非空白格：%d   總字數：%d" % (non_empty, total),
                 "- 合併儲存格：" + ("有。空格已由上方值往下填滿。" if merged else "無"), ""]
        if not grid or not max_c:
            lines.append("（本表沒有可讀取的內容）")
        else:
            lines.append("|" + "".join(" %s |" % c for c in filled[0]))
            lines.append("|" + " --- |" * max_c)
            for row in filled[1:]:
                lines.append("|" + "".join(" %s |" % c for c in row))
        return "\r\n".join(lines) + "\r\n"


def _write_csv(path, header, rows):
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL, lineterminator="\r\n")
        w.writerow(header)
        w.writerows(rows)


def export(docx_path, folder):
    """匯出三種檔到 folder。回傳統計 dict；做不到丟 ExportError。"""
    ex = Exporter(docx_path).run()
    os.makedirs(folder, exist_ok=True)
    tdir = os.path.join(folder, "tables")
    os.makedirs(tdir, exist_ok=True)
    for old in os.listdir(tdir):
        if re.match(r"^T\d{3}\.md$", old):
            os.remove(os.path.join(tdir, old))      # 上一版留下的表格檔：張數變少會被 S2 當成多出來的表
    rows = ex.paragraph_rows()
    _write_csv(os.path.join(folder, "01_paragraphs.csv"), P_COLS, rows)
    shape_rows = ex.shape_rows()
    _write_csv(os.path.join(folder, "02_shapes.csv"), S_COLS, shape_rows)
    for n in range(1, len(ex.tables) + 1):
        with io.open(os.path.join(tdir, "T%03d.md" % n), "w", encoding="utf-8-sig", newline="") as f:
            f.write(ex.table_markdown(n))
    body = [p for p in ex.paras if not p["in_tbl"] and not is_toc(p["style"])]
    return {"章": sum(1 for p in body if is_chapter(p["text"])),
            "節": sum(1 for p in body if is_section(p["text"])),
            "表格": len(ex.tables), "圖形": len(ex.shapes), "圖形文字筆數": len(shape_rows),
            "總列數": len(rows), "自動編號段": sum(1 for p in ex.paras if p["lead"])}


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) < 2:
        print("用法：py S1P_docx匯出.py <原檔.docx> <資料夾>")
        return 1
    try:
        stats = export(argv[0], argv[1])
    except ExportError as exc:
        print("[中止] %s。這一份請改用 S1 巨集（S1_匯出全文.bas）在 Word 裡匯出。" % exc)
        return 1
    print("S1P 匯出完成（不用 Word，直接讀 docx）")
    for key in ("章", "節", "表格", "圖形", "圖形文字筆數", "總列數", "自動編號段"):
        print("  %s：%d" % (key, stats[key]))
    print("  檔案位置：%s" % os.path.abspath(argv[1]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
