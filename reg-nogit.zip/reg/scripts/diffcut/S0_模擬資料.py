# -*- coding: utf-8 -*-
r"""
S0：產生模擬的 S1 產出檔（給在家測試用）

用法：
    py S0_模擬資料.py <資料夾>

會產生：
    01_paragraphs.csv
    02_shapes.csv
    tables\T001.md ... T018.md
    _這是模擬資料.txt

重要：文字內容是假的，全部是我編的填充句。
      只有「結構」是真的，照 00_專案現況.md 的 F1 到 F24 還原：
      12 章、25 節、178 筆的章節分布、18 張表的尺寸與位置、
      兩張流程圖、括號全形半形混用、7 層階層、編號緊貼前字、
      第一到第三章走自動編號、第十一章樣式是內文、
      第四章與第十一章沒有開場白、第三章前言＝第五章前言。

拿它測程式可以。拿它當內規看不行。
"""

import csv
import os
import random
import sys

CN = "一二三四五六七八九十"

FILLER = [
    "本行辦理保險代理業務時，應依主管機關規定及本行內部規範辦理。",
    "承辦人員應確認要保人與被保險人之身分，並留存相關證明文件。",
    "各分行應指定專人負責，並將名單陳報總行備查。",
    "招攬人員應具備登錄資格，且於有效期間內始得執行業務。",
    "相關文件應保存至少五年，屆期前不得銷毀。",
    "遇有異常情形，應於知悉之日起三個營業日內通報。",
    "本行得視實際情形調整作業程序，並公告周知。",
    "前項規定於本行受託辦理之各類保險商品均適用。",
    "商品上架前應完成適合度評估，並經權責主管核准。",
    "保戶申訴案件應建檔管理，並定期彙整分析。",
    "電訪紀錄應完整保存，內容不得刪改。",
    "系統應留存操作軌跡，以供事後查核。",
    "本行應定期辦理教育訓練，並留存簽到紀錄。",
    "對於高齡客戶，應加強說明並全程錄音。",
    "違反本規範者，依本行人事管理相關規定議處。",
]


def filler(n, rng):
    """湊出大約 n 個字的填充文字。"""
    out = ""
    while len(out) < n:
        out += rng.choice(FILLER)
    return out[:n] if n > 0 else ""


def cn(n):
    if n <= 10:
        return CN[n - 1]
    if n < 20:
        return "十" + CN[n - 11]
    return CN[n // 10 - 1] + "十" + (CN[n % 10 - 1] if n % 10 else "")


# ---------------------------------------------------------------
# 章節設定
#   (章名, 節名清單, 有沒有開場白, 開場白後各範圍的第一層筆數)
#   筆數對齊 00_專案現況.md 記的 S3 實測：
#   000:1 001:4 002:10 003:25 004:16 005:33
#   006:39 007:9 008:2 009:4 010:10 011:20 012:5
# ---------------------------------------------------------------
CHAPTERS = [
    # 章名, 節名, 開場白(True/False/"空"), 章層筆數, 各節筆數
    ("保險代理業務區", [], True, 3, []),
    ("網路投保業務管理",
     ["網路投保業務定義", "網路投保作業流程", "網路投保客戶服務"], True, 1, [2, 2, 1]),
    ("業務人員管理",
     ["登錄與資格", "教育訓練", "獎懲與退場"], True, 1, [8, 7, 5]),
    ("商品管理",
     ["保險商品審查", "風險等級分類"], "空", 1, [7, 5]),
    ("商品適合度管理",
     ["客戶需求與商品適合度", "高齡客戶關懷", "錄音錄影作業", "電訪作業與管理"],
     True, 1, [8, 7, 6, 6]),
    ("招攬與進件管理",
     ["人身保險進件", "財產保險進件", "核保照會處理", "網路投保控管"],
     True, 1, [12, 9, 7, 5]),
    ("保全與理賠服務",
     ["人身保險", "財產保險"], True, 1, [3, 2]),
    ("客戶資料保護", [], False, 1, []),
    ("申訴與爭議處理", [], False, 3, []),
    ("通報與異常管理", [], False, 9, []),
    ("內部控制與稽核",
     ["自行查核", "法令遵循", "稽核作業", "缺失追蹤", "風險評估",
      "資訊安全", "外部檢查配合"], "空", 1, [2, 2, 2, 1, 2, 1, 1]),
    ("附則與表單", [], False, 4, []),
]

# 表格：(表號, 所在章序號 0=無, 所在節序號 0=無, 列, 欄, 非空格, 目標字數)
TABLES = [
    (1, 0, 0, 16, 3, 22, 1550),
    (2, 4, 1, 2, 2, 3, 258),
    (3, 4, 2, 4, 4, 16, 85),
    (4, 4, 2, 4, 2, 8, 27),
    (5, 5, 1, 7, 4, 19, 1215),
    (6, 6, 1, 2, 4, 8, 70),
    (7, 10, 0, 3, 2, 3, 46),
    (8, 10, 0, 4, 3, 12, 346),
    (9, 10, 0, 2, 3, 6, 165),
    (10, 10, 0, 5, 4, 20, 179),
    (11, 10, 0, 4, 3, 12, 370),
    (12, 10, 0, 2, 3, 6, 173),
    (13, 10, 0, 3, 4, 10, 415),
    (14, 12, 0, 20, 6, 120, 731),
    (15, 12, 0, 3, 4, 5, 152),
    (16, 12, 0, 3, 4, 5, 205),
    (17, 12, 0, 3, 4, 5, 238),
    (18, 12, 0, 3, 4, 5, 265),
]

# 兩張流程圖：(圖號, 章序號, 節序號, 名稱, 方塊文字)
SHAPES = [
    (1, 4, 1, "流程圖：商品上架審查",
     ["商品提案", "初審", "適合度評估", "權責主管核准", "系統建檔", "上架公告"]),
    (2, 10, 0, "流程圖：異常通報",
     ["發現異常", "填寫通報單", "單位主管覆核", "總行受理", "查證處理", "結案回覆"]),
]

# 第三章前言 ＝ 第五章前言，一字不差（F20）
SHARED_PREFACE = ("為使本行保險代理業務之辦理有所依循，並確保客戶權益，"
                  "特訂定本章規範，作為各單位辦理相關作業之依據。")


class Builder(object):
    def __init__(self, rng):
        self.rows = []
        self.shape_rows = []
        self.pos = 0
        self.rng = rng
        self.chap = ""
        self.sect = ""

    def add(self, kind, text, style="內文", in_tbl="N", listnum=""):
        self.pos += max(len(text), 1) + 1
        self.rows.append({
            "序號": len(self.rows) + 1,
            "位置": self.pos,
            "類型": kind,
            "所在章": self.chap,
            "所在節": self.sect,
            "樣式": style,
            "在表格內": in_tbl,
            "自動編號": listnum,
            "全文": text,
            "字數": len(text),
        })


def build():
    rng = random.Random(20260828)
    b = Builder(rng)

    chap_titles = ["第%s章 %s" % (cn(i + 1), c[0]) for i, c in enumerate(CHAPTERS)]

    # ---------- 篇名（章序號 000 的那一筆） ----------
    b.add("內文", "肆、業務管理篇　本篇規範本行保險代理業務之各項管理事項。")

    # ---------- 目錄（S3 會整批跳過） ----------
    for i, c in enumerate(CHAPTERS):
        b.add("目錄", chap_titles[i], style="目錄 1")
        for j, s in enumerate(c[1]):
            b.add("目錄", "第%s節 %s" % (cn(j + 1), s), style="目錄 2")

    # ---------- T001 導讀表：12 章清單重複三次（F16） ----------
    emit_table(b, TABLES[0], chap_titles, rng)

    # ---------- 各章 ----------
    for ci, (name, sects, preface, chap_items, sect_items) in enumerate(CHAPTERS, 1):
        b.chap = chap_titles[ci - 1]
        b.sect = ""

        # 章標題。第一到第三章走自動編號，第十一章樣式是內文（F1、F6）
        auto = "第%s章" % cn(ci) if ci <= 3 else ""
        style = "內文" if ci == 11 else "標題 1"
        b.add("章", b.chap, style=style, listnum=auto)

        # 章層開場白
        if preface is True:
            if ci in (3, 5):
                b.add("內文", SHARED_PREFACE)
            else:
                b.add("內文", filler(rng.randint(40, 90), rng))
        # preface == "空" 代表章標題底下直接接第一節（F24）

        emit_shapes_and_tables(b, ci, 0, rng)

        # 章層條文（沒有節的章，全部掛在章底下）
        # preface == "空" 的章完全不放，S3 會自己生出一筆 0 字的（F24）
        if preface != "空":
            emit_range(b, ci, 0, chap_items, rng)

        # 各節
        for si, sname in enumerate(sects, 1):
            b.sect = "第%s節 %s" % (cn(si), sname)
            b.add("節", b.sect, style="標題 2",
                  listnum=("第%s節" % cn(si)) if ci <= 3 else "")
            emit_shapes_and_tables(b, ci, si, rng)
            emit_range(b, ci, si, sect_items[si - 1], rng)
            b.sect = ""

    return b


def emit_shapes_and_tables(b, ci, si, rng):
    for t in TABLES[1:]:
        if t[1] == ci and t[2] == si:
            emit_table(b, t, None, rng)
    for s in SHAPES:
        if s[1] == ci and s[2] == si:
            b.add("圖形標記", "[[SHAPE:%03d]]" % s[0])
            for k, box in enumerate(s[4], 1):
                b.shape_rows.append(["%03d" % s[0], k, b.pos, b.chap, b.sect,
                                     s[3], 100, 100 + k * 40, 180, 36, box, len(box)])


def emit_table(b, t, chap_titles, rng):
    tid, ci, si, nrow, ncol, nfilled, nchar = t
    b.add("表格標記", "[[TABLE:%03d]]" % tid)

    cells = table_cells(t, chap_titles, rng)
    for c in cells:
        if c.strip():
            b.add("表格內", c, style="內文", in_tbl="Y")

    md = ["| " + " | ".join(cells[r * ncol:(r + 1) * ncol]) + " |"
          for r in range(nrow)]
    md.insert(1, "|" + "---|" * ncol)
    body = "\n".join(md) + "\n"
    path = os.path.join(TABLE_DIR, "T%03d.md" % tid)
    with open(path, "w", encoding="utf-8-sig", newline="\n") as f:
        f.write("# T%03d\n\n" % tid)
        f.write(body)


def table_cells(t, chap_titles, rng):
    """做出 nrow x ncol 的儲存格，非空格數與總字數盡量貼近實測。"""
    tid, ci, si, nrow, ncol, nfilled, nchar = t
    total = nrow * ncol
    cells = [""] * total

    if tid == 1:
        # 導讀表：12 章名重複三次（F16）
        seq = (chap_titles * 3)[:total]
        for i in range(total):
            cells[i] = seq[i] if i < len(seq) else ""
        return cells

    per = max(2, nchar // max(nfilled, 1))
    idx = list(range(total))
    rng.shuffle(idx)
    pick = sorted(idx[:nfilled])
    for i in pick:
        cells[i] = filler(per, rng)

    # T008 與 T011 只差通路名稱（F21）
    if tid in (8, 11):
        word = "銀行通路" if tid == 8 else "證券通路"
        for k, i in enumerate(pick):
            cells[i] = ("%s第%d項：" % (word, k + 1)) + filler(max(per - 10, 5),
                                                             random.Random(999 + k))
    return cells


# ---------------------------------------------------------------
# 條文生成
# ---------------------------------------------------------------
def sym_a(n):
    return "%s、" % cn(n)


def sym_b(n, full):
    return ("（%s）" if full else "(%s)") % cn(n)


def sym_c(n):
    return "%d、" % n


def sym_d(n, full):
    return ("（%d）" if full else "(%d)") % n


def sym_e(n):
    return "%s." % chr(64 + n)


def emit_range(b, ci, si, n_items, rng):
    """產生一個範圍（章底下或節底下）的第一層條文。"""
    if n_items <= 0:
        return

    # 哪些範圍要用到深階層，照實測（004-001、006-001 五種；005-004 等四種）
    deep5 = (ci, si) in [(4, 1), (6, 1)]
    deep4 = (ci, si) in [(5, 4), (6, 4), (7, 1)]

    for k in range(1, n_items + 1):
        # F11：有的範圍第一層直接用 1、 不用 一、
        use_c_as_top = (ci, si) in [(9, 0), (12, 0)]
        head = sym_c(k) + " " if use_c_as_top else sym_a(k) + " "

        # 特大筆，照實測字數還原
        big = None
        if (ci, si) == (5, 4) and k == 2:
            big = ("mega", 6039)
        elif (ci, si) == (6, 1) and k == 1:
            big = ("wide", 4113)
        elif (ci, si) == (6, 1) and k == 2:
            big = ("wide", 1666)
        elif (ci, si) == (6, 1) and k == 3:
            big = ("wide", 1313)
        elif (ci, si) == (6, 1) and k == 6:
            big = ("wide", 1646)

        if big:
            emit_big(b, head, big, rng)
            continue

        b.add("內文", head + filler(rng.randint(25, 70), rng), style="清單段落")

        if deep5 or deep4 or rng.random() < 0.45:
            nb = rng.randint(2, 4)
            for j in range(1, nb + 1):
                full = (j % 2 == 1)          # F12：全形半形交錯
                b.add("內文", sym_b(j, full) + filler(rng.randint(20, 55), rng),
                      style="清單段落")
                if deep5 or deep4:
                    for m in range(1, 3):
                        # F23：編號緊貼前一個字，中間沒有空白
                        b.add("內文", sym_c(m) + filler(rng.randint(15, 40), rng),
                              style="清單段落")
                        if m == 1:
                            b.add("內文", sym_d(1, m % 2 == 0) + filler(20, rng),
                                  style="清單段落")
                            b.add("內文", sym_d(2, False) + filler(18, rng),
                                  style="清單段落")
                            if deep5:
                                b.add("內文", sym_e(1) + filler(18, rng),
                                      style="清單段落")
                                b.add("內文", sym_e(2) + filler(16, rng),
                                      style="清單段落")


def emit_big(b, head, spec, rng):
    """特大筆：一個第一層底下掛一整串子項，S4 就是要來切這個。"""
    kind, target = spec
    used = 0
    b.add("內文", head + filler(60, rng), style="清單段落")
    used += len(head) + 60

    if kind == "mega":
        # 005-004-002：(一) 到 (九) 九種電訪，每種底下再掛 1. 2. 3.
        names = ["契約撤銷", "品管電訪", "高齡關懷", "投資型商品", "解約慰留",
                 "減額繳清／展期定期檢核", "保單借款", "續期繳費", "滿期給付"]
        per = max((target - used) // len(names), 60)
        for j, nm in enumerate(names, 1):
            full = (j % 2 == 1)
            b.add("內文", sym_b(j, full) + " " + nm + "電訪", style="清單段落")
            for m in range(1, 4):
                b.add("內文", sym_c(m) + filler(max(per // 3 - 10, 30), rng),
                      style="清單段落")
    else:
        # 006-001-00x：(一) 到 (十八) 一長串
        n = 18 if target > 3000 else 8
        per = max((target - used) // n, 40)
        for j in range(1, n + 1):
            full = (j % 2 == 1)
            b.add("內文", sym_b(j, full) + " " + filler(per, rng),
                  style="清單段落")


# ---------------------------------------------------------------
def write_all(folder, b):
    cols = ["序號", "位置", "類型", "所在章", "所在節",
            "樣式", "在表格內", "自動編號", "全文", "字數"]
    with open(os.path.join(folder, "01_paragraphs.csv"), "w",
              encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, quoting=csv.QUOTE_ALL)
        w.writeheader()
        w.writerows(b.rows)

    with open(os.path.join(folder, "02_shapes.csv"), "w",
              encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_ALL)
        w.writerow(["圖形編號", "子項", "錨點位置", "所在章", "所在節",
                    "圖形名稱", "左", "上", "寬", "高", "文字", "字數"])
        w.writerows(b.shape_rows)

    with open(os.path.join(folder, "_這是模擬資料.txt"), "w",
              encoding="utf-8-sig") as f:
        f.write("這個資料夾裡的檔案是 S0_模擬資料.py 產生的假資料。\n"
                "文字內容是編的，只有結構跟真的一樣。\n"
                "拿到公司的真檔案之後，把這裡整個清空再放進去。\n")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S0_模擬資料.py <資料夾>")
        sys.exit(1)

    OUT = sys.argv[1]
    TABLE_DIR = os.path.join(OUT, "tables")
    os.makedirs(TABLE_DIR, exist_ok=True)

    builder = build()
    write_all(OUT, builder)

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    n_chap = sum(1 for r in builder.rows if r["類型"] == "章")
    n_sect = sum(1 for r in builder.rows if r["類型"] == "節")
    n_body = sum(len(r["全文"]) for r in builder.rows
                 if r["類型"] not in ("目錄", "表格內"))
    print("模擬資料產生完成：" + OUT)
    print("  段落列數：%d" % len(builder.rows))
    print("  章：%d　節：%d" % (n_chap, n_sect))
    print("  表格：18　圖形文字：%d 筆" % len(builder.shape_rows))
    print("  參與切分的總字數：%d" % n_body)
