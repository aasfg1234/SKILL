# -*- coding: utf-8 -*-
r"""
S3：把 01_paragraphs.csv 切成一筆一筆的條文

用法：
    py S3_切條.py <資料夾>

輸入：<資料夾>\01_paragraphs.csv
      <資料夾>\02_shapes.csv      （附件文字用）
      <資料夾>\tables\Tnnn.md     （附件文字用）
輸出：<資料夾>\03_items.csv
      <資料夾>\S3_切條報告.txt

2026-08-28 依法遵稽核改了三件事：
  一、每一筆帶「起始序號」「結束序號」，回得去原檔（F26）
  二、章前言獨立成一筆，不再跟第一條黏在一起，跟 S4 的規則對齊（F27）
  三、表格與流程圖的內容放進「附件全文」欄，不再只有一個記號（F25）
      排在第一個編號之前的記號，各自獨立成一筆，不再整批擠到第一條（F28）

無損驗證比對的是「全文」欄，附件全文不參與，所以驗證邏輯不變。
"""

import csv
import os
import re
import sys

CN_MAP = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5,
          "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}

KEEP = ("章", "節", "內文", "表格標記", "圖形標記")

OUT_COLS = ["條文ID", "章序號", "章標題", "節序號", "節標題",
            "符號類型", "符號原文", "本範圍層級", "附屬於",
            "起始序號", "結束序號",
            "全文", "字數", "含表格標記", "含圖形標記",
            "附件全文", "附件字數"]

lines = []


def say(s=""):
    lines.append(s)


def cn2int(s):
    s = s.strip()
    if not s:
        return None
    if "十" in s:
        left, _, right = s.partition("十")
        n = (CN_MAP.get(left, 1) if left else 1) * 10
        if right:
            n += CN_MAP.get(right, 0)
        return n
    if s.isdigit():
        return int(s)
    return CN_MAP.get(s)


# ------------------------------------------------------------------
# 符號辨識。括號類要先判，不然 (一) 會被當成 A
# ------------------------------------------------------------------
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _heading import ARTICLE_RE   # noqa: E402

PATTERNS = [
    # F：條文式編排的「第一條」「第五條之一」（A8）。放最前面：條一定是最上層
    ("F", ARTICLE_RE),
    ("B", re.compile(r"^[（(]\s*([一二三四五六七八九十]{1,3})\s*[）)]")),
    ("D", re.compile(r"^[（(]\s*(\d{1,3})\s*[）)]")),
    ("A", re.compile(r"^([一二三四五六七八九十]{1,3})\s*[、，,]")),
    ("C", re.compile(r"^(\d{1,3})\s*(?:、|[.．](?![0-9０-９]))")),   # 1.5% 的點是小數點
    ("E", re.compile(r"^([A-Za-z])\s*[.．]")),
]


def detect(text, listnum):
    """回傳 (符號類型, 符號原文)。先看自動編號欄，再看全文開頭。"""
    for src in (listnum, text):
        if not src:
            continue
        for kind, pat in PATTERNS:
            m = pat.match(src)
            if m:
                return kind, m.group(0).strip()
    return "無符號", ""


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _heading import number_of   # noqa: E402  第壹章、第2章、第十一章都認得（A9）


def chap_no(title):
    return number_of(title, "章") or 0


def sect_no(title):
    return number_of(title, "節") or 0


# ------------------------------------------------------------------
def load_attachments(folder):
    """把表格與流程圖的文字讀進來，之後掛到條文的附件欄。"""
    att = {}

    tdir = os.path.join(folder, "tables")
    if os.path.isdir(tdir):
        for f in sorted(os.listdir(tdir)):
            m = re.match(r"^T(\d{3})\.md$", f, re.I)
            if not m:
                continue
            with open(os.path.join(tdir, f), "r", encoding="utf-8-sig") as fh:
                att["TABLE:" + m.group(1)] = fh.read().strip()

    spath = os.path.join(folder, "02_shapes.csv")
    if os.path.isfile(spath):
        buf = {}
        with open(spath, "r", encoding="utf-8-sig", newline="") as fh:
            for r in csv.DictReader(fh):
                key = "SHAPE:" + r["圖形編號"]
                buf.setdefault(key, [r["圖形名稱"], []])
                buf[key][1].append(r["文字"])
        for k, (name, boxes) in buf.items():
            att[k] = name + "\n" + "\n".join(boxes)

    return att


# ------------------------------------------------------------------
class Item(object):
    def __init__(self, ci, ct, si, st, kind, raw, level):
        self.ci, self.ct, self.si, self.st = ci, ct, si, st
        self.kind, self.raw, self.level = kind, raw, level
        self.parts = []
        self.srcs = []
        self.seq = 0
        self.attach = ""        # 表格、圖形掛在哪一條後面

    def take(self, row):
        self.parts.append(row["全文"])
        self.srcs.append(int(row["序號"]))

    @property
    def text(self):
        return "".join(self.parts)

    def row(self, att):
        t = self.text
        tabs = re.findall(r"\[\[TABLE:(\d{3})\]\]", t)
        shps = re.findall(r"\[\[SHAPE:(\d{3})\]\]", t)
        chunks = []
        for n in tabs:
            chunks.append("[[TABLE:%s]]\n%s" % (n, att.get("TABLE:" + n, "（找不到表格檔）")))
        for n in shps:
            chunks.append("[[SHAPE:%s]]\n%s" % (n, att.get("SHAPE:" + n, "（找不到圖形文字）")))
        body = "\n\n".join(chunks)
        return {
            "條文ID": "%03d-%03d-%03d" % (self.ci, self.si, self.seq),
            "章序號": "%03d" % self.ci,
            "章標題": self.ct,
            "節序號": "%03d" % self.si,
            "節標題": self.st,
            "符號類型": self.kind,
            "符號原文": self.raw,
            "本範圍層級": self.level,
            "附屬於": self.attach,
            "起始序號": min(self.srcs) if self.srcs else "",
            "結束序號": max(self.srcs) if self.srcs else "",
            "全文": t,
            "字數": len(t),
            "含表格標記": ";".join(tabs),
            "含圖形標記": ";".join(shps),
            "附件全文": body,
            "附件字數": len(body),
        }


def split_ranges(rows):
    """把參與切分的列，依「章 / 節」切成一段一段的範圍。"""
    ranges = []
    ci, ct, si, st = 0, "", 0, ""
    cur = []
    state = {"章層已出": True}

    def flush():
        if cur:
            if si == 0:
                state["章層已出"] = True
            ranges.append((ci, ct, si, st, "內容", list(cur)))
            del cur[:]

    for r in rows:
        if r["類型"] == "章":
            flush()
            ct = r["全文"]
            ci = chap_no(ct)
            si, st = 0, ""
            state["章層已出"] = False
            ranges.append((ci, ct, 0, "", "章", [r]))
        elif r["類型"] == "節":
            flush()
            # 章標題底下沒有開場白，直接接第一節：補一筆空的章層（F24）
            if not state["章層已出"]:
                ranges.append((ci, ct, 0, "", "內容", []))
                state["章層已出"] = True
            st = r["全文"]
            si = sect_no(st)
            ranges.append((ci, ct, si, st, "節", [r]))
        else:
            cur.append(r)
    flush()
    return ranges


def build_items(ranges, range_syms=None):
    items = []
    if range_syms is None:
        range_syms = {}

    for ci, ct, si, st, rtype, rows in ranges:

        # 章、節：自己獨立一筆，序號 000
        if rtype in ("章", "節"):
            it = Item(ci, ct, si, st, "無符號", "", 0)
            it.take(rows[0])
            it.seq = 0
            items.append(it)
            continue

        # 先掃這個範圍用了哪些符號，決定各是第幾層
        order = []
        marks = []
        for r in rows:
            if r["類型"] in ("表格標記", "圖形標記"):
                marks.append(("記號", ""))
                continue
            kind, raw = detect(r["全文"], r["自動編號"])
            marks.append((kind, raw))
            if kind != "無符號" and kind not in order:
                order.append(kind)
        level_of = dict((k, i + 1) for i, k in enumerate(order))
        top = order[0] if order else None
        key = "%03d-%03d" % (ci, si)
        range_syms.setdefault(key, [])
        for k in order:
            if k not in range_syms[key]:
                range_syms[key].append(k)

        made = []
        seq = 0
        cur = None          # 目前開著的第一層條文
        pre = None          # 第一個切點之前的前言

        for r, (kind, raw) in zip(rows, marks):

            # 表格、流程圖記號：一律自己獨立成一筆（F28、F37）
            # 一筆只掛一張表，改表時才找得到是哪一條的哪一張
            if kind == "記號":
                seq += 1
                it = Item(ci, ct, si, st,
                          "表格" if r["類型"] == "表格標記" else "圖形", "", 0)
                it.seq = seq
                host = None
                for m in reversed(made):
                    if m.kind not in ("表格", "圖形"):
                        host = m
                        break
                it.attach = ("%03d-%03d-%03d" % (ci, si, host.seq)
                             if host else "")
                it.take(r)
                made.append(it)
                cur = None          # 記號之後的文字另起一筆，維持前後順序
                pre = None
                continue

            is_cut = (kind == top and top is not None)

            if is_cut:
                seq += 1
                cur = Item(ci, ct, si, st, kind, raw, level_of[kind])
                cur.seq = seq
                cur.take(r)
                made.append(cur)
                pre = None
            elif cur is None:
                # 還沒切過任何一刀 -> 前言（F27）
                # 已經切過 -> 接續，是被表格打斷的下半段
                if pre is None:
                    seq += 1
                    cut_before = any(m.kind in ("F", "A", "B", "C", "D", "E")
                                     for m in made)
                    pre = Item(ci, ct, si, st,
                               "接續" if cut_before else "前言", "", 0)
                    pre.seq = seq
                    if cut_before and made:
                        pre.attach = "%03d-%03d-%03d" % (ci, si, made[-1].seq)
                    made.append(pre)
                pre.take(r)
            else:
                cur.take(r)

        if not made:
            # 整個範圍什麼都沒有：留一筆空的（F24）
            it = Item(ci, ct, si, st, "無符號", "", 0)
            it.seq = 1
            made.append(it)

        items.extend(made)

    return items, range_syms


def main(folder):
    src = os.path.join(folder, "01_paragraphs.csv")
    if not os.path.isfile(src):
        say("找不到 " + src)
        return None, False, None

    with open(src, "r", encoding="utf-8-sig", newline="") as f:
        allrows = list(csv.DictReader(f))

    rows = [r for r in allrows if r["類型"] in KEEP]
    att = load_attachments(folder)

    say("=" * 60)
    say("S3 切條報告")
    say("資料夾：" + folder)
    say("=" * 60)
    say()
    say("輸入列數：%d" % len(allrows))
    say("參與切分：%d（跳過目錄與表格內 %d 列）"
        % (len(rows), len(allrows) - len(rows)))
    say("讀到附件：%d 個（表格 %d、圖形 %d）"
        % (len(att),
           sum(1 for k in att if k.startswith("TABLE")),
           sum(1 for k in att if k.startswith("SHAPE"))))

    items, range_syms = build_items(split_ranges(rows))

    # ---------- 無損驗證 ----------
    src_txt = "".join(r["全文"] for r in rows)
    out_txt = "".join(i.text for i in items)
    passed = (src_txt == out_txt)

    say()
    say("1. 無損驗證：" + ("過" if passed else "沒過"))
    if not passed:
        n = min(len(src_txt), len(out_txt))
        at = next((i for i in range(n) if src_txt[i] != out_txt[i]), n)
        say("   第一個不一致在第 %d 個字元" % (at + 1))
        say("   原文：" + src_txt[max(0, at - 50):at + 50])
        say("   切後：" + out_txt[max(0, at - 50):at + 50])
        say("   長度：原文 %d，切後 %d" % (len(src_txt), len(out_txt)))
        return items, False, att

    # ---------- 序號連續性（新增，回得去原檔才算數）----------
    say()
    covered = []
    for it in items:
        covered.extend(it.srcs)
    want = [int(r["序號"]) for r in rows]
    say("2. 來源對照：原始 %d 列，被 %d 筆條文認領 %d 列"
        % (len(want), len(items), len(covered)))
    if sorted(covered) != sorted(want):
        say("   [不合格] 有原始列沒有被任何一筆認領，或被認領兩次")
        return items, False, att
    say("   每一列剛好被認領一次")

    # ---------- 統計 ----------
    say()
    say("3. 切出幾筆：%d" % len(items))
    kinds = {}
    for it in items:
        kinds[it.kind] = kinds.get(it.kind, 0) + 1
    say("   " + "　".join("%s %d" % (k, v) for k, v in sorted(kinds.items())))

    say()
    say("4. 各章筆數")
    per = {}
    for it in items:
        per["%03d" % it.ci] = per.get("%03d" % it.ci, 0) + 1
    say("   " + "  ".join("%s:%d" % (k, per[k]) for k in sorted(per)))

    say()
    say("5. 各範圍用了哪幾種符號（最特殊的五個）")
    rng = dict((k, set(v)) for k, v in range_syms.items() if v)
    order = sorted(rng.items(), key=lambda kv: (-len(kv[1]), kv[0]))
    for key, ks in order[:5]:
        title = next((i.st or i.ct for i in items
                      if "%03d-%03d" % (i.ci, i.si) == key), "")
        say("   %s  %-22s %d 種  %s"
            % (key, title[:22], len(ks), ";".join(sorted(ks))))

    say()
    say("6. 附件掛載")
    rowdicts = [it.row(att) for it in items]
    tab_items = [r for r in rowdicts if r["含表格標記"]]
    shp_items = [r for r in rowdicts if r["含圖形標記"]]
    all_t = set()
    for r in tab_items:
        all_t.update(r["含表格標記"].split(";"))
    say("   帶表格的條文 %d 筆，涵蓋 %d 張表" % (len(tab_items), len(all_t)))
    say("   帶流程圖的條文 %d 筆" % len(shp_items))
    say("   附件文字合計 %d 字" % sum(r["附件字數"] for r in rowdicts))
    miss = [r["條文ID"] for r in rowdicts
            if (r["含表格標記"] or r["含圖形標記"]) and "找不到" in r["附件全文"]]
    if miss:
        say("   [注意] 有 %d 筆掛了記號卻讀不到附件內容：%s"
            % (len(miss), "、".join(miss[:5])))
    else:
        say("   每個記號都讀得到對應的附件內容")

    say()
    say("7. 字數最長的五筆")
    for r in sorted(rowdicts, key=lambda x: -x["字數"])[:5]:
        say("   %s  %d 字" % (r["條文ID"], r["字數"]))

    say()
    long_items = [r for r in rowdicts if r["字數"] > 1000]
    say("8. 超過 1000 字的有 %d 筆，這些是 S4 要處理的" % len(long_items))
    for r in long_items:
        say("   %s  %d 字" % (r["條文ID"], r["字數"]))

    return items, True, att


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S3_切條.py <資料夾>")
        sys.exit(1)

    target = sys.argv[1]
    result, ok, att = main(target)

    if ok:
        out = os.path.join(target, "03_items.csv")
        with open(out, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=OUT_COLS, quoting=csv.QUOTE_ALL)
            w.writeheader()
            for it in result:
                w.writerow(it.row(att))
        say()
        say("=" * 60)
        say("結論：S3 過。已寫出 03_items.csv")
        say("=" * 60)
    else:
        say()
        say("=" * 60)
        say("結論：驗證沒過，沒有寫出 03_items.csv")
        say("=" * 60)

    report = "\n".join(lines)
    with open(os.path.join(target, "S3_切條報告.txt"), "w",
              encoding="utf-8-sig") as f:
        f.write(report + "\n")

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if ok else 1)
