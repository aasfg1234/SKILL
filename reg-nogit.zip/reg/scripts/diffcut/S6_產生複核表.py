# -*- coding: utf-8 -*-
r"""
S6 第一步：產生人工複核表

用法：
    py S6_產生複核表.py <資料夾> [輸出檔]

輸入：<資料夾>\05_flagged.csv
輸出：<資料夾>\06_複核表.csv    （或你指定的路徑）
      <資料夾>\06_複核表_怎麼填.txt

只挑「需人工看」是 Y 的那些出來，不用你在幾百筆裡面翻。
第一欄就是「決定」，空白的，用 Excel 打開直接填。

填完之後跑第二步：
    py S6_套用決定.py <資料夾> <你填好的複核表>
"""

import csv
import io
import os
import sys

OUT_COLS = ["決定", "條文ID", "旗標", "系統建議", "字數",
            "章標題", "節標題", "符號原文", "全文",
            "重複組", "附屬於", "含表格標記", "起始序號", "結束序號",
            "附件全文"]

HOWTO = """怎麼填這張複核表

一、用 Excel 打開 06_複核表.csv

二、只要填「決定」那一欄（A 欄）。其他欄不要動。
    尤其不要改「全文」，改了程式會擋下來。

三、「決定」只能填這四個字之一：

    保留        原樣留著。看過覺得沒問題就填這個
    刪除        這一筆不要了。會另存到 06_deleted.csv 備查，不會消失
    併入上一筆   這一筆的文字併進前一條
    待改        先留著，標記起來下一輪處理

    每一列都必須明確填寫；留空白會擋下來，不會視為已複核。
    不可以另外做一張只列「刪除」項目的精簡表；漏列任何需複核條文也會擋下來。

四、沒有列在這張表裡的條文，一律當作「保留」。
    這張表只列出系統覺得要人看一眼的那些。

五、旗標的意思

    空白        這一筆 0 個字
    過短        不到 10 個字
    完全重複    有另一筆文字一模一樣
    開頭相同    跟另一筆的開頭 30 字以上一字不差
    符號跳號    同一層的編號不連續
    含表格圖形  這一條夾了表格或流程圖，改條文時那張表要一起看

六、填完存檔。存檔類型選「CSV UTF-8」。
    不要存成 Excel 活頁簿(.xlsx)。

七、把檔案路徑給我，或自己跑：
    py S6_套用決定.py <資料夾> <你填好的檔>

八、通過後會多產生 S6_複核證明.json，記錄本輪底本、決定檔與輸出的
    SHA-256。沒有這份證明，後面不能發布正式版。
"""


def main(folder, out_path):
    src = os.path.join(folder, "05_flagged.csv")
    if not os.path.isfile(src):
        print("找不到 " + src)
        return False

    with io.open(src, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    need = [r for r in rows if r["需人工看"] == "Y"]

    # 先排空白與過短，那些最好判；重複類放後面，要對照兩筆
    order = {"空白": 0, "過短": 1, "符號跳號": 2,
             "完全重複": 3, "開頭相同": 4, "含表格圖形": 5}

    def key(r):
        fl = [f for f in r["旗標"].split(";") if f]
        return (min([order.get(f, 9) for f in fl] or [9]), r["條文ID"])

    need.sort(key=key)

    with io.open(out_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=OUT_COLS, quoting=csv.QUOTE_ALL)
        w.writeheader()
        for r in need:
            w.writerow({
                "決定": "",
                "條文ID": r["條文ID"],
                "旗標": r["旗標"],
                "系統建議": r["建議動作"],
                "字數": r["字數"],
                "章標題": r["章標題"],
                "節標題": r["節標題"],
                "符號原文": r["符號原文"],
                "全文": r["全文"],
                "重複組": r["重複組"],
                "附屬於": r.get("附屬於", ""),
                "含表格標記": r["含表格標記"],
                "起始序號": r["起始序號"],
                "結束序號": r["結束序號"],
                "附件全文": r.get("附件全文", "")[:300],
            })

    with io.open(os.path.join(folder, "06_複核表_怎麼填.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(HOWTO)

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("複核表產生完成")
    print("  全部條文：%d 筆" % len(rows))
    print("  要你看的：%d 筆（%.1f%%）" % (len(need), 100.0 * len(need) / len(rows)))
    print("  檔案：%s" % out_path)
    print()
    print("  依旗標分：")
    tally = {}
    for r in need:
        for fl in r["旗標"].split(";"):
            if fl:
                tally[fl] = tally.get(fl, 0) + 1
    for k in sorted(tally, key=lambda x: -tally[x]):
        print("     %-10s %d 筆" % (k, tally[k]))
    print()
    print("  填法說明：%s" % os.path.join(folder, "06_複核表_怎麼填.txt"))
    return True


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S6_產生複核表.py <資料夾> [輸出檔]")
        sys.exit(1)
    folder = sys.argv[1]
    out = (sys.argv[2] if len(sys.argv) > 2
           else os.path.join(folder, "06_複核表.csv"))
    sys.exit(0 if main(folder, out) else 1)
