# -*- coding: utf-8 -*-
"""
終比對驗收：三個問題。三個都是零才算改好。

一、填了「改」或「刪除」的，定稿裡真的改了嗎？
二、初比對的候選，還有沒填決定的嗎？（空白＝還沒決定；「不改」算已決定）
三、定稿冒出初比對沒列過的新候選嗎？

另外報一行（不擋結論）：
四、填了「改」但「改成什麼」跟原文一字不差的有幾列？那是人自己選的不改，
    定稿上不會有修訂記號；不講的話人會以為那幾列真的改過了。
"""

import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

REGDIFF = os.path.join(HERE, "regdiff")
if REGDIFF not in sys.path:
    sys.path.insert(0, REGDIFF)

import apply_changes as ac
import decision_table as dt
import notices as nt


# AI 查不到答案、人還沒在 填寫表單/人工確認.csv 回覆的項目：異動本身、條文檢查高風險、
# 外部引用無法查證（見 review_import.pending_confirmations）。沒跑 AI 審查就一定是空的。
CONFIRM_KEY = "人工待確認"
# 會擋「改好」的鍵：三問，加上人工待確認。
# 「等於原文」不在裡面：它不是「還有事沒做完」，不能擋「改好」。
BLOCKING_KEYS = ("未改到", "未決定", "新候選", CONFIRM_KEY)
SAME_TEXT_KEY = "等於原文"
# 草稿有、決定表沒叫改也沒叫刪，乾淨版卻對不上的段落。不進三問（人在 Word 裡手改
# 條文是允許的流程），但一定要發警告：乾淨版整張表消失時，這是唯一說得出來的地方。
VANISHED_KEY = "意外消失"
# 第三問的新候選接進決定表幾列、草稿裡找不到幾列（報告第三問底下各說一句）
APPENDED_KEY = "新候選接進決定表"
UNPLACED_KEY = "新候選找不到段"


clip = ac._clip


def blocking_total(answers):
    """會擋住「改好」的總數。只算三問，不算「等於原文」——那是人自己決定的不改。"""
    return sum(len(answers.get(key) or []) for key in BLOCKING_KEYS)


def _row_line(row, total):
    """這一列的候選段次（0 起算），不是 1..total 之間的整數就回 None。"""
    line = (row.get("候選段次") or "").strip()
    if line.isdigit() and 1 <= int(line) <= total:
        return int(line) - 1
    return None


def _is_same_text(row, draft_paragraphs=None):
    """填了「改」但「改成什麼」跟原文一字不差（第四問）。跟 apply 同一把尺、同一個順序。

    apply 是先確認段次找得到、草稿那一段就是「候選全文」，都過了才判「新舊文字相同」；
    段次找不到或草稿那一段對不上，apply 記的是「跳過（找不到段）」「跳過（原文不符）」
    ——程式做不到、要擋，apply 還明講「finalize 會把它們算成未改到」。以前這裡只比
    「改成什麼」跟表上的「候選全文」，那種列在 finalize 變成「等於原文（視為不改，不擋）」，
    同一列兩支程式講相反的話。有草稿時照 apply 的順序判；對不上的交給第一問。
    沒有草稿（找不到草稿留底）就只能比表上的字。
    """
    if row["要改嗎"] != "改" or not ac.same_after_normalize(row["候選全文"], row["改成什麼"]):
        return False
    if draft_paragraphs is None:
        return True
    line = _row_line(row, len(draft_paragraphs))
    if line is None:
        return False          # apply：跳過（找不到段）
    # apply：跳過（原文不符）。比法跟 apply 一樣：兩邊收斂換行、去頭尾空白
    return (dt.normalize_newlines(draft_paragraphs[line] or "").strip()
            == dt.normalize_newlines(row["候選全文"] or "").strip())


def positional_check(decision_rows, draft_paragraphs, clean_paragraphs):
    """第一問的對位版：每一列只看「候選段次那一段」在乾淨版裡變成什麼。

    舊判法是「改成什麼」在乾淨版**全文**裡找不找得到：「改成什麼」的字別處剛好已經有
    （內規大量重複條文，這正是連帶候選會出現的原因），那一列一個字都沒改也會被放行。

    做法：草稿照決定表改完，算出乾淨版「應該長成的樣子」，跟真正的乾淨版逐段對齊
    （difflib，逐段比、不是逐字）。每一列兩件事都要成立：
        新的在    改：那一段在對齊結果裡落在「相同」區塊；不在的話，乾淨版對不上的段落裡
                  要有一段就是「改成什麼」（人在 Word 裡把條文搬到別處，是允許的）
        舊的不在  草稿那一段原本的字，在乾淨版裡出現的次數不能比應有的多——
                  光看「新的在」會被旁邊剛好同字的一段、或人打了新條文卻沒刪舊條文騙過
        刪除：原本的位置上不能還有它，次數也不能比應有的多
    只差空白的改動（dt.normalize 看不出差別）另外拿原字比，跟 apply 判「有沒有改」同一把尺。
    人在 Word 裡自己新增的條文在對齊結果裡是「插入」，不會打亂其他段；
    第三問會另外把它們撈出來。

    回傳 (未改到的列, 定位不到而退回全文比對的列, 意外消失的段落)。
    定位不到：段次空白或超出範圍，或同一段次已經有別列（人在 Excel 裡複製出來的列）。
    意外消失：草稿有、決定表沒叫改也沒叫刪，乾淨版卻對不上的段落（掉段或被手改）。
    """
    import collections
    import difflib

    total = len(draft_paragraphs)
    by_line = {}
    loose = []
    for row in decision_rows:
        if row["要改嗎"] not in ("改", "刪除") or _is_same_text(row, draft_paragraphs):
            continue
        line = _row_line(row, total)
        if line is None or line in by_line:
            loose.append(row)
        else:
            by_line[line] = row

    expected, where = [], {}
    for index, text in enumerate(draft_paragraphs):
        row = by_line.get(index)
        if row is None:
            expected.append(text)
        elif row["要改嗎"] == "改":
            where[id(row)] = ("at", len(expected), index)
            expected.append(row["改成什麼"])
        else:
            where[id(row)] = ("gap", len(expected), index)

    want = [dt.normalize(t) for t in expected]
    have = [dt.normalize(t) for t in clean_paragraphs]
    ops = difflib.SequenceMatcher(None, want, have, autojunk=False).get_opcodes()
    match_of = {}                          # 應有樣子的第幾段 → 乾淨版的第幾段（相同區塊）
    spare = collections.Counter()          # 乾淨版裡對不上的段落
    for tag, i1, i2, j1, j2 in ops:
        if tag == "equal":
            match_of.update((i1 + k, j1 + k) for k in range(i2 - i1))
        else:
            spare.update(have[j1:j2])
    want_count = collections.Counter(want)
    have_count = collections.Counter(have)

    not_done = []
    for row in decision_rows:
        spot = where.get(id(row))
        if spot is None:
            continue
        kind, at, index = spot
        # 草稿那一段真正的字（不是表上的字：原文不符時 apply 跳過，留在乾淨版裡的是草稿的字）
        old = dt.normalize(draft_paragraphs[index])
        whitespace_only = kind == "at" and old == want[at]
        old_left = not whitespace_only and have_count[old] > want_count[old]
        if kind == "at":
            j = match_of.get(at)
            if j is not None:
                placed = (not whitespace_only
                          or ac.same_after_normalize(clean_paragraphs[j], row["改成什麼"]))
            elif spare[want[at]] > 0:
                spare[want[at]] -= 1       # 條文在 Word 裡被搬到別處
                placed = True
            else:
                placed = False
            if not placed or old_left:
                not_done.append(row)
            continue
        still_here = any(tag != "equal" and i1 <= at <= i2 and old in have[j1:j2]
                         for tag, i1, i2, j1, j2 in ops)
        if still_here or old_left:
            not_done.append(row)

    # 定位不到的列交給全文比對判；它們原本那一段在乾淨版裡對不上，是決定表叫改的，不算意外
    excused = collections.Counter(dt.normalize(row["候選全文"]) for row in loose)
    decided = {spot[1] for spot in where.values() if spot[0] == "at"}
    vanished = []
    for i in range(len(expected)):
        if i in match_of or i in decided:
            continue
        if excused[want[i]] > 0:
            excused[want[i]] -= 1
            continue
        vanished.append(expected[i])
    return not_done, loose, vanished


def missing_rows(decision_rows, sidecar):
    """指紋檔記過、決定表上卻沒有的列（人把列刪掉了）。

    第二問只數表上「要改嗎」留空的列；整列刪掉的候選根本不在表上，一列都數不到，
    三問全零、結論「改好」——等於一個候選都沒看就放行。
    列與指紋怎麼對一律走 dt.match_sidecar（跟 review-import 驗原文同一套）：
    人補了或改了段次（apply 的「找不到段」就是叫人這樣做）照樣對得上，不會被當成刪列；
    候選全文被手改過也還是同一列，那是 review-import／apply 的事。
    """
    entries = sidecar.get("列", [])
    _, unused = dt.match_sidecar(decision_rows, entries)
    missing = []
    for k in unused:
        line = entries[k].get("候選段次") or 0
        sha = entries[k].get("候選全文SHA256") or ""
        missing.append({"候選段次": str(line) if line else "", "來源": "指紋檔",
                        "要改嗎": "", "改成什麼": "",
                        "候選全文": "（決定表上沒有這一列：指紋 %s… 表上被刪掉了）" % sha[:8]})
    return missing


def three_questions(decision_rows, sidecar, clean_paragraphs, final_rows,
                    draft_paragraphs=None):
    """三問（加第四問那一行）。

    draft_paragraphs：決定表對應的那份草稿的段落（段次的座標系）。有給就走對位判斷
    （positional_check），定位不到的列才退回全文比對；沒給（找不到草稿留底）就整張表
    退回全文比對，並在回傳值的「對位」記 False，呼叫端要發警告——全文比對擋不住
    「改成什麼」別處剛好已有的那一列。
    """
    # 填了「改」，但填的字跟原文一字不差。定稿上不會有任何修訂記號，
    # 定稿裡也「找得到」這段字，所以它不是「未改到」；但也不能默不作聲，
    # 不然人會以為這一列真的改過了。單獨列一行，不擋「改好」。
    #
    # 判定一定要用 apply 那一支（same_after_normalize），不可以自己用
    # dt.normalize 再判一次：dt.normalize 會把所有空白殺光，
    # 「改成什麼」只比原文多一個半形空格時，apply 真的寫了一處修訂、
    # 回報「已套用」，這裡卻會說「填了但等於原文（視為不改）」——
    # 同一列，兩支程式講相反的話，而人只會看到後面這一句。
    same_text = [row for row in decision_rows if _is_same_text(row, draft_paragraphs)]
    positional = draft_paragraphs is not None
    vanished = []
    if positional:
        not_done, fallback, vanished = positional_check(decision_rows, draft_paragraphs,
                                                        clean_paragraphs)
    else:
        not_done = []
        fallback = [row for row in decision_rows
                    if row["要改嗎"] in ("改", "刪除") and not _is_same_text(row)]
    import collections
    clean = {dt.normalize(p) for p in clean_paragraphs}
    clean_count = collections.Counter(dt.normalize(p) for p in clean_paragraphs)
    draft_count = collections.Counter(dt.normalize(p) for p in (draft_paragraphs or []))
    for row in fallback:
        old = dt.normalize(row["候選全文"])
        if positional and clean_count[old] >= draft_count[old] and draft_count[old]:
            # 定位不到的列（段次空白、超出範圍、兩列同一段次）：只看「新字找不找得到」
            # 會被平行條文騙過——別的條文本來就有同樣的字（A5）。有草稿時再加一個條件：
            # 原文在乾淨版出現的次數要比草稿少（真的有一段被改掉或刪掉）
            not_done.append(row)
        elif row["要改嗎"] == "改" and dt.normalize(row["改成什麼"]) not in clean:
            not_done.append(row)
        elif row["要改嗎"] == "刪除" and old in clean and not positional:
            not_done.append(row)
    undecided = [row for row in decision_rows if row["要改嗎"] == ""]
    undecided += missing_rows(decision_rows, sidecar)
    return {"未改到": not_done, "未決定": undecided,
            "新候選": fresh_rows(decision_rows, sidecar, final_rows),
            SAME_TEXT_KEY: same_text, VANISHED_KEY: vanished, "對位": positional}


def fresh_rows(decision_rows, sidecar, rows):
    """rows 裡哪幾列是「初比對沒列過」的新候選。

    抽成獨立一支，是因為第三問不是只有 three_questions 要問：batch-finalize 拿各本
    定稿重算跨本連帶之後，那批跨本列也要用**同一把尺**篩過才能併進第三問。
    兩邊各寫一次 known 集合，遲早會漂開成「同一列在單本報告算新候選、在批次不算」。

    known 的三個來源：
    - sidecar「列」：初比對決定表列過的候選（人看過的）。
    - sidecar「異動段落SHA256」：初比對那一輪的異動段落本文，本來就會在定稿裡。
    - 決定表填「改」的「改成什麼」：那是人指定定稿要長成的樣子，定稿冒出來不算新的。
    """
    known = {entry["候選全文SHA256"] for entry in sidecar.get("列", [])}
    known |= set(sidecar.get("異動段落SHA256", []))
    known |= {dt.text_sha256(row["改成什麼"]) for row in decision_rows if row["要改嗎"] == "改"}
    return [row for row in rows if dt.text_sha256(row["候選全文"]) not in known]


WARNING_KIND = "警告"


def warning_key(entry):
    """一則警告的指紋（人工確認表「警告」列用它對回上一次的回覆）。"""
    return "%s:%s" % (WARNING_KIND, dt.text_sha256("%s\n%s" % (entry.get("來源") or "", entry.get("文字") or "")))


def unacknowledged(notices, acknowledged=None):
    """這一輪的警告裡，人還沒在人工確認表回覆看過的那幾則。"""
    done = acknowledged or set()
    return [w for w in nt.warnings(notices) if warning_key(w) not in done]


def verdict(total, notices=None, acknowledged=None):
    """驗收結論那一行。畫面與報告檔共用同一支，兩邊不能各講各的。

    三問皆零但這一輪有警告（定稿仍含追蹤修訂、條號整批位移……）時不准只寫「改好」：
    那三個問題問的是「決定表上的事做完了沒」，警告講的是「這份檔案本身有狀況」，
    是兩回事。只寫「改好」會讓人直接送出一份還帶著追蹤修訂的定稿。
    但警告要有結案的路：這種警告每一次驗收都會再發（條號位移是這次修法本身造成的），
    以前結論永遠停在這一句，人工待辦也永遠停在「驗收沒過」。現在警告寫進人工確認表
    （類別「警告」），人回覆看過（acknowledged），結論就是改好，並註明幾則是看過的。
    """
    if total:
        return ("結論：還有 %d 處要看，請勿送出。回到連帶決定表補決定或補改"
                "（AI 查不到的到 填寫表單/人工確認.csv 填「人工確認」），再跑一次。" % total)
    alerts = unacknowledged(notices, acknowledged)
    if alerts:
        return ("結論：三問皆零，但有 %d 則警告還沒人看過（例：%s）：看完提醒段，到 填寫表單/人工確認.csv "
                "類別「警告」那幾列回覆「已確認」，再跑一次驗收。" % (len(alerts), _headline(alerts[0])))
    seen = len(nt.warnings(notices))
    return "結論：改好。三個問題都是零%s。最終仍需人工複核後才能送出。" % (
        "（%d 則警告已人工確認）" % seen if seen else "")


def _headline(entry, limit=18):
    """警告本文取前一小段當例子，長的用刪節號收尾。"""
    text = (entry.get("文字") or "").split("：")[0].split("（")[0].strip()
    return text if len(text) <= limit else text[:limit] + "…"


def write_report(answers, path, notices=None, acknowledged=None):
    """寫終比對驗收報告。notices 是這次終比對累積的提醒，附在結論後面。

    為什麼提醒要進這一份：這是「可不可以送出」的那張紙。三問都是零、結論寫「改好」，
    但這一輪發生過「有 N 處標不上去」「跳過（原文不符）」的話，那個「改好」是有
    前提的。前提只印在畫面上等於沒講。
    """
    notices = nt.collected() if notices is None else notices
    total = blocking_total(answers)
    lines = ["終比對驗收報告", ""]
    for title, key in (("一、填了「改」或「刪除」但定稿裡沒改到"
                        "（含 apply 跳過的程式做不到類：找不到段、原文不符、"
                        "範本鎖定欄位、段落含巢狀內容）", "未改到"),
                       ("二、初比對候選還沒填決定（要改嗎留空）", "未決定"),
                       ("三、定稿冒出的新候選（初比對沒列過）", "新候選"),
                       ("四、填了「改」但「改成什麼」等於原文（視為不改，不擋結論）",
                        SAME_TEXT_KEY),
                       ("五、AI 查不到答案、還沒人工確認結案的項目"
                        "（填寫表單/人工確認.csv 的「人工確認」要寫「已確認」才算結案）", CONFIRM_KEY)):
        rows = answers.get(key) or []
        if key == CONFIRM_KEY and not rows:
            continue          # 沒跑 AI 審查、或都確認過了：不多一行「0 列」
        lines.append("%s：%d 列" % (title, len(rows)))
        for row in rows:
            lines.append("   段次 %s  %s  %s" % (row.get("候選段次") or "-", row.get("來源", ""),
                                                 (row.get("候選全文") or "")[:40]))
        if key == "新候選" and answers.get(APPENDED_KEY):
            lines.append("   → 其中 %d 列已接進 填寫表單/連帶決定表.csv 最後面（來源寫「%s」）：填好「要改嗎」，"
                         "再跑一次套用與驗收" % (answers[APPENDED_KEY], dt.FINAL_SOURCE))
        if key == "新候選" and answers.get(UNPLACED_KEY):
            lines.append("   → %d 列在草稿裡找不到同樣的字（多半是套用之後才長出來的段落），"
                         "請用 Word 直接看定稿那幾段" % answers[UNPLACED_KEY])
        lines.append("")
    vanished = answers.get(VANISHED_KEY) or []
    if vanished:
        lines.append("另：草稿有、決定表沒叫改也沒叫刪，乾淨版卻對不上的段落：%d 段"
                     "（不算進三問，已發警告）" % len(vanished))
        lines += ["   %s" % clip(text, 40) for text in vanished]
        lines.append("")
    lines.append(verdict(total, notices, acknowledged))
    if notices:
        lines.append("")
        lines.append("※ 這一輪有 %d 則提醒，上面的結論要連提醒一起看。" % len(notices))
    lines.append("")
    lines += nt.report_lines(notices)
    with io.open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")
    return total == 0
