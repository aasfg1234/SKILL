# -*- coding: utf-8 -*-
"""
建基準（批次）：把改內規這條線發布出去的新版，接到切條這條線，重建每一本的規格包。

以前發布之後，有規格包的本要人一本一本：到有 Word 的電腦跑 S1 巨集、把 CSV 帶回來、跑 cut 第一趟、
填複核表、再跑 cut 第二趟帶一長串參數。現在一個指令：

    建基準                第一趟：挑要建的本 → 每本 S1P（不用 Word）匯出現行規章 → 切條到 S6 複核表
                          （有舊規格包就沿用上一版決定）→ 合成一張 工作區/建基準/複核表.csv 停下來
    （AI 填複核表的「AI建議」「AI理由」；人填「決定」）
    建基準 --照AI建議 [--預覽]   「決定」空著、AI建議是「保留」的列照 AI 建議填（人看過預覽說好才跑）
    建基準                第二趟（決定都填完了）：拆回各本 → S6 套用 → S7–S12 → 發布到 匯入/規格包/<規章名>/

要建哪幾本：預設是有規格包、而且規格包記的來源跟現在的現行規章對不上的（發布了新版、規格包還是舊的）；
第一次建基準的本用 --規章 甲要點,乙手冊 或 --全部 指定。只收 .docx（S1P 只讀 Word 檔）。
AI 不決定：「決定」欄只有人能填，AI建議只是參考；照 AI 建議只會替「保留」代填，而且要人先說好。
"""

import csv
import datetime
import io
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
for _path in (HERE, os.path.join(HERE, "regdiff"), os.path.join(HERE, "diffcut")):
    if _path not in sys.path:
        sys.path.insert(0, _path)

FOLDER = "建基準"
FORM = "複核表.csv"
INDEX = "先讀我.md"
STATE = "建基準.json"
BOOK = "規章"
AI_COLS = ["AI建議", "AI理由"]
SUGGESTIONS = ("保留", "刪除", "併入上一筆", "待改")
BOOK_FORM = "06_複核表.csv"
FILLED = "06_複核表_填好.csv"


class BaselineError(Exception):
    pass


def base_dir(workspace_root):
    return os.path.join(workspace_root, FOLDER)


def _sha(path):
    from fill_sync import _sha_file
    return _sha_file(path)


def spec_source_sha(release_root):
    """規格包（S12 發布根目錄）記的來源檔 SHA-256；沒有規格包或讀不出來回 None。"""
    try:
        with io.open(os.path.join(release_root, "LATEST.json"), encoding="utf-8") as f:
            latest = json.load(f)
        with io.open(os.path.join(release_root, latest["相對路徑"], "manifest.json"), encoding="utf-8") as f:
            return json.load(f)["來源"]["SHA256"]
    except (OSError, ValueError, KeyError, TypeError):
        return None


def release_root_of(workspace_root, doc):
    import workspace as wsm
    return doc["發布根目錄"] or os.path.join(wsm.paths(workspace_root)["規格包"], doc["規章名"])


def pick(workspace_root, names=None, everything=False):
    """(要建的 [doc], 不建的 [(規章名, 原因)])。"""
    import batch as bt
    import workspace as wsm
    docs = bt.read_manifest(wsm.paths(workspace_root)["清單"])
    wanted = set(names or [])
    unknown = wanted - set(d["規章名"] for d in docs)
    if unknown:
        raise BaselineError("規章清單裡沒有：%s" % "、".join(sorted(unknown)))
    chosen, skipped = [], []
    for doc in docs:
        name = doc["規章名"]
        root = release_root_of(workspace_root, doc)
        recorded = spec_source_sha(root)
        current = doc["舊版"]
        if not current.lower().endswith(".docx"):
            if name in wanted or everything:
                skipped.append((name, "現行規章不是 .docx（S1P 只讀 Word 檔；這一本請用 S1 巨集＋cut）"))
            continue
        stale = recorded is not None and recorded != _sha(current)
        if name in wanted or everything or stale:
            chosen.append(doc)
        elif recorded is not None:
            skipped.append((name, "規格包跟現行規章對得上，不用重建"))
    return chosen, skipped


def _state_path(workspace_root):
    return os.path.join(base_dir(workspace_root), STATE)


def load_state(workspace_root):
    try:
        with io.open(_state_path(workspace_root), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_state(workspace_root, state):
    os.makedirs(base_dir(workspace_root), exist_ok=True)
    with io.open(_state_path(workspace_root), "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def _read(path):
    from _common import open_csv
    with open_csv(path) as f:
        reader = csv.DictReader(f)
        return list(reader.fieldnames or []), list(reader)


def _write(path, fields, rows):
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, quoting=csv.QUOTE_ALL, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    os.replace(tmp, path)


def _key(row):
    import decision_table as dt
    return "%s\x00%s\x00%s" % (row.get(BOOK, ""), row.get("條文ID", ""), dt.text_sha256(row.get("全文") or ""))


def merge_forms(workspace_root, state):
    """各本的 06_複核表.csv 合成一張 工作區/建基準/複核表.csv（第一欄 規章、最後兩欄 AI建議 AI理由），
    寫 先讀我.md。上一次合成過、同一本同一條同一段字的「決定」「AI建議」「AI理由」帶回來。回傳 (列數, 要填的列數)。"""
    path = os.path.join(base_dir(workspace_root), FORM)
    previous = {}
    if os.path.isfile(path):
        for row in _read(path)[1]:
            previous[_key(row)] = row
    fields, merged = [BOOK], []
    for name in sorted(state):
        form = os.path.join(state[name]["資料夾"], BOOK_FORM)
        if not os.path.isfile(form):
            continue
        book_fields, rows = _read(form)
        for c in book_fields:
            if c not in fields:
                fields.append(c)
        for row in rows:
            row = dict(row, **{BOOK: name})
            old = previous.get(_key(row))
            if old:
                for c in ["決定"] + AI_COLS:
                    if (old.get(c) or "").strip() and not (row.get(c) or "").strip():
                        row[c] = old[c]
            merged.append(row)
    fields += [c for c in AI_COLS if c not in fields]
    os.makedirs(base_dir(workspace_root), exist_ok=True)
    _write(path, fields, merged)
    blank = sum(1 for r in merged if not _decision(r))
    _write_index(workspace_root, state, len(merged), blank)
    return len(merged), blank


def _decision(row):
    return (row.get("決定") or "").strip().split("\n")[0].strip()


def _write_index(workspace_root, state, total, blank):
    lines = ["# 建基準：複核表怎麼填", "",
             "`複核表.csv` 列的是切條程式覺得要人看一眼的條文（第一欄是規章）。**「決定」只有人能填**；",
             "AI 先把「AI建議」「AI理由」填好，人照著看、決定。這一輪共 %d 列，「決定」還空著 %d 列。" % (total, blank),
             "", "## AI 怎麼填", "",
             "「AI建議」只能寫這四個之一；「AI理由」開頭寫〔旗標〕，再寫看到了什麼：", "",
             "| AI建議 | 什麼時候 |", "|---|---|",
             "| 保留 | 正常的條文、章節標題、表格或圖形、章前言；旗標只是提醒（過短的標題、含表格圖形、開頭相同但內容不同、原文本來就跳號） |",
             "| 併入上一筆 | 這一筆明顯是上一筆被切斷的後半：開頭是標點或接續的字、單獨讀不成一句 |",
             "| 刪除 | 空白、只剩記號、跟另一筆一字不差的重複（導讀表、目錄殘留） |",
             "| 待改 | 要改原文才修得好：原文漏了編號（疑似缺少父階編號）、條文中間夾著沒切開的編號 |",
             "", "「沿用狀態」寫「沿用」的列，「決定」已經帶著上一版人的決定（第二行「沿用自…」）。這些列 AI 也要填",
             "「AI建議」：跟沿用的決定不同時，建基準會停下來請人決定（照舊就刪掉「沿用自」那一行，要改就改「決定」）。",
             "上一版判「刪除」的條文搬到別的章節、或新版出現同文的另一筆，程式不沿用，會留空給人看。",
             "全文、旗標、條文ID 不要改（S6 會擋）。", "",
             "## 人怎麼填", "",
             "「決定」填 保留／刪除／併入上一筆／待改。AI 建議「保留」的列，人看過預覽說好，可以跑",
             "`python scripts/run_all.py 建基準 --照AI建議` 一次填好（先加 `--預覽` 看會填哪幾列）。",
             "全部填完再跑 `python scripts/run_all.py 建基準`：接著切完、發布新的規格包。", "",
             "## 各本的切條資料夾", ""]
    for name in sorted(state):
        lines.append("- %s：`%s`（舊規格包：%s）" % (name, os.path.relpath(state[name]["資料夾"], workspace_root),
                                               state[name].get("舊規格包") or "沒有，第一次建"))
    with io.open(os.path.join(base_dir(workspace_root), INDEX), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def _conflict(row):
    """決定是沿用上一版預填的（還帶著「沿用自」那一行、人沒動過），AI 看過卻建議別的。"""
    suggestion = (row.get("AI建議") or "").strip()
    decision = row.get("決定") or ""
    return bool(suggestion) and "沿用自" in decision and _decision(row) != suggestion


def form_status(workspace_root):
    """(全部列數, 決定空著 {規章: 列數}, AI建議空著列數, 認不得的 [說明], 沿用跟 AI 建議不同的 [說明])。
    沒有複核表回 None。"""
    path = os.path.join(base_dir(workspace_root), FORM)
    if not os.path.isfile(path):
        return None
    _, rows = _read(path)
    blank, no_ai, bad, conflicts = {}, 0, [], []
    for n, row in enumerate(rows, 2):
        if _conflict(row):
            conflicts.append("第 %d 列（%s %s）沿用上一版的「%s」，AI 建議「%s」：請人決定——照舊就把「沿用自」那一行刪掉，"
                       "要改就把「決定」改掉" % (n, row.get(BOOK), row.get("條文ID"), _decision(row),
                                              (row.get("AI建議") or "").strip()))
        if not _decision(row):
            blank[row.get(BOOK, "")] = blank.get(row.get(BOOK, ""), 0) + 1
            if not (row.get("AI建議") or "").strip():
                no_ai += 1
        suggestion = (row.get("AI建議") or "").strip()
        if suggestion and suggestion not in SUGGESTIONS:
            bad.append("第 %d 列（%s %s）AI建議寫了「%s」：只能寫 %s" % (n, row.get(BOOK), row.get("條文ID"),
                                                            suggestion, "／".join(SUGGESTIONS)))
    return len(rows), blank, no_ai, bad, conflicts


def follow_ai(workspace_root, apply=True):
    """「決定」空著、AI建議是「保留」的列照 AI 建議填。回傳 [(規章, 條文ID, 全文前段)]。"""
    path = os.path.join(base_dir(workspace_root), FORM)
    if not os.path.isfile(path):
        raise BaselineError("還沒有 %s/%s：先跑 建基準（第一趟）" % (FOLDER, FORM))
    fields, rows = _read(path)
    done = []
    for row in rows:
        if not _decision(row) and (row.get("AI建議") or "").strip() == "保留":
            done.append((row.get(BOOK), row.get("條文ID"), (row.get("全文") or "")[:24]))
            if apply:
                row["決定"] = "保留\n依 AI 建議（人核准）：%s" % (row.get("AI理由") or "").strip()
    if apply and done:
        _write(path, fields, rows)
    return done


def split_forms(workspace_root, state):
    """合一的複核表拆回各本（各本原本的欄，「決定」照合一表），寫成 06_複核表_填好.csv。回傳 {規章: 路徑}。
    對回去用 (規章, 條文ID, 全文)，同一把鑰匙有好幾列就照先後一列對一列——只看條文ID 的話，
    ID 撞在一起的兩列（章號認不出來時）人填的決定會互相蓋掉。"""
    path = os.path.join(base_dir(workspace_root), FORM)
    _, rows = _read(path)
    queues = {}
    for r in rows:
        queues.setdefault(_key(r), []).append(r)
    out = {}
    for name in sorted(state):
        folder = state[name]["資料夾"]
        fields, own = _read(os.path.join(folder, BOOK_FORM))
        filled = []
        for row in own:
            queue = queues.get(_key(dict(row, **{BOOK: name})))
            if not queue:
                raise BaselineError("%s 的 %s 在合一的複核表裡找不到（不要刪列，全文也不要改）"
                                    % (name, row.get("條文ID")))
            merged = queue.pop(0)
            filled.append(dict(row, 決定=merged.get("決定") or ""))
        target = os.path.join(folder, FILLED)
        _write(target, fields, filled)
        out[name] = target
    return out


def next_version(release_root):
    base = datetime.datetime.now().strftime("%Y%m%d")
    version, n = base, 1
    while os.path.exists(os.path.join(release_root, version)):
        n += 1
        version = "%s_%d" % (base, n)
    return version
