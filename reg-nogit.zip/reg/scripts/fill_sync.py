# -*- coding: utf-8 -*-
"""
批次時人要動手的東西集中在 產出/填寫表單/：

    產出/填寫表單/連帶決定表.csv            全部規章一張，第一欄是「規章」
    產出/填寫表單/人工確認.csv              AI 查不到答案、要人回覆的項目才有，同樣一張
    產出/填寫表單/<規章名>_新版_定稿.docx   batch-apply 之後，用 Word 確認修訂用

程式內部照舊是一本一份（產出/系統檔案/<規章名>/填寫表單/連帶決定表.csv 與它的指紋檔）：
apply、finalize、review-pack／import 全都靠那一份的段次與指紋，拆掉的代價太大。
合一的那張表是人用的版本，兩邊靠這支同步：

    pull  每個批次子命令開始前：合一表上人改過的，寫回各本那一份
    push  每個批次子命令結束後：各本那一份（程式剛寫的、或人直接改的）重新合成一張，
          各本的新版_定稿.docx 複製一份上來

同步是**逐欄三方合併**，不是整張表誰新誰贏：
    上一次合成時，每一列「人填的欄」（要改嗎、改成什麼；人工確認、說明；人自己加的欄）
    記在 系統檔案/填寫表單同步.json。pull 時合一表上跟那時候不一樣的格，才是人這次改的，
    只把這幾格寫回各本；其他欄（AI 三欄、建議改法、核准方式……）一律以各本為準。
為什麼：Excel 開著時 push 寫不進去（檔案被鎖），這段期間程式寫進各本的東西（核准的決定、
AI 判斷、語意新列）合一表上沒有；人之後按存檔，以前「整本以較新的為準」會把那些蓋掉，
或反過來把人填的蓋掉，畫面只多一行提醒。
"""

import csv
import hashlib
import io
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
from _common import FILL_DIR, SYSTEM_DIR, book_dir, locate, open_csv, read_csv_text

TABLE = "連帶決定表.csv"
CONFIRM = "人工確認.csv"
LEGACY_CONFIRM = "異動確認.csv"
DRAFT = "新版_定稿.docx"
SYNC_FILE = "填寫表單同步.json"
BOOK_COLUMN = "規章"


def fill_dir(root):
    return os.path.join(root, FILL_DIR)


def merged_path(root, name=TABLE):
    return os.path.join(fill_dir(root), name)


def draft_copy_path(root, book):
    return os.path.join(fill_dir(root), "%s_%s" % (book, DRAFT))


def is_batch_root(root):
    return bool(root) and os.path.isfile(os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv"))


def book_names(root):
    """留底清單裡的規章名（照清單順序）。"""
    import batch as bt
    path = os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv")
    skip = bt.unaffected_books(root)          # 這一輪沒進流程的（沒改、也沒被影響）
    with open_csv(path) as f:
        return [(r.get("規章名") or "").strip() for r in csv.DictReader(f)
                if (r.get("規章名") or "").strip() and (r.get("規章名") or "").strip() not in skip]


def _sha_file(path):
    if not os.path.isfile(path):
        return ""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _sha_rows(rows):
    """一本在合一表裡那幾列的指紋：欄順序不算，列順序算（人排過序也是改過）。

    空白格不算：合一表的欄是各本的聯集，某一本本來沒有的欄在合一表上是空白，
    不能因此判成「改過」。Excel 存檔會把換行寫成 \\r\\n，也先收斂。"""
    canon = [sorted((k, (v or "").replace("\r\n", "\n")) for k, v in r.items()
                    if k and k != BOOK_COLUMN and (v or "").strip())
             for r in rows]
    return hashlib.sha256(json.dumps(canon, ensure_ascii=False).encode("utf-8")).hexdigest()


def _read_raw(path):
    if not os.path.isfile(path):
        return None, []
    with open_csv(path) as f:
        reader = csv.DictReader(f)
        return list(reader.fieldnames or []), [dict((k, v) for k, v in r.items() if k) for r in reader]


def _sync_path(root):
    return os.path.join(root, SYSTEM_DIR, SYNC_FILE)


def _load_record(root):
    try:
        with io.open(_sync_path(root), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_record(root, record):
    path = _sync_path(root)
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _book_file(root, book, name):
    return locate(book_dir(root, book), name)[0]


def _has_revisions(path):
    """這份定稿有沒有任何追蹤修訂。讀不出來就當作有：寧可多放一份，不要讓人漏看。"""
    import xml.etree.ElementTree as ET
    import zipfile
    from _common import has_tracked_changes
    try:
        with zipfile.ZipFile(path) as z:
            return has_tracked_changes(ET.fromstring(z.read("word/document.xml")))
    except (zipfile.BadZipFile, KeyError, ET.ParseError, OSError):
        return True


# ---------------------------------------------------------------------------
# pull：合一表 → 各本
# ---------------------------------------------------------------------------

# 人填的欄：只有這幾欄（加上人自己在 Excel 加的欄）從合一表寫回各本
HUMAN_FIELDS = {TABLE: ("要改嗎", "改成什麼"), CONFIRM: ("人工確認", "說明"),
                LEGACY_CONFIRM: ("人工確認", "說明")}


def _program_fields(name):
    """程式寫的欄（合一表上改了也不寫回）。不在這裡、也不是人填欄的，就是人自己加的欄。"""
    if name == TABLE:
        return set(dt.COLUMNS) | set(dt.OPTIONAL_COLUMNS)
    return {"確認ID", "類別", "段次", "內容", "AI判斷", "AI理由", "查證來源", "指紋",
            "異動ID", "新版段次", "異動內容", "異動SHA256"}


def _human_columns(name, fields):
    program = _program_fields(name)
    extra = [c for c in fields or [] if c and c != BOOK_COLUMN and c not in program
             and c not in HUMAN_FIELDS[name]]
    return list(HUMAN_FIELDS[name]) + extra


def _row_key(name, row):
    """一列的身分：決定表用段次＋候選全文，人工確認用指紋（舊的異動確認用異動指紋）。"""
    if name == TABLE:
        return "%s|%s" % ((row.get("候選段次") or "").strip(),
                          dt.text_sha256(dt.normalize_newlines(row.get("候選全文") or "")))
    if name == CONFIRM:
        return (row.get("指紋") or "").strip() or (row.get("確認ID") or "").strip()
    return (row.get("異動SHA256") or "").strip() or (row.get("異動ID") or "").strip()


def _cell(value):
    return dt.normalize_newlines(value or "")


def _snapshot(name, rows, fields):
    """合成那一刻，每一列人填欄的值：pull 拿它判斷人這次改了哪幾格。"""
    columns = _human_columns(name, fields)
    return dict((_row_key(name, r), dict((c, _cell(r.get(c))) for c in columns)) for r in rows)


def pull(root, say=print):
    """批次子命令開始前呼叫。回傳寫回了哪幾本（[(檔名, 規章名), ...]）。

    合一表的「要改嗎」「改成什麼」寫錯（dt.read_table 那一套檢查）就丟
    dt.DecisionTableError，行號是合一表自己的行號——人改的是那一張。"""
    if not is_batch_root(root):
        return []
    record = _load_record(root)
    names = book_names(root)
    written = []
    for name, validate in ((TABLE, True), (CONFIRM, False), (LEGACY_CONFIRM, False)):
        path = merged_path(root, name)
        seen = record.get(name) or {}
        if not os.path.isfile(path) or not seen:
            continue
        _back_to_utf8(path, name, say)
        if validate:
            dt.read_table(path)
        merged_fields, rows = _read_raw(path)
        unknown = sorted(set(r.get(BOOK_COLUMN, "") for r in rows) - set(names))
        if unknown:
            say("[提醒] 填寫表單/%s 有 %d 列的「規章」不在清單裡（%s），這幾列沒有寫回任何一本"
                % (name, sum(1 for r in rows if r.get(BOOK_COLUMN, "") in unknown),
                   "、".join(u or "空白" for u in unknown)))
        columns = _human_columns(name, merged_fields)
        for book in names:
            if book not in seen:
                continue
            part = [r for r in rows if r.get(BOOK_COLUMN, "") == book]
            if _sha_rows(part) == seen[book].get("合一"):
                continue                      # 人沒動這一本
            target = _book_file(root, book, name)
            fields, book_rows = _read_raw(target)
            if fields is None:
                say("[提醒] %s：系統檔案裡找不到這一本的 %s，合一表上的修改沒有寫回" % (book, name))
                continue
            snapshot = seen[book].get("欄")   # 舊版同步紀錄沒有這一項：退回「合一表跟各本不同就寫回」
            by_key = {}
            for r in book_rows:
                by_key.setdefault(_row_key(name, r), r)
            changed = unmatched = conflicts = 0
            for merged_row in part:
                key = _row_key(name, merged_row)
                book_row = by_key.get(key)
                if book_row is None:
                    unmatched += 1
                    continue
                before = (snapshot or {}).get(key, {})
                for column in columns:
                    if column not in merged_row:
                        continue
                    mine, theirs = _cell(merged_row.get(column)), _cell(book_row.get(column))
                    if snapshot is None:
                        edited = mine != theirs
                    else:
                        edited = mine != before.get(column, "")
                        if edited and theirs != before.get(column, "") and theirs != mine:
                            conflicts += 1
                    if edited and mine != theirs:
                        book_row[column] = merged_row.get(column) or ""
                        changed += 1
            if unmatched:
                say("[提醒] %s：填寫表單/%s 有 %d 列在各本對不上（「候選段次」「候選全文」或「指紋」被改過），"
                    "那幾列填的沒有寫回；這幾欄請不要改" % (book, name, unmatched))
            if conflicts:
                say("[提醒] %s：填寫表單/%s 有 %d 格程式也改過，以你在表上填的為準" % (book, name, conflicts))
            if changed:
                _write_book(target, book_rows, name)
                written.append((name, book))
    return written


def _back_to_utf8(path, name, say):
    """合一表被 Excel 另存成 Big5（「CSV（逗號分隔）」）時轉回 UTF-8，並講一聲怎麼存才對。
    讀得懂 Big5 之後流程不會卡，但留著 Big5，下一次程式寫回去又變 UTF-8，Excel 兩種來回切，
    人會以為檔案壞了。"""
    text, encoding = read_csv_text(path)
    if encoding == "utf-8-sig":
        return
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        f.write(text)
    say("[提醒] 產出/填寫表單/%s 是用 Excel 的「CSV（逗號分隔）」存的（Big5），已經轉回 UTF-8，"
        "填的內容都在；下次存檔請選「CSV UTF-8（逗號分隔）」" % name)


def _write_book(target, rows, name):
    if name == TABLE:
        dt.write_rows_csv(target, rows)
        return
    fields = None
    if os.path.isfile(target):
        fields, _ = _read_raw(target)
    fields = fields or [k for k in (rows[0] if rows else {}) if k != BOOK_COLUMN]
    extra = [k for r in rows for k in r if k not in fields and k != BOOK_COLUMN]
    fields = fields + [k for i, k in enumerate(extra) if k not in extra[:i]]
    with io.open(target, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, quoting=csv.QUOTE_ALL, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


# ---------------------------------------------------------------------------
# push：各本 → 合一表、定稿複製上來
# ---------------------------------------------------------------------------

def _merge_fields(field_lists, name):
    seen = []
    for fields in field_lists:
        for f in fields or []:
            if f and f != BOOK_COLUMN and f not in seen:
                seen.append(f)
    if name == TABLE:
        known = set(dt.COLUMNS) | set(dt.OPTIONAL_COLUMNS)
        ordered = dt.ordered_fields([f for f in seen if f in known])
        seen = ordered + [f for f in seen if f not in known]
    return [BOOK_COLUMN] + seen


_LOCKED = ("[提醒] 產出/填寫表單/%s 開在 Excel（或別的程式）裡，這次沒有更新。"
           "你在 Excel 填的內容不會丟：存檔、關掉之後，再跑任何一個批次指令就會合進來")


def push(root, say=print):
    """批次子命令結束後呼叫。回傳 {"表": 路徑或 None, "確認": 路徑或 None, "定稿": [路徑...]}。"""
    if not is_batch_root(root):
        return {}
    names = book_names(root)
    record = _load_record(root)
    out = {"表": None, "確認": None, "定稿": []}
    # 舊名 異動確認.csv 也照樣同步：升級前人在合一表上填的還寫得回各本，review-import 會把答案
    # 帶進 人工確認.csv、拿掉舊表，這裡下一次 push 就把合一的舊表一起收掉
    for name, key in ((TABLE, "表"), (CONFIRM, "確認"), (LEGACY_CONFIRM, "舊確認")):
        field_lists, rows, seen = [], [], {}
        for book in names:
            source = _book_file(root, book, name)
            fields, part = _read_raw(source)
            if fields is None:
                continue
            field_lists.append(fields)
            for r in part:
                r[BOOK_COLUMN] = book
            rows.extend(part)
            seen[book] = {"各本": _sha_file(source), "合一": _sha_rows(part)}
        path = merged_path(root, name)
        if not seen:
            if os.path.isfile(path):
                try:
                    os.remove(path)      # 這一輪各本都沒有這張表（例如沒有任何異動待確認）
                except PermissionError:
                    say(_LOCKED % name)
                    continue
            record.pop(name, None)
            continue
        os.makedirs(fill_dir(root), exist_ok=True)
        fields = _merge_fields(field_lists, name)
        for book in seen:
            seen[book]["欄"] = _snapshot(name, [r for r in rows if r[BOOK_COLUMN] == book], fields)
        tmp = path + ".tmp"
        try:
            with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fields, quoting=csv.QUOTE_ALL, extrasaction="ignore")
                writer.writeheader()
                writer.writerows(rows)
            os.replace(tmp, path)
        except PermissionError:
            # 檔案開在 Excel 裡。同步紀錄不更新：下一次 pull 照上一次成功合成時的樣子，
            # 認得出人在 Excel 裡改了哪幾格，程式這次寫進各本的也不會被蓋掉
            if os.path.isfile(tmp):
                os.remove(tmp)
            say(_LOCKED % name)
            continue
        record[name] = seen
        out[key] = path

    drafts = record.get(DRAFT) or {}
    for book in names:
        source = _book_file(root, book, DRAFT)
        dest = draft_copy_path(root, book)
        if not os.path.isfile(source) or not _has_revisions(source):
            # 沒套用任何一列（整本都「不改」）的定稿沒有修訂可確認，不放上來讓人白開一次 Word。
            # 複本是程式放的、沒被手改過才拿掉；手改過的留著
            last = drafts.get(book) or {}
            if os.path.isfile(dest) and _sha_file(dest) == last.get("複本"):
                os.remove(dest)
            drafts.pop(book, None)
            continue
        src_sha = _sha_file(source)
        last = drafts.get(book) or {}
        if os.path.isfile(dest) and last.get("來源") == src_sha:
            if _sha_file(dest) != last.get("複本"):
                say("[提醒] %s：填寫表單/%s 在 Word 裡被改過。這一份只是給你確認修訂用的複本，"
                    "程式不會讀它；要改內容請改決定表再跑 batch-apply" % (book, os.path.basename(dest)))
            out["定稿"].append(dest)
            continue
        if os.path.isfile(dest) and last and _sha_file(dest) != last.get("複本"):
            kept = dest[:-len(".docx")] + "（手改保留）.docx"
            shutil.copy2(dest, kept)
            say("[提醒] %s：填寫表單/%s 在 Word 裡被改過，已另存成「%s」；新的定稿已經蓋上去"
                % (book, os.path.basename(dest), os.path.basename(kept)))
        os.makedirs(fill_dir(root), exist_ok=True)
        try:
            shutil.copy2(source, dest)
        except PermissionError:
            say("[提醒] 產出/填寫表單/%s 開在 Word 裡，這次沒有換成新的定稿；關掉之後再跑任何一個批次指令就會更新"
                % os.path.basename(dest))
            continue
        drafts[book] = {"來源": src_sha, "複本": _sha_file(dest)}
        out["定稿"].append(dest)
    record[DRAFT] = drafts
    os.makedirs(os.path.join(root, SYSTEM_DIR), exist_ok=True)
    _save_record(root, record)
    return out
