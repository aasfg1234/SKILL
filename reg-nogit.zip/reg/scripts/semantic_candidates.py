# -*- coding: utf-8 -*-
r"""
語意候選：用 BGE-M3 找「意思相近但字面不像」的條文，當連帶決定表的第四種來源。

用法（在有模型的電腦）：
    py semantic_candidates.py --交換包 語意交換包.zip --model <模型資料夾>      （批次：一個檔來回，見 semantic_exchange）
    py semantic_candidates.py 語意輸入.json 語意候選.csv --model <模型資料夾> [--threshold 0.70] [--top 10]

語意輸入.json 由 run_all.py compare 產生。算完把 語意候選.csv 交回去：
    py run_all.py semantic 連帶決定表.csv 語意候選.csv

離開代碼：0 成功；1 輸入有問題；2 模型載不起（SPADE 或沒裝套件），請改手動。

為什麼只當第四種來源、不取代同義詞表：
向量給分數但說不出哪個詞對上；法遵每一筆建議都要能講理由。
所以語意候選一樣列全文與分數，由 AI 在第 2 步逐筆寫理由，人來決定。
"""

import argparse
import csv
import io
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
for _path in (HERE, os.path.join(HERE, "regdiff")):
    if _path not in sys.path:
        sys.path.insert(0, _path)
from _common import strip_article_no, normalize_for_compare, diff_runs  # noqa: E402
import fuzzy_duplicate_finder as fuzzy  # noqa: E402

# 門檻依分數方式不同（真資料校準：手冊 1,347 段、五→七年一字之差）：
#   三分數合併：孿生條 0.86 以上、相鄰條 0.72、其餘 0.62 以下 → 0.70 中間有明顯的空隙
#   只有 dense：孿生條 0.91／0.97、相鄰條 0.79，但無關段也有 0.70～0.72 → 要 0.75 才擋得住
# 呼叫端沒指定（None）就用分數器自己的預設。
DEFAULT_THRESHOLD = 0.70
DENSE_ONLY_THRESHOLD = 0.75
DEFAULT_TOP = 10
# 三種分數對「全文每一個單位」都算（全排名），不先用 dense 篩。記憶體靠分批：
# 每次只把 DEFAULT_BATCH 個單位送進模型、算完分數就丟掉向量（逐字向量每字 1024 個數字，
# 全部留著 1,500 個單位要幾百 MB；分批之後不管書多大都只有一批的量）。
DEFAULT_BATCH = 64
# 粗篩：None（預設）＝全排名，每個單位都算三種分數，不會漏但慢（真資料 1,347 段 801 秒）；
# 給一個數字 N ＝先用純語意把全文排一遍、只對前 N 名算三種分數（N=40 時 402 秒，
# 同一份真資料結果一模一樣；理論上純語意排 N 名外的段會漏）。設定.json「語意粗篩」可改。
DEFAULT_RECALL_TOP = None
# BGE-M3 官方建議的三分數權重（dense／sparse／colbert）。
HYBRID_WEIGHTS = (0.4, 0.2, 0.4)
# 有向量快取時：dense＋sparse 全排名（都從快取來），每個查詢句只對前這麼多名現算 colbert。
# colbert 逐字向量太大不存（見 semantic_cache）；排在兩百名外的段，dense 與 sparse 都已經遠低於門檻。
RERANK_TOP = 200
COLUMNS = ["異動段次", "異動全文", "候選段次", "候選全文", "語意分數", "異動條文ID", "語意依據"]
LEGACY_COLUMNS = COLUMNS[:6]


class SemanticError(ValueError):
    pass


def write_input(path, draft_path, draft_sha, changes, paragraphs, target_name=""):
    data = {"格式版本": 1, "目標規章": target_name,
            "草稿": {"檔名": os.path.basename(draft_path), "SHA256": draft_sha},
            "異動": changes, "段落": list(paragraphs)}
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
        f.write("\n")
    return path


def read_input(path):
    if not os.path.isfile(path):
        raise SemanticError("找不到語意輸入檔：%s" % path)
    with io.open(path, encoding="utf-8-sig") as f:
        data = json.load(f)
    if data.get("格式版本") != 1 or "段落" not in data or "異動" not in data:
        raise SemanticError("語意輸入檔格式不對：%s" % path)
    return data


# ---------------------------------------------------------------------------
# 前處理：跟字面比對用同一套
# ---------------------------------------------------------------------------

def prepare_text(text):
    """算向量前先剝條號、正規化（全半形、空白）。

    為什麼：「第三條」「第二十二條」這幾個字也會進向量，兩條講同一件事的條文
    光條號就先拉開距離；字面比對那邊早就這樣做（strip_article_no），語意這邊
    以前沒做，等於兩條路對「什麼算內容」的定義不同。
    """
    if not text:
        return ""
    return normalize_for_compare(strip_article_no(text))


# ---------------------------------------------------------------------------
# 分數器：dense-only（sentence_transformers 或任何向量函式）與 hybrid（FlagEmbedding）
# ---------------------------------------------------------------------------

def _cosine(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


def _cosine_matrix(queries, docs):
    """查詢×全文的 cosine 矩陣（list of list）。有 numpy 就一次算完（幾萬段 × 1024 維，純 Python
    逐一乘要好幾分鐘）；沒有 numpy 回 None，呼叫端退回逐一算。"""
    try:
        import numpy as np
    except ImportError:
        return None
    if not queries or not docs:
        return [[] for _ in queries]
    q = np.asarray(queries, dtype="float32")
    d = np.asarray(docs, dtype="float32")
    q = q / np.maximum(np.linalg.norm(q, axis=1, keepdims=True), 1e-12)
    d = d / np.maximum(np.linalg.norm(d, axis=1, keepdims=True), 1e-12)
    return (q @ d.T).tolist()


class DenseScorer(object):
    """只有一種向量時的分數器：cosine。embed 是 list[str] -> 向量列表。
    cache（semantic_cache.VectorCache，選填）：算過的文字直接拿，只算沒算過的。"""
    default_threshold = DENSE_ONLY_THRESHOLD

    def __init__(self, embed, cache=None):
        self.embed = embed
        self.cache = cache

    def _vectors(self, texts):
        unique = list(dict.fromkeys(texts))
        known = dict((t, v["dense"]) for t, v in (self.cache.get_many(unique) if self.cache else {}).items())
        missing = [t for t in unique if t not in known]
        if missing:
            fresh = [[float(x) for x in v] for v in self.embed(missing)]
            known.update(zip(missing, fresh))
            if self.cache:
                self.cache.put_many([(t, v, None) for t, v in zip(missing, fresh)])
        return [known[t] for t in texts]

    def score(self, queries, docs):
        if not queries or not docs:
            return [[0.0] * len(docs) for _ in queries]
        vectors = self._vectors(list(docs) + list(queries))
        doc_vecs, query_vecs = vectors[:len(docs)], vectors[len(docs):]
        return [[_cosine(q, d) for d in doc_vecs] for q in query_vecs]


class HybridScorer(object):
    """BGE-M3 三分數合併，全排名：每個查詢句對全文**每一個**單位都算
    dense／sparse／colbert，照 HYBRID_WEIGHTS 加總。

    以前先用 dense 召回前 40 名再細算，是因為誤以為逐字向量放不下；其實分批算、
    算完就丟就沒有這個問題，而且模型只要跑一遍（不用再對召回的那幾十個重跑），
    也不會有「dense 排 40 名外、細算永遠看不到」的漏抓。

    model 只要有四個方法：
        encode_all(texts) -> [{"dense": 向量, "sparse": 詞權重, "colbert": 逐字向量}, ...]
        dense_score(q, d) / sparse_score(q, d) / colbert_score(q, d) -> float
    真的模型用 _FlagM3 包起來；測試用假的。

    為什麼要三種：dense 抓「意思像」，sparse 抓「關鍵詞有沒有對上」，colbert 逐字細比。
    只用 dense 時「保險費」對「應繳金額」只有 0.742，跟無關句（0.667）拉不開；
    三種合起來是 BGE-M3 官方建議的用法。
    """
    default_threshold = DEFAULT_THRESHOLD

    def __init__(self, model, batch_size=DEFAULT_BATCH, weights=HYBRID_WEIGHTS,
                 recall_top=DEFAULT_RECALL_TOP, cache=None, rerank_top=RERANK_TOP):
        self.model = model
        self.batch_size = max(1, int(batch_size))
        self.weights = weights
        self.recall_top = int(recall_top) if recall_top else None
        self.cache = cache
        self.rerank_top = max(1, int(rerank_top))

    def _hybrid(self, q, d):
        wd, ws, wc = self.weights
        return (wd * float(self.model.dense_score(q["dense"], d["dense"]))
                + ws * float(self.model.sparse_score(q["sparse"], d["sparse"]))
                + wc * float(self.model.colbert_score(q["colbert"], d["colbert"])))

    def score(self, queries, docs):
        docs = list(docs)
        queries = list(queries)
        if not queries or not docs:
            return [[0.0] * len(docs) for _ in queries]
        q_parts = self.model.encode_all(queries)
        matrix = [[0.0] * len(docs) for _ in queries]
        if self.cache is not None:
            return self._score_cached(q_parts, docs, matrix)
        if self.recall_top:
            return self._score_recall(q_parts, docs, matrix)
        for start in range(0, len(docs), self.batch_size):
            batch = docs[start:start + self.batch_size]
            d_parts = self.model.encode_all(batch)
            for qi, q in enumerate(q_parts):
                row = matrix[qi]
                for k, d in enumerate(d_parts):
                    row[start + k] = self._hybrid(q, d)
            del d_parts          # 這一批的逐字向量到此為止，不留
        return matrix

    def _lite(self, docs):
        """每個單位的 dense＋sparse：快取有就拿，沒有才算（算完存回去）。"""
        unique = list(dict.fromkeys(docs))
        known = self.cache.get_many(unique)
        missing = [t for t in unique if t not in known]
        for start in range(0, len(missing), self.batch_size):
            batch = missing[start:start + self.batch_size]
            parts = self.model.encode_lite(batch)
            self.cache.put_many([(t, p["dense"], p["sparse"]) for t, p in zip(batch, parts)])
            for t, p in zip(batch, parts):
                known[t] = {"dense": p["dense"], "sparse": p["sparse"]}
        return [known[t] for t in docs]

    def _score_cached(self, q_parts, docs, matrix):
        """快取模式：dense＋sparse 全排名（都從快取來），每個查詢句只對前 rerank_top 名算 colbert
        （逐字向量不存，現算），得到三分數合併；其餘留 0（dense 與 sparse 都已經遠低於門檻）。"""
        wd, ws, _ = self.weights
        lite = self._lite(docs)
        dense = _cosine_matrix([q["dense"] for q in q_parts], [d["dense"] for d in lite])
        picked_by_q = []
        for qi, q in enumerate(q_parts):
            if dense is None:
                dense_row = [float(self.model.dense_score(q["dense"], d["dense"])) for d in lite]
            else:
                dense_row = dense[qi]
            partial = [wd * dense_row[j] + ws * float(self.model.sparse_score(q["sparse"], d["sparse"] or {}))
                       for j, d in enumerate(lite)]
            ranked = sorted(range(len(docs)), key=lambda j: partial[j], reverse=True)
            picked_by_q.append(ranked[:self.rerank_top])
        needed = sorted(set(j for picked in picked_by_q for j in picked))
        full = {}
        for start in range(0, len(needed), self.batch_size):
            batch = needed[start:start + self.batch_size]
            for j, part in zip(batch, self.model.encode_all([docs[j] for j in batch])):
                full[j] = part
        for qi, (q, picked) in enumerate(zip(q_parts, picked_by_q)):
            for j in picked:
                matrix[qi][j] = self._hybrid(q, full[j])
        return matrix

    def _score_recall(self, q_parts, docs, matrix):
        """粗篩模式：先只算純語意（便宜）把全文排一遍，每個查詢句只對前 recall_top 名
        算三種分數，其餘留 0（本來就遠低於門檻）。"""
        dense_all = self.model.encode_dense(docs)
        for qi, q in enumerate(q_parts):
            ranked = sorted(range(len(docs)),
                            key=lambda j: self.model.dense_score(q["dense"], dense_all[j]), reverse=True)
            picked = ranked[:self.recall_top]
            d_parts = self.model.encode_all([docs[j] for j in picked])
            for j, d in zip(picked, d_parts):
                matrix[qi][j] = self._hybrid(q, d)
        return matrix


class _FlagM3(object):
    """把 FlagEmbedding 的 BGEM3FlagModel 包成 HybridScorer 要的四個方法。"""

    def __init__(self, model):
        self.model = model

    def encode_dense(self, texts):
        """只要純語意向量（粗篩用，比三種一起要快一倍）。"""
        texts = list(texts)
        if not texts:
            return []
        return list(self.model.encode(texts, batch_size=16, max_length=512)["dense_vecs"])

    def encode_lite(self, texts):
        """dense＋sparse，不算 colbert（給快取用，逐字向量不存）。"""
        texts = list(texts)
        if not texts:
            return []
        out = self.model.encode(texts, batch_size=16, max_length=512,
                                return_dense=True, return_sparse=True, return_colbert_vecs=False)
        return [{"dense": out["dense_vecs"][i], "sparse": out["lexical_weights"][i]} for i in range(len(texts))]

    def encode_all(self, texts):
        texts = list(texts)
        if not texts:
            return []
        out = self.model.encode(texts, batch_size=16, max_length=512,
                                return_dense=True, return_sparse=True, return_colbert_vecs=True)
        return [{"dense": out["dense_vecs"][i], "sparse": out["lexical_weights"][i],
                 "colbert": out["colbert_vecs"][i]} for i in range(len(texts))]

    @staticmethod
    def dense_score(q, d):
        return _cosine([float(x) for x in q], [float(x) for x in d])

    def sparse_score(self, q, d):
        return float(self.model.compute_lexical_matching_score(q, d))

    def colbert_score(self, q, d):
        return float(self.model.colbert_score(q, d))


def as_scorer(embed_or_scorer):
    """舊呼叫端傳的是向量函式，新的傳 scorer；兩種都收。"""
    if hasattr(embed_or_scorer, "score"):
        return embed_or_scorer
    return DenseScorer(embed_or_scorer)


def load_model(model_path, recall_top=DEFAULT_RECALL_TOP, cache_dir=None):
    """先試 FlagEmbedding（三分數），再試 sentence_transformers（只有 dense）。
    都不行回 None，並印原因。回傳的是 scorer（有 .score(queries, docs)）。
    recall_top：None 全排名；數字 N 就先用純語意粗篩前 N 名（只影響三分數那一種）。
    cache_dir：<現行規章>/系統快取；給了就用向量快取（見 semantic_cache），沒改的段落不重算。"""
    import semantic_cache
    reasons = []
    try:
        from FlagEmbedding import BGEM3FlagModel
        model = BGEM3FlagModel(model_path, use_fp16=False)
        return HybridScorer(_FlagM3(model), recall_top=recall_top,
                            cache=semantic_cache.open_cache(cache_dir, model_path, "m3"))
    except Exception as exc:
        reasons.append("FlagEmbedding 載不起：%s" % exc)
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(model_path)
        return DenseScorer(lambda texts: model.encode(list(texts), batch_size=16, normalize_embeddings=True),
                           cache=semantic_cache.open_cache(cache_dir, model_path, "dense"))
    except Exception as exc:
        reasons.append("sentence_transformers 載不起：%s" % exc)
    for reason in reasons:
        print("  " + reason[:200], flush=True)
    return None


def _sentence_units(text):
    """一段文字拆成 (正規化後的比對字串, 原文) 的單位清單：每一句，再加整段。

    順序很重要：**先切句、再正規化**。normalize_for_compare 會把「；」折成「;」，
    而 split_sentences 只認全形「。」「；」，先正規化就永遠切不開分號句
    （真資料 1,347 段裡有 50 段是這樣）。字面比對那邊也是切完才正規化。

    單句段落：那一句去掉句末標點就等於整段，只留整段一個單位，不重複算
    （不去重的話 1,347 段裡有 563 個單位是重的，白跑一倍時間，而且哪一個贏是隨機的）。
    原文留著給「語意依據」用——寫進產出檔的原文一律保留原字。
    """
    raw = strip_article_no(text or "").strip()
    whole = normalize_for_compare(raw)
    if not whole:
        return []
    whole_core = whole.rstrip("。;；.")
    units = []
    seen = set()
    for sent in fuzzy.split_sentences(raw):
        norm = normalize_for_compare(sent)
        if not norm or norm in seen or norm.rstrip("。;；.") == whole_core:
            continue
        seen.add(norm)
        units.append((norm, sent.strip()))
    units.append((whole, raw))
    return units


def _units_of(text):
    """全文每一段的比對單位（見 _sentence_units）。"""
    return _sentence_units(text)


def _query_units(change):
    """這一處異動拿什麼去比：有舊全文就取「改到的那幾句」，沒有（新增段、舊格式輸入）
    就用整段。整段永遠也放進去當備援，改動句對不上時整段仍有機會。
    回傳 (正規化字串, 原文) 清單，跟 _sentence_units 同型。"""
    raw_new = strip_article_no(change.get("全文") or "").strip()
    raw_old = strip_article_no(change.get("舊全文") or "").strip()
    whole = normalize_for_compare(raw_new)
    if not whole:
        return []
    whole_core = whole.rstrip("。;；.")
    units = []
    seen = set()
    if raw_old and raw_new:
        for sent in fuzzy.changed_sentences(raw_old, raw_new, diff_runs):
            norm = normalize_for_compare(sent)
            if not norm or norm in seen or norm.rstrip("。;；.") == whole_core:
                continue
            seen.add(norm)
            units.append((norm, sent.strip()))
    units.append((whole, raw_new))
    return units


def _clip(text, limit=30):
    # 「；」是決定表證據欄的分隔符（decision_table._merge），原文裡有的話換成「、」，
    # 不然那一格會被拆成好幾段。
    text = (text or "").strip().replace("；", "、").replace(";", "、")
    return text if len(text) <= limit else text[:limit] + "…"


def _basis(query_raw, hit_raw, whole_query, whole_hit):
    """「語意依據」的字：改動句／整段 對 命中句／整段。兩邊前 30 字一樣（孿生句只差句尾）
    時把命中句放寬到 60 字，不然看表的人看不出差在哪。"""
    left = "整段" if whole_query else "改動句「%s」" % _clip(query_raw)
    if whole_hit:
        right = "整段"
    else:
        hit_clip = _clip(hit_raw)
        if not whole_query and hit_clip == _clip(query_raw):
            hit_clip = _clip(hit_raw, 60)
        right = "「%s」" % hit_clip
    return "%s對%s" % (left, right)


def find_candidates(embed, changes, paragraphs, threshold=None, top=DEFAULT_TOP,
                    target_name=""):
    """embed：向量函式或 scorer（見 as_scorer）。每筆異動用「改到的那幾句」（沒有舊全文就整段）
    去比全文每一段的每一句與整段，取最高分當這一段的分數；「語意依據」寫是哪一句對上哪一句。
    只有同本（「規章」空白或等於 target_name）且「段次」有效時才排除自己那一段。
    回傳 dict 列，欄位同 COLUMNS。

    為什麼改成句對句：整段對整段時，改動的那幾個字被沒改的兩百字稀釋；字面比對那邊的
    句子層級早就證明過這件事（36.6 分 → 90.3 分），語意這一路照同樣的結構做。
    """
    scorer = as_scorer(embed)
    if threshold is None:
        threshold = getattr(scorer, "default_threshold", DEFAULT_THRESHOLD)
    texts = list(paragraphs)
    changes = [c for c in changes if (c.get("全文") or "").strip()]
    if not texts or not changes:
        return []
    # 全文所有單位攤平（正規化字串給模型、原文給依據欄），記住每個單位屬於第幾段
    doc_units, doc_raw, owner = [], [], []
    for j, text in enumerate(texts):
        for norm, raw in _units_of(text):
            doc_units.append(norm)
            doc_raw.append(raw)
            owner.append(j)
    if not doc_units:
        return []
    change_units = [_query_units(c) for c in changes]
    flat_queries = [norm for units in change_units for norm, _raw in units]
    matrix = scorer.score(flat_queries, doc_units) if flat_queries else []
    rows = []
    cursor = 0
    for change, units in zip(changes, change_units):
        doc = (change.get("規章") or "").strip()
        same_doc = (not doc) or (doc == (target_name or ""))
        idx = int(change.get("段次") or 0) - 1 if same_doc else -1
        best = {}          # 段索引 -> (分數, 查詢單位索引, 命中單位索引)
        for qi in range(len(units)):
            row = matrix[cursor + qi]
            for k, score in enumerate(row):
                j = owner[k]
                if j == idx or score < threshold:
                    continue
                if j not in best or score > best[j][0]:
                    best[j] = (score, qi, k)
        cursor += len(units)
        label = change.get("條文ID", "")
        if not same_doc:
            label = "%s：%s" % (doc, label or ("段次 %s" % change.get("段次", "")))
        ranked = sorted(best.items(), key=lambda kv: (-kv[1][0], kv[0]))
        whole_query_norm = units[-1][0] if units else ""
        for j, (score, qi, k) in ranked[:top]:
            # 整段那一個單位永遠排在清單最後（見 _sentence_units／_query_units）
            whole_hit = (doc_units[k] == _units_of(texts[j])[-1][0])
            whole_query = (units[qi][0] == whole_query_norm)
            # 講清楚是哪一種對法：改動句／整段 對 命中句／整段。四種寫法都要看得出來，
            # 看表的人才知道這一列是「那一句對上了」還是「整段大致像」。
            basis = _basis(units[qi][1], doc_raw[k], whole_query, whole_hit)
            rows.append({"異動段次": str(idx + 1) if idx >= 0 else "",
                         "異動全文": change["全文"], "候選段次": str(j + 1),
                         "候選全文": texts[j], "語意分數": "%.3f" % score,
                         "異動條文ID": label, "語意依據": basis})
    return rows


def write_results(path, rows, draft_sha):
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["#草稿SHA256", draft_sha])
        writer.writerow(COLUMNS)
        for row in rows:
            writer.writerow([row.get(c, "") for c in COLUMNS])


def read_results(path, expected_sha=None):
    if not os.path.isfile(path):
        raise SemanticError("找不到語意候選檔：%s" % path)
    # 以前寫死 utf-8-sig：人用 Excel 開過再存成「CSV（逗號分隔）」（Big5）就噴
    # UnicodeDecodeError 的 traceback（第三批）。改走 _common.read_csv_text（UTF-8／Big5 都認），
    # 認不出來一律轉成 SemanticError，呼叫端照樣印「[中止]」加一句怎麼修。
    from _common import InputError, read_csv_text
    try:
        text, _ = read_csv_text(path)
    except InputError as exc:
        raise SemanticError("語意候選檔讀不出來：%s" % exc)
    except OSError as exc:
        raise SemanticError("語意候選檔打不開：%s（%s）" % (path, exc))
    reader = csv.reader(io.StringIO(text, newline=""))
    try:
        first = next(reader, None)
        if not first or first[0] != "#草稿SHA256" or len(first) < 2:
            raise SemanticError("語意候選.csv 第一列應為「#草稿SHA256,<指紋>」兩格")
        if expected_sha and first[1] != expected_sha:
            raise SemanticError("語意候選是對另一份草稿算的，指紋不符，不能併入")
        header = next(reader, None)
        if header not in (COLUMNS, LEGACY_COLUMNS):
            raise SemanticError("語意候選.csv 欄位不符，應為：%s" % "、".join(COLUMNS))
        rows = []
        for r in reader:
            if not r:
                continue
            row = dict(zip(COLUMNS, r))
            row.setdefault("語意依據", "")      # 六欄的舊檔補空
            rows.append(row)
    except csv.Error as exc:
        raise SemanticError("語意候選.csv 格式壞了（%s）：請重新產生，或用 Excel 另存成「CSV UTF-8（逗號分隔）」"
                            % exc)
    return rows


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    parser = argparse.ArgumentParser(description="BGE-M3 語意候選")
    parser.add_argument("--交換包", "--exchange", dest="exchange", default=None,
                        help="批次的 語意交換包.zip：算完每一本，結果寫回同一個檔（門檻等參數照包裡記的）")
    parser.add_argument("input_json", nargs="?", help="一本的語意輸入.json（跟 output_csv 一起給）")
    parser.add_argument("output_csv", nargs="?")
    parser.add_argument("--workspace", default=None,
                        help="工作區資料夾：一次算完 產出/系統檔案/語意候選/ 裡的每一本，"
                             "向量快取自動用工作區的 匯入/現行規章/系統快取")
    parser.add_argument("--folder", default=None,
                        help="語意候選資料夾：一次算完裡面每一個 <規章名>_語意輸入.json，結果寫成同資料夾的 <規章名>.csv")
    parser.add_argument("--model", required=True, help="BGE-M3 模型資料夾")
    parser.add_argument("--threshold", type=float, default=None,
                        help="語意分數門檻；不給就依分數方式用預設（三分數 %.2f、只有 dense %.2f）"
                             % (DEFAULT_THRESHOLD, DENSE_ONLY_THRESHOLD))
    parser.add_argument("--top", type=int, default=None, help="每個異動最多幾筆（預設 %d）" % DEFAULT_TOP)
    parser.add_argument("--cache", default=None,
                        help="向量快取資料夾（<現行規章>/系統快取）；給了就沿用算過的向量，沒改的段落不重算"
                             "（--交換包 沒給就用這台 reg 的 語意快取/）")
    parser.add_argument("--recall-top", type=int, default=None,
                        help="粗篩：先用純語意排一遍、只對前 N 名算三種分數（快一倍，理論上可能漏）；"
                             "不給就全排名（預設，不會漏）")
    args = parser.parse_args(argv)
    if args.exchange:
        import semantic_exchange as se
        return se.compute(args.exchange, args.model, cache_dir=args.cache, threshold=args.threshold,
                          top=args.top, recall_top=args.recall_top,
                          say=lambda text: print(text, flush=True))
    args.top = args.top or DEFAULT_TOP
    cache_dir = args.cache
    folder = args.folder
    if args.workspace:
        # 一律用工作區裡的相對位置：指令裡不寫哪一台電腦的完整路徑，複製到別台照樣能跑
        import batch as bt
        root = os.path.join(os.path.abspath(args.workspace), "產出")
        folder = os.path.join(root, "系統檔案", "語意候選")
        cache_dir = cache_dir or bt.cache_dir(root) or None
    if folder:
        if not os.path.isdir(folder):
            print("[中止] 找不到語意候選資料夾：%s" % folder, flush=True)
            return 1
        suffix = "_語意輸入.json"
        jobs = [(os.path.join(folder, name), os.path.join(folder, name[:-len(suffix)] + ".csv"))
                for name in sorted(os.listdir(folder)) if name.endswith(suffix)]
        if not jobs:
            print("[中止] %s 裡沒有任何 <規章名>_語意輸入.json" % folder, flush=True)
            return 1
    elif args.input_json and args.output_csv:
        jobs = [(args.input_json, args.output_csv)]
    else:
        parser.error("要給 --交換包、--workspace、--folder，或 語意輸入.json 與 語意候選.csv 兩個檔名")
    inputs = []
    for input_path, output_path in jobs:
        try:
            inputs.append((read_input(input_path), output_path))
        except SemanticError as exc:
            print("[中止] %s" % exc, flush=True)
            return 1
    print("載入模型：%s" % args.model, flush=True)
    scorer = load_model(args.model, recall_top=args.recall_top, cache_dir=cache_dir)
    if scorer is None:
        print("[跳過] 這個環境載不起 BGE-M3。請在有模型的電腦執行這支程式，再把結果交回。", flush=True)
        return 2
    if isinstance(scorer, HybridScorer):
        mode = "三分數合併（dense／sparse／colbert），%s" % (
            "全排名" if not scorer.recall_top else "先用純語意粗篩前 %d 名" % scorer.recall_top)
    else:
        mode = "只有 dense（sentence_transformers）"
    print("分數方式：%s" % mode, flush=True)
    used = args.threshold if args.threshold is not None else getattr(scorer, "default_threshold", DEFAULT_THRESHOLD)
    for data, output_path in inputs:
        rows = find_candidates(scorer, data["異動"], data["段落"], args.threshold, args.top,
                               data.get("目標規章", ""))
        write_results(output_path, rows, data["草稿"]["SHA256"])
        print("%s語意候選 %d 列（門檻 %.2f）：%s"
              % (("%s：" % data["目標規章"]) if data.get("目標規章") else "", len(rows), used, output_path),
              flush=True)
    if folder:
        print("算完 %d 本。把結果帶回原本那台電腦（放回同一個位置），跑 batch-semantic 併入" % len(inputs), flush=True)
    cache = getattr(scorer, "cache", None)
    if cache is not None:
        print("向量快取：沿用 %d 個、新算 %d 個（%s）" % (cache.hits, cache.misses, cache.path), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
