# -*- coding: utf-8 -*-
"""
apply 寫出的帶修訂定稿，程式自己驗：不用每一本都叫人開 Word 看「修訂正不正常」。

    全部接受 ＝ 乾淨版     （要發布的那一份就是修訂接受之後的樣子）
    全部拒絕 ＝ 原本的草稿 （每一處改動都有記成追蹤修訂，沒有偷改沒留痕跡的字）
    帶修訂的段落數 ＝ 套用報告「已套用」的列數

第三條的道理：apply 每一列「已套用」正好改一段（改寫或整段刪除），而草稿本來就不准
帶文字修訂（apply 開頭擋掉），所以定稿上帶插入／刪除記號的段落，一段對一列。
以前只看「有沒有修訂記號」：套用了 8 列、定稿上只有 1 段有修訂也會通過，
那 7 列到底有沒有寫進去，報告與定稿對不起來也沒人知道。
同一段被兩列指到時，第二列會因為段落的字已經變了而記成「跳過（原文不符）」，
不會出現一段算兩列。格式修訂（行距、字型）不算：它不改字，草稿裡本來就可能有。

比的是全文文字（去掉空白後逐字比），不比版面：字型、縮排這種 Word 才看得出來的東西，
送簽前抽一本用 Word 打開看就好。

「全部拒絕」自己讀 XML：插入（ins、moveTo）的子樹整棵拿掉，刪除（del、moveFrom）的字留著
（delText 當成一般文字）。「全部接受」用 _common.read_paragraphs——它本來就是讀接受修訂後的樣子。
"""

import os
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import (DELETE_LIKE_TAGS, INSERT_LIKE_TAGS, count_tracked_changes,
                     describe_tracked_changes, read_paragraphs, run_symbol_text)

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_TEXT_TAGS = (_W + "t", _W + "delText")
_SKIP = tuple(INSERT_LIKE_TAGS) + (_W + "pPr", _W + "rPr", _W + "txbxContent")


def _document_root(path):
    with zipfile.ZipFile(path) as z:
        return ET.fromstring(z.read("word/document.xml"))


def rejected_text(path):
    """把 path 這份 docx 的修訂全部拒絕之後的全文（不分段）。"""
    parts = []

    def walk(node):
        for child in node:
            if child.tag in _SKIP:
                continue
            if child.tag in _TEXT_TAGS:
                parts.append(child.text or "")
            else:
                # 不斷行連字號、符號字：讀檔那邊算一個字，這裡也要算，不然沒改到的段也對不上（第三批）
                symbol = run_symbol_text(child)
                if symbol:
                    parts.append(symbol)
            walk(child)

    walk(_document_root(path).find(_W + "body"))
    return "".join(parts)


def _flat(text):
    return re.sub(r"\s+", "", text or "")


_TEXT_REVISION_TAGS = tuple(INSERT_LIKE_TAGS) + tuple(DELETE_LIKE_TAGS)


def _has_own_text_revision(paragraph):
    """這一段自己（不含文字方塊裡的巢狀段落）有沒有插入／刪除記號，段落記號的刪除也算。"""
    stack = list(paragraph)
    while stack:
        node = stack.pop()
        if node.tag == _W + "p":
            continue          # 文字方塊裡的段落另外算
        if node.tag in _TEXT_REVISION_TAGS:
            return True
        stack.extend(node)
    return False


def revised_paragraphs(root):
    """本文裡帶文字修訂（插入、刪除、移動）的段落有幾段。"""
    body = root.find(_W + "body")
    if body is None:
        return 0
    return sum(1 for para in body.iter(_W + "p") if _has_own_text_revision(para))


def verify(tracked, clean, draft, applied=None):
    """回傳 {"通過": bool, "問題": [...], "修訂": 描述, "修訂段落": 段數}。

    applied：套用報告「已套用」的列數。給了才驗「有修訂記號」與「帶修訂的段落數＝已套用列數」。
    """
    import notices as nt
    from _common import _REMINDED_KEY
    # 讀檔時看到追蹤修訂會提醒一次「以已接受修訂的內容比對」；這一份本來就是帶修訂的定稿，
    # 那一則是雜訊：先把這一份標成講過了
    nt.once(_REMINDED_KEY % os.path.abspath(tracked))
    problems = []
    root = _document_root(tracked)
    counts = count_tracked_changes(root)
    accepted = "".join(read_paragraphs(tracked))
    if _flat(accepted) != _flat("".join(read_paragraphs(clean))):
        problems.append("定稿全部接受之後跟乾淨版不一樣")
    if _flat(rejected_text(tracked)) != _flat("".join(read_paragraphs(draft))):
        problems.append("定稿全部拒絕之後跟原本的草稿不一樣（有改動沒有記成追蹤修訂）")
    revised = revised_paragraphs(root)
    if applied and not any(counts.values()):
        problems.append("套用了 %d 列，定稿上卻沒有任何修訂記號" % applied)
    elif applied is not None and revised != applied:
        problems.append("套用報告記「已套用」%d 列，定稿上帶修訂的段落卻有 %d 段"
                        "（一列已套用應該正好對應一段帶修訂的段落）" % (applied, revised))
    return {"通過": not problems, "問題": problems, "修訂": describe_tracked_changes(counts),
            "修訂段落": revised}
