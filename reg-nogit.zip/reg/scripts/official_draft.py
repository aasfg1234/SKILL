# -*- coding: utf-8 -*-
"""
公文（簽稿）草稿：替改好的每一本寫一份骨架，承辦改寫、核對後再用。選用：跑「公文」才產。

只寫修正對照表上查得到的事實——修正哪幾條（點）、幾處是修正／新增／刪除、每一處的修改依據
（對照表上寫什麼就抄什麼，還寫「請補修正理由」的照抄，提醒人補）。依據（函文字號）、生效日期
程式不知道，留「（請填）」：不替人編。

    產出/結果彙整/公文草稿/<規章名>_簽稿草稿.docx（沒有 python-docx 就寫 .txt）
"""

import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import RESULT_DIR

FOLDER = "公文草稿"
SUBSTANTIVE = ("修改", "新增", "刪除")
FILL = "（請填）"
CN_NUMBERS = "一二三四五六七八九十"


def _cn(n):
    """1 → 一 …… 10 → 十、11 → 十一（公文的（一）（二）用）。"""
    if n <= 10:
        return CN_NUMBERS[n - 1]
    if n < 20:
        return "十" + CN_NUMBERS[n - 11]
    tens, ones = divmod(n, 10)
    return CN_NUMBERS[tens - 1] + "十" + (CN_NUMBERS[ones - 1] if ones else "")


def _titles():
    import diff_compare
    titles = dict((c["鍵"], c["標題"]) for c in diff_compare.load_table_format()["欄位"])
    return dict((key, titles.get(key, key)) for key in ("條號", "修改類型", "修改依據"))


def table_rows(root, name):
    """這一本修正對照表（人補過修改依據的那一份優先）每一列：[{條號, 修改類型, 修改依據}]。沒有對照表回 None。"""
    import change_reasons as cr
    from _common import book_dir, read_xlsx_dicts
    published, own = cr.tables_of(book_dir(root, name))
    path = published if os.path.isfile(published) else own
    if not os.path.isfile(path):
        return None
    titles = _titles()
    return [dict((key, (row.get(title) or "").strip()) for key, title in titles.items())
            for row in read_xlsx_dicts(path)]


def lines_for(name, rows):
    """簽稿草稿的每一行（純文字；寫 docx 時一行一段）。"""
    import change_reasons as cr
    import workspace as wsm
    shown = wsm.display_name(name) or name
    changes = [r for r in rows if r["修改類型"] in SUBSTANTIVE]
    counts = dict((kind, sum(1 for r in changes if r["修改類型"] == kind)) for kind in SUBSTANTIVE)
    others = len([r for r in rows if r["修改類型"] and r["修改類型"] not in SUBSTANTIVE])
    refs = []
    for r in changes:
        if r["條號"] and r["條號"] not in refs:
            refs.append(r["條號"])
    if not refs:
        where = "部分規定"
    elif len(refs) <= 4:
        where = "、".join(refs)
    else:
        where = "%s等 %d 處" % ("、".join(refs[:3]), len(refs))
    lines = ["簽稿草稿（程式依修正對照表整理，請承辦改寫、核對後再用；「%s」與「%s」要人補）" % (FILL, cr.PLEASE_FILL),
             "",
             "主旨：修正「%s」%s，簽請　核示。" % (shown, where),
             "說明：",
             "一、依據：%s（例：主管機關函文字號、內部會議決議；沒有就刪掉這一點）" % FILL,
             "二、修正緣由："]
    for n, r in enumerate(changes, 1):
        lines.append("　（%s）%s：%s" % (_cn(n), r["條號"] or "（條號請補）", r["修改依據"] or cr.PLEASE_FILL))
    if not changes:
        lines.append("　本次沒有實質修正。")
    detail = "、".join("%s %d 處" % (kind, counts[kind]) for kind in SUBSTANTIVE if counts[kind])
    lines += ["三、本次修正共 %d 處%s%s。修正對照表如附件一，修正後全文如附件二。"
              % (len(changes), "（%s）" % detail if detail else "",
                 "；另配合調整編號或字形 %d 處" % others if others else ""),
              "四、生效日期：%s（例：自發布日施行）" % FILL,
              "擬辦：奉核後公告實施，並更新內規系統。",
              "附件：一、%s修正對照表　二、%s（修正後全文）" % (shown, shown)]
    return lines


def write(root, name, lines):
    """寫 產出/結果彙整/公文草稿/<規章名>_簽稿草稿.docx（沒有 python-docx 就寫 .txt）。回傳路徑。"""
    from _common import HAS_DOCX
    folder = os.path.join(root, RESULT_DIR, FOLDER)
    os.makedirs(folder, exist_ok=True)
    base = os.path.join(folder, "%s_簽稿草稿" % name)
    if not HAS_DOCX:
        with io.open(base + ".txt", "w", encoding="utf-8-sig") as f:
            f.write("\n".join(lines) + "\n")
        return base + ".txt"
    from docx import Document
    doc = Document()
    for n, line in enumerate(lines):
        run = doc.add_paragraph().add_run(line)
        run.bold = n == 0 or line.startswith(("主旨：", "說明：", "擬辦：", "附件："))
    doc.save(base + ".docx")
    return base + ".docx"
