# -*- coding: utf-8 -*-
"""
批次時的 產出/結果彙整/：要送簽的文件，先分文件種類、同一種各規章放在一起。

    產出/結果彙整/
      檢視報告.xlsx                          各本合一（review_report.refresh_batch 寫的）
      標註版全文/          <規章名>_標註版全文.docx
      新版定稿（乾淨版）/   <規章名>_新版定稿_乾淨版.docx
      新版定稿（追蹤修訂）/ <規章名>_新版定稿_追蹤修訂.docx
      修正對照表/          <規章名>_修正對照表.docx／.xlsx
      本次未修改.txt                         整本沒改的那幾本（有才寫）

每一本自己的成品照舊寫在 產出/系統檔案/<規章名>/結果彙整/（跟單本一模一樣：終比對整理、
沒改的本、檢視報告都照單本的邏輯走），這支在每個批次指令結束後把它們排上來。

排上來的是複本。人可能直接在上面寫東西（修正對照表.docx 最後一欄「修改依據／理由」
就是留給人填的），所以不能每次都蓋：記下上一次排上來時兩邊的指紋——
    只有來源變了        → 換成新的
    只有複本被改過      → 不動它
    兩邊都變了          → 手改的另存「（手改保留）」，再放新的，並講一聲
"""

import io
import json
import os
import shutil

from fill_sync import _sha_file, book_names, is_batch_root
from _common import RESULT_DIR, SYSTEM_DIR, book_dir

# (每一本內部 結果彙整 裡的檔名, 產出/結果彙整/ 底下的資料夾)
PUBLISH = [
    ("標註版全文.docx", "標註版全文"),
    ("標註版全文.txt", "標註版全文"),
    ("新版定稿_乾淨版.docx", "新版定稿（乾淨版）"),
    ("新版定稿_追蹤修訂.docx", "新版定稿（追蹤修訂）"),
    ("修正對照表.docx", "修正對照表"),
    ("修正對照表.xlsx", "修正對照表"),
    ("修正對照表.csv", "修正對照表"),
]
FOLDERS = []
for _, _folder in PUBLISH:
    if _folder not in FOLDERS:
        FOLDERS.append(_folder)
UNCHANGED = "本次未修改.txt"
RECORD = "結果彙整發布.json"
KEPT = "（手改保留）"


def published_path(root, book, filename):
    """某一本的某個成品排上來之後在哪（不管現在有沒有）；不是要排的檔回 None。"""
    for name, folder in PUBLISH:
        if name == filename:
            return os.path.join(root, RESULT_DIR, folder, "%s_%s" % (book, name))
    return None


def _record_path(root):
    return os.path.join(root, SYSTEM_DIR, RECORD)


def _load(root):
    try:
        with io.open(_record_path(root), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save(root, record):
    path = _record_path(root)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _reasons_carried(dest, source):
    """修正對照表 xlsx 上人只補了修改依據、新的一份已經照抄進去（change_reasons 沿用）：
    直接換新的就好，不用再另存一份「（手改保留）」讓人以為自己寫的被搬走了。"""
    if not dest.endswith("修正對照表.xlsx"):
        return False
    import change_reasons as cr
    return cr.carried(dest, source)


def publish(root, say=print):
    """把各本內部的成品排到 產出/結果彙整/。回傳這次排好的路徑清單。"""
    if not is_batch_root(root):
        return []
    names = book_names(root)
    record = _load(root)
    result = os.path.join(root, RESULT_DIR)
    wanted = {}          # 產出/結果彙整 底下的相對路徑 → 來源
    unchanged = []
    for book in names:
        inner = os.path.join(book_dir(root, book), RESULT_DIR)
        if os.path.isfile(os.path.join(inner, UNCHANGED)):
            unchanged.append(book)
            continue
        for name, folder in PUBLISH:
            source = os.path.join(inner, name)
            if os.path.isfile(source):
                wanted[os.path.join(folder, "%s_%s" % (book, name))] = source

    # 上一次排過、這次不該再有的（重跑之後某本變成沒改、某份對照表退路 csv 不再產生……）拿掉；
    # 被手改過的不刪，留著並講一聲
    for rel in sorted(set(record) - set(wanted)):
        path = os.path.join(result, rel)
        if os.path.isfile(path):
            if _sha_file(path) == (record[rel] or {}).get("複本"):
                os.remove(path)
            else:
                say("[提醒] 結果彙整/%s 這一輪已經不是要送簽的文件了，但它被手改過，沒有刪；"
                    "確認不要了再自己刪" % rel.replace(os.sep, "/"))
        record.pop(rel, None)

    done = []
    for rel, source in sorted(wanted.items()):
        dest = os.path.join(result, rel)
        src_sha = _sha_file(source)
        last = record.get(rel) or {}
        dest_sha = _sha_file(dest)
        edited = bool(dest_sha) and bool(last) and dest_sha != last.get("複本")
        if last.get("來源") == src_sha and dest_sha:
            done.append(dest)                      # 來源沒變：不管複本改沒改都不動
            continue
        if edited and not _reasons_carried(dest, source):
            stem, ext = os.path.splitext(dest)
            kept = stem + KEPT + ext
            shutil.copy2(dest, kept)
            say("[提醒] 結果彙整/%s 被手改過，已另存成「%s」；新的一份已經放上去"
                % (rel.replace(os.sep, "/"), os.path.basename(kept)))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        try:
            shutil.copy2(source, dest)
        except OSError as exc:
            say("[提醒] 結果彙整/%s 更新不了（%s，可能開在 Word／Excel 裡）；關掉後再跑一次任何批次指令"
                % (rel.replace(os.sep, "/"), exc))
            continue
        record[rel] = {"來源": src_sha, "複本": _sha_file(dest)}
        done.append(dest)

    note = os.path.join(result, UNCHANGED)
    import batch as bt
    untouched = sorted(bt.unaffected_books(root))
    if unchanged or untouched:
        os.makedirs(result, exist_ok=True)
        with io.open(note, "w", encoding="utf-8-sig") as f:
            if unchanged:
                f.write("本次沒有修改的規章：%s\n\n"
                        "這幾本新版與舊版內容完全相同，不需要送簽，所以上面幾個資料夾裡沒有它們的檔案。\n"
                        "它們被別本的改動影響到、列進了連帶決定表，最後都決定不改：看 產出/填寫表單/連帶決定表.csv "
                        "裡這幾本的列。\n\n" % "、".join(unchanged))
            if untouched:
                f.write("沒放修訂版、也沒有被別本的改動影響到的規章（%d 本）：%s\n\n"
                        "這幾本只讀過全文，用來找別本改動的連帶與引用，一處都沒找到，所以後面的步驟都沒有處理它們。\n"
                        % (len(untouched), "、".join(untouched)))
    elif os.path.isfile(note):
        os.remove(note)
    for folder in FOLDERS:
        path = os.path.join(result, folder)
        if os.path.isdir(path) and not os.listdir(path):
            os.rmdir(path)
    _save(root, record)
    return done
