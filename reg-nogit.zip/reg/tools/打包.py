# -*- coding: utf-8 -*-
"""
把 reg 打成兩個交付 zip：reg-claude 與 reg-spade。程式相同，只有 SKILL.md 不同。
輸出到 repo 根目錄的 fin_repo/（.gitignore 已排除 zip 與 sha256 檔）。
    py reg/tools/打包.py
"""
import datetime
import hashlib
import io
import os
import subprocess
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.dirname(HERE)
ROOT = os.path.dirname(REG)
EXCLUDE_DIRS = {"tests", "__pycache__", "platform", ".git", ".claude"}
EXCLUDE_EXT = {".pyc", ".zip", ".tmp"}
# 跑過工具之後 reg 底下會多出公司的東西，一律不打包（A14）：預設工作區（放著規章與產出）、
# 語意快取、單本指令的 reg_產出*、打包自己的 fin_repo
EXCLUDE_TOP = {"工作區", "語意快取", "fin_repo"}
EXCLUDE_TOP_PREFIX = ("reg_產出",)


def _configured_workspace():
    """設定.json 的「工作區根目錄」若設在 reg 裡面，那個資料夾也不打包。"""
    import json
    try:
        with io.open(os.path.join(REG, "設定.json"), encoding="utf-8-sig") as f:
            root = (json.load(f) or {}).get("工作區根目錄") or ""
    except (OSError, ValueError, AttributeError):
        return None
    if not root:
        return None
    root = os.path.normcase(os.path.abspath(os.path.join(REG, root)))
    return root if root.startswith(os.path.normcase(REG) + os.sep) else None


def commit_short():
    try:
        r = subprocess.run(["git", "-C", ROOT, "rev-parse", "--short", "HEAD"],
                           capture_output=True, text=True, encoding="utf-8")
        return r.stdout.strip() or "nogit"
    except OSError:
        return "nogit"


def files():
    workspace = _configured_workspace()
    for dirpath, dirnames, filenames in os.walk(REG):
        top = os.path.normcase(dirpath) == os.path.normcase(REG)
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS
                       and not (top and (d in EXCLUDE_TOP or d.startswith(EXCLUDE_TOP_PREFIX)))
                       and os.path.normcase(os.path.join(dirpath, d)) != workspace]
        for name in sorted(filenames):
            if os.path.splitext(name)[1] in EXCLUDE_EXT:
                continue
            path = os.path.join(dirpath, name)
            yield path, "reg/" + os.path.relpath(path, REG).replace(os.sep, "/")


def build(platform, skill_source, out_dir=None):
    out_dir = out_dir or os.path.join(ROOT, "fin_repo")
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d")
    out = os.path.join(out_dir, "reg-%s_%s_%s.zip" % (platform, stamp, commit_short()))
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for path, arc in files():
            if arc == "reg/SKILL.md":
                z.write(skill_source, arc)
            else:
                z.write(path, arc)
    h = hashlib.sha256()
    with open(out, "rb") as f:
        h.update(f.read())
    with io.open(out[:-4] + ".sha256.txt", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (h.hexdigest(), os.path.basename(out)))
    print(out, flush=True)
    return out


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    argv = list(sys.argv[1:] if argv is None else argv)
    # --到 <資料夾>：打包到別的地方（測試用暫存資料夾，不去動交付用的 fin_repo）
    out_dir = argv[argv.index("--到") + 1] if "--到" in argv and argv.index("--到") + 1 < len(argv) else None
    build("claude", os.path.join(REG, "SKILL.md"), out_dir)
    build("spade", os.path.join(REG, "platform", "SKILL.spade.md"), out_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
