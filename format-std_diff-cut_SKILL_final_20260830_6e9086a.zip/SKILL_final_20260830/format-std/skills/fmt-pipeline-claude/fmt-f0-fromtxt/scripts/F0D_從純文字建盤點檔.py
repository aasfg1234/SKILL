# -*- coding: utf-8 -*-
r"""
F0D：從純文字檔做出一份陽春的 F1_paragraphs.csv

    py F0D_從純文字建盤點檔.py <來源.txt> <輸出資料夾>

用途
    這台電腦沒有 Word 的時候，用真的規章全文（一行一段的 txt）
    做出可以餵給 F2、F3、F4 的盤點檔，測「編號與階層」那一段邏輯。

只填得出跟文字有關的欄位
    序號、位置、在表格內、開頭符號、開頭符號類型、前導空白、含Tab、全文、字數

格式欄位（字型、字級、縮排、行距…）一律留空
    **這種檔只能測編號與階層，不能測格式比對。** 要測格式必須用
    有 Word 的電腦跑 F1_格式盤點.bas。

編號分類跟 F1_格式盤點.bas 的 LeadMark 同一套規則，兩邊要一致。
"""

import csv
import io
import os
import sys

CN_LOW = "一二三四五六七八九十百千零兩"
CN_UPP = "壹貳參肆伍陸柒捌玖拾佰仟零"
UNITS = "篇編章節條項款目點"
DIG = "0123456789"
RM = "IVXLCDMivxlcdm"

COLS = ["序號", "位置", "在表格內", "樣式", "大綱層級",
        "是否清單", "清單類型", "清單層級", "清單樣板", "自動編號文字",
        "字型", "中文字型", "英數字型", "字級", "粗體", "斜體", "底線",
        "刪除線", "字色", "標示色",
        "對齊", "左縮排", "右縮排", "首行縮排", "行距規則", "行距", "段前", "段後",
        "段落網底", "段落下框線", "段前分頁", "與下段同頁", "段中不分頁",
        "開頭符號", "開頭符號類型", "階層數",
        "前導全形空格", "前導半形空格", "含Tab", "含手動換行", "全文", "字數"]


def tail_name(t):
    return {"、": "＋頓號", ".": "＋半形句點", "．": "＋全形句點",
            ",": "＋半形逗號", "，": "＋全形逗號"}.get(t, "＋" + t)


def run_kind(s):
    if any(c in "壹貳參肆伍陸柒捌玖拾佰仟" for c in s):
        return "大寫中文數字"
    if any(c in "一二三四五六七八九十百千兩" for c in s):
        return "中文數字"
    if any(c in DIG for c in s):
        return "數字"
    return "其他"


def letter_kind(s):
    if len(s) >= 2:
        if all(c in "IVXLCDM" for c in s):
            return "羅馬大寫"
        if all(c in "ivxlcdm" for c in s):
            return "羅馬小寫"
        return "其他"
    c = s[0]
    if "A" <= c <= "Z":
        return "英文大寫"
    if "a" <= c <= "z":
        return "英文小寫"
    return "其他"


def inside_kind(s):
    k = run_kind(s)
    if k == "數字":
        return "數字"
    if k == "中文數字":
        return "中文"
    if k == "大寫中文數字":
        return "大寫中文"
    k = letter_kind(s)
    if k in ("英文大寫", "羅馬大寫"):
        return "英文大寫"
    if k in ("英文小寫", "羅馬小寫"):
        return "英文小寫"
    return ""


def lead_mark(s):
    """回傳 (開頭符號, 開頭符號類型)。跟 F1 的 LeadMark 同一套規則。"""
    if not s:
        return "", "無"
    t = s.lstrip(" 　\t")
    if not t:
        return "", "無"

    if t[0] == "第":
        head = ""
        i = 1
        while i < len(t) and t[i] in DIG + CN_LOW + CN_UPP:
            head += t[i]
            i += 1
        if head and i < len(t) and t[i] in UNITS:
            kind = "數字" if head.isdigit() else "中文"
            return "第" + head + t[i], "第X" + t[i] + kind

    for op, cl, name in (("（", "）", "全形括號"), ("(", ")", "半形括號")):
        if t.startswith(op):
            j = t.find(cl) + 1
            if 3 <= j <= 8:
                ik = inside_kind(t[1:j - 1])
                if ik:
                    return t[:j], name + ik
            return "", "無"

    head = ""
    for c in t:
        if c in DIG + CN_LOW + CN_UPP:
            head += c
        else:
            break
    if head:
        tail = t[len(head):len(head) + 1]
        if tail in "、.．,，" and tail:
            return head + tail, run_kind(head) + tail_name(tail)
        return "", "無"

    head = ""
    for c in t:
        if ("A" <= c <= "Z") or ("a" <= c <= "z"):
            head += c
        else:
            break
    if not head:
        return "", "無"
    tail = t[len(head):len(head) + 1]
    if tail not in "、.．,，" or not tail:
        return "", "無"
    k = letter_kind(head)
    if k == "其他":
        return "", "無"
    return head + tail, k + tail_name(tail)


def main(src, out_dir):
    with io.open(src, encoding="utf-8", errors="replace") as f:
        lines = [ln.rstrip("\n").rstrip("\r") for ln in f]

    rows = []
    pos = 0
    no = 0
    for ln in lines:
        if not ln.strip():
            pos += len(ln) + 1
            continue
        no += 1
        text = ln.replace("\t", "[Tab]")
        mk, mk_type = lead_mark(ln)
        r = dict((c, "") for c in COLS)
        r.update({
            "序號": no, "位置": pos, "在表格內": "N",
            "是否清單": "N", "清單層級": 0,
            "開頭符號": mk, "開頭符號類型": mk_type, "階層數": 0,
            "前導全形空格": len(ln) - len(ln.lstrip("　")),
            "前導半形空格": len(ln) - len(ln.lstrip(" ")),
            "含Tab": "Y" if "\t" in ln else "N",
            "含手動換行": "N",
            "全文": text, "字數": len(text),
        })
        rows.append(r)
        pos += len(ln) + 1

    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)
    dst = os.path.join(out_dir, "F1_paragraphs.csv")
    with io.open(dst, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS, quoting=csv.QUOTE_ALL)
        w.writeheader()
        for r in rows:
            w.writerow(r)

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    print("讀了 %s" % src)
    print("寫出 %s，共 %d 段" % (dst, len(rows)))
    print()
    print("提醒：格式欄位全部是空的，這種檔只能測編號與階層。")
    print("      要測格式比對，必須用有 Word 的電腦跑 F1_格式盤點.bas。")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法：py F0D_從純文字建盤點檔.py <來源.txt> <輸出資料夾>")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
