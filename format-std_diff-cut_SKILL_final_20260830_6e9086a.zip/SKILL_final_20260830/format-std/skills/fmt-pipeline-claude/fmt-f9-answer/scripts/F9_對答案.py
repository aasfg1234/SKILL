# -*- coding: utf-8 -*-
r"""
F9：拿 F2、F3 的結果對答案卷

用法：
    py F9_對答案.py <測試資料夾> <答案卷.csv>

答案卷是 F0B 弄亂時留下的紀錄，每一處改動都有段落序號。
這支程式逐段比對，算出每一種亂象抓到幾成。

判定
    抓到   答案卷說這段亂，工具也標了它
    漏抓   答案卷說這段亂，工具沒標
    多抓   工具標了，但答案卷沒說那段亂（不一定是錯，原檔本來就可能亂）
"""

import csv
import io
import os
import sys
import collections

# 答案卷的亂象 -> 可由哪些獨立訊號抓到；任一命中即算抓到。
MAP = {
    "同階編號寫法混用": [("F3違規", ["同階兩種編號"]), ("F2變體", ["開頭符號類型"])],
    "括號全形半形混用": [("F3違規", ["同階兩種編號"]), ("F2變體", ["開頭符號類型"])],
    "縮排與階層矛盾": [("F3違規", ["同階縮排不一致"]), ("F2變體", ["左縮排", "首行縮排"])],
    "同階縮排不一致": [("F3違規", ["同階縮排不一致"]), ("F2變體", ["左縮排"])],
    "編號清單與純文字混用": [("F1欄位", ["是否清單=Y"])],
    "一段裡面部分粗體": [("F1欄位", ["粗體=混合", "斜體=混合", "底線=混合", "刪除線=混合", "字色=混合"])],
    "用空白排版": [("F1欄位", ["前導全形空格>0", "含Tab=Y"])],
    "章節標題字型字級不一致": [("F2變體", ["樣式", "字型", "字級"])],
    "同階字型字級不一致": [("F2變體", ["字型", "字級"])],
    "行距不一致": [("F2變體", ["行距規則", "行距"])],
    "段前段後不一致": [("F2變體", ["段前", "段後"])],
    "對齊方式不一致": [("F2變體", ["對齊"])],
    "斜體底線混用": [("F2變體", ["斜體", "底線"]), ("F1欄位", ["斜體=混合", "底線=混合"])],
    "字色標示混用": [("F2變體", ["字色", "標示色"]), ("F1欄位", ["標示色!=無", "標示色!=（繼承）"])],
    "刪除線顏色混用": [("F2變體", ["刪除線", "字色"]), ("F1欄位", ["刪除線=混合", "字色=混合"])],
    "首行右側縮排混用": [("F2變體", ["首行縮排", "右縮排"])],
    "段落框線網底混用": [("F2變體", ["段落網底", "段落下框線"]), ("F1欄位", ["段落網底!=無", "段落下框線!=無"])],
    "分頁控制不一致": [("F2變體", ["段前分頁", "與下段同頁", "段中不分頁"]), ("F1欄位", ["段前分頁=是"])],
    "樣式誤用": [("F2變體", ["樣式"])],
    "表格格式不一致": [("F1表格", ["網底!=無", "框線!=無"])],
}

lines = []


def say(s=""):
    lines.append(s)


def load(p):
    if not os.path.isfile(p):
        return []
    with io.open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def field_matches(row, signal):
    if "!=" in signal:
        field, expected = signal.split("!=", 1)
        return (row.get(field) or "") != expected
    if ">" in signal:
        field, expected = signal.split(">", 1)
        try:
            return float(row.get(field) or 0) > float(expected)
        except ValueError:
            return False
    if "=" in signal:
        field, expected = signal.split("=", 1)
        return (row.get(field) or "") == expected
    return False


def main(folder, ans_path):
    ans = load(ans_path)
    para = load(os.path.join(folder, "F1_paragraphs.csv"))
    bad = load(os.path.join(folder, "F3_階層違規.csv"))
    var = load(os.path.join(folder, "F2_變體清單.csv"))
    tables = load(os.path.join(folder, "F1_tables.csv"))

    if not ans or not para:
        say("找不到答案卷或 F1_paragraphs.csv")
        return None

    by_no = dict((str(r["序號"]), r) for r in para)
    by_target = dict((r.get("目標", ""), r) for r in tables)
    f3_by_no = collections.defaultdict(set)
    for b in bad:
        f3_by_no[str(b["序號"])].add(b["違規"])

    # F2 標成「少數」的那些寫法
    minority = collections.defaultdict(set)
    for v in var:
        if v.get("是否多數") == "N":
            minority[v["維度"]].add(v["寫法"])

    say("=" * 64)
    say("F9 對答案報告")
    say("測試資料夾：%s" % folder)
    say("答案卷：%s（%d 處改動）" % (ans_path, len(ans)))
    say("=" * 64)

    result = collections.defaultdict(lambda: {"總數": 0, "抓到": 0, "漏抓": [],
                                              "無法比對": 0})

    for a in ans:
        kind = a["亂象"]
        no = str(a["段落序號"])
        target = a.get("目標", "")
        r = by_no.get(no)
        st = result[kind]
        st["總數"] += 1

        if r is None and kind != "表格格式不一致":
            st["無法比對"] += 1
            continue

        hit = False
        for how, signals in MAP.get(kind, []):
            if how == "F3違規" and bool(f3_by_no.get(no, set()) & set(signals)):
                hit = True
            elif how == "F1欄位" and r is not None:
                hit = any(field_matches(r, s) for s in signals)
            elif how == "F2變體" and r is not None:
                hit = any((r.get(d) or "") in minority.get(d, set()) for d in signals)
            elif how == "F1表格":
                table_row = by_target.get(target)
                hit = table_row is not None and any(field_matches(table_row, s) for s in signals)
            if hit:
                break

        if hit:
            st["抓到"] += 1
        else:
            shown_no = no or target
            shown_text = ((r.get("全文") or "")[:36] if r is not None
                          else (by_target.get(target, {}).get("文字") or "")[:36])
            st["漏抓"].append((shown_no, a["做了什麼"], shown_text))

    say()
    say("逐項成績")
    say("   %-24s %5s %5s %5s %7s" % ("亂象", "總數", "抓到", "漏抓", "抓到率"))
    say("   " + "-" * 54)
    tot = hit_tot = 0
    for k in sorted(result, key=lambda x: -result[x]["總數"]):
        st = result[k]
        n, h = st["總數"], st["抓到"]
        tot += n
        hit_tot += h
        say("   %-24s %5d %5d %5d %6.0f%%"
            % (k, n, h, n - h, 100.0 * h / n if n else 0))
    say("   " + "-" * 54)
    say("   %-24s %5d %5d %5d %6.0f%%"
        % ("合計", tot, hit_tot, tot - hit_tot,
           100.0 * hit_tot / tot if tot else 0))

    say()
    say("漏抓的細節（每一種列前三筆）")
    any_miss = False
    for k in sorted(result, key=lambda x: -len(result[x]["漏抓"])):
        miss = result[k]["漏抓"]
        if not miss:
            continue
        any_miss = True
        say()
        say("   【%s】漏抓 %d 筆" % (k, len(miss)))
        for no, what, txt in miss[:3]:
            say("      第 %s 段　%s" % (no, what))
            say("         %s" % txt)
    if not any_miss:
        say("   沒有漏抓")

    # 多抓
    say()
    say("工具標了、但答案卷沒說那段亂的")
    ans_no = set(str(a["段落序號"]) for a in ans)
    extra = [n for n in f3_by_no if n not in ans_no]
    say("   F3 階層違規多標了 %d 段" % len(extra))
    say("   （不一定是錯。底稿本身就可能有亂象，那不是我弄的）")
    for n in extra[:5]:
        r = by_no.get(n, {})
        say("      第 %s 段　%s　%s"
            % (n, "、".join(f3_by_no[n]), (r.get("全文") or "")[:34]))

    say()
    say("=" * 64)
    return result


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法：py F9_對答案.py <測試資料夾> <答案卷.csv>")
        sys.exit(1)
    res = main(sys.argv[1], sys.argv[2])
    report = "\n".join(lines)
    with io.open(os.path.join(sys.argv[1], "F9_對答案報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
