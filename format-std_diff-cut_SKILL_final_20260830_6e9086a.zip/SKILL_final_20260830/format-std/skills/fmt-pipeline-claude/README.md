# 格式標準化產線　CLAUDE版

把格式混亂的 Word 內規統一成一套標準格式。

## 怎麼裝

把 `fmt-*` 這些資料夾整包放進 Claude Code 的 skill 目錄。
架構 skill 是 `fmt-pipeline`，其餘是它會呼叫的階段 skill。

## 怎麼用

跟它說「幫我做格式標準化」，或直接指定階段，例如「跑 F2」。

## 七個階段

| 階段 | skill | 誰做 |
|---|---|---|
| F1 | `fmt-f1-inventory` | VBA，要有 Word |
| F0D | `fmt-f0-fromtxt` | 只在拿不到 Word 時 |
| F2 | `fmt-f2-analyze` | Python |
| F3 | `fmt-f3-hierarchy` | Python |
| F3 | `fmt-f3-standard` | 人填網頁表單 |
| F4 | `fmt-f4-compare` | Python |
| F4 | `fmt-f4-apply` | VBA，要有 Word |
| F9 | `fmt-f9-answer` | 只在驗證程式時 |

## 四件不能妥協的事

一、**標準由人訂**，多數決在文件被汙染過半時會選錯邊
二、**比對與套用分開**，中間要人複核簽核
三、**改 Word 一定開追蹤修訂**，原檔不動
四、**階層編號全線統一**：章＝第1階、節＝第2階、條列從第3階起

## 已知限制

- 三支 `.bas` 沒有在 Word 裡編譯過
- `F4_套用.bas` 的中文數字常數（TradChinNum2＝34、TradChinNum3＝35）沒實測，
  **先跑 `F4_測試編號樣式` 巨集確認**
- `.bas` 換行必須是 CRLF，混用會匯入失敗
