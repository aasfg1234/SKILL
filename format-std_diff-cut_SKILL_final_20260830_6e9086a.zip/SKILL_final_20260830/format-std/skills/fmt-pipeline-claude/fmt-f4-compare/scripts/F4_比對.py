# -*- coding: utf-8 -*-
r"""
F4 第一步：比對

    py F4_比對.py <資料夾> <標準格式表.csv>

讀進 F1 的盤點結果與人訂的標準格式表，算出「哪一段要改什麼」。
這一步不碰 Word，只產清單。清單給人複核、簽核，過了才跑 F4_套用.bas。

輸出
    <資料夾>\F4_改動清單.csv   每一列是一段的一項要改
    <資料夾>\F4_比對報告.txt   統計與提醒

三條規矩，全部照標準格式表裡人訂的來
    起點    預設從第一個第1階開始改，前面的封面目錄不動
    前言    有編號段落底下那段沒編號的說明文字，照哪一階排
    階層異常  保留 F3-1 階層，遇到跳階或編號類不同時要人工、自動或停止
"""

import collections
import csv
import io
import os
import re
import sys

lines = []


def say(s=""):
    lines.append(s)


def num(v, d=0.0):
    try:
        return float(str(v).strip())
    except (TypeError, ValueError):
        return d


def load(path):
    if not os.path.isfile(path):
        return []
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


# ---------------------------------------------------------------- 標準格式表

def read_std(path):
    """讀標準格式表。回傳 (通則, 模式, 各階層設定)。"""
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))

    rules = {}
    modes = {"起點": "first", "前言": "follow", "階層異常處理": "manual"}
    hierarchy_seen = False
    legacy_skip = ""
    legacy_mismatch = ""
    layers = {}
    head = None
    in_layer = False

    for r in rows:
        if not r or not r[0]:
            continue
        if r[0] == "通則" and len(r) > 2:
            rules[r[1]] = (r[2] == "要求")
        elif r[0] in modes and len(r) > 2 and r[1] == "模式":
            modes[r[0]] = r[2]
            if r[0] == "階層異常處理":
                hierarchy_seen = True
        elif r[0] == "跳階處理" and len(r) > 2 and r[1] == "模式":
            legacy_skip = r[2]
        elif r[0] == "階層對不上處理" and len(r) > 2 and r[1] == "模式":
            legacy_mismatch = r[2]
        elif r[0] == "階層" and len(r) > 3:
            head = r
            in_layer = True
        elif in_layer and head:
            layers[r[0]] = dict(zip(head[1:], r[1:]))

    # 舊版 CSV 有兩個分開的設定。停止優先，其次保留自動調整意圖；
    # 舊的 pull 不再搬動 F3 階層，改採安全的人工確認模式。
    if not hierarchy_seen:
        if legacy_skip == "stop":
            modes["階層異常處理"] = "stop"
        elif legacy_mismatch == "adjust":
            modes["階層異常處理"] = "adjust"
    if modes["階層異常處理"] not in ("manual", "adjust", "stop"):
        modes["階層異常處理"] = "manual"

    return rules, modes, layers


# ---------------------------------------------------------------- 編號寫法

CN = "一二三四五六七八九十"
CN_UP = "壹貳參肆伍陸柒捌玖拾"
ROMAN = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"),
         (90, "XC"), (50, "L"), (40, "XL"), (10, "X"), (9, "IX"),
         (5, "V"), (4, "IV"), (1, "I")]


def cn_num(v, table):
    """1..99 轉中文數字。超過範圍回空字串，讓呼叫端知道轉不了。"""
    if not 1 <= v <= 99:
        return ""
    ten, one = divmod(v, 10)
    if ten == 0:
        return table[one - 1]
    if ten == 1:
        return table[9] + (table[one - 1] if one else "")
    return table[ten - 1] + table[9] + (table[one - 1] if one else "")


def cn_value(s, table):
    """中文數字轉回阿拉伯數字。認不出來回 0。"""
    if not s:
        return 0
    if len(s) == 1:
        if s == table[9]:
            return 10
        return table.index(s) + 1 if s in table else 0
    if s[0] == table[9]:
        return 10 + (table.index(s[1]) + 1 if s[1] in table else 0)
    if len(s) >= 3 and s[1] == table[9]:
        tens = table.index(s[0]) + 1 if s[0] in table else 0
        one = table.index(s[2]) + 1 if s[2] in table else 0
        return tens * 10 + one
    return 0


def roman_num(v):
    if not 1 <= v <= 3999:
        return ""
    out = ""
    for n, s in ROMAN:
        while v >= n:
            out += s
            v -= n
    return out


def roman_value(s):
    vals = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
    total = 0
    prev = 0
    for ch in reversed(s.upper()):
        v = vals.get(ch, 0)
        total += -v if v < prev else v
        prev = max(prev, v)
    return total


def mark_value(mark):
    """從實際的編號字串抓出它是第幾個。抓不到回 0。"""
    core = (mark or "").strip()
    core = re.sub(r"^第", "", core)
    core = re.sub(r"[篇編章節條項款目點]$", "", core)
    core = re.sub(r"^[（(]", "", core)
    core = re.sub(r"[）)]$", "", core)
    core = re.sub(r"[、.．,，]$", "", core)
    if not core:
        return 0
    if core.isdigit():
        return int(core)
    if all(c in CN_UP for c in core):
        return cn_value(core, CN_UP)
    if all(c in CN for c in core):
        return cn_value(core, CN)
    if all(c.upper() in "IVXLCDM" for c in core) and len(core) >= 2:
        return roman_value(core)
    if len(core) == 1 and core.isalpha():
        return ord(core.upper()) - 64
    return 0


BODY_KEY = {"中文數字": "中文", "大寫中文數字": "大寫中文", "數字": "數字",
            "英文大寫": "英文大寫", "英文小寫": "英文小寫",
            "羅馬大寫": "羅馬大寫", "羅馬小寫": "羅馬小寫",
            "中文": "中文", "大寫中文": "大寫中文"}

TAIL = {"頓號": "、", "半形句點": ".", "全形句點": "．",
        "半形逗號": ",", "全形逗號": "，"}


def render_mark(style, v):
    """照指定寫法把第 v 個編號寫出來。做不到回空字串。"""
    if style == "無編號" or v <= 0:
        return ""

    body = {"中文": cn_num(v, CN),
            "大寫中文": cn_num(v, CN_UP),
            "數字": str(v),
            "英文大寫": chr(64 + v) if 1 <= v <= 26 else "",
            "英文小寫": chr(96 + v) if 1 <= v <= 26 else "",
            "羅馬大寫": roman_num(v),
            "羅馬小寫": roman_num(v).lower()}

    m = re.match(r"^第X(.)(中文|數字)$", style)
    if m:
        b = body["中文"] if m.group(2) == "中文" else str(v)
        return "第%s%s" % (b, m.group(1)) if b else ""

    m = re.match(r"^(全形|半形)括號(.+)$", style)
    if m:
        op, cl = ("（", "）") if m.group(1) == "全形" else ("(", ")")
        b = body.get(BODY_KEY.get(m.group(2), ""), "")
        return op + b + cl if b else ""

    m = re.match(r"^(.+?)＋(頓號|半形句點|全形句點|半形逗號|全形逗號)$", style)
    if m:
        b = body.get(BODY_KEY.get(m.group(1), ""), "")
        return b + TAIL[m.group(2)] if b else ""

    return ""


def cur_mark(r):
    """這一段現在的編號長什麼樣。

    自動清單的編號不是文字，是 Word 畫上去的，所以要看「自動編號文字」。
    F1 的 VBA 版會把 ListFormat.ListString 寫進那一欄，號碼直接拿得到，
    不必自己推。
    """
    if r.get("是否清單") == "Y":
        auto = (r.get("自動編號文字") or "").strip()
        if auto:
            return auto
    return (r.get("開頭符號") or "").strip()


# ---------------------------------------------------------------- 比對

# 標準格式表的欄 -> F1 的欄。左邊是「應該」，右邊是「現在」。
FORMAT_MAP = [
    ("中文字型", "中文字型", "text"),
    ("英數字型", "英數字型", "text"),
    ("字級", "字級", "num"),
    ("粗體", "粗體", "yn"),
    ("對齊", "對齊", "text"),
    ("左縮排pt", "左縮排", "num"),
    ("首行縮排pt", "首行縮排", "num"),
    ("行距規則", "行距規則", "text"),
    ("段前pt", "段前", "num"),
    ("段後pt", "段後", "num"),
    ("字色", "字色", "text"),
]


UNREADABLE = ("混合", "（繼承）", "", None)

# 通則明文禁止「同一段混用字型字級」，這幾欄出現「混合」要整段統一。
# 粗體、斜體、底線、刪除線、字色的混合是通則允許的強調，不在這裡面。
MIXED_BANNED = ("中文字型", "英數字型", "字級")

# 段首空白用得到的字元。全形空格、半形空格、Tab。
LEAD_CHARS = " 　\t"


def is_mark_body(s):
    """括號裡面這一串是不是編號。

    跟 F1_格式盤點.bas 的 IsMarkBody 同一套規則，兩邊要一致。
    全是數字、全是中文數字、單一個英文字母、或兩個字以上的羅馬數字。
    """
    if not s or len(s) > 6:
        return False
    if all(c in "0123456789" for c in s):
        return True
    if all(c in "一二三四五六七八九十百千零兩壹貳參肆伍陸柒捌玖拾佰仟" for c in s):
        return True
    if len(s) == 1 and s.isascii() and s.isalpha():
        return True
    return all(c in "IVXLCDMivxlcdm" for c in s)


def mark_class(t):
    """把編號寫法歸成「類」。跟 F3_階層分析.py 的 mark_class 同一套規則。

    F4 靠它判斷「現在的編號跟標準要的，是不是同一種東西」。
    同一類只是寫法不同（1. 對 1、），可以放心改。
    不同類代表這一段的編號本來就屬於別的階，硬改會動到條號。
    """
    t = t or "無"
    if t.startswith("第X") and len(t) >= 3:
        return t[:3]
    if "括號" in t:
        if "大寫中文" in t:
            return "括號大寫中文"
        if "英文大寫" in t:
            return "括號英文大寫"
        if "英文小寫" in t:
            return "括號英文小寫"
        if "數字" in t:
            return "括號數字"
        return "括號中文"
    for pre in ("大寫中文數字", "中文數字", "數字",
                "羅馬大寫", "羅馬小寫", "英文大寫", "英文小寫"):
        if t.startswith(pre):
            return pre
    if t.startswith("英文字母"):
        return "英文大寫"
    return "無"


BR_CLASS = {"數字": "括號數字", "大寫中文數字": "括號大寫中文",
            "中文數字": "括號中文", "英文大寫": "括號英文大寫",
            "英文小寫": "括號英文小寫"}


def class_of_mark(raw):
    """直接從編號字串推出它是哪一類。

    自動清單只拿得到 ListString（例如「1.」），沒有「開頭符號類型」那一欄，
    所以要從字面推。
    """
    s = (raw or "").strip()
    if not s:
        return "無"
    m = re.match(r"^第.+?([篇編章節條項款目點])$", s)
    if m:
        return "第X" + m.group(1)
    br = re.match(r"^[（(](.+)[）)]$", s)
    core = br.group(1) if br else re.sub(r"[、.．,，]$", "", s)
    if not core:
        return "無"
    if core.isdigit():
        base = "數字"
    elif all(c in CN_UP for c in core):
        base = "大寫中文數字"
    elif all(c in CN for c in core):
        base = "中文數字"
    elif len(core) >= 2 and all(c.upper() in "IVXLCDM" for c in core):
        base = "羅馬大寫" if core.isupper() else "羅馬小寫"
    elif len(core) == 1 and core.isalpha():
        base = "英文大寫" if core.isupper() else "英文小寫"
    else:
        return "無"
    return BR_CLASS.get(base, "括號中文") if br else base


TOC_TAIL = re.compile(r"\[Tab\]\s*\d{1,4}\s*$")


def is_toc(r):
    """這一段是不是目錄。

    真檔前面有一整份目錄，每一行長得跟章節標題一模一樣：

        第一章[Tab]保險代理業務區[Tab]7
        第一節[Tab]網路投保業務定義[Tab]8

    不擋掉的話，「從第一個第1階開始改」會把起點定在目錄第一行，
    然後整份目錄被套上章標題的格式。實測真檔有 37 行長這樣。

    兩個線索
        樣式叫「目錄 N」或「TOC N」  Word 內建的目錄樣式，最可靠
        結尾是定位點加頁碼            樣式讀不到時的備援
    """
    sty = (r.get("樣式") or "").strip()
    if sty.startswith("目錄") or sty.upper().startswith("TOC"):
        return True
    return bool(TOC_TAIL.search(r.get("全文") or ""))


def lead_space(r):
    """回傳 (段首空白的樣子, 段落中間有沒有 Tab)。

    F1 把 Tab 寫成 [Tab] 這個標記，所以要照標記找，不是找真的 Tab 字元。
    段首空白可以自動刪；段落中間的 Tab 可能在排對齊，不能亂刪。
    """
    t = r.get("全文") or ""
    lead = ""
    i = 0
    while i < len(t):
        if t[i] in " 　":
            lead += t[i]
            i += 1
        elif t.startswith("[Tab]", i):
            lead += "[Tab]"
            i += 5
        else:
            break
    mid_tab = "[Tab]" in t[i:]
    return lead, mid_tab


def same_value(kind, want, got):
    """現在的值跟標準一不一樣。讀不到的值另外處理，不走這裡。"""
    if got in UNREADABLE:
        return False
    if kind == "num":
        return abs(num(want) - num(got)) < 0.05
    if kind == "yn":
        return (want or "否") == got
    return (want or "") == got


def main(folder, std_path):
    std = os.path.abspath(std_path)
    rules, modes, layers = read_std(std)
    if not layers:
        say("讀不到標準格式表的階層那一段：%s" % std)
        return None

    para = load(os.path.join(folder, "F1_paragraphs.csv"))
    lv = load(os.path.join(folder, "F3_階層清單.csv"))
    if not para:
        say("找不到 F1_paragraphs.csv。請先跑 F1_格式盤點.bas。")
        return None
    if not lv:
        say("找不到 F3_階層清單.csv。請先跑 F3_階層分析.py。")
        return None

    lv_by_no = dict((r["序號"], r) for r in lv)

    say("=" * 64)
    say("F4 比對報告")
    say("資料夾：%s" % folder)
    say("標準格式表：%s" % std)
    say("起點：%s　前言：%s　階層異常：%s"
        % (modes["起點"], modes["前言"], modes["階層異常處理"]))
    say("=" * 64)

    on = dict((k, v.get("這本用不用") != "不用") for k, v in layers.items())

    # ---------- 一、決定每一段的階層與角色 ----------
    n_toc = sum(1 for r in para if is_toc(r))

    start_at = None
    if modes["起點"] == "first":
        for r in para:
            # 目錄那幾行長得跟章節標題一樣，不能拿來當起點
            if is_toc(r):
                continue
            # 表格裡的章節標題也不算。真檔開頭有一張「各職務人員優先
            # 閱讀之章節」的表，裡面把十二章的名稱全列了一遍。
            if r.get("在表格內") == "Y":
                continue
            if (lv_by_no.get(r["序號"], {}).get("階層") or "") == "1":
                start_at = r["序號"]
                break
        if start_at is None:
            say()
            say("[停] 整份文件找不到第1階。第1階預設是「第X章」。")
            say("     不知道從哪裡開始改，所以不產改動清單。")
            say("     要嘛把第1階的編號寫法改成這份文件真的有的寫法，")
            say("     要嘛把「從哪裡開始改」設成「整份文件從頭改」。")
            return None

    started = (modes["起點"] == "all")
    plan = []
    prev_num_lv = None
    skips = []

    # 改成 Word 自動清單之後，號碼會由 Word 自己算：
    # 同一階往下數，只要出現更淺的一階就重新從 1 開始。
    # 先算一遍，跟文件現在寫的號碼比，才知道會不會被改號。
    counters = [0] * 12
    auto_no = {}
    for r in para:
        h = lv_by_no.get(r["序號"], {})
        raw = h.get("階層")
        if not (str(raw).isdigit() and int(raw) > 0):
            continue
        k = int(raw)
        for d in range(k + 1, 12):
            counters[d] = 0
        counters[k] += 1
        auto_no[r["序號"]] = counters[k]

    for r in para:
        no = r["序號"]
        h = lv_by_no.get(no, {})
        raw = h.get("階層")
        raw = int(raw) if str(raw).isdigit() and int(raw) > 0 else 0

        if not started:
            if no == start_at:
                started = True
            else:
                plan.append((r, 0, "起點之前"))
                continue

        # 目錄的格式本來就跟本文不一樣，不要套本文的標準
        if is_toc(r):
            plan.append((r, "目錄", "目錄"))
            continue

        if r.get("在表格內") == "Y":
            plan.append((r, "表格內", "表格內"))
            continue

        if raw == 0:
            if prev_num_lv:
                plan.append((r, prev_num_lv, "前言"))
            else:
                plan.append((r, "內文", "內文"))
            continue

        eff = raw
        # 第1階是章、第2階是節。有的章底下沒有節，直接接條列，
        # 那是正常的，不是跳階。只有條列之間（第3階以下）才算。
        if prev_num_lv and prev_num_lv >= 3 and eff > prev_num_lv + 1:
            skips.append((no, prev_num_lv, eff, (r.get("全文") or "")[:30]))
        prev_num_lv = eff
        plan.append((r, eff, "標題"))

    stop_mismatches = []
    if modes["階層異常處理"] == "stop":
        for r, tgt, role in plan:
            if role != "標題" or not isinstance(tgt, int):
                continue
            spec = layers.get("第%d階" % tgt)
            if not spec:
                continue
            want_style = spec.get("編號寫法") or "無編號"
            want_cls = mark_class(want_style)
            got_style = r.get("開頭符號類型") or "無"
            got_cls = mark_class(got_style)
            if got_cls == "無":
                got_cls = class_of_mark(cur_mark(r))
            if (want_style != "無編號" and got_cls != "無"
                    and got_cls != want_cls):
                stop_mismatches.append(
                    (r["序號"], tgt, cur_mark(r), want_style,
                     (r.get("全文") or "")[:30]))

    if modes["階層異常處理"] == "stop" and (skips or stop_mismatches):
        say()
        say("[停] 階層異常處理設成「停止」，沒有產生改動清單。")
        say("     跳階 %d 處，編號類跟目標階層不同 %d 處。"
            % (len(skips), len(stop_mismatches)))
        for no, a, b, t in skips:
            say("     第 %s 段　第 %d 階 -> 第 %d 階　%s" % (no, a, b, t))
        for no, tgt, got, want, text in stop_mismatches:
            say("     第 %s 段　%s -> 第%d階標準 %s　%s"
                % (no, got or "（無）", tgt, want, text))
        return None

    # ---------- 二、逐段比對 ----------
    out = []
    missing = set()
    protect = set()
    for b in load(os.path.join(folder, "F3_階層違規.csv")):
        if b.get("違規") == "疑似缺少父階編號" and b.get("相關序號"):
            protect.add(str(b["相關序號"]))

    def add(r, tgt, role, item, now, want, note=""):
        out.append({"序號": r["序號"], "位置": r.get("位置", ""),
                    "目標階層": tgt, "角色": role, "項目": item,
                    "現在": now, "應該": want, "說明": note,
                    "全文前30字": (r.get("全文") or "")[:30]})

    for r, tgt, role in plan:
        if role in ("起點之前", "目錄"):
            continue
        if r["序號"] in protect:
            add(r, tgt, role, "疑似缺少父階編號：導入句", "這一段先不要動",
                "人工補上父階編號",
                "這是 F3 判定漏寫父階編號的那句導入句。補完編號之前，"
                "它的階層是不確定的，不可以自動改格式。")
            continue

        if role == "表格內":
            spec_name = "表格內"
        elif role == "內文":
            spec_name = "內文"
        elif role == "前言":
            if modes["前言"] == "keep":
                continue
            spec_name = "內文"
        else:
            spec_name = "第%d階" % tgt

        spec = layers.get(spec_name)
        if spec is None:
            add(r, spec_name, role, "階層", "第 %s 階" % tgt,
                "（標準格式表沒有這一階）",
                "文件比標準深。把那一階打開，或回到 F3-1 重新確認階層。")
            continue
        if not on.get(spec_name, True):
            add(r, spec_name, role, "階層", spec_name, "（這本設成不用）",
                "這一階在標準格式表設成不用，但文件裡有。")
            continue

        # --- 編號 ---
        mark_fixed = False      # 這一段的編號已經有一列在改了嗎

        # 自動清單要轉成純文字時，「編號機制」那一列本身就會把編號
        # 用標準寫法打上去，不需要再有一列「編號寫法」。兩列都去動
        # 同一個位置，第二列一定失敗。
        to_plain = (role == "標題" and r.get("是否清單") == "Y"
                    and spec.get("用Word自動清單") == "否")

        # 反方向也一樣：要轉成 Word 自動清單的段落，打出來的編號會被刪掉，
        # 再列一次「編號寫法」等於兩列動同一個位置，第二列必定失敗。
        # 實測 3 段報「文字對不上」。
        to_auto = (role == "標題" and r.get("是否清單") != "Y"
                   and spec.get("用Word自動清單") == "是")

        if role == "標題":
            new = None
            want_style = spec.get("編號寫法") or "無編號"
            got_style = r.get("開頭符號類型") or "無"
            adjust_mismatch = (modes["階層異常處理"] == "adjust")
            # 「無」代表根本沒抓到編號，那不是「屬於別的階」，
            # 要走原本的流程報「算不出第幾個」，不要歸成階層對不上。
            same_class = (mark_class(got_style) == mark_class(want_style)
                          or mark_class(got_style) == "無")

            # 類別不同時由標準格式表決定：安全模式交給人；自動模式則
            # 相信 F3 的相對階層，直接套用目標階層的標準編號寫法。
            #
            # 這是 F3 相對階層對上 F4 絕對標準表的結果：某一節少用了一層，
            # 底下的 1、 就被提到第4階，而標準表第4階是 (一)。真的照改，
            # 同一份文件的 1、 會變成有的不動、有的變成 (一)。
            if (not to_plain and not to_auto and want_style != "無編號"
                    and got_style != want_style and not same_class
                    and not adjust_mismatch):
                add(r, spec_name, role, "階層對不上",
                    "%s（%s類）" % (r.get("開頭符號") or "（無）",
                                    mark_class(got_style)),
                    "第%s階的標準是 %s" % (tgt, want_style),
                    "這一段的編號類跟這一階的標準不同，硬改會動到條號。"
                    "多半是這個章節少用了一層。要人決定。")
                mark_fixed = True

            if (not to_plain and not to_auto and want_style != "無編號"
                    and got_style != want_style
                    and (same_class or adjust_mismatch)):
                # 一定要用 cur_mark。自動清單的編號不在「開頭符號」那一欄，
                # 直接讀那一欄會拿到空字串，整段被誤判成「算不出第幾個」。
                v = mark_value(cur_mark(r))
                new = render_mark(want_style, v)
                # 寫法名稱不同但字面一樣（舊盤點檔的「英文字母」對上新的
                # 「英文大寫」），文字沒有要動，不必列成改動。
                if new and new == cur_mark(r):
                    new = None
            if (not to_plain and not to_auto and want_style != "無編號"
                    and got_style != want_style and new is not None):
                add(r, spec_name, role, "編號寫法",
                    cur_mark(r) or "（無）",
                    new or ("（" + want_style + "，算不出第幾個）"),
                    ("標準格式表設定：保留 F3-1 階層並直接套用該階標準。"
                     if new and not same_class else
                     "" if new else "抓不到原本是第幾個，要人工填。"))
                mark_fixed = True

            # 純文字 -> Word 自動清單
            if spec.get("用Word自動清單") == "是" and r.get("是否清單") != "Y":
                now_v = mark_value(cur_mark(r))
                will_v = auto_no.get(r["序號"], 0)
                if now_v and will_v and now_v != will_v:
                    # 文件自己在這裡重新起算，Word 不會。硬轉會改到號碼。
                    add(r, spec_name, role, "編號機制：會變號",
                        "現在寫 %d" % now_v,
                        "轉成自動清單會變 %d" % will_v,
                        "文件在這裡自己重新從 1 起算。轉成自動清單號碼會被改掉，"
                        "要人先確認這裡是不是少了一階。")
                else:
                    add(r, spec_name, role, "編號機制", "純文字",
                        "Word自動清單：%s" % spec_name,
                        "套用時會刪掉打出來的編號，改掛標準清單樣板的第 %d 階。"
                        % tgt)

            # Word 自動清單 -> 純文字
            if spec.get("用Word自動清單") == "否" and r.get("是否清單") == "Y":
                v = mark_value(cur_mark(r))
                # 人工確認模式：類別不同就原樣搬過去，避免條號暗中改變。
                # 自動調整模式：依目標階層標準重畫編號。
                auto_cls = class_of_mark(cur_mark(r))
                if (want_style != "無編號"
                        and (adjust_mismatch
                             or auto_cls == mark_class(want_style))):
                    txt = render_mark(want_style, v)
                else:
                    txt = cur_mark(r)
                if want_style == "無編號":
                    add(r, spec_name, role, "編號機制", "Word自動清單",
                        "純文字：（不編號）", "只把清單編號拿掉，不補文字。")
                elif txt:
                    add(r, spec_name, role, "編號機制", "Word自動清單",
                        "純文字：%s" % txt,
                        "把 Word 畫的編號拿掉，改打成文字。號碼取自 Word 現在顯示的值。")
                else:
                    add(r, spec_name, role, "編號機制：算不出號碼",
                        "Word自動清單", "純文字：（算不出第幾個）",
                        "盤點檔的「自動編號文字」是空的，讀不到 Word 現在顯示第幾號。"
                        "請用 VBA 版 F1 重新盤點。")

        # --- 前言的縮排跟著它所屬那一階的文字位置 ---
        pairs = list(FORMAT_MAP)
        if role == "前言" and modes["前言"] == "follow" and isinstance(tgt, int):
            host = layers.get("第%d階" % tgt, {})
            pairs = [p for p in pairs if p[0] != "左縮排pt"]
            want_ind = host.get("清單文字位置pt") or host.get("左縮排pt") or "0"
            if not same_value("num", want_ind, r.get("左縮排")):
                add(r, spec_name, role, "左縮排", r.get("左縮排"), want_ind,
                    "前言跟著第 %d 階的文字位置對齊" % tgt)

        # --- 逐項比字型字級縮排 ---
        for want_col, got_col, kind in pairs:
            if got_col not in r:
                missing.add(got_col)     # 舊版盤點檔沒這一欄，不能當成有問題
                continue
            want = spec.get(want_col)
            if want in (None, ""):
                continue
            if want_col == "英數字型" and want == "同中文字型":
                want = spec.get("中文字型")
            got = r.get(got_col)
            if got == "混合":
                # 「混合」不是讀不到，是這一段裡面前後不一致。兩件事要分開。
                if want_col in MIXED_BANNED:
                    add(r, spec_name, role, "段內混用：" + got_col, "混合", want,
                        "通則禁止同一段混用字型字級。整段統一成標準值。")
                else:
                    add(r, spec_name, role, "段內強調：" + got_col, "混合", want,
                        "通則允許用粗體斜體底線強調，所以不自動改。人看一下是不是"
                        "殘留的修訂痕跡。")
            elif got in UNREADABLE:
                add(r, spec_name, role, "讀不到：" + got_col, got or "（空白）",
                    want, "盤點時讀不到這一段的值，要人工看。")
            elif not same_value(kind, want, got):
                add(r, spec_name, role, got_col, got, want)

        if spec.get("行距規則") in ("固定行高", "最小行高"):
            if not same_value("num", spec.get("行距值"), r.get("行距")):
                add(r, spec_name, role, "行距", r.get("行距"), spec.get("行距值"))

        # --- 通則 ---
        if rules.get("禁止用空格或 Tab 排版"):
            lead, mid_tab = lead_space(r)
            if mid_tab:
                # 段落中間的 Tab 可能在排欄位對齊，刪掉會整欄歪掉
                add(r, spec_name, role, "通則：段中Tab", "段落中間有 Tab",
                    "人工判斷", "可能在排對齊。刪掉之前要看上下文。")
            elif lead:
                add(r, spec_name, role, "通則：段首空白", lead, "刪掉",
                    "拿空白當縮排。這一階的左縮排另有一列會設成標準值，"
                    "段首空白是多餘的。")
        if rules.get("禁止段落內手動換行") and r.get("含手動換行") == "Y":
            add(r, spec_name, role, "通則：手動換行",
                "有 Shift+Enter", "拆成兩段或刪掉")
        # 「編號寫法」那一列如果已經在改這個編號了，就不要再列一次。
        # 兩列都去改同一個位置，第二列的文字比對會對不上。
        if rules.get("括號一律半形") and not mark_fixed:
            got_mk = (r.get("開頭符號") or "").strip()
            if got_mk.startswith("（") and got_mk.endswith("）"):
                inner = got_mk[1:-1]
                if is_mark_body(inner):
                    add(r, spec_name, role, "通則：全形括號", got_mk,
                        "(" + inner + ")",
                        "只改段首這一個。段落中間的全形括號多半是插入語，不動。")
                else:
                    add(r, spec_name, role, "通則：全形括號存疑", got_mk,
                        "人工判斷", "括號裡不像編號，不敢自動改。")

    # ---------- 二之一、把 F3 抓到的「疑似缺少父階編號」帶進來 ----------
    #
    # 這不是格式問題，是原文漏寫了一個編號。它不在逐段格式比對的範圍裡，
    # 但複核的人只看改動清單，所以要一起列出來，不然會漏掉。
    # F4_套用.bas 不會自動改這一項，只會記在套用記錄裡。
    in_range = dict((r["序號"], (r, tgt, role))
                    for r, tgt, role in plan if role != "起點之前")
    miss_parent = 0
    for b in load(os.path.join(folder, "F3_階層違規.csv")):
        if b.get("違規") != "疑似缺少父階編號":
            continue
        hit = in_range.get(b.get("序號"))
        if hit is None:
            continue
        r, tgt, role = hit
        miss_parent += 1
        add(r, tgt, role, "疑似缺少父階編號", "這裡沒有父階編號",
            "人工補一個父階編號", b.get("說明", ""))

    # ---------- 三、報告 ----------
    changed = set(o["序號"] for o in out)
    body = [p for p in plan if p[2] != "起點之前"]
    skipped = [p for p in plan if p[2] == "起點之前"]

    say()
    say("1. 範圍")
    say("   全文 %d 段" % len(plan))
    say("   起點之前不動 %d 段" % len(skipped))
    if n_toc:
        say("   認定為目錄不動 %d 段（樣式是目錄，或結尾是定位點加頁碼）" % n_toc)
    say("   要比對的 %d 段" % len(body))
    if body:
        say("   起點是第 %s 段：%s"
            % (body[0][0]["序號"], (body[0][0].get("全文") or "")[:40]))

    say()
    say("2. 每一階各幾段（標題與它的前言算在同一階）")
    cc = collections.Counter(str(p[1]) for p in body)
    for k in sorted(cc, key=lambda x: (not x.startswith("第"), x)):
        say("   %-8s %4d 段" % (k, cc[k]))

    say()
    say("3. 角色")
    for k, v in collections.Counter(p[2] for p in body).most_common():
        say("   %-8s %4d 段" % (k, v))

    if missing:
        say()
        say("   [注意] 盤點檔沒有這幾欄，這次沒比：%s" % "、".join(sorted(missing)))
        say("          請用新版 F1_格式盤點.bas 重新盤點。")

    def bucket(o):
        """F4_套用.bas 會不會自動改這一項。三邊要一致。"""
        i = o["項目"]
        if i.startswith("讀不到："):
            return "讀不到"
        if (i.startswith("段內強調：") or i.startswith("編號機制：")
                or i == "階層對不上" or i.startswith("疑似缺少父階編號")
                or i.startswith("通則：段中Tab") or i.startswith("通則：全形括號存疑")
                or i in ("通則：手動換行", "疑似缺少父階編號", "階層")):
            return "要人看"
        if "算不出第幾個" in (o["應該"] or ""):
            return "要人看"
        return "自動改"

    groups = collections.defaultdict(list)
    for o in out:
        groups[bucket(o)].append(o)

    say()
    say("4. 要改的項目")
    say("   %d 段有事，共 %d 項" % (len(changed), len(out)))
    say("   自動改 %d 項　要人看 %d 項　讀不到值 %d 項"
        % (len(groups["自動改"]), len(groups["要人看"]), len(groups["讀不到"])))
    for name in ("自動改", "要人看", "讀不到"):
        if not groups[name]:
            continue
        say()
        say("   【%s】" % name)
        for k, v in collections.Counter(o["項目"]
                                        for o in groups[name]).most_common():
            say("      %-18s %5d 項" % (k, v))

    if miss_parent:
        say()
        say("5. 疑似缺少父階編號 %d 處" % miss_parent)
        say("   這不是格式問題，是原文漏寫了編號。F4 不會自動補，要人決定。")
        for o in out:
            if o["項目"] == "疑似缺少父階編號":
                say("   第 %s 段　%s" % (o["序號"], o["全文前30字"]))
                say("      %s" % o["說明"])

    if skips:
        say()
        say("6. 跳階 %d 處（F3-1 階層保持不變；處理方式：%s）"
            % (len(skips), modes["階層異常處理"]))
        for no, a, b, t in skips[:10]:
            say("   第 %s 段　第 %d 階 -> 第 %d 階　%s" % (no, a, b, t))
        if len(skips) > 10:
            say("   （還有 %d 處）" % (len(skips) - 10))

    say()
    say("=" * 64)
    return out


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法：py F4_比對.py <資料夾> <標準格式表.csv>")
        sys.exit(1)

    folder = sys.argv[1]
    res = main(folder, sys.argv[2])
    out_path = os.path.join(folder, "F4_改動清單.csv")

    if res is not None:
        cols = ["序號", "位置", "目標階層", "角色", "項目", "現在", "應該",
                "說明", "全文前30字"]
        with io.open(out_path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols, quoting=csv.QUOTE_ALL)
            w.writeheader()
            for o in res:
                w.writerow(o)
    elif os.path.isfile(out_path):
        # 停止模式不能留下前一次的舊清單，否則使用者可能誤拿舊結果去套用。
        os.remove(out_path)

    report = "\n".join(lines)
    with io.open(os.path.join(folder, "F4_比對報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    print(report)
