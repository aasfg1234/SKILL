# -*- coding: utf-8 -*-
r"""
run_all：在同一次執行裡跑完多個階段

SPADE 每次執行都是新的暫存目錄，中間檔不跨執行存活。
所以不能一階段一次，必須一口氣跑完。

用法：
    py run_all.py --pass 1 <資料夾>
    py run_all.py --pass 2 <資料夾> --decisions <填好的複核表> \
       --source <原始docx或txt> --version <唯一版本號> --name <規章名> \
       [--org <機構>] [--ver <版本日>] [--release-root <發布根目錄>]

第一趟：S2 -> S3 -> S4 -> QA -> S5 -> 產生複核表，然後停
第二趟：S2 -> S3 -> S4 -> QA -> S5 -> 套用決定 -> S7 -> S8 -> S9
        -> S10 -> S12 正式發布

第二趟為什麼要從 S2 重跑：因為中間檔沒留下來。全部不到 10 秒。
"""

import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))

# Windows 主控台預設 cp950，遇到罕用字會整支炸掉。強制轉 utf-8。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def find(name):
    """在 skill 樹裡找那一支程式。

    HERE 是 reg-pipeline/scripts，往上兩層才是放所有 reg-* 的根。
    """
    root = os.path.dirname(os.path.dirname(HERE))
    for dirpath, _, files in os.walk(root):
        if name in files:
            return os.path.join(dirpath, name)
    return None


def run(name, args, gate=False):
    p = find(name)
    if not p:
        print("[中止] 找不到 %s" % name)
        return False
    t = time.time()
    r = subprocess.run([sys.executable, p] + args,
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    out = r.stdout or ""
    print(out)
    ok = (r.returncode == 0)
    if not ok and r.stderr:
        print("--- 錯誤訊息 ---")
        print(r.stderr[-1500:])
    print("--- %s 花了 %.1f 秒，%s ---" % (name, time.time() - t,
                                       "過" if ok else "沒過"))
    if gate and not ok:
        print()
        print("[停] 這是關卡，沒過不往下跑。上面的報告請整段看。")
        return False
    return True


def main():
    a = sys.argv[1:]
    if "--pass" not in a:
        print(__doc__)
        return 1
    which = a[a.index("--pass") + 1]
    folder = [x for x in a if not x.startswith("--")
              and x not in (which,)][0]
    def option(name, default=None):
        return a[a.index(name) + 1] if name in a and a.index(name) + 1 < len(a) else default

    dec = option("--decisions")
    source = option("--source")
    version = option("--version")
    reg_name = option("--name")
    org = option("--org", "")
    version_date = option("--ver", "")
    release_root = option("--release-root", os.path.join(folder, "releases"))

    print("=" * 60)
    print("run_all 第 %s 趟　資料夾：%s" % (which, folder))
    print("=" * 60)

    if not run("S2_驗收.py", [folder], gate=True):
        return 1
    if not run("S3_切條.py", [folder]):
        return 1
    if not run("S4_二次切分.py", [folder]):
        return 1

    # QA 是 hard gate。第一趟不能在重大切分錯誤下產生複核表；
    # 第二趟也要重跑，避免暫存目錄或程式版本不同時繞過檢查。
    if not run("QA_法遵稽核.py", [folder], gate=True):
        return 1

    if which == "1":
        if not run("S5_品質旗標.py", [folder]):
            return 1
        out = os.path.join(folder, "06_複核表.csv")
        if not run("S6_產生複核表.py", [folder, out]):
            return 1
        print()
        print("=" * 60)
        print("第一趟結束。把 06_複核表.csv 交給使用者填「決定」欄。")
        print("填完再跑：py run_all.py --pass 2 %s --decisions <填好的檔>" % folder)
        print("=" * 60)
        return 0

    if not run("S5_品質旗標.py", [folder]):
        return 1
    if not dec:
        print("[中止] 第二趟要用 --decisions 指定填好的複核表")
        return 1
    if not run("S6_套用決定.py", [folder, dec], gate=True):
        return 1
    for s in ("S7_找重複.py", "S8_抓引用.py", "S9_連帶清單.py"):
        if not run(s, [folder]):
            return 1

    if not run("S10_還原對帳.py", [folder], gate=True):
        return 1

    missing = []
    for flag, value in (("--source", source), ("--version", version),
                        ("--name", reg_name)):
        if not value:
            missing.append(flag)
    if missing:
        print("[中止] 正式發布還缺參數：%s" % "、".join(missing))
        print("       第二趟沒有發布成功，09_規章總表.csv 仍只是中間產物。")
        return 1

    release_args = [folder, release_root, "--version", version,
                    "--source", source, "--name", reg_name]
    if org:
        release_args += ["--org", org]
    if version_date:
        release_args += ["--ver", version_date]
    if not run("S12_發布版本.py", release_args, gate=True):
        return 1

    print()
    print("=" * 60)
    print("第二趟結束。唯一正式入口：%s"
          % os.path.join(release_root, "LATEST.json"))
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
