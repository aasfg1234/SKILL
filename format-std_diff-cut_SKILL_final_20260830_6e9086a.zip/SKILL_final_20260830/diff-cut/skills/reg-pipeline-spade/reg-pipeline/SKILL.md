---
name: reg-pipeline
description: 內規切條產線的總指揮，SPADE 版。把一份內規變成 51 欄的規章總表，因為 SPADE 中間檔不跨執行存活，所以在同一次執行裡跑完全部階段。當使用者要處理一份新的內規、說「跑產線」「切條」「產規章總表」時使用。
---

# 內規切條產線　總指揮（SPADE 版）

## 跟 Claude 版最大的差別

**SPADE 每次執行都是新的暫存目錄，中間檔不會留到下一次執行。**

所以不能像 Claude 版那樣「一階段一次、跑完再跑下一個」。
中間檔一離開那次執行就不見了，下一個階段會找不到輸入。

**做法：用 `scripts/run_all.py`，在同一次執行裡把多個階段一次跑完。**

## 兩趟，因為中間卡著一個人

人工複核那一步只能人做，所以整條線切成兩趟。

### 第一趟：切到產生複核表

`input_files` 要帶：`01_paragraphs.csv`、`02_shapes.csv`、`tables/` 全部

```
py scripts/run_all.py --pass 1 <資料夾>
```

跑完會產出 `06_複核表.csv`。**把它交給使用者填，然後停下來。**

### 使用者填複核表

只填「決定」欄，四種字：保留／刪除／併入上一筆／待改。
每一列都要保留並填寫；漏列或留空白都表示尚未複核，第二趟會擋下來。
不可以另外做一張只列刪除項目的精簡表。
**不要代替使用者填。**

### 第二趟：套用決定，通過 S10 並建立唯一正式版

`input_files` 要帶：第一趟那三樣 **＋** 使用者填好的複核表

```
py scripts/run_all.py --pass 2 <資料夾> --decisions <填好的複核表> \
  --source <原始docx或txt> --version <唯一版本號> --name <規章名> \
  [--org <機構>] [--ver <版本日>]
```

第二趟會**從 S2 重跑一次**再套用決定。因為中間檔沒留下來，只能重算。
全部階段加起來不到 10 秒，重算不心疼。

## 階段順序

| 階段 | skill | 誰做 | 性質 |
|---|---|---|---|
| S1 | `reg-s1-export` | VBA，在有 Word 的電腦 | — |
| S1T | `reg-s1t-fromtxt` | 只在拿不到 Word 時 | — |
| S2 | `reg-s2-verify` | Python | 關卡 |
| S3 | `reg-s3-split` | Python | — |
| S4 | `reg-s4-deepen` | Python | — |
| QA | `reg-qa-audit` | Python | 關卡 |
| S5 | `reg-s5-flag` | Python | — |
| S6 | `reg-s6-review` | 人填 Excel ＋ Python | 人工 |
| S7 | `reg-s7-duplicate` | Python | — |
| S8 | `reg-s8-citation` | Python | — |
| S9 | `reg-s9-master` | Python | 發布前中間產物 |
| S10 | `reg-s10-restore` | Python | 關卡 |
| S11 | `reg-s11-specpack` | Python | 由 S12 重新產生 |
| S12 | `reg-s11-specpack` | Python | 唯一正式發布 |

S1 一樣要在有 Word 的電腦手動跑，SPADE 不能代跑。
第二趟會自動跑 S10、S12。正式交付只認 `releases/LATEST.json` 指到的版本；
工作資料夾裡的 `09_規章總表.csv` 不是正式版。
後續 reg-diff 用 `--baseline-release <發布根目錄>` 接入，不能傳鬆散規格包。


## 三條硬規矩，任何情況都不能破

1. **三道內容關卡與發布關卡不能跳。** S2、QA、S10、S12。沒過就停下來，把報告貼給使用者，不要自己往下跑。
2. **S6 第二步只能人做。** 產生複核表之後就停，把檔案交給使用者填。
   **絕對不要代替使用者填決定。**
3. **不改任何一個字。** 這條產線只切、只標、只找關聯，不改內規文字。
   要改字是 reg-diff 的事，不在這裡。

## 使用者給了什麼，就從哪裡開始

| 使用者手上有 | 從哪一階段開始 |
|---|---|
| 原始 .docx，且有 Word | S1 |
| 只有 Word 另存的 txt | S1T，並提醒產出不可交件 |
| 已經有 01_paragraphs.csv | S2 |
| 已經有 06_final.csv，但不需要正式發布 | S7 |
| 已經有 06_final.csv，且要正式發布 | 先確認同一輪 `S6_複核證明.json`；沒有就回 S6 |
| 填好的複核表 | S6 第三步 |

## 每跑完一階段要做的事

把該階段報告裡的**關鍵數字**唸給使用者聽，不要只說「跑完了」。
關卡階段一定要唸出「過」或「不合格」。


## SPADE 的其他限制

- **不要碰 `Path.home()`**，會直接 RuntimeError
- 核心邏輯全部只用標準函式庫。只有 S10 需要 `python-docx`，
  沒有的話會少掉 .docx，txt 對帳照樣做
- 產出會複製回 session working_dir，使用者拿得到

## 換一本規章要改什麼

- `reg-s7-duplicate/scripts/S7_同義詞表.csv`
- `reg-s8-citation/scripts/S8_外部規章表.csv`
