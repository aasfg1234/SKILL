# -*- coding: utf-8 -*-
r"""
S7：找出重複與關聯的條文

用法：
    py S7_找重複.py <資料夾>

輸入：<資料夾>\06_final.csv        （沒有就退而用 05_flagged.csv）
      pack\S7_同義詞表.csv          （可以自己改，一組一個意思）
輸出：<資料夾>\07_relations.csv
      <資料夾>\S7_關聯報告.txt

它在找什麼
    同一條規定散在不同章節。例如壽險、產險、網路投保各寫一次，
    文字大同小異，改了一處常常忘了改另外兩處。

怎麼比
    一、把編號、標點、空白拿掉，只留文字
    二、切成兩字一組，算兩條重疊多少（Jaccard 相似度）
    三、再把同義詞換成同一個代表詞，重算一次
    四、換詞之後才變像的，就把「是哪一組詞讓它配對上」寫出來

    表格另外比。表格的字在「附件全文」欄。

三種判定
    完全相同    一字不差
    高度相似    0.75 以上
    可能相關    0.55 以上

這一階段不改任何文字，只產出一張關聯表。
"""

import csv
import io
import os
import re
import sys
import collections
import difflib

SAME = 0.999
HIGH = 0.75
MAYBE = 0.55
MIN_LEN = 20            # 太短的不比，沒有意義

OUT_COLS = ["關係編號", "比對對象", "條文A", "位置A", "條文B", "位置B",
            "原文相似度", "換詞後相似度", "提升", "命中同義詞組",
            "關係判定", "共同開頭字數", "差在哪裡", "建議", "A內容", "B內容"]

lines = []


def say(s=""):
    lines.append(s)


# ------------------------------------------------------------------
def load_syn(path):
    """讀同義詞表。回傳 [(組別, [詞...]), ...]，長詞先換。"""
    if not os.path.isfile(path):
        return []
    g = collections.OrderedDict()
    with io.open(path, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            g.setdefault(r["組別"].strip(), []).append(r["詞"].strip())
    out = []
    for k, v in g.items():
        out.append((k, sorted(set(v), key=len, reverse=True)))
    return out


PUNCT = re.compile(r"[\s，。、；：？！「」『』（）()【】《》〈〉·．,.;:!?/\-—～~＋+*#※]")
LEAD = re.compile(r"^(?:\s*\[\[(?:TABLE|SHAPE):\d{3}\]\])*\s*"
                  r"(?:[（(]?[一二三四五六七八九十百\d]{1,3}[）)、.．]|[A-Za-z][.．])?\s*")


def norm(text):
    """去掉記號、開頭編號、標點與空白，只留文字。"""
    t = re.sub(r"\[\[(?:TABLE|SHAPE):\d{3}\]\]", "", text or "")
    t = LEAD.sub("", t)
    t = PUNCT.sub("", t)
    return t


def apply_syn(text, syn):
    """把同義詞換成組別代表詞。回傳 (換過的字串, 用到哪些組)。"""
    used = {}
    for name, words in syn:
        for w in words:
            if w and w in text:
                text = text.replace(w, name)
                used.setdefault(name, set()).add(w)
    return text, used


def grams(text, n=2):
    if len(text) < n:
        return set([text]) if text else set()
    return set(text[i:i + n] for i in range(len(text) - n + 1))


def jac(a, b):
    if not a or not b:
        return 0.0
    inter = len(a & b)
    if not inter:
        return 0.0
    return inter / float(len(a | b))


def diff_hint(a, b, limit=6):
    """把兩段文字不一樣的地方抓出來，讓人一眼看到差在哪個字。"""
    out = []
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            continue
        x = a[i1:i2].strip()
        y = b[j1:j2].strip()
        if not x and not y:
            continue
        if tag == "replace":
            out.append("%s→%s" % (x[:12] or "（無）", y[:12] or "（無）"))
        elif tag == "delete":
            out.append("A多了「%s」" % x[:12])
        else:
            out.append("B多了「%s」" % y[:12])
        if len(out) >= limit:
            out.append("…")
            break
    return "；".join(out)


def common_head(a, b):
    n = 0
    while n < min(len(a), len(b)) and a[n] == b[n]:
        n += 1
    return n


# ------------------------------------------------------------------
def compare(units, syn, label):
    """units: [(ID, 位置, 原文)]。回傳配對清單。"""
    prep = []
    for uid, pos, raw in units:
        base = norm(raw)
        if len(base) < MIN_LEN:
            continue
        swapped, used = apply_syn(base, syn)
        prep.append((uid, pos, raw, base, grams(base), swapped,
                     grams(swapped), used))

    pairs = []
    for i in range(len(prep)):
        for j in range(i + 1, len(prep)):
            a, b = prep[i], prep[j]
            s0 = jac(a[4], b[4])
            s1 = jac(a[6], b[6])
            best = max(s0, s1)
            if best < MAYBE:
                continue

            # 哪一組同義詞讓它配對上：兩邊都用到同一組，但用的詞不一樣
            hit = []
            for g in set(a[7]) & set(b[7]):
                if a[7][g] != b[7][g]:
                    hit.append("%s(%s↔%s)" % (g,
                                              "/".join(sorted(a[7][g])),
                                              "/".join(sorted(b[7][g]))))

            if a[3] == b[3]:
                verdict = "完全相同"
            elif best >= HIGH:
                verdict = "高度相似"
            else:
                verdict = "可能相關"

            pairs.append({
                "比對對象": label,
                "條文A": a[0], "位置A": a[1],
                "條文B": b[0], "位置B": b[1],
                "原文相似度": round(s0, 3),
                "換詞後相似度": round(s1, 3),
                "提升": round(s1 - s0, 3),
                "命中同義詞組": "；".join(sorted(hit)),
                "關係判定": verdict,
                "共同開頭字數": common_head(a[3], b[3]),
                "差在哪裡": ("完全一樣" if a[3] == b[3]
                         else diff_hint(a[3], b[3])),
                "A內容": a[2][:60],
                "B內容": b[2][:60],
            })
    return pairs


def main(folder, syn_path):
    src = os.path.join(folder, "06_final.csv")
    if not os.path.isfile(src):
        src = os.path.join(folder, "05_flagged.csv")
    if not os.path.isfile(src):
        say("找不到 06_final.csv 或 05_flagged.csv")
        return None

    with io.open(src, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    syn = load_syn(syn_path)

    say("=" * 64)
    say("S7 關聯報告")
    say("輸入：" + src)
    say("同義詞表：%s（%d 組）" % (syn_path, len(syn)))
    say("=" * 64)
    say()
    say("門檻：完全相同 = 一字不差；高度相似 ≥ %.2f；可能相關 ≥ %.2f"
        % (HIGH, MAYBE))
    say("少於 %d 字的條文不比" % MIN_LEN)

    def where(r):
        return (r["章標題"][:12] + (" / " + r["節標題"][:12]
                                   if r["節標題"] else "")).strip()

    tbl_of = dict((r["條文ID"], r["含表格標記"]) for r in rows
                  if r.get("含表格標記"))

    body = [(r["條文ID"], where(r), r["全文"]) for r in rows
            if r["符號類型"] not in ("表格", "圖形")]
    tabs = [(r["條文ID"], where(r), r["附件全文"]) for r in rows
            if r.get("附件全文") and r["符號類型"] == "表格"]

    say()
    say("比對範圍：條文 %d 筆、表格 %d 張" % (len(body), len(tabs)))

    pairs = compare(body, syn, "條文") + compare(tabs, syn, "表格")
    pairs.sort(key=lambda p: -max(p["原文相似度"], p["換詞後相似度"]))
    for k, p in enumerate(pairs, 1):
        p["關係編號"] = "L%04d" % k
        v = p["關係判定"]
        if v == "完全相同":
            p["建議"] = "同一段話寫了兩次。改一處一定要改另一處"
        elif v == "高度相似":
            p["建議"] = "極可能是同一條規定的不同版本。改內規時兩條一起看"
        else:
            p["建議"] = "可能相關，人工確認"

    # ---------- 統計 ----------
    say()
    say("1. 找到幾組")
    c = collections.Counter(p["關係判定"] for p in pairs)
    for k in ("完全相同", "高度相似", "可能相關"):
        say("   %-6s %d 組" % (k, c.get(k, 0)))
    say("   合計 %d 組" % len(pairs))

    say()
    say("2. 跨章節的關聯（同一條規定散在不同章）")
    cross = [p for p in pairs
             if p["位置A"].split(" / ")[0] != p["位置B"].split(" / ")[0]]
    say("   %d 組" % len(cross))
    for p in cross[:15]:
        say("   %s  %s ↔ %s  相似度 %.3f  %s"
            % (p["關係判定"], p["條文A"], p["條文B"],
               max(p["原文相似度"], p["換詞後相似度"]), p["比對對象"]))
        say("      A：%s ｜ %s" % (p["位置A"], p["A內容"][:34]))
        say("      B：%s ｜ %s" % (p["位置B"], p["B內容"][:34]))

    say()
    say("3. 靠同義詞才配對上的")
    bysyn = [p for p in pairs if p["命中同義詞組"] and p["提升"] > 0]
    say("   %d 組" % len(bysyn))
    for p in bysyn[:12]:
        say("   %s ↔ %s  原文 %.3f → 換詞後 %.3f（＋%.3f）"
            % (p["條文A"], p["條文B"], p["原文相似度"],
               p["換詞後相似度"], p["提升"]))
        say("      是這組詞讓它們配上：%s" % p["命中同義詞組"])

    say()
    say("4. 完全相同的")
    same = [p for p in pairs if p["關係判定"] == "完全相同"]
    if not same:
        say("   沒有")
    for p in same:
        say("   %s ↔ %s（%s）" % (p["條文A"], p["條文B"], p["比對對象"]))
        say("      %s" % p["A內容"][:50])

    # ---------- 已知樣本驗證 ----------
    say()
    say("5. 只差幾個字的（同一條規定，用字不一樣）")
    tiny = [p for p in pairs
            if p["關係判定"] in ("完全相同", "高度相似")
            and p["差在哪裡"] != "完全一樣" and p["差在哪裡"]
            and len(p["差在哪裡"]) <= 60]
    tiny.sort(key=lambda p: -max(p["原文相似度"], p["換詞後相似度"]))
    say("   %d 組" % len(tiny))
    for p in tiny[:15]:
        say("   %s ↔ %s  %.3f" % (p["條文A"], p["條文B"],
                                 max(p["原文相似度"], p["換詞後相似度"])))
        say("      差在：%s" % p["差在哪裡"])

    say()
    say("6. 表格之間的關聯")
    t = [p for p in pairs if p["比對對象"] == "表格"]
    if not t:
        say("   沒有")
    for p in t[:8]:
        ta = tbl_of.get(p["條文A"], "?")
        tb = tbl_of.get(p["條文B"], "?")
        say("   T%s ↔ T%s（%s ↔ %s）%.3f  %s"
            % (ta, tb, p["條文A"], p["條文B"],
               max(p["原文相似度"], p["換詞後相似度"]),
               p["命中同義詞組"] or "（沒靠同義詞）"))

    return pairs


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S7_找重複.py <資料夾>")
        sys.exit(1)

    folder = sys.argv[1]
    syn_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "S7_同義詞表.csv")
    result = main(folder, syn_path)

    if result is not None:
        with io.open(os.path.join(folder, "07_relations.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=OUT_COLS, quoting=csv.QUOTE_ALL)
            w.writeheader()
            for p in result:
                w.writerow(dict((c, p.get(c, "")) for c in OUT_COLS))
        say()
        say("=" * 64)
        say("結論：S7 完成。已寫出 07_relations.csv（%d 組）" % len(result))
        say("=" * 64)

    report = "\n".join(lines)
    with io.open(os.path.join(folder, "S7_關聯報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if result is not None else 1)
