# -*- coding: utf-8 -*-
"""
連帶決定表：compare 找到的候選合成一張表，人只填「要改嗎」「改成什麼」兩欄。

來源：
    規格包      diff-cut 正式基準已知的重複、相似、引用關係
    相似        整條相似度（fuzzy_duplicate_finder）
    相似（句）  整條相似度不夠，但改到的那一句在別的候選裡分數夠高
    關鍵詞      這次改動的字在別處也出現（有片段可搜）
    關鍵詞（文脈）改動片段太短沒有片段可搜，改用改動處左右文脈搜
    關鍵詞（舊值）被換掉的舊字（帶一兩個字上下文）別處還原樣留著；表格格子要那一列的名稱也對得上
    關鍵詞（定義）定義的用詞改名了，別處還用舊名
    語意        BGE-M3 向量（可選）
同一個候選段次只出現一列，來源與異動條文ID 用「；」併列。

一定有一份同名 .json（指紋檔）：記草稿 SHA-256、初比對異動段落指紋、每列候選全文指紋。
apply 與 finalize 靠它擋「中間動過草稿」與「拿錯表」。位置見 sidecar_path_for
（表在 填寫表單/ 時，指紋檔在隔壁的 系統檔案/）。
"""

import csv
import datetime
import hashlib
import io
import json
import os
import re
import sys

# 三格的名字只有一個來源（_common.FILE_HOMES 那一節），這裡不自己再寫一份字串。
# append 而不是 insert(0)：regdiff/run_all.py 跟 scripts/run_all.py 同名。
_REGDIFF = os.path.join(os.path.dirname(os.path.abspath(__file__)), "regdiff")
if _REGDIFF not in sys.path:
    sys.path.append(_REGDIFF)
from _common import EXCEL_ANSI_ENCODINGS, OUTPUT_DIRS, SYSTEM_DIR, open_csv, read_csv_text
import notices as nt

COLUMNS = ["來源", "異動條文ID", "異動摘要", "候選條文ID", "候選段次", "候選全文",
           "關係／分數", "經同義詞比對", "要改嗎", "改成什麼"]
ACTIONS = ("改", "刪除", "不改", "")
# 人在 Excel 裡常打的其他寫法：讀表時換成上面三個字（寫回去的時候就是標準字）。
# 以前只認三個字，打「否」「維持」「是」整批指令一開始就中止，人要回頭一格一格改。
# 只收意思不會搞錯的詞；打勾（✓、V）不收——勾「看過了」還是勾「要改」分不出來。
ACTION_SYNONYMS = {
    "改": ("修改", "要改", "要修改", "需改", "需修改", "須修改", "應修改", "照改", "照建議改", "改寫",
          "是", "要", "Y", "YES"),
    "不改": ("不修改", "不用改", "不必改", "不需改", "不需修改", "不須修改", "無須修改", "毋須修改", "免改",
            "維持", "維持原文", "維持原條文", "不動", "保留原文", "否", "不", "N", "NO"),
    "刪除": ("刪", "刪掉", "整段刪除", "刪除整段", "刪除本段", "移除"),
}
_ACTION_LOOKUP = dict((word, action) for action, words in ACTION_SYNONYMS.items() for word in words)


def normalize_action(text):
    """「要改嗎」填的字 → 改／刪除／不改／""；認不得回 None。全半形、大小寫、頭尾空白都不管。"""
    import unicodedata
    value = unicodedata.normalize("NFKC", text or "").strip()
    if value in ACTIONS:
        return value
    return _ACTION_LOOKUP.get(value.upper()) or _ACTION_LOOKUP.get(value)
RELATION_TYPES = ("重複條文", "相似條文", "被誰引用", "我引用誰")
# 選填欄：不是每一次都有，有的時候要照原順序寫出來。
# 「修改類型」＝把這一列帶出來的那一處異動是修改／新增／刪除（多處就用「；」併列）。
# 決定表只寫「異動條文ID」的話，人要回頭翻異動清單才知道那一處到底是改字還是整條刪掉，
# 而這兩種情況要判的事完全不同（刪掉的條文，別章的平行條文多半也要一起刪）。
# 「異動段次」＝把這一列帶出來的那一處異動在哪一段（新增／修改寫「N」，刪除寫「舊版 N」）。
# 無條號的作業手冊型文件，「異動條文ID」只寫得出「段次 N」這種代號，
# 人要回頭數段落才知道那是全文的哪裡；這一欄把座標直接寫在表上。
# 選填欄在這裡的順序只是登記順序；寫出去的欄序另見 DISPLAY_ORDER。
# 「異動內容」＝那一處異動改了哪幾個字（「三日→五日」），不用回頭翻對照表。
# 「建議改法」＝把同樣的改法套到候選段上的樣子，只是參考：程式不代填「改成什麼」，
#   人看過覺得對再複製過去（套不上去、猜不準就留空，不硬猜）。
# 「沿用上一輪」＝重跑 compare 時，這一列的候選與異動都跟上一輪一樣，上一輪填的決定
#   已經帶過來了（見 row_assist.carry_over）；空白的列是新的或有變，要重新看。
# 「相似分數」＝「關係／分數」裡字面相似度（整段、句子）最高的那個數字，0～100 的純數字。
#   「關係／分數」是「85.7 分、句首」這種文字，Excel 不能照分數排序；這一欄給人排序、篩選用。
#   語意分數（0～1）是另一種量法，不放進來，免得人拿兩種分數比大小；關鍵詞、引用這類沒有分數的列留空。
#   每次寫表都從「關係／分數」重算，不會跟那一欄對不上。
OPTIONAL_COLUMNS = ["規章", "修改類型", "AI判斷", "AI分數", "AI理由", "異動段次",
                    "異動內容", "建議改法", "沿用上一輪", "核准方式", "相似分數"]

# 寫出去的欄序：人要看、要填的排前面，程式判斷用的技術欄排最後。
# 以前照 COLUMNS＋選填欄的定義順序寫，要填的「要改嗎」「改成什麼」夾在第 9、10 欄，
# 旁邊是「關係／分數」這種一般人看不懂的欄；人在 Excel 裡要一直往右捲。
# 程式讀這張表一律照欄名（DictReader），不看位置，所以欄序只影響人。
# 「裁定 5」原本要求「修改類型」固定第 11 欄、新欄一律接在最後；這一版依使用者要求
# 改成下面的順序，選填欄（沒出現就不寫）照樣只在有值時才出現。
DISPLAY_ORDER = ["候選段次", "候選全文", "異動內容", "建議改法", "要改嗎", "改成什麼", "核准方式", "沿用上一輪",
                 "相似分數", "AI判斷", "AI分數", "AI理由", "規章", "修改類型", "異動摘要", "異動條文ID",
                 "異動段次", "候選條文ID", "來源", "關係／分數", "經同義詞比對"]


# 「85.7 分」「句 92.1 分」：前面不能接數字或小數點，「語意 0.812」不算
_SCORE_RE = re.compile(r"(?<![\d.])(\d{1,3}(?:\.\d+)?)\s*分")


def similarity_score(relation):
    """「關係／分數」欄裡最高的字面相似度，回字串（「85.7」）；沒有分數回 ""。"""
    # 只看每一段冒號前面：「句 92.1 分：…」冒號後面是候選句原文，裡面的「60 分以上」不是分數
    heads = [piece.split("：", 1)[0] for piece in (relation or "").split("；")]
    scores = [float(m.group(1)) for head in heads for m in _SCORE_RE.finditer(head)]
    scores = [s for s in scores if s <= 100]
    if not scores:
        return ""
    best = max(scores)
    return ("%.1f" % best).rstrip("0").rstrip(".")


SCORE_COLUMN = "相似分數"


def _cell_value(row, column, default=""):
    """寫檔時一格的值：「相似分數」當場從「關係／分數」算（不寫進列本身——呼叫端拿同一批列
    去寫自己的表時，多一個鍵會讓它的 DictWriter 當掉），其他欄照列上的值。"""
    if column == SCORE_COLUMN:
        return similarity_score(row.get("關係／分數"))
    return row.get(column, default)


def ordered_fields(present):
    """present 裡的欄照 DISPLAY_ORDER 排；不在表裡的欄（人自己在 Excel 加的）接在最後，
    彼此照原本出現的順序。"""
    present = list(present)
    return ([c for c in DISPLAY_ORDER if c in present]
            + [c for c in present if c not in DISPLAY_ORDER])
TYPE_LABELS = {"added": "新增", "deleted": "刪除", "modified": "修改"}


class DecisionTableError(ValueError):
    pass


def normalize(text):
    return re.sub(r"\s+", "", text or "")


def normalize_newlines(text):
    """把 \\r\\n（與單獨的 \\r）收斂成 \\n。

    候選全文可能帶換行（Word 的 <w:br/> 讀進來就是 \\n）。人用 Excel 開決定表、
    存檔之後，儲存格裡的換行會被寫成 \\r\\n；拿它跟草稿段落逐字比就會不相等，
    apply 於是回報「跳過（原文不符）」——但草稿其實一個字都沒被動過。
    這是「比對用字串」的正規化，不改寫任何產出檔裡的原文。
    """
    return (text or "").replace("\r\n", "\n").replace("\r", "\n")


def text_sha256(text):
    return hashlib.sha256(normalize(text).encode("utf-8")).hexdigest()


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _summary(text, limit=40):
    text = (text or "").strip()
    return text if len(text) <= limit else text[:limit] + "…"


# 刪除型異動的「異動摘要」前綴（裁定 5：不另外加欄，改在既有欄位標記）。
# 為什麼要標：決定表上的「異動摘要」對修改型放的是新文、對刪除型放的是舊文，
# 兩者長得一模一樣，看表的人分不出「這一條被改了幾個字」還是「這一條整條沒了」——
# 而這兩種要判的事完全不同：整條刪掉的條文，別章的平行條文多半也要一起刪。
DELETED_PREFIX = "【整條刪除】"


def mark_deleted_summary(summary, type_label):
    """刪除型異動的摘要加上前綴。type_label 是候選 CSV 第 2 欄的「修改類型」。"""
    summary = summary or ""
    if not summary or DELETED_PREFIX in summary:
        return summary
    if TYPE_LABELS["deleted"] not in str(type_label or ""):
        return summary
    return DELETED_PREFIX + summary


def strip_deleted_prefix(summary):
    """把前綴拿掉。拿摘要去跟條文原文做開頭比對的地方（review_pack 收斂同名 ref）
    要用這一支，不然加了前綴之後永遠比不中。"""
    summary = summary or ""
    return summary[len(DELETED_PREFIX):] if summary.startswith(DELETED_PREFIX) else summary


def _merge(row, source, change_id, cand_id, relation, evidence):
    for key, value, sep in (("來源", source, "；"), ("異動條文ID", change_id, "；"),
                            ("候選條文ID", cand_id, "；"), ("關係／分數", relation, " | "),
                            ("經同義詞比對", evidence, "；")):
        if not value:
            continue
        # 傳進來的值本身可能已經是「A；B」這種組合，要拆開逐一比，不然永遠比不中、越併越長
        existing = [x for x in row[key].split(sep) if x] if row[key] else []
        for piece in (value.split(sep) if sep in value else [value]):
            piece = piece.strip()
            if piece and piece not in existing:
                existing.append(piece)
        row[key] = sep.join(existing)


def _new_row(line, summary, text):
    return {"來源": "", "異動條文ID": "", "異動摘要": summary or "", "候選條文ID": "",
            "候選段次": str(line) if line else "", "候選全文": text or "",
            "關係／分數": "", "經同義詞比對": "", "要改嗎": "", "改成什麼": ""}


def _line_of(value):
    value = str(value or "").strip()
    return int(value) if value.isdigit() and int(value) > 0 else 0


line_of = _line_of


def change_keys(item, baseline=None):
    """一處異動在決定表「異動條文ID」欄可能出現的每一種寫法。

    同一處異動在決定表上可能以好幾種寫法出現：有正式基準時是
    「、」.join(spec_ids)（baseline.change_label），沒有基準時是 ref，規格包連帶複核
    那條路又是單一個條文ID，關鍵詞那條路還可能是「段次 N」；無條號文件整段被刪掉時
    寫的是「舊版段次 N」（見 regdiff/run_all.step_duplicates）。

    change_type_map 與 change_position_map 共用這一支，兩欄的鍵才不會漂開——
    一邊查得到、另一邊留白，看表的人會以為那一列真的沒有段次。
    """
    keys = []
    ids = list(item.get("spec_ids") or [])
    if baseline is not None:
        keys.append(baseline.change_label(item))
    elif ids:
        keys.append("、".join(ids))
    keys.append(item.get("ref") or "")
    keys += ids
    if item.get("new_index"):
        keys.append("段次 %d" % item["new_index"])
    if item.get("type") == "deleted" and item.get("old_index"):
        keys.append("舊版段次 %d" % item["old_index"])
    return [k for k in keys if k]


def change_type_map(results, baseline=None):
    """{異動的識別字: [修改類型, ...]}，給 build_rows 標「修改類型」欄用。
    鍵的寫法見 change_keys。"""
    out = {}
    for item in results or []:
        label = TYPE_LABELS.get(item.get("type"))
        if not label:
            continue
        for key in change_keys(item, baseline):
            bucket = out.setdefault(key, [])
            if label not in bucket:
                bucket.append(label)
    return out


def change_position_map(results, baseline=None):
    """{異動的識別字: [段次字串, ...]}，給 build_rows 標「異動段次」欄用。

    新增／修改寫新版段次「N」，刪除寫「舊版 N」（刪除型沒有新版段次，
    寫成「N」會被當成新版座標而翻錯段）。鍵跟 change_type_map 一模一樣。
    """
    out = {}
    for item in results or []:
        if item.get("type") not in TYPE_LABELS:
            continue
        if item.get("type") == "deleted":
            position = "舊版 %d" % item["old_index"] if item.get("old_index") else ""
        else:
            position = "%d" % item["new_index"] if item.get("new_index") else ""
        if not position:
            continue
        for key in change_keys(item, baseline):
            bucket = out.setdefault(key, [])
            if position not in bucket:
                bucket.append(position)
    return out


def values_for_change_id(change_id, mapping):
    """決定表某一列查某一張對照表：把「異動條文ID」用「；」拆開逐段查，
    查到的值去重後用「；」併起來。查不到就回空字串，不猜。"""
    if not mapping or not change_id:
        return ""
    out = []
    for piece in str(change_id).split("；"):
        piece = piece.strip()
        if not piece:
            continue
        values = mapping.get(piece)
        if values is None and "、" in piece:
            # 「A-003、A-003-1」這種一次帶好幾個條文ID的寫法，拆開再查一次
            values = []
            for sub in piece.split("、"):
                values += mapping.get(sub.strip(), [])
        for value in (values or []):
            if value not in out:
                out.append(value)
    return "；".join(out)


def _dedupe(values):
    """保留原順序去重。"""
    out = []
    for value in values:
        if value not in out:
            out.append(value)
    return out


def types_for_change_id(change_id, change_types):
    """決定表某一列的「修改類型」。"""
    return values_for_change_id(change_id, change_types)


def build_rows(candidate_rows, changed_rows, review_rows, new_line_ids, new_paragraphs,
               semantic_rows=None, sentence_rows=None, change_types=None,
               change_positions=None):
    """
    candidate_rows：regdiff run_all.step_duplicates 的 csv_rows（18 欄 list，第 2 欄是修改類型、
                    最後一欄是「異動段次」）
    changed_rows：同函式的 changed_rows（12 欄 list，第 2 欄是修改類型、
                  第 11 欄是「片段」或「文脈」、最後一欄是「異動段次」）
    review_rows：baseline.write_review 的列（dict）
    new_line_ids：baseline.annotate_results 的回傳 {新版段次: [條文ID, ...]}
    semantic_rows：semantic_candidates 讀出的列（dict）
    sentence_rows：regdiff run_all.step_duplicates 的 sentence_rows（9 欄 list）
    change_types：change_type_map 的回傳；只有「自己沒帶類型」的列（句子／規格包／語意）
                  才用它查表，沒給就那些列整欄留空
    change_positions：change_position_map 的回傳；用法同 change_types，填「異動段次」欄
    """
    by_key = {}
    order = []
    # 每一列看過的修改類型與異動段次（候選／關鍵詞列各自帶的 c[1]／h[1] 與
    # c[17]／h[11]）；句子與規格包列沒帶，不記。
    # 為什麼不能一律拿 異動條文ID 去查 change_types／change_positions：手冊型文件
    # 每一章都有一個「1.」，ref 全都是「1.」，全書共用一個鍵——第一章那處改字與
    # 第二章那段整條刪除會被併成「修改；刪除」「2；舊版 5」，段次指到別章，
    # 【整條刪除】前綴也因為混進「修改」而掉了。
    # 這兩份記的才是「真的帶出這一列的那幾處異動」，有記到就以它為準。
    # 【整條刪除】前綴要等整列併完才決定（見函式末尾），不能在 add() 當下就標——
    # 不然同一段先被刪除型帶出來、再被修改型併進來，前綴會留著；反過來就不會有，
    # 結果看合併順序而定，看表的人以為整條沒了其實旁邊還有一筆修改。
    types_seen = {}
    positions_seen = {}

    def add(line_no, source, change_id, summary, cand_id, text, relation, evidence,
            type_label=None, position=None):
        line = _line_of(line_no)
        key = line if line else ("無段次", cand_id, source, relation)
        row = by_key.get(key)
        if row is None:
            row = _new_row(line, summary, text)
            by_key[key] = row
            order.append(key)
        _merge(row, source, change_id, cand_id, relation, evidence)
        if not row["異動摘要"] and summary:
            row["異動摘要"] = summary
        if type_label:
            types_seen.setdefault(key, set()).add(str(type_label))
        if position:
            positions_seen.setdefault(key, []).append(str(position))

    # c／h 的第 2 欄（索引 1）是修改類型、最後一欄是異動段次，兩者都是
    # 「帶出這一列的那一處異動」自己的值。用 len() 守門：舊格式的 list
    # （沒有最後那一欄）就當沒帶，照樣退回 change_types／change_positions 查表。
    for c in candidate_rows or []:
        relation = "%s 分" % c[7] + ("、%s" % c[9] if c[9] else "")
        add(c[5], "相似", c[0] or "", _summary(c[2]),
            c[4] or "", c[6], relation, c[11] or "", type_label=c[1],
            position=(c[17] if len(c) > 17 else ""))
    for h in changed_rows or []:
        mode = h[10] if len(h) > 10 else "片段"
        position = h[11] if len(h) > 11 else ""
        summary = _summary(h[2])
        if mode == "文脈":
            add(h[6], "關鍵詞（文脈）", h[0] or "", summary, h[5] or "", h[7],
                "文脈「%s」" % h[8], "", type_label=h[1], position=position)
        elif mode in ("舊值", "定義"):
            add(h[6], "關鍵詞（%s）" % mode, h[0] or "", summary, h[5] or "", h[7],
                "舊字「%s」還在" % h[8], "", type_label=h[1], position=position)
        else:
            add(h[6], "關鍵詞", h[0] or "", summary, h[5] or "", h[7],
                "命中「%s」" % h[8], "", type_label=h[1], position=position)
    for s in sentence_rows or []:
        add(s[4], "相似（句）", s[0] or "", _summary(s[1]), s[3] or "", s[7],
            "句 %s 分：%s" % (s[6], _summary(s[5], 30)), s[8] or "")

    id_to_line = {}
    for line, ids in (new_line_ids or {}).items():
        for item_id in ids:
            id_to_line.setdefault(item_id, int(line))
    for r in review_rows or []:
        if r.get("關聯類型") not in RELATION_TYPES:
            continue
        line = id_to_line.get(r.get("關聯條文ID"))
        text = new_paragraphs[line - 1] if line else r.get("關聯條文全文", "")
        relation = r["關聯類型"] + ("" if line else "（無法定位到草稿段落）")
        if r.get("異動類型") == "renumbered":
            # 規格包複核表現在也展開「編號調整」那幾處的被引用關係（換號正是引用會壞的情況）
            relation += "（被引用的條這次換號）"
        add(line, "規格包", r.get("異動條文ID", ""), "", r.get("關聯條文ID", ""),
            text, relation, "")

    # 【整條刪除】前綴在這裡一次決定（裁定 5）：這一列的修改類型全部都是「刪除」才標；
    # 混了修改／新增的列一律不標，免得把「改了幾個字」誤寫成整條刪掉。
    # 修改類型與異動段次都以「真的帶出這一列的那幾處異動」為準（types_seen／
    # positions_seen）；只有句子層級、規格包、語意那幾條路的列沒帶，才退回
    # change_types／change_positions 查表。
    seen_by_row = {id(by_key[k]): types_seen.get(k, set()) for k in order}
    pos_by_row = {id(by_key[k]): positions_seen.get(k, []) for k in order}
    rows = [by_key[k] for k in order]
    rows = add_semantic(rows, semantic_rows or [])
    for row in rows:
        # 欄位存不存在還是由 change_types／change_positions 有沒有給決定（不給就整欄
        # 不長出來，呼叫端的欄位契約不變）；欄裡填什麼才改成優先看這一列自己帶的。
        own_positions = _dedupe([p for p in pos_by_row.get(id(row), []) if p])
        own_types = sorted(seen_by_row.get(id(row)) or ())
        if change_positions:
            row["異動段次"] = ("；".join(own_positions) if own_positions
                             else values_for_change_id(row.get("異動條文ID"), change_positions))
        if change_types:
            row["修改類型"] = ("；".join(own_types) if own_types
                             else types_for_change_id(row.get("異動條文ID"), change_types))
            labels = row["修改類型"]
        else:
            labels = "；".join(own_types)
        summary = strip_deleted_prefix(row["異動摘要"])
        if labels and all(t == TYPE_LABELS["deleted"] for t in labels.split("；")):
            summary = mark_deleted_summary(summary, TYPE_LABELS["deleted"])
        row["異動摘要"] = summary
    return rows


def add_semantic(rows, semantic_rows):
    """把語意候選併進既有列；同段次併列，新段次新增。既有的「要改嗎」「改成什麼」不動。"""
    by_line = {r["候選段次"]: r for r in rows if r["候選段次"]}
    for s in semantic_rows or []:
        line = _line_of(s.get("候選段次"))
        if not line:
            continue
        row = by_line.get(str(line))
        if row is None:
            row = _new_row(line, _summary(s.get("異動全文", "")), s.get("候選全文", ""))
            rows.append(row)
            by_line[str(line)] = row
        # 「語意依據」（是哪一句對上哪一句）放進「經同義詞比對」欄：那一欄本來就是
        # 「為什麼配上」的證據欄，字面比對寫同義詞組、語意這邊寫句對句。
        _merge(row, "語意", s.get("異動條文ID") or ("段次 %s" % s.get("異動段次", "")),
               "", "語意 %s" % s.get("語意分數", ""), s.get("語意依據") or "")
    rows.sort(key=lambda r: (0 if r["候選段次"] else 1, int(r["候選段次"] or 0)))
    return rows


def add_cross(rows, cross_rows):
    """把跨本候選（來源「跨本」「跨本引用」）併進既有列。規則同 add_semantic；
    沒有候選段次的列（定位不到草稿段落）依 (候選條文ID, 候選全文) 合併，排最後。既有的決定不動。"""
    by_line = {r["候選段次"]: r for r in rows if r["候選段次"]}
    by_key = {}
    for s in cross_rows or []:
        line = _line_of(s.get("候選段次"))
        if line:
            row = by_line.get(str(line))
            if row is None:
                row = _new_row(line, s.get("異動摘要", ""), s.get("候選全文", ""))
                rows.append(row)
                by_line[str(line)] = row
        else:
            key = (s.get("候選條文ID", ""), normalize(s.get("候選全文", "")))
            row = by_key.get(key)
            if row is None:
                row = _new_row(0, s.get("異動摘要", ""), s.get("候選全文", ""))
                rows.append(row)
                by_key[key] = row
        _merge(row, s.get("來源") or "跨本", s.get("異動條文ID", ""), s.get("候選條文ID", ""),
               s.get("關係／分數", ""), s.get("經同義詞比對", ""))
        if not row["異動摘要"] and s.get("異動摘要"):
            row["異動摘要"] = s["異動摘要"]
        # 跨本引用換號／被刪（batch.text_citation_links）：跟同本的章節引用同一套，
        # 建議改法由 row_assist.annotate 照位置改寫
        for finding in s.get(OUTLINE_KEY) or []:
            known = row.setdefault(OUTLINE_KEY, [])
            if not any(f.get("start") == finding.get("start") for f in known):
                known.append(finding)
    rows.sort(key=lambda r: (0 if r["候選段次"] else 1, int(r["候選段次"] or 0)))
    return rows


# 章節引用列帶著的原始發現（renumber.scan_outline_references 的那幾筆），給
# row_assist.annotate 算「異動內容」「建議改法」；不是欄，寫表時不會寫出去。
OUTLINE_KEY = "_章節引用"
OUTLINE_SOURCE = "章節引用"
OUTLINE_CHANGE_ID = "章節換號"


def add_outline(rows, findings):
    """把 Step 0.5 的章節引用（目標換號＝需改寫、目標被刪＝危險）併進決定表：
    引用所在的那一段就是候選段，填「改」、照「建議改法」改，apply 就寫成追蹤修訂。
    同段次已經是候選就併進那一列，既有的決定不動。「無法判定」的不進表（只留提醒）。"""
    by_line = {r["候選段次"]: r for r in rows if r["候選段次"]}
    for f in findings or []:
        if f.get("status") not in ("需改寫", "危險"):
            continue
        line = str(f["index"])
        row = by_line.get(line)
        if row is None:
            row = _new_row(f["index"], "章節重編後的引用", f["text"])
            rows.append(row)
            by_line[line] = row
        relation = ("「%s」→「%s」" % (f["quote"], f["new_quote"]) if f.get("new_quote")
                    else "「%s」指到的章節已刪除" % f["quote"])
        _merge(row, OUTLINE_SOURCE, OUTLINE_CHANGE_ID, "", relation, "")
        row.setdefault(OUTLINE_KEY, []).append(f)
    rows.sort(key=lambda r: (0 if r["候選段次"] else 1, int(r["候選段次"] or 0)))
    return rows


# 條、款、項引用（renumber.scan_references／scan_reference_drift）與定義變更連動
# （rule_checks 的「定義變更連動」）：以前只印在畫面或條文檢查報告，決定表上沒有，人就漏看。
# 跟章節引用同一套：原始發現掛在 OUTLINE_KEY 底下，row_assist.annotate 照它寫「異動內容」，
# 需改寫的照位置寫「建議改法」（只換那個號碼）；危險、無法判定、內容變了、定義連動一律不給
# 建議改法——要不要改、改成什麼，是人決定的。
REFS_SOURCE = "條文引用"
DEFINITION_SOURCE = "定義連動"
REFS_REWRITE_ID = "條文換號"       # 帶「換號」：change_reasons 寫修改依據時不把它當條號
REFS_CHANGE_ID = "條文引用"
DEFINITION_CHANGE_ID = "定義變更"
# 異動內容前面的標記：approve 看到【危險】一律留給人（不管 AI 怎麼判）
DANGER_MARK = "【危險】"
_REF_TAGS = {"條": "條號換號", "款": "款號換號", "項": "項次換號", "目": "目次換號"}


def _locate(text, original, span):
    """引用在原文的位置，搬到決定表那一段（重編過的話開頭號碼會變，位置跟著位移）。
    原位置對得上就照用；對不上而那幾個字在段裡只出現一次就用那一處；都不行回 None（不給建議改法）。"""
    if not span:
        return None
    token = (original or "")[span[0]:span[1]]
    if not token:
        return None
    if text[span[0]:span[1]] == token:
        return tuple(span), token
    if text.count(token) == 1:
        start = text.index(token)
        return (start, start + len(token)), token
    return None


def _ref_row(rows, by_line, index, text, summary):
    row = by_line.get(str(index))
    if row is None:
        row = _new_row(index, summary, text)
        rows.append(row)
        by_line[str(index)] = row
    return row


def _attach(row, finding):
    known = row.setdefault(OUTLINE_KEY, [])
    key = (finding.get("start"), finding.get("row_note") or finding.get("quote"))
    if not any((f.get("start"), f.get("row_note") or f.get("quote")) == key for f in known):
        known.append(finding)


def add_refs(rows, references=None, drift=None, paragraphs=None):
    """把 Step 0.5 的條、款、項引用（需改寫／危險／無法判定）與「編號沒變、指到的內容變了」
    併進決定表，來源「條文引用」。同段次已經是候選就併進那一列（既有的決定不動）。

    references：renumber.scan_references 的結果（外部法規那幾筆不進表）；
    drift：scan_reference_drift（＋章節引用的「內容變了」），已經跟 references 去重過；
    paragraphs：決定表的那一份新版段落（重編過就是重編後的），候選全文照它寫。"""
    by_line = {r["候選段次"]: r for r in rows if r["候選段次"]}
    for f in references or []:
        if f.get("status") not in ("需改寫", "危險", "無法判定") or f.get("external"):
            continue
        if f.get("pre_existing"):
            continue      # 舊版同一處就是這樣（不是這次改出來的）：只留提醒，不叫人在這一輪決定
        index = f["index"]
        text = paragraphs[index - 1] if paragraphs and index <= len(paragraphs) else f["text"]
        where = _locate(text, f["text"], f.get("span") or f.get("ref_span"))
        quote = where[1] if where else f["quote"]
        entry = {"status": f["status"], "quote": quote, "new_quote": "", "note": f.get("note") or "",
                 "tag": _REF_TAGS.get(f.get("kind"), "引用換號")}
        if where:
            entry.update(start=where[0][0], end=where[0][1])
        if f["status"] == "需改寫" and f.get("new_quote") and where and f.get("span"):
            entry["new_quote"] = f["new_quote"]
            relation = "「%s」→「%s」" % (quote, f["new_quote"])
            change_id = REFS_REWRITE_ID
        else:
            mark = DANGER_MARK if f["status"] == "危險" else "【%s】" % f["status"]
            note = f.get("note") or ""
            # 說明自己已經用「引用字句」開頭的，不再疊一次
            head = "" if note.startswith("「%s」" % f["quote"]) else "「%s」：" % f["quote"]
            entry["row_note"] = "%s%s%s%s" % (
                mark, head, note,
                "；程式不給建議改法，請人工決定" if f["status"] != "無法判定" else "")
            relation = "「%s」%s" % (f["quote"], f["status"])
            change_id = REFS_CHANGE_ID
        row = _ref_row(rows, by_line, index, text, "重編或刪條後的條文引用")
        _merge(row, REFS_SOURCE, change_id, "", relation, "")
        _attach(row, entry)
    for d in drift or []:
        index = d["index"]
        text = paragraphs[index - 1] if paragraphs and index <= len(paragraphs) else d["text"]
        old_body = _summary(d.get("old_body") or "", 30)
        new_body = _summary(d.get("new_body") or "", 30) if d.get("new_body") is not None else "（新版沒有了）"
        # advisory：只是提醒要重看，不擋同一列別的來源（相似候選）算好的建議改法
        entry = {"status": "內容變了", "quote": d["quote"], "new_quote": "", "advisory": True,
                 "row_note": "【內容變了】「%s」編號沒變，但指到的%s這次內容有改（舊：%s；新：%s），"
                             "請確認引用是否仍然成立" % (d["quote"], d.get("target") or "", old_body, new_body)}
        row = _ref_row(rows, by_line, index, text, "引用的條文內容這次有改")
        _merge(row, REFS_SOURCE, REFS_CHANGE_ID, "", "「%s」指到的%s內容有改" % (d["quote"], d.get("target") or ""), "")
        _attach(row, entry)
    rows.sort(key=lambda r: (0 if r["候選段次"] else 1, int(r["候選段次"] or 0)))
    return rows


def add_definitions(rows, findings=None, paragraphs=None):
    """「定義變更連動」（定義被改了，全文用到這個詞的段落都要重看）與「定義刪除」（定義被刪了、
    這個詞別處還在用）併進決定表，來源「定義連動」。
    findings 是 rule_checks.check_definitions 的那幾筆（帶 term、users）。建議改法一律留空。"""
    by_line = {r["候選段次"]: r for r in rows if r["候選段次"]}
    for f in findings or []:
        term = f.get("term") or ""
        where = f.get("ref") or ("第%s段" % f.get("index") if f.get("index") else "")
        deleted = f.get("check") == "定義刪除"
        for index in f.get("users") or []:
            if not paragraphs or index > len(paragraphs):
                continue
            row = _ref_row(rows, by_line, index, paragraphs[index - 1], f.get("check") or "定義變更連動")
            _merge(row, DEFINITION_SOURCE, DEFINITION_CHANGE_ID, "",
                   "定義「%s」%s（%s）" % (term, "刪除" if deleted else "變更", where), "")
            note = ("【定義刪除】「%s」的定義這次被刪除（%s），本段仍用到這個詞，"
                    "請確認沒有定義之後意思是否仍然明確" if deleted else
                    "【定義變更】「%s」的定義這次有改（%s），本段用到這個詞，"
                    "請確認在新定義下是否仍然成立")
            _attach(row, {"status": "定義連動", "quote": term, "new_quote": "", "advisory": True,
                          "row_note": note % (term, where)})
    rows.sort(key=lambda r: (0 if r["候選段次"] else 1, int(r["候選段次"] or 0)))
    return rows


EXTERNAL_SOURCE = "外部引用"
# 驗收（finalize）才冒出來的候選：接進決定表最後面，來源多標這一個，人一眼看得出是後來才加的
FINAL_SOURCE = "終比對新候選"


def appended_row(row):
    """決定表建好之後才接上去的列（外部引用、驗收新候選）：AI候選判斷.csv 裡本來就沒有它們。"""
    sources = [x for x in (row.get("來源") or "").split("；") if x]
    return sources == [EXTERNAL_SOURCE] or FINAL_SOURCE in sources


def append_rows(table_path, new_rows, label=FINAL_SOURCE):
    """驗收才冒出來的候選接進連帶決定表：人在同一張表上決定，填完照樣套用、驗收。

    以前它們只列在驗收報告第三問，決定表上沒有這幾列，人無處可填，驗收就一直是
    「還有 N 處要看」。new_rows 的「候選段次」要已經換成草稿的段次（決定表的座標）。
    同段次已經有列就只補來源（決定不動）；沒有就**接在表的最後**（不重排，前面的列ID 不位移）。
    指紋檔的「列」只增不減。回傳新增幾列。"""
    from _common import open_csv
    with open_csv(table_path) as f:
        rows = [dict((k, v) for k, v in r.items() if k) for r in csv.DictReader(f)]
    book = next((r.get("規章") for r in rows if r.get("規章")), "")
    by_line = dict((r.get("候選段次"), r) for r in rows if r.get("候選段次"))
    added = []
    for new in new_rows:
        line = str(new["候選段次"])
        row = by_line.get(line)
        if row is None:
            row = _new_row(line_of(line), new.get("異動摘要") or "", new.get("候選全文") or "")
            if book:
                row["規章"] = book
            rows.append(row)
            by_line[line] = row
            added.append(row)
        source = "；".join(x for x in (new.get("來源") or "", label) if x)
        _merge(row, source, new.get("異動條文ID") or "", new.get("候選條文ID") or "",
               new.get("關係／分數") or "", new.get("經同義詞比對") or "")
    write_rows_csv(table_path, rows)
    if added:
        json_path = sidecar_path_for(table_path)
        sidecar = read_sidecar(json_path)
        entries = list(sidecar.get("列") or [])
        for row in added:
            entries.append({"候選段次": line_of(row["候選段次"]), "候選全文SHA256": text_sha256(row["候選全文"])})
        sidecar["列"] = entries
        tmp = json_path + ".tmp"
        with io.open(tmp, "w", encoding="utf-8") as f:
            json.dump(sidecar, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, json_path)
    return len(added)


def append_external_rows(table_path, fixes):
    """AI 外部引用檢查判「引用過時／條號錯誤」的，接進連帶決定表：建議改法寫好，人只要填「改」。

    fixes：[{段次, 候選全文, 建議改法, 異動內容, 關係}]。同段次已經有列就併進那一列（既有的決定、
    建議改法都不動，只補來源與異動內容）；沒有就**接在表的最後**（不重排，前面的列ID 才不會位移，
    AI候選判斷.csv 的 R 號還對得上）。指紋檔的「列」只增不減，跟 semantic 同一套。回傳新增幾列。"""
    rows = read_table(table_path)
    json_path = sidecar_path_for(table_path)
    sidecar = read_sidecar(json_path)
    by_line = dict((r["候選段次"], r) for r in rows if r["候選段次"])
    added = []
    for fix in fixes:
        line = str(fix["段次"])
        row = by_line.get(line)
        if row is None:
            row = _new_row(fix["段次"], "外部規章引用需更新", fix["候選全文"])
            row["來源"] = EXTERNAL_SOURCE
            rows.append(row)
            by_line[line] = row
            added.append(row)
        else:
            _merge(row, EXTERNAL_SOURCE, "", "", "", "")
        _merge(row, "", "外部引用", "", fix["關係"], "")
        notes = [x for x in (row.get("異動內容") or "").split("；") if x]
        if fix["異動內容"] not in notes:
            row["異動內容"] = "；".join(notes + [fix["異動內容"]])
        if not (row.get("建議改法") or "").strip():
            row["建議改法"] = fix["建議改法"]
    write_rows_csv(table_path, rows)
    if added:
        entries = list(sidecar.get("列") or [])
        for row in added:
            entries.append({"候選段次": line_of(row["候選段次"]), "候選全文SHA256": text_sha256(row["候選全文"])})
        sidecar["列"] = entries
        tmp = json_path + ".tmp"
        with io.open(tmp, "w", encoding="utf-8") as f:
            json.dump(sidecar, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, json_path)
    return len(added)


def outline_suggestion(text, findings):
    """照位置把每一處章節引用換成新寫法（由後往前換，前面的位置才不會跑掉）。

    只要有一處換不了（指到的地方刪掉了＝危險，或位置對不上原文）就整段回空字串：
    只換其中幾處，人照建議填「改」，危險的那一處就被當成處理過了。"""
    fixes = [f for f in findings if f.get("new_quote") and "start" in f
             and text[f["start"]:f["end"]] == f["quote"]]
    if not fixes or len(fixes) != len(findings):
        return ""
    fixes.sort(key=lambda f: -f["start"])
    for f in fixes:
        text = text[:f["start"]] + f["new_quote"] + text[f["end"]:]
    return text


def change_items(results):
    """實質異動清單的每一項（異動清單.json 裡存的就是這個樣子）。"""
    items = []
    for r in results:
        if r.get("type") not in TYPE_LABELS:
            continue
        items.append({"序號": len(items) + 1, "修改類型": TYPE_LABELS[r["type"]],
                      "old_text": r.get("old_text") or "", "new_text": r.get("new_text") or "",
                      "old_index": r.get("old_index"), "new_index": r.get("new_index"),
                      "ref": r.get("ref") or "", "scope": r.get("scope") or "",
                      "spec_ids": list(r.get("spec_ids") or [])})
        move = r.get("moved_to") or r.get("moved_from")
        if move:
            # 搬移（diff_compare._mark_moves）：類型照舊是刪除／新增，這一欄講搬去哪、從哪來，
            # 讀異動清單的人與 AI 才不會把移列當成廢止一條、新訂一條
            import diff_compare
            items[-1]["移列"] = {"方向": "移出" if r.get("moved_to") else "移入",
                               "對應條號": move.get("ref") or "",
                               "對應段次": move.get("new_index") or move.get("old_index"),
                               "內容相同": bool(move.get("identical")),
                               "說明": diff_compare.move_note(r)}
    return items


def write_change_list(results, path):
    """實質異動清單，給 review-pack 用。修正對照表的欄名可由設定檔改，所以另存一份固定格式。"""
    items = change_items(results)
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return items


def sidecar_path_for(table_path):
    """一張表（連帶決定表.csv／終比對候選表.xlsx）的指紋檔在哪裡。

    指紋檔一律進 系統檔案/：它是程式接力用的中繼檔，跟表本身放哪一格無關。
    連帶決定表是「人要填」的表（填寫表單/），終比對候選表是「人要看」的表
    （審閱文件/），兩張表的指紋檔都落在同一個 <X>/系統檔案/<同名>.json——
    不然 審閱文件/ 裡會多出一個沒人看得懂、也沒登記在 FILE_HOMES 的 .json。

    所以判斷方式是「表的上一層資料夾是不是三格之一」：是的話往上一層找
    系統檔案/，不是的話（舊排法的平鋪產出、或使用者自己複製一份到桌面上填）
    退回同資料夾的同名 .json——那種情況沒有三格可言，硬要往上找一層只會
    指到一個不存在的地方。

    這裡刻意**不用** _common.place：place 會順手把資料夾建出來，而這一支
    大多數呼叫端是「讀」（apply／finalize 要驗指紋），讀一個路徑不該在
    別人的資料夾裡長出空的 系統檔案/。要寫的那一端自己用 place。
    """
    name = os.path.basename(os.path.splitext(table_path)[0]) + ".json"
    folder = os.path.dirname(table_path)
    if os.path.basename(folder) in OUTPUT_DIRS:
        return os.path.join(os.path.dirname(folder), SYSTEM_DIR, name)
    return os.path.join(folder, name)


def write_table(rows, table_path, json_path, draft_path, changed_texts=None, extra=None,
                params=None, fmt="csv", written=None, old_path=None):
    """寫一張候選表＋它的指紋檔。

    params（選填）：這次初比對實際用的四個 Step 2 門檻
    {"threshold","top","changed_top","sentence_threshold"}，記進指紋檔鍵「比對參數」。
    終比對（finalize／batch-finalize）沒有在命令列另外指定這幾個旗標時，要讀這裡
    記的值沿用初比對的門檻，不能悄悄退回程式自己的硬預設——不然終比對候選表會
    多或少候選，跟初比對兜不起來，人在對照兩張表時看不出差在哪。

    fmt："csv" 是人要**填**的那張表（連帶決定表：程式回頭要讀它，格式不能變）；
    "xlsx" 是人只要**看**的那張表（終比對候選表：欄寬、換行、粗體標題列都留得住），
    走 xlsx_writer.write_tables_or_csv，寫不出來才自動退成 csv。指紋檔兩種都照舊寫。

    written（選填）：給呼叫端收「實際寫出了哪幾個檔」的 list。xlsx 退成 csv 時
    路徑會跟 table_path 不同，呼叫端的產出清單要印的是真的寫出來的那一個。
    """
    extra = dict(extra or {})
    unknown = [k for k in extra if k not in OPTIONAL_COLUMNS]
    if unknown:
        raise DecisionTableError("不認得的額外欄：%s" % "、".join(unknown))
    # 選填欄的來源有兩個：呼叫端統一指定的 extra（例如批次的「規章」），
    # 以及列自己就帶著的（build_rows 填的「修改類型」）。只看 extra 的話，
    # 列上填好的修改類型會在寫檔這一步整欄消失。順序照 OPTIONAL_COLUMNS。
    # 「相似分數」一律寫（每次照「關係／分數」重算）
    fields = ordered_fields(COLUMNS + [c for c in OPTIONAL_COLUMNS
                                       if c == SCORE_COLUMN or c in extra or any(c in r for r in rows)])
    if fmt == "xlsx":
        import xlsx_writer as xw
        base = os.path.splitext(table_path)[0]
        sheet = os.path.basename(base)
        cells = [[as_number(_cell_value(row, c)) if c == SCORE_COLUMN else row.get(c, extra.get(c, ""))
                  for c in fields] for row in rows]
        paths = xw.write_tables_or_csv(base, [(sheet, fields, cells)], source=sheet)
    else:
        with io.open(table_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields, quoting=csv.QUOTE_ALL)
            writer.writeheader()
            for row in rows:
                writer.writerow({c: _cell_value(row, c, extra.get(c, "")) for c in fields})
        paths = [table_path]
    if written is not None:
        written.extend(paths)
    sidecar = {
        "格式版本": 1,
        "產生時間": datetime.datetime.now().astimezone().isoformat(),
        "草稿": {"檔名": os.path.basename(draft_path), "SHA256": file_sha256(draft_path)},
        "異動段落SHA256": sorted({text_sha256(t) for t in (changed_texts or []) if t}),
        "列": [{"候選段次": _line_of(r["候選段次"]),
               "候選全文SHA256": text_sha256(r["候選全文"])} for r in rows],
    }
    if params:
        sidecar["比對參數"] = dict(params)
    if old_path:
        # 舊版也記一筆：review-pack 讀留底的舊版時，要拿這張表當初對的那一份來驗，
        # 輸入指紋.json 會被之後的 stage_inputs 跟著覆寫，當不了憑據。
        sidecar["舊版"] = {"檔名": os.path.basename(old_path), "SHA256": file_sha256(old_path)}
    with io.open(json_path, "w", encoding="utf-8") as f:
        json.dump(sidecar, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return sidecar


def as_number(value):
    """寫進 xlsx 的分數用數字格，Excel 才排得了序；不是數字照原字。"""
    try:
        return float(value) if value not in (None, "") else ""
    except (TypeError, ValueError):
        return value


def read_sidecar(json_path):
    if not os.path.isfile(json_path):
        raise DecisionTableError(
            "找不到決定表的指紋檔：%s（compare 產生的 .json 要跟 .csv 放在一起）" % json_path)
    with io.open(json_path, encoding="utf-8-sig") as f:
        data = json.load(f)
    if data.get("格式版本") != 1 or "草稿" not in data or "列" not in data:
        raise DecisionTableError("指紋檔格式不對：%s" % json_path)
    return data


def match_sidecar(rows, entries):
    """決定表的每一列對到指紋檔「列」的哪一筆。回傳 (列索引 → 指紋索引或 None, 沒人對到的指紋索引)。

    全案只有這一套對法：review-import 驗原文、semantic 沿用指紋、finalize 找被刪掉的列
    都用它，三邊才不會一邊說「這列被手改過」、另一邊說「這列被刪掉了」。

    依序三輪，每一筆指紋只給一列：
        一、段次與候選全文指紋都一樣            → 原封不動的列
        二、候選全文指紋一樣、段次不同          → 人補了或改了段次（apply 的「找不到段」
                                                 就是叫人這樣做），不是刪列
        三、段次一樣、指紋不同                  → 同一列，但候選全文被手改過
    不看列序：Excel 裡排序過、刪過列，以前「先比同索引」的做法會把鄰列的指紋配給沒有段次的列。
    剩下沒對到的列＝指紋檔沒記過（段次與全文都被改過）；沒對到的指紋＝表上被刪掉的列。
    """
    used = set()
    matched = {}

    def take(index, pick):
        for k, entry in enumerate(entries):
            if k not in used and pick(entry):
                used.add(k)
                matched[index] = k
                return

    keys = [(line_of(row.get("候選段次")), text_sha256(row.get("候選全文") or "")) for row in rows]
    for index, (line, sha) in enumerate(keys):
        take(index, lambda e: (e.get("候選段次") or 0) == line and e.get("候選全文SHA256") == sha)
    for index, (line, sha) in enumerate(keys):
        if index not in matched:
            take(index, lambda e: e.get("候選全文SHA256") == sha)
    for index, (line, sha) in enumerate(keys):
        if index not in matched and line:
            take(index, lambda e: (e.get("候選段次") or 0) == line)
    result = dict((index, matched.get(index)) for index in range(len(rows)))
    return result, [k for k in range(len(entries)) if k not in used]


class _Row(dict):
    """read_table 讀回的一列。raw 記「人寫的原字」與「讀進來時正規化成的樣子」：
    {欄: (原字, 正規化後)}。write_rows_csv 寫回時，程式沒動過的格照原字寫回（B18）——
    以前整張表照正規化後的樣子寫回，人填的「是」變成「改」、留空的「改成什麼」被填進
    建議改法，人再打開表看到的已經不是自己寫的。程式真的改過的格（核准寫的「改」）照新值寫。"""
    __slots__ = ("raw",)


# Excel 用「CSV（逗號分隔）」另存的決定表是 Big5（cp950）：Big5 沒有的字（罕用字、
# 部分符號）存檔當下就被換成半形「?」，檔案裡已經沒有原字，程式讀得懂但救不回來（第三批）。
BIG5_SAVE_HINT = "請回 Excel 把那幾格改回正確的字，另存新檔時存檔類型選「CSV UTF-8（逗號分隔）」，再跑一次"


def _suspect_question_marks(row):
    """「改成什麼」裡的半形「?」比候選全文多：多半是 Big5 存不了的字被換掉了。"""
    return (row.get("改成什麼") or "").count("?") > (row.get("候選全文") or "").count("?")


def read_table(csv_path):
    text, encoding = read_csv_text(csv_path)
    big5 = encoding in EXCEL_ANSI_ENCODINGS
    if big5 and nt.once(("決定表Big5", os.path.abspath(csv_path))):
        nt.notice(nt.REMINDER,
                  "%s 是用 Excel「CSV（逗號分隔）」存的（Big5）：Big5 存不了的字會變成「?」。"
                  "下次另存請選「CSV UTF-8（逗號分隔）」" % os.path.basename(csv_path), "讀決定表")
    reader = csv.DictReader(io.StringIO(text, newline=""))
    missing = [c for c in COLUMNS if c not in (reader.fieldnames or [])]
    if missing:
        raise DecisionTableError("決定表缺欄位：%s" % "、".join(missing))
    rows = [_Row(r) for r in reader]
    garbled = []
    for index, row in enumerate(rows, 2):
        original = dict((c, row.get(c) or "") for c in ("要改嗎", "改成什麼"))
        written = (row.get("要改嗎") or "").strip()
        action = normalize_action(written)
        # 帶換行的兩欄先把 Excel 存出來的 \r\n 收斂成 \n（見 normalize_newlines）。
        # 草稿裡的 <w:br/> 讀進來是 \n，不收斂的話這一列會被判成「原文不符」而跳過。
        row["候選全文"] = normalize_newlines(row.get("候選全文") or "")
        row["改成什麼"] = normalize_newlines(row.get("改成什麼") or "")
        if action is None:
            raise DecisionTableError(
                "第 %d 列「要改嗎」寫了認不得的字：「%s」。填 改／刪除／不改（或 是／否、維持、刪掉 這類意思清楚的字），"
                "還沒決定就留空" % (index, written))
        row["要改嗎"] = action
        if action == "改" and not row["改成什麼"].strip():
            # 填了「改」、「改成什麼」留空＝照「建議改法」改：章節引用、跨本引用換號、外部引用過時
            # 這幾種建議改法是程式照位置換好的，人只要打一個「改」字，不用再抄一次
            suggestion = normalize_newlines(row.get("建議改法") or "")
            if not suggestion.strip():
                raise DecisionTableError(
                    "第 %d 列填了「改」但「改成什麼」是空的（這一列也沒有建議改法可以照用）" % index)
            row["改成什麼"] = suggestion
        row.raw = dict((c, (original[c], row[c])) for c in original)
        if action == "改" and _suspect_question_marks(row):
            garbled.append(index)
    if garbled and big5:
        # Big5 存的表：「?」幾乎一定是存檔弄壞的字，照寫就把「?」寫進定稿。擋下來。
        raise DecisionTableError(
            "第 %s 列「改成什麼」有半形「?」而候選全文沒有：這張表是 Big5（Excel「CSV（逗號分隔）」）存的，"
            "Big5 存不了的字已經被換成「?」。%s" % ("、".join(str(i) for i in garbled), BIG5_SAVE_HINT))
    if garbled and nt.once(("決定表問號", os.path.abspath(csv_path), tuple(garbled))):
        # UTF-8 的表：可能是人真的要打「?」，也可能是以前 Big5 存過、再轉回 UTF-8 留下的，不擋但講清楚
        nt.notice(nt.WARNING,
                  "%s 第 %s 列「改成什麼」有半形「?」而候選全文沒有：如果那是 Big5 存檔弄壞的字，"
                  "會照樣寫進定稿，請確認" % (os.path.basename(csv_path), "、".join(str(i) for i in garbled)),
                  "讀決定表")
    return rows


def write_rows_csv(path, rows):
    """把 read_table 讀回、人改過的列寫回去；保留 COLUMNS 之外的額外欄；先寫 .tmp 再 os.replace。

    額外欄要看「全部列」有沒有任何一列帶這個欄，不能只看 rows[0]：add_semantic／
    add_cross 用 _new_row 造的新列本來就沒有 AI／規章欄，這種新列如果排序後排第一，
    只看 rows[0].keys() 會讓整張表的 AI 三欄與「規章」欄整個消失，即使其他列都有值。

    使用者自己在 Excel 加的欄（「承辦註記」「複核意見」這類）也一起留著，排在
    已知欄後面，彼此的順序照原表頭（read_table 用 DictReader，每一列的鍵順序
    就是表頭順序）。以前用白名單挑欄，自加的欄整欄無聲消失——法遵填了一整輪
    註記，跑一次 review-import 就全部不見，而且沒有任何一句話說它被丟掉了。
    模組 docstring 與規格 §6.3 寫的都是「照留」。"""
    extra = [c for c in OPTIONAL_COLUMNS if c == SCORE_COLUMN or any(c in r for r in rows)]
    known = set(COLUMNS) | set(OPTIONAL_COLUMNS)
    user_added = []
    for row in rows:
        for column in row:
            # DictReader 多出來的值會塞在 restkey（None）底下，那不是欄名。
            if column is None or column in known or column in user_added:
                continue
            user_added.append(column)
    fields = ordered_fields(COLUMNS + extra + user_added)
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, quoting=csv.QUOTE_ALL)
        writer.writeheader()
        for row in rows:
            out = {c: _cell_value(row, c) for c in fields}
            for column, (original, normalized) in (getattr(row, "raw", None) or {}).items():
                if row.get(column) == normalized:
                    out[column] = original       # 程式沒動過：照人寫的原字寫回
            writer.writerow(out)
    os.replace(tmp, path)
