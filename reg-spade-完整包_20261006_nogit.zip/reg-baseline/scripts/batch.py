# -*- coding: utf-8 -*-
"""
多本批次與跨本連帶：清單讀取、跨本候選、引用連帶、批次摘要。

跨本候選只列不判：A 本改了某條，到 B 本草稿找整條相似、關鍵詞命中；
B 本有規格包時，再看 B 的引用表有沒有引用到 A 本被改的那條。
每一筆都帶兩條全文與分數，理由由 AI 在第 2 步寫，人決定。
"""

import csv
import io
import os
import re
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import fuzzy_duplicate_finder as fuzzy
import notices as nt
from _common import (book_dir, build_hierarchy, diff_runs, extract_article_no, format_scope, locate,
                     normalize_terms)
from _common import cn_to_int as _common_cn_to_int

MANIFEST_COLUMNS = ["規章名", "舊版", "新版草稿", "發布根目錄"]


class BatchError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 規章清單
# ---------------------------------------------------------------------------

def folder_key(name):
    """規章名落到磁碟上是哪一個資料夾：<產出>/<規章名>/ 撞不撞，要用這把尺比。

    Windows（和 macOS 預設的檔案系統）資料夾名不分大小寫，Windows 還會把名稱結尾的
    「.」和空白吃掉。只比原字串的話「規章A」「規章a」會被當成兩本，實際寫進同一個
    資料夾。這裡一律照最嚴的那一種比（不管現在跑在哪個平台）：同一份清單拿到
    Windows 上跑也不會撞。比嚴了頂多是請人改個名，比鬆了是整本產出被蓋掉。
    """
    import unicodedata
    return unicodedata.normalize("NFC", name).rstrip(". ").casefold()


def read_manifest(path):
    """讀規章清單.csv；相對路徑以清單所在資料夾為準。任何一列不合法就整支停。"""
    if not os.path.isfile(path):
        raise BatchError("找不到規章清單：%s" % path)
    base = os.path.dirname(os.path.abspath(path))
    from _common import open_csv
    with open_csv(path) as f:        # 人會用 Excel 改清單，另存可能是 Big5
        reader = csv.DictReader(f)
        missing = [c for c in MANIFEST_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise BatchError("規章清單缺欄位：%s" % "、".join(missing))
        rows = list(reader)

    def resolve(value):
        value = (value or "").strip()
        if not value:
            return ""
        return os.path.normpath(value if os.path.isabs(value) else os.path.join(base, value))

    docs = []
    seen = {}          # folder_key(規章名) -> (第一次用到它的列號, 那一列寫的規章名)
    seen_old = {}      # normcase(絕對路徑) -> 第一次用到它的列號，見 item8
    seen_draft = {}
    for index, row in enumerate(rows, 2):
        name = (row.get("規章名") or "").strip()
        if not name:
            raise BatchError("第 %d 列規章名空白" % index)
        if name in (".", "..") or os.path.basename(name) != name:
            raise BatchError("第 %d 列規章名不能含路徑字元：%s" % (index, name))
        key = folder_key(name)
        from _common import BATCH_RESERVED
        if key in set(folder_key(r) for r in BATCH_RESERVED):
            # 各本的過程檔放在 產出/系統檔案/<規章名>/，送簽文件排在 產出/結果彙整/<種類>/<規章名>_…；
            # 規章名跟那幾個固定資料夾同名會撞在一起
            raise BatchError("第 %d 列規章名不能叫「%s」（跟產出資料夾裡的固定資料夾同名），請改名"
                             % (index, name))
        if key in seen:
            # no 15：這則訊息現在也會出現在「配對」階段（cmd_pair 寫完清單就跑同一套
            # 驗證），跟其他每一則一樣要講是哪一列，人才知道要去改清單的哪一行。
            first_index, first_name = seen[key]
            if first_name == name:
                raise BatchError("第 %d 列規章名重複：%s（與第 %d 列相同）"
                                 % (index, name, first_index))
            # 字面不同、資料夾卻是同一個：「規章A」「規章a」在 Windows 上會寫進同一個
            # <產出>/<規章名>/，後跑的那本整本蓋掉前一本，batch 照樣 exit 0。
            raise BatchError("第 %d 列規章名「%s」與第 %d 列「%s」只差大小寫或結尾的點／空白，"
                             "產出會寫進同一個資料夾、後一本蓋掉前一本；請把其中一本改名"
                             % (index, name, first_index, first_name))
        seen[key] = (index, name)
        old_raw = (row.get("舊版") or "").strip()
        if not old_raw:
            # 工作區「配對」寫出的清單，舊版空白代表這本還沒配對成功（未配對／
            # 多個候選都是舊版留空）——跟「填了路徑但檔案不見了」是兩回事，訊息
            # 分開講，才不會誤導使用者去找一個根本沒填過的檔案。
            # item7：多個候選時，「配對」已經把候選寫進「備註」欄
            # （merge_manual／match，例如「多個候選：甲、乙」）——原樣附進錯誤
            # 訊息，人不用另外開清單就知道要在哪幾個裡面選。
            note = (row.get("備註") or "").strip()
            suffix = "（備註：%s）" % note if note else ""
            raise BatchError("第 %d 列（%s）未配對，請先處理%s" % (index, name, suffix))
        old = resolve(old_raw)
        if not os.path.isfile(old):
            raise BatchError("第 %d 列（%s）舊版檔不存在：%s" % (index, name, old))
        # item8：兩列指到同一份舊版／新版草稿檔，套用時後面那本會把前一本的異動
        # 誤判成自己的（同一份 .docx 被兩本各自複製、各自開追蹤修訂，內容卻是同
        # 一份），不能放行——normcase 是為了 Windows 大小寫不敏感的路徑也抓得到。
        old_key = os.path.normcase(os.path.abspath(old))
        if old_key in seen_old:
            raise BatchError("第 %d 列（%s）舊版重複使用：%s（與第 %d 列相同）"
                             % (index, name, old, seen_old[old_key]))
        seen_old[old_key] = index
        draft = resolve(row.get("新版草稿"))
        if draft and not os.path.isfile(draft):
            raise BatchError("第 %d 列（%s）新版草稿不存在：%s" % (index, name, draft))
        if draft:
            draft_key = os.path.normcase(os.path.abspath(draft))
            if draft_key in seen_draft:
                raise BatchError("第 %d 列（%s）新版草稿重複使用：%s（與第 %d 列相同）"
                                 % (index, name, draft, seen_draft[draft_key]))
            seen_draft[draft_key] = index
        release = resolve(row.get("發布根目錄"))
        if release and not os.path.isfile(os.path.join(release, "LATEST.json")):
            raise BatchError("第 %d 列（%s）發布根目錄缺 LATEST.json：%s" % (index, name, release))
        docs.append({"規章名": name, "舊版": old, "草稿": draft or old,
                     "有草稿": bool(draft), "發布根目錄": release})
    if not docs:
        raise BatchError("規章清單沒有任何規章")
    return docs


# 一本要能進 batch-review-pack／batch-review-import，這三個檔案缺一不可
# （相對 <outdir>/<規章名>/ 的路徑，顯示用的標籤是給人看的）：
# 連帶決定表.csv（填寫表單/）、異動清單.json（系統檔案/）是 compare 產出；
# 系統檔案/輸入/輸入指紋.json 是 stage_inputs 產出的指紋檔，rp.load_book 用它核對
# 草稿沒被換掉。三個只要缺一個，rp.load_book 就會在 write_pack／import_review
# 半路才炸，不如在 list_books 這一關先篩掉。
# 每一項是 (檔名, 顯示標籤, 資料夾底下的檔名)；實際路徑一律由 _common.locate 算
# （新排法優先，找不到再看舊排法的平鋪），指紋檔另外接在「輸入」資料夾底下。
_REQUIRED_BOOK_FILES = [
    ("連帶決定表.csv", "連帶決定表.csv", ""),
    ("異動清單.json", "異動清單.json", ""),
    ("輸入", "輸入/輸入指紋.json", "輸入指紋.json"),
]


def _book_file(outdir_doc, name, tail=""):
    """一本產出裡某個檔的實際路徑（新排法優先，找不到退舊平鋪）。

    tail 是接在資料夾底下的檔名（輸入/輸入指紋.json、輸入/規章清單.csv）。
    這種要多退一手：locate 看的是「輸入 這個資料夾」在不在，資料夾在、裡面那個檔
    卻不在的時候（半搬過的資料夾），還是要回頭找舊排法的 <outdir>/輸入/<tail>，
    不然會拿著一個不存在的新路徑去報「找不到規章清單」。
    """
    path = locate(outdir_doc, name)[0]
    if not tail:
        return path
    full = os.path.join(path, tail)
    if os.path.exists(full):
        return full
    legacy = os.path.join(outdir_doc, name, tail)
    return legacy if os.path.exists(legacy) else full


# 沒放修訂版、別本的改動也沒影響到的規章：只讀過全文當「被查對象」，沒有產出資料夾，
# 後面每一個批次指令都不處理它們（見 run_all.cmd_batch）。記規章名與它的舊版路徑：
# batch-semantic 在別台算出它有語意候選時，要靠這份把它拉進流程（不必再讀工作區的清單）。
UNAFFECTED_FILE = "未受影響規章.json"


def unaffected_path(root):
    from _common import SYSTEM_DIR
    return os.path.join(root, SYSTEM_DIR, "輸入", UNAFFECTED_FILE)


def unaffected_docs(root):
    """這一輪沒進流程的規章：{規章名: read_manifest 那種 doc}。沒有這個檔（舊的產出資料夾、單本）回 {}。"""
    import json
    path = unaffected_path(root or "")
    if not root or not os.path.isfile(path):
        return {}
    try:
        with io.open(path, encoding="utf-8") as f:
            return dict((doc["規章名"], doc) for doc in json.load(f))
    except (OSError, ValueError, KeyError, TypeError):
        return {}


def unaffected_books(root):
    """這一輪沒進流程的規章名（set）。"""
    return set(unaffected_docs(root))


def write_unaffected(root, docs):
    """docs：read_manifest 那種 doc 的 list（路徑寫絕對路徑）。"""
    import json
    path = unaffected_path(root)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump([dict(doc, 舊版=os.path.abspath(doc["舊版"]), 草稿=os.path.abspath(doc["草稿"]))
                   for doc in docs], f, ensure_ascii=False, indent=1)


# 快取（語意向量、AI 查證結果）放在現行規章那個資料夾底下的 系統快取/：跨很多輪一直累積，
# 「開始」歸檔上一輪不會搬走它。批次產出記一個指標，後面的指令（review-pack／import、
# 手動語意指令）照它找。清單裡的舊版不在同一個資料夾（自己寫的清單）就不用快取。
CACHE_POINTER = "快取位置.txt"
CACHE_DIR = "系統快取"


def cache_dir_for_docs(docs):
    folders = set(os.path.dirname(os.path.abspath(doc["舊版"])) for doc in docs)
    return os.path.join(folders.pop(), CACHE_DIR) if len(folders) == 1 else ""


def write_cache_pointer(root, folder):
    """記成相對產出根目錄的路徑（../匯入/現行規章/系統快取）：整個工作區複製到別台電腦
    （有語意模型的那台）時照樣找得到；不在同一個磁碟才記絕對路徑。"""
    from _common import SYSTEM_DIR
    path = os.path.join(root, SYSTEM_DIR, "輸入", CACHE_POINTER)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    value = folder or ""
    if value:
        try:
            value = os.path.relpath(value, os.path.abspath(root))
        except ValueError:
            pass
    with io.open(path, "w", encoding="utf-8") as f:
        f.write(value)


def cache_dir(outdir):
    """批次產出（根或其中一本）用的快取資料夾；沒有回 ""。"""
    from _common import SYSTEM_DIR, batch_root_of
    for root in (batch_root_of(outdir) if outdir else "", outdir):
        if not root:
            continue
        path = os.path.join(root, SYSTEM_DIR, "輸入", CACHE_POINTER)
        if os.path.isfile(path):
            with io.open(path, encoding="utf-8") as f:
                value = f.read().strip()
            if value and not os.path.isabs(value):
                value = os.path.normpath(os.path.join(os.path.abspath(root), value))
            return value
    return ""


def active_docs(docs, root):
    """read_manifest 的結果拿掉這一輪沒進流程的規章（batch-apply／batch-finalize 用）。"""
    skip = unaffected_books(root)
    return [doc for doc in docs if doc["規章名"] not in skip]


def list_books(outdir):
    """給 batch-review-pack／batch-review-import 用：讀 <outdir>/系統檔案/輸入/規章清單.csv
    （batch 已經把使用者原始清單複製進來，見 run_all.stage_inputs；舊排法的產出資料夾
    退回 <outdir>/輸入/規章清單.csv）取規章名順序，回傳 [(規章名, <outdir>/<規章名>), ...]。

    清單裡「舊版」「新版草稿」「發布根目錄」欄記的是複製前、原始清單所在資料夾的相對
    路徑，搬到留底資料夾之後大多已經找不到那些檔案——但這裡只需要規章名順序，
    所以不用 read_manifest（找不到檔案就整支停），改用 csv.DictReader 只讀規章名欄。

    產出不完整的本（缺 _REQUIRED_BOOK_FILES 任何一個——那一本當初 batch 就失敗、
    還沒跑過 batch，或是被手動刪掉了某個檔案）跳過並印出缺了什麼；一本都不剩就
    raise BatchError。"""
    path = _book_file(outdir, "輸入", "規章清單.csv")
    if not os.path.isfile(path):
        raise BatchError("找不到規章清單：%s（請先跑 batch）" % path)
    from _common import open_csv
    with open_csv(path) as f:
        reader = csv.DictReader(f)
        if "規章名" not in (reader.fieldnames or []):
            raise BatchError("規章清單缺欄位：規章名")
        rows = list(reader)

    books = []
    skip = unaffected_books(outdir)
    for row in rows:
        name = (row.get("規章名") or "").strip()
        if not name or name in skip:
            continue
        outdir_doc = book_dir(outdir, name)
        missing = [label for name_, label, tail in _REQUIRED_BOOK_FILES
                   if not os.path.isfile(_book_file(outdir_doc, name_, tail))]
        if missing:
            print("略過 %s：產出不完整（缺 %s）" % (name, "、".join(missing)))
            continue
        books.append((name, outdir_doc))
    if not books:
        raise BatchError("規章清單裡沒有任何一本有完整產出（請先跑 batch）")
    return books


# ---------------------------------------------------------------------------
# 條號正規化：中文數字轉半形數字，讓「第三十四條」對得上「第34條」
# ---------------------------------------------------------------------------

_CN_DIGIT = {"零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "三": 3, "四": 4,
             "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
_CN_UNIT = {"十": 10, "百": 100, "千": 1000}
_CN_RUN = re.compile("[%s%s]+" % ("".join(_CN_DIGIT), "".join(_CN_UNIT)))


def cn_to_int(text):
    total = 0
    number = 0
    for ch in text:
        if ch in _CN_DIGIT:
            number = _CN_DIGIT[ch]
        elif ch in _CN_UNIT:
            total += (number if number else 1) * _CN_UNIT[ch]
            number = 0
    return total + number


def normalize_article_no(text):
    text = re.sub(r"\s+", "", text or "")
    text = text.replace("（", "(").replace("）", ")")
    return _CN_RUN.sub(lambda m: str(cn_to_int(m.group(0))), text)


# ---------------------------------------------------------------------------
# 跨本候選：相似 + 關鍵詞
# ---------------------------------------------------------------------------

def _label(source_name, change):
    """沒有規格包 ID 也沒有條號時退回段次，標籤才不會只剩「A名：」。"""
    tag = change.get("條文ID") or change.get("ref") or ("段次 %s" % change.get("段次", ""))
    return "%s：%s" % (source_name, tag)


def _row(source, label, summary, cand_id, line, text, relation, evidence=""):
    return {"來源": source, "異動條文ID": label, "異動摘要": summary, "候選條文ID": cand_id or "",
            "候選段次": str(line) if line else "", "候選全文": text or "",
            "關係／分數": relation, "經同義詞比對": evidence}


def cross_candidates(source_name, source_changes, target_paragraphs, synonyms,
                     threshold, top, changed_top, sentence_threshold=fuzzy.DEFAULT_SENTENCE_THRESHOLD,
                     target_kinds=None):
    """拿 A 本每個異動到 B 本草稿找整條相似與關鍵詞命中。B 本沒有「自己那段」要排除，
    所以 exclude_index 用 0（不會等於任何段次，也關掉「文字完全相同就跳過」）。

    target_kinds 是 B 本每一段的來源種類（"p"／"cell"），跟 compare 用同一份層級脈絡，
    候選的條號才不會跟 B 本自己的修正對照表對不起來。"""
    contexts = build_hierarchy(target_paragraphs, target_kinds)
    out = []

    def tag(row, index, kind, score):
        # 給 select_cross 用的內部欄（不寫進決定表）：哪一處異動、哪一種找法、分數
        row[CROSS_CHANGE_KEY] = (source_name, index)
        row[CROSS_KIND_KEY] = kind
        row[CROSS_SCORE_KEY] = float(score)
        return row

    for index, change in enumerate(source_changes):
        label = _label(source_name, change)
        summary = dt._summary(change["new_text"])
        for c in fuzzy.find_duplicates(change["new_text"], target_paragraphs, threshold=threshold,
                                       top=top, exclude_index=0, contexts=contexts,
                                       synonyms=synonyms, changed_old_text=change.get("old_text")):
            relation = "跨本相似 %s 分" % c["similarity"]
            if c.get("fragment_position"):
                relation += "、%s" % c["fragment_position"]
            out.append(tag(_row("跨本", label, summary, "", c["line_number"], c["text"], relation,
                                "、".join(c.get("synonym_evidence") or [])), index, "相似", c["similarity"]))
        fragments = fuzzy.changed_fragments(change.get("old_text") or "", change["new_text"], diff_runs)
        if fragments:
            for h in fuzzy.find_by_changed_text(fragments, target_paragraphs, exclude_index=0,
                                                contexts=contexts, synonyms=synonyms,
                                                normalize=normalize_terms,
                                                extract_article_no=extract_article_no,
                                                format_scope=format_scope, top=changed_top):
                terms = "、".join(t for _, t in h["matched"])
                out.append(tag(_row("跨本", label, summary, "", h["line_number"], h["text"],
                                    "跨本命中「%s」" % terms), index, "命中", h["strength"]))
        else:
            # 一字之差沒有片段可搜，改用改動處左右文脈；whole_only=True 只用整段文脈
            # 當詞，不拆前後綴子詞——文脈本身只有 4 個字，拆出來的 2 字子詞辨識力低。
            context_terms = fuzzy.context_fragments(change.get("old_text") or "", change["new_text"], diff_runs)
            for h in fuzzy.find_by_changed_text(context_terms, target_paragraphs, exclude_index=0,
                                                contexts=contexts, synonyms=synonyms,
                                                normalize=normalize_terms,
                                                extract_article_no=extract_article_no,
                                                format_scope=format_scope, top=changed_top,
                                                whole_only=True):
                terms = "、".join(t for _, t in h["matched"])
                out.append(tag(_row("跨本（文脈）", label, summary, "", h["line_number"], h["text"],
                                    "跨本文脈「%s」" % terms), index, "文脈", h["strength"]))

        if sentence_threshold and sentence_threshold > 0:
            # 目前 cmd_batch 只把 type in ("added","modified") 且 new_text 非空的項目
            # 放進 source_changes，刪除段落不會走到這裡；這裡仍防禦式地把
            # 「deleted 旗標」與「new_text 空/缺」兩種可能表示法都當成「沒有新文」，
            # 跟 run_all.step_duplicates 的處理一致，避免日後放寬篩選時又比出空結果。
            cross_new_text = "" if change.get("deleted") or not change.get("new_text") else change["new_text"]
            sentences = fuzzy.changed_sentences(change.get("old_text") or "", cross_new_text, diff_runs)
            for h in fuzzy.find_by_sentence(sentences, target_paragraphs, threshold=sentence_threshold,
                                            top=top, exclude_index=0, contexts=contexts, synonyms=synonyms):
                out.append(tag(_row("跨本（句）", label, dt._summary(h["changed_sentence"]), "", h["line_number"],
                                    h["text"], "跨本句 %s 分：%s" % (h["sentence_score"],
                                                                  dt._summary(h["matched_sentence"], 30)),
                                    "、".join(h.get("synonym_evidence") or [])), index, "句", h["sentence_score"]))
    return out


# ---------------------------------------------------------------------------
# 跨本候選分層＋全域上限
# ---------------------------------------------------------------------------
# 以前是「每一處異動，在每一本各取前幾名」：規章越多，決定表越長（實測 300 本×3 本有改，
# 模擬資料 3 萬 2 千列），「陳報主管」這種套語會把幾乎每一本都拉進流程，人與 AI 都看不完。
# 改成照證據強弱分層：
#   一定列  明確引用（跨本引用、規格包引用：沒有下面這幾個內部欄的列）
#   一定列  舊值原樣還在（這一處的改法套得上候選段：建議改法寫得出來），而且是相似或同句找到的；
#           分數 CROSS_STRONG_SURE 以上的全列，其餘每一處異動、全部規章合計最多 CROSS_STRONG_TOP 段
#   限量列  其他只是相似的：每一處異動、每一種找法（相似／句／命中／文脈），全部規章加起來只留
#           分數最高的 CROSS_TOP 段，其餘講一聲「另有 N 段相似度較低，未列」
# 列數因此由「改了幾處」決定，不再由「放了幾本規章」決定。
CROSS_TOP = 10
# 「舊值原樣還在」那一層的上限（每一處異動、全部規章合計）。以前這層一律列：舊字是常見字
# （「七日」）時，一處修改就列出幾百列（實測 20 本 296 列）。設定.json「跨本舊值上限」可改，0＝不限
CROSS_STRONG_TOP = 30
# 舊值原樣還在、而且分數到這裡的（幾乎是同一段話，只差改掉的那幾個字）不受上限：
# 以前同一條義務抄在 40 本裡，上限 30 段擠掉 10 段真候選，那幾本還被判成「沒受影響」
CROSS_STRONG_SURE = 85.0
CROSS_CHANGE_KEY = "_跨本異動"
CROSS_KIND_KEY = "_跨本找法"
CROSS_SCORE_KEY = "_跨本分數"
_STRONG_KINDS = ("相似", "句")
# 命中、文脈找到的（整段不像，只是用到同樣的字）：舊值還在、而且舊值前後那一句跟異動那一句
# 夠像（CROSS_CONTEXT_STRONG 分以上）才進舊值層。「同一義務寫在長段落中間」整段相似度低，
# 以前只能落到限量層被上限擠掉；「別件事也寫三日」前後文不像，照舊不進來。
_CONTEXT_KINDS = ("命中", "文脈")
CROSS_CONTEXT_STRONG = 80.0


def _digits(match):
    value = _common_cn_to_int(match.group(0))
    return match.group(0) if value is None else str(value)


def value_form(text):
    """比舊值用的寫法：全形半形（NFKC）、空白、中文數字都不算不一樣——「十五日」＝「15日」＝「１５日」。

    以前照字面比：別本寫「應於15日內」、異動是「十五日→十日」，舊值明明還在，卻判成不在，
    同一義務的那一段掉到限量層被上限擠掉（審查第二批「跨本」）。只給比對用，建議改法照原字。"""
    plain = _SPACE_RE.sub("", unicodedata.normalize("NFKC", text or ""))
    return _CN_RUN.sub(_digits, plain)


def _value_spots(text, probe):
    """probe 在 text 的每一個位置；probe 頭尾是數字時，旁邊不能接著數字（「3日」不算在「13日」裡）。"""
    spots, at = [], text.find(probe)
    while at >= 0:
        end = at + len(probe)
        if not (probe[0].isdigit() and at > 0 and text[at - 1].isdigit()) \
                and not (probe[-1].isdigit() and end < len(text) and text[end].isdigit()):
            spots.append(at)
        at = text.find(probe, at + 1)
    return spots


def _sentence_span(text, start, end):
    """text[start:end] 所在那一句的範圍（句號、分號、問號、驚嘆號為界）。"""
    lo = max(text.rfind(ch, 0, start) for ch in "。;!?") + 1
    his = [i for i in (text.find(ch, end) for ch in "。;!?") if i >= 0]
    return lo, (min(his) + 1 if his else len(text))


def old_value_context(candidate, old, new):
    """(舊值還在嗎, 舊值前後那一句跟候選段同一位置的相似度 0～100)。

    舊值還在＝這一處異動改掉的舊字（前後各帶一個字，「於三日內」這種）候選段裡都還在，
    全形半形、空白、中文數字不計（見 value_form）。只加字、沒改掉任何舊字的異動不算。
    相似度：異動那一句（「業務員招攬後應於三日內將要保書…送交核保單位」）跟候選段裡舊值前後
    同樣長度的那一截比；同樣寫「於三日內」、講的是別件事（「理賠申請人應於三日內補正」）會很低。"""
    import difflib
    import row_assist as ra
    text, old_f, new_f = value_form(candidate), value_form(old), value_form(new)
    hunks = [h for h in ra._hunks(old_f, new_f) if h[0]]
    if not hunks:
        return False, 0.0
    scores = []
    for _, _, i1, i2 in hunks:
        lo, hi = max(0, i1 - 1), min(len(old_f), i2 + 1)
        probe = old_f[lo:hi]
        spots = _value_spots(text, probe) if len(probe) >= 2 else []
        if not spots:
            return False, 0.0
        s_lo, s_hi = _sentence_span(old_f, i1, i2)
        sentence = old_f[s_lo:s_hi]
        best = 0.0
        for at in spots:
            window = text[max(0, at - (lo - s_lo)):at + len(probe) + (s_hi - hi)]
            best = max(best, difflib.SequenceMatcher(None, sentence, window, autojunk=False).ratio())
        scores.append(best)
    return True, round(100.0 * sum(scores) / len(scores), 1)


def old_value_present(candidate, old, new):
    """舊值還在嗎（見 old_value_context）。"""
    return old_value_context(candidate, old, new)[0]


def select_cross(found, source_changes, cap=CROSS_TOP, unlisted=None, strong_cap=CROSS_STRONG_TOP,
                 sure=CROSS_STRONG_SURE):
    """found：{被查的本: [cross_candidates／citation 的列]}；source_changes：{來源本: [異動]}。
    回傳 ({被查的本: 留下的列}, {(來源本, 異動序): 沒列的候選段數})。cap<=0 不設上限。
    舊值原樣還在、分數 >= sure 的一律列（算進 strong_cap，但超過也不擠掉）。
    舊值層的排序把舊值前後文的相似度也算進去（相似／句：找到時的分數與前後文相似度平均；
    命中／文脈：前後文相似度）——以前只看找到時的分數，同樣寫「三日」、講別件事的段跟真的同一
    義務排在一起搶 strong_cap 的名額。
    同分時照段落內容排（再照本名、段次），不照規章順序——以前同分照本名順序留，排在後面的本整批被擠掉。
    unlisted（dict，選填）：填進 {被查的本: [{候選段次, 候選全文SHA256}]}——因為上限沒列出來的段。
    驗收時要拿它排除：那些段人本來就不用看，不能到驗收才冒出來變成「新候選」擋住改好。"""
    if not cap or cap <= 0:
        return found, {}
    keep = set()           # (被查的本, 段次, 異動)
    ranked = {}            # (異動, 找法) → [(分數, 被查的本, 段次)]
    strong = {}            # 異動 → {(被查的本, 段次): 分數}（舊值原樣還在的）
    checked = {}
    candidates = set()
    texts = {}
    for target, rows in found.items():
        for row in rows:
            key = row.get(CROSS_CHANGE_KEY)
            if key is None:
                continue                          # 明確引用：一定列（下面不過濾）
            line = row.get("候選段次")
            cand = (target, line, key)
            candidates.add(cand)
            texts[cand] = row.get("候選全文") or ""
            kind = row.get(CROSS_KIND_KEY)
            score = row.get(CROSS_SCORE_KEY) or 0.0
            if kind in _STRONG_KINDS or kind in _CONTEXT_KINDS:
                if cand not in checked:
                    change = source_changes[key[0]][key[1]]
                    checked[cand] = old_value_context(row.get("候選全文"), change.get("old_text"),
                                                      change.get("new_text"))
                present, local = checked[cand]
                if present and (kind in _STRONG_KINDS or local >= CROSS_CONTEXT_STRONG):
                    # (排序分, 找到時的分數)：排序分算進前後文相似度；「不受上限」只看找到時的分數
                    rank = (score + local) / 2.0 if kind in _STRONG_KINDS else local
                    found_score = score if kind in _STRONG_KINDS else 0.0
                    bucket = strong.setdefault(key, {})
                    was = bucket.get((target, line), (-1.0, -1.0))
                    bucket[(target, line)] = (max(was[0], rank), max(was[1], found_score))
            ranked.setdefault((key, kind), []).append((score, target, line))
    def order(key):
        return lambda kv: (-kv[1], texts.get((kv[0][0], kv[0][1], key), ""), kv[0][0], dt.line_of(kv[0][1]) or 0)

    def strong_order(key):
        return lambda kv: (-kv[1][0], -kv[1][1], texts.get((kv[0][0], kv[0][1], key), ""), kv[0][0],
                           dt.line_of(kv[0][1]) or 0)

    for key, bucket in strong.items():
        best = sorted(bucket.items(), key=strong_order(key))
        if strong_cap and strong_cap > 0:
            # 找到時分數 >= sure 的全部留；不到 strong_cap 段再照排序分補
            surely = [kv for kv in best if sure and kv[1][1] >= sure]
            rest = [kv for kv in best if not (sure and kv[1][1] >= sure)]
            best = surely + rest[:max(0, strong_cap - len(surely))]
        for (target, line), _ in best:
            keep.add((target, line, key))         # 舊值原樣還在：優先列
    for (key, _), items in ranked.items():
        best = {}
        for score, target, line in items:
            if score > best.get((target, line), -1):
                best[(target, line)] = score
        for (target, line), _ in sorted(best.items(), key=order(key))[:cap]:
            keep.add((target, line, key))
    dropped = {}
    for cand in candidates - keep:
        target, line, key = cand
        dropped[key] = dropped.get(key, 0) + 1
        if unlisted is not None:
            entry = {"候選段次": dt.line_of(line), "候選全文SHA256": dt.text_sha256(texts.get(cand, ""))}
            if entry not in unlisted.setdefault(target, []):
                unlisted[target].append(entry)
    out = {}
    for target, rows in found.items():
        out[target] = [row for row in rows
                       if row.get(CROSS_CHANGE_KEY) is None
                       or (target, row.get("候選段次"), row[CROSS_CHANGE_KEY]) in keep]
    return out, dropped


# ---------------------------------------------------------------------------
# 跨本引用（不靠規格包）：直接在 B 本草稿裡找「A 本名稱＋第X條／第X點／第X章第X節…」
# ---------------------------------------------------------------------------
# 規格包的 引用.csv 是建基準（切條）時才有的；沒做建基準，「B 本寫明依 A 本第三點辦理、
# 而 A 本第三點這次改了或換號了」這種最直接的跨本連帶，只能靠文字相似去碰。
# 這裡直接讀 B 本的字：B 的引用是照 A 的**舊編號**寫的，所以拿 A 的舊版去解讀，
# 再看那個位置這一輪怎麼了——
#   換號 → 需改寫：建議改法照位置把號碼換成新的（跟同本的章節引用同一套，見 row_assist）
#   刪除 → 危險：沒有建議改法，要人決定改指哪裡
#   內容改了 → 要看：號碼沒變，但指到的條文內容這次改了
#   只寫「依 A 本辦理」→ 未指明條號：A 本這次有改就提醒一次
# B 本有規格包也一樣要讀字（cross_citations）：引用.csv 常常是空的，只靠它，刪除、改號全漏。
# B 本自己也有草稿、草稿已經把那處引用照 A 的新號改好了，就不再報（不然會叫人改回錯號）。

_CITE_NUM = r"[%s\d０-９]+" % "零〇一二三四五六七八九十百千兩"
# 下面這幾支都比對「去掉空白之後」的字（squash）：名稱中間、名稱與號碼之間夾空白（含全形）照樣認得
_AFTER_NAME_RE = re.compile(r"[」』》〉\"'”’]*(?:中之|之|所定之?|規定之?)?")
_CITE_ARTICLE_RE = re.compile(r"第(%s)條(?:之(%s))?" % (_CITE_NUM, _CITE_NUM))
_CITE_POINT_RE = re.compile(r"第(%s)點" % _CITE_NUM)
# 「第四、五點」「第三至五條」：一個「第」帶好幾個號碼
_CITE_LIST_RE = re.compile(r"第(%s(?:[、及至到]%s)+)(條|點)" % (_CITE_NUM, _CITE_NUM))
_CITE_LIST_PART_RE = re.compile(r"(%s)|([、及至到])" % _CITE_NUM)
# 號碼之間的連接詞：「第四點及第五點」「第三點至第五點」「第四點、第六點」
_CITE_CONJ_RE = re.compile(r"以及|、|及|與|和|或|暨|至|到")
_OUTLINE_CONJ_RE = re.compile(r"^(?:以及|、|及|與|和|或|暨|至)$")
# 回指：「同要點第五點」「該辦法第三條」——指的是同一段前面最近提到的那一本
_ANAPHOR_RE = re.compile(r"(?:同|該|前開|上開|前揭|上揭|前述|上述)"
                         r"(要點|辦法|手冊|規則|準則|細則|須知|規範|守則|規定)")
# 名稱前一個字：中文字只收這些（引用前常見的字）；其他中文字＝名稱是更長名稱的一部分
# （「北區保險業務員招攬作業要點」「電話行銷招攬作業要點」），不是在引用這一本
_LEFT_OK = set("依照按據循遵守用準適參見及與和或暨並同另如於之在至由經從對為反背違合符列載揭訂定引述即係悉考比援沿開"
               "前上該未再均亦仍得應須需")
_LEFT_OK_TAIL = ("公司", "本行", "本會", "本處", "本部", "本中心", "本院", "本署")
# 名稱後面緊接著這些字＝是另一本（「理賠作業管理辦法施行細則」）
_RIGHT_KIND = ("施行細則", "實施細則", "細則", "補充規定", "補充要點", "作業要點", "實施要點", "作業細則", "作業手冊",
               "作業準則", "要點", "辦法", "規則", "手冊", "準則", "須知", "規範", "守則", "章程", "條例")
_KIND_WORDS = ("細則", "要點", "辦法", "規則", "手冊", "準則", "須知", "規範", "守則", "章程", "規定", "條例",
               "原則", "程序", "政策")
_QUOTE_CHARS = "「」『』《》〈〉\"'“”‘’"
_SPACE_RE = re.compile(r"\s+")
_DEFAULT_NAMES = {}


def _is_cjk(ch):
    return "一" <= ch <= "鿿" or "㐀" <= ch <= "䶿"


def squash(text):
    """去掉所有空白（含全形）；回傳 (去空白的字, 每一個字在原文的位置)。"""
    chars, where = [], []
    for i, ch in enumerate(text or ""):
        if not ch.isspace():
            chars.append(ch)
            where.append(i)
    return "".join(chars), where


def _name_key(name):
    return _SPACE_RE.sub("", name or "").strip(_QUOTE_CHARS)


def _title_of(paragraphs):
    """A 本舊版的標題（前三段裡第一段像規章名的）：檔名跟正式名稱不一樣時，別本引用寫的是標題。"""
    for text in [p for p in (paragraphs or []) if (p or "").strip()][:3]:
        s = _name_key(text)
        if 6 <= len(s) <= 40 and s.endswith(_KIND_WORDS) and not re.search(r"[，。；：、,;:]", s) \
                and not re.match(r"第%s[章節條]" % _CITE_NUM, s):
            return s
    return ""


def citation_names(name, title=""):
    """比對別本引用時 A 本叫什麼：規章名、給人看的名稱（display_name）、去掉括號／日期／版本字的
    名稱、舊版標題。簡稱（「招攬作業要點」）沒有別名欄猜不到，不放進來冒充明確引用。"""
    import workspace as ws
    out = [_name_key(name)] if _name_key(name) else []
    for value in (ws.display_name(name or ""), ws.citation_name(name or ""), title):
        value = _name_key(value)
        if len(value) >= 4 and value not in out:      # 推出來的名稱太短（「規則」）沒有辨識力，不收
            out.append(value)
    return out


def _default_names(name):
    if name not in _DEFAULT_NAMES:
        _DEFAULT_NAMES[name] = citation_names(name)
    return _DEFAULT_NAMES[name]


class CitationNames(object):
    """本批所有規章的引用名稱：最長比對（「北區保險業務員招攬作業要點」不能當成
    「保險業務員招攬作業要點」）與回指（同要點）都要知道本批還有哪些名稱。"""

    def __init__(self, books):
        """books：{規章名: 舊版段落（取標題用，可給 None）}"""
        self.owners = {}
        own = {}
        for name, paragraphs in books.items():
            own[name] = citation_names(name, _title_of(paragraphs))
            for alias in own[name]:
                self.owners.setdefault(alias, set()).add(name)
        # 兩本去掉版本字之後同名（「甲(現行)」「甲(舊)」）：那個名稱只留給規章名本來就是它的那一本
        self.own = dict((name, [a for a in aliases if self.owners[a] == {name} or a == _name_key(name)])
                        for name, aliases in own.items())
        self._covering = {}
        self._others = {}

    def of(self, name):
        return self.own.get(name) or _default_names(name)

    def covering(self, alias, source):
        """比 alias 長、包含 alias、屬於別本的名稱。"""
        key = (alias, source)
        if key not in self._covering:
            self._covering[key] = [a for a, owners in self.owners.items()
                                   if len(a) > len(alias) and alias in a and owners != {source}]
        return self._covering[key]

    def others(self, source):
        """別本的名稱（回指時看中間有沒有提到別本）。"""
        if source not in self._others:
            self._others[source] = [a for a, owners in self.owners.items() if owners != {source}]
        return self._others[source]


def _find_all(s, sub, lo, hi):
    at = s.find(sub, lo, hi)
    while at >= 0:
        yield at
        at = s.find(sub, at + 1, hi)


def _covered(s, start, end, longer_names):
    """[start, end) 這一處被更長的別本名稱整個蓋住。"""
    for longer in longer_names:
        for at in _find_all(s, longer, max(0, end - len(longer)), start + len(longer)):
            if at <= start and at + len(longer) >= end:
                return True
    return False


def _mentions(s, source_name, aliases, names):
    """去空白後的字裡，A 本名稱出現的每一處 (起, 迄)：同一處取最長的名稱，再檢查前後邊界。"""
    hits = []
    for alias in aliases:
        for at in _find_all(s, alias, 0, len(s)):
            hits.append((at, at + len(alias), alias))
    hits.sort(key=lambda h: (h[0], -(h[1] - h[0])))
    out = []
    taken = -1          # 已經看過的那一處（不論收不收）：同一處較短的名稱不再看
    for start, end, alias in hits:
        if start < taken:
            continue
        taken = end
        if s[max(0, start - 1):start] == "本":
            continue
        # 本批別本的名稱更長、而且蓋住這一處：那是在引用別本
        if names is not None and _covered(s, start, end, names.covering(alias, source_name)):
            continue
        before = s[start - 1:start] if start else ""
        if before and _is_cjk(before) and before not in _LEFT_OK and not s[:start].endswith(_LEFT_OK_TAIL):
            continue
        if s.startswith(_RIGHT_KIND, end):
            continue
        out.append((start, end))
    return out


class SourceIndex(object):
    """A 本（被引用的那一本）這一輪的新舊對照：舊版每一條、每一點、每一章節這次怎麼了。"""

    def __init__(self, outcome):
        import renumber
        from _common import cn_to_int as _cn
        self.cn = _cn
        old, new = outcome["old_paragraphs"], outcome["new_paragraphs"]
        old_kinds, new_kinds = outcome.get("old_kinds"), outcome.get("new_kinds")
        self.old_to_new = {}
        self.changed_old = set()
        self.changed_ref = {}     # 舊版段次 → 那一處異動的條號（跟異動清單的 ref 一樣）
        self.last_refs = []       # 上一次查詢（article／point／outline_touched）碰到的異動條號
        self.substantive = 0
        for r in outcome["results"]:
            oi = r.get("old_index")
            if oi:
                self.old_to_new[oi] = None if r["type"] == "deleted" else r.get("new_index")
                if r["type"] in ("modified", "deleted"):
                    self.changed_old.add(oi)
                    self.changed_ref[oi] = r.get("ref") or ""

            if r["type"] in ("added", "deleted", "modified"):
                self.substantive += 1
        self.old_ctx = build_hierarchy(old, old_kinds)
        self.article_map = renumber.plan_article_map(old, new, old_kinds, new_kinds)
        old_entries = renumber.scan(old, old_kinds)
        self.has_articles = renumber.numbering_check_applicable(old_entries)
        self.doc_wide = not self.has_articles and renumber._points_run_through(old_entries)
        self.old_points = {}
        clauses = [e for e in old_entries if e["level"] == "款" and e["written"] is not None
                   and (e.get("clause_serial") or 1) == 1]
        for pos, e in enumerate(clauses):
            end = clauses[pos + 1]["index"] - 1 if pos + 1 < len(clauses) else len(old)
            self.old_points.setdefault(e["written"], (e["index"], end))
        self.new_written = dict((e["index"], e["written"]) for e in renumber.scan(new, new_kinds)
                                if e["level"] == "款" and e["written"] is not None)
        self.old_units = renumber.outline_units(old, old_kinds)
        self.outline_map = renumber.plan_outline_map(self.old_units, renumber.outline_units(new, new_kinds))
        self.point_map = renumber.plan_point_map(renumber.outline_points(old, old_kinds),
                                                 renumber.outline_points(new, new_kinds), self.outline_map)
        # 新版有哪些條、點、章節：B 本草稿裡改過的引用「已經是新號」才認得出來（見 text_citation_links）
        self.new_articles = set(renumber.normalize_article_no(c["article"])
                                for c in build_hierarchy(new, new_kinds) if c.get("article"))
        self.new_points = set(self.new_written.values())
        self.new_units = renumber.outline_units(new, new_kinds)
        self.new_outline_points = dict((key, set(n for n, _ in values))
                                       for key, values in renumber.outline_points(new, new_kinds).items())
        # 舊版每一章節底下每一點的段落範圍：「第二章第一節二、」只看那一點，不看整節
        # （以前看整節：二、沒動、同一節的一、改了，也報「內容改了」）
        self.old_point_ranges = {}
        current = None
        for i, (text, context) in enumerate(zip(old, self.old_ctx), 1):
            clause = renumber._CLAUSE_RE.match(text) if context.get("level") == "款" else None
            if clause and not context.get("article"):
                key = (self._heading_no(context.get("chapter")), self._heading_no(context.get("section")),
                       self.cn(clause.group(1)))
                current = None if key in self.old_point_ranges else key
                if current:
                    self.old_point_ranges[key] = [i, i]
            elif context.get("level") in ("章", "節", "條", "款"):
                current = None
            elif current:
                self.old_point_ranges[current][1] = i

    def _touched(self, first, last):
        hits = sorted(i for i in self.changed_old if first <= i <= last)
        self.last_refs = [self.changed_ref[i] for i in hits if self.changed_ref.get(i)]
        return bool(hits)

    def article(self, number):
        """「第X條」：回傳 (狀態, 新寫法或 None, 說明)。狀態 None＝這一條這輪沒動，不用報。"""
        from renumber import normalize_article_no as _norm
        key = _norm(number)
        entry = None
        for old_article, value in self.article_map.items():
            if _norm(old_article) == key:
                entry, key = value, old_article
                break
        if entry is None:
            return "無法判定", None, "舊版找不到%s" % number
        indices = [i for i, c in enumerate(self.old_ctx, 1) if c.get("article") == key]
        touched = bool(indices) and self._touched(min(indices), max(indices))
        if entry.get("new") is None:
            if entry.get("merged_into"):
                return "需改寫", entry["merged_into"], "%s這次併入%s" % (key, entry["merged_into"])
            return "危險", None, "%s這次刪掉了" % key
        if _norm(entry["new"]) != _norm(key):
            return "需改寫", entry["new"], "%s這次改號為%s" % (key, entry["new"])
        if touched:
            return "內容改了", None, "%s的內容這次改了" % key
        return None, None, ""

    def point(self, number):
        """「第X點」（沒有條、一路編到底的要點）。"""
        if self.has_articles:
            return "無法判定", None, "A 本有「第X條」，「第%s點」對不到" % self.cn_text(number)
        if not self.doc_wide:
            return "無法判定", None, "A 本各章節各自從一編點，「第%s點」看不出是哪一章" % self.cn_text(number)
        unit = self.old_points.get(number)
        if unit is None:
            return "無法判定", None, "舊版找不到第%s點" % self.cn_text(number)
        first, last = unit
        new_index = self.old_to_new.get(first)
        if new_index is None:
            return "危險", None, "第%s點這次刪掉了" % self.cn_text(number)
        new_number = self.new_written.get(new_index)
        if new_number is not None and new_number != number:
            return "需改寫", new_number, "第%s點這次改號為第%s點" % (self.cn_text(number), self.cn_text(new_number))
        if self._touched(first, last):
            return "內容改了", None, "第%s點的內容這次改了" % self.cn_text(number)
        return None, None, ""

    def outline_touched(self, key):
        """舊版 key＝(章號, 節號或 0) 那一章（節）裡，這一輪有沒有段落被改或被刪。"""
        import renumber

        def number_of(label):
            match = renumber._HEADING_NO_RE.match(label or "")
            return self.cn(match.group(1)) if match else 0

        hits = []
        for i in sorted(self.changed_old):
            context = self.old_ctx[i - 1]
            if number_of(context.get("chapter")) != key[0]:
                continue
            if key[1] and number_of(context.get("section")) != key[1]:
                continue
            hits.append(i)
        self.last_refs = [self.changed_ref[i] for i in hits if self.changed_ref.get(i)]
        return bool(hits)

    def outline_point_touched(self, key, point):
        """舊版 key 那一章（節）的第 point 點，這一輪有沒有段落被改或被刪。找不到那一點的範圍就看整個章節。"""
        span = self.old_point_ranges.get((key[0], key[1], point))
        if span is None:
            return self.outline_touched(key)
        return self._touched(span[0], span[1])

    def exists_new(self, key):
        """比對鍵（_judge_number／章節引用的 key）在 A 本**新版**有沒有這個號碼。"""
        import renumber
        if key[0] == "條":
            return renumber.normalize_article_no(key[1]) in self.new_articles
        if key[0] == "點":
            return not self.has_articles and key[1] in self.new_points
        if key[0] == "章節":
            unit, point = key[1], key[2]
            return unit in self.new_units and (not point or point in self.new_outline_points.get(unit, ()))
        return False

    def _heading_no(self, label):
        import renumber
        match = renumber._HEADING_NO_RE.match(label or "")
        return self.cn(match.group(1)) if match else 0

    def cn_text(self, number):
        from _common import cn_from_int
        return cn_from_int(number)


def _cited_number(text):
    from _common import cn_to_int as _cn
    return _cn(unicodedata_nfkc(text))


def unicodedata_nfkc(text):
    import unicodedata
    return unicodedata.normalize("NFKC", text or "")


def _parse_numbers(s, pos):
    """名稱後面的「第X條」「第X點」，連接詞串起來的一起收：「第四點及第五點」「第三點至第五點」
    「第四、五點」。回傳 [item]；item：kind（條／點）、num、sub（之一）、span（要換的字在 s 的起訖）、
    whole（span 是整個「第X點」還是只有號碼）、range_from（「至」前面那一項）。"""
    listed = _CITE_LIST_RE.match(s, pos)
    if listed:
        items, conn = [], ""
        base = listed.start(1)
        for part in _CITE_LIST_PART_RE.finditer(listed.group(1)):
            if part.group(1):
                items.append({"kind": listed.group(2), "num": part.group(1), "sub": None,
                              "span": (base + part.start(), base + part.end()), "whole": False,
                              "range_from": items[-1] if items and conn in ("至", "到") else None})
            else:
                conn = part.group(2)
        return items
    items, conn = [], ""
    while True:
        article = _CITE_ARTICLE_RE.match(s, pos)
        point = None if article else _CITE_POINT_RE.match(s, pos)
        if article:
            item = {"kind": "條", "num": article.group(1), "sub": article.group(2), "span": article.span()}
        elif point:
            item = {"kind": "點", "num": point.group(1), "sub": None, "span": point.span()}
        else:
            break
        if items and items[-1]["kind"] != item["kind"]:
            break
        item["whole"] = True
        item["range_from"] = items[-1] if items and conn in ("至", "到") else None
        items.append(item)
        pos = item["span"][1]
        joint = _CITE_CONJ_RE.match(s, pos)
        if not joint or not (_CITE_ARTICLE_RE.match(s, joint.end()) or _CITE_POINT_RE.match(s, joint.end())):
            break
        conn, pos = joint.group(0), joint.end()
    return items


def _parse_outline(s, pos):
    """名稱後面的章節引用（「第二章第一節一、」），「第三章第一節及第二節」連著的也收；
    後面那一串沒寫章就沿用前一串的章。回傳 [(citation（位置相對 pos）, {章, 節, 點})]。"""
    import renumber
    window = s[pos:pos + 160]
    out = []
    previous = None
    for citation in renumber._outline_citations(window):
        if previous is None:
            if citation["start"] != 0:
                break
        elif not _OUTLINE_CONJ_RE.match(window[previous["end"]:citation["start"]]):
            break
        numbers = dict((lvl, value) for lvl, value, _ in citation["parts"])
        if out and "章" not in numbers and "章" in out[-1][1]:
            numbers["章"] = out[-1][1]["章"]
        out.append((citation, numbers))
        previous = citation
    return out


def _judge_number(index, item, num=None):
    """「第X條」「第X點」：(狀態, 新寫法（換掉 span 的字）, 說明, 標籤, 比對鍵)。
    num 給了＝判「第三點至第五點」中間的那一點（不換字）。"""
    import renumber
    number = num if num is not None else item["num"]
    digits = unicodedata_nfkc(number).isdigit()
    index.last_refs = []
    if item["kind"] == "條":
        label = "第%s條" % number + ("之%s" % item["sub"] if item.get("sub") and num is None else "")
        status, new_value, note = index.article(label)
        new_quote = None
        if status == "需改寫" and new_value:
            written = normalize_article_no(new_value) if digits else new_value
            if item.get("whole"):
                new_quote = written
            else:
                head = re.match(r"第(.+?)條", written)
                new_quote = head.group(1) if head else None
        return status, new_quote, note, label, ("條", renumber.normalize_article_no(label))
    value = _cited_number(number)
    label = "第%s點" % number
    if not value:
        return "無法判定", None, "點號讀不出來", label, ("點", 0)
    status, new_value, note = index.point(value)
    new_quote = None
    if status == "需改寫":
        written = str(new_value) if digits else index.cn_text(new_value)
        new_quote = ("第%s點" % written) if item.get("whole") else written
    return status, new_quote, note, label, ("點", value)


def _judge_outline(index, numbers, label):
    """章節引用（numbers：{章, 節, 點}）：(狀態, 改號後的號碼或 None, 說明)。"""
    key = (numbers.get("章") or 0, numbers.get("節") or 0)
    index.last_refs = []
    if "章" not in numbers or key not in index.old_units:
        return "無法判定", None, "舊版找不到%s" % label
    target = index.outline_map.get(key)
    point_no = numbers.get("點")
    if point_no and target is not None and (key, point_no) not in index.point_map:
        return "無法判定", None, "舊版找不到%s" % label
    mapped = index.point_map.get((key, point_no)) if point_no else (target, None)
    if target is None or mapped is None:
        return "危險", None, "%s這次刪掉了" % label
    renum = {"章": target[0], "節": target[1], "點": mapped[1] if point_no else None}
    if (target, renum["點"]) != (key, point_no):
        return "需改寫", renum, "%s這次改號" % label
    # 引用到某一點（「第二章第一節二、」）只看那一點；只引用到章節才看整個章節
    touched = index.outline_point_touched(key, point_no) if point_no else index.outline_touched(key)
    if touched:
        return "內容改了", None, "%s的內容這次有改" % label
    return None, None, ""


def _finding(status, note, label, key, span, new_quote, refs, kind):
    return {"status": status, "note": note, "label": label, "key": key, "span": span,
            "new_quote": new_quote, "refs": list(refs), "kind": kind}


def _findings(s, index, lead, source_name, anaphor):
    """名稱後面那一串引用逐項判：[{status, note, label, key, span, new_quote, refs, kind}]。
    什麼號碼都沒寫：A 本這次有改就是「未指明條號」（回指「同要點辦理」不算，前面已經報過）。"""
    import renumber
    out = []
    items = _parse_numbers(s, lead)
    by_item = {}
    for item in items:
        status, new_quote, note, label, key = _judge_number(index, item)
        found = _finding(status, note, label, key, item["span"], new_quote, index.last_refs, item["kind"])
        out.append(found)
        by_item[id(item)] = found
        start = item.get("range_from")
        if start is None:
            continue
        # 「第三點至第五點」：中間的第四點也算被引用。中間那一點刪了，頭尾的號碼不能只照換
        low, high = _cited_number(start["num"]), _cited_number(item["num"])
        if not low or not high or high - low > 60 or item.get("sub") or start.get("sub"):
            continue
        range_label = "%s至%s" % (by_item[id(start)]["label"], label)
        for value in range(low + 1, high):
            written = str(value) if unicodedata_nfkc(item["num"]).isdigit() else index.cn_text(value)
            m_status, _, m_note, m_label, m_key = _judge_number(index, dict(item, whole=True), num=written)
            if m_status == "危險":
                for end in (by_item[id(start)], found):
                    end["status"], end["new_quote"] = "危險", None
                    end["note"] = "%s之間的%s這次刪掉了，整串引用要重寫" % (range_label, m_label)
            elif m_status == "內容改了":
                out.append(_finding(m_status, m_note, m_label, m_key, None, None, index.last_refs, item["kind"]))
    if items:
        return out
    for citation, numbers in _parse_outline(s, lead):
        span = (lead + citation["start"], lead + citation["end"])
        label = s[span[0]:span[1]]
        status, renum, note = _judge_outline(index, numbers, label)
        new_quote = None
        if status == "需改寫":
            new_quote = renumber._rewrite_citation(s[lead:], citation,
                                                   dict((k, v) for k, v in renum.items() if v is not None))
        out.append(_finding(status, note, label,
                            ("章節", (numbers.get("章") or 0, numbers.get("節") or 0), numbers.get("點")),
                            span, new_quote, index.last_refs, "章節"))
    if out or anaphor or not index.substantive:
        return out
    return [_finding("未指明條號", "只寫依%s，沒寫條號；%s這次有 %d 處異動" % (
        source_name, source_name, index.substantive), "（未指明條號）", ("名稱",), None, None, [], "")]


def _citation_groups(text, source_name, names):
    """一段文字裡引用 A 本的每一處：(去空白的字, 位置對照, [(號碼從哪裡開始, 是不是回指)])。"""
    aliases = names.of(source_name) if names is not None else _default_names(source_name)
    plain = _SPACE_RE.sub("", text or "")
    if not any(alias in plain for alias in aliases):
        return None
    s, where = squash(text)
    mentions = _mentions(s, source_name, aliases, names)
    found = [(_AFTER_NAME_RE.match(s, end).end(), False) for _, end in mentions]
    if mentions:
        others = names.others(source_name) if names is not None else []
        for match in _ANAPHOR_RE.finditer(s):
            if s[max(0, match.start() - 1):match.start()] == "本":
                continue
            before = [m for m in mentions if m[1] <= match.start()]
            if not before:
                continue
            gap = s[before[-1][1]:match.start()]
            if any(alias in gap for alias in others):
                continue          # 中間提到了別本：「同辦法」指的是那一本
            if not any(alias.endswith(match.group(1)) for alias in aliases):
                continue
            found.append((_AFTER_NAME_RE.match(s, match.end()).end(), True))
    return s, where, found


def _cited_keys(text, source_name, index, names):
    """一段文字裡引用 A 本的那些號碼（比對鍵）：草稿與舊版比「這處引用有沒有被改過」用。"""
    groups = _citation_groups(text, source_name, names)
    if not groups:
        return set()
    s, _, found = groups
    return set(f["key"] for lead, anaphor in found for f in _findings(s, index, lead, source_name, anaphor))


def text_citation_links(source_name, index, target_paragraphs, names=None, origin=None):
    """B 本草稿裡明文引用 A 本（source_name）的每一處，對照 A 本這一輪的異動（index＝SourceIndex）。
    回傳跨本候選列；要改寫的列帶 dt.OUTLINE_KEY（建議改法由 row_assist 照位置改寫）。

    names：本批的 CitationNames（給了才做最長比對、認得標題這種檔名以外的正式名稱）。
    origin：B 本自己這次改過的段 {草稿段次: 舊版那一段（新增的段是 None）}（draft_origin）。
    改過的段落裡，引用也改了、而且已經是 A 本新版有的號碼＝已經照新號改好，不報；
    新增的段落看不出是照舊號還是新號寫的：換號、刪除改報「無法判定」、不給建議改法。"""
    out = []
    origin = origin or {}
    for line, text in enumerate(target_paragraphs, 1):
        groups = _citation_groups(text, source_name, names)
        if not groups:
            continue
        s, where, found = groups
        old_keys = None
        for lead, anaphor in found:
            for f in _findings(s, index, lead, source_name, anaphor):
                status, note, new_quote = f["status"], f["note"], f["new_quote"]
                if not status:
                    continue
                if line in origin and f["kind"]:
                    if origin[line] is not None:
                        if old_keys is None:
                            old_keys = _cited_keys(origin[line], source_name, index, names)
                        if f["key"] not in old_keys and index.exists_new(f["key"]):
                            continue     # 草稿已經把這處引用改成 A 本新版的號碼
                    elif status in ("需改寫", "危險") and index.exists_new(f["key"]):
                        status, new_quote = "無法判定", None
                        note = "草稿新增的段落，看不出%s是照%s舊版還是新版的號碼寫的（照舊版：%s）" % (
                            f["label"], source_name, note)
                # 「內容改了」：異動條文ID 寫被引用的那一點裡實際改了的那幾段的條號（跟異動清單同一套），
                # 決定表才對得回那一處異動，寫得出「異動內容」「建議改法」（例：三日→五日）
                refs = list(dict.fromkeys(f["refs"])) if status == "內容改了" else []
                label = f["label"]
                change_id = "；".join("%s：%s" % (source_name, r) for r in refs) or "%s：%s" % (source_name, label)
                row = _row("跨本引用", change_id, note, "", line, text,
                           "引用 %s%s：%s" % (source_name, label if label != "（未指明條號）" else "", note))
                if status in ("需改寫", "危險") and f["span"]:
                    start, end = where[f["span"][0]], where[f["span"][1] - 1] + 1
                    row[dt.OUTLINE_KEY] = [{
                        "status": status, "quote": text[start:end], "new_quote": new_quote or "",
                        "start": start, "end": end, "note": note, "tag": "%s換號" % source_name}]
                out.append(row)
    return out


def draft_origin(outcome):
    """B 本這一輪改過的段：{草稿段次: 舊版那一段（新增的段是 None）}。沒有草稿（只讀全文、規格包本）回 {}。"""
    origin = {}
    for r in (outcome or {}).get("results") or []:
        line = r.get("new_index")
        if not line:
            continue
        if r.get("type") == "modified":
            origin[int(line)] = r.get("old_text") or ""
        elif r.get("type") == "added":
            origin[int(line)] = None
    return origin


def cross_citations(source_name, source_outcome, target_outcome, names=None, target_baseline=None,
                    target_new_line_ids=None, cache=None):
    """B 本（target）裡引用 A 本（source）的每一處。B 本的字一律讀（text_citation_links）；
    B 本有規格包時再對引用.csv（citation_links）補上讀字沒認出來的段——同一段只留讀字那一筆，
    B 本草稿改過的段也只信讀字那一邊（引用.csv 記的是舊版的引用，草稿可能已經照新號改好）。
    cache：{A 本: SourceIndex}，同一本 A 對很多本 B 只建一次。"""
    cache = cache if cache is not None else {}
    index = cache.get(source_name)
    if index is None:
        index = cache[source_name] = SourceIndex(source_outcome)
    origin = draft_origin(target_outcome)
    paragraphs = target_outcome["new_paragraphs"]
    rows = text_citation_links(source_name, index, paragraphs, names=names, origin=origin)
    if target_baseline:
        lines = set(r["候選段次"] for r in rows if r["候選段次"])
        texts = set(r["候選全文"] for r in rows)
        for r in citation_links(source_name, None, target_baseline, target_new_line_ids, paragraphs,
                                index=index, names=names):
            line = r["候選段次"]
            if line and (line in lines or int(line) in origin):
                continue
            if not line and r["候選全文"] in texts:
                continue
            rows.append(r)
    return rows


# ---------------------------------------------------------------------------
# 引用連帶：B 本規格包的引用.csv 有沒有引用到 A 本被改的那條
# ---------------------------------------------------------------------------

def _contains_number(big, small):
    """「第3點」在「第13點」裡不算：前後不能再接數字。"""
    at = big.find(small)
    while at >= 0:
        before = big[at - 1:at] if at else ""
        after = big[at + len(small):at + len(small) + 1]
        if not before.isdigit() and not after.isdigit():
            return True
        at = big.find(small, at + 1)
    return False


def citation_links(source_name, source_changes, target_baseline, target_new_line_ids,
                   target_paragraphs, index=None, names=None):
    """B 本規格包的引用.csv 有沒有引用到 A 本。

    index（A 本的 SourceIndex）給了：引用.csv 記的每一個號碼照 A 本舊版解讀，改號、刪除、內容改了
    都判得出來（跟 text_citation_links 同一套；cross_citations 走這條）。沒給：舊做法，只拿
    source_changes（新增／修改）的條號比，刪除與改號進不來。
    規章名一律整個名稱相同才算（「招攬作業要點」不是「電話行銷招攬作業要點」）。"""
    path = os.path.join(getattr(target_baseline, "version_dir", ""), "規格包", "引用.csv")
    if not os.path.isfile(path):
        return []
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    id_to_line = {}
    for line, ids in (target_new_line_ids or {}).items():
        for item_id in ids:
            id_to_line.setdefault(item_id, int(line))
    keys = []
    for change in source_changes or []:
        wanted = set()
        if change.get("ref"):
            wanted.add(normalize_article_no(change["ref"]))
        for pos in change.get("positions") or []:
            wanted.add(normalize_article_no(pos))
        keys.append((_label(source_name, change), {k for k in wanted if k}, dt._summary(change["new_text"])))
    aliases = names.of(source_name) if names is not None else _default_names(source_name)
    wanted_names = set(normalize_article_no(a) for a in aliases)
    out = []
    for r in rows:
        if (r.get("規章外引用") or "").strip() != "Y":
            continue
        cited_names = [x.strip() for x in (r.get("規章名") or "").split(";")]
        numbers = [x.strip() for x in (r.get("條號") or "").split(";")]
        for position, name in enumerate(cited_names):
            if not name or normalize_article_no(_name_key(name)) not in wanted_names:
                continue
            number = numbers[position] if position < len(numbers) else "-"
            line = id_to_line.get(r.get("條文ID"))
            # 真的規格包 引用.csv 沒有「全文」欄；定位不到草稿段落時退回基準的 條文.csv。
            text = (target_paragraphs[line - 1] if line else
                    (getattr(target_baseline, "by_id", {}).get(r.get("條文ID"), {}) or {}).get("全文", ""))
            tail = "" if line else "（無法定位到草稿段落）"
            if index is not None:
                if number and number != "-":
                    for f in _findings(squash(number)[0], index, 0, source_name, True):
                        if f["status"] in (None, "無法判定"):
                            continue
                        refs = list(dict.fromkeys(f["refs"])) if f["status"] == "內容改了" else []
                        change_id = ("；".join("%s：%s" % (source_name, x) for x in refs)
                                     or "%s：%s" % (source_name, f["label"]))
                        out.append(_row("跨本引用", change_id, f["note"], r.get("條文ID", ""), line, text,
                                        "引用 %s%s：%s（規格包引用表）%s" % (source_name, f["label"], f["note"],
                                                                     tail)))
                elif index.substantive:
                    note = "只寫依%s，沒寫條號；%s這次有 %d 處異動" % (source_name, source_name, index.substantive)
                    out.append(_row("跨本引用", "%s：（未指明條號）" % source_name, note, r.get("條文ID", ""), line,
                                    text, "引用 %s（未指明條號）%s" % (source_name, tail)))
                continue
            if number and number != "-":
                nn = normalize_article_no(number)
                for label, wanted, summary in keys:
                    if any(nn == k or _contains_number(k, nn) or _contains_number(nn, k) for k in wanted):
                        out.append(_row("跨本引用", label, summary, r.get("條文ID", ""), line, text,
                                        "引用 %s %s%s" % (source_name, number, tail)))
            else:
                for label, wanted, summary in keys:
                    out.append(_row("跨本引用", label, summary, r.get("條文ID", ""), line, text,
                                    "引用 %s（未指明條號）%s" % (source_name, tail)))
    return out


# ---------------------------------------------------------------------------
# 摘要
# ---------------------------------------------------------------------------

def write_batch_summary(path, stats):
    """批次摘要。每本的數字之外，還要把各本的提醒彙整在同一張紙上。

    為什麼：批次跑十本時，第三本的「新舊版可能放反」印在畫面上早就被後面七本洗掉了。
    各本子資料夾裡雖然都有自己的 提醒.txt，但沒有人會一本一本去點開——
    會被看到的是這張摘要。
    """
    lines = ["批次摘要", ""]
    # 裁定 7：沒改的本要在摘要最上面單獨列一行。批次跑十本、每本三四行數字，
    # 「實質異動 0 處」那一行躺在第七本裡沒有人會注意到；而 0 異動最常見的原因
    # 不是這本真的沒改，是草稿還沒放進來或檔案拿錯。只列名字，不翻轉整批的結論。
    # 清單裡沒放新版草稿的本（配對時標「沒改」）是刻意不改，跟「放了草稿卻一處都沒改」
    # 分開講：前者是預期的，後者才可能是檔案拿錯。混在同一行「無異動」底下再叫人
    # 「確認草稿有沒有放進來」，刻意不改的那一本也會被懷疑漏放。
    kept = [s["規章名"] for s in stats if not s.get("有草稿", True)]
    zero = [s["規章名"] for s in stats if s.get("有草稿", True)
            and s.get("零異動", not s.get("實質異動", 0))]
    if kept:
        lines.append("本次不修改 %d 本：%s（清單裡沒有新版草稿；只檢查別本的改動要不要帶到這幾本）"
                     % (len(kept), "、".join(kept)))
    lines.append("無異動 %d 本：%s" % (len(zero), "、".join(zero) or "無"))
    if zero:
        lines.append("（有放新版草稿卻一處都沒改，請確認草稿有沒有放對、檔案有沒有拿錯。）")
    lines.append("")
    for s in stats:
        lines.append("【%s】%s" % (s["規章名"], "" if s.get("有草稿", True) else "（本次不修改，只看別本的改動）"))
        lines.append("  實質異動 %d 處，候選 %d 列" % (s.get("實質異動", 0), s.get("候選", 0)))
        dist = s.get("來源分佈") or {}
        lines.append("  來源：%s" % ("、".join("%s %d" % kv for kv in sorted(dist.items())) or "無"))
        lines.append("  跨本來自：%s" % ("、".join(sorted(s.get("跨本來自") or [])) or "無"))
        if s.get("沿用") is not None:
            lines.append("  沿用上一輪決定 %d 列（決定表「沿用上一輪」欄寫「是」）；其餘 %d 列要重新看"
                         % (s["沿用"], s.get("候選", 0) - s["沿用"]))
        warned = len(nt.warnings(s.get("提醒") or []))
        lines.append("  提醒 %d 則%s（完整內容見本節下方的提醒彙整，或 產出/系統檔案/<規章名>/審閱文件/提醒.txt）"
                     % (len(s.get("提醒") or []), "（其中警告 %d 則，要處理）" % warned if warned else ""))
        lines.append("")

    lines.append("─" * 30)
    lines.append("提醒彙整")
    lines.append("")
    total = sum(len(s.get("提醒") or []) for s in stats)
    if not total:
        lines.append("本次批次沒有任何提醒。")
    else:
        # 一字不差出現在兩本以上的提醒（例如每本都有的「沒有第X條」）只講一次：
        # 十本各列一次，真正只屬於某一本的那一則就被淹掉了
        # 用 notices 自己那一支排版：提醒.txt 與這裡的格式要一模一樣，各寫一份遲早會漂開
        owners = {}
        for s in stats:
            for line in set(nt.format_line(e) for e in s.get("提醒") or []):
                owners.setdefault(line, []).append(s["規章名"])
        shared = [line for line, names in owners.items() if len(names) > 1]
        if shared:
            lines.append("【各本共同】")
            for line in sorted(shared, key=lambda l: (not l.startswith(nt.WARNING), l)):
                lines.append("  %s（%s）" % (line, "、".join(owners[line])))
            lines.append("")
        for s in stats:
            entries = s.get("提醒") or []
            own = [nt.format_line(e) for e in entries if nt.format_line(e) not in shared]
            lines.append("【%s】提醒 %d 則%s" % (
                s["規章名"], len(entries),
                "（其中 %d 則見上面「各本共同」）" % (len(entries) - len(own)) if len(own) < len(entries) else ""))
            if not own:
                lines.append("  （無）" if not entries else "  （都在上面「各本共同」）")
            for line in own:
                lines.append("  " + line)
            lines.append("")
    lines.append("提醒不等於錯誤，但每一則都要有人看過再決定要不要處理。")
    lines.append("")
    lines.append("連帶決定表在 產出/填寫表單/連帶決定表.csv（全部規章一張，第一欄是規章）；"
                 "看完要跟著改，再用 reg-edit（修改文本）：填完跑 繼續（套用、驗收）。最終仍需人工複核。")
    with io.open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")
    return path
