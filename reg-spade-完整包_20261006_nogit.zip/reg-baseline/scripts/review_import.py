# -*- coding: utf-8 -*-
"""
第 1.5 步：驗證 AI 判斷、把三欄寫回連帶決定表、產出 Excel／CSV 報告。

AI 讀 review_pack 產出的審查包，填好 AI候選判斷.csv、AI異動審查.csv 兩張 CSV
（只能填 AI判斷／AI分數／AI理由三欄，列ID／候選段次等對照欄是程式先填好的，不能動）。
這支負責：
    1. 驗證兩張 CSV：列ID／異動ID 對得上、段次對得上、判斷字對、分數與判斷相符、
       理由夠格。任何一條不過，整批中止，什麼都不寫（連帶決定表、報告都不動）。
    2. 通過後把「AI判斷」「AI分數」「AI理由」三欄寫回連帶決定表.csv（走
       decision_table.write_rows_csv，COLUMNS 之外的欄照留；「要改嗎」「改成什麼」
       原樣不動；指紋檔 .json 也不動，因為列指紋只算候選全文）。
    3. 產出人看得懂的報告：LLM審查報告.xlsx（三到四個工作表）。一份產出只出一種
       格式：xlsx 寫得出來就只有 xlsx，寫不出來（磁碟滿、檔案開在 Excel 裡）才
       每張工作表各退一個 _總結.csv／_候選.csv／_異動.csv，並發一則提醒。

AI 只寫判斷，不填「要改嗎」「改成什麼」——那兩欄仍是人的最終決定。
"""

import csv
import difflib
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import notices as nt
import review_pack as rp
import scoring_rubric as sr
import xlsx_writer as xw
from _common import _decode_text, format_scope, locate, place

CAND_VERDICTS = ("建議修改", "需再檢查", "不用改")
CHANGE_VERDICTS = ("沒問題", "需再檢查", "建議修改")
AI_COLUMNS = ["AI判斷", "AI分數", "AI理由"]
# 兩張 AI CSV 該有的欄（review_pack._write_ai_csv 寫出來的表頭）。缺欄、欄名打錯
# 的訊息要點名是哪一欄，見 _check_sheet_shape。
CAND_REQUIRED = ["列ID", "候選段次"] + AI_COLUMNS
CHANGE_REQUIRED = ["異動ID", "新版段次"] + AI_COLUMNS

_HIGH = {"建議修改"}           # 分數要 ≥ 7
_LOW = {"不用改", "沒問題"}     # 分數要 ≤ 3
_MID = {"需再檢查"}            # 分數要 4–6

_CSV_SUFFIX = {"總結": "_總結.csv", "候選審查": "_候選.csv", "異動審查": "_異動.csv",
               "原文已修改未匯入": "_原文不符.csv"}


class ReviewError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 讀兩張 AI CSV
# ---------------------------------------------------------------------------

def _read_ai_csv(path):
    """讀一張 AI CSV，回傳 (dict 的 list, 表頭欄名 list 或 None)。

    表頭要一起回傳（小瑕疵 19）：「缺欄位」「欄名打錯」「只有表頭」這三種問題
    光看資料列分不出來——欄名打錯時每一列的 AI判斷 都讀成空字串，錯誤訊息會變成
    幾十行「AI判斷不是允許的字：「」」，真正的原因（表頭上寫的是「AI判定」）
    一個字都沒有。見 _check_sheet_shape。

    編碼不寫死（should_fix no 27）：AI 填完的表多半經過 Excel 手動確認再存檔，
    台灣的 Excel 預設另存就是 Big5（cp950），選「Unicode 文字」則是 UTF-16。
    以前寫死 `encoding="utf-8-sig"` 而且沒有 try，這兩種檔一律
    UnicodeDecodeError traceback——人看到的是一坨堆疊，不知道是編碼問題。
    改走 `_common._decode_text`：它會先看 BOM（UTF-32／UTF-16），
    再依序試 utf-8-sig／utf-8／cp950／big5hkscs，而且解完做一次亂碼檢查。
    真的認不出來才轉成 ReviewError，訊息直接告訴人怎麼另存。
    """
    with io.open(path, "rb") as f:
        raw = f.read()
    try:
        text = _decode_text(raw, path)
    except (UnicodeDecodeError, ValueError, SystemExit):
        # SystemExit：_decode_text 的 _reject_if_garbled 解出亂碼時丟的就是它
        # （那是給 CLI 直接中止用的）。這一步是可以救的錯，要轉成本模組的錯誤型別，
        # 讓 run_all 印成「[中止] ……」而不是整串 traceback。
        raise ReviewError("AI 檔編碼讀不出來：%s（請在 Excel 另存成「CSV UTF-8」再匯入）" % path)
    # newline="" 跟 open(..., newline="") 同義：不做換行轉換，
    # 理由欄裡包在引號中的換行才不會被切成兩列。
    reader = csv.DictReader(io.StringIO(text, newline=""))
    rows = list(reader)
    return rows, (list(reader.fieldnames) if reader.fieldnames else None)


def load_ai_files(outdir):
    """讀 AI候選判斷.csv、AI異動審查.csv，回傳 (候選列, 異動列, 表頭資訊)。

    前兩個都是 dict 的 list；第三個是 {檔名: {"path": 路徑, "fieldnames": 欄名或 None}}，
    給 validate 判「表頭本身有沒有問題」用（見 _check_sheet_shape）。
    找不到檔案就 ReviewError；編碼認不出來也是 ReviewError（見 _read_ai_csv）；
    欄位內容對不對留給 validate 判斷。"""
    # 讀端走 locate：新排法（填寫表單/）優先，找不到再看舊排法（平鋪在 outdir）
    cand_path = locate(outdir, "AI候選判斷.csv")[0]
    change_path = locate(outdir, "AI異動審查.csv")[0]
    if not os.path.isfile(cand_path):
        raise ReviewError("找不到 AI候選判斷.csv：%s（請先跑 review-pack，讓 AI 填好再匯入）" % cand_path)
    if not os.path.isfile(change_path):
        raise ReviewError("找不到 AI異動審查.csv：%s（請先跑 review-pack，讓 AI 填好再匯入）" % change_path)
    cand_rows, cand_fields = _read_ai_csv(cand_path)
    change_rows, change_fields = _read_ai_csv(change_path)
    meta = {"AI候選判斷.csv": {"path": cand_path, "fieldnames": cand_fields},
            "AI異動審查.csv": {"path": change_path, "fieldnames": change_fields}}
    return cand_rows, change_rows, meta


# ---------------------------------------------------------------------------
# 驗證（純函式，不做任何 I/O）
# ---------------------------------------------------------------------------

def _s(value):
    """欄位值轉字串再去頭尾空白；AI CSV 讀出來一定是字串，但 validate 是公開的純函式，
    別的呼叫端（例如測試、Task 4）可能直接塞 int／None 進來，這裡不要讓它整個炸掉。"""
    return "" if value is None else str(value).strip()


_SCORE_RE = re.compile(r"^(10|[0-9])$")


def _score_ok(raw):
    """回傳 (通不通過, 分數)；一定要是半形 0–10 整數（`^(10|[0-9])$`，逐字元比對，
    不是先轉數字再判斷範圍）才算過。這樣擋得住 `int()` 會放行的怪輸入：全形數字
    （`int("８")` Python 認得，但人眼看不出跟半形的差別）、小數（`"8.0"`）。"""
    raw = _s(raw)
    if not _SCORE_RE.match(raw):
        return False, None
    return True, int(raw)


# 欄名「像但不等於」的門檻：「AI判定」對「AI判斷」是 0.75，「備註」對「AI理由」是 0。
_SIMILAR_ENOUGH = 0.6


def _looks_like(name, target):
    """name 是不是 target 打錯字的版本（不是就回 0）。"""
    return difflib.SequenceMatcher(None, name, target).ratio()


def _check_sheet_shape(filename, path, ai_rows, fieldnames, required_cols, expect_rows=True):
    """AI CSV 的「形狀」對不對：空檔／只有表頭／缺欄位／欄名打錯（小瑕疵 19）。

    為什麼要單獨檢查（而不是交給 _validate_sheet 逐列驗）：這四種問題在逐列驗證
    底下長得一模一樣——欄名打成「AI判定」時每一列的 AI判斷 都讀成空字串，
    畫面上是幾十行「AI判斷不是允許的字：「」」，人看不出真正的原因是表頭；
    表整個空掉時則是幾十行「缺列ID：R1、R2……」，同樣看不出檔案根本沒內容。
    四種各給一句話，講的是這一次真正發生的事：

        「%s」是空檔（0 bytes）
        「%s」只有表頭，沒有任何資料列
        「%s」缺欄位：%s
        「%s」欄名不對：%s（應為 %s）

    path 可以不給（None）：呼叫端手上只有已經讀好的列與表頭時，就只驗表頭。
    expect_rows=False 時不驗「只有表頭」——決定表本來就 0 列候選（compare 一筆
    候選都沒列）時，空白的 AI CSV 是正確的產出，不是壞檔。
    回傳錯誤字串 list；空 list 表示形狀沒問題，可以往下逐列驗。
    """
    errors = []
    if path and os.path.isfile(path):
        try:
            if os.path.getsize(path) == 0:
                return ["「%s」是空檔（0 bytes）" % filename]
        except OSError:
            pass
    if not fieldnames:
        # 有檔案但連表頭都讀不出來（整份空白、或只有幾個空行）：跟 0 bytes 同一件事。
        return ["「%s」是空檔（0 bytes）" % filename]

    actual = [(name or "").strip() for name in fieldnames]
    spare = [name for name in actual if name and name not in required_cols]
    missing = []
    for want in required_cols:
        if want in actual:
            continue
        # 有一個沒人認領、又跟它很像的欄名 → 是打錯字，不是缺欄位。
        best, best_score = "", 0.0
        for name in spare:
            score = _looks_like(name, want)
            if score > best_score:
                best, best_score = name, score
        if best and best_score >= _SIMILAR_ENOUGH:
            spare.remove(best)
            errors.append("「%s」欄名不對：%s（應為 %s）" % (filename, best, want))
        else:
            missing.append(want)
    if missing:
        errors.append("「%s」缺欄位：%s" % (filename, "、".join(missing)))
    if errors:
        return errors
    if expect_rows and not ai_rows:
        return ["「%s」只有表頭，沒有任何資料列" % filename]
    return []


def _validate_sheet(filename, ai_rows, id_col, id_prefix, pos_col, expected_ids, expected_pos,
                    optional_ids=()):
    """驗證一張 AI CSV：列ID／異動ID 對齊、段次對得上、判斷字、分數、理由。
    verdicts 依 id_prefix 決定（候選用 R、異動用 C，剛好對應兩套判斷字）。
    回傳這張表全部的錯誤字串（不是遇第一個就停）。"""
    verdicts = CAND_VERDICTS if id_prefix == "R" else CHANGE_VERDICTS
    errors = []
    by_id = {}
    dup_ids = []
    for row in ai_rows:
        rid = _s(row.get(id_col))
        if not rid:
            continue
        if rid in by_id and rid not in dup_ids:
            # AI 填表把同一個列ID／異動ID 填到兩列：後面那列會把前面覆蓋掉，
            # 整份表看起來卻少了一列（另一列憑空消失），不擋住的話錯得很隱晦。
            dup_ids.append(rid)
        by_id[rid] = row
    for rid in dup_ids:
        errors.append("「%s」%s重複：%s" % (filename, id_col, rid))

    expected_set = set(expected_ids)
    actual_set = set(by_id.keys())
    for missing in expected_ids:
        if missing not in actual_set and missing not in optional_ids:
            errors.append("「%s」缺%s：%s" % (filename, id_col, missing))
    for extra in sorted(actual_set - expected_set, key=lambda x: (len(x), x)):
        errors.append("「%s」多出%s：%s" % (filename, id_col, extra))

    for i, rid in enumerate(expected_ids, 1):
        row = by_id.get(rid)
        if row is None:
            continue
        tag = "「%s」%s" % (filename, rid)

        actual_pos = _s(row.get(pos_col))
        want_pos = _s(expected_pos[i - 1])
        if actual_pos != want_pos:
            errors.append("%s：%s不符（決定表是「%s」，AI檔是「%s」）"
                          % (tag, pos_col, want_pos, actual_pos))

        verdict = _s(row.get("AI判斷"))
        verdict_ok = verdict in verdicts
        if not verdict_ok:
            errors.append("%s：AI判斷不是允許的字：「%s」（只能是 %s）"
                          % (tag, verdict, "／".join(verdicts)))

        score_ok, score = _score_ok(row.get("AI分數"))
        if not score_ok:
            errors.append("%s：分數要是 0–10 的半形整數：「%s」" % (tag, _s(row.get("AI分數"))))
        elif verdict_ok:
            if verdict in _HIGH and score < 7:
                errors.append("%s：分數 %d 與判斷「%s」不符（%s要 ≥ 7）" % (tag, score, verdict, verdict))
            elif verdict in _LOW and score > 3:
                errors.append("%s：分數 %d 與判斷「%s」不符（%s要 ≤ 3）" % (tag, score, verdict, verdict))
            elif verdict in _MID and not (4 <= score <= 6):
                errors.append("%s：分數 %d 與判斷「%s」不符（%s要 4–6）" % (tag, score, verdict, verdict))

        reason = _s(row.get("AI理由"))
        if not reason:
            errors.append("%s：AI理由是空的" % tag)
        else:
            # 評分標準（scoring_rubric）：理由開頭的〔標籤〕就是對到哪一條，那一條的分數就是 AI分數。
            # 只規定區段的話，同一區段裡給 7 還是 9 各說各話，這裡把它釘死
            table = "候選" if id_prefix == "R" else "異動"
            label = sr.label_in(reason)
            expected = sr.score_of(table, label) if label else None
            if not label:
                errors.append("%s：AI理由要用評分標準的標籤開頭，例如「〔%s〕…」（可用：%s）"
                              % (tag, sr.TABLES[table][1][1], sr.labels(table)))
            elif expected is None:
                errors.append("%s：「〔%s〕」不是%s評分標準的標籤（可用：%s）"
                              % (tag, label, table, sr.labels(table)))
            elif score_ok and expected != score:
                errors.append("%s：標籤「〔%s〕」是 %d 分，AI分數卻填 %d" % (tag, label, expected, score))
            if verdict == "建議修改" and "改成" not in reason:
                errors.append("%s：AI理由沒有寫「改成」（建議修改要寫建議改法）" % tag)
            if verdict == "需再檢查" and "請確認" not in reason and "請問" not in reason:
                errors.append("%s：AI理由沒有寫「請確認」或「請問」（需再檢查要寫查什麼、問誰）" % tag)
            # 異動審查的 5、6 分（需查依據、可能越界）要先上網查上位規定；表上有「查證來源」欄
            # （新版 review-pack 產的）就一定要填，舊表沒有這一欄不擋
            if (id_prefix == "C" and "查證來源" in row and score_ok and score in (5, 6)
                    and not _s(row.get("查證來源"))):
                errors.append("%s：%d 分要先上網查上位規定，查證來源 要寫查了哪些網址或關鍵字" % (tag, score))

    return errors


def validate(rows, changes, ai_cand, ai_change, meta=None):
    """驗證 AI候選判斷.csv、AI異動審查.csv 兩張表，回傳全部錯誤字串（不是遇第一個
    就停）；沒有錯誤回傳空 list。純函式，不讀檔（meta 給了路徑時只 stat 檔案大小）。

    meta（選填，load_ai_files 的第三個回傳值）給了就先驗表頭的「形狀」——空檔、
    只有表頭、缺欄位、欄名打錯（見 _check_sheet_shape）。形狀不對的那一張表
    **不再逐列驗**：表頭都錯了，逐列驗只會噴幾十行看不出原因的衍生錯誤，
    把真正該講的那一句淹掉。"""
    meta = meta or {}

    def sheet_errors(filename, ai_rows, required, expect_rows, validate_args):
        info = meta.get(filename)
        if info is not None:
            shape = _check_sheet_shape(filename, info.get("path"), ai_rows,
                                       info.get("fieldnames"), required,
                                       expect_rows=expect_rows)
            if shape:
                return shape
        return _validate_sheet(*validate_args)

    cand_ids = ["R%d" % i for i in range(1, len(rows) + 1)]
    cand_pos = [_s(row.get("候選段次")) for row in rows]
    # 外部引用檢查匯入時接在決定表最後的列（來源只有「外部引用」）：那時候 AI候選判斷.csv
    # 早就填好了，裡面沒有它們；可以不填，填了照樣驗
    optional = set("R%d" % i for i, row in enumerate(rows, 1) if dt.appended_row(row))
    errors = sheet_errors("AI候選判斷.csv", ai_cand, CAND_REQUIRED, bool(set(cand_ids) - optional),
                          ("AI候選判斷.csv", ai_cand, "列ID", "R", "候選段次",
                           cand_ids, cand_pos, optional))

    change_ids = ["C%d" % i for i in range(1, len(changes) + 1)]
    change_pos = [_s(ch["new_index"]) if ch.get("new_index") else "刪除" for ch in changes]
    errors += sheet_errors("AI異動審查.csv", ai_change, CHANGE_REQUIRED, bool(changes),
                           ("AI異動審查.csv", ai_change, "異動ID", "C", "新版段次",
                            change_ids, change_pos))
    return errors


# ---------------------------------------------------------------------------
# 驗原文：決定表的「候選全文」有沒有被手改過
# ---------------------------------------------------------------------------

MISMATCH_SHEET = "原文已修改未匯入"
MISMATCH_HEADER = ["列ID", "段次", "內容（前 40 字）", "原因"]
REASON_EDITED = "決定表上的候選全文跟初比對指紋不符（被手改過）"
REASON_STALE = "AI 判斷不是對這一輪的字判的（多半是重跑 compare 後拿上一輪的 AI 檔）"


def check_row_texts(rows, sidecar):
    """逐列比對「候選全文」與指紋檔的 候選全文SHA256。

    回傳 (不符的列索引 set（0 起算）, 指紋檔有沒有列指紋)。

    為什麼要驗（should_fix no 3）：決定表是給人用 Excel 開來填「要改嗎」「改成什麼」
    的，同一張表上的「候選全文」欄很容易被順手改掉（想順便把錯字修掉、
    貼上時把儲存格蓋掉）。以前 review-import 只驗兩張 AI CSV 的列ID 對不對得上，
    改過的原文就這樣一路進到 LLM審查報告，報告上印的「候選全文」已經不是草稿裡
    那一段，但沒有任何一個字提示這件事。

    舊版留底的指紋檔沒有「列」（格式版本 1 之前的產出）就整批照舊匯入，
    由呼叫端發一則提醒——那不是「文字被改過」，是「這次沒得驗」。

    列與指紋怎麼對一律走 dt.match_sidecar（不看列序）。對到了但指紋不同＝被手改過；
    一筆都對不到＝段次與全文都跟初比對不一樣，同樣算不符。
    """
    sidecar_rows = (sidecar or {}).get("列") or []
    if not sidecar_rows:
        return set(), False
    matched, _ = dt.match_sidecar(rows, sidecar_rows)
    bad = set()
    for i, row in enumerate(rows):
        k = matched[i]
        if k is None or sidecar_rows[k].get("候選全文SHA256") != dt.text_sha256(row.get("候選全文") or ""):
            bad.add(i)
    return bad, True


def stale_ai_rows(ai_rows, id_col, id_prefix, sha_col, expected_shas):
    """AI 檔裡「不是對這一輪那段字判的」列：程式填的指紋欄跟現在那一段的指紋對不上。

    回傳 (索引 set（0 起算，對應 expected_shas）, AI 檔有沒有指紋欄)。
    重跑 compare 之後列ID 與段次常常一模一樣，只有字變了；只靠列ID 對，上一輪
    AI 的理由就會匯進這一輪的表。指紋欄空白的列（AI 把它清掉了）一樣算對不上。
    """
    if not ai_rows or not any(sha_col in row for row in ai_rows):
        return set(), False
    by_id = dict((_s(row.get(id_col)), row) for row in ai_rows)
    stale = set()
    for i, want in enumerate(expected_shas):
        row = by_id.get("%s%d" % (id_prefix, i + 1))
        if row is not None and _s(row.get(sha_col)) != want:
            stale.add(i)
    return stale, True


def mismatch_rows(rows, bad_idx, stale_cand=(), changes=None, stale_changes=()):
    """「原文已修改未匯入」表的列：列ID、段次、內容前 40 字、原因。

    兩種沒匯入的原因分開寫：候選全文被手改過（要去還原決定表），跟 AI 檔是上一輪的
    （要重跑 review-pack）。混成一句「原文不符」，人會去決定表上找一個不存在的竄改。
    AI 異動審查裡對不上這一輪異動的列接在後面（異動ID、新版段次、新文前 40 字）。"""
    out = []
    for i in sorted(set(bad_idx) | set(stale_cand)):
        row = rows[i] if i < len(rows) else {}
        text = row.get("候選全文") or ""
        out.append(["R%d" % (i + 1), row.get("候選段次") or "", text[:40],
                    REASON_EDITED if i in bad_idx else REASON_STALE])
    for i in sorted(stale_changes):
        ch = (changes or [])[i] if i < len(changes or []) else {}
        text = ch.get("new_text") or ch.get("old_text") or ""
        out.append(["C%d" % (i + 1), ch.get("new_index") or "刪除", text[:40], REASON_STALE])
    return out


# ---------------------------------------------------------------------------
# 報告
# ---------------------------------------------------------------------------

def _count_by(ai_rows, verdicts):
    counts = dict((v, 0) for v in verdicts)
    for row in ai_rows:
        v = (row.get("AI判斷") or "").strip()
        if v in counts:
            counts[v] += 1
    return counts


def _score_cell(ai_row):
    """報告要數字格：分數轉得出來就給 int（xlsx_writer 會寫成 <v>），轉不出來就照抄字串。"""
    raw = _s(ai_row.get("AI分數"))
    try:
        return int(raw)
    except ValueError:
        return raw


def _cand_id_for(row, contexts):
    """報告要顯示的「候選條文ID」：決定表這欄本來就有填就直接用（決定表本身不動，
    這裡只是報告要顯示什麼）；是空的（沒有正式基準、regdiff 給不出條文ID 的候選，
    實測資料常見）就退回候選段落自己的章節脈絡——ref（例如「第六條」）優先，
    沒有 ref 才用 format_scope（章節，例如「第一章 第一節」）。找不到段落或
    contexts 沒給（沒有 book 可查）就維持空字串。"""
    cand_id = (row.get("候選條文ID") or "").strip()
    if cand_id or not contexts:
        return cand_id
    idx = dt.line_of(row.get("候選段次")) - 1
    if 0 <= idx < len(contexts):
        ctx = contexts[idx]
        return ctx.get("ref") or format_scope(ctx) or ""
    return cand_id


def report_tables(rows, changes, ai_cand, ai_change, book_name="", book=None, books=None,
                  mismatched=None, stale_cand=(), stale_changes=()):
    """產報告要的三張表：[(工作表名, header, rows), ...]。欄照規格第七節；「總結」
    前 10 筆依 AI分數 降冪、同分依列ID。批次時（book_name 非空）三張表最前面加
    一欄「規章」。`book`（`review_pack.load_book` 的回傳值，選填）給得出
    `new_contexts` 時，「候選條文ID」欄空白會退回候選段落的章節脈絡（見
    `_cand_id_for`）；不給就照決定表原樣（可能是空的）。`books`（{規章名: book}，
    選填）給跨本列（異動條文ID 是「X：ref」那種）用，沒給就只查得到自己這本，
    跨本列的「異動原條文」「異動修正後條文」會印「（找不到對應異動）」。

    `mismatched`（選填，不符指紋的列索引 set）非空時最後再多一張
    「原文已修改未匯入」表，讓看報告的人知道哪幾列的 AI 判斷沒有寫回去。"""
    cand_by_id = {(r.get("列ID") or "").strip(): r for r in ai_cand}
    change_by_id = {(r.get("異動ID") or "").strip(): r for r in ai_change}
    mini_book = {"changes": changes}  # changes_for_row 只用得到 book["changes"]
    contexts = (book or {}).get("new_contexts")

    # 「修改類型」緊跟在「異動條文ID」後面：那一欄講的就是這一列被哪一處異動帶出來的，
    # 是修改還是整條刪掉，判的事完全不同，不能只給 ID 叫人自己去翻異動清單。
    cand_header = ["列ID", "候選段次", "候選條文ID", "來源", "關係／分數", "異動條文ID",
                  "修改類型", "異動原條文", "異動修正後條文", "候選全文",
                  "AI判斷", "AI分數", "AI理由"]
    cand_rows = []
    for i, row in enumerate(rows, 1):
        rid = "R%d" % i
        ai_row = cand_by_id.get(rid, {})
        matches = rp.changes_for_row(row, mini_book, books)
        if matches:
            old_text = "\n\n".join((ch.get("old_text") or "") for _, ch in matches)
            new_text = "\n\n".join((ch.get("new_text") or "") for _, ch in matches)
        else:
            old_text = new_text = "（找不到對應異動）"
        cand_rows.append([
            rid, row.get("候選段次") or "", _cand_id_for(row, contexts), row.get("來源") or "",
            row.get("關係／分數") or "", row.get("異動條文ID") or "",
            row.get("修改類型") or "", old_text, new_text,
            row.get("候選全文") or "", ai_row.get("AI判斷") or "", _score_cell(ai_row),
            ai_row.get("AI理由") or "",
        ])

    change_header = ["異動ID", "新版段次", "條號", "修改類型", "原條文", "修正後條文",
                     "AI判斷", "AI分數", "AI理由"]
    change_rows = []
    for i, ch in enumerate(changes, 1):
        cid = "C%d" % i
        ai_row = change_by_id.get(cid, {})
        ref = ch.get("ref") or ch.get("scope") or ""
        change_rows.append([
            cid, ch.get("new_index") or "刪除", ref, ch.get("修改類型") or "",
            ch.get("old_text") or "", ch.get("new_text") or "",
            ai_row.get("AI判斷") or "", _score_cell(ai_row), ai_row.get("AI理由") or "",
        ])

    cand_counts = _count_by(ai_cand, CAND_VERDICTS)
    change_counts = _count_by(ai_change, CHANGE_VERDICTS)
    summary_header = ["項目", "數量"]
    # 「項目」欄光看「需再檢查」分不出是候選審查還是異動審查那一種，加「候選：」「異動：」
    # 字首才看得出兩個表各自的三種判斷數量。
    summary_rows = [["候選：%s" % v, cand_counts[v]] for v in CAND_VERDICTS]
    summary_rows += [["異動：%s" % v, change_counts[v]] for v in CHANGE_VERDICTS]
    summary_rows.append(["", ""])
    summary_rows.append(["分數最高前 10 筆", ""])
    # 「候選段次」緊跟在列ID 後面（小瑕疵 5）：這張總結是拿來排優先序、然後回決定表
    # 逐列處理的，只給列ID 的話人得先翻到「候選審查」表查段次，才找得到草稿裡的那一段。
    summary_rows.append(["列ID", "候選段次", "候選條文ID", "候選全文", "AI分數", "AI理由"])

    def _sort_key(i):
        ai_row = cand_by_id.get("R%d" % (i + 1), {})
        score_ok, score = _score_ok(ai_row.get("AI分數"))
        return (-score if score_ok else 1, i)

    for i in sorted(range(len(rows)), key=_sort_key)[:10]:
        rid = "R%d" % (i + 1)
        ai_row = cand_by_id.get(rid, {})
        row = rows[i]
        summary_rows.append([rid, row.get("候選段次") or "", _cand_id_for(row, contexts),
                             row.get("候選全文") or "",
                             _score_cell(ai_row), ai_row.get("AI理由") or ""])

    tables = [("總結", summary_header, summary_rows),
             ("候選審查", cand_header, cand_rows),
             ("異動審查", change_header, change_rows)]
    if mismatched or stale_cand or stale_changes:
        tables.append((MISMATCH_SHEET, MISMATCH_HEADER,
                       mismatch_rows(rows, mismatched or set(), stale_cand, changes, stale_changes)))

    if book_name:
        tables = [(name, ["規章"] + header, [[book_name] + list(r) for r in table_rows])
                  for name, header, table_rows in tables]
    return tables


def write_report(base_path, tables, source="審查匯入"):
    """報告只出一種格式：先試 .xlsx，寫不出來（磁碟滿、檔案開在 Excel 裡）才
    每張工作表各退一個 .csv（`_總結.csv`、`_候選.csv`、`_異動.csv`、`_原文不符.csv`）
    並發一則提醒。回傳實際寫出來的第一個檔（xlsx 或第一份 csv）。

    以前是「csv 每次都寫、xlsx 再寫一次」，同一份報告在資料夾裡有四個檔，
    人分不出哪一個才是這次要看的；而且 csv 沒有欄寬、沒有換行，打開就是一團。

    這一輪沒有寫出來的檔（xlsx 成功時的那幾份 csv、或這一輪沒有「原文已修改未匯入」
    那張表的 `_原文不符.csv`）要把上一輪留下來的同名檔刪掉——不然人會拿上一輪的
    結果當成這一次的。"""
    names = dict((name, os.path.basename(base_path) + suffix)
                 for name, suffix in _CSV_SUFFIX.items())
    written = xw.write_tables_or_csv(base_path, tables, source=source, csv_names=names)
    kept = set(os.path.abspath(p) for p in written)
    for suffix in _CSV_SUFFIX.values():
        stale = base_path + suffix
        if os.path.abspath(stale) not in kept and os.path.isfile(stale):
            os.remove(stale)
    return written[0]


# ---------------------------------------------------------------------------
# 匯入主流程
# ---------------------------------------------------------------------------

AI_REVIEW_RECORD = "AI審查紀錄.json"


def ai_review_signature(rows, changes):
    """這一次 AI 審的是哪些候選列、哪些異動（指紋）。人工待辦拿現在的表算一次比對：
    不一樣（補了語意、重跑了開始）就是還要 AI 審。之後才接上去的列（外部引用、驗收新候選）不算。"""
    return {"列": sorted("%s@%s" % (dt.text_sha256(r.get("候選全文") or ""), (r.get("候選段次") or "").strip())
                        for r in rows if not dt.appended_row(r)),
            "異動": sorted(rp.change_sha256(ch) for ch in changes)}


def import_review(outdir, book_name="", books=None, book=None):
    """驗證兩張 AI CSV → 通過就把 AI判斷／AI分數／AI理由 三欄寫回連帶決定表.csv，
    再產出 LLM審查報告.xlsx 與三份保底 .csv。驗證不過就 raise ReviewError（訊息是
    每行一條的全部錯誤），什麼都不寫。`books`（{規章名: book}，選填）給跨本候選查
    來源本的異動全文用，見 report_tables。

    `book`（rp.load_book 的回傳值，選填）給得出就不再重新 load_book——批次逐本
    呼叫時，第一階段驗證已經 load_book 過一次（見 run_all.cmd_batch_review_import
    的 loaded dict），這裡不用再讀一次連帶決定表／異動清單／docx。

    匯入前先驗原文（should_fix no 3）：決定表上的「候選全文」要跟初比對指紋檔
    （<決定表>.json 的「列」）的 候選全文SHA256 一致，不一致的列不寫 AI 三欄，
    另外列一張「原文已修改未匯入」表並發一則警告。見 check_row_texts。

    回傳 {"候選": {判斷: 數}, "異動": {判斷: 數}, "報告": xlsx路徑,
          "表": [(工作表名, header, rows), ...], "原文不符": [列ID...]}。"""
    if book is None:
        book = rp.load_book(outdir)
    rows, changes = book["rows"], book["changes"]
    ai_cand, ai_change, ai_meta = load_ai_files(outdir)

    errors = validate(rows, changes, ai_cand, ai_change, ai_meta)
    ext_rows = load_external(outdir)
    ext_errors, ext_good, ext_stale = check_external(book, ext_rows)
    errors += ext_errors
    rc_items = rp.rulecheck_items(outdir)
    rc_errors, rc_good, rc_stale = check_rulecheck(rc_items, load_rulecheck(outdir))
    errors += rc_errors
    if errors:
        raise ReviewError("\n".join(errors))

    csv_path = locate(outdir, "連帶決定表.csv")[0]
    sidecar = book.get("sidecar")
    if sidecar is None:
        # load_book 沒把指紋檔存進 book（舊的 book dict、或呼叫端自己組的）就補讀一次。
        try:
            sidecar = dt.read_sidecar(dt.sidecar_path_for(csv_path))
        except dt.DecisionTableError:
            sidecar = {}
        book["sidecar"] = sidecar
    bad_idx, has_fingerprints = check_row_texts(rows, sidecar)
    if rows and not has_fingerprints:
        nt.notice(nt.REMINDER,
                  "指紋檔沒有列指紋，這次沒驗原文（舊版留底的產出資料夾）；"
                  "決定表上的候選全文有沒有被手改過，這一輪查不出來",
                  "review-import")
    mismatch_ids = ["R%d" % (i + 1) for i in sorted(bad_idx)]
    if mismatch_ids:
        nt.notice(nt.WARNING,
                  "有 %d 列候選全文與初比對指紋不符（列ID %s），這幾列的 AI 判斷沒有匯入；"
                  "請重跑 compare 或還原決定表"
                  % (len(mismatch_ids), "、".join(mismatch_ids)),
                  "review-import")

    # AI 判斷是不是對「這一輪」的字判的：AI 檔裡 review-pack 填的指紋要跟現在那一段一樣。
    stale_cand, cand_has_sha = stale_ai_rows(
        ai_cand, "列ID", "R", rp.CAND_SHA_COLUMN,
        [rp.candidate_sha256(row, book) for row in rows])
    stale_change, change_has_sha = stale_ai_rows(
        ai_change, "異動ID", "C", rp.CHANGE_SHA_COLUMN,
        [rp.change_sha256(ch) for ch in changes])
    stale_cand -= bad_idx          # 原文被手改的那幾列上面已經講過了
    stale_ids = (["R%d" % (i + 1) for i in sorted(stale_cand)]
                 + ["C%d" % (i + 1) for i in sorted(stale_change)])
    if stale_ids:
        nt.notice(nt.WARNING,
                  "有 %d 列 AI 判斷不是對這一輪的字判的（%s）：AI 檔記的指紋跟現在的候選／異動"
                  "對不上，多半是重跑 compare 之後拿上一輪的 AI 檔來匯入；這幾列沒有匯入，"
                  "請重跑 review-pack 讓 AI 重判" % (len(stale_ids), "、".join(stale_ids)),
                  "review-import")
    no_sha = []
    if ai_cand and not cand_has_sha:
        no_sha.append("AI候選判斷.csv 的「%s」" % rp.CAND_SHA_COLUMN)
    if ai_change and not change_has_sha:
        no_sha.append("AI異動審查.csv 的「%s」" % rp.CHANGE_SHA_COLUMN)
    if no_sha:
        # 上一版 review-pack 產的表沒有這一欄。照舊匯入，但不能默不作聲。
        nt.notice(nt.WARNING,
                  "AI 檔缺指紋欄（%s），無法確認 AI 判斷是對這一輪的字判的；"
                  "重跑過 compare 的話請重跑 review-pack 讓 AI 重判" % "、".join(no_sha),
                  "review-import")
    # 沒匯入的列（手改過＋AI 過期）不進報告的判斷與統計：報告上看得到判斷，
    # 人就會以為那一列審過了。
    skipped = bad_idx | stale_cand
    skip_ids = set(mismatch_ids) | set(stale_ids)
    ai_cand = [r for r in ai_cand if _s(r.get("列ID")) not in skip_ids]
    ai_change = [r for r in ai_change if _s(r.get("異動ID")) not in skip_ids]

    cand_by_id = {(r.get("列ID") or "").strip(): r for r in ai_cand}
    for i, row in enumerate(rows, 1):
        if (i - 1) in skipped:
            # 候選全文已經不是初比對那一段了，AI 是照著被改過的文字判的；
            # 寫回去只會讓報告看起來有憑有據。三欄清空，不留上一輪的舊判斷——
            # 留著的話決定表上那一列會掛著跟旁邊文字對不上的 AI 建議，
            # 而人填「要改嗎」時看的正是這一張表（審查發現）。
            row["AI判斷"] = row["AI分數"] = row["AI理由"] = ""
            continue
        ai_row = cand_by_id.get("R%d" % i, {})
        _, score = _score_ok(ai_row.get("AI分數"))
        row["AI判斷"] = (ai_row.get("AI判斷") or "").strip()
        row["AI分數"] = "" if score is None else str(score)      # 空白不能寫成 "None"
        row["AI理由"] = (ai_row.get("AI理由") or "").strip()

    dt.write_rows_csv(csv_path, rows)
    flagged, pending = write_confirmations(
        outdir, changes, ai_change, rc_items, rc_good,
        rp.external_items(book) if ext_good else None, ext_good, book["new_paragraphs"])

    tables = report_tables(rows, changes, ai_cand, ai_change, book_name, book=book,
                           books=books, mismatched=bad_idx, stale_cand=stale_cand,
                           stale_changes=stale_change)
    rc_counts = None
    if rc_items:
        body = rulecheck_table(rc_items, rc_good)
        header = RULECHECK_REPORT_HEADER
        if book_name:
            header, body = ["規章"] + header, [[book_name] + r for r in body]
        tables.append((RULECHECK_SHEET, header, body))
        rc_counts = dict((v, 0) for v in sr.RULECHECK_VERDICTS + (NOT_REVIEWED,))
        for item in rc_items:
            state = _rulecheck_state(item, rc_good)[0]
            rc_counts[state] = rc_counts.get(state, 0) + 1
        if rc_good is None:
            nt.notice(nt.REMINDER,
                      "AI條文檢查.csv 沒有填：條文檢查高風險 %d 項全部進 人工確認.csv 要承辦回覆"
                      % len(rc_items), "review-import")
        if rc_stale:
            nt.notice(nt.WARNING,
                      "AI條文檢查.csv 有 %d 列不是對這一輪的字判的（%s），當成 AI 沒審、進人工確認；"
                      "請重跑 review-pack 讓 AI 重判" % (len(rc_stale), "、".join(rc_stale)), "review-import")
    ext_counts = None
    if ext_good is not None:
        ext_counts = _count_external(ext_good)
        _remember_external(outdir, book, ext_good)
        done = apply_external(book, ext_good, csv_path)
        header, body = EXTERNAL_REPORT_HEADER, external_table(book, ext_good, done["逐列"])
        if book_name:
            header, body = ["規章"] + header, [[book_name] + r for r in body]
        tables.append((EXTERNAL_SHEET, header, body))
        fixed = done["登錄"] + ["排除：%s" % n for n in done["排除"]]
        if fixed:
            nt.notice(nt.REMINDER,
                      "外部規章：程式抓錯的已自動修正（%s），下一次比對就會抓對，不用人處理"
                      % "、".join(("登錄：%s" % n) if not n.startswith("排除：") else n for n in fixed),
                      "review-import")
        if done["決定表"]:
            nt.notice(nt.WARNING,
                      "外部規章引用過時或條號錯誤 %d 處（AI 已上網查證），已列進連帶決定表"
                      "（來源「外部引用」，建議改法寫好）：確認後在「要改嗎」填「改」（改成什麼留空＝照建議改法）就會套用"
                      % done["決定表"], "review-import")
        if ext_counts["無法查證"]:
            nt.notice(nt.REMINDER,
                      "外部規章：%d 處 AI 無法上網查證，要承辦確認（%s）；已列進 人工確認.csv"
                      % (ext_counts["無法查證"], "、".join(done["無法查證"])), "review-import")
    elif ext_rows is not None and rp.external_items(book):
        nt.notice(nt.REMINDER, "AI外部引用.csv 沒有填，這一輪沒做外部規章引用的 AI 檢查", "review-import")
    if ext_stale:
        nt.notice(nt.WARNING,
                  "AI外部引用.csv 有 %d 列不是對這一輪的字判的（%s），沒有匯入；請重跑 review-pack 讓 AI 重判"
                  % (len(ext_stale), "、".join(ext_stale)), "review-import")
    # 報告是人要看的 → 審閱文件/。place 回傳的是帶副檔名的路徑，write_report 要的是
    # 不帶副檔名的 base（副檔名由它自己補，因為可能退成 csv）。
    report_path = write_report(os.path.splitext(place(outdir, "LLM審查報告.xlsx"))[0], tables)
    with io.open(place(outdir, AI_REVIEW_RECORD), "w", encoding="utf-8") as f:
        json.dump(ai_review_signature(rows, changes), f, ensure_ascii=False)

    return {"候選": _count_by(ai_cand, CAND_VERDICTS), "異動": _count_by(ai_change, CHANGE_VERDICTS),
            "報告": report_path, "表": tables, "原文不符": mismatch_ids, "AI過期": stale_ids,
            "人工確認": flagged, "人工待確認": pending, "外部引用": ext_counts, "條文檢查": rc_counts}


# ---------------------------------------------------------------------------
# 外部規章引用檢查（AI外部引用.csv）
# ---------------------------------------------------------------------------
# 程式用規則抓外部規章引用（rule_checks.external_mentions），抓得到寫法固定的，
# 抓不到的是「名稱對不對、是不是真的外部法規、條號合不合理、母法有沒有改過」這種要讀懂的事，
# 還有寫法特別的漏網之魚。review-pack 把每一處（E1…）和可能漏抓的段落交給 AI，
# 這裡驗 AI 填的表、做成報告的一張表，有誤／漏抓發警告、需查證發提醒。
# AI 完全沒填（整張空白）就當成這一輪沒做外部引用檢查，講一聲，不擋其他兩張表匯入。

EXTERNAL_SHEET = "外部引用"
EXTERNAL_REPORT_HEADER = ["引用ID", "段次", "程式抓到", "AI判斷", "AI理由", "AI更正", "查證來源", "類別",
                          "自動處理", "段落全文"]
# 這幾種標籤的 AI更正 一定要填：程式要照它修登錄表，或照它寫建議改法
_FIX_REQUIRED = ("名稱錯誤", "引用過時", "條號錯誤", "漏抓")
_URL_RE = re.compile(r"https?://")


def load_external(outdir):
    """讀 AI外部引用.csv；沒有這個檔（舊的產出資料夾、還沒跑過新版 review-pack）回 None。"""
    path = locate(outdir, rp.EXTERNAL_FILE)[0]
    if not os.path.isfile(path):
        return None
    return _read_ai_csv(path)[0]


def _category(row, item):
    from _common import external_category
    return _s(row.get("類別")) or (external_category(item["名稱"]) if item else "")


def check_external(book, ai_rows):
    """驗 AI外部引用.csv。回傳 (錯誤 list, 驗過可匯入的列 list 或 None＝整張沒填, 過期的引用ID list)。

    這一步盡量不留給人：法律與主管機關法規要 AI 上網查證（沒附查證網址就退件），
    「無法查證」只收本行內規、查無資料、無法連網三種。
    過期：這一列審的是哪一段、哪一處引用，由段落指紋記著；重跑 compare 之後字變了就不匯入。"""
    if ai_rows is None:
        return [], None, []
    items = dict((item["引用ID"], item) for item in rp.external_items(book))
    # 從查證快取沿用的列（「沿用查證」有日期）不算 AI 這一輪填的：只有它們、別的都沒填，
    # 而且還有沒沿用到的引用，就是 AI 這一輪沒做外部引用檢查
    answered = [r for r in ai_rows if not _s(r.get("沿用查證"))
                and (_s(r.get("AI判斷")) or _s(r.get("AI理由")) or _s(r.get("AI更正")))]
    reused = set(_s(r.get("引用ID")) for r in ai_rows if _s(r.get("沿用查證")))
    if not answered and not (items and set(items) <= reused):
        return [], None, []
    total = len(book["new_paragraphs"])
    errors, good, stale, seen = [], [], [], set()
    for row in ai_rows:
        rid = _s(row.get("引用ID"))
        tag = "「%s」%s" % (rp.EXTERNAL_FILE, rid or "（沒有引用ID）")
        verdict = _s(row.get("AI判斷"))
        reason = _s(row.get("AI理由"))
        fix = _s(row.get("AI更正"))
        source = _s(row.get("查證來源"))
        item = items.get(rid)
        if rid == "新增":
            line = _s(row.get("段次"))
            if not (line.isdigit() and 1 <= int(line) <= total):
                errors.append("%s：段次要是 1–%d 的整數：「%s」" % (tag, total, line))
            if verdict != "漏抓":
                errors.append("%s：自己加的列 AI判斷 只能填「漏抓」" % tag)
        elif item:
            if rid in seen:
                errors.append("%s：引用ID 重複" % tag)
            seen.add(rid)
            if _s(row.get(rp.EXTERNAL_SHA_COLUMN)) not in ("", item["sha"]):
                stale.append(rid)
                continue
            if verdict not in ("有誤", "無法查證", "沒問題"):
                errors.append("%s：AI判斷 只能是 有誤／無法查證／沒問題：「%s」" % (tag, verdict))
        else:
            errors.append("%s：引用ID 對不上（程式抓到的是 E1…E%d，自己加的列寫「新增」）"
                          % (tag, len(items)))
            continue
        label = sr.label_in(reason)
        if not reason:
            errors.append("%s：AI理由是空的" % tag)
        elif not label:
            errors.append("%s：AI理由要用標籤開頭（可用：%s）" % (tag, sr.external_labels()))
        elif verdict in sr.EXTERNAL_VERDICTS and not sr.external_label_ok(verdict, label):
            errors.append("%s：「〔%s〕」配不上判斷「%s」（%s 可用：%s）"
                          % (tag, label, verdict, verdict, sr.external_labels(verdict)))
        category = _category(row, item)
        if category and category not in sr.EXTERNAL_CATEGORIES:
            errors.append("%s：類別只能是 %s：「%s」" % (tag, "／".join(sr.EXTERNAL_CATEGORIES), category))
        if (label == "名稱錯誤" or verdict == "漏抓") and category not in sr.EXTERNAL_CATEGORIES:
            errors.append("%s：〔%s〕要填類別（%s），匯入時照它加進登錄表"
                          % (tag, label or verdict, "／".join(sr.EXTERNAL_CATEGORIES)))
        if label in ("名稱錯誤", "引用過時", "條號錯誤") and "改成" not in reason:
            errors.append("%s：〔%s〕的理由要寫「改成…」" % (tag, label))
        if (label in _FIX_REQUIRED or verdict == "漏抓") and not fix:
            errors.append("%s：〔%s〕要在 AI更正 填正確的寫法" % (tag, label or verdict))
        checked_online = verdict == "沒問題" or label in ("引用過時", "條號錯誤") or verdict == "漏抓"
        if checked_online and category not in ("本行內規",) and not _URL_RE.search(source):
            errors.append("%s：法律、主管機關法規、公會自律規範要上網查證，查證來源 要填實際打開的網址" % tag)
        if label == "查無資料" and not source:
            errors.append("%s：〔查無資料〕要在 查證來源 寫查了哪些網址或關鍵字" % tag)
        good.append(row)
    for rid in sorted(set(items) - seen, key=lambda x: int(x[1:])):
        errors.append("「%s」缺 %s（程式抓到的每一處都要判）" % (rp.EXTERNAL_FILE, rid))
    return errors, good, stale


def _remember_external(outdir, book, rows):
    """AI 這一輪上網查過的（有誤、沒問題）存進查證快取，下一輪同一處引用直接沿用。"""
    import batch as bt
    import verify_cache as vc
    folder = bt.cache_dir(outdir)
    if not folder:
        return 0
    items = dict((item["引用ID"], item) for item in rp.external_items(book))
    pairs = []
    for row in rows:
        item = items.get(_s(row.get("引用ID")))
        if item:
            pairs.append((vc.key(item["引用"], book["new_paragraphs"][item["段次"] - 1]), row))
    return vc.record(folder, pairs)


def _law_name_of(citation):
    """「洗錢防制法第十條」→「洗錢防制法」（登錄表只記名稱）。"""
    text = re.sub(r"\s+", "", citation or "")
    text = re.sub(r"（未指明條號）$", "", text)
    match = re.match(r"^(.+?)第[%s\d]+[條點]" % "零〇一二三四五六七八九十百千", text)
    return match.group(1) if match else text


def _splice_citation(text, item, fix):
    """把那一處外部引用換成 AI更正（「名稱＋條號」的寫法）。

    原文就是照「引用」那樣寫的，整段換掉。原文寫法不一樣時——名稱加引號（「保險法」第五條）、
    「同法第五條」、第二個條號（保險法第五條、第七條的「第七條」，起訖只框條號）——
    AI更正的名稱跟程式抓到的一樣就只換條號，名稱那一段照原文留著；整段換掉的話
    引號會少一半、「同法」被改寫、第二個條號前面多出一次名稱。"""
    start, end = item["起"], item["訖"]
    original = text[start:end]
    name, number = item.get("名稱") or "", item.get("條號") or ""
    if (original == item.get("引用") or not number or not original.endswith(number)
            or not fix.startswith(name)):
        return text[:start] + fix + text[end:]
    return text[:end - len(number)] + fix[len(name):] + text[end:]


def apply_external(book, rows, table_path):
    """AI 判完之後程式自己做的事（不用人）：
        程式抓錯（名稱錯誤、漏抓）→ 名稱加進登錄表；非外部法規 → 加進排除表。下一次比對就抓對。
        本文引用錯（引用過時、條號錯誤）→ 接進連帶決定表，建議改法照位置把那一處換成 AI更正。
    回傳 {"逐列": [每一列做了什麼], "登錄": [...], "排除": [...], "決定表": 新增幾列, "無法查證": [...]}。"""
    from _common import add_external_exclusion, add_external_registry
    items = dict((item["引用ID"], item) for item in rp.external_items(book))
    paragraphs = book["new_paragraphs"]
    done = {"逐列": [], "登錄": [], "排除": [], "決定表": 0, "無法查證": []}
    fixes = []
    for row in rows:
        rid = _s(row.get("引用ID"))
        item = items.get(rid)
        verdict = _s(row.get("AI判斷"))
        label = sr.label_in(_s(row.get("AI理由")))
        fix = _s(row.get("AI更正"))
        source = _s(row.get("查證來源"))
        action = ""
        if label == "名稱錯誤" or verdict == "漏抓":
            name = _law_name_of(fix)
            if add_external_registry(name, _category(row, item), "AI 外部引用檢查〔%s〕" % label):
                done["登錄"].append(name)
                action = "已加進登錄表：%s" % name
            else:
                action = "登錄表已有：%s" % name
        elif label == "非外部法規" and item:
            if add_external_exclusion(item["名稱"], "AI 外部引用檢查"):
                done["排除"].append(item["名稱"])
            action = "已加進排除表：%s" % item["名稱"]
        elif label in ("引用過時", "條號錯誤") and item:
            text = paragraphs[item["段次"] - 1]
            fixes.append({"段次": item["段次"], "候選全文": text,
                          "建議改法": _splice_citation(text, item, fix),
                          "異動內容": "「%s」→「%s」（外部引用〔%s〕）" % (item["引用"], fix, label),
                          "關係": "〔%s〕查證：%s" % (label, source)})
            action = "列進連帶決定表（第 %d 段）" % item["段次"]
        elif verdict == "無法查證":
            done["無法查證"].append("%s %s" % (rid, item["引用"] if item else ""))
            action = "要承辦確認"
        done["逐列"].append(action)
    if fixes:
        done["決定表"] = dt.append_external_rows(table_path, fixes)
        done["決定表"] = max(done["決定表"], len(fixes))
    return done


def external_table(book, rows, actions=None):
    """報告裡「外部引用」那一張表。"""
    items = dict((item["引用ID"], item) for item in rp.external_items(book))
    actions = actions or [""] * len(rows)
    out = []
    for row, action in zip(rows, actions):
        rid = _s(row.get("引用ID"))
        line = _s(row.get("段次"))
        text = (book["new_paragraphs"][int(line) - 1]
                if line.isdigit() and 1 <= int(line) <= len(book["new_paragraphs"]) else "")
        out.append([rid, line, items.get(rid, {}).get("引用", ""), _s(row.get("AI判斷")),
                    _s(row.get("AI理由")), _s(row.get("AI更正")), _s(row.get("查證來源")),
                    _category(row, items.get(rid)), action, text])
    return out


def _count_external(rows):
    counts = dict((v, 0) for v in sr.EXTERNAL_VERDICTS)
    for row in rows:
        verdict = _s(row.get("AI判斷"))
        if verdict in counts:
            counts[verdict] += 1
    return counts


# ---------------------------------------------------------------------------
# 條文檢查高風險項（AI條文檢查.csv）
# ---------------------------------------------------------------------------
# 條文檢查報告的「高」風險項（應→得、數值期間、條號重複、定義變更連動、待補殘留）加上施行日期，
# 以前只躺在檢視報告裡，沒有表可以回覆，也不擋驗收。review-pack 把它們（K1…）交給 AI 上網查證，
# 這裡驗 AI 填的表：「沒問題」自動結案（理由、網址留在報告），「有問題」「需人確認」進人工確認表。

RULECHECK_SHEET = "條文檢查查證"
RULECHECK_REPORT_HEADER = ["檢查ID", "段次", "檢查項目", "程式發現", "AI判斷", "AI理由", "查證來源", "處理"]
NOT_REVIEWED = "（AI 沒審）"


def load_rulecheck(outdir):
    """讀 AI條文檢查.csv；沒有這個檔回 None。"""
    path = locate(outdir, rp.RULECHECK_FILE)[0]
    if not os.path.isfile(path):
        return None
    return _read_ai_csv(path)[0]


def check_rulecheck(items, ai_rows):
    """驗 AI條文檢查.csv。回傳 (錯誤 list, {檢查ID: 列} 或 None＝整張沒填, 過期的檢查ID list)。"""
    if items is None or ai_rows is None:
        return [], None, []
    if not [r for r in ai_rows if _s(r.get("AI判斷")) or _s(r.get("AI理由"))]:
        return [], None, []
    by_id = dict((item["檢查ID"], item) for item in items)
    errors, good, stale, seen = [], {}, [], set()
    for row in ai_rows:
        kid = _s(row.get("檢查ID"))
        tag = "「%s」%s" % (rp.RULECHECK_FILE, kid or "（沒有檢查ID）")
        item = by_id.get(kid)
        if item is None:
            errors.append("%s：檢查ID 對不上（這一輪是 K1…K%d）" % (tag, len(items)))
            continue
        if kid in seen:
            errors.append("%s：檢查ID 重複" % tag)
        seen.add(kid)
        if _s(row.get(rp.RULECHECK_SHA_COLUMN)) not in ("", item["sha"]):
            stale.append(kid)
            continue
        verdict, reason, source = _s(row.get("AI判斷")), _s(row.get("AI理由")), _s(row.get("查證來源"))
        if verdict not in sr.RULECHECK_VERDICTS:
            errors.append("%s：AI判斷 只能是 %s：「%s」" % (tag, "／".join(sr.RULECHECK_VERDICTS), verdict))
        label = sr.label_in(reason)
        if not reason:
            errors.append("%s：AI理由是空的" % tag)
        elif not label:
            errors.append("%s：AI理由要用標籤開頭（可用：%s）" % (tag, sr.rulecheck_labels()))
        elif verdict in sr.RULECHECK_VERDICTS and not sr.rulecheck_label_ok(verdict, label):
            errors.append("%s：「〔%s〕」配不上判斷「%s」（%s 可用：%s）"
                          % (tag, label, verdict, verdict, sr.rulecheck_labels(verdict)))
        if label in sr.RULECHECK_URL_LABELS and not _URL_RE.search(source):
            errors.append("%s：〔%s〕要上網查證，查證來源 要填實際打開的網址" % (tag, label))
        if label == "查無依據" and not source:
            errors.append("%s：〔查無依據〕要在 查證來源 寫查了哪些網址或關鍵字" % tag)
        if verdict == "有問題" and "改成" not in reason:
            errors.append("%s：「有問題」的理由要寫「改成…」" % tag)
        good[kid] = row
    for kid in sorted(set(by_id) - seen, key=lambda x: int(x[1:])):
        errors.append("「%s」缺 %s（每一項都要判）" % (rp.RULECHECK_FILE, kid))
    return errors, good, stale


def _rulecheck_state(item, good):
    """(AI判斷, AI理由, 查證來源, 要不要人確認)。"""
    row = (good or {}).get(item["檢查ID"])
    if row is None:
        return NOT_REVIEWED, "", "", True
    verdict = _s(row.get("AI判斷"))
    return verdict, _s(row.get("AI理由")), _s(row.get("查證來源")), verdict != "沒問題"


def rulecheck_table(items, good):
    """報告裡「條文檢查查證」那一張表：自動結案的也列，理由與網址留底。"""
    out = []
    for item in items:
        verdict, reason, source, needs = _rulecheck_state(item, good)
        out.append([item["檢查ID"], item["段次"], item["check"], item["detail"], verdict, reason, source,
                    "進人工確認" if needs else "AI 查證結案"])
    return out


# ---------------------------------------------------------------------------
# 人工確認：AI 查不到、要人回覆的，全部在這一張
# ---------------------------------------------------------------------------
# 三種來源：
#   異動       AI 對「這次改的那一處本身」標了需再檢查／建議修改（例：放寬到超過上位規定）
#   條文檢查   高風險項 AI 判「有問題」「需人確認」，或 AI 沒審
#   外部引用   AI 上網也查不到（本行內規、查無資料、無法連網）
# 它們都不是連帶候選，決定表裡沒有它們的列；以前前一種有一張 異動確認.csv，後兩種只在報告裡、
# 沒有表可以回覆，人看過沒看過沒有紀錄，finalize 照樣判「改好」。
# 人在「人工確認」欄填「已確認」（看過沒問題）或寫下怎麼處理；留空的在 finalize 擋「改好」。
# 不動 AI 自己填的那幾張表：人跟 AI 寫在同一張表上分不出誰說的。

CONFIRM_FILE = "人工確認.csv"
LEGACY_CONFIRM_FILE = "異動確認.csv"
CONFIRM_COLUMN = "人工確認"
CONFIRM_SHA_COLUMN = "指紋"
CONFIRM_FLAGGED = ("需再檢查", "建議修改")
# 「人工確認」欄這幾種寫法才算結案。寫了別的（「不同意，改回三日」這種處理方式）不算：
# 以前只要有字就結案，驗收照樣判改好，但那句話要人去改的東西根本還沒改
CLOSED_ANSWERS = ("已確認", "確認", "確認過", "沒問題", "同意", "OK", "V", "✓", "✔")


def is_closed(answer):
    text = _s(answer)
    return text in CLOSED_ANSWERS or text.upper() in CLOSED_ANSWERS
# 講的是「這一處異動本身」的條文檢查項目：同一段已經因為異動審查列進來時，併成一列
# （門檻用語、但書跟數值、責任用語一樣，講的都是這一段這次怎麼改，人回覆一次就好）
_SAME_CHANGE_CHECKS = ("數值期間變更", "責任用語變更", "門檻用語變更", "但書增刪")


def _confirm_fields():
    return ["確認ID", "類別", "段次", "內容", "AI判斷", "AI理由", "查證來源", CONFIRM_COLUMN, "說明",
            CONFIRM_SHA_COLUMN]


def _change_text(change):
    old, new = (change.get("old_text") or "").strip(), (change.get("new_text") or "").strip()
    if old and new:
        return "舊：%s　→　新：%s" % (old, new)
    return ("刪除：%s" % old) if old else ("新增：%s" % new)


def _read_confirmations(path):
    if not path or not os.path.isfile(path):
        return []
    from _common import open_csv
    with open_csv(path) as f:
        return list(csv.DictReader(f))


def _row_key(row):
    """一列的指紋（「類別:sha」）。舊的 異動確認.csv 只有「異動SHA256」一欄。"""
    key = _s(row.get(CONFIRM_SHA_COLUMN))
    if key:
        return key
    old = _s(row.get(rp.CHANGE_SHA_COLUMN))
    return ("異動:" + old) if old else ""


def write_confirmations(outdir, changes, ai_change, rulecheck_items=None, rulecheck_good=None,
                        external_items=None, external_good=None, paragraphs=None):
    """把 AI 查不到、要人回覆的寫成 填寫表單/人工確認.csv。回傳 (列數, 還沒填的列數)。

    重跑 review-import 時，上一輪人填過的「人工確認」「說明」照指紋帶過來（同一處、字沒變才帶；
    舊的 異動確認.csv 也認）；這一輪一列都沒有就把表拿掉，免得留著一張過期的表。"""
    from _common import archived_file
    previous = {}
    # 上一輪歸檔的先讀、這一輪的後讀（同一處以這一輪為準）：重跑「開始」之後回覆照樣帶過來
    for name in (LEGACY_CONFIRM_FILE, CONFIRM_FILE):
        for path in (archived_file(outdir, name), locate(outdir, name)[0]):
            for r in _read_confirmations(path):
                key = _row_key(r)
                if key and (_s(r.get(CONFIRM_COLUMN)) or _s(r.get("說明"))):
                    previous[key] = (_s(r.get(CONFIRM_COLUMN)), _s(r.get("說明")))
    rows = []

    def add(rid, kind, line, text, verdict, reason, source, sha):
        key = "%s:%s" % (kind, sha)
        answer, note = previous.get(key, ("", ""))
        rows.append([rid, kind, line, text, verdict, reason, source, answer, note, key])

    for ai_row in ai_change:
        verdict = _s(ai_row.get("AI判斷"))
        cid = _s(ai_row.get("異動ID"))
        if verdict not in CONFIRM_FLAGGED or not cid[1:].isdigit():
            continue
        index = int(cid[1:]) - 1
        if not 0 <= index < len(changes):
            continue
        change = changes[index]
        add(cid, "異動", change.get("new_index") or "刪除", _change_text(change), verdict,
            _s(ai_row.get("AI理由")), _s(ai_row.get("查證來源")), rp.change_sha256(change))
    # 同一段的異動已經在上面列了（AI 標需再檢查），這一段的條文檢查（三日→五日、應→得）講的是
    # 同一件事：併進那一列，不另外一列，人不用回覆兩次
    by_line = dict((str(r[2]), r) for r in rows if r[1] == "異動")
    for item in rulecheck_items or []:
        verdict, reason, source, needs = _rulecheck_state(item, rulecheck_good)
        if not needs:
            continue
        same = by_line.get(str(item["段次"])) if item["check"] in _SAME_CHANGE_CHECKS else None
        if same is not None:
            same[0] += "＋" + item["檢查ID"]
            same[1] = "異動＋條文檢查"
            # 檢查項目寫在括號裡，AI 自己的理由（含〔標籤〕）原樣接上：以前把 AI 的〔查無依據〕換成〔數值期間變更〕，
            # 標籤就跟評分標準對不上了
            same[5] += "；%s（%s）%s" % (item["檢查ID"], item["check"], reason or verdict)
            if source and source not in same[6]:
                same[6] = "；".join(x for x in (same[6], source) if x)
            continue
        text = "[%s] %s" % (item["check"], item["detail"])
        if item.get("quote"):
            text += "｜" + item["quote"]
        add(item["檢查ID"], "條文檢查", item["段次"], text, verdict, reason, source, item["sha"])
    items = dict((item["引用ID"], item) for item in (external_items or []))
    for row in external_good or []:
        item = items.get(_s(row.get("引用ID")))
        if item is None or _s(row.get("AI判斷")) != "無法查證":
            continue
        text = item["引用"]
        if paragraphs and 1 <= item["段次"] <= len(paragraphs):
            text += "｜" + paragraphs[item["段次"] - 1][:80]
        add(item["引用ID"], "外部引用", item["段次"], text, "無法查證", _s(row.get("AI理由")),
            _s(row.get("查證來源")), item["sha"])

    # 驗收寫進來的警告列（類別「警告」）不是這一步管的，原樣接在最後
    for r in _read_confirmations(locate(outdir, CONFIRM_FILE)[0]):
        if _s(r.get("類別")) == WARNING_KIND:
            rows.append([r.get(c, "") for c in _confirm_fields()])
    target = place(outdir, CONFIRM_FILE)
    stale = [p for p in (locate(outdir, LEGACY_CONFIRM_FILE)[0], place(outdir, LEGACY_CONFIRM_FILE))
             if os.path.isfile(p)]
    if not rows:
        stale += [p for p in (locate(outdir, CONFIRM_FILE)[0], target) if os.path.isfile(p)]
    for path in set(stale):
        os.remove(path)
    if not rows:
        return 0, 0
    with io.open(target, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(_confirm_fields())
        writer.writerows(rows)
    mine = [r for r in rows if r[1] != WARNING_KIND]
    return len(mine), sum(1 for r in mine if not is_closed(r[7]))


WARNING_KIND = "警告"


def sync_warnings(outdir, warnings):
    """驗收的警告寫進 填寫表單/人工確認.csv（類別「警告」，確認ID W1、W2…），人回覆看過才算。
    其他類別的列原樣不動；上一次回覆過的照指紋帶過來。回傳人已經回覆的警告指紋（set）。

    為什麼：條號整批位移這種警告，每一次驗收都會再發（是這次修法本身造成的），
    以前結論永遠是「三問皆零但有警告」，人工待辦永遠停在「驗收沒過」，沒有結案的路。"""
    import finalize_check as fc
    path = locate(outdir, CONFIRM_FILE)[0]
    rows = _read_confirmations(path)
    fields = _confirm_fields()
    others = [r for r in rows if _s(r.get("類別")) != WARNING_KIND]
    from _common import archived_file
    previous = {}
    for r in _read_confirmations(archived_file(outdir, CONFIRM_FILE)) + rows:   # 這一輪的蓋過上一輪的
        if _s(r.get("類別")) == WARNING_KIND and _s(r.get(CONFIRM_COLUMN)):
            previous[_s(r.get(CONFIRM_SHA_COLUMN))] = r
    for r in rows:
        if _s(r.get("類別")) == WARNING_KIND:
            previous.setdefault(_s(r.get(CONFIRM_SHA_COLUMN)), r)
    fresh = []
    for i, entry in enumerate(warnings or [], 1):
        key = fc.warning_key(entry)
        old = previous.get(key) or {}
        fresh.append({"確認ID": "W%d" % i, "類別": WARNING_KIND, "段次": "",
                      "內容": "［%s］%s" % (entry.get("來源") or "驗收", entry.get("文字") or ""),
                      "AI判斷": "", "AI理由": "", "查證來源": "",
                      CONFIRM_COLUMN: _s(old.get(CONFIRM_COLUMN)), "說明": _s(old.get("說明")),
                      CONFIRM_SHA_COLUMN: key})
    target = place(outdir, CONFIRM_FILE)
    everything = others + fresh
    if not everything:
        for p in set(x for x in (path, target) if x and os.path.isfile(x)):
            os.remove(p)
        return set()
    if [r.get(CONFIRM_SHA_COLUMN) for r in rows] != [r[CONFIRM_SHA_COLUMN] for r in everything] or \
            any(_s(a.get(CONFIRM_COLUMN)) != _s(b.get(CONFIRM_COLUMN)) for a, b in zip(rows, everything)):
        with io.open(target, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields, quoting=csv.QUOTE_ALL, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(everything)
    return set(r[CONFIRM_SHA_COLUMN] for r in fresh if is_closed(r[CONFIRM_COLUMN]))


def pending_warnings(outdir):
    """人工確認表裡還沒回覆的警告列數（人工待辦用）。"""
    rows = _read_confirmations(locate(outdir, CONFIRM_FILE)[0])
    return sum(1 for r in rows if _s(r.get("類別")) == WARNING_KIND and not is_closed(r.get(CONFIRM_COLUMN)))


def pending_confirmations(outdir):
    """人工確認.csv（舊資料夾是 異動確認.csv）裡還沒填「人工確認」的列（finalize 用，會擋「改好」）。

    只算這一輪的：異動與條文檢查的指紋對不上現在的異動清單／條文檢查（重跑 compare 之後
    留下的上一輪）不算。回傳的每一筆長得跟決定表列一樣（候選段次／來源／候選全文），
    驗收報告照同一個格式列。"""
    rows = _read_confirmations(locate(outdir, CONFIRM_FILE)[0])
    if not rows:
        rows = _read_confirmations(locate(outdir, LEGACY_CONFIRM_FILE)[0])
    if not rows:
        return []
    current = {}
    changes_path = locate(outdir, "異動清單.json")[0]
    if os.path.isfile(changes_path):
        with io.open(changes_path, encoding="utf-8") as f:
            current["異動"] = set(rp.change_sha256(ch) for ch in json.load(f))
    checks = rp.rulecheck_items(outdir)
    if checks is not None:
        current["條文檢查"] = set(item["sha"] for item in checks)
    pending = []
    for row in rows:
        kind, _, sha = _row_key(row).partition(":")
        if kind == WARNING_KIND:
            continue                  # 警告另外算（sync_warnings），不擋三問，只擋「改好」那一句
        if kind in current and sha not in current[kind]:
            continue
        answer = _s(row.get(CONFIRM_COLUMN))
        if is_closed(answer):
            continue
        rid = _s(row.get("確認ID")) or _s(row.get("異動ID"))
        note = ("；寫了「%s」，處理好之後改成「已確認」" % answer) if answer else ""
        pending.append({"候選段次": _s(row.get("段次")) or _s(row.get("新版段次")),
                        "來源": "%s：AI %s（%s）%s" % (kind or "異動", _s(row.get("AI判斷")), rid, note),
                        "候選全文": _s(row.get("內容")) or _s(row.get("異動內容"))})
    return pending
