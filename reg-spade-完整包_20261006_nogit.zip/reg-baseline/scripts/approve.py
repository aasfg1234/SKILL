# -*- coding: utf-8 -*-
"""
批次核准：人下一次指令，把決定表裡「AI 建議很明確」的列一次決定掉，不用逐列打字。

規章內容改不改一律由人決定——這支程式不是替人決定，是**人照一條規則一次核准一整類**，
而且每一列都在「核准方式」欄記下是照哪一條規則核准的，事後查得到。人已經填過決定的列不動。

兩種規則：
    照建議改（要改嗎＝改、改成什麼＝建議改法）
        來源全部是機械性的（章節引用、條文引用、跨本引用、外部引用）而且建議改法已經寫好：
            號碼換號、母法條號過時這種，程式照位置換好了，沒有要判斷的內容
        或 AI 的評分標籤是〔引用換號〕〔同義務舊值〕、判「建議修改」，而且建議改法已經寫好
    不改
        AI 判「不用改」、評分標籤是〔套語命中〕〔無關〕（0–1 分：只因共同套語被抓到、或根本無關）
剩下的（中間地帶、沒有建議改法、要判斷的）留給人。規則可以用 --改／--不改 換。
異動內容裡有任何一處引用是危險（指到的地方這次刪掉了），整列一律留給人，不管哪一條規則。
"""

import datetime
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import scoring_rubric as sr

# 只要來源全落在這幾種、建議改法又寫好了，就是機械性的換號／改號
# 條文引用（Step 0.5 的條、款、項引用）跟章節引用同一類：需改寫的建議改法是照位置換號，
# 異動內容尾巴是「（條號換號）」「（款號換號）」；危險、內容變了、定義連動沒有建議改法，進不來
MECHANICAL_SOURCES = ("章節引用", "條文引用", "跨本引用", "外部引用")
DEFAULT_CHANGE = ("章節引用", "條文引用", "跨本引用", "外部引用", "引用換號", "同義務舊值")
# 異動內容裡這幾種字樣＝有一處引用指到的地方刪掉了（decision_table.DANGER_MARK、
# row_assist 章節引用、batch 跨本引用的說法）：意思已經變了，沒有機械式的改法
DANGER_HINTS = ("【危險】", "指到的地方這次刪掉了", "這次刪掉了")
DEFAULT_KEEP = ("套語命中", "無關")
COLUMN = "核准方式"


def _sources(row):
    return [s for s in (row.get("來源") or "").split("；") if s]


def _mechanical_change(row):
    """建議改法是不是照位置換號、或換成查證過的外部引用寫出來的（異動內容尾巴有程式的標記：
    「（章節換號）」「（招攬作業要點換號）」「（外部引用〔引用過時〕）」）。
    跨本引用「內容改了」那種列（被引用的那一點改了三日→五日）也有建議改法，但那是要判斷的，不算。"""
    pieces = [p.strip() for p in (row.get("異動內容") or "").split("；") if p.strip()]
    return bool(pieces) and all(p.endswith("換號）") or "（外部引用〔" in p for p in pieces)


def rule_for(row, change_rules=DEFAULT_CHANGE, keep_rules=DEFAULT_KEEP):
    """這一列照哪一條規則核准：("改", 規則) / ("不改", 規則) / None（留給人）。人已經決定的列回 None。"""
    if (row.get("要改嗎") or "").strip():
        return None
    if any(hint in (row.get("異動內容") or "") for hint in DANGER_HINTS):
        return None          # 危險列不准批次核准（改也不行、不改也不行），一定要人看
    suggestion = (row.get("建議改法") or "").strip()
    label = sr.label_in(row.get("AI理由") or "")
    verdict = (row.get("AI判斷") or "").strip()
    sources = _sources(row)
    if suggestion and sources and all(s in MECHANICAL_SOURCES for s in sources) and _mechanical_change(row):
        matched = [s for s in sources if s in change_rules]
        if matched and len(matched) == len(sources):
            return "改", "機械性換號（%s）" % "、".join(matched)
    if suggestion and verdict == "建議修改" and label in change_rules:
        return "改", "AI〔%s〕" % label
    if verdict == "不用改" and label in keep_rules:
        return "不改", "AI〔%s〕" % label
    return None


def approve(rows, change_rules=DEFAULT_CHANGE, keep_rules=DEFAULT_KEEP, apply=True):
    """照規則核准。回傳 {"改": [...], "不改": [...], "留給人": 還沒決定的列數}（每一筆是 (列, 規則)）。
    apply=False 只算不改（預覽）。"""
    done = {"改": [], "不改": []}
    for row in rows:
        decision = rule_for(row, change_rules, keep_rules)
        if not decision:
            continue
        action, rule = decision
        done[action].append((row, rule))
        if apply:
            row["要改嗎"] = action
            if action == "改":
                row["改成什麼"] = row["建議改法"]
            row[COLUMN] = "依 AI 建議批次核准：%s" % rule
    done["留給人"] = sum(1 for row in rows if not (row.get("要改嗎") or "").strip()) - (
        0 if apply else len(done["改"]) + len(done["不改"]))
    return done


def parse_rules(text, default):
    if text is None:
        return default
    return tuple(x.strip() for x in text.replace("，", ",").replace("、", ",").split(",") if x.strip())


PREVIEW_FILE = "核准預覽.txt"


def result_lines(name, done):
    """一本照規則會怎麼決定（核准畫面與 核准預覽.txt 共用同一個格式）。"""
    lines = ["%s照建議改 %d 列、不改 %d 列；還要人決定 %d 列"
             % ("%s：" % name if name else "", len(done["改"]), len(done["不改"]), done["留給人"])]
    for action in ("改", "不改"):
        for row, rule in done[action]:
            what = (row.get("異動內容") or "").strip()
            lines.append("    段次 %s　%s　%s　%s%s" % (
                row.get("候選段次") or "-", action, rule, (row.get("候選全文") or "")[:24],
                "（%s）" % what[:40] if action == "改" and what else ""))
    return lines


def write_preview(path, tables, command):
    """人工待辦用：把「核准會怎麼決定」寫成 核准預覽.txt（決定表不動）。tables：[(規章名, 列 list)]。
    回傳 (改, 不改) 列數；一列都沒有就把舊的預覽拿掉、回傳 (0, 0)。command：印給人看的核准指令。"""
    blocks, total = [], {"改": 0, "不改": 0}
    for name, rows in tables:
        done = approve(rows, apply=False)
        if not (done["改"] or done["不改"]):
            continue
        total["改"] += len(done["改"])
        total["不改"] += len(done["不改"])
        blocks += result_lines(name, done) + [""]
    if not blocks:
        if os.path.isfile(path):
            os.remove(path)
        return 0, 0
    lines = ["核准預覽（%s）" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "",
             "AI 建議很明確的列照規則會這樣決定（決定表還沒動）：照建議改 %d 列、不改 %d 列。"
             % (total["改"], total["不改"]),
             "使用者看過、說好，才跑：%s（每一列「核准方式」欄會記下規則；人已經填的列不動）" % command,
             "規則：照建議改＝%s；不改＝%s" % ("、".join(DEFAULT_CHANGE), "、".join(DEFAULT_KEEP)), ""]
    with io.open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines + blocks))
    return total["改"], total["不改"]
