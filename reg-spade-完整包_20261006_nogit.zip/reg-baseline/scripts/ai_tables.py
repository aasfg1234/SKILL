# -*- coding: utf-8 -*-
"""
批次的 AI 表：每一種一張、全部規章合在一起（第一欄是規章），放 產出/系統檔案/AI審查/。

以前 AI 要到 產出/系統檔案/<規章名>/填寫表單/ 逐本填四張表：二十本就是八十個檔，漏一本整批退件。
現在 batch-review-pack 逐本寫完之後合成四張，另寫一份 先讀我.md（這一批要讀哪幾份審查包、
四張表各有幾列要填）。AI 只填這四張。

程式內部照舊一本一份（review-import 的驗證、指紋、報告都靠各本那一份）。合一表寫回各本時
只寫 AI 這次改過的格：打包當時每一列的答案記在 合一表紀錄.json，跟那時候不一樣的格才算 AI 填的。
所以 AI 照舊直接填各本那一份也照樣算——合一表沒動，就不會去蓋各本。
"""

import csv
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import SYSTEM_DIR, locate, open_csv

FOLDER = "AI審查"
BOOK = "規章"
INDEX = "先讀我.md"
RECORD = "合一表紀錄.json"
NEW_ID = "新增"
REUSED = "沿用查證"
# (檔名, 編號欄, AI 填的欄)
SPECS = (
    ("AI候選判斷.csv", "列ID", ("AI判斷", "AI分數", "AI理由")),
    ("AI異動審查.csv", "異動ID", ("AI判斷", "AI分數", "AI理由", "查證來源")),
    ("AI條文檢查.csv", "檢查ID", ("AI判斷", "AI理由", "查證來源")),
    ("AI外部引用.csv", "引用ID", ("AI判斷", "AI理由", "AI更正", "查證來源", "類別")),
)
# 每一本要讀的審查資料（在 產出/系統檔案/<規章名>/系統檔案/）
PACK_FILES = ("LLM審查包_*.md", "LLM異動清單.md", "LLM條文檢查清單.md", "LLM外部引用清單.md")


def folder(root):
    return os.path.join(root, SYSTEM_DIR, FOLDER)


def _s(value):
    return "" if value is None else str(value).strip()


def _read(path):
    with open_csv(path) as f:
        reader = csv.DictReader(f)
        return list(reader.fieldnames or []), list(reader)


def _write(path, fields, rows):
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(fields)
        for row in rows:
            writer.writerow([row.get(c, "") for c in fields])
    os.replace(tmp, path)


def _key(book, rid):
    return "%s\x00%s" % (book, rid)


def _answers(row, columns):
    return dict((c, _s(row.get(c))) for c in columns)


def _fingerprint(row, columns):
    """一列「AI 不填的欄」的指紋：寫回時拿來確認各本那一列還是打包時的同一列（A11）。"""
    import hashlib
    skip = set(columns) | {BOOK}
    # 空欄不算：合一表的欄是各本欄位的聯集，某一本沒有的欄讀回來是空字串
    text = "\x1f".join("%s=%s" % (k, _s(v)) for k, v in sorted(row.items()) if k and k not in skip and _s(v))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def merge(root, books):
    """batch-review-pack 逐本寫完之後呼叫：各本的四張 AI 表合成四張放 AI審查/，
    記下打包當時的答案（合一表紀錄.json），寫 先讀我.md。回傳 {檔名: (列數, 還沒填的列數)}。"""
    import glob
    out = folder(root)
    os.makedirs(out, exist_ok=True)
    record, counts = {}, {}
    for filename, id_col, columns in SPECS:
        fields, merged, answers, new_rows, prints = [], [], {}, {}, {}
        for name, outdir_doc in books:
            path = locate(outdir_doc, filename)[0]
            if not os.path.isfile(path):
                continue
            book_fields, rows = _read(path)
            for c in book_fields:
                if c not in fields:
                    fields.append(c)
            for row in rows:
                rid = _s(row.get(id_col))
                merged.append(dict(row, **{BOOK: name}))
                if rid == NEW_ID:
                    new_rows.setdefault(name, []).append(dict(row))
                elif rid:
                    answers[_key(name, rid)] = _answers(row, columns)
                    prints[_key(name, rid)] = _fingerprint(row, columns)
        path = os.path.join(out, filename)
        if not fields:
            if os.path.isfile(path):
                os.remove(path)          # 這一批沒有這種表：不留上一次的
            continue
        _write(path, [BOOK] + fields, merged)
        record[filename] = {"列": answers, "新增": new_rows, "指紋": prints}
        waiting = sum(1 for r in merged if not _s(r.get(REUSED)) and not _s(r.get("AI判斷")))
        counts[filename] = (len(merged), waiting)
    with io.open(os.path.join(out, RECORD), "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False)
    lines = ["# AI 審查：這一批要做的事", "",
             "只填這個資料夾的四張表（第一欄是規章；「沿用查證」有值的列程式已經填好，不用管）。",
             "打分照每份審查包開頭的評分標準；外部引用、條文檢查要上網查證，查證來源填實際打開的網址。",
             "填完回到 reg-report 的 skill 資料夾（有 scripts/ 的那一層）跑 `python scripts/run_all.py 繼續 --到報告`"
             "（或 審查匯入）。", "",
             "## 四張表", ""]
    for filename, _, _ in SPECS:
        if filename in counts:
            total, waiting = counts[filename]
            lines.append("- `%s`：%d 列，要填 %d 列" % (filename, total, waiting))
    lines += ["", "## 每一本要讀的審查資料", ""]
    for name, outdir_doc in books:
        system = os.path.join(outdir_doc, SYSTEM_DIR)
        found = []
        for pattern in PACK_FILES:
            found += sorted(os.path.basename(p) for p in glob.glob(os.path.join(system, pattern)))
        rel = "產出/%s/%s/%s/" % (SYSTEM_DIR, name, SYSTEM_DIR)
        lines.append("- %s：%s" % (name, "、".join("`%s%s`" % (rel, f) for f in found) or "（沒有）"))
    with io.open(os.path.join(out, INDEX), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return counts


def _plain(row):
    return dict((k, _s(v)) for k, v in row.items() if k != BOOK)


def split(root, books):
    """合一表上 AI 改過的格寫回各本（batch-review-pack 重新打包前、batch-review-import 驗證前呼叫）。
    回傳 (錯誤 list, {規章: 寫回的格數}, 提醒 list)；有錯誤就一格都不寫。
    沒有合一表（還沒打包、或不是這一版打包的）回 ([], {}, [])。
    打包時有、這次不在 books 裡的本（產出不完整被略過）：AI 沒動的列不管；AI 填過的列講一聲、先不寫回。"""
    out = folder(root)
    record_path = os.path.join(out, RECORD)
    if not os.path.isfile(record_path):
        return [], {}, []
    with io.open(record_path, encoding="utf-8") as f:
        record = json.load(f)
    known = dict(books)
    errors, plans, notes = [], [], []
    for filename, id_col, columns in SPECS:
        path = os.path.join(out, filename)
        if filename not in record or not os.path.isfile(path):
            continue
        before = record[filename]
        try:
            _, rows = _read(path)
        except (OSError, UnicodeDecodeError, csv.Error, ValueError) as exc:
            errors.append("%s/%s 讀不出來：%s" % (FOLDER, filename, exc))
            continue
        changes, new_rows, seen = {}, {}, set()
        recorded = set(k.split("\x00")[0] for k in before["列"]) | set(before["新增"])
        for line, row in enumerate(rows, 2):
            book, rid = _s(row.get(BOOK)), _s(row.get(id_col))
            if not book and not rid:
                continue
            tag = "%s/%s 第 %d 列（%s %s）" % (FOLDER, filename, line, book or "沒寫規章", rid or "沒有編號")
            if book not in known:
                if book not in recorded:
                    errors.append("%s：規章「%s」不在這一批" % (tag, book))
                    continue
                old = before["列"].get(_key(book, rid))
                touched = (_plain(row) not in [_plain(r) for r in before["新增"].get(book, [])] if rid == NEW_ID
                           else old is None or any(_s(row.get(c)) != old.get(c, "") for c in columns))
                if touched:
                    notes.append("%s：%s 這次沒有進批次（產出不完整？），AI 填的這一列先沒寫回" % (tag, book))
                continue
            if rid == NEW_ID:
                new_rows.setdefault(book, []).append(dict((k, v) for k, v in row.items() if k != BOOK))
                continue
            old = before["列"].get(_key(book, rid))
            if old is None:
                errors.append("%s：這一本打包時沒有這一列（編號不要改）" % tag)
                continue
            if (book, rid) in seen:
                errors.append("%s：同一列出現兩次" % tag)
                continue
            seen.add((book, rid))
            fingerprint = before.get("指紋", {}).get(_key(book, rid))
            if fingerprint and _fingerprint(row, columns) != fingerprint:
                errors.append("%s：AI 不該動的欄（全文、段次、編號…）被改過了；只填 %s"
                              % (tag, "、".join(columns)))
                continue
            cells = dict((c, _s(row.get(c))) for c in columns if _s(row.get(c)) != old.get(c, ""))
            if cells:
                changes.setdefault(book, {})[rid] = cells
        for book in sorted((set(changes) | set(new_rows) | set(before["新增"])) & set(known)):
            merged_new = new_rows.get(book, [])
            new_changed = ([dict((k, _s(v)) for k, v in r.items()) for r in merged_new]
                           != [dict((k, _s(v)) for k, v in r.items()) for r in before["新增"].get(book, [])])
            if not changes.get(book) and not new_changed:
                continue
            book_path = locate(known[book], filename)[0]
            if not os.path.isfile(book_path):
                errors.append("%s：找不到 %s 的 %s" % (FOLDER, book, filename))
                continue
            # 各本那一張在打包之後變過（例如語意併入後重寫，列ID 位移）：照列ID 寫回會把答案
            # 掛到別的候選上，review-import 也驗不出來（A11）。這時候不寫，請重新打包
            prints = before.get("指紋", {})
            if prints and changes.get(book):
                try:
                    _, current = _read(book_path)
                except (OSError, UnicodeDecodeError, csv.Error, ValueError) as exc:
                    errors.append("%s 的 %s 讀不出來：%s" % (book, filename, exc))
                    continue
                now = dict((_s(r.get(id_col)), _fingerprint(r, columns)) for r in current)
                moved = [rid for rid in changes[book] if prints.get(_key(book, rid)) not in (None, now.get(rid))]
                if moved:
                    errors.append("%s 的 %s 在打包之後變過（%s 已經不是打包時的那一列）：AI 的答案不能照編號寫回，"
                                  "請重跑 審查打包（batch-review-pack），AI 照新的表再填"
                                  % (book, filename, "、".join(moved[:5])))
                    continue
            plans.append((book, book_path, id_col, changes.get(book, {}), merged_new if new_changed else None))
    if errors:
        return errors, {}, notes          # 有錯就一格都不寫：不留一半寫回、一半沒寫的各本
    written = {}
    for book, book_path, id_col, cells_by_id, merged_new in plans:
        fields, book_rows = _read(book_path)
        count = 0
        for row in book_rows:
            cells = cells_by_id.get(_s(row.get(id_col)))
            if cells:
                row.update(cells)
                count += len(cells)
        if merged_new is not None:
            book_rows = [r for r in book_rows if _s(r.get(id_col)) != NEW_ID] + merged_new
            count += len(merged_new)
        _write(book_path, fields, book_rows)
        written[book] = written.get(book, 0) + count
    return errors, written, notes


def unanswered(books):
    """各本的四張 AI 表還有幾列沒填「AI判斷」（程式先填好的「沿用查證」列不算）：{檔名: 列數}，只列有缺的。"""
    missing = {}
    for filename, _, _ in SPECS:
        for _, outdir_doc in books:
            path = locate(outdir_doc, filename)[0]
            if not os.path.isfile(path):
                continue
            try:
                _, rows = _read(path)
            except (OSError, UnicodeDecodeError, csv.Error, ValueError):
                continue
            count = sum(1 for r in rows if not _s(r.get(REUSED)) and not _s(r.get("AI判斷")))
            if count:
                missing[filename] = missing.get(filename, 0) + count
    return missing
