# -*- coding: utf-8 -*-
r"""
S8：抓出條文裡面的引用

用法：
    py S8_抓引用.py <資料夾>

輸入：<資料夾>\06_final.csv        （沒有就退而用 05_flagged.csv）
      tables\S8_外部規章表.csv        （可以自己加，加完重跑就生效）
輸出：<資料夾>\08_citations.csv
      <資料夾>\S8_引用報告.txt

它在找什麼
    一條規定裡面，常常寫「依本節第一條」「依保險法第一百十二條」。
    法規變動時，這些引用會連帶失效或指錯地方。
    這一階段把每一條的引用全部挑出來，並盡量指出它指到哪裡。

分兩種
    規章內引用：指到本篇自己的其他地方
        本章 本節 本篇 本條 本項 本款
        前條 前項 前款 前目 前點 前述
        第X章  第X節  本節第X條  本章第X條
    規章外引用：指到本篇以外的東西
        法律、主管機關法規、本行其他內規
        會一併抓出條號，例如「保險法第一百十二條」

輸出欄位
    規章內引用(Y/N)、引用ID、內引用原文
    規章外引用(Y/N)、規章名、條號、外引用原文

這一階段不改任何文字。
"""

import csv
import io
import os
import re
import sys
import collections

TABLES = os.path.normpath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", "tables"))

CN = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5,
      "六": 6, "七": 7, "八": 8, "九": 9, "十": 10, "零": 0, "〇": 0, "兩": 2}

OUT_COLS = ["條文ID", "章標題", "節標題", "符號原文",
            "規章內引用", "引用ID", "內引用原文",
            "規章外引用", "規章名", "條號", "外引用原文",
            "字數", "全文"]

lines = []


def say(s=""):
    lines.append(s)


def cn2int(s):
    """中文數字轉阿拉伯數字。認到「一百十二」這種。"""
    s = s.strip()
    if not s:
        return None
    if s.isdigit():
        return int(s)
    total, section, num = 0, 0, 0
    for ch in s:
        if ch == "千":
            section = (num or 1) * 1000
            num = 0
        elif ch == "百":
            section += (num or 1) * 100
            num = 0
        elif ch == "十":
            section += (num or 1) * 10
            num = 0
        elif ch in CN:
            num = CN[ch]
        else:
            return None
    return total + section + num


# ------------------------------------------------------------------
def load_regs(path):
    """讀外部規章表，長的名字排前面，避免「個資法」被「保險法」搶走。"""
    if not os.path.isfile(path):
        return []
    out = []
    with io.open(path, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            nm = (r.get("規章名") or "").strip()
            if nm:
                out.append((nm, (r.get("類別") or "").strip()))
    out.sort(key=lambda x: -len(x[0]))
    return out


# 零、千、兩也要收（「第一百零七條」以前抓不到，B25）
NUM = r"[0-9０-９零〇一二三四五六七八九十百千兩]{1,8}"

# 條號：接在規章名後面的那一串；「之一」的一可以是國字（以前只收阿拉伯數字，「之一」被丟掉）
ART = re.compile(r"^[」』》】\"'\s]*第\s*(" + NUM + r"(?:\s*[-之]\s*" + NUM + r")?)\s*(條|項|款|目|點)"
                 r"(?:\s*之\s*(" + NUM + r"))?")

# 手冊常用「參、第一章……第四節……」而不是法規的「第 N 條」。
OUTLINE = re.compile(
    r"^[」』》】\"'\s_]*(?P<part>[壹貳參肆伍陸柒捌玖拾]+)[、，]\s*"
    r"第\s*(?P<chapter>[一二三四五六七八九十]{1,3})\s*章"
    r"[^，。；]{0,30}?[、，]?\s*第\s*(?P<section>[一二三四五六七八九十]{1,3})\s*節")

# 法規名稱的字尾。長的排前面，「施行細則」「自律規範」才不會只被認成「細則」「規範」。
# 跟 regdiff/_common._LAW_SUFFIX 同一份（兩條管線不互相 import，各寫一份）
LAW_SUFFIX = r"(?:自律規範|注意事項|施行細則|條例|辦法|準則|規則|細則|要點|規範|法)"

# 規章外：沒有登錄在表裡，但長得就像法規名的。
# 名稱上限 40 字：以前 14 字，「中華民國人壽保險商業同業公會保險業招攬廣告自律規範」
# 被截成「險商業同業公會…」；「細則」「規範」以前不在字尾裡，「保險法施行細則第五條」整筆漏掉。
# 名稱跟條號中間可以隔引號：「保險業招攬及核保理賠辦法」第六條。
# 抓到的那一段從句子開頭算起，前面黏著的「業務員應依照」由 clean_name 剝掉
# （以前沒剝，規章名欄寫成「依據本公司依保險法」，精確度只有四成）。
GENERIC = re.compile(r"([一-鿿]{2,40}?" + LAW_SUFFIX + r")[」』》】\"'\s]*第\s*(" + NUM + r")\s*"
                     r"(條之" + NUM + r"|條|點)")

# 同一部規章的第二個以後的條號：「保險法第一百四十六條、第一百四十六條之一」。
# 只收「條」「點」：「第一項及第二項」是同一條裡的項，不是另一處引用。
MORE = re.compile(r"^\s*[、及或與和至]\s*第\s*(" + NUM + r")\s*(條|點)(?:\s*之\s*(" + NUM + r"))?")

# 「及同法第一百四十六條之一」「該法第五條」：指前面那一部規章
SAME_LAW = re.compile(r"[同該](?:法|條例|辦法|準則|規則|細則|要點|規範)(?=[」』\s]*第)")
SAME_LAW_NAME = re.compile(r"^[同該]" + LAW_SUFFIX + r"$")
# 「共同法」「不同法」不是指前一部
SAME_LAW_NOT_AFTER = "共不相協等"

# ------------------------------------------------------------------
# 名稱前面黏到的字怎麼剝。規則跟 regdiff/_common.clean_law_name 同一套
# （兩條管線不互相 import，各寫一份；改一邊要記得改另一邊）。
# 從最右邊的提示詞後面切：「業務員應依照保險業務員管理規則」→「保險業務員管理規則」
_CUES = ("依據", "依照", "依循", "另依", "按照", "參照", "準用", "適用",
         "所定", "所稱", "規定", "符合", "牴觸", "抵觸", "遵循", "違反",
         "遵守", "配合", "比照", "參酌", "悉依", "違背")
# 單字的動詞、介詞：出現在名稱中間就代表前面是句子。「準」「自」不列（內部控制準則、自律規範）
_LEADERS = "依按照本第凡"
# 連接詞只有在最開頭才切：「保險業招攬及核保理賠辦法」本身就含「及」
_CONJ = "及與暨和或、，,"
_DEBRIS = re.compile(r"^[0-9０-９零〇一二三四五六七八九十百千兩]*[條項款目章節][及與暨和或、，,]?")
# 「業務員有保險業務員管理規則」：「有」前面至少兩個字、後面至少四個字才切（國有財產法不切）
_HAVE = re.compile(r"^.{2,}有(.{4,})$")
# 「個人資料保護法及金融消費者保護法」：連接詞前面剛好是字尾才切，後面是其／同／該的不切
_LISTED = re.compile(r"^.*(?:自律規範|注意事項|條例|辦法|準則|規則|細則|要點|規範|法)[及與暨和或、]"
                     r"((?![其同該]).{2,})$")
_TAIL = re.compile(r"[一-鿿（）()]{1,40}" + LAW_SUFFIX + r"$")
_NOT_NAMES = frozenset(("法", "條例", "辦法", "準則", "規則", "細則", "施行細則", "要點", "規範",
                        "注意事項", "自律規範"))
_NOT_TAILS = ("依法", "合法", "違法", "守法", "非法", "不法", "無法", "立法", "司法",
              "執法", "方法", "做法", "作法", "用法", "說法", "看法", "想法", "此法",
              "如法", "設法", "效法", "手法", "打法", "唱法", "療法")
_TAIL_EXCEPTIONS = ("公司法", "醫療法")
# 登錄的短名稱是長名稱的結尾（保險法之於全民健康保險法）時，多出來的前綴不能有這些字
_PREFIX_JUNK = frozenset("應有之的為時者係須於並且其該各及與暨和或、，,")


def _strip_name(trimmed):
    """剝掉名稱前面黏到的動詞、連接詞、主詞。剝完不像規章名稱回空字串。"""
    cut = 0
    for cue in _CUES:
        pos = trimmed.rfind(cue)
        if pos >= 0:
            cut = max(cut, pos + len(cue))
    leaders = [i for i, ch in enumerate(trimmed) if ch in _LEADERS]
    if leaders:
        cut = max(cut, leaders[-1] + 1)
    trimmed = trimmed[cut:]
    have = _HAVE.match(trimmed)
    if have:
        trimmed = have.group(1)
    trimmed = _DEBRIS.sub("", trimmed)
    while trimmed and trimmed[0] in _CONJ:
        trimmed = trimmed[1:]
    listed = _LISTED.match(trimmed)
    if listed:
        trimmed = listed.group(1)
    match = _TAIL.search(trimmed)
    if not match:
        return ""
    trimmed = match.group(0)
    if trimmed in _NOT_NAMES:
        return ""
    if trimmed.endswith(_NOT_TAILS) and not trimmed.endswith(_TAIL_EXCEPTIONS):
        return ""
    if re.match(r"^本" + LAW_SUFFIX + r"$", trimmed):
        return ""
    return trimmed


def clean_name(raw, regs=()):
    """抓到的那一段修成規章名稱；不是規章名稱回空字串。

    外部規章表的名字優先：抓到的那一段結尾是登錄名稱就用登錄的。例外是剝出來的名稱更長、
    又以登錄名稱結尾、多出來的前綴像名稱的一部分（全民健康保險法、所得稅法）——
    以前登錄的「保險法」「稅法」直接搶走，表上寫成另一部法（最長比對）。"""
    trimmed = re.sub(r"\s+", "", raw or "")
    stripped = _strip_name(trimmed)
    for nm, _ in regs:
        if not trimmed.endswith(nm):
            continue
        prefix = stripped[:-len(nm)] if stripped.endswith(nm) else ""
        before = trimmed[:len(trimmed) - len(stripped)]
        if len(prefix) >= 2 and not (set(prefix) & _PREFIX_JUNK) and not before.endswith("本"):
            return stripped
        return nm
    return stripped


def _articles_at(text, pos):
    """text[pos:] 開頭的條號（含後面接著的第X項第X款）：(條號, 結束位置)；沒有回 ("", pos)。"""
    m = ART.match(text[pos:])
    if not m:
        return "", pos
    art = "第%s%s" % (re.sub(r"\s+", "", m.group(1)), m.group(2))
    if m.group(3):
        art += "之%s" % m.group(3)       # 第一百零七條之一
    end = pos + m.end()
    # 後面還接著第X項第X款就一起收
    while True:
        m2 = ART.match(text[end:])
        if not m2:
            break
        art += "第%s%s" % (re.sub(r"\s+", "", m2.group(1)), m2.group(2))
        if m2.group(3):
            art += "之%s" % m2.group(3)
        end += m2.end()
    return art, end


def _more_articles(text, end):
    """「、第一百四十六條之一」「及第十八條」：同一部規章後面接著的條號。[(起, 條號, 訖)]"""
    out = []
    while True:
        m = MORE.match(text[end:])
        if not m:
            break
        start = end + m.group(0).index("第")
        art = "第%s%s" % (re.sub(r"\s+", "", m.group(1)), m.group(2))
        if m.group(3):
            art += "之%s" % m.group(3)
        rest, stop = _articles_at(text, end + m.end())
        if rest:
            art += rest                         # 「第十八條第二項」的「第二項」
        end = stop if rest else end + m.end()
        out.append((start, art, end))
    return out
# 「本辦法」「本要點」是這一份自己，不是別人家的規章（B25）。
# 「本作業要點」「本管理辦法」「本實施細則」也是自己：「本」跟字尾中間可以夾 0～6 個字。
# 以前只認直接相接，這幾種被列成「作業要點（未登錄）」這種外部法規，本文引用也漏收。
# 規則跟 regdiff/_common._OWN_LAW_NAME 同一套（兩條管線不互相 import，各寫一份）：
#   「本公司」「本行」「本國」開頭的是別本（「本行為準則」除外）；
#   「本」前一個字要是邊界——「資本適足性管理辦法」「基本法」的「本」是詞的一部分；
#   中間不能夾提示詞、連接詞、條項款或另一個字尾的字（「本要點依保險法」是保險法）；
#   只有一個字尾「法」的只認「本法」（「本案作法」不是法規）。
_SELF_LEADS = "依按照據循用定稱合觸遵反守酌悉背及與暨和或並且另凡由於在經如對即為從之至"
_SELF_STOPS = "依按照據及與暨和或並之所第法則點例範條項款"
SELF_NAME = re.compile(
    r"(?:^|(?<=[^一-鿿])|(?<=[%s]))本(?!公司|行(?!為)|國)"
    r"(?:法|(?:(?![%s])[一-鿿]){0,6}?"
    r"(?:條例|規則|辦法|準則|要點|注意事項|自律規範|手冊|規章|細則))$" % (_SELF_LEADS, _SELF_STOPS))
# 規章內：單獨寫的「第三條」「第五條之一」（前面沒有別的規章名）
IN_ART_ANY = re.compile(r"第\s*(" + NUM + r")\s*條(?:\s*之\s*(" + NUM + r"))?")
# 「保險法第一百四十六條、第一百四十六條之一」的第二個條號：前面是「規章名＋條號＋連接詞」。
# 規章名要另外判是不是自己（「依本辦法第三條、第五條」的第五條是本文的）
AFTER_EXTERNAL = re.compile(r"([一-鿿]{1,40}?" + LAW_SUFFIX + r")[」』\s]*第\s*" + NUM
                            + r"\s*(?:條(?:\s*之\s*" + NUM + r")?|點)"
                            r"(?:\s*第\s*" + NUM + r"\s*[項款目])*\s*[、及或與和至]\s*$")

# 規章內：相對指涉
REL = ["前條", "前項", "前款", "前目", "前點", "前述",
       "本條", "本項", "本款", "本章", "本節", "本篇"]

# 規章內：第X章 / 第X節 / 本節第X條
IN_CH = re.compile(r"第\s*([一二三四五六七八九十]{1,3})\s*章")
IN_SE = re.compile(r"第\s*([一二三四五六七八九十]{1,3})\s*節")
IN_ART = re.compile(r"(本節|本章)\s*第\s*([一二三四五六七八九十]{1,3})\s*條")


def find_external(text, regs):
    """回傳 [(規章名, 條號, 原文片段), ...]。"""
    hits = []
    used = []          # 已被吃掉的區段，避免重複認
    reg_names = set(nm for nm, _ in regs)

    def add_more(nm, end):
        """同一部後面接著的第二個以後的條號，一個條號一筆。"""
        for s, art, e in _more_articles(text, end):
            used.append((s, e))
            hits.append((s, nm, art, text[max(0, s - 8):e + 6]))

    # 一、先掃長得像規章全銜、後面帶條號的（不管有沒有登錄），名稱剝乾淨。
    #     剝出來比登錄名稱長、又包含登錄名稱的（全民健康保險法、保險法施行細則）以它為準：
    #     以前登錄表先比，「保險法」先搶走那三個字，長名稱整個漏掉、條號也掛錯法
    generic = []
    for m in GENERIC.finditer(text):
        # 「依本辦法第三條」：本辦法是自己，這是規章內引用，不是未登錄的外部法規
        if SELF_NAME.search(m.group(1)):
            continue
        name = clean_name(m.group(1), regs)
        if not name or SAME_LAW_NAME.match(name):
            continue
        generic.append((m.end(1) - len(name), name, m))
    longer = [(s, s + len(name)) for s, name, _ in generic
              if name not in reg_names and any(nm in name for nm in reg_names)]

    for nm, cat in regs:
        start = 0
        while True:
            i = text.find(nm, start)
            if i < 0:
                break
            start = i + len(nm)
            if any(a <= i < b for a, b in used):
                continue
            if any(a <= i and i + len(nm) <= b for a, b in longer):
                continue                     # 是更長一部法（未登錄）的一部分
            art, end = _articles_at(text, i + len(nm))
            if not art:
                outline = OUTLINE.match(text[i + len(nm):])
                if outline:
                    art = "%s、第%s章、第%s節" % (
                        outline.group("part"), outline.group("chapter"),
                        outline.group("section"))
                    end = i + len(nm) + outline.end()
            used.append((i, end))
            hits.append((i, nm, art, text[max(0, i - 8):end + 6]))
            if art.startswith("第"):
                add_more(nm, end)

    # 二、表裡沒登錄，但長得像法規名又帶條號的
    for i, name, m in generic:
        if name in reg_names:
            continue                         # 登錄過的，上面已經照登錄的名字收了
        if any(i < b and a < m.end() for a, b in used):
            continue                         # 跟已登錄的規章重疊
        used.append((i, m.end()))
        hits.append((i, name + "（未登錄）", "第%s%s" % (m.group(2), m.group(3)),
                     text[max(0, i - 8):m.end() + 6]))
        add_more(name + "（未登錄）", m.end())

    # 三、「同法第X條」「該法第X條」：指前面最近的那一部
    for m in SAME_LAW.finditer(text):
        i = m.start()
        if any(a <= i < b for a, b in used) or text[i - 1:i] in tuple(SAME_LAW_NOT_AFTER):
            continue
        previous = [h for h in hits if h[0] < i and h[2].startswith("第")]
        art, end = _articles_at(text, m.end())
        if not previous or not art:
            continue
        nm = max(previous, key=lambda h: h[0])[1]
        used.append((i, end))
        hits.append((i, nm, art, text[max(0, i - 8):end + 6]))
        add_more(nm, end)
    hits.sort(key=lambda x: x[0])
    return [(a, b, c) for _, a, b, c in hits]


NEAR = 45          # 往前看幾個字，判斷這個「第X章」是不是別人家的


def belongs_outside(text, i, regs):
    """這個第X章、第X節，前面不遠處有沒有別的規章名或手冊。

    有的話代表它指的是那本規章的章節，不是本篇的章節。
    例如「防制洗錢中心作業手冊中之第一章」。
    """
    win = text[max(0, i - NEAR):i]
    if any(nm in win for nm, _ in regs):
        return True
    # 沒登錄的手冊也要擋，例如「作業處作業手冊共同篇\第一章…」
    if re.search(r"(手冊|辦法|規則|準則|要點|規範|注意事項)[^，。；]{0,12}$", win):
        return True
    return False


def find_internal(text, regs=()):
    """回傳 [(種類, 原文片段), ...]。只收指向本篇自己的。"""
    hits = []
    taken = []
    for m in IN_ART.finditer(text):
        hits.append(("%s第%s條" % (m.group(1), m.group(2)), m.group(0)))
        taken.append(m.span())
    # 單獨寫的「第三條」「依本辦法第三條」（B25）：段首那個是這一條自己的條號，不算引用；
    # 前面不遠處有別的規章名的，是別人家的條號（find_external 收）
    for m in IN_ART_ANY.finditer(text):
        if m.start() == 0 or any(a <= m.start() < b for a, b in taken):
            continue
        before = text[max(0, m.start() - 20):m.start()].rstrip()
        listed = AFTER_EXTERNAL.search(text[max(0, m.start() - 60):m.start()])
        if SELF_NAME.search(before):
            pass                                   # 本辦法第三條：自己的
        elif re.search(r"(?:法|條例|規則|辦法|準則|要點|注意事項|自律規範|細則)[」』]*$", before) or \
                any(before.rstrip("」』").endswith(nm) for nm, _ in regs):
            continue                               # 緊接在別的規章名後面（可以隔引號）：別人家的條號
        elif listed and not SELF_NAME.search(listed.group(1)):
            continue                               # 「保險法第五條、第七條」的第七條：也是別人家的
        label = "第%s條" % m.group(1) + ("之%s" % m.group(2) if m.group(2) else "")
        hits.append((label, m.group(0)))
    for w in REL:
        if w in text:
            i = text.find(w)
            hits.append((w, text[max(0, i - 6):i + len(w) + 8]))
    for m in IN_CH.finditer(text):
        if belongs_outside(text, m.start(), regs):
            continue
        hits.append(("第%s章" % m.group(1), m.group(0)))
    for m in IN_SE.finditer(text):
        if belongs_outside(text, m.start(), regs):
            continue
        hits.append(("第%s節" % m.group(1), m.group(0)))
    return hits


# 「真的開一層」的符號類型：第一條（F）、一、(一)、1.、(1)、A.。表格、圖形、接續（被附件打斷的
# 下半段）、前言、無符號與章節標題都不開層，「前款」不能指到它們。
OPENERS = ("F", "A", "B", "C", "D", "E")


def _depth(r):
    """這一列在本章節裡是第幾層：S4 算過的階層深度優先，沒有才用 S3 的本範圍層級。"""
    for col in ("階層深度", "本範圍層級"):
        try:
            value = int(r.get(col) or 0)
        except ValueError:
            value = 0
        if value:
            return value
    return 0


def _opens_level(r):
    return (not r["條文ID"].endswith("-000") and r.get("符號類型") in OPENERS
            and _depth(r) > 0)


# 「前款」這一類指的是「同一層的前一個」；「前項」「前述」指的是「緊接在前面講的那一段」。
SIBLING_WORDS = ("前條", "前款", "前目", "前點")
NOT_A_PARAGRAPH = ("表格", "圖形")


def _host_of(rows, at, k):
    """這一列自己不開層（表格、圖形、接續、前言）時，順著「附屬於」回到它所屬的開層列。

    接續列可能附屬於表格、表格再附屬於前一段接續……一款被附件打斷幾次就串幾層，
    所以一路往回走到開層列為止，不設層數上限；附屬的一定在前面（S3 只往前掛），
    每一步都要往前退，退不動就停，不會繞圈。
    """
    me = rows[k]
    while not _opens_level(me):
        host = me.get("附屬於") or ""
        # 附屬於記的是 S3 的 ID；那一款被 S4 拆開的話，它自己的本文在「-00」子項
        while host and host not in at and host + "-00" in at:
            host += "-00"
        if host not in at or at[host] >= k:
            break
        k = at[host]
        me = rows[k]
    return k


def previous_sibling(rows, at, k):
    """「前條／前款／前目／前點」指到誰：同一章節裡、往前最近的同一種編號（一、對一、，
    (一) 對 (一)）的開層列。

    以前直接拿上一列：兩款中間夾一張表，「前款」指到表格；上一款底下有子目，
    「前款」指到最後一個子目。只有兩款緊鄰時才對。

    比的是符號類型，不是階層深度：S4 把一段裡的「一、……二、……」拆成 -01、-02 時，
    兩款的深度都比下一個正常切出來的「三、」深一層，比深度的話「三、」找不到「二、」。
    往前遇到另一種編號、而且比自己淺的列就停：那是自己的上層，前面沒有同層的兄弟，
    指不到就留空，不要硬指到別的上層底下去。
    這一列自己不開層時，先回到它所屬的那一款（_host_of）再往前找。
    """
    if k is None:
        return ""
    k = _host_of(rows, at, k)
    me = rows[k]
    scope = (me.get("章序號"), me.get("節序號"))
    kind = me.get("符號類型") if _opens_level(me) else None
    for j in range(k - 1, -1, -1):
        cand = rows[j]
        if (cand.get("章序號"), cand.get("節序號")) != scope:
            break
        if not _opens_level(cand):
            continue
        if kind is None or cand.get("符號類型") == kind:
            return cand["條文ID"]
        if _depth(cand) < _depth(me):
            break
    return ""


def previous_passage(rows, k, word):
    """「前項」「前述」指到誰：緊接在前面講的那一段（跟以前一樣是上一列）。

    這兩個詞講的不是「同一層的前一個」：接續列寫「前述表格」指的就是前面那張表，
    「(一)前述事項」指的是帶出這幾目的那一段。套用「前款」的找法會跳到別的款去。
    「前項」是前一段文字，所以跳過表格與圖形那幾列。
    """
    if not k:
        return ""
    for j in range(k - 1, -1, -1):
        cand = rows[j]
        if word == "前項" and cand.get("符號類型") in NOT_A_PARAGRAPH:
            continue
        return cand["條文ID"]
    return ""


# ------------------------------------------------------------------
def main(folder, reg_path):
    src = os.path.join(folder, "06_final.csv")
    if not os.path.isfile(src):
        src = os.path.join(folder, "05_flagged.csv")
    if not os.path.isfile(src):
        say("找不到 06_final.csv 或 05_flagged.csv")
        return None

    with io.open(src, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    regs = load_regs(reg_path)

    say("=" * 64)
    say("S8 引用報告")
    say("輸入：" + src)
    say("外部規章表：%s（%d 筆）" % (reg_path, len(regs)))
    say("=" * 64)

    # 查表：章序號 -> 章標題筆ID；章節 -> 節標題筆ID；(章,節,A號) -> 條文ID
    chap_id, sect_id, art_id = {}, {}, {}
    for r in rows:
        ci, si = r["章序號"], r["節序號"]
        if r["條文ID"].endswith("-000") and si == "000":
            chap_id[ci] = r["條文ID"]
        elif r["條文ID"].endswith("-000"):
            sect_id[(ci, si)] = r["條文ID"]
        if r["符號類型"] == "A" and r["符號原文"]:
            v = cn2int(re.sub(r"[、，,]", "", r["符號原文"]))
            if v and (ci, si, v) not in art_id:
                art_id[(ci, si, v)] = r["條文ID"]

    at = dict((r["條文ID"], k) for k, r in enumerate(rows))

    out = []
    tally = collections.Counter()
    unresolved = collections.Counter()

    for r in rows:
        text = r["全文"]
        ci, si = r["章序號"], r["節序號"]

        # 章、節標題本身不是引用，跳過
        is_title = r["條文ID"].endswith("-000")
        ins = [] if is_title else find_internal(text, regs)
        exs = find_external(text, regs)

        ids, in_raw = [], []
        for kind, frag in ins:
            in_raw.append(kind)
            tally["內:" + re.sub(r"第[一二三四五六七八九十]+", "第N", kind)] += 1
            tgt = ""
            if kind == "本章":
                tgt = chap_id.get(ci, "")
            elif kind == "本節":
                tgt = sect_id.get((ci, si), "")
            elif kind == "本篇":
                tgt = "（本篇）"
            elif kind in ("本條", "本項", "本款"):
                tgt = r["條文ID"]
            elif kind in SIBLING_WORDS:
                tgt = previous_sibling(rows, at, at.get(r["條文ID"]))
            elif kind in ("前項", "前述"):
                tgt = previous_passage(rows, at.get(r["條文ID"]), kind)
            else:
                m = re.match(r"^(本節|本章)第([一二三四五六七八九十]{1,3})條$", kind)
                if m:
                    v = cn2int(m.group(2))
                    key = (ci, si, v) if m.group(1) == "本節" else (ci, "000", v)
                    tgt = art_id.get(key, "")
                else:
                    m = re.match(r"^第([一二三四五六七八九十]{1,3})章$", kind)
                    if m:
                        tgt = chap_id.get("%03d" % cn2int(m.group(1)), "")
                    else:
                        m = re.match(r"^第([一二三四五六七八九十]{1,3})節$", kind)
                        if m:
                            tgt = sect_id.get((ci, "%03d" % cn2int(m.group(1))), "")
            if tgt:
                ids.append(tgt)
            else:
                unresolved[kind] += 1

        for nm, art, frag in exs:
            tally["外:" + nm] += 1

        rec = {
            "條文ID": r["條文ID"],
            "章標題": r["章標題"],
            "節標題": r["節標題"],
            "符號原文": r["符號原文"],
            "規章內引用": "Y" if ins else "N",
            "引用ID": ";".join(dict.fromkeys(ids)),
            "內引用原文": ";".join(dict.fromkeys(in_raw)),
            "規章外引用": "Y" if exs else "N",
            # 規章名與條號位置對齊，沒有條號的填「-」
            "規章名": ";".join(x[0] for x in exs),
            "條號": ";".join(x[1] or "-" for x in exs),
            "外引用原文": " ｜ ".join(x[2].replace("\n", " ") for x in exs)[:200],
            "字數": r["字數"],
            "全文": text,
        }
        out.append(rec)

    # ---------- 報告 ----------
    n_in = sum(1 for r in out if r["規章內引用"] == "Y")
    n_ex = sum(1 for r in out if r["規章外引用"] == "Y")
    n_both = sum(1 for r in out if r["規章內引用"] == "Y" and r["規章外引用"] == "Y")

    say()
    say("1. 總覽（%d 筆條文）" % len(out))
    say("   有規章內引用：%d 筆" % n_in)
    say("   有規章外引用：%d 筆" % n_ex)
    say("   兩種都有：    %d 筆" % n_both)
    say("   完全沒引用：  %d 筆"
        % sum(1 for r in out if r["規章內引用"] == "N" and r["規章外引用"] == "N"))

    say()
    say("2. 引用到哪些外部規章")
    for k, v in sorted(((k[2:], v) for k, v in tally.items()
                        if k.startswith("外:")), key=lambda x: -x[1]):
        say("   %-34s %d 次" % (k, v))

    say()
    say("3. 規章內引用的寫法")
    for k, v in sorted(((k[2:], v) for k, v in tally.items()
                        if k.startswith("內:")), key=lambda x: -x[1]):
        say("   %-12s %d 次" % (k, v))

    say()
    resolved = sum(1 for r in out if r["引用ID"])
    say("4. 內引用有沒有指出目標")
    say("   指得到 ID 的條文：%d 筆" % resolved)
    if unresolved:
        say("   指不到的寫法：")
        for k, v in unresolved.most_common(10):
            say("      %-12s %d 次" % (k, v))

    say()
    say("5. 有明確條號的外部引用（那一條一改，這裡要跟著查）")
    withart = [r for r in out if "第" in r["條號"]]
    say("   %d 筆" % len(withart))
    for r in withart[:20]:
        say("   %-22s %s %s" % (r["條文ID"], r["規章名"], r["條號"]))
        say("      %s" % r["外引用原文"][:70])

    return out


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S8_抓引用.py <資料夾>")
        sys.exit(1)

    folder = sys.argv[1]
    reg_path = os.path.join(TABLES, "S8_外部規章表.csv")
    result = main(folder, reg_path)

    if result is not None:
        with io.open(os.path.join(folder, "08_citations.csv"), "w",
                     encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=OUT_COLS, quoting=csv.QUOTE_ALL)
            w.writeheader()
            for r in result:
                w.writerow(dict((c, r.get(c, "")) for c in OUT_COLS))
        say()
        say("=" * 64)
        say("結論：S8 完成。已寫出 08_citations.csv（%d 筆）" % len(result))
        say("=" * 64)

    report = "\n".join(lines)
    with io.open(os.path.join(folder, "S8_引用報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if result is not None else 1)
