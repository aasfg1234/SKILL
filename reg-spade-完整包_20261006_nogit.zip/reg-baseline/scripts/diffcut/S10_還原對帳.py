# -*- coding: utf-8 -*-
r"""
S10：把切好的條文組回一份 Word

用法：
    py S10_還原對帳.py <資料夾> [原始txt] [--source-file 原檔] [--toc 起-迄]
    --source-file：這一輪的原檔（S12 的 --source 要給同一個檔），對帳證明記它的 SHA-256

輸入：<資料夾>\06_final.csv       （沒有就退而用 05_flagged.csv）
      <資料夾>\tables\Tnnn.md
      <資料夾>\02_shapes.csv
輸出：<資料夾>\10_還原.docx
      <資料夾>\10_還原.txt        （純文字，拿來逐字比對用）
      <資料夾>\S10_還原報告.txt

===========================================================
先講清楚這支程式的定位
===========================================================
**這是檢查工具，不是交件用的。**

真的要改內規，做法是「改原檔、開追蹤修訂」，不是把切碎的組回去。
組回去一定會出事：格式全掉、表格會歪、流程圖不見、
沒改到的地方也被重打一次。法遵文件不能這樣交。

那還原有什麼用？
    把切出來的東西組回純文字，跟原始 txt 逐字比對。
    比對得上，就證明前面 S1 到 S6 沒有漏字、沒有改字。
    這是整套的最後一道保險。

===========================================================
還原不了的東西（先列清楚）
===========================================================
    字型、字級、粗體、顏色      完全沒存
    縮排、行距、對齊、分頁      完全沒存
    表格的欄列結構            被壓平，不可逆
    流程圖的方塊與箭頭         只剩「【流程圖】」四個字
    頁首頁尾、頁碼            沒有
    目錄                    故意不還原（原檔的目錄是自動產生的）
"""

import csv
import datetime
import hashlib
import io
import json
import math
import os
import re
import sys

# 原始 txt 的目錄區行號。換一份文件就不一樣，執行時給：
#     py S10_還原對帳.py <資料夾> <原始txt> --toc 19-58
# 不給的話，找不到的行只會列出來，不會分類。
TOC_FROM, TOC_TO = None, None

lines = []


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def write_proof(folder, txt_path, source_file=""):
    """寫 S10_對帳證明.json。

    source_file：這一輪產線的原檔（cut 的 --source，docx 或 txt）。S12 發布時拿它的
    --source 跟這裡記的 SHA 比——以前證明只綁 01／05／06 幾個 CSV，S10 通過之後
    換一份來源檔跑 S12，規格包照樣記下新來源的雜湊發布出去，沒有任何一道關卡比對。
    沒給就退回 txt_path（直接拿 txt 跑 S10 時，那份 txt 就是來源）。
    沒有 txt（第二項沒做）就不記：第二項沒對過的來源，不能讓 S12 當成「對帳過的那一份」。
    """
    required_inputs = ("01_paragraphs.csv", "05_flagged.csv",
                       "06_final.csv", "06_deleted.csv")
    required_outputs = ("10_還原.txt", "S10_還原報告.txt")
    proof = {
        "格式版本": 1,
        "產生時間": datetime.datetime.now().astimezone().isoformat(),
        "逐字對帳通過": True,
        "輸入": {},
        "輸出": {},
    }
    for name in required_inputs:
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            raise ValueError("S10 證明缺少輸入：%s" % name)
        proof["輸入"][name] = {"SHA256": file_sha256(path),
                                  "位元組": os.path.getsize(path)}
    if txt_path and os.path.isfile(txt_path):
        proof["原始文字檔"] = {
            "檔名": os.path.basename(txt_path), "SHA256": file_sha256(txt_path),
            "位元組": os.path.getsize(txt_path),
        }
        source_file = source_file or txt_path
        if os.path.isfile(source_file):
            proof["來源檔"] = {
                "檔名": os.path.basename(source_file), "SHA256": file_sha256(source_file),
                "位元組": os.path.getsize(source_file),
            }
    for name in required_outputs:
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            raise ValueError("S10 證明缺少輸出：%s" % name)
        proof["輸出"][name] = {"SHA256": file_sha256(path),
                                  "位元組": os.path.getsize(path)}
    path = os.path.join(folder, "S10_對帳證明.json")
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump(proof, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return path


def say(s=""):
    lines.append(s)


def load(folder, name):
    p = os.path.join(folder, name)
    if not os.path.isfile(p):
        return None
    with io.open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def load_table(folder, tid):
    """讀 Tnnn.md，回傳一格一列的清單。"""
    p = os.path.join(folder, "tables", "T%s.md" % tid)
    if not os.path.isfile(p):
        return []
    cells = []
    with io.open(p, encoding="utf-8-sig") as f:
        for ln in f:
            ln = ln.rstrip("\n")
            if ln.startswith("- "):
                cells.append(ln[2:].strip())
            elif ln.startswith("|") and set(ln) - set("|- "):
                for c in ln.strip("|").split("|"):
                    if c.strip():
                        cells.append(c.strip())
    return cells


def norm(s):
    """比對用：把空白與全形空白拿掉。"""
    return re.sub(r"[\s　]+", "", s or "")


_MARKER = re.compile(r"(\[\[(?:TABLE|SHAPE):\d+\]\])")
_MARKER_ONLY = re.compile(r"^(?:\[\[(?:TABLE|SHAPE):\d+\]\])+$")


def load_deletions(folder):
    """(05_flagged.csv 的列, S6 核准刪除的條文ID set)。第一項與第二項共用這一份，
    兩項對「S6 刪了哪幾筆」才不會各講各的。"""
    base = load(folder, "05_flagged.csv") or []
    gone = load(folder, "06_deleted.csv") or []
    return base, set(x["條文ID"] for x in gone if x.get("人工決定") == "刪除")


def _row_tokens(folder, r):
    """一筆條文在還原稿裡占哪幾段字：照全文裡的順序，文字照放，表格記號換成那張表的每一格。

    原始 txt 裡沒有 [[TABLE:001]] 這種記號，表格是一格一行攤在原位上。記號前後的字
    要留在記號前後：S6「併入上一筆」會把表格後面那一行接到表格那一筆後面
    （全文「[[TABLE:001]]上表未盡事項。」），先放字再放格，順序就反了。
    """
    out = []
    for piece in _MARKER.split(r.get("全文") or ""):
        m = re.match(r"^\[\[(TABLE|SHAPE):(\d+)\]\]$", piece)
        if m:
            if m.group(1) == "TABLE":
                out += load_table(folder, m.group(2))
        elif norm(piece):
            out.append(piece)
    return out


def restored_tokens(folder, rows, base, deleted_ids):
    """還原稿照文件順序的一串段落，回傳 [(文字, 是否為 S6 核准刪除)]。

    以 05_flagged.csv（S6 之前）為準，每一筆各放自己的字，S6 核准刪除的標成刪除：
        刪除         不在 06_final.csv 裡，但原始 txt 裡有；以前被第二項當成漏字，
                     第一項說「已排除刪除的 1 筆」、第二項說「還缺 1 行」
        併入上一筆   S6 把它接到「前一個留下來的筆」（會跳過中間刪掉的筆）；以前放在
                     那一筆的位置，中間夾一筆刪除時順序就錯了，一樣被點名成漏字
    各放各的字、各在各的位置，跟原始 txt 的順序一模一樣。06_final.csv 的全文等於
    05 扣掉刪除的那幾筆依序接起來，這件事由第一項逐字驗過。
    """
    if not base:
        return [(t, False) for r in rows for t in _row_tokens(folder, r)]
    out = []
    for b in base:
        out += [(t, b["條文ID"] in deleted_ids) for t in _row_tokens(folder, b)]
    # 06_final.csv 有、05_flagged.csv 沒有的條文 ID 不該出現；真的有就接在最後，
    # 字仍然算得到，只是位置對不上時會被點名成缺字（寧可多報，不可少報）。
    known = set(b["條文ID"] for b in base)
    for r in rows:
        if r["條文ID"] not in known:
            out += [(t, False) for t in _row_tokens(folder, r)]
    return out


class _NoDocument(object):
    """沒有 python-docx 時頂替 Document：什麼都收、什麼都不做。"""

    def __getattr__(self, name):
        return self

    def __call__(self, *args, **kwargs):
        return self

    def __setattr__(self, name, value):
        pass


def align_source(source, tokens):
    """原始 txt 的行跟還原稿的段照順序對齊，回傳 (對不上的原始行 [(行號, 文字)], 還原稿多出來的字 [文字])。

    兩個方向都要查（A6）：以前只查「原檔的字有沒有少」，01 比原檔多出來的句子、整段條文
    （匯出時把沒接受的修訂、移動前的原文也讀進來）一路過 S10、S12 成為正式基準。

    以前是「這一行的字在還原稿任何地方找不找得到」：來源有兩段一模一樣的條文、
    匯出只剩一份時，兩行都「找得到」，S10 照樣放行（覆蓋率只有 67.6%）。
    現在逐行做順序比對（difflib），同一段出現幾次就要對到幾次。
    行數對不上的區塊（S4 把一行拆成好幾筆、併入上一筆把兩行併成一筆、表格一格有好幾行）
    整塊串起來照順序消化：原始行依序在那一塊還原字裡往後找，找到就往前推，找不到就是缺字。
    """
    import difflib
    a = [norm(ln) for _, ln in source]
    b = [norm(t) for t, _ in tokens]
    miss, extra = [], []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == "equal":
            continue
        if tag == "insert":
            extra += [t for t in b[j1:j2] if t]
            continue
        if tag == "delete":
            miss += source[i1:i2]
            continue
        pool = "".join(b[j1:j2])
        cursor = 0
        gaps = []
        for k in range(i1, i2):
            at = pool.find(a[k], cursor)
            if at < 0:
                miss.append(source[k])
            else:
                gaps.append(pool[cursor:at])
                cursor = at + len(a[k])
        gaps.append(pool[cursor:])
        extra += [g for g in gaps if g]
    return miss, extra


def main(folder, txt_path):
    rows = load(folder, "06_final.csv") or load(folder, "05_flagged.csv")
    if not rows:
        say("找不到 06_final.csv 或 05_flagged.csv")
        return False

    ok = True
    shapes = {}
    for r in (load(folder, "02_shapes.csv") or []):
        shapes.setdefault(r["圖形編號"], []).append(r["文字"])

    say("=" * 64)
    say("S10 還原報告")
    say("資料夾：" + folder)
    say("=" * 64)
    say()
    say("條文 %d 筆" % len(rows))

    # ---------- 組 Word ----------
    # 沒有 python-docx 只少 10_還原.docx 這一份（給人看的）；逐字對帳用的是 txt，照做（B26）。
    # 以前這裡直接 import，沒裝就整支中斷，對帳根本沒跑
    try:
        from docx import Document
        from docx.shared import Pt
    except ImportError:
        Document = None
    if Document is None:
        say("沒有安裝 python-docx：不產 10_還原.docx，逐字對帳照做")
        doc = _NoDocument()
    else:
        doc = Document()
        doc.core_properties.title = "還原稿（檢查用，不可交件）"
        p = doc.add_paragraph()
        run = p.add_run("【本檔為還原稿，只供比對檢查，不可作為正式內規】")
        run.bold = True
        run.font.size = Pt(12)

    plain = []          # 純文字，拿來逐字比對
    n_tbl = n_shp = 0

    for r in rows:
        text = r["全文"]
        kind = r["符號類型"]
        cid = r["條文ID"]

        if not text.strip():
            continue

        # 表格
        if kind == "表格":
            tid = r["含表格標記"].split(";")[0] if r["含表格標記"] else ""
            cells = load_table(folder, tid) if tid else []
            doc.add_paragraph("［表 T%s］（原表格欄列結構已在轉檔時遺失，"
                              "以下一列等於原本一格）" % tid)
            if cells:
                t = doc.add_table(rows=len(cells), cols=1)
                t.style = "Table Grid"
                for i, c in enumerate(cells):
                    t.cell(i, 0).text = c
            n_tbl += 1
            plain.append(text)
            continue

        # 流程圖
        if kind == "圖形":
            sid = r["含圖形標記"].split(";")[0] if r["含圖形標記"] else ""
            doc.add_paragraph("［流程圖 S%s］%s"
                              % (sid, "／".join(shapes.get(sid, []))))
            n_shp += 1
            plain.append(text)
            continue

        # 章、節標題
        if cid.endswith("-000") and r["節序號"] == "000":
            doc.add_heading(text, level=1)
        elif cid.endswith("-000"):
            doc.add_heading(text, level=2)
        else:
            doc.add_paragraph(text)
        plain.append(text)

    out_docx = os.path.join(folder, "10_還原.docx")
    if Document is None:
        out_docx = "（沒有 python-docx，沒產 10_還原.docx）"
    else:
        doc.save(out_docx)

    body = "\n".join(plain)
    with io.open(os.path.join(folder, "10_還原.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(body)

    say("   還原段落 %d 段（含表格 %d 張、流程圖 %d 張）"
        % (len(plain), n_tbl, n_shp))

    # ---------- 檢查一：跟切條前的段落檔逐字比對 ----------
    say()
    say("1. 跟 01_paragraphs.csv 逐字比對")
    para = load(folder, "01_paragraphs.csv")
    if not para:
        say("   [不合格] 找不到 01_paragraphs.csv")
        ok = False
    else:
        KEEP = ("章", "節", "內文", "表格標記", "圖形標記")
        src = "".join(x["全文"] for x in para if x["類型"] in KEEP)
        got = "".join(plain)
        say("   切條前 %d 字，還原後 %d 字" % (len(src), len(got)))

        # 用 S5 的原始順序重建「只排除真正刪除」後應有的全文。
        # 併入上一筆的文字仍在 06_final.csv 裡，不能再當刪除字數加一次。
        base, deleted_ids = load_deletions(folder)
        expected = src
        if base:
            base_text = "".join(x["全文"] for x in base)
            if base_text != src:
                say("   [不合格] 05_flagged.csv 已經跟 01_paragraphs.csv 不一致")
                ok = False
            expected = "".join(
                x["全文"] for x in base if x["條文ID"] not in deleted_ids
            )

        if got == expected:
            if deleted_ids:
                nchar = sum(
                    len(x["全文"]) for x in base if x["條文ID"] in deleted_ids
                )
                say("   [過] 一字不差；另排除 S6 真正刪除的 %d 筆（%d 字）"
                    % (len(deleted_ids), nchar))
            else:
                say("   [過] 一字不差")
        else:
            at = next((i for i in range(min(len(expected), len(got)))
                       if expected[i] != got[i]), min(len(expected), len(got)))
            say("   [不合格] 第一個不一致在第 %d 個字元" % (at + 1))
            say("      應：" + expected[max(0, at - 40):at + 40])
            say("      還：" + got[max(0, at - 40):at + 40])
            ok = False

    # ---------- 檢查二：跟原始 txt 比對 ----------
    say()
    say("2. 跟原始 %s 比對" % os.path.basename(txt_path or ""))
    if not txt_path:
        say("   沒有給原始 txt，跳過")
    elif not os.path.isfile(txt_path):
        # 給了卻找不到：以前也印「跳過」回 0，打錯路徑就等於沒對帳（第三批）
        say("   [不合格] 找不到原始 txt：%s" % txt_path)
        ok = False
    elif txt_path.lower().endswith((".docx", ".doc")):
        say("   [不合格] 第二個參數要給 txt，不是 Word 檔（run_all.py cut 會自動把 .docx 抽成 txt 再對帳）")
        ok = False
    else:
        raw = io.open(txt_path, encoding="utf-8-sig").read()
        source = [(k, ln.strip()) for k, ln in enumerate(raw.split(chr(10))) if norm(ln)]
        # 目錄區在對齊之前就拿掉：留著一起對齊的話，跟章標題同字的目錄行（沒有頁碼的目錄）
        # 會把本文章標題的錨點搶走，本文的行反而被點名成缺字。
        # 只有表格／圖形記號的行（手做的 txt 會照 S1 的樣子留著記號）也不必對：
        # 那一行不是條文，表格內容由表格那幾格自己對。
        toc = [(k, ln) for k, ln in source
               if TOC_FROM is not None and TOC_FROM <= k <= TOC_TO]
        body = [(k, ln) for k, ln in source
                if not (TOC_FROM is not None and TOC_FROM <= k <= TOC_TO)
                and not _MARKER_ONLY.match(norm(ln))]
        tokens = restored_tokens(folder, rows, *load_deletions(folder))
        n_deleted = sum(1 for _, deleted in tokens if deleted)
        miss, extra = align_source(body, tokens)
        body_chars = sum(len(norm(ln)) for _, ln in body)
        missed_chars = sum(len(norm(ln)) for _, ln in miss)
        # 無條件捨去到小數兩位：差幾個字時四捨五入會印出「100.0%」，旁邊卻寫「不到 100%」
        coverage = math.floor(10000.0 * (body_chars - missed_chars) / max(body_chars, 1)) / 100.0
        say("   原始 txt %d 行、%d 字（去空白、不含目錄區）" % (len(body), body_chars))
        say("   還原稿   %d 段（條文 ＋ 表格內容；S6 核准刪除的 %d 段放回原位一起對）"
            % (len(tokens), n_deleted))
        # 覆蓋率＝原始 txt 有對到還原稿的字數 ÷ 原始 txt 字數，照順序、照出現次數算：
        # 同一段在來源出現兩次、還原稿只有一次，少的那一份就是沒對到。
        # 以前是「還原稿字數 ÷ 來源字數」，只印出來、不擋：67.6% 也照樣放行。
        say("   還原覆蓋率：%.2f%%（原始 txt 有對到還原稿的字數 ÷ 原始 txt 字數，不含目錄區）"
            % coverage)
        if TOC_FROM is None:
            say("   沒指定目錄區行號：全部的行都要對得上")
        else:
            say("   目錄區（第 %d 到 %d 行）：%d 行 <- 故意不還原，不比對"
                % (TOC_FROM, TOC_TO, len(toc)))

        # 逐行點名：原始 txt 哪幾行在還原稿的對應位置上找不到
        if miss:
            say("   [不合格] 覆蓋率不到 100%%：還缺 %d 行、共 %d 字：" % (len(miss), missed_chars))
            for k, ln in miss[:15]:
                say("         行%d  %s" % (k, ln[:60]))
            ok = False
        else:
            say("   [過] 目錄以外一行都沒缺")
        # 反方向：還原稿有、原始 txt 沒有的字（A6）
        if extra:
            say("   [不合格] 還原稿多出原始 txt 沒有的字 %d 處、共 %d 字（匯出讀進了原檔沒有的內容，"
                "例如沒接受的追蹤修訂）：" % (len(extra), sum(len(x) for x in extra)))
            for x in extra[:15]:
                say("         多出  %s" % x[:60])
            ok = False
        else:
            say("   [過] 還原稿沒有多出原始 txt 沒有的字")

    say()
    say("3. 還原不了的東西（不是程式漏做，是資料本來就沒有）")
    say("   字型、字級、粗體、顏色、縮排、行距、分頁：完全沒存")
    say("   表格欄列結構：轉檔時已壓平，不可逆")
    say("   流程圖方塊與箭頭：只剩文字")
    say("   頁首頁尾、頁碼、自動目錄：沒有")

    say()
    say("4. 這份檔怎麼用")
    say("   拿來核對「字有沒有掉」可以。")
    say("   拿來當正式內規不行。要改內規請用 reg-report 比對、reg-edit 改原檔並開追蹤修訂。")

    say()
    say("   產出：%s" % out_docx)
    return ok


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S10_還原對帳.py <資料夾> [原始txt] [--toc 19-58] [--source-file 原檔]")
        sys.exit(1)
    folder = sys.argv[1]
    old_proof = os.path.join(folder, "S10_對帳證明.json")
    if os.path.isfile(old_proof):
        os.remove(old_proof)
    txt = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith("--") else ""
    source_file = ""
    for i, a in enumerate(sys.argv):
        if a == "--toc" and i + 1 < len(sys.argv) and "-" in sys.argv[i + 1]:
            lo, hi = sys.argv[i + 1].split("-", 1)
            TOC_FROM, TOC_TO = int(lo), int(hi)
        if a == "--source-file" and i + 1 < len(sys.argv):
            source_file = sys.argv[i + 1]
    ok = main(folder, txt)
    report = "\n".join(lines)
    with io.open(os.path.join(folder, "S10_還原報告.txt"), "w",
                 encoding="utf-8-sig") as f:
        f.write(report + "\n")
    if ok:
        try:
            proof_path = write_proof(folder, txt, source_file)
            report += "\n完整對帳證明：%s" % proof_path
        except Exception as exc:
            ok = False
            report += "\n[不合格] 無法產生 S10 對帳證明：%s" % exc
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if ok else 1)
