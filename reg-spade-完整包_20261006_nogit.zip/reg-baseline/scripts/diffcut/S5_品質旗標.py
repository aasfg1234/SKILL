# -*- coding: utf-8 -*-
r"""
S5：打品質旗標

用法：
    py S5_品質旗標.py <資料夾>

輸入：<資料夾>\04_items2.csv
輸出：<資料夾>\05_flagged.csv
      <資料夾>\S5_品質旗標報告.txt

這一階段不改任何文字，只在每一筆旁邊貼標籤，
把「人一定要親眼看一下」的筆挑出來，交給 S6。

十種旗標：
  空白        字數 0
  過短        內容筆但不到 10 字
  過長        還超過 800 字，S4 沒切動
  只有標記    整筆只有 [[TABLE:xxx]] 或 [[SHAPE:xxx]]
  開頭異常    開頭是標點或殘缺符號，代表切點切在字中間
  括號未閉    全形半形括號數量對不上
  無符號內容  是內容筆卻沒有編號符號
  符號跳號    同一層的編號不連續，例如 1、2、4
  疑似缺少父階編號  子編號重新從 1 起算前出現導入句，原文可能漏寫了一個父階編號
  內含未切出的編號  條文中間還躺著別的編號，代表 S4 的切點選錯了
  完全重複    有另一筆文字一模一樣
  開頭相同    跟另一筆的開頭 30 字以上一字不差
  含表格圖形  裡面夾了表格或流程圖，改條文時要一起看
"""

import csv
import os
import re
import sys
import collections

LIMIT = 800
SHORT = 10

CN_MAP = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5,
          "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}

BAD_HEAD = "、，。；：）)」』】〉》,;:.．·"

NEW_COLS = ["旗標", "旗標數", "需人工看", "建議動作", "重複組"]

lines = []


def say(s=""):
    lines.append(s)


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _heading import ITEM_CN, item_num, cited_mark   # noqa: E402


def cn2int(s):
    # 認到九百九十九（「一百零一、」），跟 S3、S4 同一把尺；以前到九十九，一百以後全算錯號
    return item_num(s)


def sym_value(raw):
    """從符號原文取出數值。認不出來回 None。"""
    if not raw:
        return None
    m = re.search(r"(%s|\d{1,3}|[A-Za-z])" % ITEM_CN, raw)
    if not m:
        return None
    t = m.group(1)
    if t.isdigit():
        return int(t)
    if re.match(r"^[A-Za-z]$", t):
        return ord(t.upper()) - 64
    return cn2int(t)


HEAD_PATS = [
    re.compile(r"^[（(]\s*(%s)\s*[）)]" % ITEM_CN),
    re.compile(r"^[（(]\s*(\d{1,3})\s*[）)]"),
    re.compile(r"^(%s)\s*[、，,]" % ITEM_CN),
    re.compile(r"^(\d{1,3})\s*(?:、|[.．](?![0-9０-９]))"),
    re.compile(r"^([A-Za-z])\s*[.．]"),
]


def head_kind(text):
    """從一段文字的開頭認出編號屬於哪一類。"""
    t = re.sub(r"^(?:\s*\[\[(?:TABLE|SHAPE):\d{3}\]\])+", "", text or "").lstrip()
    for name, pat in zip(("B", "D", "A", "C", "E"), HEAD_PATS):
        if pat.match(t):
            return name
    return ""


def head_value(text):
    """從一段文字的開頭認出編號數值。認不出來回 None。"""
    t = re.sub(r"^(?:\s*\[\[(?:TABLE|SHAPE):\d{3}\]\])+", "", text or "").lstrip()
    for pat in HEAD_PATS:
        m = pat.match(t)
        if m:
            return sym_value(m.group(1))
    return None


BODY_PATS = {
    "A": re.compile(r"(%s)\s*[、，,]" % ITEM_CN),
    "B": re.compile(r"[（(]\s*(%s)\s*[）)]" % ITEM_CN),
    "C": re.compile(r"(\d{1,3})\s*(?:、|[.．](?![0-9０-９]))"),
    "D": re.compile(r"[（(]\s*(\d{1,3})\s*[）)]"),
    "E": re.compile(r"([A-Za-z])\s*[.．]"),
}


def has_number(text, kind, value):
    """這段文字裡面，有沒有出現這一類符號的這個號碼。"""
    pat = BODY_PATS.get(kind)
    if not pat or not text:
        return False
    for m in pat.finditer(text):
        a = m.start()
        # 跟 S4 同一套排除規則：前面是「第」或英數字，那是引用或代號
        if a > 0 and text[a - 1] == "第":
            continue
        if a > 0 and text[a - 1].isascii() and text[a - 1].isalnum():
            continue
        # 段落中間「依…第一節二、規定」「一、二、三級」是引用或列數字（跟 S4 同一套）
        if a > 0 and cited_mark(text, a, m.end(), kind):
            continue
        if sym_value(m.group(1)) == value:
            return True
    return False


def parent_key(item_id):
    """同一層的兄弟共用的前置字串。"""
    return item_id.rsplit("-", 1)[0]


# ------------------------------------------------------------------
# 內含未切出的編號
#
# 一筆條文的中間如果還躺著別的編號，代表 S4 的切點選錯了，那個編號
# 底下的內容被併進了上一條。
#
# 實例：006-001-008-03 的全文是
#     4. 檢核結果若有異常狀況……處置辦理。(四) 保險代理部針對異常減額
#     繳清/展期定期之案件……
# 那個 (四) 是新的父階，應該自己成一條。
#
# S4 為什麼沒切：pick() 只把「從 1 開始」的序列當候選。這一筆裡 B 類
# 只有 (四)(五)，從 4 開始，longest_run 回傳長度 0，所以 B 整個被排除，
# 選了從位置 0 就出現的 C 類。詳見 Session 009 的紀錄。
#
# 這裡不去改 S4 的切點選擇（風險高），改成事後補一張安全網。
# ------------------------------------------------------------------

# 編號前面緊鄰這些字，那是引用不是編號
#   第、依、之   「依第(二)款」「之(二)至(八)」
#   至、及、或、與、、   並列或範圍，例如「(二)至(八)」「程序、五、本行」
NOT_MARK_BEFORE = "第依之至及或與、，和"

# 句末標點。編號前面是這些字元，代表上一句已經結束
SENT_END = "。！？；：:;）)」』】"


def quoted_spans(text):
    """書名號與引號的範圍。裡面的編號是在引用別份文件。"""
    return [(m.start(), m.end())
            for m in re.finditer(r"[《「『][^》」』]{0,80}[》」』]", text or "")]


def mid_marks(text):
    """條文中間（開頭符號之後）還躺著哪些編號。回傳符號原文清單。"""
    t = text or ""
    if not t.strip():
        return []

    # 先跳過本筆自己的開頭符號
    head = re.sub(r"^(?:\s*\[\[(?:TABLE|SHAPE):\d{3}\]\])+", "", t)
    off = len(t) - len(head)
    head = head.lstrip()
    off += len(t) - off - len(head)
    start = 0
    for pat in HEAD_PATS:
        m = pat.match(head)
        if m:
            start = m.end()
            break
    start += off

    spans = quoted_spans(t)
    found = []
    for kind, pat in BODY_PATS.items():
        for m in pat.finditer(t):
            a = m.start()
            if a < start:
                continue
            if t[a - 1] in NOT_MARK_BEFORE:
                continue
            if t[a - 1].isascii() and t[a - 1].isalnum():
                continue
            if any(x <= a < y for x, y in spans):
                continue
            if m.end() < len(t) and t[m.end()] in "條款項目章節點":
                continue
            # 「依…手冊第二章第一節一、規定」「如附表一、二」「一、二、三級」：S4 刻意不切，
            # 這裡也不要再報「內含未切出的編號」（跟 S4 同一套，_heading.cited_mark）
            if t[a - 1] in "百零〇" or cited_mark(t, a, m.end(), kind):
                continue

            # 真的漏切，編號前面只會是這兩種樣子
            #   一、前面是句末標點      「……處置辦理。(四) 保險代理部……」
            #   二、前面整段是短標題    「(二) 存量前十大標的分析1、 單一標的……」
            # 兩種都不是的話，那多半是編號夾在句子中間，是引用或代號。
            seg = t[start:a]
            if not (t[a - 1] in SENT_END
                    or (len(seg) <= 30 and not re.search(r"[。！？；]", seg))):
                continue

            found.append((a, m.group(0)))
    found.sort()
    return [s for _, s in found]


# ------------------------------------------------------------------
# 疑似缺少父階編號
#
# 同一個父項底下，子編號編到 2 以上之後又從 1 開始，本來是允許的，
# 所以上面的跳號檢查刻意不報。但如果在重新起算之前出現一句
# 「前項……應依下列方式執行：」這種導入句，那就是另一回事：
# 原文很可能漏寫了一個父階編號，導致兩組子項被併在同一個父項底下。
#
# 實例（原檔 947 到 951 行）
#     (一) 為確認要保人網路投保意願……
#     1、 要保人單獨投保強制汽車責任保險……
#     2、 投保財產保險之既有保戶……
#     3、 要保人透過生物辨識……不在此限。前項確認程序，應依下列方式執行：
#     1、 首次經由本行與保險公司洽訂保險契約……   <- 這裡少了一個 (二)
#
# 判定條件寫得很嚴，三個都要成立才報。放寬會開始誤報。
# ------------------------------------------------------------------

INTRO_TAIL = re.compile(
    r"(?P<intro>(?:前項|前款|前目|前述|上述|以下|下列)"
    r"[^。！？；;]{0,100}?(?:下列|以下|方式|程序|項目|情形|事項)"
    r"[^。！？；;]{0,60}?[：:])\s*$"
)

INTRO_CUE = re.compile(r"(前項|前款|前目|前述|上述|下列|以下)")


def intro_at_tail(text):
    """條文尾端有沒有一句用來引出下一組子項的導入句。

    導入句前面必須先有一句完整內容，不然「1、前項……如下：」
    這種正常寫法會被誤認。
    """
    s = (text or "").strip()
    m = INTRO_TAIL.search(s)
    if not m:
        return ""
    before = s[:m.start()].rstrip()
    if not before or before[-1:] not in "。！？；;":
        return ""
    return m.group("intro")


def intro_standalone(text):
    """整條就是一句導入句，而且沒有編號。

    S3、S4 有時候會把它切成獨立一筆。長度不超過 120、結尾是冒號、
    含前項或下列這類詞，三個都成立才算。
    """
    s = (text or "").strip()
    if not s or len(s) > 120:
        return ""
    if not s.endswith("：") and not s.endswith(":"):
        return ""
    if not INTRO_CUE.search(s):
        return ""
    return s


def parent_sym(by_id, parent_id):
    """父項的符號原文。父項被 S4 切掉時，改看它的第一個子項。"""
    p = by_id.get(parent_id)
    if p and p.get("符號原文"):
        return p["符號原文"]
    p = by_id.get(parent_id + "-00")
    if p and p.get("符號原文"):
        return p["符號原文"]
    return ""


def check_miss_parent(by_id, rows, at, prev_id, cur_id, parent_id):
    """判斷 cur_id 從 1 重新起算，是不是因為前面漏寫了父階編號。

    回傳說明字串；不是的話回空字串。

    三個條件都要成立
      一、prev 到 cur 之間沒有夾別的有編號條文
      二、找得到導入句（在 prev 尾端，或中間自成一條）
      三、算得出父階的下一個編號
    """
    a, b = at.get(prev_id), at.get(cur_id)
    if a is None or b is None or b <= a:
        return ""

    intro = ""
    where = prev_id

    # 中間那幾條：只允許沒有編號的（導入句、表格、圖形）
    for j in range(a + 1, b):
        r = rows[j]
        if r["符號類型"] in ("F", "A", "B", "C", "D", "E"):
            return ""            # 夾了別的編號，那是換了父項，正常
        if not intro:
            t = intro_standalone(r["全文"])
            if t:
                intro, where = t, r["條文ID"]

    if not intro:
        prev = by_id.get(prev_id)
        intro = intro_at_tail(prev["全文"]) if prev else ""
        where = prev_id
    if not intro:
        return ""

    want = next_sym(parent_sym(by_id, parent_id))
    if not want:
        return ""

    return ("上一組子編號已到底又從 1 起算，中間有導入句「%s」。"
            "疑似應在該導入句前補「%s」（位置：%s）。" % (intro, want, where))


def next_sym(raw):
    """照現在的父階編號，算出下一個同階編號長什麼樣。算不出回空字串。"""
    s = (raw or "").strip()
    v = sym_value(s)
    if not v:
        return ""
    nv = v + 1
    m = re.search(r"[一二三四五六七八九十]+", s)
    if m:
        rev = dict((n, k) for k, n in CN_MAP.items())
        if 1 <= nv <= 9:
            new = rev[nv]
        elif 10 <= nv <= 99:
            tens, ones = divmod(nv, 10)
            new = ("" if tens == 1 else rev[tens]) + "十" + (rev[ones] if ones else "")
        else:
            return ""
        return s[:m.start()] + new + s[m.end():]
    m = re.search(r"\d+", s)
    if m:
        return s[:m.start()] + str(nv) + s[m.end():]
    return ""


def norm(text):
    return re.sub(r"\s+", "", text)


def main(folder):
    src = os.path.join(folder, "04_items2.csv")
    if not os.path.isfile(src):
        say("找不到 " + src)
        return None, False, None

    with open(src, "r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    say("=" * 60)
    say("S5 品質旗標報告")
    say("資料夾：" + folder)
    say("=" * 60)
    say()
    say("輸入筆數：%d" % len(rows))

    # ---------- 先算完全重複 ----------
    groups = collections.defaultdict(list)
    for r in rows:
        t = norm(r["全文"])
        if len(t) >= 15:          # 太短的重複沒有意義
            groups[t].append(r["條文ID"])
    dup_of = {}
    gno = 0
    for t, ids in groups.items():
        if len(ids) > 1:
            gno += 1
            for i in ids:
                dup_of[i] = "R%03d" % gno

    # ---------- 先算開頭相同（重複前言常被併進第一筆，完全比對抓不到）----------
    HEAD_MIN = 30
    pairs = sorted(((norm(r["全文"]), r["條文ID"]) for r in rows
                    if len(norm(r["全文"])) >= HEAD_MIN))
    head_of = {}
    chain = []           # 連在一起的一群，共用同一組編號
    share = 0
    groups_found = []
    for i in range(len(pairs) - 1):
        a_txt, a_id = pairs[i]
        b_txt, b_id = pairs[i + 1]
        n = 0
        while n < min(len(a_txt), len(b_txt)) and a_txt[n] == b_txt[n]:
            n += 1
        if n >= HEAD_MIN and a_txt != b_txt:
            if not chain:
                chain = [a_id, b_id]
                share = n
            else:
                chain.append(b_id)
                share = min(share, n)
        else:
            if chain:
                groups_found.append((chain, share))
            chain, share = [], 0
    if chain:
        groups_found.append((chain, share))

    for k, (ids, n) in enumerate(groups_found, 1):
        tag = "P%03d(%d字)" % (k, n)
        for i in ids:
            head_of[i] = tag

    # ---------- 先算符號跳號 ----------
    by_id = dict((r["條文ID"], r) for r in rows)
    kids = collections.defaultdict(list)
    for r in rows:
        if r["父ID"]:
            kids[r["父ID"]].append(r)

    nodes = {}                       # 條文ID -> 數值
    kind_of = {}                     # 條文ID -> 符號類型
    for r in rows:
        if r["符號類型"] in ("A", "B", "C", "D", "E"):
            nodes[r["條文ID"]] = sym_value(r["符號原文"])
            kind_of[r["條文ID"]] = r["符號類型"]
    # 被 S4 切掉的那些父項，本人已經不在表裡，
    # 但它的第一個子項開頭就是它自己的符號，從那裡把它補回來
    for pid, group in kids.items():
        if pid in by_id:
            continue
        first = sorted(group, key=lambda x: x["條文ID"])[0]
        v = head_value(first["全文"])
        if v is not None:
            nodes[pid] = v
            kind_of[pid] = head_kind(first["全文"])

    lead = set(r["條文ID"] for r in rows if r.get("是否前言") == "Y")
    sibs = collections.defaultdict(list)
    for iid, v in nodes.items():
        if iid in lead:
            # 這是母條文自己的本文段，編號屬於上一層，不跟子項排在一起
            continue
        sibs[(parent_key(iid), kind_of.get(iid, ""))].append((iid, v))

    # 條文在檔案裡的先後順序，用來往前抓一條
    order = [r["條文ID"] for r in rows]
    at = dict((cid, k) for k, cid in enumerate(order))

    def prev_body(cid):
        """往前找最近一條有內容的條文（跳過表格、圖形、章節標題）。"""
        k = at.get(cid)
        if k is None:
            return None
        for j in range(k - 1, -1, -1):
            r = rows[j]
            if r["符號類型"] in ("表格", "圖形"):
                continue
            if r["條文ID"].endswith("-000"):
                continue
            if r["全文"].strip():
                return r
        return None

    jump = set()
    miss_parent = {}                 # 條文ID -> 說明
    for key, group in sibs.items():
        group.sort(key=lambda x: x[0])
        want = None
        prev_i = prev_v = None
        for i, v in group:
            if v is None:
                continue

            if want is None:
                if v == 1:
                    want = 2
                    continue
                # 開頭不是 1：往前抓一條，看前一條裡面有沒有 v-1
                # 有 -> 這串是接著前一條編下來的，不算跳號
                # 沒有 -> 真的少了一號
                p = prev_body(i)
                kd = key[1]
                if p is not None and has_number(p["全文"], kd, v - 1):
                    want = v + 1
                else:
                    if i in by_id:
                        jump.add(i)
                    want = v + 1
                continue

            if v == want:
                want += 1
            elif v == 1:
                # 同一條底下有好幾組 1.2.3.，換一組重新編，不算跳號。
                # 但重新起算之前如果出現導入句，那多半是漏寫了父階編號。
                if i in by_id and prev_i and prev_v and prev_v >= 2:
                    note = check_miss_parent(by_id, rows, at, prev_i, i, key[0])
                    if note:
                        miss_parent[i] = note
                want = 2
            else:
                if i in by_id:
                    jump.add(i)
                want = v + 1

            prev_i, prev_v = i, v

    # ---------- 逐筆打旗標 ----------
    out = []
    inner_of = {}
    tally = collections.Counter()
    for r in rows:
        text = r["全文"]
        n = len(text)
        is_title = r["條文ID"].endswith("-000")
        flags = []

        if n == 0:
            flags.append("空白")
        elif not is_title and n < SHORT:
            flags.append("過短")
        if n > LIMIT:
            flags.append("過長")

        stripped = re.sub(r"\[\[(?:TABLE|SHAPE):\d{3}\]\]", "", text).strip()
        if (not stripped and re.search(r"\[\[", text)
                and r["符號類型"] not in ("表格", "圖形")):
            # 符號類型是表格或圖形的，是 S3 故意讓它獨立的，不算異常
            flags.append("只有標記")

        if text and text[0] in BAD_HEAD:
            flags.append("開頭異常")

        op = text.count("（") + text.count("(")
        cl = text.count("）") + text.count(")")
        if op != cl:
            flags.append("括號未閉")

        if (not is_title and n > 0 and r["符號類型"] in ("無符號", "")
                and r.get("是否前言") != "Y"):
            flags.append("無符號內容")

        if r["條文ID"] in jump:
            flags.append("符號跳號")
        if r["條文ID"] in miss_parent:
            flags.append("疑似缺少父階編號")
        if not is_title and r["符號類型"] not in ("表格", "圖形"):
            inner = mid_marks(text)
            if inner:
                flags.append("內含未切出的編號")
                inner_of[r["條文ID"]] = inner

        if r["條文ID"] in dup_of:
            flags.append("完全重複")

        if r["條文ID"] in head_of:
            flags.append("開頭相同")

        if r["含表格標記"] or r["含圖形標記"]:
            flags.append("含表格圖形")

        for f in flags:
            tally[f] += 1

        # 建議動作
        act = ""
        if "空白" in flags:
            act = "刪掉這一筆"
        elif "只有標記" in flags:
            act = "併進上一筆，或讓表格自己獨立一筆"
        elif "過長" in flags:
            act = "手動再切一次"
        elif "開頭異常" in flags:
            act = "回去看 S3、S4 的切點是不是切在字中間"
        elif "內含未切出的編號" in flags:
            act = ("中間還有編號 %s 沒切出來，S4 的切點選錯了。"
                   "把它切成獨立一條。" % "、".join(inner_of[r["條文ID"]][:6]))
        elif "疑似缺少父階編號" in flags:
            act = miss_parent[r["條文ID"]]
        elif "符號跳號" in flags:
            act = "看是漏切還是原文本來就跳號"
        elif "完全重複" in flags:
            act = "留著，S7 判斷是引用還是重複條文"
        elif "開頭相同" in flags:
            act = "跟另一筆的開頭一字不差，S7 要判斷是不是同一條重複寫"
        elif "無符號內容" in flags:
            act = ("這是篇名，S6 決定留不留" if r["條文ID"].startswith("000-")
                   else "看是不是前一筆的續行")
        elif "括號未閉" in flags:
            act = "看括號是不是被切斷"
        elif "過短" in flags:
            act = "看是不是切太碎"

        # 「含表格圖形」自己不算要人工看，只是提醒
        need = [f for f in flags if f != "含表格圖形"]

        rec = dict(r)
        rec["旗標"] = ";".join(flags)
        rec["旗標數"] = len(flags)
        rec["需人工看"] = "Y" if need else "N"
        rec["建議動作"] = act
        rec["重複組"] = dup_of.get(r["條文ID"], "") or head_of.get(r["條文ID"], "")
        out.append(rec)

    # ---------- 報告 ----------
    need_rows = [r for r in out if r["需人工看"] == "Y"]

    say()
    say("1. 旗標統計")
    for f in ["空白", "過短", "過長", "只有標記", "開頭異常", "括號未閉",
              "無符號內容", "符號跳號", "疑似缺少父階編號",
              "內含未切出的編號", "完全重複", "開頭相同", "含表格圖形"]:
        say("   %-10s %d 筆" % (f, tally.get(f, 0)))

    say()
    say("2. 需人工看：%d 筆（占 %.1f%%）"
        % (len(need_rows), 100.0 * len(need_rows) / max(len(out), 1)))
    say("   乾淨不用看：%d 筆" % (len(out) - len(need_rows)))

    say()
    say("3. 需人工看的清單")
    for r in need_rows:
        say("   %-26s %4s 字  [%s]" % (r["條文ID"], r["字數"], r["旗標"]))
        say("       建議：%s" % r["建議動作"])
        say("       內容：%s" % (r["全文"][:40] or "（空）"))

    say()
    say("4. 完全重複的組")
    bygroup = collections.defaultdict(list)
    for r in out:
        if r["重複組"]:
            bygroup[r["重複組"]].append(r)
    if not bygroup:
        say("   沒有")
    for g in sorted(bygroup):
        members = bygroup[g]
        say("   %s  %d 筆  %s 字" % (g, len(members), members[0]["字數"]))
        for r in members:
            say("      %s" % r["條文ID"])
        say("      內容：%s" % members[0]["全文"][:50])

    say()
    say("5. 夾了表格或流程圖的筆（改條文時要一起看）")
    for r in out:
        if r["含表格標記"] or r["含圖形標記"]:
            say("   %-26s 表 %-22s 圖 %s"
                % (r["條文ID"], r["含表格標記"] or "-", r["含圖形標記"] or "-"))

    return out, True, rows


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：py S5_品質旗標.py <資料夾>")
        sys.exit(1)

    folder = sys.argv[1]
    result, ok, srcrows = main(folder)

    if ok:
        # 這一階段不動文字，還是驗一次
        a = "".join(r["全文"] for r in srcrows)
        b = "".join(r["全文"] for r in result)
        if a != b:
            ok = False
            say()
            say("無損驗證沒過，沒有寫出 05_flagged.csv")

    if ok:
        cols = list(srcrows[0].keys()) + NEW_COLS
        with open(os.path.join(folder, "05_flagged.csv"), "w",
                  encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols, quoting=csv.QUOTE_ALL)
            w.writeheader()
            for r in result:
                w.writerow(dict((c, r.get(c, "")) for c in cols))
        say()
        say("=" * 60)
        say("結論：S5 完成。已寫出 05_flagged.csv")
        say("=" * 60)

    report = "\n".join(lines)
    with open(os.path.join(folder, "S5_品質旗標報告.txt"), "w",
              encoding="utf-8-sig") as f:
        f.write(report + "\n")

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(report)
    sys.exit(0 if ok else 1)
