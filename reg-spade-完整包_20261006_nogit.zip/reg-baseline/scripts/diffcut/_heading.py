# -*- coding: utf-8 -*-
"""章、節標題怎麼認：S1P、S2、S3 共用同一把尺（S1 巨集的 IsChapter／IsSection 照同一套寫）。

以前各支各寫一套：S1 巨集「第一個字是第、前 8 個字有章」就算章，S3、S2 只認一到十的國字。
結果「第壹章」「第2章」「第十一章」切出來章序號都是 000（ID 重複），內文「第三款依第二章規定…」
被當成一章，關卡都不擋。現在：

    標題 = 第 ＋ 數字（國字一二三…、大寫壹貳參…、阿拉伯、全形）＋ 章／節 ＋ 標題文字
    標題文字：可以沒有；有的話不超過 30 字、不含句號，而且第一個字不是接續語
             （所、之、的、規定、第、及、或、與、至、中所、內所、，、；、。）——標題本身可能是「內部控制」「目的」，
             所以只擋這幾個接續語，不擋單一個「內」「目」
             「第二章所定之表單」「第三章第二節規定」是內文在引用，不是標題。
"""

import re

_DIGITS = "〇零一二三四五六七八九"
_VALUE = dict(zip("〇零一二三四五六七八九", (0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9)))
_UPPER = {"壹": "一", "貳": "二", "參": "三", "叁": "三", "肆": "四", "伍": "五", "陸": "六",
          "柒": "七", "捌": "八", "玖": "九", "拾": "十", "佰": "百", "兩": "二", "廿": "二十"}
NUM_CHARS = "〇零一二三四五六七八九十百壹貳參叁肆伍陸柒捌玖拾佰兩廿0-9０-９"
HEAD_RE = re.compile(r"^第\s*([%s]+)\s*([章節])" % NUM_CHARS)
SEPARATORS = "、：:．. 　"
CONTINUATION = ("所", "之", "的", "規定", "第", "及", "或", "與", "至", "中所", "內所", "，", ",", "；", ";", "。")
MAX_TITLE = 30


def cn_num(s):
    """國字、大寫、阿拉伯、全形數字 → int；認不出來回 None。認到 999。"""
    s = (s or "").strip()
    if not s:
        return None
    s = "".join(chr(ord(c) - 0xFEE0) if "０" <= c <= "９" else c for c in s)
    if s.isdigit():
        return int(s)
    for k, v in _UPPER.items():
        s = s.replace(k, v)
    if any(c not in _DIGITS + "十百" for c in s):
        return None
    if "十" not in s and "百" not in s:
        # 逐位寫法：一〇五
        if len(s) == 1:
            return _VALUE[s] or None
        return int("".join(str(_VALUE[c]) for c in s))
    total = 0
    rest = s
    if "百" in rest:
        left, _, rest = rest.partition("百")
        if len(left) > 1 or "十" in left:
            return None
        total += (_VALUE[left] if left else 1) * 100
        rest = rest.lstrip("〇零")
    if "十" in rest:
        left, _, rest = rest.partition("十")
        if len(left) > 1:
            return None
        total += (_VALUE[left] if left else 1) * 10
    if rest:
        if len(rest) > 1:
            return None
        total += _VALUE[rest]
    return total or None


def heading(text):
    """(「章」或「節」, 序號)；不是章節標題回 None。"""
    text = (text or "").strip()
    m = HEAD_RE.match(text)
    if not m:
        return None
    rest = text[m.end():].lstrip(SEPARATORS)
    if rest and (rest.startswith(CONTINUATION) or "。" in rest or len(rest) > MAX_TITLE):
        return None
    n = cn_num(m.group(1))
    if not n:
        return None
    return m.group(2), n


# 條文式編排（第一條、第五條之一）：S3 拿它當最上層的切點（符號類型 F，A8）。
# 後面接「規定」「所定」「至」「、第」這種的是句子在引用別條，不是條號本身。
ARTICLE_RE = re.compile(r"^第\s*[%s]+\s*條(?:\s*之\s*[%s]+)?(?!\s*(?:規定|所|至|及|或|與|之|中|內|第|，|,|。|、))"
                        % (NUM_CHARS, NUM_CHARS))


def article(text):
    """段首的條號（「第五條之一」）；不是條號開頭回空字串。"""
    m = ARTICLE_RE.match((text or "").strip())
    return m.group(0).strip() if m else ""


def is_chapter(text):
    h = heading(text)
    return bool(h) and h[0] == "章"


def is_section(text):
    h = heading(text)
    return bool(h) and h[0] == "節"


def number_of(text, kind):
    """章或節標題的序號；不是這一種標題回 None。"""
    h = heading(text)
    return h[1] if h and h[0] == kind else None


# ---------------------------------------------------------------------------
# 點、款的國字編號（S3、S4、S5、QA 共用）
#
# 以前各支寫 [一二三四五六七八九十]{1,3}，只認到九十九。要點一路編到「一百零一、」時：
# S3 認不出它是新的一點，一百以後的點全部黏成一筆上千字；S4 再從「一百零一、」的中間
# 找到「一、」「二、」切下去，切成「…一百零」＋「一、…」，QA 擋「切在句子中間」。
# 30 本測資 12 本建不出規格包，10 本有這個（另 6 本有段中引用，見下面 cited_mark）。現在認到九百九十九；第一個字不能是「百」「零」，
# 「二〇二六、」「一二、」這種逐位寫法也不算（那是年份或代號，不是點號）。
# ---------------------------------------------------------------------------
ITEM_CN = "[一二三四五六七八九十][一二三四五六七八九十百零〇]{0,4}"


def item_num(s):
    """點、款的國字編號 → int；不像編號回 None。"""
    s = (s or "").strip()
    if len(s) > 1 and "十" not in s and "百" not in s:
        return None
    return cn_num(s)


# ---------------------------------------------------------------------------
# 段落中間的編號是不是在引用（S4 切點、S5 漏切旗標、QA 該切沒切共用）
#
# 只有段首的編號才是結構。段落中間的「一、」「（二）」「3.」，下面這幾種是句子在講別的條次
# 或列數字，不能切開：
#   「依契約保全作業手冊第二章第一節一、規定」  前面緊接完整的「第X章／節／條／點／款／項／目」
#   「依本要點第三點（二）辦理」
#   「如附表一、二」「附件三、」                  前面緊接附表、附件、附圖、附錄
#   「依保全手冊一、規定」「依前開一、規定辦理」  同一句前面有依／參照／準用，後面接規定／辦理
#   「分為一、二、三級」                          後面只接另一個數字（再接、或級、類、點…）
# 只看前一個字不夠：真檔常把點名跟第一款寫在同一段——「一、照會作業程序(一)照會通知程序」
# 「保險商品風險等級分類評分項目(一)解約金型態」「應遵循事項(一)…」，「序」「目」「項」後面的
# (一) 是真的款。所以要看到「第」開頭的完整條次，規章名稱也要同一句有「依」才算引用。
# 段首不套這幾條：段首的「一、規定事項如下」是真的第一點。
# S1 匯出時段內的軟換行已經變成空白，查不回「換行後的行首」；前面隔著空白照樣算緊接
# （「第一節 一、規定」多半是打字留的空白，不會是一行只寫「…第一節」就換行）。
# ---------------------------------------------------------------------------
_CITE_UNIT = re.compile(r"第\s*(?:%s|[0-9０-９]{1,3})\s*[章節條點款項目](?:\s*之\s*(?:%s|[0-9０-９]{1,3}))?$"
                        % (ITEM_CN, ITEM_CN))
CITE_ATTACH = ("附表", "附件", "附圖", "附錄")
CITE_VERBS = ("依", "參照", "準用", "詳", "比照", "按", "適用", "如")
CITE_AFTER = ("規定", "辦理", "所定", "所列", "所述", "所稱", "之規定", "準用")
NUM_LIST_AFTER = "、級類等種章節條點款項目"
_NUM_AHEAD = re.compile(r"^\s*(?:%s|[0-9０-９]{1,3})" % ITEM_CN)


def cited_mark(text, a, b, kind=""):
    """text[a:b] 是段落中間的一個編號。是引用或列數字就回原因（給人看的一句話），
    是結構編號回空字串。呼叫端自己判斷段首：段首的編號不要拿來問。"""
    before = (text[:a] or "").rstrip(" \u3000\t")
    after = text[b:] or ""
    mark = text[a:b].strip()
    if before.endswith(CITE_ATTACH):
        return "「%s」前面緊接「%s」，是附表、附圖或附件的編號，不是一點一點的規定" % (mark, before[-3:])
    m = _CITE_UNIT.search(before)
    if m:
        return "「%s」前面緊接「%s」，是在引用別的條次（例如「依…第二章第一節一、規定」）" % (mark, m.group(0))
    if kind in ("A", "C"):
        m = _NUM_AHEAD.match(after)
        if m and (m.end() == len(after) or after[m.end()] in NUM_LIST_AFTER):
            return "「%s」後面只接數字「%s」，是在列數字（例如「一、二、三級」），不是一點一點的規定" % (
                mark, after[:m.end() + 1].strip())
    if after.lstrip().startswith(CITE_AFTER):
        seg = re.split(r"[。；：，;:,]", before)[-1][-40:]
        if any(v in seg for v in CITE_VERBS):
            return "「%s」前面有「%s」、後面接「%s」，是在引用" % (mark, seg[-12:], after.lstrip()[:2])
    return ""
