# -*- coding: utf-8 -*-
"""
共用工具模組。

各支腳本(check_env / renumber / diff_compare / rule_checks / fuzzy_duplicate_finder / run_all)
共用的東西都放這裡，避免同一段讀檔邏輯在三個檔案裡各寫一次、改了一個忘了改另外兩個。

這個檔案不會單獨執行，是被其他腳本 import 用的。
"""

import difflib
import fnmatch
import functools
import io
import os
import re
import sys
import unicodedata
import xml.etree.ElementTree as ET
import zipfile

if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# 給人看的表一律先試 .xlsx，寫表的共用入口在 scripts/xlsx_writer.py（上一層資料夾）。
# 這裡 append 而不是 insert(0)：scripts/run_all.py 跟 regdiff/run_all.py 同名，
# 插到最前面會把「import run_all 拿到哪一支」整個翻掉。
_SCRIPTS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _SCRIPTS_DIR not in sys.path:
    sys.path.append(_SCRIPTS_DIR)
# 所有提醒都要走 notices：印到畫面之外還要留進產出檔（提醒.txt、條文檢查報告、
# 批次摘要）。只印在畫面上的提醒會被後面的輸出洗掉，等於沒提醒。
import notices as nt


# ---------------------------------------------------------------------------
# 主控台編碼
# ---------------------------------------------------------------------------

def setup_console():
    """
    讓中文在 Windows 主控台不要變亂碼。

    Windows 的命令提示字元預設用 cp950(繁中Big5)，Python 印 UTF-8 中文會變成一堆
    問號跟怪符號。這裡把標準輸出改成 UTF-8。Python 3.7 以上才有 reconfigure，
    舊版就用 TextIOWrapper 包一層，兩種都失敗就放棄(只是會亂碼，不影響檔案輸出)。
    """
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name, None)
        if stream is None:
            continue
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except AttributeError:
            try:
                setattr(sys, name, io.TextIOWrapper(
                    stream.buffer, encoding="utf-8", errors="replace"))
            except Exception:
                pass
        except Exception:
            pass


# ---------------------------------------------------------------------------
# 讀檔
# ---------------------------------------------------------------------------

try:
    from docx import Document
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False


SUPPORTED_EXTS = (".docx", ".txt", ".md")


class InputError(ValueError):
    """輸入檔不能用（不存在、舊版 .doc、不支援的副檔名）。

    為什麼要有這個型別：以前這三句話只由 read_paragraphs 用 SystemExit 丟出來，
    而 read_paragraphs 是在 makedirs／stage_inputs *之後*才被呼叫的——檔案格式
    不對的時候，產出資料夾與 輸入/ 已經建好、原始檔也已經複製進去了，使用者
    看到一個「有東西但沒結論」的資料夾，下一輪還會被這些殘骸干擾（見 no 10）。
    拆成可以單獨呼叫的 check_input_file + 可被 except 的例外型別之後，
    各個子命令才能在動任何檔案之前先驗一次。
    """


def check_input_file(path):
    """輸入檔前置驗證：不存在／舊版 .doc／不支援的副檔名一律擋下來（no 10、11）。

    訊息跟 read_paragraphs 原本丟的一字不差——使用者看到的那句話不因為檢查
    提前而改變，既有測試與操作手冊裡的字也都還對得上。
    """
    if not path:
        raise InputError("錯誤：沒有給檔案路徑。")
    if not os.path.exists(path):
        raise InputError("錯誤：找不到檔案 %s\n請確認路徑有沒有打錯，含空白的路徑要用雙引號括起來。" % path)

    if os.path.isdir(path):
        # 資料夾沒有副檔名，走下面那句會印成「不支援的檔案格式 ，目前支援…」，
        # 副檔名欄整格留白——使用者看到的是一句話中間破一個洞，猜不到問題出在
        # 「你給的是資料夾」。批次那條路把整個資料夾拖進來是很常見的操作。
        raise InputError(
            "錯誤：不支援的檔案格式（資料夾）%s，目前支援 %s\n"
            "請改指定資料夾裡的那一份檔案；整批要比對請走 batch 那條路。"
            % (path, "、".join(SUPPORTED_EXTS)))

    ext = os.path.splitext(path)[1].lower()
    if ext == ".doc":
        raise InputError(
            "錯誤：不支援舊版 .doc 格式(Word 97-2003)。\n"
            "請先用 Word 開啟該檔，另存新檔選「Word 文件 (*.docx)」之後再跑一次。")
    if ext not in SUPPORTED_EXTS:
        # 沒有副檔名的檔案同理：那一欄不能留白，不然訊息中間破一個洞。
        raise InputError("錯誤：不支援的檔案格式 %s，目前支援 %s"
                         % (ext or "（沒有副檔名）", "、".join(SUPPORTED_EXTS)))


def read_paragraphs(filepath):
    """
    讀取內規檔案，回傳「段落列表」(每個元素是一段文字，已去掉前後空白、跳過空行)。

    支援 .docx / .txt / .md。
    不支援舊版 .doc(Word 97-2003 二進位格式)，遇到會明確擋下來並告訴使用者怎麼轉檔,
    因為 python-docx 讀不了 .doc，硬讀會拋出看不懂的錯誤訊息。

    .docx 一律用自己的 XML 解析（read_docx_stdlib），不經過 python-docx——
    後者讀不到追蹤修訂的插入文字。詳見該函式的說明。
    """
    # 三種擋法（不存在／.doc／不支援的副檔名）集中在 check_input_file，
    # 各子命令才能在 makedirs／stage_inputs 之前先驗同一套規則。這裡照舊
    # 轉成 SystemExit，直接呼叫 read_paragraphs 的既有路徑行為一字不變。
    try:
        check_input_file(filepath)
    except InputError as exc:
        raise SystemExit(str(exc))

    ext = os.path.splitext(filepath)[1].lower()

    if ext == ".docx":
        # 一律走自己的 XML 解析，不用 python-docx 讀。
        #
        # 為什麼：python-docx 的 paragraph.text 只抓 <w:p> 的直屬 <w:r>，
        # 追蹤修訂的插入文字包在 <w:ins> 裡面，會被整段漏掉。實測一份含追蹤
        # 修訂的檔案，python-docx 讀成「保險費應於繳納。」——插入的「三十日內」
        # 不見了，而且不會報錯，只會安靜地產出一份錯的對照表。
        #
        # 法遵用 Word 追蹤修訂改內規非常常見，這個坑一定會踩到。
        # 兩條讀取路徑並存也是風險：有沒有裝 python-docx 會得到不同的對照表。
        # 所以讀檔只留一條路，python-docx 只負責寫檔。
        return read_docx_stdlib(filepath)

    if ext in (".txt", ".md"):
        raw = open(filepath, "rb").read()
        content = _decode_text(raw, filepath)
        lines = [line.strip() for line in content.splitlines()]
        if ext == ".md":
            stripped = [_strip_markdown_marks(line) for line in lines]
            # 剝掉的是排版標記，不是條文的字；但「產出檔裡的原文」從此是去標記後的
            # 文字，跟使用者手上的 .md 長得不一樣。這件事一定要講，而且要留底——
            # 複核時有人會拿產出對回原檔，看到少了「#」「- 」會以為程式吃掉了字。
            if any(a != b for a, b in zip(lines, stripped)):
                _warn_markdown_stripped(filepath)
            lines = stripped
        return [line for line in lines if line]

    # check_input_file 已經把不支援的副檔名擋掉了，走到這裡代表 SUPPORTED_EXTS
    # 多了一種而上面沒接——留著這行當保險絲，不要安靜回空清單。
    raise SystemExit("錯誤：不支援的檔案格式 %s，目前支援 %s" % (ext, "、".join(SUPPORTED_EXTS)))


def read_paragraphs_with_kinds(filepath):
    """跟 read_paragraphs 讀到一模一樣的段落，另外回傳每一段的來源種類。

    回傳 (段落列表, 種類列表)，兩者等長、同一個順序：
        "p"    本文段落
        "cell" 表格儲存格（一格一段）

    給 build_hierarchy 用：表格的表頭格、備註格不能被算成前一條的「第X項」，
    否則對照表會寫出「第四條第三項」這種文件裡不存在的條號（實測 idx 24／42）。
    .txt／.md 沒有表格，一律回 "p"。read_paragraphs 保持原樣不動，其他呼叫端不受影響。
    """
    ext = os.path.splitext(filepath)[1].lower()
    if ext == ".docx" and os.path.exists(filepath):
        return read_docx_stdlib(filepath, with_kinds=True)
    paragraphs = read_paragraphs(filepath)
    return paragraphs, ["p"] * len(paragraphs)


# markdown 的行首標記是排版，不是條文的字。「# 第一章 總則」跟「第一章 總則」
# 是同一條，不剝掉的話純排版差異會被判成實質修改，假異動直接進正式修正對照表。
_MD_HEADING = re.compile(r"^#{1,6}\s+")
_MD_BULLET = re.compile(r"^[-*+]\s+")


def _warn_markdown_stripped(filepath):
    """同一個檔在一次作業裡會被讀好幾次，提醒只講一次（notices.once 管去重）。

    去重旗標放在 notices 而不是這裡：這裡的模組層旗標要整支程式跑完才會消失，
    批次跑第二本時第二本的提醒會被當成「已經講過」整個吞掉。
    """
    if not nt.once("md:%s" % os.path.abspath(filepath or "")):
        return
    nt.notice(nt.REMINDER,
              "%s 是 .md 來源，行首的「#」標題與「-」清單標記已去除標記，"
              "產出裡的原文是去標記後文字，跟你手上的 .md 不會逐字相同"
              % os.path.basename(filepath or ""), "讀檔")


def _strip_markdown_marks(line):
    """剝掉 .md 的行首標題與清單標記。

    只處理 ATX 標題（#～######）與 -／*／+ 清單。
    數字清單（「1. 」「2) 」）故意不碰：內規裡「1. 條文……」的數字就是條號本身，
    剝掉會把條號吃掉，比不剝更糟。
    """
    line = _MD_HEADING.sub("", line, count=1)
    line = _MD_BULLET.sub("", line, count=1)
    return line.strip()


# 解出來的文字裡有這個比例以上的 U+FFFD（無法解讀的位元組），就當成編碼認錯了。
# 1% 是留給「一份正常的中文內規裡混到一兩個怪字」的餘裕；整份解錯時這個比例
# 動輒兩三成，兩者差很遠，不會誤擋。
_BAD_CHAR_RATIO = 0.01


def _decode_text(raw, filepath=None):
    """
    純文字檔解碼。台灣的內規文字檔常常是 Big5 或 UTF-8-BOM 存的，
    寫死 encoding='utf-8' 會直接 UnicodeDecodeError，所以依序試幾種常見編碼。

    先看 BOM：Word／記事本「另存純文字」選 Unicode 存出來的就是 UTF-16。
    以前沒看 BOM，這種檔會被 cp950 硬吃成亂碼而且不丟例外，整份對照表全錯
    卻一句提醒都沒有；亂碼裡帶的 NUL 還會讓 Word 匯出丟 ValueError 崩掉，
    而此時亂碼的 修正對照表 已經寫到磁碟上了。

    解完一律做一次理智檢查：與其吐一份看起來正常、其實整份錯掉的對照表，
    不如當場擋下來叫人另存 UTF-8。
    """
    if raw[:4] in (b"\xff\xfe\x00\x00", b"\x00\x00\xfe\xff"):
        return _reject_if_garbled(raw.decode("utf-32", errors="replace"), filepath)
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return _reject_if_garbled(raw.decode("utf-16", errors="replace"), filepath)
    for enc in ("utf-8-sig", "utf-8", "cp950", "big5hkscs"):
        try:
            return _reject_if_garbled(raw.decode(enc), filepath)
        except UnicodeDecodeError:
            continue
    return _reject_if_garbled(raw.decode("utf-8", errors="replace"), filepath)


class CsvEncodingError(InputError):
    pass


# Excel 在繁體中文 Windows 用「CSV（逗號分隔）」另存，存出來是 Big5（cp950）；
# 選「CSV UTF-8（逗號分隔）」才是 UTF-8。人一定會另存到其中一種。
EXCEL_ANSI_ENCODINGS = ("cp950", "big5hkscs")


def read_csv_text(path):
    """人會拿 Excel 開、存的 CSV（連帶決定表、人工確認、規章清單）讀成文字：回傳 (文字, 編碼)。

    以前寫死 utf-8-sig：使用者在 Excel 按一次「另存新檔 → CSV（逗號分隔）」，存成 Big5，
    之後每一個指令一開始就停在 UnicodeDecodeError，畫面上看不出是存檔格式的問題，整個流程卡死。
    UTF-8 先試（程式自己寫的都是 UTF-8），再試 Big5；都不是才請人另存。"""
    with open(path, "rb") as f:
        raw = f.read()
    for enc in ("utf-8-sig",) + EXCEL_ANSI_ENCODINGS:
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    raise CsvEncodingError("%s 的編碼認不出來：請用 Excel 另存新檔，存檔類型選「CSV UTF-8（逗號分隔）」"
                           % os.path.basename(path))


def open_csv(path):
    """read_csv_text 的串流版：回傳可以直接交給 csv.DictReader 的物件（也能用 with）。"""
    text, _ = read_csv_text(path)
    return io.StringIO(text, newline="")


def _reject_if_garbled(text, filepath=None):
    """解出來的字明顯不是人寫的文字就擋下來，不要讓亂碼往下流。"""
    if not text:
        return text
    if "\x00" in text or text.count("�") > len(text) * _BAD_CHAR_RATIO:
        raise SystemExit(
            "錯誤：這個純文字檔的編碼認不出來，請用記事本或 Word 另存成 UTF-8 再跑一次。"
            + ("\n檔案：%s" % filepath if filepath else ""))
    return text


# ---------------------------------------------------------------------------
# 條號辨識
# ---------------------------------------------------------------------------

_CN_NUM = "零〇一二三四五六七八九十百千兩"

_ARTICLE_PATTERNS = [
    re.compile(r"^第\s*[%s\d]+\s*條\s*之\s*[%s\d]+" % (_CN_NUM, _CN_NUM)),  # 第五條之一
    re.compile(r"^第\s*[%s\d]+\s*條" % _CN_NUM),                             # 第五條
    re.compile(r"^第\s*[%s\d]+\s*[點項款目章節]" % _CN_NUM),                  # 第三點 / 第二章
    re.compile(r"^[%s]+\s*、" % _CN_NUM),                                    # 一、
    # 壹、貳、參：要點與注意事項類的文件很常拿它當章次。
    # 不收的話那一整層的條號欄會空白，人工核對時看不出這一段在哪一章。
    re.compile(r"^[壹貳參肆伍陸柒捌玖拾]+\s*、"),                            # 壹、
    # 全形括號與半形括號都要收。公文絕大多數寫「（一）」，早期只認半形，
    # 結果最常見的那種反而抓不到，對照表的條號欄整欄空白。
    re.compile(r"^[（(]?\s*[%s\d]+\s*[）)]" % _CN_NUM),                       # （一）/ (一) / (1)
    re.compile(r"^\d+(\.\d+)*\s"),                                           # 1.2.3
    # 作業手冊型文件最常見的寫法：「1.本手冊……」「1、本手冊……」「１．本手冊……」。
    # 它們跟前一條樣式的差別是編號後面沒有空白，早期整批抓不到，後果有兩個：
    # 對照表的條號欄整欄空白；比相似度時 strip_article_no 剝不掉這個前綴，
    # 兩段內容毫不相干的手冊文字光靠共用的「1. 」就把分數從 33.3 拉到 46.7 而過門檻。
    # 後面的 (?!…) 是擋「1.5倍以上」「2.3.1事項」這種不是編號的開頭——
    # 真正的多層編號「1.2.3 」由前一條樣式接（它要求結尾有空白）。
    re.compile(r"^[0-9０-９]+\s*[.、．]\s*(?![0-9０-９.．])"),                  # 1. / 1、/ １．
]


def extract_article_no(text):
    """
    從段落開頭抓出條號，例如「第五條之一 ……」回傳「第五條之一」。
    抓不到就回傳空字串——內規格式五花八門，抓不到是正常的，不要在這裡硬猜，
    寧可留白讓人工填，也不要生一個錯的條號進正式對照表。
    """
    if not text:
        return ""
    for pattern in _ARTICLE_PATTERNS:
        match = pattern.match(text)
        if match:
            # 只去掉條號中間的空白（「第 五 條」->「第五條」），不要動標點。
            # 「一、」的頓號要保留：拿掉之後只剩「一」，在對照表的條號欄裡看不出
            # 那是條號還是內文的第一個字，人工核對時容易誤判。
            return re.sub(r"\s+", "", match.group(0))
    return ""


def article_no_for(old_text, new_text):
    """對照表要顯示的條號：優先取新版的，新版沒有(整段被刪)就取舊版的。"""
    return extract_article_no(new_text or "") or extract_article_no(old_text or "")


# ---------------------------------------------------------------------------
# 外部法規引用
# ---------------------------------------------------------------------------
#
# 「依個人資料保護法第五條第三款辦理」裡的「第五條」不是本規章的第五條，是別人家的。
# 早期 renumber 把它當成本文的引用，--rewrite-refs 就真的把外部法規的條號一起改掉
# （實測 idx 142）。在正式修法文件上把別人的法條號碼寫錯，比漏改嚴重得多，
# 所以這一類引用一律只列出來、不判、不改。
#
# 判斷規則沿用 diffcut/S8_抓引用.py 那一套（NEAR=45、法規全銜的字尾樣式），
# 實作放在 _common 讓兩邊共用同一條規則；不從 regdiff 去 import diffcut，
# 那是兩條各自獨立的管線，互相 import 會把彼此的相依綁死。

EXTERNAL_NEAR = 45        # 往左看幾個字；沿用 S8_抓引用.py 的 NEAR

# 長的字尾排前面，「管理辦法」才不會只被認成「…法」。
_LAW_SUFFIX = (r"(?:自律規範|注意事項|施行細則|條例|辦法|準則|規則|細則|要點|規範|法)")
_QUOTE_TAIL = r"[」』》】〕）)\"'\s]*"
# 名稱上限 40 字：主管機關的辦法常常很長（「保險代理人公司保險經紀人公司內部控制稽核制度及
# 招攬處理制度實施辦法」33 字），以前 14 字會從中間截斷，清單上出現一部不存在的法規
_LAW_NAME = r"[一-鿿]{2,40}%s" % _LAW_SUFFIX

# 法規全銜緊接在「第X條」前面：「…個人資料保護法第五條」
_EXTERNAL_LAW_RE = re.compile(r"(%s)%s$" % (_LAW_NAME, _QUOTE_TAIL))
# 「本辦法第三條」「本要點第五條」講的是這份文件自己，不是外部法規。
# 「本」跟字尾中間可以夾 0～6 個字：「本作業要點」「本管理辦法」「本實施細則」「本處理準則」
# 也是自己。以前只認「本」直接接字尾，這幾種被當成一部叫「作業要點」的外部法規，
# 自己的「依本作業要點第五條第三款」重編後就不改寫（審查 R-A／X18）。
# 三個限制，少一個都會把別人家的法規當成自己、反過來被自動改號：
#   「本公司…辦法」「本行…要點」是同一家公司的另一本內規，不是這一本（「本行為準則」除外），
#     「本國…」講的是國家的法；只有一個字尾「法」的只認「本法」：「本案作法」「本國刑法」
#     都以「法」結尾，放寬的話整串日常用語都會變成「自己」；
#   「本」前一個字要是邊界（句首、標點，或「依」「準用」「違反」這類提示詞的最後一字）——
#     「資本適足性管理辦法」「基本法」裡的「本」是詞的一部分；
#   中間夾的字不能有提示詞、連接詞、條項款或另一個字尾的字——
#     「本要點依保險法」「本辦法施行細則」講的是別的法規。
_OWN_LAW_LEADS = "依按照據循用定稱合觸遵反守酌悉背及與暨和或並且另凡由於在經如對即為從之至"
_OWN_LAW_MIDDLE_STOPS = "依按照據及與暨和或並之所第法則點例範條項款"
_OWN_LAW_NAME = (r"(?:^|(?<=[^一-鿿])|(?<=[%s]))本(?!公司|行(?!為)|國)"
                 r"(?:法|(?:(?![%s])[一-鿿]){0,6}?"
                 r"(?:自律規範|注意事項|施行細則|條例|辦法|準則|規則|細則|要點|規範))"
                 % (_OWN_LAW_LEADS, _OWN_LAW_MIDDLE_STOPS))
_OWN_LAW_RE = re.compile(r"%s%s$" % (_OWN_LAW_NAME, _QUOTE_TAIL))
_OWN_LAW_NAME_RE = re.compile(r"%s$" % _OWN_LAW_NAME)
# 「…保險法第五條、第七條」的第二個條號：前面隔著一個已認定的外部條號加連接詞
_EXTERNAL_CONT_RE = re.compile(
    r"(%s)第\s*[%s\d]+\s*條(?:\s*之\s*[%s\d]+)?"
    r"(?:第\s*[%s\d]+\s*[項款目])*[、及或與和至]\s*$"
    % (_LAW_NAME, _CN_NUM, _CN_NUM, _CN_NUM))

# 往左抓到的字串會連著前面的動詞一起進來（「應依個人資料保護法」「且為避免牴觸
# 公平交易法」），從最右邊的提示詞切掉，留下比較像全銜的那一段。
_LAW_NAME_CUES = ("依據", "依照", "依循", "另依", "按照", "參照", "準用", "適用",
                  "所定", "所稱", "規定", "符合", "牴觸", "抵觸", "遵循", "違反",
                  # 「並應遵守金融消費者保護法」以前整串被當成名稱
                  "遵守", "配合", "比照", "參酌", "悉依", "違背")

# 單字的動詞、介詞：出現在名稱中間就代表前面是句子，從最後一個切開。
# 「準」「自」刻意不列：「內部控制準則」「業務員自律規範」會被切壞。
_LAW_NAME_LEADERS = "依按照本第凡"

# 連接詞只有在最開頭才切。「保險業招攬及核保理賠辦法」本身就含「及」，
# 看到就切會變成「核保理賠辦法」。
_LAW_NAME_CONJUNCTIONS = "及與暨和或、，,"

# 切完可能還黏著「五條及」這種殘骸（原文是「第五條及證券交易法」）
_LAW_NAME_DEBRIS_RE = re.compile(r"^[%s\d]*[條項款目章節][%s]?"
                                 % (_CN_NUM, _LAW_NAME_CONJUNCTIONS))

# 切完之後只留「最後一段長得像全銜」的部分，前面剩下的雜字一律丟掉。
# 字尾前面至少要有一個字：「民法」「刑法」是真的全銜，「法」自己不是；
# 「辦法」「條例」這種光是字尾的，由 _NOT_LAW_NAMES 擋掉。
# 「自律規範」也要收：rule_checks 的外部法規清單本來就認它（保險業務員自律規範）。
_LAW_NAME_TAIL_RE = re.compile(
    r"[一-鿿（）()]{1,40}"
    r"(?:自律規範|注意事項|條例|辦法|準則|規則|細則|要點|規範|法)$")

# 光是字尾，不是名稱。認成外部法規會讓真正該檢查的引用被整句跳過。
_NOT_LAW_NAMES = frozenset((
    "法", "條例", "辦法", "準則", "規則", "細則", "要點", "規範", "注意事項",
    "自律規範"))

# 長得像法規名、其實是日常用語。這一組要比「結尾」而不是比全等：
# 「其處理方法」「本案作法」都得擋掉，但不能連「個人資料保護法施行細則」
# 這種真的以「細則」結尾的全銜一起擋，所以兩組分開。
_NOT_LAW_TAILS = (
    "依法", "合法", "違法", "守法", "非法", "不法", "無法", "立法", "司法",
    "執法", "方法", "做法", "作法", "用法", "說法", "看法", "想法", "此法",
    "如法", "設法", "效法", "手法", "打法", "唱法", "療法")
# 反過來，有幾部真的法規全銜剛好以上面那幾個詞結尾：「公司法」「金融控股公司法」（司法）、
# 「醫療法」（療法）。以前比結尾把它們一起擋掉，renumber 就把「準用公司法第八條第四款」
# 當成本文的款號，自動改寫成「第三款」——在正式文件上寫錯別人的法條（審查 R-R）。
# 這裡不改成「前一個字是邊界字才擋」：那樣「其處理方法」「本案作法」也會放行，
# 等於把上面那組整個廢掉。只放行這幾個確定是法規全銜的結尾。
_LAW_TAIL_EXCEPTIONS = ("公司法", "醫療法")
# 放行「公司法」之後，「本公司法令遵循」「本公司法務室」的「公司法」也會被遮掉，
# 用語檢查就少算一次「公司」。遮全銜時「法」後面緊接這些字，那個「法」是「法令」
# 「法務」的一部分，不是全銜的結尾。只對上面那幾個放行的結尾套用，其餘照舊。
_LAW_WORD_CONTINUATION = tuple("令律人院務遵制")

# 「業務員有保險業務員管理規則第十五條…情事者」：「有」前面是主詞、後面才是名稱。
# 「有」不放進 _LAW_NAME_LEADERS：「國有財產法」的「有」是名稱的一部分，看到就切會變成
# 「財產法」。所以只在「有」前面至少兩個字、後面至少四個字時才切。
_LAW_NAME_HAVE_RE = re.compile(r"^.{2,}有(.{4,})$")

# 「依個人資料保護法及金融消費者保護法第七條」：往左抓到的字串裡有一部全銜接連接詞，
# 連接詞後面那一段才是這一處的名稱。只在連接詞前面剛好是法規字尾時切——
# 「保險業招攬及核保理賠辦法」「證券投資信託及顧問法」的「及」前面是「招攬」「信託」，不切；
# 後面是「其」「同」「該」的（「保險法及其施行細則」）也不切，那不是另一部的全銜。
_LAW_NAME_LIST_RE = re.compile(
    r"^.*(?:自律規範|注意事項|條例|辦法|準則|規則|細則|要點|規範|法)[及與暨和或、]((?![其同該]).{2,})$")

# 登錄表的短名稱剛好是長名稱的結尾：「保險法」之於「全民健康保險法」「強制汽車責任保險法」，
# 「稅法」之於「所得稅法」。以前抓到的字串結尾是登錄名稱就直接回登錄的短名稱，
# 清單上寫成另一部法、交叉引用的報告也指錯法。改成最長比對：剝完前面黏的字之後
# 比登錄名稱長、多出來的前綴又像名稱的一部分，就用長的。「像名稱的一部分」是：
#   至少兩個字、沒有下面這些虛字或連接詞（「應依保險法」剝不乾淨時不會變成「應保險法」）；
#   不是緊接在「本」後面（「本公司消費爭議處理辦法」剝掉「本」剩「公司…」，那是別本內規
#   的寫法，照登錄的名字）。
_LAW_PREFIX_JUNK = frozenset("應有之的為時者係須於並且其該各及與暨和或、，,")


_REGISTRY = []
_EXCLUSIONS = []


def _tables_path(name):
    """tables/ 底下的檔。REG_TABLES_DIR 有設就改用那個資料夾（測試用：自動加登錄表、排除表的
    那幾支測試不能寫到真的 tables/）。"""
    folder = os.environ.get("REG_TABLES_DIR") or os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "tables")
    return os.path.join(folder, name)


EXTERNAL_REGISTRY_FILE = "S8_外部規章表.csv"
EXTERNAL_EXCLUSION_FILE = "外部規章排除表.csv"


def external_exclusions():
    """外部規章排除表 tables/外部規章排除表.csv：長得像法規名、其實不是外部規章的名稱（set）。
    AI 外部引用檢查判「非外部法規」時由 review_import 自動加進來，下一次就不再抓它。"""
    if not _EXCLUSIONS:
        names = set()
        path = _tables_path(EXTERNAL_EXCLUSION_FILE)
        if os.path.isfile(path):
            import csv as _csv
            with io.open(path, encoding="utf-8-sig", newline="") as f:
                for row in _csv.DictReader(f):
                    name = re.sub(r"\s+", "", row.get("名稱") or "")
                    if name:
                        names.add(name)
        _EXCLUSIONS.append(names)
    return _EXCLUSIONS[0]


def _append_table_row(filename, header, row):
    """在 tables/ 底下的表尾加一列（沒有這張表就連表頭一起建）。已經有同名的不加，回傳有沒有加。"""
    import csv as _csv
    path = _tables_path(filename)
    exists = os.path.isfile(path)
    if exists:
        with io.open(path, encoding="utf-8-sig", newline="") as f:
            reader = _csv.DictReader(f)
            header = reader.fieldnames or header
            key = header[0]
            if any(re.sub(r"\s+", "", r.get(key) or "") == row[key] for r in reader):
                return False
        with io.open(path, "rb") as f:
            data = f.read()
        prefix = b"" if not data or data.endswith(b"\n") else b"\r\n"
        with io.open(path, "ab") as f:
            buf = io.StringIO()
            _csv.DictWriter(buf, fieldnames=header, lineterminator="\r\n",
                            extrasaction="ignore").writerow(row)
            f.write(prefix + buf.getvalue().encode("utf-8"))
    else:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
            writer = _csv.DictWriter(f, fieldnames=header, lineterminator="\r\n", extrasaction="ignore")
            writer.writeheader()
            writer.writerow(row)
    del _REGISTRY[:]
    del _EXCLUSIONS[:]
    return True


def add_external_registry(name, category, note=""):
    """把一個外部規章名稱加進登錄表（AI 判「名稱錯誤」「漏抓」時）。回傳有沒有真的加。"""
    return _append_table_row(EXTERNAL_REGISTRY_FILE, ["規章名", "類別", "說明"],
                             {"規章名": re.sub(r"\s+", "", name), "類別": category, "說明": note})


def add_external_exclusion(name, note=""):
    """把一個名稱加進排除表（AI 判「非外部法規」時）。回傳有沒有真的加。"""
    return _append_table_row(EXTERNAL_EXCLUSION_FILE, ["名稱", "說明"],
                             {"名稱": re.sub(r"\s+", "", name), "說明": note})


def external_category(name):
    """登錄表裡這個名稱的類別；沒登錄回空字串。"""
    for registered, category in external_registry():
        if registered == name:
            return category
    return ""


def external_registry():
    """外部規章登錄表 tables/S8_外部規章表.csv：[(規章名, 類別)]，長的名字排前面。

    diff-cut S8（建規格包）與這裡（比對時的外部法規清單、交叉引用排除）共用同一張表。
    表可以自己加，加完下一次執行就生效。讀不到表就是空的，只靠字面規則。"""
    if not _REGISTRY:
        path = _tables_path(EXTERNAL_REGISTRY_FILE)
        entries = []
        if os.path.isfile(path):
            import csv as _csv
            with io.open(path, encoding="utf-8-sig", newline="") as f:
                for row in _csv.DictReader(f):
                    name = re.sub(r"\s+", "", row.get("規章名") or "")
                    if name:
                        entries.append((name, (row.get("類別") or "").strip()))
        entries.sort(key=lambda x: -len(x[0]))
        _REGISTRY.append(entries)
    return _REGISTRY[0]


def is_own_law_name(name):
    """抓到的法規名是不是這份文件自己（「本辦法」「依本作業要點」）。規則見 _OWN_LAW_NAME。
    rule_checks 的外部法規清單用這一支，跟 renumber 的交叉引用判定同一條規則。"""
    return bool(_OWN_LAW_NAME_RE.search(re.sub(r"\s+", "", name or "")))


def clean_law_name(name):
    """把抓到的字串修成法規全銜；判定它根本不是法規名就回空字串。

    rule_checks 的外部法規清單與 renumber 的交叉引用判定共用這一支。
    兩邊各寫一份的話，同一句話在條文檢查報告裡被當成「保險法」、
    在交叉引用檢查裡卻被當成本文自己的引用，兩張產出自相矛盾。
    """
    trimmed = re.sub(r"\s+", "", name or "")
    # 「依本作業要點」「本管理辦法」是這份文件自己。要在剝字之前判：下面會把「本」當成
    # 句子的開頭切掉，切完只剩「作業要點」，就被當成一部外部法規列出來、引用也不改寫
    if _OWN_LAW_NAME_RE.search(trimmed):
        return ""
    stripped = _strip_law_name(trimmed)
    # 登錄表（tables/S8_外部規章表.csv）裡的名字優先：抓到的字串結尾就是某個登錄名稱，
    # 用登錄的全名，不靠剝字規則猜（長的名字排前面，先比先贏）。
    # 例外是剝出來的名稱更長、又以這個登錄名稱結尾（全民健康保險法），見 _LAW_PREFIX_JUNK
    for registered, _ in external_registry():
        if trimmed.endswith(registered):
            if _is_longer_law_name(trimmed, stripped, registered):
                return stripped
            return registered
    return stripped


def _is_longer_law_name(trimmed, stripped, registered):
    """剝出來的名稱是不是登錄名稱再往前多幾個字的另一部法（全民健康保險法之於保險法）。"""
    if not stripped or len(stripped) <= len(registered) or not stripped.endswith(registered):
        return False
    prefix = stripped[:-len(registered)]
    before = trimmed[:len(trimmed) - len(stripped)]
    return (len(prefix) >= 2 and not (set(prefix) & _LAW_PREFIX_JUNK)
            and not before.endswith("本"))


def _strip_law_name(trimmed):
    """把名稱前面黏到的動詞、連接詞、主詞剝掉（規則見 _LAW_NAME_CUES 以下幾組）。
    剝完不像法規名稱就回空字串。trimmed 已經去掉空白。"""
    cut = 0
    for cue in _LAW_NAME_CUES:
        pos = trimmed.rfind(cue)
        if pos >= 0:
            cut = max(cut, pos + len(cue))
    leaders = [i for i, ch in enumerate(trimmed) if ch in _LAW_NAME_LEADERS]
    if leaders:
        cut = max(cut, leaders[-1] + 1)
    trimmed = trimmed[cut:]
    have = _LAW_NAME_HAVE_RE.match(trimmed)
    if have:
        trimmed = have.group(1)

    trimmed = _LAW_NAME_DEBRIS_RE.sub("", trimmed)
    while trimmed and trimmed[0] in _LAW_NAME_CONJUNCTIONS:
        trimmed = trimmed[1:]
    listed = _LAW_NAME_LIST_RE.match(trimmed)
    if listed:
        trimmed = listed.group(1)

    match = _LAW_NAME_TAIL_RE.search(trimmed)
    if not match:
        return ""                      # 「應依」＋「法」這種切完只剩一個字，不是法規名
    trimmed = match.group(0)
    if trimmed in _NOT_LAW_NAMES:
        return ""
    if trimmed.endswith(_NOT_LAW_TAILS) and not trimmed.endswith(_LAW_TAIL_EXCEPTIONS):
        return ""
    if re.match(r"^本%s$" % _LAW_SUFFIX, trimmed):
        return ""                      # 「本辦法」是這份文件自己
    if trimmed in external_exclusions():
        return ""                      # AI 查證過不是外部規章（排除表）
    return trimmed


# 遮法規全銜用的樣式：跟 _LAW_NAME_TAIL_RE 同一份字尾，差別只在不釘 $，
# 這樣才能在一整段話裡把每一個全銜都掃出來。抓到的那一段還是交給
# clean_law_name 判一次——「本公司應依下列方法辦理」也吃得到字尾「法」，
# 不判就會把「方法」前面三十個字一起遮掉。
_LAW_NAME_SCAN_RE = re.compile(
    r"[一-鿿（）()]{1,30}"
    r"(?:自律規範|注意事項|條例|辦法|準則|規則|細則|要點|規範|法)")


def mask_law_names(text, filler="○"):
    """把整段話裡的法規全銜遮成等長的替代字元。回傳遮過的字串。

    為什麼要遮（實測 no 26）：用語混用檢查用 whole.count(term) 純字串計數，
    內規只要引用到「保險業務員管理規則」，裡面那三個字「業務員」就被算成
    「這份內規混用了業務人員與業務員」，每跑一次固定誤報一筆；照著建議改下去
    還會把別人家的法規全銜改錯。全銜是引用的專有名詞，不是這份內規的用語。

    長度一定要保住：遮成空字串會讓後面所有詞的位置跟原文對不起來。
    """
    if not text:
        return text
    pieces = []
    last = 0
    for match in _LAW_NAME_SCAN_RE.finditer(text):
        name = clean_law_name(match.group(0))
        if not name:
            continue                   # 「下列方法」「本辦法」這種，不是別人家的全銜
        if name.endswith(_LAW_TAIL_EXCEPTIONS) and \
                text[match.end():match.end() + 1] in _LAW_WORD_CONTINUATION:
            continue                   # 「本公司法令遵循」：是「法令」，不是「公司法」
        start = match.end() - len(name)
        if start < last:
            continue
        pieces.append(text[last:start])
        pieces.append(filler * len(name))
        last = match.end()
    if not pieces:
        return text
    pieces.append(text[last:])
    return "".join(pieces)


# ---------------------------------------------------------------------------
# 定義用語的樣式
# ---------------------------------------------------------------------------
#
# 條文檢查（rule_checks 的定義用語）與同本「舊值搜尋」（fuzzy_duplicate_finder 的定義舊名、
# row_assist 的定義改名）共用這一份。以前各寫一份：最常見的定義清單
# 「本要點用詞，定義如下：一、網路投保：指…」條文檢查認不得，改了定義不報連動；
# 「所稱之高齡客戶」被抓成「之高齡客戶」，「所稱業務員係指」被抓成「業務員係」。
# 每一個樣式的第 1 組都是被定義的那個詞。

# 詞裡不會有標點、引號、括號、空白
_DEF_TERM = r"[^「」『』，,：:、。；;\s（）()]"
# 清單那一款的詞不能含「所稱」：不然「本要點所稱高齡客戶：指」會多抓一個「本要點所稱高齡客戶」
_DEF_TERM_BARE = r"(?:(?!所稱|所謂)%s)" % _DEF_TERM
# 「指」後面接這些字是別的詞（指定、指派、指示、指導…），不是定義用的「指」
_DEF_VERB = r"(?:係指|指(?![定派示導揮出明標數引摘紋])|謂)"
# 款、目的編號：一、　（一）　1.　(1)
_DEF_ITEM_NO = r"(?:[一二三四五六七八九十]+[、.．]|[（(][一二三四五六七八九十]+[）)]|\d+[.．、]|[（(]\d+[）)])"
# 清單的一款從段首、或冒號句號後面開始（「定義如下：一、A：指…。二、B：指…」寫在同一段）
_DEF_ITEM_START = r"(?:^|(?<=[：:。；;\s]))"

DEFINED_TERM_RES = (
    # 「本要點所稱高齡客戶，指」「本手冊所稱之高齡客戶，係指」「前項所稱「關係人」：指」
    re.compile(r"所(?:稱|謂)之?\s*[「『]?(%s{2,12})[」』]?\s*[，,：:]\s*%s" % (_DEF_TERM, _DEF_VERB)),
    # 沒有逗號的「所稱業務員係指」：詞取最短的，「係」才不會被算進詞
    re.compile(r"所(?:稱|謂)之?\s*[「『]?(%s{2,12}?)[」』]?\s*(?:係指|謂)" % _DEF_TERM),
    # 「「關係人」，指」
    re.compile(r"[「『](%s{2,12})[」』]\s*[，,：:]?\s*%s" % (_DEF_TERM, _DEF_VERB)),
    # 定義清單的一款：「一、網路投保：指」「（一）電子保單：係指」
    re.compile(r"%s(?:%s\s*)?[「『]?(%s{2,12})[」』]?\s*[：:]\s*%s"
               % (_DEF_ITEM_START, _DEF_ITEM_NO, _DEF_TERM_BARE, _DEF_VERB)),
)
# 用逗號的那一款（「一、網路投保，指」）：只有在「用詞，定義如下」底下才認。
# 一般條文的款也可能寫成「二、要保人，指…」以外的意思，沒有標題撐著就不當定義
DEFINED_LIST_ITEM_RE = re.compile(r"%s%s\s*[「『]?(%s{2,12})[」』]?\s*[，,]\s*%s"
                                  % (_DEF_ITEM_START, _DEF_ITEM_NO, _DEF_TERM_BARE, _DEF_VERB))
# 定義清單的標題：「本要點用詞，定義如下：」「本辦法用詞定義如下」「下列用詞定義如下」「名詞定義」
DEFINITION_LIST_HEADER_RE = re.compile(r"定義如下|(?:用詞|用語|名詞)[，,]?(?:之)?定義")
# 段首就是款目編號的段落：定義清單到第一個不是這種開頭的段落為止
DEFINITION_LIST_ITEM_START_RE = re.compile(r"^\s*%s" % _DEF_ITEM_NO)


# ---------------------------------------------------------------------------
# XML 不合法字元
# ---------------------------------------------------------------------------
#
# .docx 與 .xlsx 裡面都是 XML。XML 1.0 只允許 Tab、換行、歸位，加上三段可列印
# 區間（第 2.2 節），其餘一律不合法——包含 U+FFFE、U+FFFF 與未配對的代理字。
# 不先清掉的話（實測 no 32）：
#     寫 docx  python-docx 底下的 lxml 直接丟例外，使用者看到十幾層 traceback，
#              而且 CSV／TXT 已經寫出去了，資料夾裡留下版本對不起來的半套產出
#     寫 xlsx  純字串組 XML 不會丟例外，寫出來的 .xlsx 打不開，程式卻回報成功
# 兩邊都過這一支，而且拿掉幾個字元一定要講——那是使用者原稿裡真的存在的字。

XML_CLEANUP_NOTICE = ("已移除 %d 個 XML 不允許的字元（原稿裡的控制字元或未定義字），"
                      "其餘內容一字不動")


def xml_allows(ch):
    """這個字元 XML 1.0 收不收。用碼位判，不寫成含跳脫序列的字串樣式——
    那種樣式在不同工具之間搬運時會被改掉（實測整段變成真的換行字元）。"""
    code = ord(ch)
    return (code in (0x09, 0x0A, 0x0D)
            or 0x20 <= code <= 0xD7FF        # 到代理區之前
            or 0xE000 <= code <= 0xFFFD      # 代理區之後，不含 U+FFFE／U+FFFF
            or 0x10000 <= code <= 0x10FFFF)  # 輔助平面


def sanitize_for_xml(text, filler=""):
    """去掉 XML 1.0 不允許的字元。回傳 (清乾淨的字串, 拿掉幾個)。

    未配對的代理字（U+D800–U+DFFF）也在拿掉之列：它落在允許區間之外。
    """
    if not text:
        return text, 0
    kept = []
    removed = 0
    for ch in text:
        if xml_allows(ch):
            kept.append(ch)
        else:
            removed += 1
            if filler:
                kept.append(filler)
    if not removed:
        return text, 0
    return "".join(kept), removed


def is_external_reference(text, span):
    """「第X條」前面接的是不是別人家的法規全銜。

    text 是整段原文，span 是那個「第X條」在原文的起訖位置。
    是外部法規就回傳法規名（給報告顯示用），不是就回傳空字串。

    只認「全銜緊接在『第』前面」這一種寫法（中間可以隔引號或空白）。
    放寬成「45 字內出現過法規名就算」會把「本要點第三條所定事項，準用保險法規定」
    這種本文自己的引用也吃掉，那等於整份文件都不檢查了。
    """
    start = span[0] if isinstance(span, (tuple, list)) else span
    if not text or start <= 0:
        return ""
    window = text[max(0, start - EXTERNAL_NEAR):start]
    if not window or _OWN_LAW_RE.search(window):
        return ""
    match = _EXTERNAL_LAW_RE.search(window) or _EXTERNAL_CONT_RE.search(window)
    if not match:
        return ""
    return clean_law_name(match.group(1))


# ---------------------------------------------------------------------------
# 輸出路徑
# ---------------------------------------------------------------------------

def resolve_output(outdir, prefix, filename):
    """
    組出輸出檔完整路徑，並確保資料夾存在。

    有 prefix 的話會加在檔名前面(例如 prefix='壽險內規' -> '壽險內規_修正對照表.xlsx')，
    這樣連續比對好幾份內規時不會後面一份把前面一份的結果蓋掉。

    去向由 place()（也就是 FILE_HOMES 那張表）決定：檔案落在
    <outdir>/審閱文件／填寫表單／系統檔案 其中一格，不再平鋪在 outdir 底下。
    沒有登記去向的檔名會當場炸（見 home_of），寧可炸也不要默默放錯格。

    一律回傳絕對路徑。有些 AI 平台的產出檔案不會顯示在對話裡，使用者得自己
    去資料夾找；印「.\結果彙整\修正對照表.xlsx」這種相對路徑等於沒講，
    得寫完整路徑他才找得到。
    """
    return os.path.abspath(place(outdir or ".", filename, prefix))


# ---------------------------------------------------------------------------
# 產出四格資料夾（結果彙整／審閱文件／填寫表單／系統檔案）
# ---------------------------------------------------------------------------
#
# 產出資料夾以前是平鋪的：十幾個檔案全部塞在同一層，使用者分不出哪個要看、
# 哪個要填、哪個是程式接力用的中繼檔。這裡把每個產出檔名登記去向，同一張表
# 程式跟測試都用（見 reg/tests/_paths.py 的 P()），改去向只改這一張表。
#
# 四格名稱一字不差：
#   結果彙整（最終使用者要的成品：標註版全文、修正對照表、檢視報告）
#   審閱文件（過程中要看的報告與留底的稽核紀錄：套用報告、提醒、候選明細、定稿……）
#   填寫表單（人要填的表）
#   系統檔案（程式接力用、人不太需要動的中繼檔）
# 結果彙整是後來從審閱文件分出來的：審閱文件一輪下來十幾個檔，真正要交出去的
# 只有那三類，其餘是留著備查的稽核紀錄，混在一起人找不到要交的那幾份。

RESULT_DIR, REVIEW_DIR, FILL_DIR, SYSTEM_DIR = "結果彙整", "審閱文件", "填寫表單", "系統檔案"
OUTPUT_DIRS = (RESULT_DIR, REVIEW_DIR, FILL_DIR, SYSTEM_DIR)

# 有些檔案會先被 resolve_output 加上「最終版」之類的前綴（批次驗收時把某一本
# 標成最終版）。home_of 判斷去向前要先把這個前綴剝掉，不然「最終版_修正對照表.xlsx」
# 對不到「修正對照表.xlsx」的規則，會被誤判成沒登記的檔名。
KNOWN_PREFIXES = ("最終版_",)

# [(fnmatch 樣式, 格名), ...]，順序即優先序（目前規則彼此不重疊，順序只是保留
# 跟需求對照表一致，方便以後加規則時對照）。
FILE_HOMES = [
    # 結果彙整
    ("修正對照表.xlsx", RESULT_DIR),
    ("修正對照表.docx", RESULT_DIR),
    ("修正對照表.csv", RESULT_DIR),          # 退路（xlsx 寫不出來時）
    ("標註版全文.docx", RESULT_DIR),
    ("標註版全文.txt", RESULT_DIR),           # 退路
    ("檢視報告.xlsx", RESULT_DIR),
    ("檢視報告_*.csv", RESULT_DIR),          # 退路
    # 終比對之後放進來的新版定稿（run_all._settle_result_folder 從 審閱文件/ 複製一份）
    ("新版定稿_追蹤修訂.docx", RESULT_DIR),
    ("新版定稿_乾淨版.docx", RESULT_DIR),
    # 結果彙整只留要交的那一套：終比對之後初比對那一套改名「初比對_」移進審閱文件；
    # 重跑初比對時，上一輪留在結果彙整的最終版改名「上一輪_」移進審閱文件
    ("初比對_*", REVIEW_DIR),
    ("上一輪_*", REVIEW_DIR),
    # 批次裡整本沒改的那一本：結果彙整只放一張說明，空的對照表改名「無異動_」移進審閱文件
    # （見 run_all._settle_unchanged_book）
    ("本次未修改.txt", RESULT_DIR),
    ("無異動_*", REVIEW_DIR),
    # AI 對異動本身標了需再檢查時，人要回覆的那張表（見 review_import.write_confirmations）
    ("異動確認.csv", FILL_DIR),               # 舊名；現在併進 人工確認.csv
    # AI 查不到、要人回覆的全部在這一張：異動本身、條文檢查高風險、外部引用無法查證
    ("人工確認.csv", FILL_DIR),
    ("AI條文檢查.csv", FILL_DIR),
    ("AI條文檢查.new.csv", FILL_DIR),
    ("條文檢查待查證.json", SYSTEM_DIR),
    ("LLM條文檢查清單.md", SYSTEM_DIR),
    # 審閱文件
    ("條文檢查報告.xlsx", REVIEW_DIR),
    ("條文檢查報告.csv", REVIEW_DIR),
    ("候選明細.xlsx", REVIEW_DIR),
    ("候選明細_*.csv", REVIEW_DIR),
    ("規格包連帶複核.xlsx", REVIEW_DIR),
    ("規格包連帶複核.csv", REVIEW_DIR),
    ("終比對候選表.xlsx", REVIEW_DIR),
    ("終比對候選表.csv", REVIEW_DIR),
    ("終比對驗收報告.txt", REVIEW_DIR),
    ("套用報告.txt", REVIEW_DIR),
    ("新版_定稿.docx", REVIEW_DIR),
    ("新版_定稿_乾淨版.docx", REVIEW_DIR),
    ("重編後_*", REVIEW_DIR),
    ("LLM審查報告.xlsx", REVIEW_DIR),
    ("LLM審查報告_*.csv", REVIEW_DIR),
    ("LLM審查總表.xlsx", REVIEW_DIR),
    ("LLM審查總表_*.csv", REVIEW_DIR),
    ("批次摘要.txt", REVIEW_DIR),
    ("批次驗收摘要.txt", REVIEW_DIR),
    ("人工待辦.txt", REVIEW_DIR),             # 現在要人做的事（todo.py）
    ("核准預覽.txt", REVIEW_DIR),             # 核准會怎麼決定（人工待辦順手寫，決定表不動；approve.write_preview）
    ("發布紀錄.txt", REVIEW_DIR),             # 哪一天發布了哪幾本、換下來的在哪（publish_round）
    ("已發布.json", SYSTEM_DIR),              # 這一輪已經發布（人工待辦、繼續 看它）
    ("*提醒.txt", REVIEW_DIR),
    ("執行紀錄.txt", REVIEW_DIR),            # 批次每一本的詳細過程（見 run_all.BookLog）
    # 填寫表單
    ("連帶決定表.csv", FILL_DIR),
    ("AI候選判斷.csv", FILL_DIR),
    ("AI異動審查.csv", FILL_DIR),
    ("AI候選判斷.new.csv", FILL_DIR),
    ("AI異動審查.new.csv", FILL_DIR),
    ("AI外部引用.csv", FILL_DIR),             # AI 外部規章引用檢查（review_pack._external_pack）
    ("AI外部引用.new.csv", FILL_DIR),
    # 系統檔案
    ("連帶決定表.json", SYSTEM_DIR),
    # 終比對候選表本身是給人看的表（審閱文件/），它的指紋檔跟決定表的指紋檔一樣
    # 是程式接力用的中繼檔，一律進 系統檔案/（見 decision_table.sidecar_path_for）。
    ("終比對候選表.json", SYSTEM_DIR),
    ("異動清單.json", SYSTEM_DIR),
    ("語意輸入.json", SYSTEM_DIR),
    ("語意候選.csv", SYSTEM_DIR),
    ("LLM審查包_*.md", SYSTEM_DIR),
    ("LLM異動清單.md", SYSTEM_DIR),
    ("LLM外部引用清單.md", SYSTEM_DIR),
    ("修訂驗證.json", SYSTEM_DIR),               # apply 後自動驗修訂的結果（run_all._verify_applied）
    ("修改依據.json", SYSTEM_DIR),               # 對照表幾列草擬、幾列請補（change_reasons）
    ("跨本未列.json", SYSTEM_DIR),               # 開始時因跨本上限沒列的段（驗收不算新候選）
    ("AI審查紀錄.json", SYSTEM_DIR),             # 這一次 AI 審的是哪些列、異動（人工待辦判斷 AI 審查做過沒）
    ("輸入來源.json", SYSTEM_DIR),               # 這一本的現行規章、修訂版在哪裡（人工待辦用來發現被改過）
    ("輸入", SYSTEM_DIR),                     # 資料夾
    ("歷次", SYSTEM_DIR),                     # 資料夾
]


def home_of(filename):
    """檔名（或資料夾名）該放哪一格，回傳格名；對不到表就炸，寧可當場炸也不要默默放錯格。"""
    name = filename
    for pre in KNOWN_PREFIXES:
        if name.startswith(pre):
            name = name[len(pre):]
            break
    for pattern, home in FILE_HOMES:
        if fnmatch.fnmatch(name, pattern):
            return home
    raise ValueError("沒有登記去向的檔名：%s" % filename)


# 產出/系統檔案/ 底下本來就有的資料夾，規章名不能跟它們同名
BATCH_RESERVED = OUTPUT_DIRS + ("輸入", "歷次", "語意候選", "AI審查")


def book_dir(root, name, legacy=True):
    """批次裡一本的過程檔資料夾：<產出根>/系統檔案/<規章名>/（底下是審閱文件／填寫表單／系統檔案）。

    產出根目錄第一層是 結果彙整／審閱文件／填寫表單／系統檔案：送簽文件排在 結果彙整/<種類>/<規章名>_…，
    整批彙總在 審閱文件/，各本的過程檔收進 系統檔案/<規章名>/。
    上一版放在 <產出根>/<規章名>/：讀的時候（legacy=True）新位置還沒有、舊位置有就用
    舊位置，舊的產出資料夾接著跑 batch-apply／batch-finalize 才找得到決定表；
    batch 重新產出時傳 legacy=False，一律寫新位置（舊的那一份 archive_previous 會收進歷次）。
    """
    new = os.path.join(root, SYSTEM_DIR, name)
    old = os.path.join(root, name)
    if legacy and not os.path.isdir(new) and os.path.isdir(old):
        return old
    return new


def batch_root_of(outdir):
    """outdir 是批次裡的某一本就回 <產出根>，不是就回 None。

    一本的位置是 <產出根>/系統檔案/<規章名>/（上一版是 <產出根>/<規章名>/）。
    認法：產出根有 batch 留底的 規章清單.csv（系統檔案/輸入/，或舊排法平鋪的 輸入/）。
    batch 一開始、逐本比對之前就會把清單留底，所以每一本的第一個產出寫出去時它已經在了。
    """
    outdir = os.path.abspath(outdir)
    name = os.path.basename(outdir)
    if not name or name in BATCH_RESERVED:
        return None
    parent = os.path.dirname(outdir)
    candidates = [parent]
    if os.path.basename(parent) == SYSTEM_DIR:
        candidates.insert(0, os.path.dirname(parent))
    for root in candidates:
        for marker in (os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv"),
                       os.path.join(root, "輸入", "規章清單.csv")):
            if os.path.isfile(marker):
                return root
    return None


def result_home(outdir):
    """結果彙整在哪：一律 <outdir>/結果彙整/。

    批次時每一本的 outdir 是 產出/系統檔案/<規章名>/，所以這裡是那一本內部的結果彙整；
    人看的 產出/結果彙整/ 由 result_publish 在每個批次指令結束後，照文件種類分資料夾、
    各規章放一起排出來（標註版全文／新版定稿（乾淨版）／新版定稿（追蹤修訂）／修正對照表）。
    """
    return os.path.join(outdir, RESULT_DIR)


def _home_dir(outdir, home):
    return result_home(outdir) if home == RESULT_DIR else os.path.join(outdir, home)


def output_paths(outdir):
    """四格＋根目錄的路徑，不建資料夾（真的要用哪一格再由 place() 建）。"""
    return {
        "結果": result_home(outdir),
        "審閱": os.path.join(outdir, REVIEW_DIR),
        "填寫": os.path.join(outdir, FILL_DIR),
        "系統": os.path.join(outdir, SYSTEM_DIR),
        "根": outdir,
    }


def _homed_name(filename, prefix):
    home = home_of(filename)
    name = "%s_%s" % (prefix, filename) if prefix else filename
    return home, name


def place(outdir, filename, prefix=""):
    """目的路徑 <outdir>/<格>/<prefix>_<filename>；格資料夾不存在就建。"""
    home, name = _homed_name(filename, prefix)
    sub = _home_dir(outdir, home)
    if not os.path.isdir(sub):
        os.makedirs(sub)
    return os.path.join(sub, name)


def archived_file(outdir, filename):
    """「開始」歸檔進 <outdir>/系統檔案/歷次/ 的最新一輪裡的 filename（照 FILE_HOMES 的格子找）；
    沒有回 ""。重跑開始之後，AI 判過的答案、人工確認的回覆要從這裡帶回來。"""
    history = os.path.join(outdir, SYSTEM_DIR, "歷次")
    if not os.path.isdir(history):
        return ""
    home = home_of(filename)
    for stamp in sorted(os.listdir(history), reverse=True):
        for candidate in (os.path.join(history, stamp, home, filename),
                          os.path.join(history, stamp, filename)):
            if os.path.isfile(candidate):
                return candidate
    return ""


def locate(outdir, filename, prefix=""):
    """
    讀檔用：先找 place() 會給的新位置，不存在再找舊平鋪（<outdir>/<prefix>_<filename>）。

    回傳 (path, is_legacy)。都沒有就回 (place 路徑, False)，讓呼叫端照「應該要在的
    新位置」去處理找不到檔案的錯誤訊息。不像 place()，這裡不建資料夾——單純找路徑
    不該有副作用。
    """
    home, name = _homed_name(filename, prefix)
    new_path = os.path.join(_home_dir(outdir, home), name)
    if os.path.exists(new_path):
        return new_path, False
    # 批次的一本：前一版把成品放在 <本>/結果彙整/，那一份照樣讀得到
    older = os.path.join(outdir, home, name)
    if older != new_path and os.path.exists(older):
        return older, False
    legacy_path = os.path.join(outdir, name)
    if os.path.exists(legacy_path):
        return legacy_path, True
    return new_path, False


def warn_legacy_layout(outdir):
    """讀到舊排法（平鋪、沒分三格）的產出資料夾時提醒一次；同一個 outdir 只講一次。

    走 notice_pending 而不是 notice：「這個資料夾是舊排法」是**作業開始之前**就成立的
    事實，而 apply／review-pack 這幾步一開始都會 nt.reset() 清空提醒清單。用 notice()
    的話畫面上有這一句、提醒.txt 裡卻沒有——那份檔案才是留得住的那一份。
    notice_pending 收在 _pending，reset() 不清，第一次 write_notices 會把它寫進去。
    """
    if not nt.once("legacy:" + outdir):
        return
    nt.notice_pending(nt.REMINDER,
                      "%s 是舊排法的產出資料夾（檔案平鋪、沒有分「審閱文件／填寫表單／系統檔案」），"
                      "這次照舊讀；新產出仍寫進三格，建議重跑 compare 換成新排法" % outdir,
                      "輸出排法")


# ---------------------------------------------------------------------------
# 讀 .xlsx（純 stdlib）
# ---------------------------------------------------------------------------
#
# 寫 .xlsx 在 scripts/xlsx_writer.py，讀放這裡：給人看的表改成 xlsx 之後，
# 分步流程的 fuzzy_duplicate_finder --from-csv 要讀得回修正對照表，測試也要
# 讀得回產出檔（reg/tests/_paths.read_xlsx_rows 轉呼叫這一支）。
# 一樣不裝套件：.xlsx 就是一個 zip，裡面幾個 XML。

_XLSX_NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
_XLSX_RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"


def _xlsx_col_index(ref):
    """儲存格參照（如 "B2"）換成 0 起算的欄索引。"""
    letters = "".join(ch for ch in ref if ch.isalpha())
    index = 0
    for ch in letters:
        index = index * 26 + (ord(ch.upper()) - ord("A") + 1)
    return index - 1


def _xlsx_shared_strings(archive):
    if "xl/sharedStrings.xml" not in archive.namelist():
        return []
    tree = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    return ["".join(t.text or "" for t in si.findall(".//m:t", _XLSX_NS))
            for si in tree.findall("m:si", _XLSX_NS)]


def _xlsx_sheet_part(archive, sheet):
    """工作表名 → zip 裡的 XML 路徑。沒給名字就第一張。"""
    if not sheet:
        return "xl/worksheets/sheet1.xml"
    workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    targets = {node.get("Id"): node.get("Target") or "" for node in rels}
    names = []
    for node in workbook.findall("m:sheets/m:sheet", _XLSX_NS):
        names.append(node.get("name"))
        if node.get("name") == sheet:
            target = targets.get(node.get(_XLSX_RID), "")
            return target if target.startswith("xl/") else "xl/" + target.lstrip("/")
    raise ValueError("%s 裡沒有工作表「%s」（有的是：%s）"
                     % (os.path.basename(getattr(archive, "filename", "") or "xlsx"),
                        sheet, "、".join(n for n in names if n)))


def xlsx_sheet_names(path):
    """一份 .xlsx 有哪些工作表（照活頁簿裡的順序）。"""
    with zipfile.ZipFile(path) as archive:
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    return [node.get("name") for node in workbook.findall("m:sheets/m:sheet", _XLSX_NS)]


def read_xlsx_rows(path, sheet=None):
    """把 .xlsx 的一張工作表讀成 list[list[str]]（含標題列）。

    sheet 給工作表名就讀那一張，不給就讀第一張。數字格也一律回字串——
    這一支是給「核對表上寫了什麼」用的，不是給算數用的。
    """
    with zipfile.ZipFile(path) as archive:
        shared = _xlsx_shared_strings(archive)
        tree = ET.fromstring(archive.read(_xlsx_sheet_part(archive, sheet)))
        rows = []
        for row in tree.findall(".//m:sheetData/m:row", _XLSX_NS):
            cells = {}
            for position, cell in enumerate(row.findall("m:c", _XLSX_NS)):
                ref = cell.get("r") or ""
                index = _xlsx_col_index(ref) if ref else position
                kind = cell.get("t")
                if kind == "s":
                    value = cell.find("m:v", _XLSX_NS)
                    text = shared[int(value.text)] if value is not None and value.text else ""
                elif kind == "inlineStr":
                    inline = cell.find("m:is", _XLSX_NS)
                    text = ("".join(t.text or "" for t in inline.findall(".//m:t", _XLSX_NS))
                            if inline is not None else "")
                else:
                    value = cell.find("m:v", _XLSX_NS)
                    text = value.text if value is not None and value.text is not None else ""
                cells[index] = text
            width = (max(cells) + 1) if cells else 0
            rows.append([cells.get(i, "") for i in range(width)])
        return rows


def read_xlsx_dicts(path, sheet=None):
    """同 read_xlsx_rows，但用第一列當欄名回 list[dict]（欄名重複時後者覆蓋前者）。"""
    rows = read_xlsx_rows(path, sheet)
    if not rows:
        return []
    header = rows[0]
    out = []
    for row in rows[1:]:
        out.append({name: (row[i] if i < len(row) else "")
                    for i, name in enumerate(header)})
    return out


# ---------------------------------------------------------------------------
# 多檔原子寫出
# ---------------------------------------------------------------------------

TMP_SUFFIX = ".tmp"


def display_path(path):
    """印給人看的路徑。

    走 AtomicWrites 的時候，寫檔函式收到的是「正式路徑 + .tmp」，
    它們印「已產生…：<路徑>」時要顯示正式檔名——畫面上出現
    「標註版全文.docx.tmp」使用者會去找一個根本不會留下來的檔案。
    """
    text = str(path)
    if text.endswith(TMP_SUFFIX):
        return text[:-len(TMP_SUFFIX)]
    return text


class AtomicWrites(object):
    """把多個目的檔先寫到同資料夾的 .tmp，全部成功才逐一 os.replace。

    為什麼需要（實測 no 12）：一次比對要寫好幾份檔（修正對照表.xlsx、標註版全文.docx
    或 .txt、修正對照表.docx），舊寫法是一份一份直接覆寫正式檔名。第三份
    失敗時前兩份已經被新內容蓋掉，資料夾裡變成「兩份新的、兩份上一輪的舊的」，
    看的人完全分不出哪幾份是這一次的。

    用法：
        with AtomicWrites() as aw:
            write_csv(results, aw.path(csv_path))
            export_docx(results, aw.path(docx_path))
        # 離開 with 且沒例外 → 全部 os.replace 到正式路徑

    aw.path(final) 回傳 final + ".tmp"（同資料夾，os.replace 才不會跨磁碟）。
    寫函式「沒有產生檔案」的情況（例如 export_to_docx 遇到不支援格式時不寫）
    → commit 時該 .tmp 不存在就跳過，不算失敗。
    """

    def __init__(self):
        self._pairs = []          # [(tmp 路徑, 正式路徑)]

    def path(self, final):
        """登記一個目的檔，回傳要實際寫進去的 .tmp 路徑。"""
        final = os.path.abspath(final)
        tmp = final + TMP_SUFFIX
        folder = os.path.dirname(tmp)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        if (tmp, final) in self._pairs:
            # 同一個目的檔在同一次 with 裡登記第二次：那份 .tmp 是這一輪自己剛寫好的
            # 內容，不是上一輪的殘骸。清掉的話第一次寫進去的東西就沒了，commit 時
            # 那一份變成「沒產生檔案」而整個跳過，正式檔停在上一輪的舊內容。
            return tmp
        # 上一輪中斷留下來的 .tmp 先清掉：留著的話 commit 會把上一輪的殘骸
        # 當成這一次的產物 replace 上去（寫函式這次沒寫成功也照樣搬）。
        self._remove(tmp)
        self._pairs.append((tmp, final))
        return tmp

    @staticmethod
    def _remove(tmp):
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass

    def rollback(self):
        """把所有 .tmp 刪掉，正式檔一個都不動。"""
        for tmp, _final in self._pairs:
            self._remove(tmp)

    def commit(self):
        """逐一 os.replace 到正式路徑，回傳實際搬過去的正式路徑清單。

        replace 途中失敗（例如某一份正在 Word 裡開著、被鎖住）沒辦法回滾：
        前面幾份已經是新的了。這時把剩下還沒搬的 .tmp 刪掉，例外照樣往外丟，
        由呼叫端印「[中止]」——寧可少幾份也不要留下一堆 .tmp 讓人以為有產出。
        """
        pairs, self._pairs = self._pairs, []
        moved = []
        for index, (tmp, final) in enumerate(pairs):
            if not os.path.exists(tmp):
                continue          # 寫函式這次沒產生這一份（例如沒裝 python-docx）
            try:
                os.replace(tmp, final)
            except OSError:
                for rest_tmp, _rest_final in pairs[index:]:
                    self._remove(rest_tmp)
                raise
            moved.append(final)
        return moved

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if exc_type is not None:
            self.rollback()
            return False          # 例外照原樣往外丟
        self.commit()
        return False


# ---------------------------------------------------------------------------
# 比對用文字正規化
# ---------------------------------------------------------------------------

# 只差字形或空白的那一類異動，對照表上要叫它什麼。
# 放在這裡是因為 diff_compare（產生它）與 fuzzy_duplicate_finder（讀對照表時
# 要跳過它）兩邊都得認得同一個字串，各寫一份遲早會對不起來。
COSMETIC_LABEL = "僅字形／空白差異"


@functools.lru_cache(maxsize=20000)
def normalize_for_compare(text):
    """比對用的文字正規化，**只給比對用**（寫進產出檔的原文一律保留原字）。

    做三件事：
      1. NFKC：全形英數與符號轉半形，「３０日」與「30日」、「５％」與「5%」
         正規化之後是同一個字串。
      2. 全形空格 U+3000 轉成半形空格（NFKC 本來就會轉，這裡明寫一次，
         免得日後有人改成別的正規化形式時這條保證跟著消失）。
      3. 連續空白摺疊成一個，頭尾空白去掉。

    為什麼需要：比對以前拿原始字串照字面比，於是
      -「第一條 甲」對「第一條　甲」只差一個空格，被標成「編號調整」進正式
        修正對照表，可是兩邊的條號一個字都沒變；
      - 同一種空白差異落在句中時更糟，直接升格成「實質異動（修改）」，
        對照表兩欄印出來肉眼完全一樣，複核的人看不出改了什麼；
      -「３０日」與「30日」被數值檢查當成兩個不同的值，純字形統一被列成
        【高】實質數值變更。

    注意：不要把這個函式搬到 read_paragraphs／_docx_paragraph_text 去做全域
    空白折疊。apply_changes 是拿 docx_annotate 讀回來的段落原文去跟決定表的
    「候選全文」做字面相等比對，讀檔端單方面正規化會讓套用階段大量出現
    「跳過（原文不符）」。正規化只能發生在「比」的那一刻。

    純函式，結果只看輸入，所以用 lru_cache 記住——一次比對同一段文字會被
    反覆正規化很多次（difflib、對齊、條號比對各要一次）。

    零寬字元（U+200B 等）一律拿掉：從網頁、PDF 貼過來的條文常夾著看不見的零寬空格，
    NFKC 不會動它，以前「保險費\u200b應於」對「保險費應於」被判成實質修改，
    數值檢查也會把「3\u200b0日」切成兩個數字。
    """
    if not text:
        return ""
    plain = _ZERO_WIDTH_RE.sub("", unicodedata.normalize("NFKC", text)).replace("　", " ")
    return re.sub(r"\s+", " ", plain).strip()


# 看不見、也不佔位的字：零寬空格／連接／不連接、詞連接、BOM、軟連字號。
_ZERO_WIDTH_RE = re.compile("[\u200b\u200c\u200d\u2060\ufeff\u00ad]")

# 中日韓文字與全形符號（NFKC 之後還留著的那些：漢字、「」、、。、注音、假名、相容漢字）。
# 中文字之間本來就不空格；這種字旁邊的空白是排版留下的，不是內容。
_CJK_CLASS = ("\u2e80-\u2fff\u3000-\u303f\u3040-\u30ff\u3100-\u312f\u3190-\u31ff"
              "\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\ufe30-\ufe4f\uff00-\uffef")
_SPACE_BY_CJK_RE = re.compile(" (?=[%s])|(?<=[%s]) " % (_CJK_CLASS, _CJK_CLASS))


@functools.lru_cache(maxsize=20000)
def normalize_for_diff(text):
    """異動偵測（diff_compare）用：normalize_for_compare 之外，再拿掉中文字旁邊的空白。

    為什麼不直接併進 normalize_for_compare：那一支別處（數值檢查、條文檢查、語意候選）
    也在用，而且有測試保證「甲　乙」正規化成「甲 乙」；異動偵測要的是「只差空白算不算改」，
    標準比較嚴，分開一支，誰要用誰明說。

    拿掉的是「至少一邊是中文字或全形符號」的空白：「第 五 條」對「第五條」、「保險費 應於」
    對「保險費應於」、「一 、身分證明文件」對「一、身分證明文件」、「3 日內」對「3日內」都是
    排版差異，以前判成「修改」或「編號調整」進正式對照表，兩欄印出來看不出差在哪。
    兩邊都是英數字的空白（「ISO 9001」「Article 5」）是內容，留著。
    """
    plain = normalize_for_compare(text)
    if " " not in plain:
        return plain
    return _SPACE_BY_CJK_RE.sub("", plain)


def strip_article_no(text):
    """
    把段落開頭的條號拿掉，只留條文本體。

    比相似度時要用這個。原因：條號本身不是條文內容，卻會干擾分數。
    「第三條 逾期未繳超過三十日者……」跟「第二十二條 保險費未於到期日後未繳納者……」
    是同一件事寫在不同章節，但光是「第三條」對「第二十二條」這幾個字就先扣掉一截分數。
    實測拿掉條號後，真正相關的條文分數幾乎不變(53.1 -> 51.3)，不相干的條文卻從
    22~32 掉到 11~18，訊號雜訊比明顯拉開。
    """
    if not text:
        return ""
    article_no = extract_article_no(text)
    if not article_no:
        return text

    cursor = _prefix_end(text, article_no)
    return text[cursor:].lstrip(" 　、：:．.") or text


def _prefix_end(text, article_no):
    """extract_article_no 回傳的是去掉空白後的字串：從原文往前走同樣多的「非空白字元」。"""
    consumed = 0
    cursor = 0
    while cursor < len(text) and consumed < len(article_no):
        if not text[cursor].isspace():
            consumed += 1
        cursor += 1
    return cursor


# 阿拉伯數字後面接這些字，是數量不是編號：「30 日」「1.5 倍」「3 萬元」
_QUANTITY_UNITS = "日天月年週周時分秒倍%％元萬千百個人次件位名家歲度成折張頁份"
# 「第X條」後面接這些才是條號本身（標題、分隔）；接「規定」「所定」就是句子在引用
_HEADING_FOLLOW = " \u3000\t（(、：:．.「"


def strip_numbering_prefix(text):
    """比 strip_article_no 嚴：只拿掉「真的是編號」的段首，判「編號調整」用（A3）。

    strip_article_no 是給相似度用的，寬一點無妨；拿來判「這一段只是換了編號」就太寬：
    段首「第五條規定，於本條準用之」的「第五條」是引用、「30 日內」「1.5 倍」是數量，
    剝掉之後「第五條→第六條」「30 日→60 日」都被當成編號調整——不算異動、不出候選、
    條文檢查跳過，修改依據還自動寫「配合條次調整」。
    """
    if not text:
        return ""
    article_no = extract_article_no(text)
    if not article_no:
        return text
    cursor = _prefix_end(text, article_no)
    after = text[cursor:]
    if article_no.startswith("第"):
        if after and after[0] not in _HEADING_FOLLOW:
            return text
    elif re.match(r"^[0-9０-９]+([.．][0-9０-９]+)?$", article_no):   # 1.2.3 兩個點以上一定是編號
        rest = after.lstrip(" \u3000\t")
        if rest and (rest[0] in _QUANTITY_UNITS or rest[0].isdigit()):
            return text
    return after.lstrip(" 　、：:．.") or text


def diff_runs(old_text, new_text, min_equal=2):
    """
    比對同一條的新舊文字，回傳字級的標記片段：[(種類, 文字), ...]
    種類是 "equal"／"delete"／"insert"。

    為什麼要做到字級：
    整段刪掉再整段加回來，人得把兩行從頭讀到尾自己找出差在哪。實際上第一條
    只改了「一百十五年」五個字，對照表就該只標那五個字，其餘維持黑字。
    這也是修正對照表本來的閱讀方式。

    min_equal：夾在兩處修改中間、短到沒有意義的相同片段（預設少於 2 個字），
    直接併進修改範圍。否則中文很容易標成一串紅黑相間的碎屑，反而看不出改了什麼。
    但不是每個短片段都該併（審查第三批「差異標示偶爾多標幾字」），見 _short_equal_action。

    回傳的片段一定還原得回兩邊原文：equal＋delete＝舊文、equal＋insert＝新文
    （標註版在原檔上重寫段落、套用修訂都靠這一條）。
    """
    old_text, new_text = old_text or "", new_text or ""
    matcher = difflib.SequenceMatcher(None, old_text, new_text, autojunk=False)  # autojunk 關掉：200 字以上的段落，常用字會被當成雜訊，改 2 字標出幾百字（B4）
    # 一段一段：["eq", 相同的字, ""] 或 ["chg", 刪掉的字, 新增的字]。
    # 同一個修改區塊裡，先把刪掉的字全部列完，再列新增的字（chg 一格裝兩邊）。
    # 不這樣的話會交錯。實測「十五日」改「三十日」：中間的「十」兩邊都有，
    # 被拆成 新增三／刪除十／新增十／刪除五，畫面上是紅字一個插一個，
    # 人得自己把它們重新拼回「十五」跟「三十」才知道改了什麼。
    # 分開之後就是「刪除 十五、新增 三十」，跟修正對照表本來的讀法一致，
    # 而且對照表的原條文欄只顯示刪除、修正後條文欄只顯示新增，
    # 分組之後那兩欄各自才是讀得通的完整句子。
    segs = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            segs.append(["eq", old_text[i1:i2], ""])
        elif segs and segs[-1][0] == "chg":
            segs[-1][1] += old_text[i1:i2]
            segs[-1][2] += new_text[j1:j2]
        else:
            segs.append(["chg", old_text[i1:i2], new_text[j1:j2]])

    # 夾在兩處修改中間的短片段：併、留、或挪位（段落頭尾的不動）
    k = 1
    while k < len(segs) - 1:
        seg = segs[k]
        if (seg[0] != "eq" or len(seg[1]) >= min_equal
                or segs[k - 1][0] != "chg" or segs[k + 1][0] != "chg"):
            k += 1
            continue
        left, right, same = segs[k - 1], segs[k + 1], seg[1]
        action, side = _short_equal_action(left, right, same)
        if action == "keep":
            # 前後還得是站得住的相同片段（夠長，或到段頭段尾）：整句改寫裡也會有
            # 「三→四」這種一對一的小格子，旁邊卻全是碎字，那種照舊併掉
            before = segs[k - 2][1] if k >= 2 else None
            after = segs[k + 2][1] if k + 2 < len(segs) else None
            if ((before is not None and len(before) < min_equal)
                    or (after is not None and len(after) < min_equal)):
                action = "merge"
        if action == "keep":
            k += 1
            continue
        if action == "slide_right":
            # 「新增 A、相同。、新增 B。」＝「新增 A。B、相同。」：相同的字挪到後面跟下文接起來
            block = ["chg", "", ""]
            block[side] = left[side] + same + right[side][:-len(same)]
            tail = ["eq", same, ""]
            if k + 2 < len(segs) and segs[k + 2][0] == "eq":
                tail[1] += segs[k + 2][1]
                del segs[k + 2]
            segs[k - 1:k + 2] = [block, tail]
            k = max(1, k - 2)
            continue
        if action == "slide_left":
            block = ["chg", "", ""]
            block[side] = left[side][len(same):] + same + right[side]
            if k >= 2 and segs[k - 2][0] == "eq":
                segs[k - 2][1] += same
                segs[k - 1:k + 2] = [block]
                k = max(1, k - 2)
            else:
                segs[k - 1:k + 2] = [["eq", same, ""], block]
                k = 1
            continue
        segs[k - 1:k + 2] = [["chg", left[1] + same + right[1], left[2] + same + right[2]]]
        k = max(1, k - 1)

    # 攤平；相鄰同種類的片段合併起來，避免產生一堆零碎的 run
    out = []
    for kind, removed, added in segs:
        pieces = [("equal", removed)] if kind == "eq" else [("delete", removed), ("insert", added)]
        for name, text in pieces:
            if not text:
                continue
            if out and out[-1][0] == name:
                out[-1] = (name, out[-1][1] + text)
            else:
                out.append((name, text))
    return out


def _short_equal_action(left, right, same):
    """兩處修改中間夾一個短的相同片段 same 時怎麼辦：("merge"|"keep"|"slide_right"|"slide_left", 哪一邊)。

    left／right 是 ["chg", 刪掉的字, 新增的字]。以前一律併（merge），量 532 組標準答案時
    有兩種併錯，紅字把沒改的字也標了：
      一、兩邊各自是一對一的小替換（「一百十三年一月一日」→「一百十四年七月一日」）：
          中間的「年」兩邊都在、位置也對得上，是真的沒改；併掉會標成「三年一→四年七」。
          這種留著（keep），只標「三→四」「一→七」。
      二、兩邊都只是新增（或都只是刪除）：「。」被對到新增那一大段中間的句號，
          併掉會變成「刪除。、新增…。」——舊文明明一個字沒刪。這種把相同的字挪到
          新增那段的頭或尾（字串一樣，只是換一個等價的對法），舊文就不會被標刪除。
    一邊只新增、一邊只刪除（「十五→三十」中間的「十」）是兩邊剛好有同一個字、對歪了，
    照舊併成「十五→三十」；其餘（整句改寫裡的零碎巧合）也照舊併，免得紅黑相間。
    """
    l_ins, l_del = not left[1] and bool(left[2]), bool(left[1]) and not left[2]
    r_ins, r_del = not right[1] and bool(right[2]), bool(right[1]) and not right[2]
    if (l_ins and r_ins) or (l_del and r_del):
        side = 2 if l_ins else 1
        if right[side].endswith(same):
            return "slide_right", side
        if left[side].startswith(same):
            return "slide_left", side
        return "merge", None
    if all(1 <= len(block[1]) == len(block[2]) <= 2 for block in (left, right)):
        return "keep", None
    return "merge", None


# ---------------------------------------------------------------------------
# 層級脈絡（章／節／條／項／款／目）
# ---------------------------------------------------------------------------

_CHAPTER_RE = re.compile(r"^第\s*([%s\d]+)\s*章" % _CN_NUM)
_SECTION_RE = re.compile(r"^第\s*([%s\d]+)\s*節" % _CN_NUM)
_ARTICLE_RE = re.compile(r"^第\s*[%s\d]+\s*條(\s*之\s*[%s\d]+)?" % (_CN_NUM, _CN_NUM))
_CLAUSE_RE = re.compile(r"^([%s]+)\s*、" % _CN_NUM)              # 款：一、二、三、
_ITEM_RE = re.compile(r"^[（(]\s*([%s\d]+)\s*[）)]" % _CN_NUM)    # 目：(一)(二)(三)
# 點：「1.」「1、」「１．」──要點、辦法、作業手冊最常見的第三層編號，夾在款與目中間。
# 後面緊接另一個數字的（「1.2.3」「1. 2 人以上」）不收：那是多層編號或內文數字，
# 收進來會讓每個「1.x」都變成同一個「第1點」，反而撞號。
_POINT_RE = re.compile(r"^([0-9０-９]+)\s*[.．、](?!\s*[0-9０-９])")
POINT_RE = _POINT_RE          # renumber.scan 要用同一個物件，不要各寫一份

# 這幾種開頭代表「這一段在講前面的項」，所以它自己一定是新的一項，
# 不是上一款的折行：「前項文件之保存期限，依下列規定：」後面接的一、二、
# 是第二項的款，跟第一項的款不是同一組。
_NEW_PARAGRAPH_CUE_RE = re.compile(r"^(前[%s各]*項|第\s*[%s\d]+\s*項)" % (_CN_NUM, _CN_NUM))
# 沒有「前項」開頭的新項：上一段以句號收尾、這一段自己是完整句子（見 build_hierarchy
# 的 starts_new_paragraph）。冒號、分號也算這一段收得了尾——「申請人有下列情形之一者，
# 應予退件：」是新的一項的引言；但上一段以冒號收尾時，這一段是它的續行。
_SENTENCE_CLOSED_RE = re.compile(r"[。！？!?][」』）)]*$")
_SENTENCE_ENDED_RE = re.compile(r"[。！？!?：:；;][」』）)]*$")
_SENTENCE_OPENING_STOPS = "，、。；：,;:）)」』"
# 往後找「下一個有編號的段落」最多看幾段：款與款之間的說明通常一兩段，看太遠會跨到別處
_NEXT_NUMBER_LOOKAHEAD = 8

# 段首的「第X條」後面接這些字時，這一段是在「引用」某一條，不是在「宣告」某一條。
# 實測（20 情境掃描 idx 17）四種寫法全部被誤判成宣告：
#   「第五條規定，於本條準用之。」「第七條第二項所定期間……」
#   「第十條至第十二條之規定……」「第十條第二項所定文件……」
# 誤判的代價是整串款目改掛到一個文件裡不存在的條號底下，直接寫進正式修正對照表。
# 這份清單刻意獨立成常數，日後遇到新的引用寫法直接加一個詞就好。
_ARTICLE_CITATION_TAILS = ("規定", "所定", "所稱", "所列", "準用",
                           "但書", "前段", "後段", "本文", "各款", "各目",
                           "中所", "中規定", "有關",
                           "至", "第", "及", "與", "或", "、", "，", ",", "；", ";")
# 條號後面接這些字就一定是宣告，不必再看引用詞。
# 空字串「""」代表 tail 是空的，也就是整段只有條號（「第三條」自成一段）。
# 「、」「，」不列入：真正的條文標題不會寫成「第五條、……」，那是引用的列舉寫法。
_ARTICLE_HEAD_SEPARATORS = ("", " ", "　", "\t", "：", ":", "．", ".")


# 章節標題：跟切條那邊（scripts/diffcut/_heading.py）同一套規則
_HEADING_SEPARATORS = "、：:．. \u3000"
_HEADING_CONTINUATION = ("所", "之", "的", "規定", "第", "及", "或", "與", "至", "中所", "內所",
                         "，", ",", "；", ";", "。")


def _is_heading(text, match):
    """段首的「第三章」是章標題，還是句子在引用（「第三章所定之表單…」，B3）。"""
    if not match:
        return False
    rest = text[match.end():].lstrip(_HEADING_SEPARATORS)
    return not rest or not (rest.startswith(_HEADING_CONTINUATION) or "。" in rest or len(rest) > 30)


def _is_article_declaration(text, match, seen_articles=()):
    """段首的「第X條」是「宣告這一條」還是「引用那一條」。

    seen_articles 是這一份文件前面已經宣告過的條號集合。

    判斷順序：
    1. 條號後面接「之」而且不是「之＋數字」（那種已經被 _ARTICLE_RE 吃進條號了）
       → 引用：「第五條之規定」「第五條之一部」講的都是別條。
    2. 後面接引用詞（_ARTICLE_CITATION_TAILS）→ 引用。
    3. 後面是分隔符或整段只有條號 → 宣告（真的條文標題絕大多數長這樣）。
    4. 這個條號前面已經宣告過，而且後面沒有分隔符 → 引用。
       同一個條號不會在同一份文件裡宣告兩次，但很常被引用（「第五條情形之一者…」）。
    5. 其餘一律算宣告，例如「第五條本規則自發布日施行。」這種沒有分隔符的標題——
       只靠第 3 條規則會把它判掉，那等於憑空少掉一條，比誤收更糟。

    第 4 條刻意排在第 3 條後面：「第五條　……」這種有分隔符的重複條號要留給
    rule_checks 的「條號重複」去報（那是高風險發現，實測資料真的會出現誤植兩次的條）。
    """
    tail = text[match.end():]
    if tail.startswith("之"):
        return False
    if any(tail.startswith(word) for word in _ARTICLE_CITATION_TAILS):
        return False
    if tail[:1] in _ARTICLE_HEAD_SEPARATORS:
        return True
    if re.sub(r"\s+", "", match.group(0)) in seen_articles:
        return False
    return True


# 「（第N組）」是 build_hierarchy 在「同一款裡編號重新起算」時加的區隔標記，
# 不是文件裡真的條號。它必須留在內部（審查包、決定表靠 ref 當錨點），
# 但不能出現在送出去會簽的修正對照表上。
_GROUP_MARK_RE = re.compile(r"（第\d+組）")
# display_ref 拿掉過標記的 ref 記在 notices（只給提醒用）。放在那裡而不是這裡的
# 模組層，是因為它的生命週期要跟「一次作業」一致：批次的第二本要重新算一次，
# 不然第二本的提醒會用到第一本的數字，或整個被當成「已經講過」而不印。
GROUP_MARKER_KEY = "group_marker_stripped"


def display_ref(ref):
    """正式產出（修正對照表 CSV／Word）的條號欄要寫的字：拿掉「（第N組）」。

    拿掉之後同一款裡重新起算的兩組會出現一樣的條號，所以一定要同時提醒
    （warn_if_group_markers_stripped），叫人改用「新版段次」欄定位。

    只拿掉程式加的「（第N組）」，文件自己的寫法一個字都不動——阿拉伯數字的目
    在 build_hierarchy 就寫成文件原樣「(1)」，半形括號跟這裡要剝的全形「（第」
    不會互相誤傷，所以對照表條號欄、審查包 ref 與決定表的鍵是同一個寫法。
    """
    if not ref or "（第" not in ref:
        return ref
    plain = _GROUP_MARK_RE.sub("", ref)
    if plain != ref:
        nt.remember(GROUP_MARKER_KEY, ref)
    return plain


def warn_if_group_markers_stripped():
    """提醒印一次就好：同一次執行會先寫 CSV 再寫 Word，兩邊都會呼叫這一支。"""
    stripped = nt.remembered(GROUP_MARKER_KEY)
    if not stripped or not nt.once("group_marker_warned"):
        return
    nt.notice(nt.REMINDER,
              "有 %d 段的編號在同一款內重新起算（例：%s），對照表的條號欄會有兩列一模一樣，"
              "請改用「新版段次」欄定位"
              % (len(stripped), stripped[0]), "條號層級")
    print("      對照表的條號欄會有兩列一模一樣，無法唯一定位。這種段落多半是被程式")
    print("      看不到的小標題分成兩組，請改用「新版段次」欄定位並人工確認。")


def build_hierarchy(paragraphs, kinds=None):
    """
    走一遍全文，算出每一段所在的層級位置。

    為什麼需要這個：
    條號只看單一段落是不夠的。「(二)」單獨拿出來看毫無意義——一份 50 頁的內規
    裡有幾百個「(二)」，對照表寫「條號：(二)」等於沒寫，人工核對時根本找不到
    它在哪一條底下。必須從頭往下走，記住現在走到第幾章、第幾節、第幾條，
    才能把它還原成「第三十三條第一款第二目」這種找得到的引用。

    kinds 是與 paragraphs 等長的來源種類（read_paragraphs_with_kinds 回傳的
    "p" 本文段落／"cell" 表格儲存格）；不給就當成整份都是本文段落，行為與以前相同。
    儲存格自己沒有編號時一律算「其他」，而且**不遞增項次**——表格的表頭格、備註格
    被算成前一條的「第X項」，對照表就會寫出「第四條第三項」這種文件裡不存在的條號
    （實測 idx 24／42）。格內自己寫著「第八條　……」時照常認得，不受影響。

    層級由上而下：章／節／條／項／款（一、）／點（1.）／目（(一)、(1)）。
    「點」是手冊最常見的第三層，以前認不得（ref 留白），同一款底下不同小群的
    「(1)」還會拿到一模一樣的條號（實測 idx 46／50）。

    款底下的子層**照出現順序**堆疊，不寫死「款＞點＞目」：同一份手冊裡
    「一、／(一)／1.」與「一、／1.／(一)」兩種寫法都有，寫死順序的話後者的
    ref 會把層級對調，同一款不同小群還是會撞號。

    沒有編號的段落分兩種：
      * 這一條還沒開過款／點／目 → 新的一項（項次進 ref）。
      * 已經開過了 → 那是款目的折行補充，level「其他」、ref 沿用目前最內層，
        而且**不重設任何東西**。以前一律當成新的一項，折行一插進來，
        後面的目就從第一目重新算，新舊版同一段的條號因此對不起來。
      * 例外：段落自己以「前項」「第二項」開頭時，它就是在講前面的項，
        那是真的新的一項（「前項文件之保存期限，依下列規定：」）。

    回傳與 paragraphs 等長的列表，每個元素是 dict：
        chapter / section / article  ── 所在的章、節、條（字串，沒有就空字串）
        ref                          ── 完整條號引用，例如「第三十三條第一款第二目」
        level                        ── 章／節／條／項／款／點／目／其他
        group_serial                 ── 這一段開的那一層是第幾組（編號重新起算才 > 1）

    ref 裡的「（第N組）」是程式加的區隔標記，不是文件裡的條號：寫進正式產出之前
    要先用 display_ref() 拿掉，並印 warn_if_group_markers_stripped() 的提醒。
    """
    contexts = []
    chapter = section = article = ""
    paragraph_no = 0     # 條底下第幾項（條文本身算第一項）
    stack = []           # 這一項底下已經開了哪些子層，(層級, ref 片段)，照出現順序
    seen_articles = set()
    last_number = {}     # (上層路徑, 層級) → 上一個看到的號碼
    last_index = {}      # (上層路徑, 層級) → 上一個同層標題在第幾段（判斷中間有沒有夾東西）
    group_no = {}        # (上層路徑, 層級) → 現在是第幾組（編號重新起算就 +1）

    def para_part():
        """項次寫進 ref 的部分。第一項照法制慣例不寫，第二項起一定要寫，
        否則第二項底下的款目會跟第一項的撞號（實測 idx 18）。"""
        return "第%s項" % cn_from_int(paragraph_no) if paragraph_no > 1 else ""

    def prefix():
        """ref 的前綴：有條就用條；沒有條的規章（作業手冊）用章＋節。
        只取其中一個的話，每一章都有「第一節」的手冊會整份撞號。"""
        return article or (chapter + section)

    def stack_ref():
        return prefix() + para_part() + "".join(part for _, part in stack)

    def open_sub(level_name, part, number=None, index=None):
        """開一個新的子層：同層或比它更深的（也就是在這一款裡比它晚開的）先收掉。

        number 是這一段自己寫的號碼。號碼沒有往上走時有兩種可能，必須分開：

        一、**編號重新起算**：整組跑完又從頭開始（1、2、3、4 之後出現 1），
            或兩組中間隔著別的東西（沒有編號的引言、更深一層的目）。
            手冊裡這通常是被一個程式看不到的小標題分成兩組。兩組的編號一模一樣，
            ref 就會撞號，對照表上兩段不同的條文拿到同一個條號。這時在 ref 後面加
            「（第N組）」——程式加的區隔標記，不是文件裡的條號，但每一段都定位得到。
        二、**真的重號**：使用者刪了一款忘了重編，「一、」後面又接一個「一、」，
            中間什麼都沒有。這是必須報出來的缺陷，不能靜悄悄地拆成兩組蓋掉，
            所以這種情形不加標記，留給 renumber 的編號檢查去抓。
        """
        for position, (opened, _) in enumerate(stack):
            if opened == level_name:
                del stack[position:]
                break
        key = (tuple(fragment for _, fragment in stack), level_name)
        if number is not None:
            previous = last_number.get(key)
            previous_index = last_index.get(key)
            if previous is not None and number <= previous:
                restarted_from_one = number == 1 and previous > 1
                separated = (previous_index is not None and index is not None
                             and index > previous_index + 1)
                if restarted_from_one or separated:
                    group_no[key] = group_no.get(key, 1) + 1
            else:
                group_no.setdefault(key, 1)
            last_number[key] = number
            if index is not None:
                last_index[key] = index
        serial = group_no.get(key, 1)
        if serial > 1:
            part += "（第%d組）" % serial
        stack.append((level_name, part))
        return serial

    def reset_groups():
        """換條、換項、換章節：編號本來就重新起算，不算「重新起算的另一組」。"""
        last_number.clear()
        last_index.clear()
        group_no.clear()

    def is_cell_at(position):
        return bool(kinds) and position < len(kinds) and kinds[position] == "cell"

    def continues_current_list(index):
        """往後找下一個有編號的段落：它接著目前這一組的下一號，中間這段就只是款與款之間的說明。"""
        in_clause_now = any(opened == "款" for opened, _ in stack)
        for later in range(index + 1, min(len(paragraphs), index + 1 + _NEXT_NUMBER_LOOKAHEAD)):
            if is_cell_at(later):
                continue
            following = paragraphs[later]
            if (_is_heading(following, _CHAPTER_RE.match(following))
                    or _is_heading(following, _SECTION_RE.match(following))):
                return False
            article_head = _ARTICLE_RE.match(following)
            if article_head and _is_article_declaration(following, article_head, seen_articles):
                return False
            if _NEW_PARAGRAPH_CUE_RE.match(following):
                return False
            clause_head = _CLAUSE_RE.match(following)
            point_head = _POINT_RE.match(following)
            item_head = _ITEM_RE.match(following)
            if clause_head:
                level_name, number = "款", cn_to_int(clause_head.group(1))
            elif point_head and in_clause_now:
                level_name, number = "點", cn_to_int(point_head.group(1))
            elif item_head:
                raw_item = unicodedata.normalize("NFKC", item_head.group(1))
                level_name = "目（阿拉伯）" if raw_item.isdigit() else "目（中文）"
                number = cn_to_int(item_head.group(1))
            else:
                continue                # 又是一段沒編號的，再往下看
            for position, (opened, _) in enumerate(stack):
                if opened == level_name:
                    key = (tuple(fragment for _, fragment in stack[:position]), level_name)
                    previous = last_number.get(key)
                    return previous is not None and number == previous + 1
            # 下一個編號是更深一層、這一組還沒開過（「(一)」接在說明後面）：目不會直接掛在
            # 項底下，那段說明是款的一部分。下一個是款卻不在堆疊裡，才算新的一項
            return level_name != "款"
        return False

    def starts_new_paragraph(index, text):
        """款目後面那一段沒有編號、也不是「前項」開頭：是款的折行，還是這一條的下一項。

        以前一律當折行，「二、身分證明文件。」後面接「申請人所附文件不齊備者，應通知補正。」
        對照表就寫成「第四條第二款」，其實那是第二項（審查第 10 項）。判成新的一項要三件事都成立：
          一、上一段以句號收尾——那一款寫完了。上一段以「：」或沒有標點收尾時，這一段是它的
              續行或折行（「一、申請人應檢附下列文件：」「一、乙」後面那段），照舊沿用上一款；
          二、這一段自己是完整的句子（句號、冒號、分號收尾，不以標點開頭）；
          三、後面緊接的編號不是目前這組的下一號。「一、甲。」「本款所稱甲，指丙。」「二、丁。」
              中間那段是款與款之間的說明，當成新項的話「二、丁」會掛到第二項底下，
              後面每一款的條號整串換掉，renumber 還會以為第二項的款從二起跳。
        只在有「第X條」的文件裡判（呼叫端檢查）：沒有條的手冊沒有「項」可言。
        """
        if index == 0 or is_cell_at(index - 1):
            return False
        previous = paragraphs[index - 1].strip()
        body = text.strip()
        if not _SENTENCE_CLOSED_RE.search(previous):
            return False
        if len(body) < 4 or body[0] in _SENTENCE_OPENING_STOPS or not _SENTENCE_ENDED_RE.search(body):
            return False
        return not continues_current_list(index)

    for index, text in enumerate(paragraphs):
        is_cell = bool(kinds) and index < len(kinds) and kinds[index] == "cell"
        group_serial = 1     # 這一段開的那一層是第幾組（編號重新起算才會 > 1）

        chapter_match = _CHAPTER_RE.match(text)
        section_match = _SECTION_RE.match(text)
        if not _is_heading(text, chapter_match):
            chapter_match = None      # 「第三章所定之表單…」是內文，不是章標題
        if not _is_heading(text, section_match):
            section_match = None
        article_match = _ARTICLE_RE.match(text)
        if article_match and not _is_article_declaration(text, article_match,
                                                         seen_articles):
            article_match = None      # 是引用句，往下落到「項」那一支
        clause_match = _CLAUSE_RE.match(text)
        item_match = _ITEM_RE.match(text)
        point_match = _POINT_RE.match(text)
        if is_cell:
            # 儲存格裡的「一、」「1.」「(一)」是那一格自己的編號，不是全文的層級。
            # 一張表的每一列都會重複同一組編號，收進來整張表就會撞號
            # （實測 A新.docx 有一張表讓 9 段拿到同一個「第十章第八款第四目第2點」）。
            # 格內寫著「第八條　……」的條文宣告仍然照常認得，那是真的條號。
            clause_match = item_match = point_match = None
        in_clause = any(opened == "款" for opened, _ in stack)

        if chapter_match:
            chapter = re.sub(r"\s+", "", chapter_match.group(0))
            section = article = ""
            paragraph_no = 0
            del stack[:]
            reset_groups()
            level, ref = "章", chapter
        elif section_match:
            section = re.sub(r"\s+", "", section_match.group(0))
            article = ""
            paragraph_no = 0
            del stack[:]
            reset_groups()
            level, ref = "節", chapter + section
        elif article_match:
            article = re.sub(r"\s+", "", article_match.group(0))
            seen_articles.add(article)
            paragraph_no = 1
            del stack[:]
            reset_groups()
            level, ref = "條", article
        elif clause_match:
            # 新的一款，整組子層重來
            del stack[:]
            group_serial = open_sub("款", "第%s款" % clause_match.group(1),
                                    cn_to_int(clause_match.group(1)), index)
            level, ref = "款", stack_ref()
        elif point_match and in_clause:
            # 「1.」只在款底下才自成一層；條底下直接寫「1.」時維持原本行為（當成項），
            # 那種文件的「1.」其實是項的序號，硬塞一層反而多生一個假層級。
            group_serial = open_sub(
                "點", "第%s點" % unicodedata.normalize("NFKC", point_match.group(1)),
                cn_to_int(point_match.group(1)), index)
            level, ref = "點", stack_ref()
        elif item_match:
            # 「(一)」與「(1)」是兩個不同的層：手冊裡「(一)／1.／(1)」三層套著寫很常見，
            # 當成同一層的話，(1) 會把上面的「(一)」與「1.」一起收掉，
            # 每一組的 (1) 都變成同一個「第二款(1)」——實測 A新.docx 有 11 段撞在一起。
            raw_item = unicodedata.normalize("NFKC", item_match.group(1))
            # 阿拉伯數字的目寫文件自己的樣子「(1)」，不套中文條號模板：
            # 「第1目」是中英數混用的四不像，法規上沒有這種寫法，而這個字串會
            # 原封不動進正式修正對照表的條號欄。中文數字的「(一)」照舊寫
            # 「第一目」——那是條文本來就有的講法（「第二款第一目」）。
            group_serial = open_sub(
                "目（阿拉伯）" if raw_item.isdigit() else "目（中文）",
                ("(%s)" % raw_item) if raw_item.isdigit() else ("第%s目" % item_match.group(1)),
                cn_to_int(item_match.group(1)), index)
            level, ref = "目", stack_ref()
        elif is_cell:
            # 表格儲存格：跟著目前的位置走，但不編項次也不動堆疊。
            # 寧可寫得粗一點，也不要生一個文件裡不存在的「第X項」。
            level, ref = "其他", (stack_ref() if stack else prefix())
        elif stack and not _NEW_PARAGRAPH_CUE_RE.match(text) and \
                not (article and starts_new_paragraph(index, text)):
            # 款目底下的折行補充：不是新的一項，也不重設任何東西。
            level, ref = "其他", stack_ref()
        elif article:
            # 沒有任何編號、也還沒開過款目的段落＝新的一項。條號要標第幾項，
            # 否則同一條有三項時，對照表分不出改的是哪一項。
            paragraph_no += 1
            del stack[:]
            reset_groups()
            level, ref = "項", article + para_part()
        else:
            level, ref = "其他", stack_ref() if stack else ""

        contexts.append({
            "chapter": chapter, "section": section, "article": article,
            "ref": ref, "level": level,
            # 這一段開的款／點／目是同一個位置的第幾組。renumber 要用它分群：
            # 兩組各自從一、二、開始的款，合成一組會誤報重號、還會被實際改號。
            "group_serial": group_serial,
            "_head": (prefix(), stack[0][1]) if stack and stack[0][0] == "款" else None,
            "_clause_no": (cn_to_int(clause_match.group(1)) if clause_match and level == "款" else None),
        })

    _use_point_refs(contexts, seen_articles)
    return contexts


def _use_point_refs(contexts, seen_articles):
    """沒有「第X條」、而且「一、二、三、」從頭到尾連續編號（跨章不重編）的文件（要點、注意事項）：
    「一、」那一層是「點」，引用寫「第三點」，不是「第二章第三款」。
    別的規章引用要點時寫的就是「依招攬作業要點第三點」；對照表條號欄寫「第二章第三款」
    人對不回去，程式拿它去對別本的引用也對不上。
    各章各自從「一、」重編的手冊照舊寫「第二章第三款」（那時候單寫第三點指不到是哪一章）。"""
    numbers = [c["_clause_no"] for c in contexts if c.get("_clause_no") is not None]
    points = (not seen_articles and numbers and numbers == list(range(1, len(numbers) + 1)))
    for c in contexts:
        head = c.pop("_head", None)
        c.pop("_clause_no", None)
        if points and head:
            prefix, part = head
            if part.startswith("第") and part.endswith("款") and c["ref"].startswith(prefix + part):
                c["ref"] = "第%s點" % part[1:-1] + c["ref"][len(prefix + part):]


_CN_DIGITS = "一二三四五六七八九十"


def cn_from_int(value):
    """阿拉伯數字轉中文，支援到 999。百位照法規寫法：一百十二、一百零五。

    項次、款目重編、檢查報告都用這一支。以前 _common 自己另寫了一份只到 99 的版本，
    100～109 會吐出「第十十五項」這種東西，110 以上直接 IndexError 當掉整次比對
    （1,347 段的手冊真的會有超過 100 段的連續項）。renumber.int_to_cn 就是這一支。
    """
    if value < 1:
        return str(value)
    if value >= 1000:
        # 內規不會有第一千項；真的遇到就原樣回阿拉伯數字，不要當掉。
        return str(value)
    if value >= 100:
        hundreds, rest = divmod(value, 100)
        head = _CN_DIGITS[hundreds - 1] + "百"
        if rest == 0:
            return head
        if rest < 10:
            return head + "零" + _CN_DIGITS[rest - 1]
        return head + cn_from_int(rest)
    if value <= 10:
        return _CN_DIGITS[value - 1]
    if value < 20:
        return "十" + _CN_DIGITS[value - 11]
    tens, ones = divmod(value, 10)
    return _CN_DIGITS[tens - 1] + "十" + (_CN_DIGITS[ones - 1] if ones else "")


# 舊名字留著：模組內與既有呼叫端都還在用。
_cn_from_int = cn_from_int

_CN_VALUES = {ch: idx + 1 for idx, ch in enumerate(_CN_DIGITS)}

# 逐位寫法會用到的字（沒有十／百／千）。見 cn_to_int。
_CN_POSITIONAL = frozenset("零〇一二三四五六七八九")

# 位值寫法的合法樣子（到 999）：〔X百〕〔零X｜〔X〕十〔X〕｜X〕。
# 「零X」只能接在百後面（一百零五）；百後面直接接個位數（一百五）口語是一百五十、
# 法規寫法沒有這種寫法，有歧義，由 cn_to_int 回 None。
_CN_VALUE_RE = re.compile(
    r"^(?:(?P<h>[一二三四五六七八九])百)?"
    r"(?:零(?P<z>[一二三四五六七八九])"
    r"|(?P<t>[一二三四五六七八九])?(?P<ten>十)(?P<o>[一二三四五六七八九])?"
    r"|(?P<u>[一二三四五六七八九]))?$")


def cn_to_int(text):
    """中文數字轉阿拉伯數字，支援到 999（真資料的手冊一章可超過一百個款）。抓不到回 None。

    全案只留這一份（renumber.cn_to_int 就是它）：層級脈絡要判斷「編號有沒有重新起算」，
    跟重編用的是同一套數字解讀，兩邊各寫一份遲早會不一致。
    """
    text = unicodedata.normalize("NFKC", text or "").strip()
    if text.isdigit():
        return int(text)
    if not text:
        return None
    text = text.replace("兩", "二")       # 「兩百」＝「二百」
    # 「第三〇一條」是逐位寫法（三、〇、一），跟「第三百零一條」的位值寫法是兩套。
    # 不能只把「〇」換成「零」丟進下面的位值算式——那會算成 0，而 0 比 None 更糟：
    # 「第一〇一條」與「第三〇一條」會正規化成同一把鑰匙，條號對照整個對錯人。
    if len(text) > 1 and all(ch in _CN_POSITIONAL for ch in text):
        return int("".join("0" if ch in "零〇" else str(_CN_VALUES[ch]) for ch in text))
    if text in ("零", "〇"):
        return 0
    # 以前照位值硬算、不看寫法合不合法：「十十」算成 20、「二二十」「百」算成 0。
    # 拿一個錯的數字去對條號、款號，比回 None（「抓不到」，呼叫端會列成無法判定）更糟。
    match = _CN_VALUE_RE.match(text)
    if not match:
        return None
    if match.group("z") and not match.group("h"):
        return None          # 「零五」不是位值寫法（逐位寫法在上面已經處理過）
    if match.group("u") and match.group("h"):
        return None          # 「一百五」有歧義：口語是一百五十，法規寫法要寫成一百零五
    value = lambda key: _CN_VALUES.get(match.group(key) or "", 0)
    total = value("h") * 100 + value("z") + value("u")
    if match.group("ten"):
        total += (value("t") or 1) * 10 + value("o")
    return total


def format_scope(context):
    """對照表「章節」欄要顯示的內容，例如「第一章 第三節」。"""
    if not context:
        return ""
    parts = [p for p in (context.get("chapter"), context.get("section")) if p]
    return " ".join(parts)


# ---------------------------------------------------------------------------
# 不靠 python-docx 讀 .docx（給套件庫固定、裝不了東西的環境用）
# ---------------------------------------------------------------------------

_W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

# 已經對哪些檔案印過讀檔提醒，記在 notices.once 裡（key 是「docx:絕對路徑」）。
# 詳見 read_docx_stdlib。以前這是本模組的一個 set，一支程式跑完才消失——
# 批次跑第二本時，第二本的追蹤修訂／自動編號／文字方塊提醒會被當成「已經講過」
# 整個吞掉，那一本的 提醒.txt 就少了幾則。
_REMINDED_KEY = "docx:%s"


# 測試要重播某個檔案的讀檔提醒時用（例：test_revision_nodes）。
def forget_reminded_file(filepath):
    nt.forget(_REMINDED_KEY % os.path.abspath(filepath))


def describe_bad_docx(filepath):
    """
    .docx 讀不開時，講清楚到底是哪一種讀不開。

    副檔名是 .docx 但打不開，實務上就三種：真的是舊版 .doc 改了副檔名、
    檔案有密碼保護、或檔案壞了。前兩種的檔頭都是 OLE 複合檔的那八個位元組，
    分不出來就會給錯指引——叫一個「加了密碼」的人去「另存成 docx」沒有用。
    """
    name = os.path.basename(filepath)
    try:
        head = open(filepath, "rb").read(8)
    except OSError:
        head = b""

    if head[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
        return (
            "錯誤：%s 打不開。它的檔頭是舊格式的複合檔，可能是下列兩種情況：\n"
            "      一、這份檔案設了開啟密碼。請先在 Word 中開啟、移除密碼後另存新檔。\n"
            "      二、這其實是舊版 .doc，只是副檔名被改成 .docx。\n"
            "         請用 Word 開啟後，選「另存新檔」，格式選 Word 文件（.docx）。"
            % name)
    if not head:
        return "錯誤：%s 是空檔案或讀不到內容，請確認檔案有沒有上傳完整。" % name
    return ("錯誤：%s 不是有效的 .docx。若這是舊版 .doc，請先用 Word 另存成 .docx。"
            % name)


# 檔名裡常見的「先後」標記。前面的代表舊、後面的代表新。
_VERSION_MARKERS = [
    ("舊版", "新版"), ("舊", "新"), ("修正前", "修正後"), ("修訂前", "修訂後"),
    ("修改前", "修改後"), ("現行", "修正"), ("原條文", "修正條文"),
    ("原始", "修改"), ("before", "after"), ("old", "new"),
    ("v1", "v2"), ("V1", "V2"),
]


def warn_if_versions_swapped(old_path, new_path):
    """
    新舊版放反時提醒一聲。

    這是實際會發生而且後果很嚴重的操作失誤：兩個檔案位置對調，程式照跑不誤，
    產出的對照表會變成「三十日 → 十五日」，方向整個相反。那份東西送出去，
    會變成一份把新規定改回舊規定的正式文件。

    判斷依據有兩個，都不是百分之百，所以只提醒、不阻擋——
    確實有人需要反向比對，程式不該替他決定。
    """
    old_name = os.path.basename(old_path or "")
    new_name = os.path.basename(new_path or "")
    reasons = []

    lower_old, lower_new = old_name.lower(), new_name.lower()
    for earlier, later in _VERSION_MARKERS:
        e, l = earlier.lower(), later.lower()
        # 傳進來當「舊版」的那個檔名帶著「新」的標記，另一個帶著「舊」的標記
        if l in lower_old and e in lower_new and e not in lower_old:
            reasons.append("檔名：舊版位置放的是「%s」，新版位置放的是「%s」"
                           % (old_name, new_name))
            break

    try:
        old_time = os.path.getmtime(old_path)
        new_time = os.path.getmtime(new_path)
        # 差一天以上才算數，同一批產生的檔案時間差幾秒沒有意義
        if old_time - new_time > 86400:
            reasons.append("修改時間：舊版位置那個檔比新版位置那個檔還新")
    except OSError:
        pass

    if not reasons:
        return False

    # 留底那一行要自己講得完整：人拿到 提醒.txt 時手邊沒有畫面上的下文。
    nt.notice(nt.REMINDER,
              "新舊版可能放反了（%s）" % "；".join(reasons), "讀檔")
    print("      放反的話對照表的方向會整個相反（例如把「三十日」寫成改回「十五日」），")
    print("      那份文件送出去會變成把新規定改回舊規定。請先確認參數順序：")
    print("      舊版檔案在前、新版檔案在後。")
    print()
    return True

def _count_numbered_by_style(filepath, body):
    """段落套的樣式本身帶自動編號時，本文裡看不到 <w:numPr>，要去查 styles.xml。"""
    import zipfile
    import xml.etree.ElementTree as ET

    try:
        with zipfile.ZipFile(filepath) as archive:
            if "word/styles.xml" not in archive.namelist():
                return 0
            styles_xml = archive.read("word/styles.xml")
    except (KeyError, OSError, zipfile.BadZipFile):
        return 0

    try:
        styles = ET.fromstring(styles_xml)
    except ET.ParseError:
        return 0

    numbered_styles = set()
    for style in styles.findall("%sstyle" % _W_NS):
        if style.findall(".//%snumPr" % _W_NS):
            style_id = style.get("%sstyleId" % _W_NS)
            if style_id:
                numbered_styles.add(style_id)
    if not numbered_styles:
        return 0

    count = 0
    for para in body.iter("%sp" % _W_NS):
        for ref in para.findall(".//%spStyle" % _W_NS):
            if ref.get("%sval" % _W_NS) in numbered_styles:
                count += 1
                break
    return count


def iter_body_blocks(parent):
    """
    照文件順序走過本文的段落與表格，回傳 (種類, 元素, 它的父元素)。種類是 "p" 或 "tbl"。

    Word 的內容控制項（<w:sdt>）會把段落或表格包在 <w:sdtContent> 裡；公文範本常用它做
    生效日期、簽核欄之類的欄位。以前只看 body 直接子層，這些段落讀檔看不到、套用也找不到，
    而且沒有任何提醒。這支會走進去，讀檔（read_docx_stdlib）與套用（docx_annotate.collect_slots）
    都用它，段次才會一致。
    """
    for child in parent:
        if child.tag == "%sp" % _W_NS:
            yield "p", child, parent
        elif child.tag == "%stbl" % _W_NS:
            yield "tbl", child, parent
        else:
            for item in _unwrapped(child, iter_body_blocks):
                yield item


def _unwrapped(child, walk):
    """透明外殼裡面的東西照走：內容控制項（<w:sdt> 的 <w:sdtContent>）與
    自訂 XML（<w:customXml>，XML 對應、公文自動化工具產的檔會有）。
    兩種都只是把段落、表格、列、格包起來，不改變它們在文件裡的位置；
    看不見的話，讀檔少讀一段、乾淨版把整張表當成空的收掉。"""
    if child.tag == "%ssdt" % _W_NS:
        content = child.find("%ssdtContent" % _W_NS)
        if content is not None:
            for item in walk(content):
                yield item
    elif child.tag == "%scustomXml" % _W_NS:
        for item in walk(child):
            yield item


def _direct_blocks(parent, tag):
    """取直屬子層的某一種元素（<w:tr> 或 <w:tc>），<w:sdt>／<w:customXml> 包住的也算直屬。

    一定要用直接子層，不能用 ElementTree 的 .iter()——.iter() 是遞迴的，
    外層表格的 <w:tr>／<w:tc> 會把巢狀表格的列與格一起掃進來，同一格被讀兩次。
    """
    for child in parent:
        if child.tag == "%s%s" % (_W_NS, tag):
            yield child
        else:
            for item in _unwrapped(child, lambda node: _direct_blocks(node, tag)):
                yield item


def cell_paragraphs(cell):
    """一個儲存格「自己的」段落（含內容控制項裡的），不含巢狀表格裡的段落。"""
    return [node for kind, node, _ in iter_body_blocks(cell) if kind == "p"]


def _iter_table_text_nodes(table):
    """把一張表格就地展開成一連串儲存格段落；巢狀表格排在該格段落之後。

    回傳順序跟 iter_body_blocks 一樣是 (種類, 元素, 容器)。
    """
    for row in _direct_blocks(table, "tr"):
        for cell in _direct_blocks(row, "tc"):
            # 一格裡的每一個 <w:p> 各自算一段（容器仍是那一格）。
            # 舊寫法是整格 yield 一次、文字用 \n 黏成一段——apply 遇到多段的格
            # 只能整格跳過（「跳過（儲存格多段）」），格內的「前項」也因為整格
            # 被當成一段而算錯項次。逐段展開之後這兩件事一起消失。
            for para in cell_paragraphs(cell):
                yield "cell", para, cell
            for kind, node, _ in iter_body_blocks(cell):
                if kind == "tbl":
                    for item in _iter_table_text_nodes(node):
                        yield item


def iter_docx_text_nodes(parent):
    """
    依 body 的真實文件順序走訪「有文字的節點」，回傳 (種類, 元素, 容器)。

    回傳順序跟 iter_body_blocks 一樣是 (種類, 元素, 容器)，兩支換著用才不會拆錯。
    種類 "p"   ：元素是 <w:p>，文字用 _docx_paragraph_text 取。
    種類 "cell"：元素是該格自己的 <w:p>（一格有幾段就展開幾段），文字一樣用
                 _docx_paragraph_text 取；巢狀表格的格排在該格段落之後。
    容器是「要在同一層插入新元素時該 append 進去的那個元素」：段落是它的直屬父元素，
    儲存格段落是那一格自己。

    為什麼要有這支：以前讀檔先收完所有本文段落，再把「所有」表格儲存格接在最後，
    文件中段的附表因此被搬到全文尾端。對比的另一邊若是自然順序的 .txt，同一批條文
    會同時被判成刪除又新增，交付的對照表與標註版全文直接是錯的。

    段次（1 起算）是決定表、指紋檔、審查包共用的座標，所以 read_docx_stdlib 與
    docx_annotate.collect_slots 只准呼叫這一支，兩邊順序才會一模一樣。
    兩邊都要用同一個條件跳過空白節點（本函式一律照實回傳，不做過濾）。
    """
    for kind, node, container in iter_body_blocks(parent):
        if kind == "p":
            yield "p", node, container
        else:
            for item in _iter_table_text_nodes(node):
                yield item


def count_content_controls(body):
    """整份文件的內容控制項數：本文層級的與段落內行內的都算進去。

    body.iter() 走的是全部子孫節點，行內控制項（<w:p> 裡面那一種）當然也數得到。
    docstring 以前寫「不含段落內的行內控制項」，跟實作剛好相反——照文件理解的人
    會以為「內容控制項 3 個」只有三格是範本欄位，實際上行內那幾格也是，
    而 apply 對範本鎖住的欄位是改不動的。
    """
    return sum(1 for _ in body.iter("%ssdt" % _W_NS))


def count_text_boxes(body):
    """文字方塊（<w:txbxContent>）的數量。"""
    return sum(1 for _ in body.iter("%stxbxContent" % _W_NS))


def read_docx_stdlib(filepath, with_kinds=False):
    """
    只用標準函式庫讀 .docx，不需要 python-docx。

    with_kinds=True 時回傳 (段落列表, 種類列表)，種類是 "p"（本文段落）或
    "cell"（表格儲存格），順序與段落一一對應，給 build_hierarchy 分辨表格用。
    預設維持只回段落列表，既有呼叫端不用動。

    為什麼需要這條路：
    有些企業 AI 平台的執行環境套件庫是固定的，裝不了 python-docx。
    但內規幾乎都是 Word 檔，讀不了 .docx 等於整套工具在那種環境不能用。

    .docx 其實就是一個 zip，條文放在裡面的 word/document.xml。
    用 zipfile ＋ xml.etree 就能拆出來，兩者都是標準函式庫。

    段落順序照文件真實順序（iter_docx_text_nodes）：表格走到哪就在哪展開，
    一格算一段。以前是先收完所有本文段落、再把所有儲存格接在最後，文件中段的附表
    會被搬到全文尾端；對比的另一邊若是自然順序的 .txt，同一批條文會同時被判成
    刪除又新增，交付的對照表與標註版全文直接是錯的。

    追蹤修訂的處理方式：**當成「已接受修訂」來讀**。
        <w:ins>／<w:moveTo>    插入與移進來的文字 → 收進來（它在 <w:t> 裡）
        <w:del>／<w:moveFrom>  刪除與移出去的文字 → 不收
        <w:rPrChange> 等格式修訂 → 記的是「改之前的格式」，裡面沒有本文，不收
    哪個標籤算哪一種，一律看 REVISION_NODES 那一張表，不要在各處自己列。
    這是正確的解讀：使用者交來的「新版」，意思就是修訂後的樣子。
    但這件事會影響結果，所以偵測到追蹤修訂時要明講，不能默默決定。
    """
    import zipfile
    import xml.etree.ElementTree as ET

    try:
        with zipfile.ZipFile(filepath) as archive:
            xml_bytes = archive.read("word/document.xml")
    except KeyError:
        raise SystemExit(
            "錯誤：%s 不是有效的 Word 檔（裡面找不到 word/document.xml）。" % filepath)
    except zipfile.BadZipFile:
        raise SystemExit(describe_bad_docx(filepath))

    root = ET.fromstring(xml_bytes)
    body = root.find("%sbody" % _W_NS)
    if body is None:
        return ([], []) if with_kinds else []

    # 同一支程式裡同一個檔案會被讀好幾次（compare 讀一次、條文檢查讀一次、
    # 審查包再讀一次）。提醒只在第一次讀的時候印，不然畫面上同一句話會重複三四遍，
    # 人會開始跳過它——而這些提醒（追蹤修訂、自動編號、文字方塊）正是最不能被跳過的。
    remind = nt.once(_REMINDED_KEY % os.path.abspath(filepath))

    # 有追蹤修訂就要講。使用者可能以為自己交的是「修訂前」的版本，
    # 而我們讀的是「接受修訂後」的內容——這個差別會直接反映在對照表上。
    # 五類修訂記號都要數（REVISION_NODES）：只數 ins／del 的話，把一整項剪下貼到
    # 別章（moveFrom／moveTo）、改字級改行距（rPrChange／pPrChange）、
    # 整列整格增刪（cellIns／cellDel）都會被當成「這份檔案沒有追蹤修訂」，
    # 那是最容易讓人誤會的一種沉默。
    counts = count_tracked_changes(root)
    if any(counts.values()) and remind:
        nt.notice(nt.REMINDER,
                  "%s 含有 Word 追蹤修訂（%s），本程式以「已接受修訂」的內容進行比對"
                  % (os.path.basename(filepath), describe_tracked_changes(counts)), "讀檔")
        print("      本程式以「已接受修訂」的內容進行比對：移動當成已經移到新位置、")
        print("      格式修訂當成已經套用。若你要比對的是修訂前的版本，")
        print("      請先在 Word 中拒絕修訂並另存新檔。")

    # Word 自動編號：畫面上看得到「第一條」「一、」，但那是 Word 產生的，
    # 不在文字裡，程式讀不到，對照表的條號欄會整欄空白。
    # 這件事一定要講——使用者看畫面明明有條號，不會想到程式看不到。
    # 編號可能直接寫在段落裡（<w:numPr>），也可能寫在段落套的「樣式」裡
    # （例如內建的 ListNumber）。兩邊都要看，只看本文會漏掉一半的情況。
    numbered = len(root.findall(".//%snumPr" % _W_NS))
    if not numbered:
        numbered = _count_numbered_by_style(filepath, body)
    if numbered:
        lettered = sum(1 for para in body.iter("%sp" % _W_NS)
                       if extract_article_no(_docx_paragraph_text(para)))
        if lettered < numbered and remind:
            nt.notice(nt.REMINDER,
                      "%s 有 %d 段使用 Word 自動編號，程式讀不到，"
                      "對照表的「條號」欄會留白，條號重複與跳號也檢查不出來"
                      % (os.path.basename(filepath), numbered), "讀檔")
            print("      自動編號是 Word 產生的，不在文字裡，程式讀不到，")
            print("      對照表的「條號」欄會留白，條號重複與跳號也檢查不出來。")
            print("      要有條號的話，請先在 Word 裡把自動編號轉成一般文字再存檔。")

    controls = count_content_controls(body)
    if controls and remind:
        nt.notice(nt.REMINDER,
                  "%s 有 %d 個內容控制項（Word 的表單欄位）。裡面的段落已納入比對與套用；"
                  "段落中間的行內控制項那一段會被 apply 跳過，需人工處理"
                  % (os.path.basename(filepath), controls), "讀檔")

    # 文字方塊裡的字不是本文段落：它在 <w:txbxContent> 裡自成一個小文件，
    # 標註端（docx_annotate）只看段落直接子層，看不到它。以前讀檔用遞迴把它
    # 黏進所在段落的文字裡，結果是「讀得到、標不到」，標註版全文會把同一條印兩次。
    # 現在讀檔也不收，但一定要講——不能讓人以為那幾行有被比對過。
    boxes = count_text_boxes(body)
    if boxes and remind:
        nt.notice(nt.REMINDER,
                  "%s 有 %d 個文字方塊。方塊裡的文字不納入比對，也不會被標註或套用，"
                  "請人工確認方塊內容要不要跟著改"
                  % (os.path.basename(filepath), boxes), "讀檔")
        print("      要納入比對請先把文字移到本文段落。")

    paragraphs = []
    kinds = []
    carry = ""
    for kind, node, _ in iter_docx_text_nodes(body):
        # 兩種節點現在都是 <w:p>（"cell" 是儲存格自己的段落），取文字同一支。
        text = carry + _docx_paragraph_text(node)
        carry = ""
        if kind == "p" and _paragraph_mark_deleted(node):
            # 段落記號被刪（追蹤修訂把兩段併成一段）：接受修訂後這一段跟下一段是同一段（B5）。
            # 不接起來的話，讀出來多一段，比對成假的「修改＋新增」，段次也跟乾淨版對不上
            carry = text
            continue
        if text:
            paragraphs.append(text)
            kinds.append(kind)
    if carry:
        paragraphs.append(carry)
        kinds.append("p")

    return (paragraphs, kinds) if with_kinds else paragraphs


def _paragraph_mark_deleted(paragraph):
    """段落記號有沒有被追蹤修訂刪掉（<w:pPr><w:rPr><w:del/>，或移走的 moveFrom）。"""
    ppr = paragraph.find("%spPr" % _W_NS)
    rpr = ppr.find("%srPr" % _W_NS) if ppr is not None else None
    if rpr is None:
        return False
    return rpr.find("%sdel" % _W_NS) is not None or rpr.find("%smoveFrom" % _W_NS) is not None


# ---------------------------------------------------------------------------
# Word 追蹤修訂的節點對照表
# ---------------------------------------------------------------------------
#
# 為什麼要有這一張表：以前「讀檔提醒」「apply 守門」「clean_tree」「標註掃描」四個
# 地方各自寫死「追蹤修訂＝<w:ins> 加 <w:del>」，Word 的另外三種修訂節點全部溜過去。
# 實測：法遵把一整項條文剪下貼到別章，Word 記的是 <w:moveFrom>／<w:moveTo>；
# 改字級改行距記的是 <w:rPrChange>／<w:pPrChange>。畫面上明明有修訂記號，程式卻說
# 這份檔案沒有追蹤修訂——使用者不知道我們讀的是「接受修訂後」的內容，apply 也照樣
# 放行，產出的「乾淨版」裡還留著移動前的整段文字。
#
# 接受修訂的語意（clean_tree 與標註前的逐段接受都照這一張表做）：
#   INSERT_LIKE       解開外殼、裡面的東西留下來   moveTo（移進來的字）跟 ins 同一路
#   DELETE_LIKE       整個子樹拿掉                 moveFrom（移出去的字）跟 del 同一路
#   PROPERTY_CHANGES  節點本身拿掉                 它記的是「改之前的格式長什麼樣」，
#                                                  接受＝維持現在的格式，記錄不用留
#   STRUCTURE_CHANGES 看情況：cellDel 整格拿掉、    表格的格被新增／刪除／合併
#                     cellIns 與 cellMerge 只拿記號
#   RANGE_MARKERS     拿掉                         只是標出移動範圍的空元素，沒有內容
INSERT_LIKE = ("ins", "moveTo")
DELETE_LIKE = ("del", "moveFrom")
PROPERTY_CHANGES = ("rPrChange", "pPrChange", "sectPrChange", "numberingChange",
                    "tblPrChange", "trPrChange", "tcPrChange", "tblPrExChange")
STRUCTURE_CHANGES = ("cellIns", "cellDel", "cellMerge")
RANGE_MARKERS = ("moveFromRangeStart", "moveFromRangeEnd",
                 "moveToRangeStart", "moveToRangeEnd")

# 印給人看的分類。五類加起來就是「這份檔案有幾個修訂記號」。
# 分類要講得出是哪一種：只說「有 6 個修訂記號」，人不會知道其中有一整項被搬到別章。
REVISION_NODES = {
    "插入": ("ins",),
    "刪除": ("del",),
    "移動": ("moveFrom", "moveTo"),
    "結構修訂": STRUCTURE_CHANGES,
    "格式修訂": PROPERTY_CHANGES,
}
_REVISION_ORDER = ("插入", "刪除", "移動", "結構修訂", "格式修訂")

# 會動到條文內容的分類：apply 一律拒絕，人必須先在 Word 接受或拒絕。
# 結構修訂算在這裡——表格少一格就是少一段條文，跟刪字一樣要人看過。
TEXT_AFFECTING_KINDS = ("插入", "刪除", "移動", "結構修訂")
# 只動版面、不動條文一個字的分類：可以放行，但一定要講乾淨版把它接受了。
FORMAT_ONLY_KINDS = ("格式修訂",)


def _w_tag(name):
    return "%s%s" % (_W_NS, name)


def _w_tags(names):
    return tuple(_w_tag(name) for name in names)


INSERT_LIKE_TAGS = _w_tags(INSERT_LIKE)
DELETE_LIKE_TAGS = _w_tags(DELETE_LIKE)
PROPERTY_CHANGE_TAGS = _w_tags(PROPERTY_CHANGES)
STRUCTURE_CHANGE_TAGS = _w_tags(STRUCTURE_CHANGES)
RANGE_MARKER_TAGS = _w_tags(RANGE_MARKERS)
CELL_DELETE_TAG = _w_tag("cellDel")
# 「接受修訂」要處理的全部節點
REVISION_TAGS = (INSERT_LIKE_TAGS + DELETE_LIKE_TAGS + PROPERTY_CHANGE_TAGS
                 + STRUCTURE_CHANGE_TAGS + RANGE_MARKER_TAGS)

# 接受時「只把記號本身拿掉」的：格式修訂記錄、移動範圍標記，
# 以及 cellIns（格留著）與 cellMerge（格留著，合併狀態本來就寫在 tcPr 的 vMerge 上）。
_DROP_MARKER_TAGS = (PROPERTY_CHANGE_TAGS + RANGE_MARKER_TAGS
                     + _w_tags(("cellIns", "cellMerge")))

# 這幾個記號的「接受」牽涉到整段／整列／整格要不要消失，不是 accept_revisions
# 能決定的（它只管一棵子樹），所以原地留著交給呼叫端：
#   <w:pPr><w:rPr><w:del/>   段落記號被刪 → 跟下一段合併，或整段消失
#   <w:trPr><w:del/>         整列被刪     → 整個 <w:tr> 消失
#   <w:tcPr><w:cellDel/>     整格被刪     → 整個 <w:tc> 消失
# 呼叫端＝apply_changes.clean_tree（會真的併段／刪列／刪格）與
# docx_annotate.accept_paragraph_revisions（標註版只拿掉記號，不動段落結構）。
_DEFERRED_MARKERS = {
    _w_tag("rPr"): DELETE_LIKE_TAGS,
    _w_tag("trPr"): DELETE_LIKE_TAGS,
    _w_tag("tcPr"): (CELL_DELETE_TAG,),
}

# 修訂子樹裡可能夾著這些「錨點」：書籤與註解的起訖標記。它們不是文字，但把整個
# 子樹丟掉會連它們一起丟——書籤沒了，指向它的交叉參照欄位在 Word 裡會印出
# 「錯誤! 找不到參照來源」，等於把原檔弄壞。丟子樹之前要先把它們撈出來。
ANCHOR_TAGS = _w_tags(("bookmarkStart", "bookmarkEnd", "commentRangeStart",
                       "commentRangeEnd", "commentReference"))


def count_tracked_changes(root):
    """數 root 這棵樹裡各種修訂記號各有幾個，回傳 {分類: 個數}，五類都會有（沒有就是 0）。

    段落記號、整列、整格上的記號（<w:pPr><w:rPr><w:del/>、<w:trPr><w:del/>、
    <w:tcPr><w:cellDel/>）也算：整段被刪、整列被刪就是靠它記的，不算的話
    「只刪掉一整段」「只刪掉一整列」的草稿會被當成沒有修訂而放行。
    範圍標記（moveFromRangeStart 那一類）不算，它跟 moveFrom／moveTo 是同一件事，
    算進去會讓一次搬移看起來像更多個。
    """
    counts = {}
    for label in _REVISION_ORDER:
        counts[label] = sum(len(root.findall(".//%s" % _w_tag(tag)))
                            for tag in REVISION_NODES[label])
    return counts


def has_tracked_changes(root):
    """root 這棵樹裡有沒有任何一種追蹤修訂。"""
    return any(count_tracked_changes(root).values())


def describe_tracked_changes(root_or_counts):
    """講成人看得懂的一句：「共 6 個修訂記號：插入 3 個、刪除 1 個、移動 2 個」。

    沒有的種類不列。講「幾個記號」不講「幾處」：一次搬移會留下 moveFrom（內容）、
    moveFrom（段落記號）、moveTo 三個記號，說成「移動 3 處」會讓人以為搬了三個地方。
    """
    counts = (root_or_counts if isinstance(root_or_counts, dict)
              else count_tracked_changes(root_or_counts))
    parts = ["%s %d 個" % (label, counts[label])
             for label in _REVISION_ORDER if counts.get(label)]
    if not parts:
        return "沒有修訂記號"
    return "共 %d 個修訂記號：%s" % (sum(counts.values()), "、".join(parts))


def accept_revisions(element):
    """就地接受 element 這棵子樹裡的追蹤修訂（照上面那張表），回傳 element。

    由下往上重建每一層的子元素，一趟走完就收斂，不用定點迴圈也不用父節點表：
    先把子元素自己的內容整理好（遞迴），再決定它本身要留、要拆殼還是要整棵丟。
    <w:ins> 裡面包 <w:del>（Word 對「已插入又被刪」的寫法）因此天生就對——
    解開 ins 之前，裡面的 del 已經先被處理掉了。
    （以前是「找到一個就改一個、每改一次重算整棵樹的父節點表」，三千個 rPrChange
    要重算三千次，實測慢到不能接受；現在是一趟 O(節點數)。）

    段落記號、整列、整格上的刪除記號（_DEFERRED_MARKERS）這裡**不動**：接受它們的
    意思是整段合併、整列消失、整格消失，那是結構層級的決定，由呼叫端自己做
    （apply_changes.clean_tree 併段／刪列／刪格，標註那邊只拿掉記號）。
    """
    def accepted_children(node):
        kept = []
        deferred = _DEFERRED_MARKERS.get(node.tag, ())
        for child in node:
            if child.tag in deferred:
                kept.append(child)          # 記號留著，交給呼叫端
                continue
            if child.tag in DELETE_LIKE_TAGS:
                continue                    # 刪除／移出：整棵子樹丟掉
            if child.tag in _DROP_MARKER_TAGS:
                continue                    # 只是記錄或標記，節點本身丟掉
            child[:] = accepted_children(child)
            if child.tag in INSERT_LIKE_TAGS:
                # 解開外殼，裡面的東西原地留下（空的 <w:rPr><w:ins/> 解開就等於拿掉，
                # 那正是「接受一個被插入的段落記號」該有的結果）
                kept.extend(child)
            else:
                kept.append(child)
        return kept

    element[:] = accepted_children(element)
    return element


# 段落裡不算本文文字的子樹：
#   w:pPr / w:rPr  段落與字元格式（<w:pPr><w:tabs><w:tab/> 是定位停留點的設定，不是定位點本身）
#   DELETE_LIKE ＋ w:delText  已刪除／已移走的文字，讀的是「接受修訂後」的樣子
#   PROPERTY_CHANGES          格式修訂記錄的是「改之前的格式」，裡面沒有本文
#   w:txbxContent  文字方塊，另外提醒
# INSERT_LIKE（ins／moveTo）不在這裡：插入與移進來的字就是接受修訂後看得到的字。
_SKIP_SUBTREES = _w_tags(
    ("pPr", "rPr", "delText", "txbxContent") + DELETE_LIKE + PROPERTY_CHANGES)


def is_line_break(node):
    """<w:br/>、<w:cr/> 是不是「換行」。分頁符與分欄符（w:type=page／column）不算，那是版面元素。

    <w:cr/> 是 run 裡的換行（歸位字元），Word 顯示起來跟 <w:br/> 一樣；以前沒認，讀檔時
    整個丟掉，換行兩邊的字黏在一起。寫回去時一律寫成 <w:br/>（append_text_nodes）。
    """
    if node.tag == "%scr" % _W_NS:
        return True
    return (node.tag == "%sbr" % _W_NS
            and node.get("%stype" % _W_NS) not in ("page", "column"))


def run_symbol_text(node):
    """<w:r> 裡「不是 <w:t>、顯示出來卻是一個字」的元素讀成哪個字；不是這種元素回 None。

    <w:noBreakHyphen/>  不斷行連字號，讀成 "-"。
    <w:sym w:char="F0B7" w:font="Symbol"/>  符號字型的字，照 w:char 的十六進位碼轉成字元。
        F0xx 是 Symbol／Wingdings 這類符號字型的私用區碼，對不回標準 Unicode，照原碼點保留：
        新舊兩版同一個符號讀出來一樣就比得起來，寫回去時字型跟著帶（docx_annotate._symbol_rpr）。
        碼寫壞的（不是十六進位、超出範圍、落在代理字區）回 None，照舊當成非文字元素原樣保留。
    <w:softHyphen/> 是選擇性連字號，只有行尾斷字時才顯示，平常看不到，不算字（回 None）；
        標註與套用那邊它照舊當成非文字元素原位保留，兩邊文字一樣。
    <w:cr/> 是換行，由 is_line_break 處理。

    以前這幾個全被丟掉：「第一-1號」讀成「第一1號」、符號清單的項目符號不見。
    讀檔（_docx_paragraph_text）與標註／套用（docx_annotate._scan_paragraph）都呼叫這一支，
    兩邊算出的文字才會一模一樣——差一個字，套用就判成原文不符整段跳過。
    """
    if node.tag == "%snoBreakHyphen" % _W_NS:
        return "-"
    if node.tag == "%ssym" % _W_NS:
        code = (node.get("%schar" % _W_NS) or "").strip()
        try:
            value = int(code, 16)
        except ValueError:
            return None
        if not 0 < value <= 0x10FFFF or 0xD800 <= value <= 0xDFFF:
            return None
        return chr(value)
    return None


def _docx_paragraph_text(paragraph, strip=True):
    """
    一個 <w:p> 讀出來的文字。

    <w:t>      文字
    <w:tab/>   轉成 \\t——條號與條文之間用定位點分隔很常見，不轉的話兩邊會黏成一坨，
               而且套用時原文對不起來（寫出去的原文一律保留原字）。
    <w:br/>    轉成 \\n（分頁符與分欄符除外）：同一段裡的手動換行本來就是同一段。
    <w:cr/>    同 <w:br/>，轉成 \\n。
    <w:noBreakHyphen/>、<w:sym/>    各讀成一個字，見 run_symbol_text；<w:softHyphen/> 看不到，不收。
    <w:ins>／<w:moveTo>    收（插入與移進來的文字）；<w:del>／<w:moveFrom> 不收——
               讀的是接受修訂後的樣子。哪個標籤算哪一種看 REVISION_NODES。
    <w:txbxContent> 不收：文字方塊不是本文段落，標註端也標不到它。

    docx_annotate._paragraph_text 直接呼叫這一支（strip=False），標註與套用比對的
    「原文」才會跟讀檔讀到的一模一樣。
    """
    parts = []

    def walk(node):
        for child in node:
            if child.tag in _SKIP_SUBTREES:
                continue
            if child.tag == "%st" % _W_NS:
                parts.append(child.text or "")
            elif child.tag == "%stab" % _W_NS:
                parts.append("\t")
            elif is_line_break(child):
                parts.append("\n")
            else:
                symbol = run_symbol_text(child)
                if symbol is not None:
                    parts.append(symbol)
                else:
                    walk(child)

    walk(paragraph)
    text = "".join(parts)
    return text.strip() if strip else text


# ---------------------------------------------------------------------------
# 同義詞正規化
# ---------------------------------------------------------------------------

_TABLES = os.path.normpath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", "tables"))

DEFAULT_SYNONYM_FILE = os.path.join(_TABLES, "synonyms.json")


def load_synonyms(path=None):
    """
    讀取同義詞表，回傳 [(變體, 代表詞), ...]，已依變體長度由長到短排好。

    為什麼需要同義詞：
    字面比對抓不到「用詞完全換掉」的重複條文。實測「要保人應於保險費到期日前
    繳納保險費」與「應繳金額須於約定期日以前完成給付」講的是同一件事，
    字面相似度只有 34 分，遠低於門檻。

    為什麼不用語意向量：
    一、需要 PyTorch 與預訓練模型，很多企業 AI 平台裝不了也連不到外網。
    二、更重要的是說不出理由。法遵場合要能回答「為什麼系統認為這兩條相關」，
        同義詞表指得出是哪一組詞對應，語意向量指不出來。
    三、法遵人員可以自己維護詞表，不需要工程師換模型。

    由長到短排序是必要的：「應繳保費」若先被「保費」比中，就會變成
    「應繳保險費」而對不上「保險費」。長的先換才正確。
    """
    import json

    path = path or DEFAULT_SYNONYM_FILE
    if not os.path.exists(path):
        return []

    # 這份檔案是給法遵自己維護的，一定會有人改壞。改壞的代價應該是
    # 「這次沒有用到同義詞」，不是「整份對照表產不出來」——所以吃掉錯誤、
    # 明確講一聲，然後照常往下跑。對照表格式設定檔也是同樣的處理方式。
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except ValueError as exc:
        nt.notice(nt.REMINDER, "同義詞表讀不進來（%s），本次不使用同義詞，只做純字面比對" % exc, "設定檔")
        print("      請檢查 %s 的 JSON 格式，或用 tools/同義詞表編輯器.html 重新產生。"
              % os.path.basename(path))
        return []
    except OSError as exc:
        nt.notice(nt.REMINDER, "同義詞表開不起來（%s），本次不使用同義詞" % exc, "設定檔")
        return []

    groups = data.get("詞組", data) if isinstance(data, dict) else {}
    if not isinstance(groups, dict):
        nt.notice(nt.REMINDER, "同義詞表的「詞組」不是一組對照表，本次不使用同義詞", "設定檔")
        return []

    table = []
    for canonical, variants in groups.items():
        if not isinstance(canonical, str) or canonical.startswith("_"):
            continue
        # 變體寫成單一字串（而不是清單）是很容易犯的手誤，容忍它
        if isinstance(variants, str):
            variants = [v for v in re.split(r"[、,，\s]+", variants) if v]
        if not isinstance(variants, (list, tuple)):
            nt.notice(nt.REMINDER, "同義詞表裡「%s」的變體格式不對，已略過這一組" % canonical, "設定檔")
            continue
        for variant in variants:
            if isinstance(variant, str) and variant and variant != canonical:
                table.append((variant, canonical))

    table.sort(key=lambda pair: len(pair[0]), reverse=True)
    return table


def normalize_terms(text, table):
    """
    把文字裡的同義詞變體換成代表詞。

    回傳 (正規化後的文字, 被換過的代表詞集合)。
    後面那個集合是用來說明「這兩條為什麼被判定相關」的證據，
    不能只給分數不給理由。
    """
    if not table or not text:
        return text, set()

    applied = set()
    for variant, canonical in table:
        if variant in text:
            text = text.replace(variant, canonical)
            applied.add(canonical)
    return text, applied


def synonym_evidence(applied_a, applied_b, text_a, text_b, table):
    """
    找出「兩邊用了不同寫法、但被收斂成同一個代表詞」的那些詞組。

    只有這種才算是同義詞真正發揮作用。兩邊都寫「保險費」的話，
    字面比對本來就配得起來，不該算在同義詞的功勞上。
    """
    variants_by_canonical = {}
    for variant, canonical in table:
        variants_by_canonical.setdefault(canonical, []).append(variant)

    evidence = []
    for canonical in sorted(applied_a | applied_b):
        surface_a = _surface_form(text_a, canonical, variants_by_canonical)
        surface_b = _surface_form(text_b, canonical, variants_by_canonical)
        if surface_a and surface_b and surface_a != surface_b:
            evidence.append("%s＝%s" % (surface_a, surface_b))
    return evidence


def _surface_form(text, canonical, variants_by_canonical):
    """這段原文裡，這個代表詞實際上是用哪個寫法出現的。"""
    for variant in sorted(variants_by_canonical.get(canonical, []),
                          key=len, reverse=True):
        if variant in text:
            return variant
    return canonical if canonical in text else ""


# ---------------------------------------------------------------------------
# 對照表版面設定
# ---------------------------------------------------------------------------

DEFAULT_TABLE_FORMAT_FILE = os.path.join(_TABLES, "對照表格式.json")

# 設定檔缺欄位、或根本沒有設定檔時的預設值。
# 刻意寫在程式裡而不是只靠 JSON：設定檔被改壞、被刪掉、被塞了半套內容時，
# 也要還能產出一份格式正確的對照表，不能整支掛掉。
_FALLBACK_TABLE_FORMAT = {
    "版面": {"方向": "橫式", "左右邊界公分": 1.5, "上下邊界公分": 2.0},
    "標題": {"文字": "修正對照表", "字級": 18, "粗體": True, "對齊": "置中"},
    "表格": {"字級": 11, "表頭底色": "E8E8E8", "表頭粗體": True, "框線": True},
    "標示": {
        "新增": {"顏色": "C00000", "底線": True, "刪除線": False},
        "刪除": {"顏色": "C00000", "底線": False, "刪除線": True},
    },
    "欄位": [
        {"鍵": "序號", "標題": "序號", "寬度公分": 1.2, "對齊": "置中", "顯示": True},
        {"鍵": "章節", "標題": "章節", "寬度公分": 3.0, "對齊": "靠左", "顯示": True},
        {"鍵": "條號", "標題": "條號", "寬度公分": 3.4, "對齊": "靠左", "顯示": True},
        {"鍵": "修改類型", "標題": "修改類型", "寬度公分": 1.5, "對齊": "置中", "顯示": True},
        {"鍵": "原文", "標題": "原條文", "寬度公分": 7.0, "對齊": "靠左", "顯示": True},
        {"鍵": "修改後文字", "標題": "修正後條文", "寬度公分": 7.0, "對齊": "靠左", "顯示": True},
        {"鍵": "修改依據", "標題": "修改依據／理由", "寬度公分": 3.4, "對齊": "靠左", "顯示": True},
    ],
}

# 程式看得懂的欄位鍵。設定檔寫了別的鍵會被忽略並提醒，不會靜靜產出一張空白欄。
# 「原條號」選用：開了它，條號欄只寫新版條號、舊版條號寫在這一欄（新舊兩欄各寫自己的條號）；
# 沒開就在條號欄寫「第五條（原第四條）」（diff_compare.article_no_cell）。
VALID_COLUMN_KEYS = ("序號", "章節", "條號", "原條號", "修改類型", "原文",
                     "修改後文字", "修改依據", "新版段次")


def load_term_groups(path, default):
    """
    讀取自訂用語對照表（二維陣列，例如 [["要保人","投保人"], ...]）。

    跟同義詞表一樣是給法遵自己維護的檔案，一定會有人改壞。
    改壞的代價應該是「這次用預設用語表」，不是「整份檢查報告產不出來」。
    """
    import json

    if not path:
        return default
    try:
        with open(path, encoding="utf-8") as f:
            groups = json.load(f)
    except ValueError as exc:
        nt.notice(nt.REMINDER, "用語表讀不進來（%s），本次改用預設用語表" % exc, "設定檔")
        return default
    except OSError as exc:
        nt.notice(nt.REMINDER, "用語表開不起來（%s），本次改用預設用語表" % exc, "設定檔")
        return default

    cleaned = [[w for w in group if isinstance(w, str) and w]
               for group in groups
               if isinstance(group, (list, tuple))]
    cleaned = [g for g in cleaned if len(g) >= 2]
    if not cleaned:
        nt.notice(nt.REMINDER, "用語表裡沒有可用的詞組（每組至少要兩個詞），改用預設用語表", "設定檔")
        return default
    return cleaned


def load_table_format(path=None):
    """
    讀取對照表版面設定。設定檔壞掉或缺項時退回預設值，不讓它擋住產出。

    為什麼要有這個：各單位公文格式要求不同——欄位順序、要不要「章節」欄、
    標示用紅字還藍字、直式還橫式。寫死在程式裡的話，每個單位都要改程式碼。
    """
    import json
    import copy

    fmt = copy.deepcopy(_FALLBACK_TABLE_FORMAT)
    path = path or DEFAULT_TABLE_FORMAT_FILE
    if not os.path.exists(path):
        return fmt

    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except ValueError as exc:
        nt.notice(nt.REMINDER, "對照表格式設定檔讀不進來（%s），改用預設格式" % exc, "設定檔")
        return fmt

    for section in ("版面", "標題", "表格"):
        if isinstance(data.get(section), dict):
            fmt[section].update(data[section])

    if isinstance(data.get("標示"), dict):
        for kind in ("新增", "刪除"):
            if isinstance(data["標示"].get(kind), dict):
                fmt["標示"][kind].update(data["標示"][kind])

    columns = data.get("欄位")
    if isinstance(columns, list) and columns:
        cleaned = []
        for column in columns:
            if not isinstance(column, dict):
                continue
            key = column.get("鍵")
            if key not in VALID_COLUMN_KEYS:
                nt.notice(nt.REMINDER, "對照表格式設定裡有不認得的欄位鍵「%s」，已略過" % key, "設定檔")
                continue
            if column.get("顯示", True):
                cleaned.append({
                    "鍵": key,
                    "標題": column.get("標題", key),
                    "寬度公分": float(column.get("寬度公分", 3.0)),
                    "對齊": column.get("對齊", "靠左"),
                })
        if cleaned:
            fmt["欄位"] = cleaned
        else:
            nt.notice(nt.REMINDER, "對照表格式設定裡沒有任何要顯示的欄位，改用預設欄位", "設定檔")

    return fmt
