# -*- coding: utf-8 -*-
"""
Step 1.5：款目編號重編與交叉引用檢查

什麼時候要用：
你在內規裡刪掉或插入了某一款、某一目之後，跑這支程式。

刪掉「二、」之後會發生三件事，一件比一件嚴重：

1. 編號斷掉        剩下 一、三、四、  ── 肉眼容易漏看，尤其 50 頁的內規
2. 對照表被灌爆    手動把 三、改成二、、四、改成三、之後，對照表會多出一堆
                   「修改」，但那些條文一個字都沒動，只是編號位移
3. 交叉引用失效    別的條文寫「依前條第二款規定」，原本的第二款已經不存在，
                   這句話現在指到完全不同的內容 ── 這是真正會出事的地方

這支程式處理前兩件，第三件明確列出來給人工判斷。

--------------------------------------------------------------------------
為什麼「條」預設不重編
--------------------------------------------------------------------------
法制作業慣例上，刪除某一條時，後面的條號不跟著往前遞補；被刪的條保留條號並
註記「第○條　（刪除）」。這樣做的理由很實際：全文與其他規章裡引用「第五十條」
的地方，不會因為前面刪了一條就全部指錯。新增條文也是同樣道理，才會有
「第五條之一」這種寫法。

所以本程式預設只重編「款」與「目」（它們是條的內部結構，重編不影響外部引用），
條號一律不動，只在發現斷號時提醒你要不要補「（刪除）」註記。
條號一律不重編，也沒有旗標可以打開；要遞補請人工處理並自行複核引用。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
    python renumber.py 新版內規.docx
        檢查模式：只報告問題，不動檔案

    python renumber.py 新版內規.docx --apply
        重編款目編號，輸出「重編後_新版內規.docx」

    python renumber.py 新版內規.docx --apply --rewrite-refs
        連同交叉引用一起改寫（只改「被引用的條款目還在、只是換號」那種；
        引用到已刪除款目的一律不動，強制人工處理；
        「個人資料保護法第五條」這種外部法規的條號一律不動）

    python renumber.py 新版內規.docx --old 舊版內規.docx
        額外比對舊版，找出被整條刪掉的條號，提醒補「（刪除）」註記，
        並且比出「舊條號 → 新條號」，才判得了條層級的交叉引用。
        沒給舊版就一律印「未檢查」，不會印「沒有受影響」這種假的安心。
"""

import argparse
import difflib
import os
import re
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, read_paragraphs_with_kinds,
                     build_hierarchy, cn_from_int, cn_to_int, resolve_output,
                     strip_article_no, normalize_for_compare,
                     is_external_reference, is_own_law_name, POINT_RE, HAS_DOCX, _CN_NUM)
import notices as nt

# 中文數字的「字元集合」，只給正規表示式的字元類別用（[%s] 那個位置），
# 不要拿它當「第 n 個字是數字 n」的查表——「零」在最前面，索引會整排錯開。
# 要數字轉中文一律用 int_to_cn。
#
# 為什麼要含百／千／零／〇：以前這裡是「一二三四五六七八九十」，
# `_TOKEN_RE` 與 `scan_reference_drift` 的條號樣式因此認不得「第一百二十條」——
# `parse_references` 對三位數條號回空清單，報告卻照印「條層級引用：通過」；
# 更糟的是「第一百二十條第三款」的前半段配不上，後半段的「第三款」變成裸款號，
# 被當成「本條第三款」錯掛到引用所在的那一條。三位數條號在真資料很常見
# （300 條的作業要點），這是靜默漏判。
# 跟 `_common._CN_NUM` 共用同一個常數，兩邊各寫一份遲早會不一致。
CN = _CN_NUM

_CLAUSE_RE = re.compile(r"^([%s]+)(\s*、)" % CN)
# 目分成兩個數字體系：「(一)」是目，「(1)」是目底下再一層。
# 以前兩種收在同一個 _ITEM_RE 裡，plan_renumber 把它們併成一串重編，
# --apply-renumber 就會把「(1) 全職人員…」實際改寫成「(二) 全職人員…」——
# 兩個層級被壓成一層，原文被毀，而且會先誤報一次「編號重複」（實測 idx 45）。
# 重編一律用原本的體系：中文的回中文，阿拉伯的回阿拉伯，永遠不跨體系。
_ITEM_CN_RE = re.compile(r"^([（(])\s*([%s]+)\s*([）)])" % CN)
_ITEM_AR_RE = re.compile(r"^([（(])\s*([0-9０-９]+)\s*([）)])")
_ITEM_RE = re.compile(r"^([（(])\s*([%s\d０-９]+)\s*([）)])" % CN)   # 兩種都收，只給取號用
# 點：「1.」「1、」「１．」。跟 _common.build_hierarchy 判「點」層用的是同一個物件，
# 兩邊各寫一份的話，改了一邊另一邊會對不上（scan 抓不到號碼，重編就靜默跳過）。
_POINT_RE = POINT_RE

_ITEM_STYLE_CN = "目（中文）"
_ITEM_STYLE_AR = "目（阿拉伯）"


def _item_style_of(text):
    """這一段的目是哪一種數字體系，抓不到回 None。"""
    if _ITEM_CN_RE.match(text):
        return _ITEM_STYLE_CN
    if _ITEM_AR_RE.match(text):
        return _ITEM_STYLE_AR
    return None


def _item_pattern(style):
    return _ITEM_AR_RE if style == _ITEM_STYLE_AR else _ITEM_CN_RE


def _number_text(style, value):
    """重編後要寫回原文的號碼：阿拉伯體系寫阿拉伯，其餘寫中文。"""
    return str(value) if style == _ITEM_STYLE_AR else int_to_cn(value)


# 中文數字轉阿拉伯數字，支援到 999。實作在 _common.cn_to_int：
# 層級脈絡判斷「編號有沒有重新起算」用的是同一份，兩邊各寫一份遲早會不一致。
cn_to_int = cn_to_int


# 阿拉伯數字轉中文數字，支援到 999（百位照法規寫法：一百十二、一百零五）。
# 實作在 _common.cn_from_int：層級脈絡的項次也要用同一份，兩邊各寫一份的結果是
# _common 那份只到 99，100 以上吐出「第十十五項」、110 以上直接當掉。
int_to_cn = cn_from_int


# ---------------------------------------------------------------------------
# 掃描目前的編號狀態
# ---------------------------------------------------------------------------

def scan(paragraphs, kinds=None):
    """
    走一遍全文，回傳每一段的編號資訊。

    kinds 是 read_paragraphs_with_kinds 回傳的來源種類（"p"／"cell"），
    往下傳給 build_hierarchy：表格儲存格不能被算成前一條的項，
    否則重編與交叉引用檢查看到的層級跟修正對照表不一樣。

    每個元素：
        {"index": 段次(從1), "level": 條/款/點/目/其他, "article": 所屬條號,
         "written": 目前寫的號碼(整數), "clause_written": 所屬款的號碼,
         "point_written": 所屬「1.」點的號碼, "item_parent": 阿拉伯目所屬的中文目號碼,
         "item_style": 目的數字體系（中文／阿拉伯）,
         "clause_serial"／"point_serial": 所屬的款／點是同一個位置的第幾組}

    組序號來自 build_hierarchy：同一項裡被「本公司辦理前項事項時……」這種沒有編號的
    段落分成兩組的款，各自從「一、」重新起算。不分群的話會誤報「編號重複」，
    --apply-renumber 還會把第二組實際改成「三、四、」——原文就毀了。

    點與目的「所屬」資訊要記下來，重編才分得出「同一款底下不同小群的 (1)」——
    不分群的話兩群的 (1) 會被併成一串，第二群的 (1) 會被改寫成 (3)（實測 idx 45／50）。
    """
    contexts = build_hierarchy(paragraphs, kinds)
    entries = []
    clause_written = None
    point_written = None
    item_parent = None       # 目前所在的中文目，阿拉伯目掛在它底下
    paragraph_no = 1         # 條底下第幾項；每一項的款目都是重新起算的
    clause_serial = 1        # 這一項裡的款是第幾組（編號重新起算就 +1）
    point_serial = 1         # 這一款裡的點是第幾組

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        level = context["level"]
        written = None
        item_style = None

        if level == "條":
            clause_written = point_written = item_parent = None
            paragraph_no = 1
            clause_serial = point_serial = 1
        elif level == "項":
            # 新的一項開始，上一項的款目作廢。不歸零的話，第二項的「(一)(二)」
            # 會被接到第一項的「(一)(二)」後面，先誤報「編號重複」，
            # --apply-renumber 再把它們實際改寫成「(三)(四)」，原文就毀了。
            clause_written = point_written = item_parent = None
            paragraph_no += 1
            clause_serial = point_serial = 1
        elif level == "款":
            match = _CLAUSE_RE.match(text)
            written = cn_to_int(match.group(1)) if match else None
            clause_written = written
            point_written = item_parent = None
            clause_serial = context.get("group_serial", 1)
            point_serial = 1
        elif level == "點":
            match = _POINT_RE.match(text)
            written = cn_to_int(unicodedata.normalize("NFKC", match.group(1))) if match else None
            point_written = written
            item_parent = None
            point_serial = context.get("group_serial", 1)
        elif level == "目":
            item_style = _item_style_of(text)
            match = _ITEM_RE.match(text)
            written = cn_to_int(unicodedata.normalize("NFKC", match.group(2))) if match else None
            if item_style == _ITEM_STYLE_CN:
                item_parent = written

        entries.append({
            "index": idx, "level": level, "article": context["article"],
            "written": written, "clause_written": clause_written,
            "point_written": point_written, "item_style": item_style,
            "paragraph_no": paragraph_no,
            "clause_serial": clause_serial, "point_serial": point_serial,
            # 中文目自己就是群的頭，不掛在別的目底下
            "item_parent": None if item_style == _ITEM_STYLE_CN else item_parent,
            # 沒有「第X條」的規章（作業手冊常見），款目是在章／節底下重新起算的，
            # 重編時要用章節當範圍，不能全文一串編到一百多。
            "scope": (context.get("chapter", ""), context.get("section", "")),
        })
    return entries


def plan_renumber(paragraphs, entries):
    """
    算出「哪一段的編號要從幾號改成幾號」。

    款：同一條底下的款，由上而下重編為 一、二、三……
    目：同一條同一款底下的目，重編為 (一)(二)(三)……

    回傳 (變更清單, 款對照表, 目對照表)。
    對照表是給交叉引用檢查用的：{(條號, 舊號): 新號}
    """
    changes = []
    clause_map = {}
    item_map = {}
    if not numbering_check_applicable(entries):
        return changes, clause_map, item_map

    clause_counter = {}
    item_counter = {}

    for entry in entries:
        article = entry["article"]
        # 有「第X條」就以條為範圍；沒有就以章／節為範圍
        group = _numbering_group(entry)

        if entry["level"] == "款":
            clause_counter[group] = clause_counter.get(group, 0) + 1
            new_no = clause_counter[group]
            if entry["written"] is not None:
                # 鍵要帶「第幾項」：每一項的款都從一起算，第二項的第四款會蓋掉第一項的第四款（B1）
                clause_map[(article, entry.get("paragraph_no") or 1, entry["written"])] = new_no
            if entry["written"] != new_no:
                changes.append({
                    "index": entry["index"], "level": "款",
                    "article": article,
                    "old": entry["written"], "new": new_no,
                    "old_text": paragraphs[entry["index"] - 1],
                    "new_text": _CLAUSE_RE.sub(
                        lambda m: int_to_cn(new_no) + m.group(2),
                        paragraphs[entry["index"] - 1], count=1),
                })

        elif entry["level"] == "目":
            style = entry.get("item_style") or _ITEM_STYLE_CN
            key = _item_group_key(entry, group)
            item_counter[key] = item_counter.get(key, 0) + 1
            new_no = item_counter[key]
            if entry["written"] is not None:
                map_key = (article, entry.get("paragraph_no") or 1, entry["clause_written"], entry["written"])
                # 交叉引用寫的是「第二目」這種中文寫法，中文體系優先佔位，
                # 阿拉伯體系只在中文沒佔到時補上，避免兩種體系互相覆蓋。
                if style == _ITEM_STYLE_CN:
                    item_map[map_key] = new_no
                else:
                    item_map.setdefault(map_key, new_no)
            if entry["written"] != new_no:
                number = _number_text(style, new_no)
                changes.append({
                    "index": entry["index"], "level": "目", "style": style,
                    "article": article,
                    "old": entry["written"], "new": new_no,
                    "old_text": paragraphs[entry["index"] - 1],
                    "new_text": _item_pattern(style).sub(
                        lambda m: m.group(1) + number + m.group(3),
                        paragraphs[entry["index"] - 1], count=1),
                })

    return changes, clause_map, item_map


def _item_group_key(entry, group):
    """目重新起算的範圍。

    中文目掛在（範圍, 款, 點）底下；阿拉伯目再往下掛一層，多帶所屬的中文目。
    少了「點」與「所屬中文目」這兩段，同一款底下不同小群的 (1) 會被併成一串，
    第二群的 (1) 就會被改寫成 (3)——那是實測 idx 45 毀掉原文的那條路。
    """
    style = entry.get("item_style") or _ITEM_STYLE_CN
    base = (style, group, entry.get("clause_written"),
            entry.get("point_written"), entry.get("point_serial") or 1)
    if style == _ITEM_STYLE_AR:
        return base + (entry.get("item_parent"),)
    return base


def find_numbering_gaps(entries):
    """
    找出編號本身就有問題的地方（斷號、重號、沒從一開始）。

    這是「使用者刪了款但沒重編」的直接證據，也是最容易在 50 頁內規裡漏看的東西。
    """
    if not numbering_check_applicable(entries):
        return []
    return _numbering_problems(entries)


def _numbering_problems(entries, include_points=False):
    """find_numbering_gaps 的本體，不看「適不適用」：沒有條的文件由 point_numbering_issues 呼叫。
    include_points：「1.」那一層也查（有條的文件照舊不查，行為不變）。
    每一筆多帶 indices（這一組每一段的段次）與 scope（章、節），分辨「這次改出來的」要用。"""
    problems = []
    groups = {}
    doc_wide = include_points and _points_run_through(entries)
    for entry in entries:
        # 跟 plan_renumber 同一套：有「第X條」以條為範圍，沒有就以章／節為範圍。
        # 作業手冊每章各自從「一、」起算，全文合成一組會被誤判成「編號重複」。
        # 例外：要點常見「一、」一路編到底、跨章不重來，那種文件整份當一串查。
        group = _numbering_group(entry)
        if entry["level"] == "款":
            if doc_wide and (entry.get("clause_serial") or 1) == 1:
                group = ("全文",)
            groups.setdefault(("款", group), []).append(entry)
        elif entry["level"] == "目":
            # 分群方式跟 plan_renumber 一模一樣：兩種數字體系、不同的點與中文目
            # 各自成群，否則會把「(一)(1)(2)(二)(1)」誤報成編號重複。
            groups.setdefault(("目",) + _item_group_key(entry, group),
                              []).append(entry)
        elif entry["level"] == "點" and include_points:
            groups.setdefault(("點", group, entry.get("clause_written"),
                               entry.get("point_serial") or 1), []).append(entry)

    for key, group in groups.items():
        written = [e["written"] for e in group]
        if any(w is None for w in written):
            continue
        expected = list(range(1, len(written) + 1))
        if written == expected:
            continue

        if len(set(written)) != len(written):
            reason = "編號重複"
        elif written[0] != 1:
            reason = "沒有從第一%s開始" % key[0]
        else:
            reason = "編號不連續（中間有缺號，通常是刪除後沒有重編）"

        # 沒有條的文件（include_points）指到第一個對不上的那一段：整份一串的要點動輒二三十點，
        # 講「第 3 段起」人還要自己往下數到出錯的地方
        at = 0
        if include_points:
            at = next(i for i, (w, x) in enumerate(zip(written + [None], expected + [None])) if w != x)
            at = min(at, len(group) - 1)
        problems.append({
            "level": key[0], "article": group[0]["article"],
            "style": group[0].get("item_style"),
            "written": written, "expected": expected, "reason": reason,
            "first_index": group[at]["index"], "at": at,
            "indices": [e["index"] for e in group], "scope": group[at].get("scope") or ("", ""),
            "parent": (group[0].get("clause_written") if key[0] != "款" else None),
        })
    problems.sort(key=lambda p: p["first_index"])
    return problems


def _points_run_through(entries):
    """沒有條的文件，第一層的點（一、）是不是全文一路編下去、跨章節不重來。

    各章節第一層那一串照出現順序排好，下一串接著上一串的號碼往下編的次數，
    比從「一、」重來的次數多，就是一路編到底（要點最常見）；否則各章節各自起算（手冊）。"""
    runs = []
    for entry in entries:
        if entry["level"] != "款" or entry["written"] is None or (entry.get("clause_serial") or 1) != 1:
            continue
        if runs and runs[-1][0] == entry.get("scope"):
            runs[-1][2] = entry["written"]
        else:
            runs.append([entry.get("scope"), entry["written"], entry["written"]])
    pairs = list(zip(runs, runs[1:]))
    through = sum(1 for prev, cur in pairs if cur[1] == prev[2] + 1)
    restart = sum(1 for prev, cur in pairs if cur[1] == 1)
    return through > restart


def numbering_check_applicable(entries):
    """款目編號檢查／重編只適用於「第X條」底下有款目的規章。

    作業手冊型文件沒有條，款目在標題（含程式看不到的小標）底下各自重新起算，
    無論用條還是章／節分組都會誤報「編號重複」、也會提出錯的重編。真資料實測：
    1,347 段的手冊用章／節分組仍誤報 14 處。所以沒有任何一條的文件直接跳過。"""
    return any(e.get("article") for e in entries)


def _numbering_group(entry):
    """編號重新起算的範圍：有條用（條, 項次），沒有條用 (章, 節)。
    plan_renumber 與 find_numbering_gaps 共用。

    項次一定要進來：一條有兩項時，每一項的款都是從「一、」重新起算的，
    合成一組會誤報「編號重複」，重編還會把第二項的款目實際改號（毀原文）。
    同一項裡被沒有編號的段落分成兩組的款（build_hierarchy 的「（第N組）」）也一樣，
    所以組序號也要進來。"""
    serial = entry.get("clause_serial") or 1
    article = entry.get("article") or ""
    if article:
        return (article, entry.get("paragraph_no") or 1, serial)
    return ("§",) + tuple(entry.get("scope") or ("", "")) + (serial,)


# 舊條有這麼多比例的字出現在同一條新條裡，就算「被併進去」而不是「被刪掉」。
# 0.6 是這樣抓的：真的併條時舊條文幾乎原封不動搬過去，覆蓋率都在 0.9 以上；
# 只是碰巧用詞相近的兩條通常落在 0.3 以下，0.6 留了很寬的安全帶。
MERGE_COVERAGE = 0.6


def _article_texts(paragraphs, kinds=None):
    """把全文切成一條一條：[(條號, 這一條的原文全文)]。原文保留原字。

    整條的文字（條文本體加底下的款目項）才是配對的依據。只拿第一段比，
    兩條開頭都寫「本公司辦理下列事項：」就會互相配錯。
    """
    units = []
    current = None
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] == "條" and context["article"]:
            if current is None or context["article"] != current[0]:
                current = [context["article"], [strip_article_no(text)]]
                units.append(current)
                continue
        if current is not None:
            current[1].append(text)
    return [(article, "".join(parts)) for article, parts in units]


def _article_units(paragraphs, kinds=None):
    """比對用的條文：條號加上正規化過的全文。

    只差全半形或空白的同一條要配得起來，所以比對前一律正規化；
    要印出來或寫進產出檔的一律用 _article_texts 的原文。
    """
    return [(article, normalize_for_compare(text))
            for article, text in _article_texts(paragraphs, kinds)]


def _coverage(old_body, new_body):
    """舊條的文字有多少比例出現在新條裡（0.0~1.0）。用來認「併條」。"""
    if not old_body:
        return 0.0
    matcher = difflib.SequenceMatcher(None, old_body, new_body, autojunk=False)
    matched = sum(block.size for block in matcher.get_matching_blocks())
    return matched / float(len(old_body))


def _align_block(old_chunk, new_chunk):
    """對一個被改過的區塊做一對一對齊。

    回傳 ([(舊區塊內序號, 新區塊內序號或 None), ...], 有沒有走帶狀對齊)。

    對齊演算法跟修正對照表用的是同一支（diff_compare.align_chunk）：保持前後順序、
    總相似度最高。兩邊各寫一份的話，對照表說「這兩條是同一條」、交叉引用卻說
    「這一條被刪了」，兩張產出自相矛盾。

    align_chunk 遇到大區塊會自己印「改用帶狀對齊」的提醒，那段話講的是修正對照表，
    對條號對照是錯的描述，而且一次執行會被印好幾遍。用 diff_compare 自己的收集
    機制先接住，由呼叫端改印一句講條號對照的。
    """
    import diff_compare

    outer = diff_compare._banded_notices
    diff_compare._banded_notices = []
    try:
        pairs = diff_compare.align_chunk(old_chunk, new_chunk)
        banded = bool(diff_compare._banded_notices)
    finally:
        diff_compare._banded_notices = outer

    # align_chunk 回傳的是文字，同一份文件裡可能有兩條文字一模一樣，
    # 所以照順序走游標還原到底是第幾條，不要拿文字回去查。
    result = []
    oi = nj = 0
    for old_text, new_text in pairs:
        if old_text is not None and new_text is not None:
            result.append((oi, nj))
            oi += 1
            nj += 1
        elif old_text is not None:
            result.append((oi, None))
            oi += 1
        else:
            nj += 1
    return result, banded


def _prefer_same_article(old_units, new_units, unpaired, new_indices,
                         old_to_new, new_to_old):
    """同號優先：條號一樣、內容又對得上的，一定是同一條。

    align_chunk 只看文字分數，併條時常常把「新的第四條」配給「舊的第五條」
    （併進去之後新條比較長，跟長的那一條分數比較高），結果報成
    「第四條不見了、併入第四條」——那句話沒有人看得懂。

    unpaired 會被就地改掉：換掉的那一條進來、原本佔位的那一條出去。
    """
    for i in list(unpaired):
        article, old_body = old_units[i]
        for j in new_indices:
            new_article, new_body = new_units[j]
            if not _same_article(new_article, article):
                continue
            if _coverage(old_body, new_body) < MERGE_COVERAGE:
                continue
            holder = new_to_old.get(j)
            if holder is not None:
                del old_to_new[holder]
                unpaired.append(holder)
            old_to_new[i] = j
            new_to_old[j] = i
            unpaired.remove(i)
            break


def plan_article_map(old_paragraphs, new_paragraphs,
                     old_kinds=None, new_kinds=None):
    """
    用「內容」把舊版的條配到新版的條，回傳 {舊條號: {"new":…, "merged_into":…}}。

    new 是新版對應的條號，配不到就是 None；merged_into 是「被併進哪一條」。

    為什麼不能只比條號集合：條號預設不重編，但實務上使用者常常自己先遞補過，
    也常常把兩條併成一條。只比集合的話，「第十條改叫第九條」會被報成
    「第十條被刪除」，人就會去補一個根本不該補的「（刪除）」註記；
    而別的條文寫的「第十條」其實已經指到不同的內容，反而沒人講。
    """
    old_units = _article_units(old_paragraphs, old_kinds)
    new_units = _article_units(new_paragraphs, new_kinds)
    if not old_units:
        return {}
    old_bodies = [body for _, body in old_units]
    new_bodies = [body for _, body in new_units]

    # 先用 difflib 的 opcodes 把「一模一樣的條」整段對掉（跟 _compare_paragraphs
    # 同一套做法），只有真的被改過的 replace 區塊才送進相似度對齊。
    # 不做這一步的話，一份 300 條的規章即使只刪了 3 條，也要算 300x297 格相似度
    # （實測 1.9 秒，而且一定會觸發帶狀對齊的提醒），那個提醒還是假警報。
    old_to_new = {}
    new_to_old = {}
    unpaired = []
    banded = False
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(
            None, old_bodies, new_bodies).get_opcodes():
        if tag == "equal":
            for offset in range(i2 - i1):
                old_to_new[i1 + offset] = j1 + offset
                new_to_old[j1 + offset] = i1 + offset
        elif tag == "delete":
            unpaired.extend(range(i1, i2))
        elif tag == "insert":
            pass                    # 新版多出來的條，沒有舊條要對過去
        else:
            block_pairs, block_banded = _align_block(old_bodies[i1:i2],
                                                     new_bodies[j1:j2])
            banded = banded or block_banded
            block_unpaired = []
            for local_i, local_j in block_pairs:
                if local_j is None:
                    block_unpaired.append(i1 + local_i)
                else:
                    old_to_new[i1 + local_i] = j1 + local_j
                    new_to_old[j1 + local_j] = i1 + local_i
            _prefer_same_article(old_units, new_units, block_unpaired,
                                 range(j1, j2), old_to_new, new_to_old)
            unpaired.extend(block_unpaired)

    if banded:
        nt.notice(nt.REMINDER,
                  "改動的條很多（舊 %d 條、新 %d 條），條號對照改用帶狀對齊；"
                  "若有整章搬移，條層級的交叉引用判斷可能配錯，請人工核對"
                  % (len(old_units), len(new_units)), "Step 0.5")
    unpaired.sort()

    mapping = {}
    for i, (article, _body) in enumerate(old_units):
        j = old_to_new.get(i)
        mapping[article] = {"new": new_units[j][0] if j is not None else None,
                            "merged_into": None}

    # 配不到的再問一次：它是不是整段被搬進某一條新條裡（併條）。
    for i in unpaired:
        article, old_body = old_units[i]
        best_article, best = "", 0.0
        for j, (new_article, new_body) in enumerate(new_units):
            # 併進去的話新條一定至少跟舊條一樣長，短的直接跳過，省下大量比對
            if len(new_body) < len(old_body) * 0.9:
                continue
            # 而且併條的新條除了吃下這一條，自己原本的內容還在，所以一定比它
            # 配到的那條舊文長出一截。只看「像不像」的話，兩條碰巧寫得像的短條
            # （「甲事項規定如下。」對「乙事項規定如下。」）會被誤報成併條，
            # 真正被刪掉的那一條就沒有人去補「（刪除）」註記了。
            holder = new_to_old.get(j)
            grown = len(new_body) - (len(old_units[holder][1])
                                     if holder is not None else 0)
            if grown < len(old_body) * MERGE_COVERAGE:
                continue
            score = _coverage(old_body, new_body)
            if score > best:
                best_article, best = new_article, score
        if best >= MERGE_COVERAGE:
            mapping[article]["merged_into"] = best_article
    return mapping


def find_changed_paragraphs(old_paragraphs, new_paragraphs,
                            old_kinds=None, new_kinds=None):
    """回傳「本次有改過」的新版段次集合（1 起算）。

    比的是去掉條號、正規化過的本體：條號本身會因為重編而變，那不算改內容。
    一段的本體在舊版裡找得到（不管在哪一段）就算沒改。

    用途是條層級引用的保險絲：重編之後，「作者已經改好的新號」跟「還沒改的舊號」
    在文字上一模一樣，程式分不出來。分不出來的時候唯一安全的說法是
    「這一段本次有改，你自己確認」，不能猜。
    """
    old_bodies = set()
    for text in old_paragraphs:
        old_bodies.add(normalize_for_compare(strip_article_no(text)))
    changed = set()
    for idx, text in enumerate(new_paragraphs, 1):
        if normalize_for_compare(strip_article_no(text)) not in old_bodies:
            changed.add(idx)
    return changed


def find_deleted_articles(old_paragraphs, new_paragraphs,
                          old_kinds=None, new_kinds=None, article_map=None):
    """
    比對新舊版，找出新版找不到的舊條號。

    回傳 [{"article": 舊條號, "status": "刪除"／"併入", "into": 新條號}]。

    條號預設不重編，所以刪掉之後新版會出現條號斷點。依法制慣例，
    真的刪掉應該保留條號並註記「第○條　（刪除）」，讓後面的條號維持不變。
    但「併入別條」不是刪除——補「（刪除）」註記反而是錯的，所以分開報。

    article_map 給了就直接用，省得同一次執行把條號對照算兩遍。
    """
    if article_map is None:
        article_map = plan_article_map(old_paragraphs, new_paragraphs,
                                       old_kinds, new_kinds)
    result = []
    for article, info in article_map.items():
        if info["new"] is not None:
            continue
        if info["merged_into"]:
            result.append({"article": article, "status": "併入",
                           "into": info["merged_into"]})
        else:
            result.append({"article": article, "status": "刪除", "into": ""})
    return result


# ---------------------------------------------------------------------------
# 交叉引用
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 交叉引用解析
# ---------------------------------------------------------------------------
#
# 這一段是整支程式風險最高的地方。內規裡的引用寫法遠比「第五條第二款」複雜：
#
#     前條第三款及第四款      ← 「及第四款」的範圍要延續前面的「前條」
#     第五條第二款至第四款    ← 範圍寫法，實際指的是第二、三、四款
#     依前款規定              ← 相對引用，要看它自己在第幾款
#     前二項                  ← 往前數兩個
#     依第五條規定            ← 只到條層級
#
# 每一種漏掉，就是一處指錯的引用送進正式修法文件。所以這裡用逐字掃描配上
# 範圍狀態，而不是一條大正規表示式硬套。
#
# 判定結果分四種：
#     安全      引用的目標編號沒變
#     需改寫    目標還在、只是換號，機械式改寫是安全的
#     危險      目標已被刪除，沒有正確的改寫方式
#     無法判定  解析不出來（可能是原文寫法特殊，也可能本來就寫錯）
#
# 「無法判定」一定要列出來，不能默默跳過 —— 沉默才是最危險的結果。

# 相對引用的「前」要是一個詞的開頭：「目前項目」「當前條件」「先前款項」裡的「前項」
# 「前條」「前款」不是引用。以前沒有邊界，「目前項目」被當成「前項」，
# 還會拿它去算「本條的前一項」。「以前項規定」是「以 前項」，「以」不在排除之列。
_PREV = r"(?<![目當先事提日眼從空])前"

_TOKEN_RE = re.compile(
    r"(?P<article>第\s*[%(cn)s\d]+\s*條(?:\s*之\s*[%(cn)s\d]+)?)"
    r"|(?P<prev_article>%(prev)s\s*[%(cn)s]*\s*條)"
    r"|(?P<this_article>本條)"
    r"|(?P<para>第\s*[%(cn)s\d]+\s*項)"
    r"|(?P<prev_para>%(prev)s\s*[%(cn)s]*\s*項)"
    r"|(?P<clause>第\s*[%(cn)s\d]+\s*款)"
    r"|(?P<prev_clause>%(prev)s\s*[%(cn)s]*\s*款)"
    r"|(?P<all_clause>各\s*款)"
    r"|(?P<item>第\s*[%(cn)s\d]+\s*目)"
    r"|(?P<prev_item>%(prev)s\s*[%(cn)s]*\s*目)"
    r"|(?P<rangemark>至)"
    r"|(?P<conj>[及或與和、])"
    r"|(?P<stop>[。；：])" % {"cn": CN, "prev": _PREV})

_NUM_IN_TOKEN = re.compile(r"[%s\d]+" % CN)


def _token_number(token_text):
    """從「第十二款」這種字串裡取出數字。取不到回 None。"""
    match = _NUM_IN_TOKEN.search(token_text.replace("第", "").replace("前", ""))
    return cn_to_int(match.group(0)) if match else None


def _relative_offset(token_text):
    """「前款」指前面 1 個，「前二款」指前面 2 個（前兩款）。回傳往前涵蓋幾個。"""
    number = _token_number(token_text)
    return number if number else 1


def _relative_targets(base_no, token_text):
    """相對引用指到哪幾號：「前款」＝[base-1]，「前二款」＝[base-2, base-1]。數不到回 None。

    「前二款」「前二項」是「前兩款」「前兩項」，不是「往前數第二款」。以前解成往前數第二款
    一個號碼：「五、不符前二款規定者」被當成只引第三款，第四款被刪也不報（實測 R-M）。"""
    if not base_no:
        return None
    count = _relative_offset(token_text)
    targets = list(range(base_no - count, base_no))
    return targets if targets and targets[0] >= 1 else None


# 「前條」後面緊接著第X項／款／目（或「各款」），範圍才延續給後面的引用；
# 沒接的話「前條」自己就是一個條層級引用（「違反前條規定者」）。
_CHAINED_AFTER_RE = re.compile(r"\s*(?:第\s*[%s\d]+\s*[項款目]|各\s*款)" % CN)


def parse_references(text, own_article, own_clause, previous_article,
                    own_para=None, skip_declaration=False, own_item=None, own_para_no=None,
                    previous_articles=None):
    """
    解析一段文字裡的所有條款目引用。

    own_article／own_clause／own_para：這一段自己所在的條、款、項，
    用來解析沒寫範圍的引用（例如條文裡直接寫「第三款」，指的就是本條第三款；
    「前項」指的是本條的前一項）。
    previous_article：這一段的「前條」是哪一條。
    previous_articles：這一段之前的各條（照全文順序，最近的在最後）；「前二條」要往前數兩條。
        沒給就只知道 previous_article 那一條。
    skip_declaration：這一段開頭的「第X條」是這一條的條號，不是引用。
        不跳過的話，條層級判定會把條文自己的條號當成要改寫的引用，
        --rewrite-refs 就會直接改掉條號本身。

    回傳引用清單，每筆含 span（在原文的起訖位置，供改寫用）、
    article（指向哪一條）、kind（款／目／項／條）、numbers（指向哪幾號）；
    external 有值代表那是外部法規的條號（例如「個人資料保護法第五條」），
    本程式不判也不改。
    """
    references = []
    scope_article = own_article
    # 引用鏈：「第二項第四款」「第二款第三目」——款跟在項後面、目跟在款後面時，
    # 指的是那一項的款、那一款的目，不是本段自己所在的（B1、B2）。記 (號碼, 結束位置, 所屬項)
    chain_para = None
    chain_clause = None
    scope_span = None        # 範圍前綴在原文的位置，例如「前條」「第五條」
    pending_range = False
    last_reference = None
    # 外部法規的引用鏈延伸到哪個位置：「個人資料保護法第五條第三款」的「第三款」
    # 緊接在後面，也是別人家的，不能拿本文的對照表去判。
    external_chain_end = None
    # 範圍是不是「前條」給的：新舊版各推算一次時，「前條第二款」的前條也要照舊版重算
    scope_relative = False

    def display_quote(token_span):
        """
        報告裡要顯示的引用字句。

        span 只涵蓋號碼那一段（改寫時只能動那裡），但報告寫「引用『第二款』」
        會讓人看不出是哪一條的第二款。所以緊接在範圍前綴後面的引用，
        顯示時把前綴一起帶上，變成「前條第二款」。
        """
        if scope_span and scope_span[1] == token_span[0]:
            return text[scope_span[0]:token_span[1]]
        return text[token_span[0]:token_span[1]]

    for match in _TOKEN_RE.finditer(text):
        kind = match.lastgroup
        token = match.group(0)

        # 緊接在外部法規條號後面的款目（中間只隔連接詞），一律跟著算外部的。
        # 不是緊接著的就不算，否則「保險法第五條所定事項，第三款另有規定」這種
        # 後半句其實是本文自己的引用，會被整句跳過不檢查。
        chained = (external_chain_end is not None
                   and match.start() == external_chain_end)
        if chained and kind in ("clause", "item", "para", "conj", "rangemark"):
            external_chain_end = match.end()
            continue
        if kind != "article":
            external_chain_end = None

        if kind == "stop":
            # 句子結束，範圍重設回本條，「及」的延續也中斷
            scope_article = own_article
            scope_span = None
            scope_relative = False
            pending_range = False
            last_reference = None
            continue

        if kind == "conj":
            # 「及」「或」「、」本身不重設範圍，讓後面的「第四款」延用前面的條
            continue

        if kind == "rangemark":
            pending_range = True
            continue

        if kind == "article":
            law = is_external_reference(text, match.span())
            if law:
                # 別人家的法條。記一筆讓報告看得到，但不判、不改；
                # 範圍也不能留給它，否則後面沒帶條號的「第三款」會被算到它頭上。
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": re.sub(r"\s+", "", token),
                    "kind": "條", "numbers": None, "is_range": False,
                    "external": law,
                })
                scope_article = own_article
                scope_span = None
                scope_relative = False
                external_chain_end = match.end()
                last_reference = None
                continue

            external_chain_end = None
            scope_article = re.sub(r"\s+", "", token)
            scope_span = match.span()
            scope_relative = False
            if skip_declaration and not text[:match.start()].strip():
                # 段落開頭的「第七條」是這一條的條號，不是引用
                scope_span = None
                last_reference = None
                continue
            # 條層級的引用本身也要記一筆。「本公司得依第五條規定辦理」這種
            # 沒帶款目的引用，只要第五條被整條刪掉就會指空，不能漏掉。
            references.append({
                "span": match.span(), "raw": token, "article": scope_article,
                "kind": "條", "numbers": None, "is_range": False,
            })
            last_reference = None
            continue

        if kind == "prev_article":
            offset = _relative_offset(token)
            scope_article = previous_article if offset == 1 else ""
            scope_span = match.span()
            scope_relative = True
            last_reference = None
            if not _CHAINED_AFTER_RE.match(text, match.end()):
                # 單獨寫的「前條」「前二條」本身就是條層級引用。以前這裡只設範圍、不記引用：
                # 「違反前條規定者」的前一條被刪、或中間插進一條，前條改指別條也沒有人講（C7b、C9）。
                chain = list(previous_articles if previous_articles is not None
                             else ([previous_article] if previous_article else []))
                targets = chain[-offset:] if len(chain) >= offset else None
                references.append({
                    "span": match.span(), "raw": token, "token": token,
                    "article": targets[-1] if targets else "", "kind": "條",
                    "numbers": None, "is_range": offset > 1, "relative": True,
                    "offset": offset, "targets": targets, "own_article": own_article,
                    "note": "" if targets else
                            "往前數不到%d條，解析不出「%s」指的是哪一條" % (offset, token),
                })
            continue

        if kind == "this_article":
            scope_article = own_article
            scope_span = match.span()
            scope_relative = False
            last_reference = None
            continue

        if kind in ("para", "prev_para"):
            # 項不像款目那樣把編號寫在文字裡，所以沒有「重編」可言；
            # 但它一樣會出事——刪掉一個項，後面的項次全部往前移，
            # 「前項」「第二項」就指到別的東西了。
            #
            # 早期版本這裡直接 continue，等於靜默略過，違反本程式的原則
            # （解析不出來也要列出來，沉默才是最危險的結果）。現在照樣產生
            # 引用記錄，交給 _judge 與 scan_reference_drift 判斷。
            if kind == "prev_para":
                offset = _relative_offset(token)
                targets = _relative_targets(own_para, token)
                if targets:
                    note, hint = "", None
                elif own_para:
                    # 知道自己是第幾項，卻算出往前指到第 0 項或更前面，
                    # 那就是明確的錯：本條第一項前面沒有項可以指。
                    if own_para == 1:
                        note = ("這一段是本條的第一項，前面沒有項可以指，"
                                "「%s」指不到東西" % token)
                    else:
                        note = ("這一段是本條的第 %d 項，前面只有 %d 項，"
                                "「%s」要再往前數 %d 項，指不到東西"
                                % (own_para, own_para - 1, token, offset))
                    hint = "危險"
                else:
                    note = ("這一段本身不在任何條的項次之內，"
                            "解析不出「%s」指的是哪一項" % token)
                    hint = None
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": scope_article, "kind": "項",
                    "numbers": targets, "is_range": bool(targets and len(targets) > 1),
                    "relative": True, "offset": offset, "own_no": own_para,
                    "own_article": own_article,
                    "note": note, "status_hint": hint,
                })
            else:
                number = _token_number(token)
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": scope_article, "kind": "項",
                    "numbers": [number] if number else None,
                    "note": "" if number else "解析不出項次",
                    "own_article": own_article, "scope_relative": scope_relative,
                    "scope_span": scope_span,
                })
                if number:
                    chain_para = (number, match.end())
            last_reference = None
            continue

        if kind == "all_clause":
            references.append({
                "span": match.span(), "raw": token, "article": scope_article,
                "kind": "款", "numbers": None, "note": "「各款」指全部，重編不影響",
            })
            last_reference = None
            continue

        if kind in ("clause", "item"):
            unit = "款" if kind == "clause" else "目"
            number = _token_number(token)
            if number is None:
                continue

            if pending_range and last_reference and last_reference["kind"] == unit:
                # 「第二款至第四款」：把範圍展開成 2、3、4，並把兩端合併成一筆
                start = last_reference["numbers"][0]
                last_reference["numbers"] = list(range(min(start, number),
                                                       max(start, number) + 1))
                last_reference["span"] = (last_reference["span"][0], match.span()[1])
                last_reference["raw"] = text[last_reference["span"][0]:
                                             last_reference["span"][1]]
                last_reference["is_range"] = True
                last_reference["is_range"] = True
                pending_range = False
                continue

            para, explicit = None, False
            if unit == "款" and chain_para and chain_para[1] == match.start():
                para, explicit = chain_para[0], True
            clause_of = None
            if unit == "目" and chain_clause and chain_clause[1] == match.start():
                clause_of, para, explicit = chain_clause[0], chain_clause[2], chain_clause[3]
            if para is None and scope_article == own_article:
                para = own_para_no or own_para       # 沒寫項：本條就是本段所在的那一項
            reference = {
                "para": para, "para_explicit": explicit,
                "clause": clause_of if unit == "目" else None,
                # span 只涵蓋號碼那一段，改寫時只能動這裡；
                # raw 是報告要顯示的字句，會把「前條」「第五條」這種前綴帶上；
                # token 是純號碼字串，改寫時拿它去換，不能用 raw，
                # 否則「第五條第四款」會被改成「第五條第五條第三款」。
                "span": match.span(), "raw": display_quote(match.span()),
                "token": token, "article": scope_article,
                "kind": unit, "numbers": [number], "is_range": False,
                "own_article": own_article, "scope_relative": scope_relative,
                "scope_span": scope_span,
            }
            references.append(reference)
            last_reference = reference
            pending_range = False
            if unit == "款":
                chain_clause = (number, match.end(), para, explicit)
            continue

        if kind in ("prev_clause", "prev_item"):
            unit = "款" if kind == "prev_clause" else "目"
            offset = _relative_offset(token)
            # 「前目」往前數的是本段自己的目號，不是所在的款號（B2）
            base_no = own_clause if unit == "款" else own_item
            if base_no is None:
                references.append({
                    "span": match.span(), "raw": token, "article": scope_article,
                    "kind": unit, "numbers": None,
                    "note": "這一段本身不在任何%s之下，解析不出「%s」指的是哪一%s"
                            % (unit, token, unit),
                })
            else:
                targets = _relative_targets(base_no, token)
                references.append({
                    "span": match.span(), "raw": token, "token": token, "article": scope_article,
                    "kind": unit, "para": own_para_no or own_para, "para_explicit": False,
                    "clause": own_clause if unit == "目" else None,
                    "numbers": targets, "is_range": bool(targets and len(targets) > 1),
                    "relative": True, "offset": offset, "own_no": base_no,
                    "own_article": own_article,
                    "note": "" if targets else "「%s」往前數超出範圍" % token,
                })
            last_reference = None
            continue

    return references


def scan_references(paragraphs, entries, clause_map, item_map,
                    known_articles=None, articles_with_clauses=None,
                    kinds=None, article_map=None, changed_paragraphs=None,
                    old_paragraphs=None, old_kinds=None):
    """
    掃描全文的交叉引用，判斷它們會不會因為重編而指錯。

    clause_map／item_map 是 plan_renumber() 算出來的「舊號 → 新號」對照。
    known_articles 是全文實際存在的條號集合，用來抓出指向不存在條號的引用。
    article_map 是 plan_article_map() 算出來的「舊條號 → 新條號」對照；
    沒給就代表沒有舊版可比對，條層級一律不下結論（報告印「未檢查」），
    絕對不可以因此印「沒有受影響」。
    changed_paragraphs 是 find_changed_paragraphs() 算出來的「本次有改過」段次，
    用來把「這一段自己也被改過」的條層級引用降級成危險（見 _judge）。
    old_paragraphs／old_kinds：舊版全文。給了（而且有 article_map）就再做一次「新舊版各推算一次」：
    同一段在舊版找回原本那一段，相對引用（前項、前X款）與款、項號各自推算指到誰，經條號對照
    比較（見 cross_version_references）。沒給就只看新版，跟以前一樣。
    """
    contexts = build_hierarchy(paragraphs, kinds)
    entry_by_index = {e["index"]: e for e in entries}
    if articles_with_clauses is None:
        articles_with_clauses = {e["article"] for e in entries
                                 if e["level"] == "款" and e["article"]}

    # 每一條有幾項，用來判斷「第三項」這種引用指不指得到
    para_counts = {}
    for context in contexts:
        if context["level"] in ("條", "項") and context["article"]:
            ordinal = _paragraph_ordinal(context) or 1
            key = context["article"]
            para_counts[key] = max(para_counts.get(key, 0), ordinal)

    cross = None
    if old_paragraphs is not None and article_map:
        cross = cross_version_references(old_paragraphs, paragraphs, old_kinds, kinds,
                                         article_map=article_map)

    findings = []

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        entry = entry_by_index.get(idx, {})
        own_clause = entry.get("clause_written")
        references = _paragraph_references(text, context, entry, contexts, idx)

        for reference in references:
            finding = _judge(reference, text, idx, clause_map, item_map,
                             own_clause, known_articles, articles_with_clauses,
                             para_counts, article_map, changed_paragraphs)
            if cross is not None:
                key = (idx, tuple(reference["span"]))
                if key in cross["verdicts"]:
                    finding = _merge_cross(finding, cross["verdicts"][key])
                if finding and reference.get("relative") and idx in cross["added"]:
                    # 新版才有的段落：「前條」「前項」是照新版寫的，沒有「舊版指誰」可比
                    # （條層級那支保險絲把新增段落也算成「本次有改」，會誤報成危險）
                    if finding.get("note", "").startswith("危險（引用所在段落本次有改"):
                        finding = None
                if (finding and not finding.get("cross")
                        and finding.get("status") in ("危險", "無法判定")
                        and cross["old_status"].get(key) == finding["status"]):
                    # 舊版同一處就是一樣的問題（例：「前項」寫在本條第一項）：不是這次改出來的，
                    # 照列，但不進連帶決定表、提醒併成一則（大型內規實測 40 列都是這種）
                    finding = dict(finding, pre_existing=True,
                                   note=finding.get("note", "") + "（舊版同一處就是這樣，不是這次改出來的）")
            if finding:
                findings.append(finding)

    return findings


def _paragraph_references(text, context, entry, contexts, idx):
    """一段裡的引用。scan_references 與新舊版各推算一次共用，兩邊的解析才一模一樣。"""
    # own_para（這一段是所在條的第幾項）：條文本體與項照層級脈絡算；款、目、點是它所在的那一項
    # （「一、前項所定文件」的前項是本項的前一項，以前一律「解析不出」）。
    # 表格儲存格裡的段落層級是「其他」，ref 卻沿用所在條——照樣傳 own_para 的話，
    # 格內的「前項」會被當成「本條第一項的前項」，判成「前面沒有項可以指」的危險
    # （實測 no 23）。那一格根本不在條的項次結構裡，傳 None 走「解析不出」那一支。
    if context["level"] in ("條", "項"):
        own_para = _paragraph_ordinal(context)
    elif context["level"] in ("款", "目", "點") and context.get("article"):
        own_para = entry.get("paragraph_no")
    else:
        own_para = None
    previous = _previous_articles_of(contexts, idx)
    return parse_references(
        text, context["article"], entry.get("clause_written"),
        previous[-1] if previous else "",
        own_para=own_para,
        skip_declaration=(context["level"] == "條"),
        own_item=entry.get("written") if entry.get("level") == "目" else None,
        own_para_no=entry.get("paragraph_no"), previous_articles=previous)


def _merge_cross(judged, verdict):
    """只看新版的判定（judged）跟新舊版各推算一次的判定（verdict）合起來。

    verdict 是 None＝新舊版指到的是同一個（內容變了另外由 scan_reference_drift 報）。
    兩邊結論一樣就留只看新版那一筆（重編時照樣可以機械式改寫）；不一樣以新舊版比對為準，
    而且只列不改（list_only）：那是照內容對齊推出來的，不是本次重編自己算出來的號碼，
    要人在決定表上看過才改。"""
    if verdict is None:
        return None
    if (verdict.get("ambiguous") and judged is not None and judged.get("status") == "需改寫"
            and (judged.get("new_quote") or "") == (verdict.get("would_quote") or "")):
        return judged
    if (judged is not None and judged.get("status") == verdict.get("status")
            and (judged.get("new_quote") or "") == (verdict.get("new_quote") or "")):
        return judged
    out = dict(verdict)
    if out.get("status") == "需改寫":
        out["list_only"] = True
    return out


_ARTICLE_NO_RE = re.compile(r"^第\s*([%s\d]+)\s*條(?:\s*之\s*([%s\d]+))?" % (CN, CN))


def normalize_article_no(text):
    """條號正規化，**只給比對用**（寫進產出檔的原文一律保留原字）。

    全形數字先用 NFKC 轉半形，再把中文數字換成阿拉伯數字，所以
    「第１２條」「第12條」「第十二條」正規化後是同一把鑰匙。
    以前是照字面比，同一份文件裡混寫全形／中文就會判成「引用的條在新版中不存在」，
    那是最高等級的「危險」警告，人得一筆一筆回去查才發現是假警報。
    認不出條號就回去掉空白的原字，不硬猜。
    """
    if not text:
        return ""
    plain = re.sub(r"\s+", "", unicodedata.normalize("NFKC", text))
    match = _ARTICLE_NO_RE.match(plain)
    if not match:
        return plain
    main = cn_to_int(match.group(1))
    if main is None:
        return plain
    sub = cn_to_int(match.group(2)) if match.group(2) else None
    return "條%d%s" % (main, "之%d" % sub if sub else "")


def _same_article(left, right):
    return normalize_article_no(left) == normalize_article_no(right)


def _lookup_by_article(mapping, key):
    """字典查詢：先照原字，查不到再用正規化後的條號比一次。"""
    if key in mapping:
        return mapping[key]
    if isinstance(key, tuple):
        want = (normalize_article_no(key[0]),) + tuple(key[1:])
        for candidate, value in mapping.items():
            if (isinstance(candidate, tuple) and len(candidate) == len(key)
                    and (normalize_article_no(candidate[0]),) + tuple(candidate[1:]) == want):
                return value
        return None
    for candidate, value in mapping.items():
        if _same_article(candidate, key):
            return value
    return None


def _lookup_article_map(article_map, article):
    """在「舊條號 → 新條號」對照裡查一條，查不到回 None。條號先正規化再比。"""
    if not article_map:
        return None
    if article in article_map:
        return article_map[article]
    for candidate, value in article_map.items():
        if _same_article(candidate, article):
            return value
    return None


_AMBIGUOUS = object()


def _map_lookup(mapping, article, para, explicit, rest):
    """款／目對照表查詢。鍵是 (條, 項, …, 舊號)。
    有寫項就照那一項查；沒寫（本段所在的項只是推定）先照推定的項查，查不到再看
    全條只有一項有這個號碼就用它，好幾項都有回 _AMBIGUOUS（不能猜）。"""
    if para is not None:
        value = _lookup_by_article(mapping, (article, para) + tuple(rest))
        if value is not None or explicit:
            return value
    hits = {}
    for key, value in mapping.items():
        if (isinstance(key, tuple) and len(key) == 2 + len(rest)
                and _same_article(key[0], article) and tuple(key[2:]) == tuple(rest)):
            hits[key[1]] = value
    if len(hits) == 1:
        return list(hits.values())[0]
    return _AMBIGUOUS if hits else None


def _judge(reference, text, index, clause_map, item_map, own_clause,
           known_articles, articles_with_clauses=None, para_counts=None,
           article_map=None, changed_paragraphs=None):
    """判斷單一筆引用會不會出問題。沒問題（安全）就回 None。

    條號一律先正規化再比（normalize_article_no）：全形數字、中文數字混寫的同一條
    以前會被判成「在新版中不存在」的假危險。
    """
    base = {"index": index, "text": text, "quote": reference["raw"],
            "article": reference["article"], "kind": reference["kind"],
            "external": reference.get("external", ""),
            # 引用在原文的位置（不論判成什麼）：「內容變了」那一關拿它去重，決定表拿它對位置
            "ref_span": tuple(reference.get("span") or ())}

    if reference.get("external"):
        # 外部法規的條號：本程式沒有那部法規的新舊版，判不了也不該判。
        # 列出來讓人自己去查，但絕對不能改寫（實測 idx 142 就是被改掉的）。
        base.update({"status": "外部法規", "law": reference["external"],
                     "note": "這是「%s」的條號，不是本規章的條，本程式不檢查也不改寫"
                             % reference["external"]})
        return base

    if reference.get("note") and reference.get("numbers") is None:
        if "各款" in reference["raw"]:
            return None      # 「各款」指全部，不受重編影響
        base.update({"status": reference.get("status_hint") or "無法判定",
                     "note": reference["note"]})
        return base

    if not reference["article"]:
        base.update({"status": "無法判定",
                     "note": "解析不出這個引用指向哪一條，請人工確認"})
        return base

    if known_articles is not None and not any(
            _same_article(reference["article"], known) for known in known_articles):
        base.update({"status": "危險",
                     "note": "引用的 %s 在新版中不存在" % reference["article"]})
        return base

    if reference["kind"] == "條":
        # 以前這裡直接 return None，理由是「條號不重編，條存在就沒事」。
        # 但實務上使用者常常自己把條號往前遞補過：新版的確有「第七條」，
        # 內容卻已經是舊版的第八條——寫「第七條」的地方全部指錯，
        # 程式卻一聲不吭，報告還印「沒有受影響的交叉引用」（實測 idx 63、80）。
        if article_map is None:
            # 沒有舊版可比對，算不出舊條號跟新條號的對應。這裡不下任何結論，
            # 由 report() 把條層級整段印成「未檢查」。
            return None
        if reference.get("relative"):
            # 「前條」不能拿新版的前一條去查對照表：新版的前一條永遠在，查到的不是舊版沒有
            # （被當成新寫的引用放過，C9）就是新舊號一樣（C7b）。要照舊版的前一條算。
            return _judge_previous_article(base, reference, article_map,
                                           changed_paragraphs, index)
        target = _lookup_article_map(article_map, reference["article"])
        if target is None:
            # 舊版根本沒有這個條號（新版才有），代表這是新版新寫的引用，
            # 作者是照新版的條號寫的，沒有位移問題，不下判斷也不列出來。
            return None
        if changed_paragraphs is not None and index in changed_paragraphs:
            # 這一段本次有改過。重編之後，「作者已經改好的新號」跟「還沒改的舊號」
            # 文字上一模一樣，程式分不出來，猜錯就是把對的條號改成錯的
            # （實測：作者已經把第七條改成第六條，程式又把它改成第五條）。
            base.update({
                "status": "危險",
                "note": "危險（引用所在段落本次有改，無法判斷是舊號或新號）："
                        "舊版的%s在新版是%s，請人工確認這裡的「%s」指的是哪一個"
                        % (reference["article"],
                           target["new"] or "已刪除或併入別條",
                           reference["article"]),
            })
            return base
        if target["new"] is None:
            if target["merged_into"]:
                base.update({
                    "status": "危險",
                    "note": "舊版的%s已併入%s，這個引用要指向哪裡必須人工確認"
                            % (reference["article"], target["merged_into"]),
                })
            else:
                base.update({
                    "status": "危險",
                    "note": "舊版的%s在新版已被刪除，沒有對應的新條號，必須人工確認"
                            % reference["article"],
                })
            return base
        if _same_article(target["new"], reference["article"]):
            return None      # 條號沒變，指到的還是同一條
        base.update({
            "status": "需改寫", "new_quote": target["new"],
            "span": reference["span"],
            "note": "被引用的條還在，只是從%s變成%s"
                    % (reference["article"], target["new"]),
        })
        return base

    if reference.get("scope_relative") and article_map:
        # 「前條第二款」：前條在新舊版指的不是同一條，後面的款項號再怎麼對也沒有意義
        shifted = _judge_previous_scope(base, reference, text, article_map,
                                        changed_paragraphs, index, clause_map)
        if shifted is not None:
            return shifted or None

    if reference["kind"] == "項":
        # 項沒有寫在文字裡的編號，沒辦法機械式改寫；能做的是確認它指得到，
        # 指不到就一定要講。實際「指到的內容變了沒有」由 scan_reference_drift
        # 比對新舊版來抓。
        counts = para_counts or {}
        total = _lookup_by_article(counts, reference["article"]) or 0
        wanted = max(reference["numbers"])       # 「前二項」兩項都要指得到
        if not total:
            base.update({"status": "無法判定",
                         "note": "%s 底下推算不出項次，請人工確認這個引用指向哪裡"
                                 % reference["article"]})
            return base
        if wanted > total:
            base.update({"status": "危險",
                         "note": "%s 只有 %d 項，但這裡引用第 %d 項，指不到"
                                 % (reference["article"], total, wanted)})
            return base
        return None

    # 引用的條底下根本沒有款，代表這個引用本身有問題（常見於「前條」指錯條），
    # 不能報成「已被刪除」——那會讓人以為是這次修訂造成的。
    if (reference["kind"] == "款" and articles_with_clauses is not None
            and not any(_same_article(reference["article"], known)
                        for known in articles_with_clauses)):
        base.update({
            "status": "無法判定",
            "note": "%s 底下沒有任何款，這個引用可能原本就寫錯，請人工確認指向哪裡"
                    % reference["article"],
        })
        return base

    mapped = []
    for number in reference["numbers"]:
        if reference["kind"] == "款":
            rest = (number,)
        else:
            clause = reference.get("clause")
            rest = (clause if clause is not None else own_clause, number)
        mapped.append(_map_lookup(clause_map if reference["kind"] == "款" else item_map,
                                  reference["article"], reference.get("para"),
                                  reference.get("para_explicit"), rest))

    if any(m is _AMBIGUOUS for m in mapped):
        base.update({
            "status": "無法判定",
            "note": "%s 有好幾項都有這個%s，引用沒寫是第幾項，請人工確認指向哪裡"
                    % (reference["article"], reference["kind"]),
        })
        return base

    if any(m is None for m in mapped):
        missing = [n for n, m in zip(reference["numbers"], mapped) if m is None]
        base.update({
            "status": "危險",
            "note": "引用的第%s%s已被刪除，沒有對應的新編號，必須人工確認要改成什麼"
                    % ("、".join(int_to_cn(n) for n in missing), reference["kind"]),
        })
        return base

    if reference.get("relative") and reference.get("own_no"):
        # 「前款」「前二款」是相對的：自己跟被指的那幾款一起換號，相對關係沒變就不用改。
        # 刪掉的是更前面的款時，「四、違反前款」重編成「三、違反前款」照樣指對；以前被報成
        # 「需改寫」，建議的新寫法卻還是「前款」（實測 R-C2）。
        own_rest = ((reference["own_no"],) if reference["kind"] == "款"
                    else (reference.get("clause") if reference.get("clause") is not None
                          else own_clause, reference["own_no"]))
        own_new = _map_lookup(clause_map if reference["kind"] == "款" else item_map,
                              reference["article"], reference.get("para"),
                              reference.get("para_explicit"), own_rest)
        if own_new is not None and own_new is not _AMBIGUOUS:
            if mapped == list(range(own_new - len(mapped), own_new)):
                return None
            base.update({"status": "需改寫", "span": reference["span"],
                         "new_quote": _join_numbers(mapped, reference["kind"]),
                         "note": "「%s」重編後指不到原本的第%s%s，要改成明寫的號碼"
                                 % (reference["raw"],
                                    "、".join(int_to_cn(n) for n in reference["numbers"]),
                                    reference["kind"])})
            return base

    if mapped == reference["numbers"]:
        return None          # 安全，編號沒變

    # 範圍引用只有在重編後仍然連續時，機械式改寫才成立
    if reference.get("is_range") and mapped != list(range(mapped[0], mapped[-1] + 1)):
        base.update({"status": "危險",
                     "note": "範圍引用在重編後不再連續，必須人工改寫"})
        return base

    new_quote = _rewrite_quote(reference, mapped)
    base.update({
        "status": "需改寫", "new_quote": new_quote, "span": reference["span"],
        "note": "被引用的%s還在，只是從第%s%s變成第%s%s"
                % (reference["kind"],
                   "、".join(int_to_cn(n) for n in reference["numbers"]),
                   reference["kind"],
                   "、".join(int_to_cn(n) for n in mapped), reference["kind"]),
    })
    return base


def _join_numbers(numbers, unit):
    """[2] →「第二款」，[2, 3] →「第二款及第三款」，連續三個以上 →「第二款至第四款」；不連續回空字串。"""
    if not numbers:
        return ""
    if len(numbers) == 1:
        return "第%s%s" % (int_to_cn(numbers[0]), unit)
    if numbers != list(range(numbers[0], numbers[0] + len(numbers))):
        return ""
    joiner = "及" if len(numbers) == 2 else "至"
    return "第%s%s%s第%s%s" % (int_to_cn(numbers[0]), unit, joiner, int_to_cn(numbers[-1]), unit)


def _join_articles(articles):
    """「第八條」「第七條及第八條」「第六條、第七條及第八條」。"""
    articles = list(articles or [])
    if len(articles) <= 1:
        return "".join(articles)
    return "、".join(articles[:-1]) + "及" + articles[-1]


def _old_previous_articles(own_article, offset, article_map):
    """這一段所在的條在舊版是哪一條、舊版往前 offset 條是哪幾條（照舊版順序）。

    article_map 的鍵就是舊版各條照出現順序排的。回傳 (舊版本條, [舊版前幾條])；
    這一條是新版才有的回 (None, None)，舊版也往前數不到回 (舊版本條, None)。"""
    if not own_article or not article_map:
        return None, None
    olds = list(article_map)
    own_old = None
    for old, info in article_map.items():
        if info.get("new") and _same_article(info["new"], own_article):
            own_old = old
            break
    if own_old is None:
        return None, None
    pos = olds.index(own_old)
    if pos < offset:
        return own_old, None
    return own_old, olds[pos - offset:pos]


def _gone_text(article_map, old):
    info = _lookup_article_map(article_map, old) or {}
    return ("已併入%s" % info["merged_into"]) if info.get("merged_into") else "已刪除"


def _judge_previous_article(base, reference, article_map, changed_paragraphs, index):
    """單獨寫的「前條」「前二條」：照舊版的前一條（經條號對照）跟新版的前一條比。"""
    raw = reference["raw"]
    own_old, old_targets = _old_previous_articles(reference.get("own_article"),
                                                  reference.get("offset") or 1, article_map)
    if own_old is None or not old_targets:
        return None      # 這一條是新版才有的（照新版寫的），或舊版也數不到（本來就這樣寫）
    infos = [(old, _lookup_article_map(article_map, old)) for old in old_targets]
    actual = reference.get("targets") or []
    gone = [old for old, info in infos if not info or not info.get("new")]
    if gone:
        base.update({"status": "危險",
                     "note": "「%s」在舊版指%s，%s新版%s；現在改指%s，要指向哪裡必須人工確認"
                             % (raw, "、".join(old_targets), gone[0], _gone_text(article_map, gone[0]),
                                "、".join(actual) or "不到任何一條")})
        return base
    expected = [info["new"] for _, info in infos]
    if [normalize_article_no(x) for x in expected] == [normalize_article_no(x) for x in actual]:
        return None
    note = ("「%s」在舊版指%s（新版是%s），新版的%s卻是%s"
            % (raw, "、".join(old_targets), "、".join(expected), raw, "、".join(actual) or "（沒有）"))
    if changed_paragraphs is not None and index in changed_paragraphs:
        base.update({"status": "危險",
                     "note": "危險（引用所在段落本次有改，無法判斷是照舊版或新版寫的）：" + note})
        return base
    base.update({"status": "需改寫", "span": reference["span"],
                 "new_quote": _join_articles(expected),
                 "note": note + "，照舊版的意思要改寫成「%s」" % _join_articles(expected)})
    return base


def _judge_previous_scope(base, reference, text, article_map, changed_paragraphs, index,
                          clause_map):
    """「前條第二款」「前條第二項」的前條在新舊版是不是同一條。

    回傳 None＝前條沒改指，往下照款、項自己的判法；False＝不用列（同一串後面那幾個，
    改寫算在緊接前條的那一個上）；dict＝判定。"""
    own_old, old_targets = _old_previous_articles(reference.get("own_article"), 1, article_map)
    if own_old is None or not old_targets:
        return None
    old = old_targets[0]
    info = _lookup_article_map(article_map, old) or {}
    raw = reference["raw"]
    if not info.get("new"):
        base.update({"status": "危險",
                     "note": "「前條」在舊版指%s，那一條新版%s；「%s」現在改指%s的%s，必須人工確認"
                             % (old, _gone_text(article_map, old), raw, reference["article"] or "（沒有）",
                                reference["kind"])})
        return base
    if _same_article(info["new"], reference["article"]):
        return None
    note = ("「前條」在舊版指%s（新版是%s），新版的前條卻是%s，「%s」指到的已經不是原來那一%s"
            % (old, info["new"], reference["article"] or "（沒有）", raw, reference["kind"]))
    if changed_paragraphs is not None and index in changed_paragraphs:
        base.update({"status": "危險",
                     "note": "危險（引用所在段落本次有改，無法判斷是照舊版或新版寫的）：" + note})
        return base
    scope = reference.get("scope_span")
    if not scope or scope[1] != reference["span"][0]:
        return False
    token = text[reference["span"][0]:reference["span"][1]]
    if reference["kind"] == "款":
        # 款號照舊版那一條的對照換（同一條自己也重編時）；有舊版全文時另由新舊版各推算一次再核
        number = reference["numbers"][0]
        mapped = _map_lookup(clause_map, info["new"], None, False, (number,))
        if mapped is not None and mapped is not _AMBIGUOUS:
            token = "第%s款" % int_to_cn(mapped)
    new_quote = info["new"] + token
    base.update({"status": "需改寫", "span": (scope[0], reference["span"][1]),
                 "new_quote": new_quote, "list_only": True,
                 "note": note + "，照舊版的意思要改寫成「%s」" % new_quote})
    return base


def _rewrite_quote(reference, mapped):
    """把引用字句裡的號碼換成新號碼。範圍引用只換頭尾兩端。"""
    unit = reference["kind"]
    if reference.get("is_range"):
        return "第%s%s至第%s%s" % (int_to_cn(mapped[0]), unit,
                                   int_to_cn(mapped[-1]), unit)
    return re.sub(r"第\s*[%s\d]+\s*%s" % (CN, unit),
                  "第%s%s" % (int_to_cn(mapped[0]), unit),
                  reference.get("token", reference["raw"]), count=1)


def _paragraph_ordinal(context):
    """
    這一段是所在條的第幾項。build_hierarchy 已經算好了，從 ref 裡取出來。
    條文本體是第一項，之後每一個沒有編號的獨立段落依序遞增。
    """
    ref = context.get("ref", "")
    match = re.search(r"第([%s]+)項$" % CN, ref)
    if match:
        return cn_to_int(match.group(1))
    return 1 if context.get("level") in ("條", "項") else None


def _previous_article_of(contexts, index):
    """往回找「前條」指的是哪一條。"""
    current = contexts[index - 1]["article"]
    seen_current = False
    for context in reversed(contexts[:index]):
        if context["level"] != "條":
            continue
        if not seen_current:
            if context["article"] == current:
                seen_current = True
            continue
        return context["article"]
    return ""


def _previous_articles_of(contexts, index):
    """這一段所在的條之前的各條（照全文順序，最近的在最後）。「前二條」要往前數兩條。
    最後一個就是 _previous_article_of 那一條。"""
    current = contexts[index - 1]["article"]
    heads = []
    for context in contexts[:index]:
        if context["level"] == "條" and context["article"] and (
                not heads or heads[-1] != context["article"]):
            heads.append(context["article"])
    if not current or current not in heads:
        return []
    pos = len(heads) - 1 - heads[::-1].index(current)
    return heads[:pos]


# ---------------------------------------------------------------------------
# 新舊版各推算一次：相對引用（前條、前項、前X款）與款、項號的位移
# ---------------------------------------------------------------------------
# 只看新版的話，「前條」永遠指得到東西（新版的前一條），程式就判「通過」：刪掉第二十條之後
# 第二十一條的「前條」改指第十九條、插入第八條之一之後第九條的「前條報告」改指新的那一條，
# 都沒有人講。款、項也一樣：作者刪掉第二款又自己把三、改成二、，「第二十二條第三款」在新版
# 指不到東西，被報成「已被刪除」，其實是換號了；「前項」只確認項次存在，中間一項被刪也不報。
# 做法：同一段在舊版找回原本那一段（內容對內容），兩邊各自解析引用、各自推算指到誰；
# 舊版指到的那一條／項／款經「舊 → 新」對照換到新版，再跟新版實際指到的比：
#   一樣           → 沒事；相對引用指到的內容變了，另外報「編號沒變、但指到的內容變了」
#   不一樣         → 需改寫（照舊版的意思給新寫法，例如「第三款」→「第二款」；拿不準就不給）
#   舊版那一個被刪 → 危險
# 引用所在的段落本次也改過：作者可能已經照新版寫了，分不出來，一律危險（跟條層級同一條保險絲）。

_CROSS_SKIP = object()
_cross_memo = {}


def _body_key(text):
    """比對「這一段是不是同一段、有沒有改」用：拿掉開頭的條號與款目編號，再正規化。
    重編只換了開頭的號碼，不算改內容（那個號碼不是引用）。"""
    body = strip_article_no(text or "")
    for pattern in (_CLAUSE_RE, _ITEM_RE, _POINT_RE):
        if pattern.match(body):
            body = pattern.sub("", body, count=1)
            break
    return normalize_for_compare(body)


def _align_lists(old_keys, new_keys, fallback=False):
    """兩串文字一對一對齊：{舊序號: 新序號}。一模一樣的整段對掉，改過的區塊用修正對照表
    同一支對齊（_align_block）。fallback：還沒配到的，同一個位置在新版也空著就配給它
    （內容改很多、但只是同一項／同一款改寫）。"""
    mapping = {}
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(
            None, old_keys, new_keys, autojunk=False).get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                mapping[i1 + k] = j1 + k
        elif tag == "replace":
            pairs, _ = _align_block(old_keys[i1:i2], new_keys[j1:j2])
            for local_i, local_j in pairs:
                if local_j is not None:
                    mapping[i1 + local_i] = j1 + local_j
    if fallback:
        used = set(mapping.values())
        for i in range(len(old_keys)):
            if i not in mapping and i < len(new_keys) and i not in used:
                mapping[i] = i
                used.add(i)
    return mapping


def _para_table(paragraphs, contexts):
    """{正規化條號: [(項次, 比對鍵, 原文), ...]}，照項次順序。"""
    table = {}
    for text, context in zip(paragraphs, contexts):
        if context["level"] not in ("條", "項") or not context["article"]:
            continue
        table.setdefault(normalize_article_no(context["article"]), []).append(
            (_paragraph_ordinal(context) or 1, _body_key(text), strip_article_no(text).strip()))
    return table


def _clause_table(paragraphs, entries):
    """{(正規化條號, 項次): [(寫的款號, 比對鍵, 本體), ...]}，照出現順序。"""
    table = {}
    for entry in entries:
        if entry["level"] != "款" or not entry["article"] or entry["written"] is None:
            continue
        text = paragraphs[entry["index"] - 1]
        table.setdefault((normalize_article_no(entry["article"]), entry.get("paragraph_no") or 1),
                         []).append((entry["written"], _body_key(text),
                                     _CLAUSE_RE.sub("", text, count=1).strip()))
    return table


def cross_version_references(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None,
                             article_map=None):
    """新舊版各推算一次引用指到誰（說明見上）。

    回傳 {"verdicts": {(新版段次, 引用的 span): 判定或 None}, "drift": [...], "article_map": ...}。
    verdicts 只收「新舊版都解析得出來」的引用；None＝兩邊指到同一個；判定的格式跟 _judge 一樣。
    drift 是相對引用（前條、前項、前X款）指到同一個、但那一個的內容這次改了，格式跟
    scan_reference_drift 一樣。scan_references 與 scan_reference_drift 都要用，同一次執行
    只算一次（記住最後一組輸入）。"""
    key = (tuple(old_paragraphs), tuple(new_paragraphs),
           tuple(old_kinds or ()), tuple(new_kinds or ()))
    if _cross_memo.get("key") == key:
        return _cross_memo["value"]
    value = _cross_version_references(old_paragraphs, new_paragraphs, old_kinds, new_kinds,
                                      article_map)
    _cross_memo.clear()
    _cross_memo.update(key=key, value=value)
    return value


def _cross_version_references(old_paragraphs, new_paragraphs, old_kinds, new_kinds, article_map):
    if article_map is None:
        article_map = plan_article_map(old_paragraphs, new_paragraphs, old_kinds, new_kinds)
    result = {"verdicts": {}, "drift": [], "article_map": article_map, "added": set(),
              "old_status": {}}
    if not article_map:
        return result
    old_ctx = build_hierarchy(old_paragraphs, old_kinds)
    new_ctx = build_hierarchy(new_paragraphs, new_kinds)
    old_entries = scan(old_paragraphs, old_kinds)
    new_entries = scan(new_paragraphs, new_kinds)
    old_by = dict((e["index"], e) for e in old_entries)
    new_by = dict((e["index"], e) for e in new_entries)
    _, plan_clause, _ = plan_renumber(new_paragraphs, new_entries)
    new_of = dict((normalize_article_no(old), info) for old, info in article_map.items())

    # 項：舊版每一條的每一項，在新版是哪一條第幾項（被刪的是 None）
    old_paras = _para_table(old_paragraphs, old_ctx)
    new_paras = _para_table(new_paragraphs, new_ctx)
    para_x = {}
    for art, items in old_paras.items():
        target = (new_of.get(art) or {}).get("new")
        news = new_paras.get(normalize_article_no(target), []) if target else []
        pairs = _align_lists([k for _, k, _ in items], [k for _, k, _ in news], fallback=True)
        for i, (ordinal, _, _) in enumerate(items):
            j = pairs.get(i)
            para_x[(art, ordinal)] = (target, news[j][0]) if j is not None else None

    # 款：舊版每一項底下的每一款，在新版是哪一條哪一項寫的第幾款
    old_clauses = _clause_table(old_paragraphs, old_entries)
    new_clauses = _clause_table(new_paragraphs, new_entries)
    clause_x = {}
    new_clause_body = {}
    for (art, para), items in new_clauses.items():
        for written, _, body in items:
            new_clause_body[(art, para, written)] = body
    old_clause_body = {}
    for (art, para), items in old_clauses.items():
        target = (new_of.get(art) or {}).get("new")
        new_para = para
        moved = para_x.get((art, para))
        if moved:
            new_para = moved[1]
        news = new_clauses.get((normalize_article_no(target), new_para), []) if target else []
        pairs = _align_lists([k for _, k, _ in items], [k for _, k, _ in news], fallback=True)
        for i, (written, _, body) in enumerate(items):
            j = pairs.get(i)
            clause_x[(art, para, written)] = (target, new_para, news[j][0]) if j is not None else None
            old_clause_body[(art, para, written)] = body

    old_units = dict((normalize_article_no(a), b) for a, b in _article_units(old_paragraphs, old_kinds))
    new_units = dict((normalize_article_no(a), b) for a, b in _article_units(new_paragraphs, new_kinds))
    old_texts = dict((normalize_article_no(a), t) for a, t in _article_texts(old_paragraphs, old_kinds))
    new_texts = dict((normalize_article_no(a), t) for a, t in _article_texts(new_paragraphs, new_kinds))
    old_para_body = dict(((a, o), body) for a, items in old_paras.items() for o, _, body in items)
    new_para_body = dict(((a, o), body) for a, items in new_paras.items() for o, _, body in items)

    old_keys = [_body_key(t) for t in old_paragraphs]
    new_keys = [_body_key(t) for t in new_paragraphs]
    counterpart = dict((j, i) for i, j in _align_lists(old_keys, new_keys).items())
    result["added"] = set(j + 1 for j in range(len(new_paragraphs)) if j not in counterpart)

    # 舊版自己的「只看單一版本」判定：同一處舊版就判成危險／無法判定的，是本來就有的問題
    _, old_plan_clause, old_plan_item = plan_renumber(old_paragraphs, old_entries)
    old_known = {c["article"] for c in old_ctx if c["level"] == "條" and c["article"]}
    old_with_clauses = {e["article"] for e in old_entries if e["level"] == "款" and e["article"]}
    old_para_counts = {}
    for context in old_ctx:
        if context["level"] in ("條", "項") and context["article"]:
            ordinal = _paragraph_ordinal(context) or 1
            old_para_counts[context["article"]] = max(old_para_counts.get(context["article"], 0), ordinal)

    def plan_number(article, para, written):
        value = _lookup_by_article(plan_clause, (article, para, written))
        return value if value is not None else written

    def clause_key(article, para, explicit, number):
        if para is not None and (article, para, number) in clause_x:
            return (article, para, number)
        if explicit:
            return None
        hits = [k for k in clause_x if k[0] == article and k[2] == number]
        return hits[0] if len(hits) == 1 else None

    for j0, text in enumerate(new_paragraphs):
        i0 = counterpart.get(j0)
        if i0 is None:
            continue          # 新版才有的段落：裡面的引用是照新版寫的
        idx = j0 + 1
        new_refs = [r for r in _paragraph_references(text, new_ctx[j0], new_by.get(idx, {}),
                                                     new_ctx, idx) if not r.get("external")]
        if not new_refs:
            continue
        old_refs = [r for r in _paragraph_references(old_paragraphs[i0], old_ctx[i0],
                                                     old_by.get(i0 + 1, {}), old_ctx, i0 + 1)
                    if not r.get("external")]
        changed = old_keys[i0] != new_keys[j0]

        def finding(n, status, note, new_quote="", span=None, ambiguous=False, would=""):
            out = {"index": idx, "text": text, "quote": n["raw"], "article": n["article"],
                   "kind": n["kind"], "external": "", "status": status, "note": note,
                   "cross": True, "ref_span": tuple(span or n["span"])}
            if status == "需改寫":
                out.update(new_quote=new_quote, span=tuple(span or n["span"]))
            if ambiguous:
                out.update(ambiguous=True, would_quote=would)
            return out

        def shifted(n, note, new_quote, span=None):
            if changed:
                return finding(n, "危險", "危險（引用所在段落本次有改，無法判斷是照舊編號或新編號寫的）："
                               + note, span=span, ambiguous=True, would=new_quote)
            if new_quote:
                return finding(n, "需改寫", note + "，照舊版的意思要改寫成「%s」" % new_quote,
                               new_quote, span)
            return finding(n, "需改寫", note + "；程式拿不準新寫法，請人工改寫", "", span)

        def drift_entry(n, target, old_body, new_body):
            return {"index": idx, "text": text, "quote": n["raw"], "target": target,
                    "old_body": old_body, "new_body": new_body,
                    "start": n["span"][0], "end": n["span"][1]}

        def judge_pair(o, n):
            kind = n["kind"]
            if kind == "條":
                if not n.get("relative") or not o.get("targets") or not n.get("targets"):
                    return _CROSS_SKIP
                expected = [(new_of.get(normalize_article_no(x)) or {}).get("new") for x in o["targets"]]
                if not all(expected) or [normalize_article_no(x) for x in expected] != \
                        [normalize_article_no(x) for x in n["targets"]]:
                    return _CROSS_SKIP          # 被刪、併入、改指：_judge 照條號對照判
                for old, new in zip(o["targets"], n["targets"]):
                    if old_units.get(normalize_article_no(old)) != new_units.get(normalize_article_no(new)):
                        return None, drift_entry(n, "%s（%s）" % (n["raw"], new),
                                                 old_texts.get(normalize_article_no(old)),
                                                 new_texts.get(normalize_article_no(new)))
                return None, None
            if kind not in ("項", "款") or not o.get("numbers") or not o.get("article"):
                return _CROSS_SKIP
            art = normalize_article_no(o["article"])
            relative = bool(n.get("relative"))
            absolute = (not relative and not n.get("scope_relative")
                        and not _same_article(n["article"], n.get("own_article") or ""))
            old_label = "%s第%s%s" % (o["article"], "、".join(int_to_cn(x) for x in o["numbers"]), kind)
            if kind == "項":
                keys = [(art, x) for x in o["numbers"]]
                if any(k not in para_x for k in keys):
                    return _CROSS_SKIP
                mapped = [para_x[k] for k in keys]
                old_bodies = [old_para_body.get(k) for k in keys]
            else:
                keys = [clause_key(art, o.get("para"), o.get("para_explicit"), x) for x in o["numbers"]]
                if any(k is None for k in keys):
                    return _CROSS_SKIP
                mapped = [clause_x[k] for k in keys]
                old_bodies = [old_clause_body.get(k) for k in keys]
            if any(m is None for m in mapped):
                gone = [x for x, m in zip(o["numbers"], mapped) if m is None]
                return finding(n, "危險", "「%s」在舊版指%s（%s），舊版的第%s%s這次刪掉了，要改指哪裡必須人工確認"
                               % (n["raw"], old_label, clip_body(old_bodies[o["numbers"].index(gone[0])]),
                                  "、".join(int_to_cn(x) for x in gone), kind)), None
            new_art = mapped[0][0]
            if kind == "項":
                finals = [m[1] for m in mapped]
                new_bodies = [new_para_body.get((normalize_article_no(m[0]), m[1])) for m in mapped]
            else:
                finals = [plan_number(m[0], m[1], m[2]) for m in mapped]
                new_bodies = [new_clause_body.get((normalize_article_no(m[0]), m[1], m[2])) for m in mapped]
            if relative:
                own = n.get("own_no")
                if kind == "款" and own:
                    own = plan_number(n["article"], n.get("para") or 1, own)
                actual = list(range(own - len(finals), own)) if own else []
            else:
                actual = list(n.get("numbers") or [])
            same_article = absolute or _same_article(new_art, n["article"])
            if same_article and finals == actual:
                if relative and any(a != b for a, b in zip(old_bodies, new_bodies)):
                    return None, drift_entry(n, "%s（%s第%s%s）" % (n["raw"], new_art,
                                                                "、".join(int_to_cn(x) for x in finals), kind),
                                             "；".join(b or "" for b in old_bodies),
                                             "；".join(b or "" for b in new_bodies))
                return None, None
            note = "「%s」在舊版指%s（%s），新版要寫成%s第%s%s才指得到同一%s" % (
                n["raw"], old_label, clip_body(old_bodies[0]), new_art,
                "、".join(int_to_cn(x) for x in finals), kind, kind)
            span = None
            if relative:
                same_place = _same_article(new_art, n.get("own_article") or "") and (
                    kind == "項" or mapped[0][1] == (n.get("para") or 1))
                new_quote = _join_numbers(finals, kind) if same_place else ""
            elif not same_article:
                scope = n.get("scope_span")
                new_quote = ""
                if scope and scope[1] == n["span"][0] and len(finals) == 1:
                    new_quote = new_art + "第%s%s" % (int_to_cn(finals[0]), kind)
                    span = (scope[0], n["span"][1])
            else:
                if n.get("is_range") and finals != list(range(finals[0], finals[-1] + 1)):
                    return finding(n, "危險", "範圍引用在新舊版對照後不再連續，必須人工改寫"), None
                new_quote = _rewrite_quote(n, finals) if len(finals) == 1 or n.get("is_range") else ""
            return shifted(n, note, new_quote, span), None

        sig = lambda r: (r["kind"], re.sub(r"\s+", "", r.get("raw") or ""))
        matcher = difflib.SequenceMatcher(None, [sig(r) for r in old_refs],
                                          [sig(r) for r in new_refs], autojunk=False)
        for tag, a1, a2, b1, b2 in matcher.get_opcodes():
            if tag != "equal":
                continue
            for o, n in zip(old_refs[a1:a2], new_refs[b1:b2]):
                old_judged = _judge(o, old_paragraphs[i0], i0 + 1, old_plan_clause, old_plan_item,
                                    old_by.get(i0 + 1, {}).get("clause_written"), old_known,
                                    old_with_clauses, old_para_counts, None, None)
                result["old_status"][(idx, tuple(n["span"]))] = (old_judged or {}).get("status")
                outcome = judge_pair(o, n)
                if outcome is _CROSS_SKIP:
                    continue
                verdict, drift = outcome
                result["verdicts"][(idx, tuple(n["span"]))] = verdict
                if drift:
                    result["drift"].append(drift)
    return result


def clip_body(text, limit=24):
    text = re.sub(r"\s+", " ", text or "").strip()
    return text if len(text) <= limit else text[:limit] + "…"


def dedupe_drift(drift, references):
    """同一處引用已經在交叉引用判成需改寫／危險／無法判定，就不再列一次「內容變了」：
    決定表上同一段只要一筆說清楚，兩筆講同一件事人會以為是兩個問題。"""
    taken = {}
    for ref in references or []:
        span = ref.get("ref_span") or ref.get("span")
        if ref.get("status") in ("需改寫", "危險", "無法判定") and span:
            taken.setdefault(ref["index"], []).append(tuple(span))
    out = []
    for item in drift or []:
        start, end = item.get("start"), item.get("end")
        spans = taken.get(item["index"], [])
        if start is not None and any(start < b and a < end for a, b in spans):
            continue
        if start is not None and any(d["index"] == item["index"] and d.get("start") is not None
                                     and start < d["end"] and d["start"] < end for d in out):
            continue
        out.append(item)
    return out


def _paragraph_bodies(paragraphs, kinds=None):
    """
    把全文的「項」整理成 {(條號, 項次): 條文本體}。

    項沒有寫在文字裡的編號，項次是從條文本體開始往下數出來的。
    刪掉一個項，後面的項次全部往前移——「第二項」就指到別的東西了，
    這跟刪掉一個款完全是同一種問題，只是更難察覺，因為文件上看不出編號變動。
    """
    bodies = {}
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] not in ("條", "項") or not context["article"]:
            continue
        ordinal = _paragraph_ordinal(context) or 1
        bodies[(context["article"], ordinal)] = strip_article_no(text).strip()
    return bodies


def _numbered_bodies(paragraphs, level, kinds=None):
    """
    把全文的款（或目）整理成 {(條號, 編號): 條文本體}，本體是去掉編號後的文字。

    用來比對「同一個編號，新舊版指的是不是同一件事」。
    """
    bodies = {}
    contexts = build_hierarchy(paragraphs, kinds)
    clause_written = None

    for text, context in zip(paragraphs, contexts):
        if context["level"] == "條":
            clause_written = None
        elif context["level"] == "款":
            match = _CLAUSE_RE.match(text)
            number = cn_to_int(match.group(1)) if match else None
            clause_written = number
            if level == "款" and number is not None:
                bodies[(context["article"], number)] = _CLAUSE_RE.sub("", text, count=1).strip()
        elif context["level"] == "目":
            match = _ITEM_RE.match(text)
            number = cn_to_int(match.group(2)) if match else None
            if level == "目" and number is not None:
                bodies[(context["article"], clause_written, number)] =                     _ITEM_RE.sub("", text, count=1).strip()
    return bodies


def scan_reference_drift(old_paragraphs, new_paragraphs,
                         old_kinds=None, new_kinds=None):
    """
    比對新舊版，找出「編號沒變、但指的東西變了」的交叉引用。

    為什麼一定要有這一關：
    如果使用者刪掉第二款之後，自己先把三、四、改成二、三、才拿來跑，
    編號連續性檢查會說「完全乾淨」——因為它確實乾淨。但別的條文寫的
    「依前條第二款規定」，指的已經從被刪掉的「原保險單正本」變成
    「契約變更申請書」，意思整個換掉，而且**表面上完全看不出來**。
    這是所有情況裡最危險的一種，正是因為它看起來沒問題。

    做法很直接：同一個條號、同一個款號，比對新舊版的條文本體。
    不一樣就把兩邊都列出來，交給人判斷。不自動改。
    """
    old_clauses = _numbered_bodies(old_paragraphs, "款", old_kinds)
    new_clauses = _numbered_bodies(new_paragraphs, "款", new_kinds)
    old_paras = _paragraph_bodies(old_paragraphs, old_kinds)
    new_paras = _paragraph_bodies(new_paragraphs, new_kinds)
    # 比對用正規化過的，顯示用原文（產出檔一律保留原字）
    old_articles = dict(_article_units(old_paragraphs, old_kinds))
    new_articles = dict(_article_units(new_paragraphs, new_kinds))
    old_article_texts = dict(_article_texts(old_paragraphs, old_kinds))
    new_article_texts = dict(_article_texts(new_paragraphs, new_kinds))
    contexts = build_hierarchy(new_paragraphs, new_kinds)
    # 相對引用（前條、前項、前X款）新舊版各推算一次；「前條第二款」的舊內容也要照舊版的前條取
    cross = cross_version_references(old_paragraphs, new_paragraphs, old_kinds, new_kinds)
    article_map = cross["article_map"]

    pattern = re.compile(r"(%s條|第\s*[%s\d]+\s*條(?:\s*之\s*[%s\d]+)?)?"
                         r"第\s*([%s\d]+)\s*(款|項)" % (_PREV, CN, CN, CN))
    # 以前只認「第X條」後面還接著款或項的寫法，純粹寫「依第五條規定」的引用
    # 從來沒進到這一關（實測 idx 63、80）——指到的內容整條換掉也不會有人講。
    #
    # 「之X」一定要吃到底、吃完不能再接「之」：後面的「不接第X款／項」是否定前瞻，
    # 比不過時正規表示式會往回退——「第五條之十一第二款」退成「第五條之十」（後面接
    # 「一」不是「第」）、或乾脆退成「第五條」，就把引用對到別條去（之一／之十一互相誤認）。
    article_pattern = re.compile(
        r"第\s*[%s\d]+\s*條(?:\s*之\s*[%s\d]+(?![%s\d]))?(?!\s*之\s*[%s\d])"
        r"(?!\s*第\s*[%s\d]+\s*[款項])"
        % (CN, CN, CN, CN, CN))

    findings = []
    for idx, (text, context) in enumerate(zip(new_paragraphs, contexts), 1):
        for match in article_pattern.finditer(text):
            if context["level"] == "條" and not text[:match.start()].strip():
                continue          # 段落開頭的條號是這一條自己的，不是引用
            if is_external_reference(text, match.span()):
                continue          # 別人家的法條，本程式沒有它的新舊版可比
            target_article = re.sub(r"\s+", "", match.group(0))
            old_body = old_articles.get(target_article)
            if old_body is None or old_body == new_articles.get(target_article):
                continue
            findings.append({
                "index": idx, "text": text, "quote": match.group(0),
                "target": target_article,
                "old_body": old_article_texts.get(target_article),
                "new_body": new_article_texts.get(target_article),
                "start": match.start(), "end": match.end(),
            })

        for match in pattern.finditer(text):
            scope_text, number_text, unit = match.groups()
            number = cn_to_int(number_text)
            if number is None:
                continue
            if is_external_reference(text, match.span()):
                continue          # 「個人資料保護法第五條第三款」不是本文的款

            old_article = None
            if scope_text and scope_text.startswith("前條"):
                target_article = _previous_article_of(contexts, idx)
                # 舊版的內容要照舊版的「前條」取：這一段所在的條在舊版的前一條。以前新舊兩邊
                # 都拿新版的前一條去查，刪掉一條之後比的根本不是同一條。這一條是新版才有的，
                # 引用是照新版寫的，沒有「舊版指什麼」可比。
                if article_map:
                    own_old, old_prev = _old_previous_articles(context["article"], 1, article_map)
                    if own_old is None or not old_prev:
                        continue
                    old_article = old_prev[0]
            elif scope_text:
                target_article = re.sub(r"\s+", "", scope_text)
            else:
                target_article = context["article"]
            if not target_article:
                continue
            old_article = old_article or target_article

            if unit == "款":
                old_body = old_clauses.get((old_article, number))
                new_body = new_clauses.get((target_article, number))
            else:
                old_body = old_paras.get((old_article, number))
                new_body = new_paras.get((target_article, number))

            if old_body is None or old_body == new_body:
                continue

            findings.append({
                "index": idx, "text": text, "quote": match.group(0),
                "target": "%s第%s%s" % (target_article, number_text, unit),
                "old_body": old_body,
                "new_body": new_body,
                "start": match.start(), "end": match.end(),
            })
    # 相對引用（單獨的前條、前項、前X款）指到同一個、內容卻改了：上面的樣式不認這幾種寫法
    findings += cross["drift"]
    findings.sort(key=lambda item: (item["index"], item.get("start") or 0))
    return dedupe_drift(findings, [])


# ---------------------------------------------------------------------------
# 輸出
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 章節引用：「依第三章第二節規定」
# ---------------------------------------------------------------------------
# 沒有「第X條」的要點、手冊，本文裡互相引用寫的是章節（「第三章第二節」「本章第二節」），
# 上面那套以條為錨點的引用檢查一個都抓不到。新增、刪除或搬動一章一節之後，後面的
# 章節整批換號，引用就指到別的地方——跟條號位移是同一種問題，只是換了一層。
# 做法：新舊版各排一份章節目錄，用標題把舊章節對到新章節，看出誰換了號、誰被刪了；
# 再掃新版本文裡的章節引用，照舊編號解讀（沒改過的段落一定是照舊編號寫的），
# 目標換了號就列出建議的新寫法，目標沒了就列成必須人工處理。只列不改。

_HEADING_NO_RE = re.compile(r"^第\s*([%s\d０-９]+)\s*[章節]" % CN)
_OUTLINE_NUM = r"[%s\d０-９]+" % CN
# 一串章節引用的開頭：「第三章」「第二節」「本章第二節」
_OUTLINE_START_RE = re.compile(r"(?P<this_ch>本章)?第\s*(?P<n>%s)\s*(?P<unit>[章節])" % _OUTLINE_NUM)
# 章名、節名可以夾在中間：「第三章陳報作業第二節保存期限二、」。名稱最多 24 字，碰到標點、
# 「、」或下一個「第」就停——「第二章、第三章」是兩個引用，不是一串。
_OUTLINE_GAP = r"[^，,。；;：:、第\n]{0,24}?"
_CHAIN_SECTION_RE = re.compile(r"%s第\s*(?P<n>%s)\s*節" % (_OUTLINE_GAP, _OUTLINE_NUM))
# 節（或章）底下的點：「二、」或「第二款」
_CHAIN_POINT_RE = re.compile(r"%s(?:(?P<cn>[%s]+)\s*、|第\s*(?P<kuan>%s)\s*款)"
                             % (_OUTLINE_GAP, CN, _OUTLINE_NUM))
# 「第三章第一節及第二節」：連接詞後面的「第二節」接著前一串的章
_OUTLINE_CONJ_RE = re.compile(r"^\s*[及或與和、至]\s*$")
# 章節引用前面緊接著別本的名稱（「依招攬作業要點第三章」「作業手冊中之第一章」）：
# 那是別本的章節，本程式沒有那一本的新舊版，不判。「本要點」「本手冊」是自己，照判。
_OTHER_BOOK_BEFORE_RE = re.compile(
    r"(?<!本)[一-鿿]*(?:手冊|要點|辦法|規則|準則|須知|規範|細則|法|條例|規定)"
    r"[」』》\"'\s]*(?:中之|之|中)?\s*$")
# 目錄行尾巴的點線與頁碼（「第一章 總則……3」），標題比對前要拿掉
_TOC_TAIL_RE = re.compile(r"[\s\.．·…‥_－\-]*[0-9０-９]*\s*$")


# 「依本要點」「依本作業手冊」是這份文件自己，不是別本。_OTHER_BOOK_BEFORE_RE 的 (?<!本)
# 只擋得住緊貼在字尾前的「本」，「依本要點第三章」照樣被當成別本的章節跳過不檢查。
# 法規字尾那幾種用 _common.is_own_law_name（跟外部法規判定同一條規則）；手冊、須知、規定
# 不在它的字尾表裡，這裡補一條同樣寫法的。
_OWN_BOOK_EXTRA_RE = re.compile(
    r"(?:^|(?<=[^一-鿿])|(?<=[依按照據及與和或、]))本(?!公司|行|國)[一-鿿]{0,6}?(?:手冊|須知|規定)$")
_BOOK_TAIL_RE = re.compile(r"[」』》\"'\s]*(?:中之|之|中)?\s*$")


def _other_book_before(before):
    """章節引用前面緊接著的是不是別本的名稱（是自己這一份就不算）。"""
    match = _OTHER_BOOK_BEFORE_RE.search(before)
    if not match:
        return False
    name = _BOOK_TAIL_RE.sub("", match.group(0))
    return not (is_own_law_name(name) or _OWN_BOOK_EXTRA_RE.search(name))


def _outline_bodies(paragraphs, kinds=None):
    """每一章、每一節底下的內文（正規化後串起來）：{(章, 0): …, (章, 節): …}。標題本身不算。"""
    bodies = {}
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] in ("章", "節"):
            continue
        chapter = _HEADING_NO_RE.match(context.get("chapter") or "")
        if not chapter:
            continue
        ch = cn_to_int(chapter.group(1)) or 0
        section = _HEADING_NO_RE.match(context.get("section") or "")
        sec = (cn_to_int(section.group(1)) or 0) if section else 0
        piece = normalize_for_compare(text)
        bodies.setdefault((ch, 0), []).append(piece)
        if sec:
            bodies.setdefault((ch, sec), []).append(piece)
    return dict((k, "\n".join(v)) for k, v in bodies.items())


def _diff_snippet(old, new, width=12):
    """兩段文字第一處不一樣的地方，前後各帶幾個字：(舊的那一截, 新的那一截)。"""
    matcher = difflib.SequenceMatcher(None, old or "", new or "", autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag != "equal":
            return (clip_body((old or "")[max(0, i1 - width):i2 + width], 40),
                    clip_body((new or "")[max(0, j1 - width):j2 + width], 40))
    return "", ""


def _outline_title(text):
    title = _HEADING_NO_RE.sub("", text, count=1)
    return normalize_for_compare(_TOC_TAIL_RE.sub("", title))


def outline_units(paragraphs, kinds=None):
    """全文的章節目錄：{(章號, 節號或 0): (標題, 段次)}。

    同一個章節號出現兩次時，後面的蓋掉前面的：文件開頭的目錄在前、本文的標題在後，
    要的是本文那一個。"""
    units = {}
    for idx, (text, context) in enumerate(zip(paragraphs, build_hierarchy(paragraphs, kinds)), 1):
        if context["level"] not in ("章", "節"):
            continue
        match = _HEADING_NO_RE.match(text)
        number = cn_to_int(match.group(1)) if match else None
        if number is None:
            continue
        if context["level"] == "章":
            key = (number, 0)
        else:
            chapter = _HEADING_NO_RE.match(context.get("chapter") or "")
            key = ((cn_to_int(chapter.group(1)) or 0) if chapter else 0, number)
        units[key] = (_outline_title(text), idx)
    return units


def plan_outline_map(old_units, new_units):
    """舊章節 → 新章節：{舊 key: 新 key，被刪掉的是 None}。

    先用標題對（標題在新舊版各只出現一次才算數），對不到的再退回「同一個號碼、
    新版那一個也還沒被別人認走」＝只改了標題。節先在對到的那一章裡找同標題，
    找不到再看全文（整節搬到別章）。"""
    mapping = {}
    used = set()

    def pick(key, candidates):
        free = [c for c in candidates if c not in used]
        if len(free) == 1:
            mapping[key] = free[0]
            used.add(free[0])
            return True
        return False

    def titled(units, keys, title):
        return [k for k in keys if units[k][0] == title]

    old_chapters = sorted(k for k in old_units if k[1] == 0)
    new_chapters = sorted(k for k in new_units if k[1] == 0)
    for key in old_chapters:
        title = old_units[key][0]
        if title and len(titled(old_units, old_chapters, title)) == 1:
            pick(key, titled(new_units, new_chapters, title))
    for key in old_chapters:
        if key not in mapping and not pick(key, [key] if key in new_units else []):
            mapping[key] = None

    old_sections = sorted(k for k in old_units if k[1])
    new_sections = sorted(k for k in new_units if k[1])
    for key in old_sections:
        title = old_units[key][0]
        if not title:
            continue
        chapter = mapping.get((key[0], 0))
        home = [k for k in new_sections if chapter and k[0] == chapter[0]]
        if not pick(key, titled(new_units, home, title)):
            if len(titled(old_units, old_sections, title)) == 1:
                pick(key, titled(new_units, new_sections, title))
    for key in old_sections:
        if key in mapping:
            continue
        chapter = mapping.get((key[0], 0))
        same = (chapter[0] if chapter else key[0], key[1])
        if not pick(key, [same] if same in new_units else []):
            mapping[key] = None
    return mapping


def _outline_text(key, point=None):
    chapter, section = key
    text = ("第%s章" % cn_from_int(chapter) if chapter else "") + \
        ("第%s節" % cn_from_int(section) if section else "")
    return text + ("%s、" % cn_from_int(point) if point else "")


def outline_points(paragraphs, kinds=None):
    """沒有「第X條」的文件裡，每一章（或節）底下的點：{(章號, 節號或 0): [(號碼, 本體), ...]}。"""
    points = {}
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] != "款" or context.get("article"):
            continue
        match = _CLAUSE_RE.match(text)
        if not match:
            continue
        chapter = _HEADING_NO_RE.match(context.get("chapter") or "")
        section = _HEADING_NO_RE.match(context.get("section") or "")
        key = ((cn_to_int(chapter.group(1)) or 0) if chapter else 0,
               (cn_to_int(section.group(1)) or 0) if section else 0)
        body = normalize_for_compare(_CLAUSE_RE.sub("", text, count=1))
        points.setdefault(key, []).append((cn_to_int(match.group(1)), body))
    return points


def plan_point_map(old_points, new_points, mapping):
    """舊的點 → 新的點：{(舊章節 key, 舊號碼): (新章節 key, 新號碼)，被刪的是 None}。

    在對到的那一個章節裡用內容對（內容一模一樣、而且只有一個），對不到的退回同一個號碼
    （內容改過、號碼沒動），再對不到就是被刪了。"""
    point_map = {}
    for key, olds in old_points.items():
        target = mapping.get(key, key)
        news = new_points.get(target, []) if target else []
        used = set()
        for number, body in olds:
            same = [n for n, b in news if b == body and n not in used]
            if body and len(same) == 1:
                point_map[(key, number)] = (target, same[0])
                used.add(same[0])
        numbers = set(n for n, _ in news)
        for number, _ in olds:
            if (key, number) in point_map:
                continue
            if target and number in numbers and number not in used:
                point_map[(key, number)] = (target, number)
                used.add(number)
            else:
                point_map[(key, number)] = None
    return point_map


def _outline_citations(text):
    """一段裡的章節引用，每一串是 {start, end, this_ch, parts}；parts 是
    [(層級, 號碼, 號碼在原文的起訖), ...]，層級是 章／節／點，照原文順序。"""
    found = []
    pos = 0
    while True:
        match = _OUTLINE_START_RE.search(text, pos)
        if not match:
            return found
        parts = [(match.group("unit"), cn_to_int(match.group("n")), match.span("n"))]
        end = match.end()
        if match.group("unit") == "章":
            section = _CHAIN_SECTION_RE.match(text, end)
            if section:
                parts.append(("節", cn_to_int(section.group("n")), section.span("n")))
                end = section.end()
        point = _CHAIN_POINT_RE.match(text, end)
        if point:
            group = "cn" if point.group("cn") else "kuan"
            parts.append(("點", cn_to_int(point.group(group)), point.span(group)))
            end = point.end()
        found.append({"start": match.start(), "end": end,
                      "this_ch": bool(match.group("this_ch")), "parts": parts})
        pos = end


def _rewrite_citation(text, citation, numbers, chapter_prefix=None):
    """照 numbers（層級 → 新號碼）改寫一串引用；阿拉伯數字寫的照樣寫阿拉伯數字。
    chapter_prefix：「本章第二節」「第二節」要補章號時的新章號。"""
    out = text[citation["start"]:citation["end"]]
    base = citation["start"]
    for level, _, (s, e) in sorted(citation["parts"], key=lambda p: -p[2][0]):
        written = text[s:e]
        value = numbers[level]
        new = str(value) if unicodedata.normalize("NFKC", written).isdigit() else cn_from_int(value)
        out = out[:s - base] + new + out[e - base:]
    if chapter_prefix:
        out = "第%s章" % cn_from_int(chapter_prefix) + (out[2:] if citation["this_ch"] else out)
    return out


def scan_outline_references(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None,
                            drift=None):
    """新版本文裡的章節引用，目標換號或被刪的列出來。

    認得的寫法：「第三章第二節」「第三章」「本章第二節」「第二節」，章名節名夾在中間的
    「第三章陳報作業第二節保存期限」，以及接在後面的點「…第二節保存期限二、」「…第二款」。

    回傳 (moved, findings)：moved 是換了號或被刪的章節與點的數目（0＝都沒動，
    不用往下看）；findings 每一筆是 {index, text, quote, status, new_quote, note}，
    status 是「需改寫」（目標換了號）、「危險」（目標被刪了）或「無法判定」。

    drift（選填，list）：章節號沒變、但那一章節（或那一點）的內容這次改了的引用，
    照 scan_reference_drift 的格式加進去（「依第三章第二節所定期限」而第二節的期限改了，
    引用的那一段要重看；以前章節沒換號就整個不看，C8b）。不給就跟以前一樣。
    """
    old_units = outline_units(old_paragraphs, old_kinds)
    new_units = outline_units(new_paragraphs, new_kinds)
    mapping = plan_outline_map(old_units, new_units)
    old_points = outline_points(old_paragraphs, old_kinds)
    new_points = outline_points(new_paragraphs, new_kinds)
    point_map = plan_point_map(old_points, new_points, mapping)
    moved = (sum(1 for k, v in mapping.items() if v != k)
             + sum(1 for k, v in point_map.items() if v != k))
    if not moved and drift is None:
        return 0, []
    old_bodies = _outline_bodies(old_paragraphs, old_kinds) if drift is not None else {}
    new_bodies = _outline_bodies(new_paragraphs, new_kinds) if drift is not None else {}
    back = dict((v, k) for k, v in mapping.items() if v)
    changed = find_changed_paragraphs(old_paragraphs, new_paragraphs, old_kinds, new_kinds)
    contexts = build_hierarchy(new_paragraphs, new_kinds)

    findings = []
    for idx, (text, context) in enumerate(zip(new_paragraphs, contexts), 1):
        here = _HEADING_NO_RE.match(context.get("chapter") or "")
        here_new = (cn_to_int(here.group(1)) or 0) if here else 0
        previous = None       # 同一段前一串引用：(結尾位置, 舊章號)
        for citation in _outline_citations(text):
            start = citation["start"]
            if context["level"] in ("章", "節") and not text[:start].strip():
                previous = None
                continue          # 段落開頭的章節號是這一段自己的標題（含目錄行），不是引用
            before = text[max(0, start - 20):start]
            if is_external_reference(text, (start, citation["end"])) or \
                    _other_book_before(before):
                previous = None
                continue          # 別本的章節
            numbers = dict((level, value) for level, value, _ in citation["parts"])
            if None in numbers.values():
                continue
            bare = "章" not in numbers
            inherited = False
            if bare:
                if previous and _OUTLINE_CONJ_RE.match(text[previous[0]:start]):
                    chapter = previous[1]          # 「第三章第一節及第二節」
                    inherited = True
                else:
                    # 「第二節」「本章第二節」＝這一段所在的那一章；照舊編號解讀要換回舊章號
                    chapter = back.get((here_new, 0), (here_new, 0))[0]
            else:
                chapter = numbers["章"]
            key = (chapter, numbers.get("節", 0))
            point = numbers.get("點")
            previous = (citation["end"], chapter)
            quote = text[start:citation["end"]]

            def add(item, start=start, end=citation["end"]):
                # 在原文的起訖位置：決定表的「建議改法」照位置改寫，同一段兩處引用才不會互相改到
                item.update(start=start, end=end)
                findings.append(item)
            label = _outline_text(key, point)

            if key not in old_units and key != (0, 0):
                if key in new_units or (bare and (here_new, key[1]) in new_units):
                    continue      # 新寫的引用，照新編號寫、而且找得到
                add({"index": idx, "text": text, "quote": quote,
                                 "status": "無法判定", "new_quote": "",
                                 "note": "新舊版都找不到%s" % _outline_text(key)})
                continue
            target = mapping.get(key, key)
            title = old_units.get(key, ("",))[0]
            named = "%s（%s）" % (label, title) if title else label
            if target is None:
                add({"index": idx, "text": text, "quote": quote,
                                 "status": "危險", "new_quote": "",
                                 "note": "舊版的%s新版已經沒有了，引用要改指別處或刪掉" % named})
                continue
            new_point = point
            if point:
                if (key, point) not in point_map:
                    if not any(n == point for n, _ in new_points.get(target, [])):
                        add({"index": idx, "text": text, "quote": quote,
                                         "status": "無法判定", "new_quote": "",
                                         "note": "新舊版的%s底下都找不到%s、"
                                                 % (_outline_text(key), cn_from_int(point))})
                    continue
                mapped = point_map[(key, point)]
                if mapped is None:
                    add({"index": idx, "text": text, "quote": quote,
                                     "status": "危險", "new_quote": "",
                                     "note": "舊版的%s新版已經沒有了，引用要改指別處或刪掉" % named})
                    continue
                new_point = mapped[1]
            if target == key and new_point == point:
                if drift is not None:
                    _outline_drift(drift, idx, text, citation, quote, key, point, named, here_new,
                                   context, old_bodies, new_bodies, old_points, new_points)
                continue
            if inherited and target[1] == key[1] and new_point == point:
                continue          # 章號跟著前一串改就好，這一串自己的節、點沒動
            renumbered = {"章": target[0], "節": target[1], "點": new_point}
            prefix = target[0] if bare and not inherited and target[0] != here_new else None
            new_quote = _rewrite_citation(text, citation, renumbered, prefix)
            if new_quote == quote:
                continue          # 「本章第二節」：章跟著這一段一起換號、節號沒變，寫法不用動
            note ="舊版的%s新版是%s" % (named, _outline_text(target, new_point))
            if idx in changed:
                note += "；這一段本次也改過，引用如果已經照新編號改好就不用動"
            add({"index": idx, "text": text, "quote": quote,
                             "status": "需改寫", "new_quote": new_quote, "note": note})
    if not moved:
        return 0, []
    return moved, findings


def _outline_drift(drift, idx, text, citation, quote, key, point, named, here_new, context,
                   old_bodies, new_bodies, old_points, new_points):
    """章節號沒變的引用：那一章節（或點）的內容這次改了就記一筆「內容變了」。
    引用寫在那一章節自己裡面的不記（「本章第二節」寫在第二章裡，改的就是它自己那一章）。"""
    here_sec = _HEADING_NO_RE.match(context.get("section") or "")
    here = (here_new, (cn_to_int(here_sec.group(1)) or 0) if here_sec else 0)
    if here[0] == key[0] and (key[1] == 0 or here[1] == key[1]):
        return
    if point:
        old_b = next((b for n, b in old_points.get(key, []) if n == point), None)
        new_b = next((b for n, b in new_points.get(key, []) if n == point), None)
    else:
        old_b, new_b = old_bodies.get(key), new_bodies.get(key)
    if old_b is None or new_b is None or old_b == new_b:
        return
    old_snip, new_snip = _diff_snippet(old_b, new_b)
    drift.append({"index": idx, "text": text, "quote": quote, "target": named,
                  "old_body": old_snip, "new_body": new_snip,
                  "start": citation["start"], "end": citation["end"]})


# ---------------------------------------------------------------------------
# 沒有「第X條」的文件：點的編號（一、／（一）／(1)／1.）與章節標題的編號
# ---------------------------------------------------------------------------
# 以前沒有條的文件整個不查點的編號：手冊裡的點常被程式看不到的小標分組、各自從一起算，
# 用章節分組照樣誤報（真資料 1,347 段誤報 14 處）。現在照查、全部都報，但分兩種講：
#   這次改出來的（舊版同一個地方沒有這個不連續）→ 警告
#   本來就有的（舊版同一個地方就是這樣）          → 提醒，合成一則列出位置
# 「是不是這次改出來的」不能只看旁邊的段落有沒有改：刪掉「二、」之後「一、三、」兩段
# 自己都沒動，所以拿舊版跑同一套檢查，同一個位置、同一串號碼舊版就有，才算本來就有。
# 章節標題（第一章、第三章少了第二章）只報這次改出來的。

_LEVEL_SHOWN = {"款": "一、", "點": "1.", "目": "（一）"}
_TOC_LINE_RE = re.compile(r"(?:[\.．·…‥_]{2,}|\t)\s*[0-9０-９]+\s*$")


def _kind(reason):
    """人看的問題名稱：跳號／重號／沒有從一開始（內部 reason 帶層級名，要點的文件看不懂）。"""
    if reason.startswith("編號重複"):
        return "重號"
    if reason.startswith("沒有從"):
        return "沒有從一開始"
    return "跳號"


def _written_text(problem, numbers):
    level, style = problem["level"], problem.get("style")
    if level == "款":
        return "".join("%s、" % cn_from_int(n) for n in numbers)
    if level == "點":
        return " ".join("%d." % n for n in numbers)
    if style == _ITEM_STYLE_AR:
        return "".join("(%d)" % n for n in numbers)
    return "".join("（%s）" % cn_from_int(n) for n in numbers)


def _point_place(problem):
    """「第二章第一節」「第二章第一節 二、底下」：人拿著回文件找得到的位置。"""
    where = "".join(problem["scope"]) or "全文"
    if problem["level"] != "款" and problem.get("parent"):
        where += " %s、底下" % cn_from_int(problem["parent"])
    return where


def point_numbering_issues(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None):
    """沒有「第X條」的文件，點的編號有沒有跳號、重號、沒從一開始。

    回傳 list，每筆是 _numbering_problems 那一筆，多帶：
        this_round  True＝這次改出來的；False＝舊版同一個地方就是這樣
        place／written_text／expected_text  給畫面與提醒用的字"""
    new_entries = scan(new_paragraphs, new_kinds)
    if numbering_check_applicable(new_entries):
        return []          # 有條的文件照舊由 find_numbering_gaps 查
    old_problems = _numbering_problems(scan(old_paragraphs, old_kinds), include_points=True)

    def sign(p, with_place=True):
        base = (p["level"], p.get("style"), tuple(p["written"]))
        return base + ((p["scope"], p.get("parent")) if with_place else ())

    old_exact = set(sign(p) for p in old_problems)
    old_loose = set(sign(p, False) for p in old_problems)
    changed = find_changed_paragraphs(old_paragraphs, new_paragraphs, old_kinds, new_kinds)
    issues = []
    for p in _numbering_problems(new_entries, include_points=True):
        untouched = not (set(p["indices"]) & changed)
        existed = sign(p) in old_exact or (untouched and sign(p, False) in old_loose)
        issues.append(dict(p, this_round=not existed, place=_point_place(p), kind=_kind(p["reason"]),
                           written_text=_window_text(p, p["written"]),
                           expected_text=_window_text(p, p["expected"])))
    return issues


def _window_text(problem, numbers, keep=6):
    """一串太長（整份一路編的要點）就只印出錯那一段前後，其餘用「…」。"""
    if len(numbers) <= keep:
        return _written_text(problem, numbers)
    at = problem.get("at", 0)
    lo, hi = max(0, at - 2), min(len(numbers), at + 3)
    return (("…" if lo else "") + _written_text(problem, numbers[lo:hi])
            + ("…" if hi < len(numbers) else ""))


def _run_problems(numbers):
    """一串標題號碼有什麼問題（重新從一起算的當成另一串，例如文件前面的目錄）。"""
    runs, current = [], []
    for n, idx in numbers:
        if len(current) >= 2 and n == 1:     # 「第一章、第一章」緊接著是重號，不是另一串
            runs.append(current)
            current = []
        current.append((n, idx))
    if current:
        runs.append(current)
    problems = []
    for run in runs:
        written = [n for n, _ in run]
        expected = list(range(1, len(written) + 1))
        if written == expected:
            continue
        if len(set(written)) != len(written):
            reason = "編號重複"
        elif written[0] != 1:
            reason = "沒有從一開始"
        else:
            reason = "編號不連續（中間有缺號）"
        problems.append({"written": written, "expected": expected, "reason": reason,
                         "first_index": run[0][1]})
    return problems


def _heading_problems(paragraphs, kinds=None):
    chapters, sections, order = [], {}, []
    for idx, (text, context) in enumerate(zip(paragraphs, build_hierarchy(paragraphs, kinds)), 1):
        if context["level"] not in ("章", "節") or _TOC_LINE_RE.search(text):
            continue
        match = _HEADING_NO_RE.match(text)
        number = cn_to_int(match.group(1)) if match else None
        if number is None:
            continue
        if context["level"] == "章":
            chapters.append((number, idx))
        else:
            owner = context.get("chapter") or ""
            if owner not in sections:
                order.append(owner)
            sections.setdefault(owner, []).append((number, idx))
    found = [dict(p, unit="章", owner="") for p in _run_problems(chapters)]
    for owner in order:
        found += [dict(p, unit="節", owner=owner) for p in _run_problems(sections[owner])]
    return found


def heading_numbering_issues(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None):
    """章節標題本身的編號（第一章、第三章少了第二章；同一章裡兩個第一節），只回這次改出來的。"""
    old = set((p["unit"], tuple(p["written"])) for p in _heading_problems(old_paragraphs, old_kinds))
    issues = []
    for p in _heading_problems(new_paragraphs, new_kinds):
        if (p["unit"], tuple(p["written"])) in old:
            continue
        shown = lambda nums: "、".join("第%s%s" % (cn_from_int(n), p["unit"]) for n in nums)
        issues.append(dict(p, kind=_kind(p["reason"]),
                           written_text=shown(p["written"]), expected_text=shown(p["expected"]),
                           place=("%s底下的節" % p["owner"]) if p["unit"] == "節" else "章"))
    return issues


def notice_numbering_issues(points, headings, limit=10):
    """點的編號與章節標題的問題走 notices（批次時畫面只剩一行）。"""
    for item in headings:
        nt.notice(nt.WARNING, "章節標題%s　%s：目前「%s」，應為「%s」（第 %d 段起）"
                  % (item["kind"], item["place"], item["written_text"],
                     item["expected_text"], item["first_index"]), "Step 0.5")
    fresh = [p for p in points if p["this_round"]]
    for item in fresh[:limit]:
        nt.notice(nt.WARNING, "點的編號%s（這次改出來的）　%s：目前「%s」，應為「%s」（第 %d 段起）"
                  % (item["kind"], item["place"], item["written_text"],
                     item["expected_text"], item["first_index"]), "Step 0.5")
    if len(fresh) > limit:
        nt.notice(nt.WARNING, "點的編號還有 %d 處這次改出來的問題沒列出來，完整清單見執行紀錄的「編號有問題的地方」"
                  % (len(fresh) - limit), "Step 0.5")
    old = [p for p in points if not p["this_round"]]
    if old:
        shown = "；".join("%s%s「%s」（第 %d 段）" % (p["place"], p["kind"], p["written_text"], p["first_index"])
                         for p in old[:limit])
        more = "；另有 %d 處見執行紀錄" % (len(old) - limit) if len(old) > limit else ""
        nt.notice(nt.REMINDER, "點的編號本來就有跳號或重號（舊版同一個地方就是這樣，這次沒動）%d 處：%s%s。"
                  "有些是被小標分成兩組、其實沒錯，請看一眼" % (len(old), shown, more), "Step 0.5")


def notice_outline_references(findings, limit=15):
    """章節引用的問題走 notices：批次時畫面只剩一行，要留進 提醒.txt 與批次摘要才看得到。"""
    for item in findings[:limit]:
        if item["status"] == "需改寫":
            line = "第%d段引用「%s」要改成「%s」：%s" % (
                item["index"], item["quote"], item["new_quote"], item["note"])
        else:
            line = "第%d段引用「%s」：%s" % (item["index"], item["quote"], item["note"])
        level = nt.REMINDER if item["status"] == "無法判定" else nt.WARNING
        if item["status"] != "無法判定":
            line += "（已列進連帶決定表，填「改」照建議改法套用）"
        nt.notice(level, "章節重編後的引用　" + line, "Step 0.5")
    if len(findings) > limit:
        nt.notice(nt.WARNING, "章節重編後的引用還有 %d 處沒列出來，完整清單見執行紀錄的「章節引用」"
                  % (len(findings) - limit), "Step 0.5")


def notice_article_references(references, drift, limit=15):
    """條、款、項引用的問題（需改寫／危險／無法判定）與「編號沒變、內容變了」走 notices。
    以前只印在畫面（批次時只剩一行），提醒.txt 與批次摘要都看不到，人就漏改。"""
    lines = []
    old_ones = [item for item in references or [] if item.get("pre_existing")]
    for item in references or []:
        if item.get("status") not in ("需改寫", "危險", "無法判定") or item.get("external"):
            continue
        if item.get("pre_existing"):
            continue
        if item["status"] == "需改寫" and item.get("new_quote"):
            line = "第%d段引用「%s」要改成「%s」：%s" % (
                item["index"], item["quote"], item["new_quote"], item["note"])
        else:
            line = "第%d段引用「%s」（%s）：%s" % (item["index"], item["quote"], item["status"],
                                              item.get("note") or "")
        lines.append((nt.REMINDER if item["status"] == "無法判定" else nt.WARNING, line))
    for item in drift or []:
        lines.append((nt.WARNING, "第%d段引用「%s」：編號沒變，但指到的%s內容這次有改"
                      % (item["index"], item["quote"], item["target"])))
    for level, line in lines[:limit]:
        nt.notice(level, "條文引用　" + line + "（已列進連帶決定表，請逐筆確認）", "Step 0.5")
    if len(lines) > limit:
        nt.notice(nt.WARNING, "條文引用的問題還有 %d 處沒列出來，完整清單見連帶決定表（來源「條文引用」）"
                  "與執行紀錄的「交叉引用」" % (len(lines) - limit), "Step 0.5")
    if old_ones:
        shown = "；".join("第%d段「%s」" % (item["index"], item["quote"]) for item in old_ones[:limit])
        nt.notice(nt.REMINDER, "條文引用本來就指不到或解析不出的有 %d 處（舊版同一處就是這樣，不是這次改出來的，"
                  "沒有列進連帶決定表）：%s%s" % (len(old_ones), shown, "…" if len(old_ones) > limit else ""),
                  "Step 0.5")


SKIPPED_NUMBERING = "未檢查（此文件沒有第X條，款目編號檢查不適用）"
# 同一份報告裡第二次講同一件事，理由不用再寫一遍
SKIPPED_NUMBERING_AGAIN = "未檢查（同上，此文件沒有第X條）"
# 條層級的引用只列不改，理由見 apply_changes
ARTICLE_REF_MANUAL = "條層級引用只列不改，請人工確認後自行修改"
# 新舊版都沒有「第X條」（要點、手冊）時，編號檢查的結論只講這一則
NO_ARTICLE_NOTE = ("這份文件沒有「第X條」：條號增刪與「第X條」引用的檢查不適用；"
                   "章節引用（第X章第X節…）有檢查；「一、二、三、」有沒有跳號本次未檢查"
                   "（沒有條可分組，小標底下常重新起算，程式判了容易誤報），請自己看一眼")
_ARTICLE_ONLY_CHECKS = ("款目編號", "新版少掉的條號", "條層級交叉引用")


# report() 這一輪有哪幾項是「沒檢查」。畫面上每一段各自印過「未檢查」了，
# 這裡收起來在最後發一則提醒——畫面留不住，而「沒有發現問題」與「根本沒檢查」
# 在產出檔裡看起來一模一樣，那才是危險的地方。
_unchecked = []


def _note_unchecked(item, reason):
    _unchecked.append("%s（%s）" % (item, reason))


def report(problems, changes, deleted_articles, references, drift=None,
           numbering_applicable=True, article_map=None, outline=None,
           point_issues=None, heading_issues=None):
    """把檢查結果印出來。每一段都要明講是「通過」「未檢查」還是「有問題」。

    numbering_applicable：款目編號檢查適不適用於這份文件（沒有「第X條」就不適用）。
    article_map：plan_article_map() 的「舊條號 → 新條號」對照；None 代表沒有舊版
        可比對，條層級與條號增刪一律印「未檢查」。

    為什麼要三態：沒檢查卻印「無，款目編號都是連續的」「沒有受影響的交叉引用」，
    使用者會以為程式看過了、沒問題，實際上是程式根本沒看。這種假的安心比不檢查
    更危險，所以任何沒跑到的分支一律印「未檢查」並說明原因。
    """
    del _unchecked[:]
    print("\n" + "=" * 62)
    print("編號檢查結果")
    print("=" * 62)

    print("\n【編號有問題的地方】")
    if not numbering_applicable and point_issues is not None:
        # 沒有條的文件：點的編號照章、節（與上一層的點）分組查，這次改出來的與本來就有的分開講
        if not point_issues:
            print("  通過，各章節底下點的編號（一、／（一）／(1)／1.）都是連續的")
        for tag, this_round in (("這次改出來的", True), ("本來就有的（舊版同一個地方就是這樣）", False)):
            group = [p for p in point_issues if p["this_round"] == this_round]
            if group:
                print("  %s，共 %d 處" % (tag, len(group)))
            for p in group:
                print("  %s：%s" % (p["place"], p["kind"]))
                print("      目前：%s" % p["written_text"])
                print("      應為：%s（第 %d 段起）" % (p["expected_text"], p["first_index"]))
    elif not numbering_applicable:
        print("  " + SKIPPED_NUMBERING)
        _note_unchecked("款目編號", "此文件沒有第X條，不適用")
    elif problems:
        print("  有問題，共 %d 處" % len(problems))
        for problem in problems:
            # 號碼照原本的數字體系印：阿拉伯目印「1、2」，中文目印「一、二」。
            # 印錯體系的話，人拿著報告回文件裡找不到那一段。
            style = problem.get("style")
            print("  %s %s：%s" % (problem["article"], problem["level"], problem["reason"]))
            print("      目前：%s" % "、".join(_number_text(style, n) for n in problem["written"]))
            print("      應為：%s（第 %d 段起）"
                  % ("、".join(_number_text(style, n) for n in problem["expected"]),
                     problem["first_index"]))
    else:
        print("  通過，款目編號都是連續的")

    print("\n【要重編的段落】")
    if not numbering_applicable:
        print("  " + SKIPPED_NUMBERING_AGAIN)
    elif changes:
        print("  有 %d 段要重編" % len(changes))
        for change in changes[:20]:
            style = change.get("style")
            print("  第%d段 %s %s：第%s%s → 第%s%s"
                  % (change["index"], change["article"], change["level"],
                     _number_text(style, change["old"]) if change["old"] else "?",
                     change["level"],
                     _number_text(style, change["new"]), change["level"]))
        if len(changes) > 20:
            print("  …另有 %d 段（完整清單見輸出檔）" % (len(changes) - 20))
    else:
        print("  通過，不需要重編")

    print("\n【新版少掉的條號】")
    if article_map is None:
        print("  未檢查（沒有給舊版，比不出條號有沒有被刪或被併；請加 --old 舊版檔）")
        _note_unchecked("新版少掉的條號", "沒有給舊版，比不出條號有沒有被刪或被併")
    elif not article_map:
        # 舊版根本沒有「第X條」，不是「每一條都找得到」，是根本沒有東西可以比。
        print("  未檢查（舊版沒有「第X條」，比不出條號對照）")
        _note_unchecked("新版少掉的條號", "舊版沒有「第X條」，比不出條號對照")
    elif not deleted_articles:
        print("  通過，舊版每一條在新版都找得到")
    else:
        gone = [d for d in deleted_articles if d["status"] == "刪除"]
        merged = [d for d in deleted_articles if d["status"] == "併入"]
        print("  有問題，共 %d 條" % len(deleted_articles))
        if gone:
            print("  依法制慣例，刪除的條應保留條號並註記「（刪除）」，讓後面的條號維持不變，")
            print("  否則全文及其他規章裡引用這些條號的地方會全部指錯。建議補上：")
            for item in gone:
                print("      %s　（刪除）" % item["article"])
        if merged:
            # 併條不是刪除。補「（刪除）」註記反而是錯的，所以一定要分開講。
            print("  下列各條的內容是被併進別條，不是刪除，不要補「（刪除）」註記：")
            for item in merged:
                print("      %s　併入%s" % (item["article"], item["into"]))

    external = [r for r in references if r["status"] == "外部法規"]
    dangerous = [r for r in references if r["status"] == "危險"]
    rewritable = [r for r in references if r["status"] == "需改寫"]
    unresolved = [r for r in references if r["status"] == "無法判定"]
    affected = dangerous + rewritable + unresolved
    article_level = [r for r in affected if r["kind"] == "條"]
    inner_level = [r for r in affected if r["kind"] != "條"]

    print("\n【交叉引用】")
    if external:
        laws = []
        for ref in external:
            if ref.get("law") and ref["law"] not in laws:
                laws.append(ref["law"])
        print("  外部法規引用（不檢查）%d 處：%s" % (len(external), "、".join(laws)))
        print("      這些是別部法規的條號，本程式沒有那部法規的新舊版，不判也不改寫。")
    if article_map is None:
        print("  條層級引用：未檢查（沒有舊版可比對，算不出舊條號對到新版哪一條；"
              "請加 --old 舊版檔）")
        _note_unchecked("條層級交叉引用", "沒有舊版可比對，算不出舊條號對到新版哪一條")
    elif not article_map:
        # 舊版沒有任何「第X條」，對照表是空的，條層級等於沒檢查
        print("  條層級引用：未檢查（舊版沒有「第X條」，算不出條號對照）")
        _note_unchecked("條層級交叉引用", "舊版沒有「第X條」，算不出條號對照")
    elif article_level:
        print("  條層級引用：有問題，共 %d 處（%s）"
              % (len(article_level), ARTICLE_REF_MANUAL))
    else:
        print("  條層級引用：通過，比對過新舊版條號，沒有指錯的「第X條」")
    if inner_level:
        print("  款目與項引用：有問題，共 %d 處" % len(inner_level))
    else:
        print("  款目與項引用：通過，沒有指錯的款目或項")

    # 新舊版對照推出來的（list_only）跟條層級一樣只列不改；沒有新寫法的也只能人改
    rewritable_inner = [r for r in rewritable if _auto_rewritable(r)]
    rewritable_article = [r for r in rewritable if not _auto_rewritable(r)]
    if rewritable_inner:
        print("  可機械式改寫 %d 處（加 --rewrite-refs 一併處理）：" % len(rewritable_inner))
        for ref in rewritable_inner:
            print("    第%d段「%s」→「%s」" % (ref["index"], ref["quote"], ref["new_quote"]))
            print("        %s" % ref["note"])
    if rewritable_article:
        # 條層級一律只列不改：作者可能已經自己改好了，文字上看不出來，猜錯就是
        # 把對的條號改成錯的。建議的新條號照印，改不改由人決定。
        print("  %s（%d 處）：" % (ARTICLE_REF_MANUAL, len(rewritable_article)))
        for ref in rewritable_article:
            if ref.get("new_quote"):
                print("    第%d段「%s」→ 建議改成「%s」"
                      % (ref["index"], ref["quote"], ref["new_quote"]))
            else:
                print("    第%d段「%s」" % (ref["index"], ref["quote"]))
            print("        %s" % ref["note"])
    if dangerous:
        print("\n  ⚠ 必須人工處理 %d 處 —— 本程式不會自動改：" % len(dangerous))
        for ref in dangerous:
            print("    第%d段：%s" % (ref["index"], ref["text"][:50]))
            print("        引用「%s」，%s" % (ref["quote"], ref["note"]))
    if unresolved:
        # 解析不出來的一定要列出來。沉默才是最危險的結果——使用者會以為
        # 程式看過了、沒問題，實際上是程式根本沒看懂那句話。
        print("\n  ? 解析不出來 %d 處 —— 可能是寫法特殊，也可能原文本來就寫錯，"
              "請人工看一下：" % len(unresolved))
        for ref in unresolved:
            print("    第%d段：%s" % (ref["index"], ref["text"][:50]))
            print("        引用「%s」，%s" % (ref["quote"], ref["note"]))

    if drift:
        print("\n【編號沒變、但指到的內容變了】共 %d 處 —— 這是最容易漏掉的一種"
              % len(drift))
        print("  表面上編號連續、看不出問題，但同一個編號在新舊版指的是不同的東西。")
        for item in drift:
            print("\n    第%d段：%s" % (item["index"], item["text"][:52]))
            print("        引用「%s」" % item["quote"])
            print("        舊版的%s是：%s" % (item["target"], item["old_body"]))
            if item["new_body"] is None:
                print("        新版沒有這一款了")
            else:
                print("        新版的%s是：%s" % (item["target"], item["new_body"]))
        print("\n  本程式不會自動改這些，請逐筆確認引用要指向哪裡。")

    if outline is not None:
        moved, found = outline
        print("\n【章節引用（第X章第X節）】")
        if not moved:
            print("  通過，章節編號沒有變動")
        elif not found:
            print("  通過，有 %d 個章節或點換號或刪除，但本文沒有引用到它們" % moved)
        else:
            print("  有問題，共 %d 處（有 %d 個章節或點換號或刪除；本程式只列不改）" % (len(found), moved))
            for item in found:
                print("    第%d段：%s" % (item["index"], item["text"][:50]))
                if item["new_quote"]:
                    print("        「%s」→ 建議改成「%s」" % (item["quote"], item["new_quote"]))
                else:
                    print("        引用「%s」" % item["quote"])
                print("        %s" % item["note"])

    print("=" * 62)
    if heading_issues:
        print("\n【章節標題的編號】這次改出來的，共 %d 處" % len(heading_issues))
        for h in heading_issues:
            print("  %s：%s　目前「%s」，應為「%s」（第 %d 段起）"
                  % (h["place"], h["kind"], h["written_text"], h["expected_text"], h["first_index"]))
    elif heading_issues is not None:
        print("\n【章節標題的編號】通過，這次沒有改出跳號或重號")

    unchecked = list(_unchecked)
    if not numbering_applicable and article_map == {}:
        # 新舊版都沒有「第X條」：條號那幾項是「不適用」，跟「該查沒查到」不同。
        # 點的編號有查（point_issues）就什麼都不用講；沒查（只有單獨呼叫 report 的舊路）
        # 才併成一則講清楚哪些不適用、哪一項沒查
        if point_issues is None:
            nt.notice(nt.REMINDER, NO_ARTICLE_NOTE, "Step 0.5")
        unchecked = [u for u in unchecked if not u.startswith(_ARTICLE_ONLY_CHECKS)]
    if unchecked:
        nt.notice(nt.REMINDER,
                  "編號檢查有 %d 項未檢查：%s。未檢查不等於沒問題，這幾項本次沒有跑到"
                  % (len(unchecked), "、".join(unchecked)), "Step 0.5")


def _edit_span(old, new):
    """old 改成 new 動到的是 old 的哪一段：(起, 迄, 換成的字)。去掉共同的頭尾。"""
    head = 0
    while head < min(len(old), len(new)) and old[head] == new[head]:
        head += 1
    tail = 0
    while tail < min(len(old), len(new)) - head and old[-1 - tail] == new[-1 - tail]:
        tail += 1
    return head, len(old) - tail, new[head:len(new) - tail]


def _auto_rewritable(ref):
    """--rewrite-refs 會自動改的引用：需改寫、有新寫法、不是外部法規、不是條層級、
    也不是新舊版對照推出來的（list_only，要人看過）。report 與 apply_changes 共用。"""
    return (ref.get("status") == "需改寫" and bool(ref.get("span")) and bool(ref.get("new_quote"))
            and not ref.get("external") and ref.get("kind") != "條" and not ref.get("list_only"))


def apply_changes(paragraphs, changes, references, rewrite_refs):
    """套用重編（以及選用的引用改寫），回傳新的段落列表。

    引用的 span 是**原文**的座標。以前先把段首換成新編號再用舊 span 切字，編號長度一變
    （十一→十）就切歪：「十一、依第十二款規定」變成「十、依第第十一款定」（A12）。
    現在同一段的編號改動與引用改寫都換算成原文上的區段，由後往前一次套上；
    兩者重疊（理論上不會）就只改編號、不動那一處引用。
    """
    result = list(paragraphs)
    edits = {}
    for change in changes:
        index = change["index"]
        edits.setdefault(index, []).append(_edit_span(paragraphs[index - 1], change["new_text"]))

    if rewrite_refs:
        # 只改「需改寫」的款目與項。「危險」「無法判定」「外部法規」一律不動，
        # 條層級也一律不動——只列出來給人看。
        #
        # 條層級為什麼不能自動改：重編之後，「作者已經改好的新號」跟「還沒改的
        # 舊號」在文字上一模一樣，程式沒有辦法分辨，而 _judge 一律往「還沒改」
        # 的方向解，猜錯就是把對的條號改成錯的（實測：作者已經把第七條改成
        # 第六條，程式又把它改成第五條）。款目與項不一樣，它們的新舊號是由
        # 本次重編自己算出來的，不是從文字上猜的。
        #
        # 外部法規那一條也特別重要：把別部法規的條號改掉，是在正式修法文件上
        # 寫錯別人的法條，比漏改嚴重得多（實測 idx 142）。
        #
        # 用 span 由後往前取代：同一段裡可能出現兩個「第四款」，
        # 用字串比對會改到錯的那一個。
        by_paragraph = {}
        for ref in references:
            if _auto_rewritable(ref):
                by_paragraph.setdefault(ref["index"], []).append(ref)

        for index, refs in by_paragraph.items():
            for ref in refs:
                start, end = ref["span"]
                taken = edits.get(index, [])
                if any(start < b and a < end for a, b, _ in taken):
                    continue
                edits.setdefault(index, []).append((start, end, ref["new_quote"]))

    for index, spans in edits.items():
        text = paragraphs[index - 1]
        for start, end, new in sorted(spans, key=lambda s: s[0], reverse=True):
            text = text[:start] + new + text[end:]
        result[index - 1] = text
    return result


def write_output(paragraphs, source_path, outdir, prefix):
    """輸出重編後的檔案，格式跟來源檔一致。"""
    base = "重編後_" + os.path.basename(source_path)
    output_path = resolve_output(outdir, prefix, base)

    if output_path.lower().endswith(".docx"):
        if not HAS_DOCX:
            output_path = os.path.splitext(output_path)[0] + ".txt"
            nt.notice(nt.REMINDER, "沒有安裝 python-docx，重編結果改輸出純文字檔", "重編輸出")
        else:
            from docx import Document
            doc = Document()
            for text in paragraphs:
                doc.add_paragraph(text)
            doc.save(output_path)
            print("\n已輸出重編後檔案：%s" % output_path)
            return output_path

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(paragraphs) + "\n")
    print("\n已輸出重編後檔案：%s" % output_path)
    return output_path


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="Step 1.5：款目編號重編與交叉引用檢查")
    parser.add_argument("regulation_file", help="要檢查的內規檔案（通常是你剛改好的新版）")
    parser.add_argument("--old", default=None,
                        help="舊版檔案；給了才能找出被整條刪掉的條號")
    parser.add_argument("--apply", action="store_true",
                        help="實際重編款目編號並輸出檔案；不加就只檢查不動檔案")
    parser.add_argument("--rewrite-refs", action="store_true",
                        help="連同可機械式改寫的交叉引用一起改（引用到已刪除款目的、"
                             "以及外部法規的條號一律不動）")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    print("正在讀取：%s" % args.regulation_file)
    paragraphs, kinds = read_paragraphs_with_kinds(args.regulation_file)
    print("全文共 %d 段。" % len(paragraphs))

    entries = scan(paragraphs, kinds)
    applicable = numbering_check_applicable(entries)
    if not applicable:
        nt.notice(nt.REMINDER,
                  "這份文件沒有「第X條」（作業手冊型），款目編號檢查與重編不適用，"
                  "本次未檢查；交叉引用檢查照常", "Step 0.5")
    problems = find_numbering_gaps(entries)
    changes, clause_map, item_map = plan_renumber(paragraphs, entries)
    known_articles = {c["article"] for c in build_hierarchy(paragraphs, kinds)
                      if c["level"] == "條" and c["article"]}

    # 條層級的判定要先有「舊條號 → 新條號」的對照，所以舊版要先讀進來。
    article_map = None
    changed_paragraphs = None
    deleted_articles = []
    drift = []
    old_paragraphs = old_kinds = None
    if args.old:
        print("正在比對舊版：%s" % args.old)
        old_paragraphs, old_kinds = read_paragraphs_with_kinds(args.old)
        article_map = plan_article_map(old_paragraphs, paragraphs, old_kinds, kinds)
        changed_paragraphs = find_changed_paragraphs(old_paragraphs, paragraphs,
                                                     old_kinds, kinds)
        deleted_articles = find_deleted_articles(old_paragraphs, paragraphs,
                                                 old_kinds, kinds,
                                                 article_map=article_map)
        drift = scan_reference_drift(old_paragraphs, paragraphs, old_kinds, kinds)
    else:
        nt.notice(nt.REMINDER,
                  "沒有給 --old，無法檢查「編號沒變但指到的內容變了」這種情況，"
                  "條層級的交叉引用也只能印「未檢查」；強烈建議加上舊版一起跑"
                  "（--old 舊版內規.docx）", "Step 0.5")

    references = scan_references(paragraphs, entries, clause_map, item_map,
                                 known_articles=known_articles, kinds=kinds,
                                 article_map=article_map,
                                 changed_paragraphs=changed_paragraphs,
                                 old_paragraphs=old_paragraphs if args.old else None,
                                 old_kinds=old_kinds if args.old else None)
    drift = dedupe_drift(drift, references)

    report(problems, changes, deleted_articles, references, drift,
           numbering_applicable=applicable, article_map=article_map)

    if not args.apply:
        if changes or [r for r in references if r["status"] != "安全"]:
            print("\n這是檢查模式，沒有更動任何檔案。要實際重編請加 --apply。")
        return changes

    updated = apply_changes(paragraphs, changes, references, args.rewrite_refs)
    write_output(updated, args.regulation_file, args.outdir, args.prefix)

    dangerous = [r for r in references if r["status"] == "危險"]
    if dangerous:
        print("\n⚠ 仍有 %d 處交叉引用引用到已刪除的款目，本程式沒有改動它們，"
              "請務必人工確認後再送出。" % len(dangerous))

    return changes


if __name__ == "__main__":
    main()
