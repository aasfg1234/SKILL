# -*- coding: utf-8 -*-
"""
Step 1.6：條文品質與風險檢查

跑完 Step 1 的精確比對之後跑這支。比對告訴你「哪裡改了」，這支告訴你
「這些改動裡有哪些特別該看」，以及「文件本身有沒有結構性的毛病」。

十項檢查，全部是程式碼做得到、不需要 LLM 判斷的：

需要新舊版比對（要給 --old）
    1. 責任用語變更   應→得、不得→得 這種修改是責任強度的實質變更；
                      同一項另報但書增刪（新增或拿掉「但…不在此限」）
    2. 數值期間變更   十五日→三十日、五年→三年、十萬元→二十萬元；
                      同一項另報門檻用語變更（以上→以下、逾→未滿、「以上」被刪）
    3. 施行日期       改了實質條文，但施行日期條文沒動

只看新版就能查
    4. 條號健全性     重複、跳號、「之一」順序錯亂、空白條文
    5. 定義用語       定義了卻全文沒用到；改了定義但用到它的條文沒跟著看；
                      刪了定義、這個詞別處還在用（用到的段落進連帶決定表，來源「定義連動」）
    6. 外部法規引用   抽出所有「○○法第X條」（含引號、「同法」、第二個以後的條號），
                      供人工核對母法是否已修正
    7. 待補殘留       TBD、XXX、○○年○月○日、XX萬元、××、待補、待確認 之類沒清掉的字
    8. 格式一致性     （一）與(一)混用、條號後分隔符不一致
    9. 用語混用       要保人／投保人、業務員／業務人員 這類同義詞混著用
   10. 附表引用       文中提到「附表一」，但全文找不到附表一

--------------------------------------------------------------------------
這支程式不做什麼
--------------------------------------------------------------------------
條文之間有沒有邏輯矛盾、修改有沒有逾越母法授權、修正理由該怎麼寫——
這些需要理解條文的意思，程式做不到，交給 SKILL.md 裡的 LLM 檢查層。
本程式只做「規則明確、結果可重複驗證」的部分。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
    python rule_checks.py 新版內規.docx --old 舊版內規.docx
    python rule_checks.py 新版內規.docx                  只做不需要比對的六項
    python rule_checks.py 新版內規.docx --terms 用語表.json   自訂用語混用檢查

輸出：條文檢查報告.xlsx（寫不出來才退 .csv），以及主控台的分級摘要。
"""

import argparse
import csv
import difflib
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, read_paragraphs_with_kinds,
                     build_hierarchy, diff_runs, resolve_output, load_term_groups,
                     normalize_for_compare, clean_law_name, mask_law_names, external_registry,
                     is_own_law_name, cn_to_int,
                     DEFINED_TERM_RES, DEFINED_LIST_ITEM_RE, DEFINITION_LIST_HEADER_RE,
                     DEFINITION_LIST_ITEM_START_RE,
                     extract_article_no, strip_article_no, display_path)
import diff_compare
import notices as nt
import xlsx_writer as xw

CN = "零〇一二三四五六七八九十百千萬兩"

HIGH, MEDIUM, LOW = "高", "中", "低"

# 「這一筆是從哪一種異動看出來的」。正常的逐段比對是「修改」；比對相似度太低、
# 判成一刪一增的那種整條改寫，配回同一條之後標這個字串，讓複核的人知道
# 原文與修改後文字是程式配的，不是比對直接配到的。
REWRITE_LABEL = "刪除＋新增（視為改寫）"
# 一個區塊裡剛好只有一刪一增，但條號不同、本文也不像時才用的標籤。
# 這種配對的把握比前一種低，報告上要看得出來差別。
REWRITE_DIFF_NO_LABEL = "刪除＋新增（視為改寫，條號不同）"
MODIFIED_LABEL = "修改"


def clip(text, limit):
    """報告裡的引文一律走這一支：換行先換成空白，真的截到字才加「…」。

    硬切有兩個毛病：一是截在句子中間卻沒有任何記號，看起來像句末標點被刪掉了，
    複核的人會以為那就是條文原樣；二是含換行的條文（<w:br/> 讀進來是 \\n）
    直接切下去，報告的「一列一行」被撐破，後面幾欄全部錯位。
    沒有截到的不加「…」——沒截還加，一樣是在騙人說後面還有字。
    """
    one_line = re.sub(r"\s+", " ", text or "").strip()
    return (one_line[:limit] + "…") if len(one_line) > limit else one_line


# 引文自己帶了標籤（「原文：」「修改後：」）時，report() 不要再疊一次「原文：」——
# 疊出來是「原文：修改後：本行應辦理」，看的人會以為舊版寫的就是那個新值，
# 這一行正好落在最高風險的那幾筆（責任用語變更）上。
_QUOTE_LABELS = ("原文：", "修改後：", "舊版：", "新版：")


def quote_line(quote):
    """報告上引文那一行要印的字（含標籤）。自己帶標籤的不再加「原文：」。"""
    text = quote or ""
    if any(text.startswith(label) for label in _QUOTE_LABELS):
        return text
    return "原文：%s" % text


def finding(severity, check, detail, index=None, ref="", quote="", action="",
            change_type=""):
    """統一的檢查結果格式。"""
    return {"severity": severity, "check": check, "index": index, "ref": ref,
            "quote": quote, "detail": detail, "action": action,
            "change_type": change_type}


# ---------------------------------------------------------------------------
# 0. 把「刪除＋新增」配回同一條（P11）
# ---------------------------------------------------------------------------
#
# 責任用語與數值期間這兩項本來都是 `if result["type"] != "modified": continue` 開頭。
# 一條被整條改寫時（「應於十五日內申報」→「本公司得於三十日內辦理申報事宜」），
# 兩段的相似度低於 diff_compare.PAIR_THRESHOLD，比對會判成「刪除一條、新增一條」，
# 這兩項就整組跳過——最該看的「十五日→三十日」「應→得」反而一筆都不報。
#
# 配對是**以區塊為單位**做的。比對把「這一段被換掉」判成一刪一增時，連續改寫的
# 好幾條會擠成一整塊（刪、刪、增、增），不是一刪一增交錯排。只看 results[i] 與
# results[i+1] 的話，中間那幾對永遠配不到——真實的修法一次改好幾條才是常態。
#
# 一個區塊 = 連續的 deleted／added（中間夾到 unchanged／modified 就斷開）。
# 區塊裡的配對規則刻意保守，而且只用來「多報一筆給人看」，不會改任何文字：
#   一、先配條號相同的。同一個「第三條」被刪掉又新增，實務上就是整條重寫。
#   二、剩下的用相似度配：拿掉條號之後的本文要達到 diff_compare.PAIR_THRESHOLD
#       ——那是比對自己用的同一條門檻，不另立標準。而且不准交叉（保持前後順序），
#       不然第一條會被配到最後一條的新文。
#   三、區塊裡剛好只有一刪一增，前兩輪又都沒配到（條號不同、本文也不像）：
#       這種多半是「同一條被改號又整條重寫」——條號變了所以第一輪配不到，
#       整條重寫所以第二輪配不到。沒有別的候選可以搶，門檻放低到
#       SINGLE_PAIR_THRESHOLD 再判一次，配到就標 REWRITE_DIFF_NO_LABEL，
#       讓人看得出這一對的把握比較低。
#
# 配錯的代價是條文檢查報告多一列要人看，配漏的代價是責任範圍或期間被改掉沒人看到。
# 兩者不對稱，所以寧可多配——但不能配到完全不相干的兩條，那會讓人開始不信任
# 【高】那一欄，連真的該看的也一起略過。

# 「區塊裡只有一刪一增」時才用的較低門檻。0.25 是這樣抓的：
#   真的改號又整條重寫（第三條 …十五日內申報 → 第四條 本公司得於三十日內辦理申報事宜）
#       拿掉條號後相似度 0.286
#   真的不相干（第六條 保險費逾期未繳…契約停止效力 → 第五條 投保人須於契約撤銷期間內以書面通知）
#       0.205
# 兩者中間取 0.25。這是本支最弱的一條規則（樣本少），所以配到的那一筆一定要
# 標成「條號不同」，不跟條號對得上的那種混在一起。
#
# 這個數字的來歷要講白，不然下一個人會以為它是統計出來的：
#   一、校準樣本只有上面那兩筆（假配對 0.205、真改寫 0.286）。兩筆不是分布，
#       是兩個點；0.25 是這兩點中間，不是什麼最佳切點。
#   二、已知的漏抓：長句改寫實測落在 0.2449，就差一點點，配不到。
#       也就是說「真的改號又整條重寫」的長條文本來就有一部分抓不到，
#       這一條規則是補網，不是保證。
#   三、日後要調整，**校準方向看「假配對率」，不是看漏抓率**。
#       把門檻往下拉可以多抓幾筆，但假的【高】警報會淹掉真警報——
#       人一旦開始不信任【高】那一欄，連真的該看的也會一起略過，
#       那比漏抓一筆更糟。要動這個數字，先蒐足夠多「改號又整條重寫」的真條文，
#       兩個方向的錯誤各算一次，再決定。
SINGLE_PAIR_THRESHOLD = 0.25


def _pair_ratio(old_text, new_text):
    """拿掉條號之後的本文相似度。用 diff_compare 自己那一支，門檻不另立一套。

    注意 diff_compare._ratio 低於 PAIR_THRESHOLD 時一律回 0.0（它用便宜的估算
    先擋掉明顯不像的），所以要判比它更低的門檻時得用 _raw_ratio。
    """
    return diff_compare._ratio(strip_article_no(old_text or ""),
                               strip_article_no(new_text or ""))


def _raw_ratio(old_text, new_text):
    """拿掉條號之後的本文相似度，不做 PAIR_THRESHOLD 的預先過濾。"""
    return difflib.SequenceMatcher(None, strip_article_no(old_text or ""),
                                   strip_article_no(new_text or ""), autojunk=False).ratio()


def _rewrite_blocks(results):
    """把比對結果切成一段一段「連續的刪除／新增」。"""
    blocks = []
    current = []
    for item in results:
        if item["type"] in ("deleted", "added"):
            current.append(item)
        elif current:
            blocks.append(current)
            current = []
    if current:
        blocks.append(current)
    return blocks


def _pair_block(block):
    """一個區塊裡的配對，回傳 [(deleted, added, 標籤), ...]。"""
    deleted = [x for x in block
               if x["type"] == "deleted" and (x.get("old_text") or "")]
    added = [x for x in block
             if x["type"] == "added" and (x.get("new_text") or "")]
    if not deleted or not added:
        return []

    pairs = []
    taken = set()

    # 第一輪：條號一樣的直接配
    for d in deleted:
        old_no = extract_article_no(d["old_text"])
        if not old_no:
            continue
        for pos, a in enumerate(added):
            if pos in taken:
                continue
            if extract_article_no(a["new_text"]) == old_no:
                taken.add(pos)
                pairs.append((d, a, REWRITE_LABEL))
                break

    # 第二輪：剩下的用相似度配，不准交叉（配到的位置只能往後走）
    paired_deleted = {id(d) for d, _a, _label in pairs}
    floor = -1
    for d in deleted:
        if id(d) in paired_deleted:
            continue
        best_pos, best_score = None, 0.0
        for pos, a in enumerate(added):
            if pos in taken or pos <= floor:
                continue
            score = _pair_ratio(d["old_text"], a["new_text"])
            if score >= diff_compare.PAIR_THRESHOLD and score > best_score:
                best_pos, best_score = pos, score
        if best_pos is not None:
            taken.add(best_pos)
            floor = best_pos
            paired_deleted.add(id(d))
            pairs.append((d, added[best_pos], REWRITE_LABEL))

    # 第三輪：整個區塊就只有一刪一增，而且前兩輪都沒配到
    if (len(deleted) == 1 and len(added) == 1 and not pairs
            and _raw_ratio(deleted[0]["old_text"],
                           added[0]["new_text"]) >= SINGLE_PAIR_THRESHOLD):
        pairs.append((deleted[0], added[0], REWRITE_DIFF_NO_LABEL))
    return pairs


def logical_rewrites(results):
    """把「刪除＋新增」配成邏輯上的改寫，回傳假的 modified 結果清單。

    回傳的每一筆長得跟比對結果一樣（type／old_text／new_text／ref／index），
    另外帶 change_type，讓報告標得出這是配出來的、以及是靠什麼配的。
    原始的刪除列與新增列仍然留在對照表上，這裡不動它們。
    """
    pairs = []
    for block in _rewrite_blocks(results):
        for deleted, added, label in _pair_block(block):
            pairs.append({
                "type": "modified",
                "old_text": deleted["old_text"],
                "new_text": added["new_text"],
                "ref": added.get("ref") or deleted.get("ref") or "",
                "old_index": deleted.get("old_index"),
                "new_index": added.get("new_index"),
                "change_type": label,
            })
    return pairs


def _with_rewrites(results):
    """真的 modified 加上配出來的邏輯改寫。兩項高風險檢查都吃這一份。"""
    return list(results) + logical_rewrites(results)


# ---------------------------------------------------------------------------
# 1. 責任用語變更
# ---------------------------------------------------------------------------

# 強度分級：數字越大責任越重。用來判斷這次修改是鬆綁還是加嚴。
# 法制作業上「應」與「得」是天差地別的兩件事——「應」是義務，「得」是裁量權。
# 在一堆文字修改裡，這種兩個字的差異最容易被滑過去，但它才是真正的實質變更。
#
# 否定與免除的寫法要收齊（實測 M14、M15、M22、M26）：「毋須」「不須」不在表裡時，
# 「須→毋須」只看到「須」不見了，報成「責任用語增刪」，看不出是免除；「不可→可」更糟——
# 「不可」被當成「可」，新舊兩邊都數到一個「可」，整筆不報；「嚴禁→得」看不到禁止被拿掉。
MODAL_STRENGTH = {
    "不得": 4, "非經": 4, "禁止": 4, "不可": 4, "不應": 4, "嚴禁": 4,
    "應": 3, "須": 3, "必須": 3, "應予": 3,
    "宜": 2, "原則上": 2,
    "得": 1, "可": 1, "得予": 1,
    "無須": 1, "毋須": 1, "不須": 1, "無需": 1, "毋庸": 1, "免": 1,
}

# 每個詞屬於哪一類。強度只講得出「重了還是輕了」，講不出「義務變成免除」這種性質的轉變；
# 報告把兩邊的類別一起印出來，看的人不用自己再查「毋庸」算哪一種。
MODAL_KIND = {
    "不得": "禁止", "非經": "禁止", "禁止": "禁止", "不可": "禁止", "不應": "禁止", "嚴禁": "禁止",
    "應": "義務", "須": "義務", "必須": "義務", "應予": "義務",
    "宜": "建議", "原則上": "建議",
    "得": "裁量", "可": "裁量", "得予": "裁量",
    "無須": "免除", "毋須": "免除", "不須": "免除", "無需": "免除", "毋庸": "免除", "免": "免除",
}


# 這些詞裡面雖然有「應」「得」「可」「須」，但那不是責任用語，
# 是「應用程式」「取得」「可能」這種一般詞彙的一部分。
# 中文沒有空白斷詞，直接用 count() 會把它們全部算進去——實測「或行動應用程式」
# 就被誤判成「新增了一個應」。比對前先把這些複合詞遮掉。
_MODAL_DECOYS = [
    "應用", "應變", "應答", "應急", "應對", "應收", "應付", "應酬", "應試",
    "因應", "對應", "相應", "適應", "反應", "供應", "呼應", "感應", "響應", "供不應求",
    "取得", "獲得", "所得", "心得", "使得", "值得", "懂得", "覺得", "免得",
    "難得", "記得", "曉得", "捨得", "不得已", "得標", "得利",
    "可能", "可靠", "可疑", "可觀", "認可", "許可", "可行", "可否",
    # 「核可」「准可」是核准，不是「可以」（實測 M18：「同意→核可」被報成新增一個「可」）
    "核可", "准可", "寧可", "不可或缺",
    "不可竄改", "不可抗力", "不可分", "不可歸責", "不可撤銷", "不可逆",
    "須知", "必須",   # 必須另行計數，避免被「須」重複算
    "毋庸置疑", "無需求",
    # 「以免」「避免」裡的「免」不是免除（實測 M17：補一句「以免發生冒名投保」被報成新增「免」）
    "以免", "避免", "難免", "未免", "不免", "免費", "任免", "罷免",
    # 會計、繳費用語裡的「應X」是名詞，不是「應該」（實測 no 30）：
    # 「應繳金額」被算成新增了一個「應」，整條被報成【高】的責任用語變更。
    "應繳", "應計", "應攤",
]

# 誘餌要精準到詞：「應X」「得X」「可X」後面再多一個字，常常就變回真的「應＋動詞」。
# 以前整串照字面遮，「應變更」被遮成「應變」＋「更」、「應收取」被遮成「應收」＋「取」，
# 義務被拿掉也一筆不報（實測 M19、M21）；「應繳納→得繳納」只看到新增一個「得」（M20）。
# 下表：後面緊接著這幾個字的，不當誘餌。
_DECOY_UNLESS_NEXT = {
    "應答": "覆",             # 應答 ／ 應答覆
    "應試": "行辦",           # 應試者 ／ 應試行、應試辦
    "得利": "用",             # 得利（公司名、獲利）／ 得利用
    "可行": "使",             # 可行性 ／ 可行使
    "須知": "會悉",           # 投保須知 ／ 須知會、須知悉
    "應變": "更動",           # 應變計畫、應變措施 ／ 應變更、應變動
    "應收": "取回受齊妥執",   # 應收帳款 ／ 應收取、應收回、應收齊
    "應付": "給予清",         # 應付帳款 ／ 應付給、應付予
    "應繳": "納交回還清付",   # 應繳金額 ／ 應繳納、應繳交
    "應計": "入算列提",       # 應計利息 ／ 應計入、應計算
    "應攤": "還付",           # 應攤金額 ／ 應攤還
}
# 反過來，「應對」只有後面接名詞才是誘餌：「應對措施」是名詞，「應對客戶說明」是「應＋對」，
# 後者在內規裡常見得多，整串遮掉等於把一大類義務條文放掉。
_DECOY_ONLY_BEFORE = {
    "應對": ("措施", "方式", "策略", "方案", "機制", "計畫", "之道"),
}


def _decoy_pattern(decoy):
    if decoy in _DECOY_UNLESS_NEXT:
        return re.escape(decoy) + "(?![%s])" % _DECOY_UNLESS_NEXT[decoy]
    if decoy in _DECOY_ONLY_BEFORE:
        return re.escape(decoy) + "(?=%s)" % "|".join(_DECOY_ONLY_BEFORE[decoy])
    return re.escape(decoy)


def _decoy_regex(skip=()):
    """一支正規式由左往右遮，同一個位置長的先配（「不可竄改」先於「不可分」、「供不應求」先於「供應」）。"""
    words = sorted((d for d in _MODAL_DECOYS if d not in skip), key=len, reverse=True)
    return re.compile("|".join(_decoy_pattern(d) for d in words))


_DECOY_RE = _decoy_regex()
# 數責任用語時「必須」本身就是詞，不能遮；長的先配就不會被「須」重複算
_DECOY_RE_FOR_COUNT = _decoy_regex(skip=("必須",))


def _blank(match):
    """遮成等長的替代字元：遮短了，後面所有詞的位置就跟原文對不起來。"""
    return "○" * len(match.group(0))


def mask_compound_decoys(text):
    """只遮複合詞（應用程式、取得、不可竄改、應繳金額）。

    這一支可以安全地用在「接起來的差異片段」上：它比對的是實際存在的詞，
    不會因為兩段不相連的字被接在一起就生出新的比對結果。
    """
    return _DECOY_RE.sub(_blank, text)


def mask_decoys(text):
    """把「看起來是責任用語、其實不是」的字遮成等長的替代字元。

    兩類：
      一、複合詞（應用程式、取得、不可竄改）——那幾個字不是責任用語。
      二、外部法規全銜（保險業務員管理規則）——那是引用的專有名詞，
          不是這份內規自己的用語。遮罩規則跟交叉引用檢查共用 _common 那一份，
          兩邊各寫一份的話，同一句話在兩張產出裡會被當成不同的東西。
    長度一律保住：遮短了，後面所有詞的位置就跟原文對不起來。

    **只能餵整段原文**。法規全銜是「連續的一串字」才成立的樣式，餵接起來的
    差異片段會判錯：一處刪掉「應」、另一處刪掉「法」，接起來變成「應法」，
    剛好符合法規名樣式而被整個遮掉，真正被拿走的那個義務就一筆都不報。
    差異片段請改用 mask_compound_decoys。
    """
    return mask_compound_decoys(mask_law_names(text))


_MODAL_TERMS = sorted(MODAL_STRENGTH, key=len, reverse=True)


def _masked_for_modals(text):
    """數責任用語用的遮罩：法規全銜＋複合詞（「必須」不遮）。"""
    return _DECOY_RE_FOR_COUNT.sub(_blank, mask_law_names(text or ""))


def _scan_modals(masked, start=0, end=None):
    """由左往右「長的先配」（不得 先於 得、毋須 先於 須、應予 先於 應），一個字只算一次。

    回傳 [(位置, 詞)]。start／end 給子句用：只掃那一段，位置仍是整段的位置。
    """
    end = len(masked) if end is None else end
    found = []
    i = start
    while i < end:
        for term in _MODAL_TERMS:
            if masked.startswith(term, i, end):
                found.append((i, term))
                i += len(term)
                break
        else:
            i += 1
    return found


def count_modals(text):
    """整段裡每個責任用語出現幾次：先遮法規全銜與複合詞，再由左往右「長的先配」
    （不得 先於 得、必須／無須 先於 須、應予 先於 應），一個字只算一次。"""
    import collections
    return collections.Counter(term for _pos, term in _scan_modals(_masked_for_modals(text)))


# 子句的邊界。「應A，並得B」對調成「得A，並應B」時整段的詞數一樣，要拆到子句才看得出來。
_CLAUSE_RE = re.compile(r"[^，。；：、,;:!?！？\n]+")
# 子句配對的相似度門檻（拿掉責任用語之後比）。真的對調時兩邊子句本文一模一樣（1.0）；
# 0.6 是給「順手改了一兩個字」留的餘地，再低就容易把不相干的兩個子句硬配在一起，
# 只是換了子句順序（得A，並應B → 應B，並得A）也會被誤報成對調。
_CLAUSE_PAIR_THRESHOLD = 0.6


def _modal_clauses(text):
    """[(子句原文, 拿掉責任用語之後的本文, [詞, ...])]，只留有責任用語的子句。"""
    # 條號先拿掉：第一個子句帶著「第二條　」，相似度會被條號墊高，配到不該配的子句
    raw = strip_article_no(text or "")
    masked = _masked_for_modals(raw)
    # 遮罩照理等長；萬一不等長（日後有人改了遮罩），引文退回用遮過的字，位置才不會錯開
    shown = raw if len(raw) == len(masked) else masked
    clauses = []
    for match in _CLAUSE_RE.finditer(masked):
        hits = _scan_modals(masked, match.start(), match.end())
        if not hits:
            continue
        pieces, cursor = [], match.start()
        for pos, term in hits:
            pieces.append(masked[cursor:pos])
            cursor = pos + len(term)
        pieces.append(masked[cursor:match.end()])
        clauses.append((shown[match.start():match.end()], "".join(pieces).strip(),
                        [term for _pos, term in hits]))
    return clauses


def _swapped_modals(old_text, new_text):
    """整段詞數沒變，但同一個子句的責任用語換了。回傳 [(新版子句, 舊詞, 新詞), ...]。

    子句用「拿掉責任用語之後的本文」配對：「說明商品內容」配「說明商品內容」，
    兩邊的詞不一樣就是這一句的責任換了。只換子句順序、每句的詞跟著句子走的，配起來詞一樣，不報。
    """
    import collections
    old_clauses, new_clauses = _modal_clauses(old_text), _modal_clauses(new_text)
    # 先配最像的那一對，不是照舊版順序一句一句搶：子句順序換過時（得A，並應B → 應B，並得A），
    # 照順序搶會讓第一句先搶走「主詞一樣、動作不同」的那一句，誤報成對調
    scored = []
    for i, (_raw, skeleton, _terms) in enumerate(old_clauses):
        for j, (_raw2, skeleton2, _terms2) in enumerate(new_clauses):
            score = 1.0 if skeleton2 == skeleton else difflib.SequenceMatcher(
                None, skeleton, skeleton2, autojunk=False).ratio()
            if score >= _CLAUSE_PAIR_THRESHOLD:
                scored.append((-score, i, j))
    used_old, used_new, matched = set(), set(), []
    for _score, i, j in sorted(scored):
        if i in used_old or j in used_new:
            continue
        used_old.add(i)
        used_new.add(j)
        matched.append((i, j))
    swaps = []
    for i, j in sorted(matched):
        terms, (raw2, _skeleton2, terms2) = old_clauses[i][2], new_clauses[j]
        if collections.Counter(terms) != collections.Counter(terms2):
            swaps.append((raw2, terms, terms2))
    return swaps


def check_modal_changes(results):
    """
    在字級差異裡找出責任用語的變化。

    只看「真正被改掉的那幾個字」，不看整段，所以雜訊很低：
    一段話改了三十個字但沒動到「應」「得」，就不會被列出來。

    法規全銜的遮罩下在**比對之前的整段原文**，不是下在接起來的差異片段上：
    全銜要連續的一串字才成立，遮罩長度又跟原文等長，所以先遮再比對，
    位置一個都不會跑掉，而全銜內部的改動（保險法→保險業務員管理規則）
    會變成一串○對一串○，自然不會被當成責任用語變更。
    片段那一層只遮複合詞（mask_compound_decoys）。
    """
    findings = []
    # 整條改寫（比對判成一刪一增）也要進來，不然責任範圍被改掉沒人看得到。詳見 logical_rewrites。
    #
    # 以前只數「差異片段」裡的詞：「不得→得」差異只有一個「不」、「須→無須」只多一個「無」，
    # 片段裡都湊不成詞，完全不報；「必須」又在誘餌表裡被遮掉，「得→必須」只看到得被刪（A13）。
    # 現在整段新舊各數一次（長的詞先配），差幾個就是改了幾個；沒動到的部分自然互相抵掉。
    for result in _with_rewrites(results):
        if result["type"] != "modified":
            continue

        before, after = count_modals(result["old_text"]), count_modals(result["new_text"])
        changed = []
        for term in MODAL_STRENGTH:
            delta = after[term] - before[term]
            if delta:
                changed.append((term, delta))

        if changed:
            gone = [t for t, d in changed if d < 0]
            appeared = [t for t, d in changed if d > 0]
            direction = _strictness_direction(gone, appeared)
            detail = "%s（%s → %s%s）" % (direction,
                                         "、".join(gone) or "（無）",
                                         "、".join(appeared) or "（無）",
                                         _kind_note(gone, appeared))
        else:
            # 詞數一樣不代表沒改：「應說明商品內容，並得提供建議書」→「得說明…，並應提供…」
            # 兩邊都是一個應、一個得，整段數下來互相抵掉，以前一筆不報（實測 M12）。
            swaps = _swapped_modals(result["old_text"], result["new_text"])
            if not swaps:
                continue
            direction = "責任用語對調"
            detail = "責任用語對調（整段的詞數沒變，但子句的責任換了：%s）" % "；".join(
                "「%s」%s → %s" % (clip(raw, 16), "、".join(old_terms),
                                   "、".join(new_terms))
                for raw, old_terms, new_terms in swaps)

        findings.append(finding(
            HIGH if direction != "用語調整" else MEDIUM,
            "責任用語變更",
            detail,
            index=result.get("new_index") or result.get("old_index"),
            ref=result.get("ref", ""),
            quote="原文：%s ／ 修改後：%s" % (clip(result["old_text"], 40),
                                            clip(result["new_text"], 40)),
            action="確認這是否為有意識的責任範圍調整，並在修正理由欄敘明",
            change_type=result.get("change_type") or MODIFIED_LABEL))
    return findings


def _strictness_direction(gone, appeared):
    """判斷是鬆綁、加嚴，還是只是換個說法。"""
    if not gone or not appeared:
        return "責任用語增刪"
    before = max(MODAL_STRENGTH[t] for t in gone)
    after = max(MODAL_STRENGTH[t] for t in appeared)
    if after < before:
        return "責任放寬（鬆綁）"
    if after > before:
        return "責任加重（加嚴）"
    return "用語調整"


def _kind_note(gone, appeared):
    """接在「應 → 得」後面的類別說明（；義務 → 裁量、；同屬禁止）。"""
    def kinds(terms):
        seen = []
        for term in terms:
            if MODAL_KIND[term] not in seen:
                seen.append(MODAL_KIND[term])
        return "、".join(seen) or "（無）"
    before, after = kinds(gone), kinds(appeared)
    if gone and appeared and before == after:
        return "；同屬%s" % before
    return "；%s → %s" % (before, after)


# ---------------------------------------------------------------------------
# 2. 數值、期間、金額變更
# ---------------------------------------------------------------------------

_UNITS = ("個營業日", "個工作日", "個星期", "個月", "營業日", "工作日", "星期", "日", "週",
          "月", "年", "小時", "分鐘", "億元", "萬元", "元", "％", "%", "倍", "次", "人",
          "件", "成", "歲")

# 國字數字（含大寫）。大寫是金額的慣用寫法（新臺幣壹拾萬元），以前不在字元表裡，
# 「壹拾萬元→貳拾萬元」一筆都抓不到（實測 N22）。
_CN_DIGIT_VALUE = {"零": 0, "〇": 0, "一": 1, "壹": 1, "二": 2, "貳": 2, "兩": 2,
                   "三": 3, "參": 3, "叁": 3, "四": 4, "肆": 4, "五": 5, "伍": 5,
                   "六": 6, "陸": 6, "七": 7, "柒": 7, "八": 8, "捌": 8, "九": 9, "玖": 9}
_CN_SMALL_UNIT = {"十": 10, "拾": 10, "百": 100, "佰": 100, "千": 1000, "仟": 1000}
_CN_LARGE_UNIT = {"萬": 10 ** 4, "億": 10 ** 8}
_NUM_CHARS = "".join(_CN_DIGIT_VALUE) + "".join(_CN_SMALL_UNIT) + "".join(_CN_LARGE_UNIT)
# 阿拉伯數字的千分位逗號只認「三位一組」：NFKC 會把全形「，」轉成半形「,」，
# 不限定的話「十五日，三十日」這種句子裡的逗號會把前後兩個數字接成一個。
# 用佔有量詞（++、*+）：數字串很長時不會回溯到爆。
_NUM = r"(?:\d++(?:,\d{3})*+(?:\.\d+)?+|[%s])++" % _NUM_CHARS
_ARABIC_RE = re.compile(r"\d+(?:,\d{3})*(?:\.\d+)?")

# 「百分之五十」「千分之三」以前完全不抓（實測 N13、N19）：數字後面沒有單位，
# 樣式配不到。分數寫法另開一支，換算成百分比再比。
# 「半年」「半個月」的「半」也算數字；「上半年」「下半年」講的是時段，不算。
_QUANTITY_RE = re.compile(
    r"(?P<frac>百分之|千分之|萬分之)(?P<fnum>%s)"
    r"|(?P<num>%s|(?<![上下前後])半)\s*(?P<unit>%s)" % (_NUM, _NUM, "|".join(_UNITS)))

# 換算成可以比的值：同一個值換個寫法（十五日→15日、一百萬元→100萬元、八成→80%、
# 一週→七日、百分之五→5%）不是數值變更。對照表照樣標修改（那是異動偵測的事），
# 條文檢查不再報【高】——報了會讓人去查一個根本沒變的期限（實測 N15、N17）。
# 只換算「換了也不會有爭議」的：一週固定七日；月與日（一個月不一定是三十日）、
# 日與小時（期間的起算方式不同）、年與月都不換，寫法改了照樣報。
_UNIT_CANON = {
    "億元": ("元", 10 ** 8), "萬元": ("元", 10 ** 4), "元": ("元", 1),
    "％": ("%", 1), "%": ("%", 1), "成": ("%", 10),
    "週": ("日", 7), "星期": ("日", 7), "個星期": ("日", 7),
    "個營業日": ("營業日", 1), "個工作日": ("工作日", 1),
}
_FRACTION_CANON = {"百分之": 1, "千分之": 0.1, "萬分之": 0.01}


def _parse_number(text):
    """「十五」「一百萬」「100萬」「壹拾萬」「1.5」「5,000」「二〇」→ 數值；看不懂回 None。"""
    if text == "半":
        return 0.5
    total, section, current = 0, 0, None
    pos = 0
    while pos < len(text):
        arabic = _ARABIC_RE.match(text, pos)
        if arabic:
            if current is not None:
                return None          # 兩串阿拉伯數字黏在一起（1,2345），不猜
            current = float(arabic.group(0).replace(",", ""))
            pos = arabic.end()
            continue
        char = text[pos]
        pos += 1
        if char in _CN_DIGIT_VALUE:
            digit = _CN_DIGIT_VALUE[char]
            # 「一百零五」的零之後接五；「二〇」「一一五」這種逐位寫法照十進位接起來
            current = digit if current is None else current * 10 + digit
        elif char in _CN_SMALL_UNIT:
            section += (1 if current is None else current) * _CN_SMALL_UNIT[char]
            current = None
        elif char in _CN_LARGE_UNIT:
            part = (section + (current or 0)) or 1
            if char == "億":
                total = (total + part) * _CN_LARGE_UNIT[char]
            else:
                total += part * _CN_LARGE_UNIT[char]
            section, current = 0, None
        else:
            return None
    return total + section + (current or 0)


def _quantities(text):
    """抽出 [(顯示用的字, 比較用的鍵, 位置)]。text 要先正規化過。

    鍵是 (單位, 換算後的值)：「十五日」與「15日」的鍵一樣，「一週」與「七日」的鍵一樣。
    看不懂的數字拿原字當值，至少照字面比，不會整筆漏掉。
    """
    items = []
    for match in _QUANTITY_RE.finditer(text):
        if match.group("frac"):
            raw_number, shown = match.group("fnum"), match.group(0)
            unit, scale = "%", _FRACTION_CANON[match.group("frac")]
        else:
            raw_number = match.group("num")
            shown = raw_number + match.group("unit")
            unit, scale = _UNIT_CANON.get(match.group("unit"), (match.group("unit"), 1))
        value = _parse_number(raw_number)
        key = (unit, round(value * scale, 6)) if value is not None else (unit, shown)
        items.append((shown, key, match.span()))
    return items


def check_numeric_changes(results):
    """
    在字級差異裡找出數字、期間、金額的變化。

    法遵複核時這是必看項：期間從十五日放寬成三十日、金額門檻從十萬提高到
    二十萬，都是實質變更，但夾在文字修改裡很容易被當成潤稿滑過去。
    """
    findings = []
    # 整條改寫（比對判成一刪一增）也要進來：期間、金額的門檻最常夾在整條重寫裡。
    for result in _with_rewrites(results):
        if result["type"] != "modified":
            continue

        # 這裡刻意比對「整段」而不是只看 diff 片段。
        # 「十五日」改成「三十日」時，單位「日」沒有變動，會留在相同片段裡，
        # 只掃描差異片段的話只看得到「十五」與「三十」，抓不到單位就整筆漏掉。
        #
        # 抽數字之前先正規化（只給比對用，報告引用的仍是原文）：不正規化的話全形與半形
        # 會被當成兩個不同的值——「３１日 → 31日」這種純字形統一會被列成【高】實質數值變更；
        # 更糟的是單位「％」配不上「%」，「３％至５％ → 3%至7%」會被拆成四筆增刪，
        # 真正變的那個 5%→7% 反而看不出來。
        old_items = _quantities(normalize_for_compare(result["old_text"]))
        new_items = _quantities(normalize_for_compare(result["new_text"]))
        if [key for _s, key, _p in old_items] == [key for _s, key, _p in new_items]:
            # 值跟順序都一樣，只是寫法換了（十五日→15日、一百萬元→100萬元）：不報
            continue
        # 照次數比（不是「有沒有」）：「三日申報、五日核定」對調成「五日申報、三日核定」，
        # 兩邊都有三日、五日，以前不報（B7）；同一個值少寫一次也是變更
        removed = _minus(old_items, new_items)
        added = _minus(new_items, old_items)

        # 同單位的一減一增，配成「十五日 → 三十日」比較好讀
        pairs, leftover_removed, leftover_added = _pair_by_unit(removed, added)
        parts = ["%s → %s" % (a, b) for a, b in pairs]
        parts += ["刪除 %s" % x for x in leftover_removed]
        parts += ["新增 %s" % x for x in leftover_added]
        if not parts:
            # 值都一樣、只有順序變了：哪個期限配哪件事換過了
            parts = ["數值順序對調（%s → %s）" % ("、".join(s for s, _k, _p in old_items),
                                               "、".join(s for s, _k, _p in new_items))]

        findings.append(finding(
            HIGH, "數值期間變更", "；".join(parts),
            index=result.get("new_index") or result.get("old_index"),
            ref=result.get("ref", ""),
            quote="修改後：%s" % result["new_text"][:50],
            action="確認新的數值是否符合母法或主管機關規定的上下限",
            change_type=result.get("change_type") or MODIFIED_LABEL))
    return findings


def _minus(left, right):
    """left 扣掉 right（照次數、照比較用的鍵），保留 left 的順序。"""
    import collections
    extra = (collections.Counter(item[1] for item in left)
             - collections.Counter(item[1] for item in right))
    out = []
    for item in left:
        if extra[item[1]] > 0:
            out.append(item)
            extra[item[1]] -= 1
    return out


def _pair_by_unit(removed, added):
    """把同單位（換算後）的舊值新值配成一對。配不到的分別列出。"""
    remaining = list(added)
    pairs = []
    leftover_removed = []

    for shown, key, _span in removed:
        match = next((item for item in remaining if item[1][0] == key[0]), None)
        if match:
            remaining.remove(match)
            pairs.append((shown, match[0]))
        else:
            leftover_removed.append(shown)

    return pairs, leftover_removed, [item[0] for item in remaining]


# ---------------------------------------------------------------------------
# 2b. 門檻用語（以上／以下、逾／未滿、超過／不足、達／未達）
# ---------------------------------------------------------------------------
#
# 數字沒變、門檻方向反了：「達新臺幣五十萬元以上者，應申報」→「…五十萬元以下者」，
# 數值期間檢查看到的是同一個「五十萬元」，一筆都不報（實測 N23）。這一項只看緊貼著
# 數字的門檻用語，改了就報「這裡的門檻方向／含不含本數改了」；改得對不對、是不是有意的，
# 交給人判斷，程式不下結論。
#
# 每個詞記兩件事：方向（這個數「以上」才算，還是「以下」才算）與含不含本數。
# 「以上→逾」方向一樣，但剛好五十萬元那一筆從「算」變成「不算」，一樣要人看。
_THRESHOLD_BEFORE = {   # 寫在數字前面的
    "不少於": ("以上", True), "不低於": ("以上", True), "至少": ("以上", True),
    "達": ("以上", True), "滿": ("以上", True),
    "超過": ("以上", False), "高於": ("以上", False), "多於": ("以上", False), "逾": ("以上", False),
    "不超過": ("以下", True), "未逾": ("以下", True), "不逾": ("以下", True), "至多": ("以下", True),
    "未滿": ("以下", False), "不滿": ("以下", False), "不足": ("以下", False), "未達": ("以下", False),
    "低於": ("以下", False), "少於": ("以下", False),
}
_THRESHOLD_AFTER = {    # 寫在數字（含單位）後面的；「十五日內」與「十五日以內」同義
    "以上": ("以上", True), "以下": ("以下", True), "以內": ("以下", True), "內": ("以下", True),
}
_THRESHOLD_WORDS = dict(_THRESHOLD_BEFORE, **_THRESHOLD_AFTER)
_THRESHOLD_SENSE = {("以上", True): "含本數以上", ("以上", False): "超過、不含本數",
                    ("以下", True): "含本數以下", ("以下", False): "未達、不含本數"}
_THRESHOLD_BEFORE_RE = re.compile("|".join(sorted(_THRESHOLD_BEFORE, key=len, reverse=True)))
_THRESHOLD_AFTER_RE = re.compile(r"\s*(?:\(含(?:本數)?\))?\s*(以上|以下|以內|內)")
# 不是門檻的「達」「滿」「逾」：送達、達成、期滿、逾期（逾期是「過了期限」，後面的數字是逾期多久）
_THRESHOLD_DECOY_RE = re.compile(
    "送達|到達|抵達|傳達|轉達|達成|通達|表達|下達|發達|期滿|滿意|圓滿|充滿|逾期")
# 門檻詞跟數字之間最多隔幾個字（「逾新臺幣十萬元」「超過首年度保險費百分之五十」）
_THRESHOLD_WINDOW = 10


def _threshold_marks(text):
    """每個數量配上緊貼著它的門檻詞：[(顯示字, 比較鍵, 前面的詞或 None, 後面的詞或 None)]。"""
    norm = normalize_for_compare(text)
    masked = _THRESHOLD_DECOY_RE.sub(_blank, norm)
    marks = []
    previous_end = 0
    for shown, key, (start, end) in _quantities(norm):
        window = masked[max(previous_end, start - _THRESHOLD_WINDOW):start]
        # 跨過標點就不算同一個門檻：「逾三日者，五日內…」的「逾」不是五日的
        window = re.split(r"[。;,:!?、]", window)[-1]
        before = _THRESHOLD_BEFORE_RE.findall(window)
        after = _THRESHOLD_AFTER_RE.match(masked, end)
        marks.append((shown, key, before[-1] if before else None,
                      after.group(1) if after else None))
        previous_end = end
    return marks


def _pair_marks(old_marks, new_marks):
    """先配值一樣的（數字沒動、門檻詞改了），再配同單位的（數字跟門檻一起改）。"""
    pairs, used_old, used_new = [], set(), set()
    for same_value in (True, False):
        for i, old in enumerate(old_marks):
            if i in used_old:
                continue
            for j, new in enumerate(new_marks):
                if j in used_new:
                    continue
                if (old[1] == new[1]) if same_value else (old[1][0] == new[1][0]):
                    used_old.add(i)
                    used_new.add(j)
                    pairs.append((i, old, new))
                    break
    return [(old, new) for _i, old, new in sorted(pairs, key=lambda p: p[0])]


def _threshold_kind(old_word, new_word):
    """兩個門檻詞差在哪裡；同義換字（超過→逾、以內→內）回 None。"""
    old_sense, new_sense = _THRESHOLD_WORDS[old_word], _THRESHOLD_WORDS[new_word]
    if old_sense[0] != new_sense[0]:
        return "門檻方向改變"
    if old_sense[1] != new_sense[1]:
        return "含不含本數改變"
    return None


def _threshold_events(old, new):
    """一組新舊數量的門檻差異 [(種類, 舊詞, 新詞)]，以及兩邊都有的詞。

    數字前、後兩個位置合起來比，不分開比：「五十萬元以上」→「逾五十萬元」是同一個門檻
    從「以上」換成「逾」（含不含本數改了），分開比會變成一刪一增兩筆。
    """
    old_words = [w for w in (old[2], old[3]) if w]
    new_words = [w for w in (new[2], new[3]) if w]
    common = [w for w in old_words if w in new_words]
    old_rest = [w for w in old_words if w not in common]
    new_rest = [w for w in new_words if w not in common]
    events = []
    for old_word, new_word in zip(old_rest, new_rest):
        kind = _threshold_kind(old_word, new_word)
        if kind:
            events.append((kind, old_word, new_word))
    events += [("刪除門檻用語", w, None) for w in old_rest[len(new_rest):]]
    events += [("新增門檻用語", None, w) for w in new_rest[len(old_rest):]]
    return events, common


def _senses(mark):
    return {_THRESHOLD_WORDS[w] for w in (mark[2], mark[3]) if w}


def check_threshold_changes(results):
    """數字旁邊的門檻用語改了：以上→以下、逾→未滿、達→未達，或「以上」被刪掉。

    只報事實（哪一個數字、哪個詞改成哪個詞、方向與含不含本數怎麼變），不判斷改得對不對。
    同一處還有另一個意思一樣的詞（「達五十萬元以上」刪掉「以上」，「達」還在）時降成「中」，
    並把那個詞講出來，讓人自己看整體的門檻有沒有變。
    """
    findings = []
    for result in _with_rewrites(results):
        if result["type"] != "modified":
            continue
        events, severity = [], MEDIUM
        for old, new in _pair_marks(_threshold_marks(result["old_text"]),
                                    _threshold_marks(result["new_text"])):
            changes, common = _threshold_events(old, new)
            for kind, old_word, new_word in changes:
                quantity = old[0] if old[0] == new[0] else "%s → %s" % (old[0], new[0])
                text = "%s（%s）：%s → %s（%s → %s）" % (
                    kind, quantity, old_word or "（無）", new_word or "（無）",
                    _THRESHOLD_SENSE.get(_THRESHOLD_WORDS.get(old_word), "沒寫門檻"),
                    _THRESHOLD_SENSE.get(_THRESHOLD_WORDS.get(new_word), "沒寫門檻"))
                if _senses(old) == _senses(new) and common:
                    text += "；同一處另有「%s」，整體門檻可能仍由它表達" % "、".join(common)
                else:
                    severity = HIGH
                events.append(text)
        if not events:
            continue
        findings.append(finding(
            severity, "門檻用語變更", "；".join(events),
            index=result.get("new_index") or result.get("old_index"),
            ref=result.get("ref", ""),
            quote="原文：%s ／ 修改後：%s" % (clip(result["old_text"], 40),
                                            clip(result["new_text"], 40)),
            action="確認門檻的方向與含不含本數是有意調整的，並在修正理由欄敘明",
            change_type=result.get("change_type") or MODIFIED_LABEL))
    return findings


# ---------------------------------------------------------------------------
# 2c. 但書（「但…不在此限」）的增刪
# ---------------------------------------------------------------------------
#
# 加一句「但經本公司同意者，不在此限。」整條的義務就多了一個例外；拿掉一句但書，
# 原本的例外就沒了。責任用語一個都沒動（實測 M25），前面幾項全部不報。
# 這一項只數但書的句數與「但書」二字的引用，有增有減就報，並把那一句列出來。
# 但書內容改寫（句數不變）是一般的修改，對照表本來就看得到，這裡不另外報。
_PROVISO_RE = re.compile(r"(?:^|(?<=[。；;，,：:\s]))但(?!書)[^。；;]*")
# 沒寫「但」的例外：「有下列情形之一者，不在此限」
_EXCEPTION_RE = re.compile(r"[^。；;]*不在此限")


def _provisos(text):
    """[但書句原文, ...]（頭尾空白去掉）。比較時另外正規化，報告引用原文。"""
    raw = strip_article_no(text or "")
    spans = [match.span() for match in _PROVISO_RE.finditer(raw)]
    units = [raw[s:e] for s, e in spans]
    for match in _EXCEPTION_RE.finditer(raw):
        tail = match.end() - len("不在此限")
        if not any(s <= tail < e for s, e in spans):
            units.append(match.group(0))
    return [unit.strip() for unit in units if unit.strip()]


def check_proviso_changes(results):
    """新增或刪除但書（「但…」「…不在此限」），以及「但書」二字的引用增減。

    只講「這裡加了／拿掉一個例外」並列出那一句，不判斷例外合不合理。
    """
    findings = []
    for result in _with_rewrites(results):
        if result["type"] != "modified":
            continue
        old_units, new_units = _provisos(result["old_text"]), _provisos(result["new_text"])
        events = []
        if len(new_units) != len(old_units):
            grew = len(new_units) > len(old_units)
            changed = (_minus_text(new_units, old_units) if grew
                       else _minus_text(old_units, new_units))
            events.append("%s但書（例外規定）：%s" % (
                "新增" if grew else "刪除",
                "、".join("「%s」" % clip(unit, 30) for unit in changed)))
        old_refs = (result["old_text"] or "").count("但書")
        new_refs = (result["new_text"] or "").count("但書")
        if old_refs != new_refs:
            events.append("%s引用「但書」的文字（%d 處 → %d 處）"
                          % ("新增" if new_refs > old_refs else "刪除", old_refs, new_refs))
        if not events:
            continue
        findings.append(finding(
            HIGH, "但書增刪", "；".join(events),
            index=result.get("new_index") or result.get("old_index"),
            ref=result.get("ref", ""),
            quote="原文：%s ／ 修改後：%s" % (clip(result["old_text"], 40),
                                            clip(result["new_text"], 40)),
            action="確認例外規定的增刪是有意的，適用範圍寫清楚，並在修正理由欄敘明",
            change_type=result.get("change_type") or MODIFIED_LABEL))
    return findings


def _minus_text(left, right):
    """left 裡 right 沒有的那幾句（照次數，正規化之後比）；全部都有（只是句數變了）就整份回傳。"""
    import collections
    extra = (collections.Counter(normalize_for_compare(x) for x in left)
             - collections.Counter(normalize_for_compare(x) for x in right))
    out = []
    for item in left:
        key = normalize_for_compare(item)
        if extra[key] > 0:
            out.append(item)
            extra[key] -= 1
    return out or list(left)


# ---------------------------------------------------------------------------
# 3. 施行日期
# ---------------------------------------------------------------------------

# 只認「真的在講生效時點」的句型，不是看到「施行／實施」就算。
# 「前項作業應於核定後實施。」「本要點實施前已受理之案件……」這些都含「實施」，
# 但它們不是施行日期條文——誤判會讓程式指著無關的條文說「施行日期沒改」，
# 那比不檢查更糟，人會開始不信任這一項。
_SELF_REF = r"本(?:要點|辦法|準則|規則|規定|細則|注意事項|程序|標準|章程|須知|原則|規章|表)"

_EFFECTIVE_RE = re.compile(
    # 一、「本要點……自／經／於……施行」——最常見的寫法
    _SELF_REF + r".{0,30}?[自經於].{0,20}?(?:施行|生效|實施)"
    # 二、「自發布日施行」——即使沒寫主詞，這個句型也不會是別的意思
    r"|自.{0,20}?(?:發布|公布|核定|頒布|函頒|即日|中華民國|民國|\d).{0,20}?(?:施行|生效)"
    # 三、直接寫「施行日期」「生效日期」
    r"|(?:施行|生效)日期")

# 施行條文的長度上限。超過的多半是一般條文順帶提到「實施」，不是施行條文——
# 但段首第一句就是施行句型的照收：「本要點自發布日施行。但中華民國一百十三年…修正發布之
# 第五條…自一百十四年七月一日施行。」這種分段施行的但書常超過 60 字，以前整條被當成
# 「全文找不到施行條文」，報錯了方向（實測 E07）。
_EFFECTIVE_MAX_LEN = 60

# 條文裡寫了確定的日期（「一百十四年七月一日」「114年7月1日」「○○年○月○日」）。
_EFFECTIVE_DATE_RE = re.compile(r"[%s\d○〇Ｏ０-９]+\s*年\s*[%s\d○〇Ｏ０-９]*\s*月" % (CN, CN))
# 「修正時亦同」：修正條文跟著同一套程序生效，條文本身不用改（實測 E04）
_SELF_UPDATING_RE = re.compile(r"修正(?:時|後)?\s*[，,]?\s*亦同")


def _is_effective_clause(text):
    """這一段是不是施行條文：短的照 _EFFECTIVE_RE 判；長的只認段首第一句就是施行句型的。"""
    if not _EFFECTIVE_RE.search(text):
        return False
    if len(text) < _EFFECTIVE_MAX_LEN:
        return True
    first = re.split(r"[。；;]", strip_article_no(text).strip(), 1)[0]
    return len(first) < _EFFECTIVE_MAX_LEN and bool(_EFFECTIVE_RE.search(first))


def _needs_new_date(text):
    """修了條文，這一條施行條文要不要跟著改：沒寫日期、又寫了「修正時亦同」的不用。

    「本要點經董事會通過後施行，修正時亦同。」修正條文一樣經董事會通過後施行，這一條
    一個字都不必動；以前照樣報「施行日期條文沒有跟著修改」，人照著去改反而改錯。
    只放這一種：「本要點自發布日施行。」沒寫「修正時亦同」，修正條文是不是也自發布日施行、
    要不要另訂，還是要人看一眼，照舊報。
    """
    return bool(_EFFECTIVE_DATE_RE.search(text)) or not _SELF_UPDATING_RE.search(text)


def check_effective_date(paragraphs, results):
    """
    改了實質條文，施行日期條文卻原封不動——不一定是錯，但一定要問一句。

    內規修正通常要註明「本要點修正條文自○年○月○日施行」。忘了改的話，
    新規定的生效日會停留在上一版，實務上會出現「規定改了但沒生效」的爭議。
    """
    effective = [(idx, text) for idx, text in enumerate(paragraphs, 1)
                 if _is_effective_clause(text)]

    substantive = [r for r in results
                   if r["type"] in ("added", "deleted", "modified")]
    if not substantive:
        return []

    if not effective:
        return [finding(MEDIUM, "施行日期",
                        "全文找不到施行或生效日期的條文",
                        action="確認是否需要補一條「本要點修正條文自○年○月○日施行」")]

    # 施行日期條文只差一個全形空格不算「改過」，不然這一項會靜靜地放行，
    # 人以為日期改好了，實際上還停在上一版。
    # renumbered（只有條號位移、內容一個字沒動）跟 cosmetic 一樣不算「改過」：
    # 施行日期條文被往前遞補一號不代表日期改了，放行的話這一項會靜靜地說沒事。
    changed_effective = any(
        r["type"] not in ("unchanged", "cosmetic", "renumbered")
        and any(text == r.get("new_text") or text == r.get("old_text")
                for _, text in effective)
        for r in results)

    if changed_effective:
        # 施行日期改成「○○年○月○日」也算「改過」，以前這一項就放行了，待補殘留又認不得
        # 「○○」，兩項都印「通過」，日期沒填就送出去。改過但日期還是佔位字的要講一聲。
        for idx, text in effective:
            placeholder = _PLACEHOLDER_RE.search(text)
            if placeholder and any(r.get("new_text") == text for r in results
                                   if r["type"] not in ("unchanged", "cosmetic", "renumbered")):
                return [finding(MEDIUM, "施行日期",
                                "施行日期條文改了，但日期還是「%s」，尚未填入" % placeholder.group(0),
                                index=idx, quote=text,
                                action="填入確定的施行日期")]
        return []

    # 每一條施行條文都是「修正時亦同」、又沒寫日期：修正條文自動跟著生效，沒有要改的
    pending = [(idx, text) for idx, text in effective if _needs_new_date(text)]
    if not pending:
        return []
    idx, text = pending[-1]
    return [finding(MEDIUM, "施行日期",
                    "本次有 %d 處實質異動，但施行日期條文沒有跟著修改" % len(substantive),
                    index=idx, quote=text,
                    action="確認修正條文的生效日期是否需要另訂")]


# ---------------------------------------------------------------------------
# 4. 條號健全性
# ---------------------------------------------------------------------------

_ARTICLE_NO_RE = re.compile(r"^第\s*([%s\d]+)\s*條(?:\s*之\s*([%s\d]+))?" % (CN, CN))


def _cn_value(text):
    """中文數字轉整數，支援到千位（條號用得到「第一百十六條」）。"""
    if not text:
        return None
    if text.isdigit():
        return int(text)
    digits = {"零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "三": 3, "四": 4,
              "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    units = {"十": 10, "百": 100, "千": 1000}
    total, current = 0, 0
    for char in text:
        if char in digits:
            current = digits[char]
        elif char in units:
            current = current or 1
            total += current * units[char]
            current = 0
        else:
            return None
    return total + current


# 「第六條　（刪除）」這種刪除註記。依法制慣例，刪除某一條時保留條號並如此註記，
# 後面的條號才不會全部往前移、導致其他規章的引用全部指錯。
_DELETED_MARK_RE = re.compile(r"^[（(]\s*刪\s*除\s*[）)]\s*$")


def check_article_integrity(paragraphs, old_paragraphs=None, kinds=None,
                            old_kinds=None):
    """
    條號本身的健全性：重複、跳號、「之一」順序錯亂、只有條號沒有內容。

    這幾種毛病在 50 頁的內規裡靠肉眼幾乎抓不到，但送出去會被挑。

    old_paragraphs：給了舊版的話，會分辨跳號是「本次修訂造成的」還是
    「上一版就已經存在」。既有的斷號每次修訂都報一次是純雜訊，
    使用者看久了會連真正該看的那筆一起略過。
    """
    findings = []
    contexts = build_hierarchy(paragraphs, kinds)
    seen = {}
    sequence = []

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        if context["level"] != "條":
            continue
        match = _ARTICLE_NO_RE.match(text)
        if not match:
            continue

        main = _cn_value(match.group(1))
        sub = _cn_value(match.group(2)) if match.group(2) else 0
        label = context["article"]

        if label in seen:
            findings.append(finding(
                HIGH, "條號重複",
                "%s 出現兩次（第 %d 段與第 %d 段）" % (label, seen[label], idx),
                index=idx, ref=label, quote=text[:40],
                action="確認是否誤植，或其中一條應改號"))
        else:
            seen[label] = idx

        body = text[match.end():].strip(" 　:：")
        if not body:
            findings.append(finding(
                MEDIUM, "空白條文", "%s 只有條號、沒有內容" % label,
                index=idx, ref=label,
                action="若為刪除，請改為「%s　（刪除）」的標準寫法" % label))

        is_deleted_mark = bool(_DELETED_MARK_RE.match(body))
        sequence.append((main, sub, label, idx, text, is_deleted_mark))

    existing_gaps = _gap_articles(old_paragraphs, old_kinds) if old_paragraphs else set()
    findings.extend(_check_sequence(sequence, existing_gaps))
    findings.extend(_check_tail(sequence, old_paragraphs, old_kinds))
    return findings


def _article_numbers(paragraphs, kinds=None):
    """一份文件裡「條」層級宣告的主條號序列（不含「之一」那種附條）。

    只看 build_hierarchy 判成「條」的段落：舊版裡的引用句（「第二十條之規定…」）
    不是宣告，算進來會生出一段假的條號序列，跳號判斷跟著錯。
    """
    numbers = []
    for text, context in zip(paragraphs or [], build_hierarchy(paragraphs or [], kinds)):
        if context["level"] != "條":
            continue
        match = _ARTICLE_NO_RE.match(text)
        if match and not match.group(2):
            value = _cn_value(match.group(1))
            if value is not None:
                numbers.append(value)
    return numbers


def _gap_articles(paragraphs, kinds=None):
    """算出一份文件裡條號斷掉的地方，用來判斷斷號是不是本來就有。

    含頭：第一條就不見（整份從第三條開始）也是斷號。原本只用
    zip(numbers, numbers[1:]) 兩兩相比，序列的第一個數字永遠沒有「前一個」可比，
    「刪掉第一條」——最常見的刪除之一——因此在新舊兩邊都算不出來：
    新版報不出跳號，舊版也給不出「本來就這樣」的對照。
    尾巴不在這裡：一份文件自己看不出來最後一條之後還該不該有下一條，
    那要跟舊版的最大條號比，見 _check_tail。
    """
    numbers = _article_numbers(paragraphs, kinds)
    missing = set()
    if numbers and numbers[0] > 1:
        missing.update(range(1, numbers[0]))
    for previous, current in zip(numbers, numbers[1:]):
        if current > previous + 1:
            missing.update(range(previous + 1, current))
    return missing


def _check_tail(sequence, old_paragraphs=None, old_kinds=None):
    """含尾：舊版的最後一條在新版不見了。

    這要有舊版才看得出來——一份文件停在第十七條，光看它自己完全正常，
    只有跟舊版的第十八條一比才知道最後一條被整條刪掉了。
    刪最後一條跟刪中間一條同樣要保留條號註記「（刪除）」，否則別的規章引用
    「第十八條」會指到不存在的地方。
    """
    if not old_paragraphs:
        return []
    old_numbers = [n for n in _article_numbers(old_paragraphs, old_kinds)]
    new_numbers = [main for main, sub, _, _, _, _ in sequence
                   if main is not None and not sub]
    if not old_numbers or not new_numbers:
        return []
    old_max, new_max = max(old_numbers), max(new_numbers)
    if old_max <= new_max:
        return []
    missing = ["第%s條" % _int_to_cn(n) for n in range(new_max + 1, old_max + 1)]
    last_index = max(idx for main, sub, _, idx, _, _ in sequence
                     if main == new_max and not sub)
    return [finding(
        MEDIUM, "條號跳號",
        "舊版有 第%s條，新版最後一條是 第%s條，末尾缺 %s"
        % (_int_to_cn(old_max), _int_to_cn(new_max), "、".join(missing)),
        index=last_index, ref="第%s條" % _int_to_cn(new_max),
        action="若為本次刪除，依慣例應保留條號並註記「（刪除）」")]


def _check_sequence(sequence, existing_gaps=frozenset()):
    """檢查條號順序：跳號、「之一」跑到本條前面。

    含頭：以前 previous_main 起手是 None，第一條要等到第二條出現才開始比，
    「整份從第三條開始」（第一條、第二條被整條刪掉）一則都不會報。
    現在序列的第一個主條號一出現就先跟「第一條」對一次。
    """
    findings = []
    previous_main = None

    for main, sub, label, idx, text, is_deleted_mark in sequence:
        if main is None:
            continue

        if sub and previous_main != main:
            # 「第五條之一」前面必須先有「第五條」，否則就是接錯位置
            findings.append(finding(
                HIGH, "條號順序",
                "%s 出現在 第%s條 之前或找不到本條" % (label, main),
                index=idx, ref=label, quote=text[:40],
                action="「之一」的條文應緊接在本條之後"))

        if previous_main is None and not sub and main > 1:
            # 整份的第一個主條號就不是第一條：前面那幾條被整條刪掉了。
            gap_numbers = list(range(1, main))
            missing = ["第%s條" % _int_to_cn(n) for n in gap_numbers]
            pre_existing = existing_gaps and set(gap_numbers) <= existing_gaps
            findings.append(finding(
                LOW if pre_existing else MEDIUM, "條號跳號",
                "全文從 %s 開始，前面缺 %s%s"
                % (label, "、".join(missing),
                   "（舊版即已如此，非本次修訂造成）" if pre_existing else ""),
                index=idx, ref=label, quote=text[:40],
                action="舊版即有，本次可不處理" if pre_existing
                       else "若為本次刪除，依慣例應保留條號並註記「（刪除）」"))

        if previous_main is not None and not sub and main > previous_main + 1:
            gap_numbers = list(range(previous_main + 1, main))
            missing = ["第%s條" % _int_to_cn(n) for n in gap_numbers]
            # 舊版就已經斷在同樣的位置，代表是上一版留下來的，不是這次造成的。
            # 這種每次修訂都報一次只會變成雜訊，降級但不隱藏。
            pre_existing = existing_gaps and set(gap_numbers) <= existing_gaps
            findings.append(finding(
                LOW if pre_existing else MEDIUM, "條號跳號",
                "%s 之後直接跳到 %s，中間缺 %s%s"
                % ("第%s條" % _int_to_cn(previous_main), label, "、".join(missing),
                   "（舊版即已如此，非本次修訂造成）" if pre_existing else ""),
                index=idx, ref=label,
                action="舊版即有，本次可不處理" if pre_existing
                       else "若為本次刪除，依慣例應保留條號並註記「（刪除）」"))

        if not sub:
            previous_main = main
    return findings


def _int_to_cn(value):
    """整數轉中文數字，支援到 999。"""
    digits = "零一二三四五六七八九"
    if value < 10:
        return digits[value]
    if value < 20:
        return "十" + (digits[value - 10] if value % 10 else "")
    if value < 100:
        tens, ones = divmod(value, 10)
        return digits[tens] + "十" + (digits[ones] if ones else "")
    hundreds, rest = divmod(value, 100)
    text = digits[hundreds] + "百"
    if rest == 0:
        return text
    if rest < 10:
        return text + "零" + digits[rest]
    return text + _int_to_cn(rest)


# ---------------------------------------------------------------------------
# 5. 定義用語
# ---------------------------------------------------------------------------

# 定義的樣式跟同本「舊值搜尋」共用 _common.DEFINED_TERM_RES（說明見那裡）。以前這裡只認
# 「本要點所稱X，指」「「X」，指」兩種：最常見的定義清單「本要點用詞，定義如下：一、網路投保：指…」
# 整個認不得，「本手冊所稱」「本作業要點所稱」也不認，改了定義都不報連動。


# 用到這個詞的段落要進連帶決定表的那兩種（來源「定義連動」；decision_table.add_definitions）
DEFINITION_LINK_CHECKS = ("定義變更連動", "定義刪除")


def _definition_terms(text, in_list=False):
    """這一段定義了哪些詞：[(詞, 起, 訖)]，照位置排好。

    幾個樣式可能抓到同一處，先抓到的為準、重疊的不再算一次。
    in_list：這一段在「用詞，定義如下」底下，用逗號的那種款（「一、網路投保，指」）也算。"""
    patterns = tuple(DEFINED_TERM_RES) + ((DEFINED_LIST_ITEM_RE,) if in_list else ())
    terms = []
    for pattern in patterns:
        for match in pattern.finditer(text or ""):
            start, end = match.span(1)
            if any(start < b and a < end for _, a, b in terms):
                continue
            terms.append((match.group(1), start, end))
    return sorted(terms, key=lambda t: t[1])


def _definitions_in(paragraphs):
    """全文的定義：{詞: (段次, 段落全文, 這個詞的定義文字)}，同一個詞以第一次定義的為準。

    定義文字是從這個詞到這句話結束（下一個被定義的詞之前，見 _definition_end），正規化、去空白。
    拿它比新舊版，不拿整段比：一段裡定義好幾個詞時（「定義如下：一、A：指…。二、B：指…」寫在
    同一段），只改了 A 的定義不該連 B 一起報；定義那一條改的是別句話，也不算定義改了。"""
    found = {}
    in_list = False
    for idx, text in enumerate(paragraphs, 1):
        text = text or ""
        if DEFINITION_LIST_HEADER_RE.search(text):
            in_list = True
        elif not DEFINITION_LIST_ITEM_START_RE.match(text):
            in_list = False
        terms = _definition_terms(text, in_list)
        for k, (term, start, _) in enumerate(terms):
            stop = terms[k + 1][1] if k + 1 < len(terms) else len(text)
            stop = _definition_end(text, start, stop)
            body = re.sub(r"\s+", "", normalize_for_compare(text[start:stop]))
            found.setdefault(term, (idx, text, body))
    return found


# 定義那句話後面接著的但書、除外也是定義的一部分（「…之人員。但不包括…」），句號不能在那裡斷
_DEFINITION_TAIL_RE = re.compile(r"\s*(?:但|惟|不包括|不含|並包括|包括)")


def _definition_end(text, start, stop):
    """定義文字在哪裡結束：start 之後第一個句號（後面接但書、除外的再往下一句），最遠到 stop。"""
    pos = start
    while True:
        end = text.find("。", pos, stop)
        if end < 0:
            return stop
        if not _DEFINITION_TAIL_RE.match(text, end + 1):
            return end + 1
        pos = end + 1


def _old_paragraphs(results):
    """比對結果裡的舊版段落，照舊版段次排（有一筆沒有段次就照出現順序）。"""
    olds = [r for r in results or [] if r.get("old_text") is not None]
    if all(r.get("old_index") for r in olds):
        olds = sorted(olds, key=lambda r: r["old_index"])
    return [r["old_text"] for r in olds]


def check_definitions(paragraphs, results, kinds=None):
    """
    定義用語的三種毛病：

    1. 定義了卻全文沒用到 —— 通常是條文刪掉了、定義忘了刪
    2. 定義本身被改了（含這次才新增的定義）—— 用到這個詞的所有條文都要重看一次，
       因為它們的意思跟著變了
    3. 定義被刪了，這個詞別處還在用 —— 那些條文的意思變得沒有依據（要有舊版才查得到）

    第二種是實務上最常出包的：改了「網路投保」的定義，卻只想到要改網路投保章，
    忘了核保章、理賠章也有十幾條寫著「網路投保」。
    """
    findings = []
    contexts = build_hierarchy(paragraphs, kinds)
    definitions = _definitions_in(paragraphs)
    old_definitions = _definitions_in(_old_paragraphs(results)) if results else {}

    # 這次有動到的段落（修改、新增）。整條改寫（比對判成一刪一增）也算定義被改了（B8）：
    # 跟責任用語、數值同一份 _with_rewrites
    touched = {r["new_text"] for r in _with_rewrites(results)
               if r["type"] in ("modified", "added") and r.get("new_text")}
    added = {r["new_text"] for r in results or [] if r["type"] == "added" and r.get("new_text")}

    for term, (def_index, def_text, body) in definitions.items():
        users = [idx for idx, text in enumerate(paragraphs, 1)
                 if idx != def_index and term in text]

        if not users:
            findings.append(finding(
                LOW, "贅定義", "定義了「%s」，但全文其他地方沒有用到" % term,
                index=def_index, ref=contexts[def_index - 1]["ref"],
                quote=def_text[:44],
                action="確認是否為條文刪除後遺留的定義"))
            continue

        old = old_definitions.get(term)
        if def_text not in touched or (old and old[2] == body):
            continue          # 定義那一段沒動，或動的是同一段裡別的字、別的詞的定義
        if not old and all(paragraphs[i - 1] in added for i in users):
            continue          # 這次才定義的詞只用在這次新增的條文裡：沒有舊條文要重看

        refs = [contexts[i - 1]["ref"] or ("第%d段" % i) for i in users]
        findings.append(finding(
            HIGH, "定義變更連動",
            "「%s」的定義被修改，全文另有 %d 處用到這個詞：%s"
            % (term, len(users), "、".join(refs[:12])
               + ("…" if len(refs) > 12 else "")),
            index=def_index, ref=contexts[def_index - 1]["ref"],
            quote=def_text[:44],
            action="逐條確認這些條文在新定義下是否仍然成立"))
        # 用到這個詞的段次：連帶決定表要一段一列列出來（來源「定義連動」），
        # 以前只在這一列的說明裡寫前 12 個條號，決定表上一列都沒有
        findings[-1].update(term=term, users=list(users))

    # 定義被刪了、詞還在用：以前只看新版，刪掉的定義看不到，這一種一筆都不報。
    # 跟定義變更連動一樣帶 term、users，用到這個詞的段落進連帶決定表（來源「定義連動」）
    for term, (_, old_text, _) in old_definitions.items():
        if term in definitions:
            continue
        users = [idx for idx, text in enumerate(paragraphs, 1) if term in text]
        if not users:
            continue
        here = next((r for r in results if r.get("old_text") == old_text), None) or {}
        new_index = here.get("new_index") if here.get("new_text") is not None else None
        if new_index and new_index <= len(contexts):
            where = contexts[new_index - 1]["ref"] or ("第%d段" % new_index)
        else:
            new_index = None
            where = "%s（舊版）" % (extract_article_no(old_text)
                                  or ("第%d段" % here["old_index"] if here.get("old_index") else "已刪除的條文"))
        refs = [contexts[i - 1]["ref"] or ("第%d段" % i) for i in users]
        findings.append(finding(
            HIGH, "定義刪除",
            "「%s」的定義被刪除，但全文仍有 %d 處用到這個詞：%s"
            % (term, len(users), "、".join(refs[:12]) + ("…" if len(refs) > 12 else "")),
            index=new_index, ref=where, quote="舊版：%s" % clip(old_text, 44),
            action="確認這些條文是否還需要這個定義（保留定義），或一併改用別的用詞"))
        findings[-1].update(term=term, users=list(users))
    return findings


# ---------------------------------------------------------------------------
# 6. 外部法規引用
# ---------------------------------------------------------------------------

# 「第X條（之Y）」或「第X點」：外部的要點、注意事項（本行內規幾乎都是）以「點」編號，
# 以前只認「條」，那一類整個漏掉。名稱上限 40 字，理由見 _common._LAW_NAME。
# 名稱跟條號中間可以隔引號：「保險業招攬及核保理賠辦法」第六條（以前整筆漏掉）。
_EXTERNAL_RE = re.compile(
    r"([一-鿿]{2,40}?(?:法|條例|辦法|準則|規則|細則|要點|規範|注意事項|自律規範))"
    r"[」』》】〕）)\"'\s]*"
    r"(第\s*[%s\d]+\s*(?:條(?:\s*之\s*[%s\d]+)?|點))" % (CN, CN))
# 同一部法規的第二個以後的條號：「保險法第一百四十六條、第一百四十六條之一」
# 「…第十五條第一項及第十八條」。以前只抓到第一個。只收「條」「點」：
# 「第一項及第二項」是同一條裡的項，不是另一處引用。
_EXTERNAL_MORE_RE = re.compile(
    r"(?:\s*第\s*[%s\d]+\s*[項款目])*\s*[、及或與和至]\s*"
    r"(第\s*[%s\d]+\s*(?:條(?:\s*之\s*[%s\d]+)?|點))" % (CN, CN, CN))
# 「依保險法第一百四十六條及同法第一百四十六條之一」：「同法」「該法」指前面那一部，
# 以前被當成一部叫「同法」的法規列進清單。
_SAME_LAW_RE = re.compile(r"^[同該](?:法|條例|辦法|準則|規則|細則|要點|規範)$")

# 法規名稱前面常常黏著動詞或連接詞：「本要點依保險法第X條」「及金融消費者保護法第Y條」。
# 不切掉的話會抓出「本要點依保險法」，還會因為開頭是「本要點」而被誤判成自我引用整筆漏掉。
#
# 剝法本身搬到 _common.clean_law_name，跟 renumber 的交叉引用判定共用同一份。
# 兩邊各寫一份的話，同一句話在條文檢查報告裡被當成「保險法」、在交叉引用檢查裡
# 卻被當成本文自己的引用，兩張產出自相矛盾。


def _clean_law_name(name):
    """把法規名稱前面黏到的動詞、連接詞剝掉。剝完不像法規名稱就回空字串。

    以前剝不出來會退回原樣，結果「其處理方法第三條」這種日常用語也被列進
    外部法規清單，叫人去查一部不存在的法規。
    """
    return clean_law_name(name)


_SELF_NAMES = ("本要點", "本辦法", "本準則", "本規則", "本規定", "本作業程序",
               "本法", "本條例")


def _is_self_name(raw, law):
    """這筆是不是這份文件自己。以前只拿剝完的名稱跟 _SELF_NAMES 比全等，
    「依本作業要點第五條」「本管理辦法」被當成外部法規列進清單（審查 X18）。
    原始抓到的那一段要一起看：剝字會把開頭的「本」切掉，只看剝完的就認不出來。
    規則跟 renumber 的交叉引用判定共用 _common.is_own_law_name。"""
    return law in _SELF_NAMES or is_own_law_name(raw) or is_own_law_name(law)


def external_mentions(paragraphs):
    """全文每一處外部規章引用：[{段次, 名稱, 條號, 引用, 起, 訖}]，照段次與位置排好。

    兩種來源：
        一、長得像法規全銜、後面接「第X條（之Y）」或「第X點」的（字面規則，登錄表的名字優先）
        二、登錄表（tables/S8_外部規章表.csv）裡的名字，後面沒寫條號也算——
            「依個人資料保護法規定辦理」是最常見的母法引用，以前因為沒有條號整個不列
    條文檢查報告的外部法規清單與 AI 外部引用檢查（review_pack）共用這一份。"""
    registry = external_registry()
    found = []
    for idx, text in enumerate(paragraphs, 1):
        spans = []

        def add(law, number, start, end):
            spans.append((start, end))
            found.append({"段次": idx, "名稱": law, "條號": number, "引用": law + number,
                          "起": start, "訖": end})
            # 後面接著的第二個、第三個條號也是這一部的（起訖只框那個條號）
            while True:
                more = _EXTERNAL_MORE_RE.match(text, end)
                if not more:
                    break
                end = more.end()
                spans.append((more.start(1), end))
                number = re.sub(r"\s+", "", more.group(1))
                found.append({"段次": idx, "名稱": law, "條號": number, "引用": law + number,
                              "起": more.start(1), "訖": end})

        for match in _EXTERNAL_RE.finditer(text):
            if any(a <= match.start(2) < b for a, b in spans):
                continue          # 已經當成前一部的第二個條號收過
            law = _clean_law_name(match.group(1))
            if not law or _is_self_name(match.group(1), law):
                continue
            number = re.sub(r"\s+", "", match.group(2))
            start = max(match.start(1), match.end(1) - len(law))
            if _SAME_LAW_RE.match(law):
                previous = [m for m in found if (m["段次"], m["起"]) < (idx, start)]
                if not previous:
                    continue      # 前面沒有法規可以指，不猜
                law = max(previous, key=lambda m: (m["段次"], m["起"]))["名稱"]
            add(law, number, start, match.end())
        for name, _ in registry:
            pos = 0
            while True:
                i = text.find(name, pos)
                if i < 0:
                    break
                pos = i + len(name)
                if any(a <= i < b or a < pos <= b for a, b in spans):
                    continue          # 已經連條號一起抓到，或是更長的登錄名稱的一部分
                if text[max(0, i - 1):i] == "本":
                    continue
                # 「依全民健康保險法規定」：登錄的「保險法」是更長一部法的結尾，用長的（最長比對）
                law = clean_law_name(text[max(0, i - 40):pos]) or name
                start = pos - len(law) if law.endswith(name) and len(law) > len(name) else i
                law = text[start:pos]
                spans.append((start, pos))
                found.append({"段次": idx, "名稱": law, "條號": "", "引用": law + "（未指明條號）",
                              "起": start, "訖": pos})
    found.sort(key=lambda m: (m["段次"], m["起"]))
    return found


def check_external_refs(paragraphs, kinds=None):
    """
    抽出所有外部法規的引用，列成清單。

    程式判斷不了「保險法第一百四十八條之三有沒有修正過」——那要查法規資料庫。
    但程式可以把該查的清單一次列齊，避免人工翻 50 頁去找。
    內規因母法修正而需連動修正，是最常見的漏改來源之一。
    """
    contexts = build_hierarchy(paragraphs, kinds)
    seen = {}

    for mention in external_mentions(paragraphs):
        idx = mention["段次"]
        seen.setdefault(mention["引用"], []).append(
            (idx, contexts[idx - 1]["ref"] or ("第%d段" % idx)))

    if not seen:
        return []

    findings = []
    for citation, places in sorted(seen.items()):
        refs = "、".join(ref for _, ref in places[:8])
        findings.append(finding(
            MEDIUM, "外部法規引用",
            "引用 %s（%d 處：%s%s）"
            % (citation, len(places), refs, "…" if len(places) > 8 else ""),
            index=places[0][0], ref=places[0][1], quote=citation,
            action="查證該法條現行條文，確認引用的條號與內容仍然正確"))
    return findings


# ---------------------------------------------------------------------------
# 7. 待補殘留
# ---------------------------------------------------------------------------

# 佔位用的記號：○（U+25CB）、〇（U+3007，也是國字的「零」）、Ｏ／O、Ｘ／X、×（乘號）。
# 以前只認 TBD、XXX、待補這幾個字，草稿最常見的「中華民國○○年○月○日」「新臺幣XX萬元」
# 「××處」都認不得，施行日期改成○○也印「通過」。
_PH_MARKS = "○〇ＯＸｘ×OXx"
_PLACEHOLDER_RE = re.compile(
    r"(TBD|TODO|待補(?!正)|待確認|待議|待訂|\?\?\?|？{2,}|【待[^】]*】"
    # 「暫定保險費」是正式用語，只有括起來的「（暫定）」才是草稿記號
    r"|[（(【〔\[]\s*暫定\s*[）)】〕\]]"
    # 日期整串算一筆：「中華民國○○年○月○日」只報一次，不拆成三筆
    # 前面是國字或數字的不算：「一〇〇年」是民國一百年
    r"|(?<![%(cn)s\d])[%(m)s]{1,4}\s*年\s*[%(m)s]{1,2}\s*月(?:\s*[%(m)s]{1,2}\s*日)?"
    # 連續兩個以上的佔位記號：○○單位、××處、XX萬元、XXX。英文字母夾著的不算（XXL）
    r"|(?<![A-Za-z%(cn)s\d])(?:[○〇]{2,}|[ＯＸｘ×]{2,}|[OXx]{2,}(?![A-Za-z]))"
    # 單一個○接在條號、數量前後：第○條、○元、○日
    r"|第\s*○+\s*[條項款點]|○(?=[年月日條項款點元萬千百人份次])"
    r")" % {"cn": CN, "m": _PH_MARKS},
    re.IGNORECASE)
# 底線空格「＿＿＿」：多半是待填的空白，但附表、表單本來就留空格給人填，所以只報【中】、
# 表格儲存格裡的不報。英數字夾著的（檔名、代碼）不算。
_BLANK_RE = re.compile(r"(?<![A-Za-z0-9])[＿_]{2,}(?![A-Za-z0-9])")


def check_placeholders(paragraphs, kinds=None):
    """草稿階段的佔位文字沒清乾淨就送出去，是很現實的意外。
    同一段同一個佔位字只報一次（「○○部門…○○科」不報兩筆）。"""
    contexts = build_hierarchy(paragraphs, kinds)
    findings = []
    for idx, text in enumerate(paragraphs, 1):
        seen = set()
        for match in _PLACEHOLDER_RE.finditer(text):
            token = match.group(0)
            if token in seen:
                continue
            seen.add(token)
            findings.append(finding(
                HIGH, "待補殘留", "條文裡還留著「%s」" % token,
                index=idx, ref=contexts[idx - 1]["ref"], quote=text[:44],
                action="送出前務必清除或補實"))
        if kinds and idx <= len(kinds) and kinds[idx - 1] == "cell":
            continue
        blank = _BLANK_RE.search(text)
        if blank:
            findings.append(finding(
                MEDIUM, "待補殘留", "條文裡有底線空格「%s」" % blank.group(0),
                index=idx, ref=contexts[idx - 1]["ref"], quote=text[:44],
                action="是待補的內容就補實；是表單留給人填的空格可略過"))
    return findings


# ---------------------------------------------------------------------------
# 8. 格式一致性
# ---------------------------------------------------------------------------

def check_format_consistency(paragraphs):
    """
    全形半形混用、條號後分隔符不一致。

    這種問題不影響法律效力，但法制作業複核時會被退件重打，
    而且在 50 頁的文件裡靠肉眼找非常花時間。
    """
    findings = []

    full_width = sum(1 for p in paragraphs if re.match(r"^（", p))
    half_width = sum(1 for p in paragraphs if re.match(r"^\(", p))
    if full_width and half_width:
        findings.append(finding(
            LOW, "格式一致性",
            "目的括號全形半形混用：全形（）%d 段、半形() %d 段"
            % (full_width, half_width),
            action="統一為其中一種，通常內規慣用全形"))

    separators = {}
    for text in paragraphs:
        match = re.match(r"^第[%s\d]+條(?:之[%s\d]+)?(.)" % (CN, CN), text)
        if match:
            char = match.group(1)
            name = {" ": "半形空白", "　": "全形空白"}.get(char, "無空白")
            if char not in (" ", "　"):
                name = "無空白"
            separators[name] = separators.get(name, 0) + 1

    if len(separators) > 1:
        detail = "、".join("%s %d 條" % (k, v) for k, v in sorted(separators.items()))
        findings.append(finding(
            LOW, "格式一致性", "條號後的分隔方式不一致：%s" % detail,
            action="統一條號與條文之間的分隔（內規慣用全形空白）"))

    return findings


# ---------------------------------------------------------------------------
# 9. 用語混用
# ---------------------------------------------------------------------------

# 同一份內規裡混用同義詞，複核時會被要求統一。這裡放保險/金融內規常見的幾組，
# 各單位用語習慣不同，可以用 --terms 指定自己的對照表覆蓋。
#
# 每一組的「第一個」就是建議統一的用字，順序有意義，不要隨意調換。
# 不採用「哪個出現次數多就建議哪個」——法制作業慣用「不得」而非「不可」、
# 「應」而非「須」，跟出現頻率無關。實測就踩過這個坑：測試文本裡「不可竄改」
# 出現一百多次，程式因此建議把「不得」全部改成「不可」，方向完全相反。
DEFAULT_TERM_GROUPS = [
    ["要保人", "投保人"],
    ["被保險人", "受保人"],
    ["業務人員", "業務員", "招攬人員"],
    ["保險費", "保費"],
    ["保險契約", "保險合約"],
    ["本公司", "本行", "本銀行"],
    ["訂定", "制定"],
    ["應", "須"],
    ["得", "可"],
    ["不得", "不可"],
]


# 含著短詞的否定詞：「不得」裡有「得」、「不可」裡有「可」。數「得／可」時要先遮掉，
# 不然一份只用「得」與「不得」、「可」只出現在「不可」裡的內規，會被報成「得／可」混用。
_NEGATED_TERMS = ("不得", "不可")


def _count_term(whole, term, containers):
    """term 在全文出現幾次，不算長詞（containers 裡含著 term 的詞）裡的那幾次。

    先把長詞遮掉再數，不用「短詞次數減長詞次數」：幾個長詞彼此重疊時減法會扣過頭。
    """
    longer = sorted((c for c in containers if len(c) > len(term) and term in c),
                    key=len, reverse=True)
    for word in longer:
        whole = whole.replace(word, "○" * len(word))
    return whole.count(term)


def check_term_consistency(paragraphs, groups=None):
    """同一組同義詞在全文混著用，就列出來讓人決定統一成哪一個。"""
    groups = groups or DEFAULT_TERM_GROUPS
    # 同樣要遮掉「不可竄改」「應用程式」「取得」這類複合詞。
    # 不遮的話，測試文本裡「不可竄改」出現一百多次，程式會反過來
    # 建議把「不得」統一成「不可」。
    # 法規全銜也一起遮：一份用「業務人員」的內規只要引用到「保險業務員管理規則」，
    # 全銜裡那三個字就被算成混用，每跑一次固定誤報一筆（實測 no 26）。
    whole = mask_decoys("\n".join(paragraphs))
    findings = []
    # 「不得」會被「得」的計數涵蓋，要先遮掉才不會誤報。以前是在「得」那一組裡找
    # counts["不得"] 來扣——可是「不得」在另一組，那一組的 counts 裡根本沒有它，
    # 扣的那一步永遠不會執行，「得」與「不得」並用就固定誤報一筆「得／可」混用。
    containers = set(_NEGATED_TERMS)
    for group in groups:
        containers.update(group)

    for group in groups:
        counts = {term: _count_term(whole, term, containers) for term in group}
        used = {term: n for term, n in counts.items() if n}
        if len(used) < 2:
            continue

        detail = "、".join("%s %d 次" % (t, n)
                           for t, n in sorted(used.items(), key=lambda x: -x[1]))
        preferred = next(t for t in group if t in used)
        findings.append(finding(
            LOW, "用語混用", "%s（建議統一為「%s」）" % (detail, preferred),
            action="確認是否為有意區分；若無，統一用語"))
    return findings


# ---------------------------------------------------------------------------
# 10. 附表引用
# ---------------------------------------------------------------------------

# 號碼要整串吃完（(?![數字])），後面接量詞的是份數不是編號：「應檢具申請書及附件二份」
# 是「附件、兩份」，以前被當成引用「附件二」而報找不到本體（實測 T04）。
_ATTACHMENT_REF_RE = re.compile(
    r"(附表|附件|附錄)\s*([%s\d０-９]+)(?![%s\d０-９])(?!\s*[份張頁冊本套式紙])" % (CN, CN))


def _attachment_key(kind, number):
    """「附件1」「附件一」「附件１」是同一份：號碼換成數字比（讀不出來就照字面）。"""
    value = cn_to_int(number)
    return (kind, value if value is not None else number)


def check_attachments(paragraphs, kinds=None):
    """文中寫「詳如附表一」，但全文找不到附表一——附件漏附是很常見的疏漏。"""
    contexts = build_hierarchy(paragraphs, kinds)
    referenced = {}
    defined = set()

    for idx, text in enumerate(paragraphs, 1):
        for match in _ATTACHMENT_REF_RE.finditer(text):
            name = "%s%s" % (match.group(1), match.group(2))
            key = _attachment_key(match.group(1), match.group(2))
            # 段落開頭就是「附表一」，視為附表本體而非引用
            if match.start() == 0:
                defined.add(key)
            else:
                referenced.setdefault(key, (name, []))[1].append(idx)

    findings = []
    for key, (name, places) in sorted(referenced.items(), key=lambda item: item[1][0]):
        if key in defined:
            continue
        findings.append(finding(
            MEDIUM, "附表引用",
            "條文提到「%s」，但全文找不到該附表的本體（%d 處引用）" % (name, len(places)),
            index=places[0], ref=contexts[places[0] - 1]["ref"],
            action="確認附表是否漏附，或引用名稱是否誤植"))
    return findings


# ---------------------------------------------------------------------------
# 輸出
# ---------------------------------------------------------------------------

SEVERITY_ORDER = {HIGH: 0, MEDIUM: 1, LOW: 2}

# 交給 AI 查證的發現：高風險的全部，加上施行日期（它是「中」，但改了期限、義務卻沒改施行日
# 是送簽前最常被退的）。AI 查得到答案的自動結案，查不到的才進 填寫表單/人工確認.csv。
AI_REVIEW_EXTRA = ("施行日期",)
AI_REVIEW_FILE = "條文檢查待查證.json"


def ai_review_findings(findings):
    """要交給 AI 查證的那幾筆（見 AI_REVIEW_EXTRA）。"""
    return [item for item in findings
            if item["severity"] == HIGH or item["check"] in AI_REVIEW_EXTRA]

# 十項檢查，以及每一項會吐出哪些「檢查項目」字串。
# 報告要逐項講「通過／未檢查／有問題」，就得分得出「這一項沒有發現」與
# 「這一項根本沒跑」——沒有這張表就只能印一句「都沒有發現問題」，而那句話在
# 沒給舊版時是假的：責任用語、數值期間、施行日期三項根本沒有檢查。
CHECK_ITEMS = [
    # 但書增刪、門檻用語變更是後來加的，掛在最相近的那一項底下：它們跟責任用語、數值一樣
    # 要有舊版才比得出來，沒給舊版時跟著印「未檢查」；另立兩項的話「十項檢查」的說法
    # 散在報告、說明文件、AI 清單各處，改不齊反而誤導。
    ("責任用語變更", ("責任用語變更", "但書增刪")),
    ("數值期間變更", ("數值期間變更", "門檻用語變更")),
    ("施行日期", ("施行日期",)),
    ("條號健全性", ("條號重複", "空白條文", "條號順序", "條號跳號")),
    ("定義用語", ("贅定義",) + DEFINITION_LINK_CHECKS),
    ("外部法規引用", ("外部法規引用",)),
    ("待補殘留", ("待補殘留",)),
    ("格式一致性", ("格式一致性",)),
    ("用語混用", ("用語混用",)),
    ("附表引用", ("附表引用",)),
]

# 沒有給舊版時跑不了的項目與原因。rule_checks 單獨執行（沒有 --old）時傳給 report()。
# 定義用語也要列：沒有舊版時 check_definitions 只做得了「贅定義」那一半，
# 真正高風險的「定義變更連動」（改了定義，用到這個詞的條文全部要重看）做不了——
# 印「通過」等於說那一半也看過了。
NO_OLD_REASON = "沒有給舊版，比不出前後差異；請加 --old 舊版檔"
NO_OLD_DEFINITION_REASON = "沒有舊版，只做贅定義檢查，定義變更連動未檢查"
NO_OLD_SKIPPED = [("責任用語變更", NO_OLD_REASON),
                  ("數值期間變更", NO_OLD_REASON),
                  ("施行日期", NO_OLD_REASON),
                  ("定義用語", NO_OLD_DEFINITION_REASON)]


def _tri_state(findings, skipped):
    """每一項的三態：(項目, "通過"／"未檢查（原因）"／"有問題，共 N 項")。"""
    reasons = dict(skipped or [])
    counts = {}
    for item in findings:
        counts[item["check"]] = counts.get(item["check"], 0) + 1
    rows = []
    for name, kinds in CHECK_ITEMS:
        total = sum(counts.get(kind, 0) for kind in kinds)
        if name in reasons:
            # 只做了一半的項目（例：沒有舊版時的定義用語）還是可能有發現，
            # 那幾筆要講出來，但整項的結論仍然是「未檢查」。
            extra = "；另發現 %d 項" % total if total else ""
            rows.append((name, "未檢查（%s）%s" % (reasons[name], extra)))
            continue
        rows.append((name, "有問題，共 %d 項" % total if total else "通過"))
    return rows


def report(findings, skipped=None):
    """依嚴重程度分級印出，並逐項給「通過／未檢查／有問題」的結論。

    skipped：[(檢查項目, 沒檢查的原因), ...]。沒跑到的項目一律印「未檢查」並說明
    原因——印「都沒有發現問題」等於告訴使用者程式看過了，那種假的安心比不檢查更危險。
    """
    print("\n" + "=" * 62)
    print("條文品質與風險檢查")
    print("=" * 62)

    print("\n【十項檢查結論】")
    for name, state in _tri_state(findings, skipped):
        print("  %s：%s" % (name, state))

    if not findings:
        if skipped:
            print("\n有檢查的項目都沒有發現問題；上面標「未檢查」的項目本次沒有跑到。")
        else:
            print("\n十項檢查全部做過，沒有發現問題。")
        print("=" * 62)
        return

    grouped = {}
    for item in findings:
        grouped.setdefault(item["severity"], []).append(item)

    labels = {HIGH: "高（送出前一定要處理或確認）",
              MEDIUM: "中（建議確認）",
              LOW: "低（格式與用語，不影響效力）"}

    for severity in (HIGH, MEDIUM, LOW):
        items = grouped.get(severity)
        if not items:
            continue
        print("\n【%s】共 %d 項" % (labels[severity], len(items)))
        for item in items:
            location = item["ref"] or (
                "第%d段" % item["index"] if item["index"] else "全文")
            tail = ("（%s）" % item["change_type"]
                    if item.get("change_type") in (REWRITE_LABEL, REWRITE_DIFF_NO_LABEL)
                    else "")
            print("  ● [%s] %s%s" % (item["check"], location, tail))
            print("      %s" % item["detail"])
            if item["quote"]:
                print("      %s" % quote_line(item["quote"]))
            if item["action"]:
                print("      建議：%s" % item["action"])

    print("\n" + "-" * 62)
    counts = {s: len(grouped.get(s, [])) for s in (HIGH, MEDIUM, LOW)}
    print("合計 %d 項（高 %d、中 %d、低 %d）"
          % (len(findings), counts[HIGH], counts[MEDIUM], counts[LOW]))
    print("提醒：這十項是規則明確、程式查得出來的部分。條文之間的邏輯矛盾、")
    print("      是否逾越母法授權，程式查不到，仍需人工或 LLM 複核。")
    print("=" * 62)


CSV_COLUMNS = ["嚴重程度", "檢查項目", "位置", "段次", "說明", "相關原文",
               "建議處理", "修改類型", "處理情形（人工填寫）"]

# 提醒列的建議處理欄一律寫這句：提醒不是條文的毛病，是「這次執行發生了什麼事」。
NOTICE_ACTION = "確認這則提醒會不會影響本次比對結果，再決定要不要處理"


def report_rows(findings, notices=None):
    """條文檢查報告的資料列。xlsx 版與 csv 退路共用一份，兩張表才不會漂開。"""
    rows = []
    for item in sorted(findings, key=lambda x: SEVERITY_ORDER[x["severity"]]):
        rows.append([
            item["severity"], item["check"],
            item["ref"] or "", item["index"] or "",
            item["detail"], item["quote"], item["action"],
            item.get("change_type") or "", "",
        ])
    for entry in (notices or []):
        rows.append([
            entry.get("等級") or nt.REMINDER, entry.get("來源") or "執行提醒",
            "", "", entry.get("文字") or "", "", NOTICE_ACTION, "", "",
        ])
    return rows


def write_report_table(findings, base_path, notices=None, path_for=None):
    """寫條文檢查報告（.xlsx；寫不出來才退 .csv）。base_path 不帶副檔名。

    notices 是這次執行累積的提醒，以「提醒」等級附在最後。
    為什麼提醒也要進這張表：畫面上的提醒會被後面的輸出洗掉，而這張表是複核時
    一定會打開的檔案。提醒.txt 是完整留底，這裡是「順手就會看到」的那一份。

    回傳實際寫出的路徑清單。
    """
    written = xw.write_tables_or_csv(
        base_path, [("條文檢查報告", CSV_COLUMNS, report_rows(findings, notices))],
        source="Step 1.6 檢查報告", path_for=path_for)
    for path in written:
        # display_path：走 AtomicWrites 時收到的是「正式路徑 + .tmp」（見 fuzzy 同一段）
        print("\n已產生檢查報告：%s" % display_path(path))
    return written


def main():
    setup_console()
    parser = argparse.ArgumentParser(description="Step 1.6：條文品質與風險檢查")
    parser.add_argument("regulation_file", help="新版內規檔案")
    parser.add_argument("--old", default=None,
                        help="舊版檔案；有給才能做責任用語、數值變更、施行日期三項檢查")
    parser.add_argument("--terms", default=None,
                        help="自訂用語對照表（JSON，格式為二維陣列）")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    print("正在讀取：%s" % args.regulation_file)
    paragraphs, kinds = read_paragraphs_with_kinds(args.regulation_file)
    print("全文共 %d 段。" % len(paragraphs))

    groups = load_term_groups(args.terms, DEFAULT_TERM_GROUPS)

    old_paragraphs, old_kinds = (read_paragraphs_with_kinds(args.old) if args.old
                                 else (None, None))

    findings = []
    skipped = []
    findings += check_article_integrity(paragraphs, old_paragraphs, kinds, old_kinds)
    findings += check_external_refs(paragraphs, kinds)
    findings += check_placeholders(paragraphs, kinds)
    findings += check_format_consistency(paragraphs)
    findings += check_term_consistency(paragraphs, groups)
    findings += check_attachments(paragraphs, kinds)

    if args.old:
        print("正在比對舊版：%s" % args.old)
        results = diff_compare.compare_paragraphs(old_paragraphs, paragraphs,
                                                  old_kinds, kinds)
        findings += check_modal_changes(results)
        findings += check_proviso_changes(results)
        findings += check_numeric_changes(results)
        findings += check_threshold_changes(results)
        findings += check_effective_date(paragraphs, results)
        findings += check_definitions(paragraphs, results, kinds)
    else:
        findings += check_definitions(paragraphs, [], kinds)
        skipped = NO_OLD_SKIPPED
        nt.notice(nt.REMINDER,
                  "沒有給 --old，責任用語變更、數值期間變更、施行日期無法檢查，"
                  "定義用語也只做得了贅定義那一半；這幾項都是高風險項目，"
                  "強烈建議加上舊版一起跑", "Step 1.6")

    report(findings, skipped=skipped)
    collected = nt.collected()
    if findings or collected:
        base = os.path.splitext(
            resolve_output(args.outdir, args.prefix, "條文檢查報告.xlsx"))[0]
        write_report_table(findings, base, notices=collected)
    return findings


if __name__ == "__main__":
    main()
