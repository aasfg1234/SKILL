# -*- coding: utf-8 -*-
"""
Step 1：新舊內規精確文字比對工具

這支程式做的事情：
1. 讀取舊版跟新版兩份內規文件
2. 逐段比對，找出哪裡「新增」、哪裡「刪除」、哪裡「修改」
3. 輸出三份東西(後兩份需要 python-docx)：
   a. 修正對照表.xlsx  ── 條號、修改類型、原文、修改後文字、新版段次
                          (寫不出 xlsx 才退 修正對照表.csv)
   b. 標註版全文.docx  ── 修改後全文，紅字底線(新增)/刪除線(刪除)
                          (來源不是 .docx 時改出 標註版全文.txt，用【刪：…】【增：…】標)
   c. 修正對照表.docx  ── 正式對照表，橫式表格，末欄「修改依據／理由」：終比對時程式只草擬查得到
                          依據的（見 scripts/change_reasons.py），其餘寫「請補修正理由」

產出檔會依 _common.FILE_HOMES 分進 <輸出資料夾>/結果彙整、審閱文件、填寫表單、系統檔案 四格。

兩份 Word 檔的紅字只標「真正改動的那幾個字」，不是整段刪掉再整段加回來。

使用方式：
    python diff_compare.py 舊版.docx 新版.docx
    python diff_compare.py 舊版.txt 新版.txt --prefix 壽險內規 --outdir 輸出
    python diff_compare.py 舊版.docx 新版.docx --title "○○作業要點修正對照表"

對照表裡的「新版段次」欄位很重要，Step 2 的 fuzzy_duplicate_finder.py 會用到，
不要自己手動改動那一欄的數字。
"""

import argparse
import difflib
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, article_no_for, display_ref,
                     warn_if_group_markers_stripped, display_path,
                     build_hierarchy, diff_runs, format_scope,
                     load_table_format, strip_article_no, strip_numbering_prefix, resolve_output,
                     normalize_for_compare, normalize_for_diff, extract_article_no, COSMETIC_LABEL,
                     warn_if_versions_swapped, HAS_DOCX, cn_to_int,
                     sanitize_for_xml, XML_CLEANUP_NOTICE)
import docx_annotate
import notices as nt
import xlsx_writer as xw

# 兩段文字相似度要到這個程度，才會被判定成「同一條被改過」而不是「刪一條、加一條」。
# 0.45 是從實際保險內規條文抓出來的：改寫幅度大的同一條(例如「要保人應於保險費到期日前
# 繳納保險費」改寫成「保險費應由要保人於到期日前繳納」)相似度約 0.62，而不相干的兩條
# 通常低於 0.35，抓 0.45 剛好落在中間。
PAIR_THRESHOLD = 0.45

# 整條改寫：同一個缺口（前後錨點相同）裡的一刪一增，相似度不到 PAIR_THRESHOLD 也可能是同一條。
# 以前一律拆成「刪除＋新增」兩列，對照表上看起來像廢了一條、又訂了一條新的（審查第二批）。
# 這幾個數字是拿 532 組有標準答案的測資量的：真的改寫，去編號後相似度落在 0.27～0.39，
# 共同開頭（條號後的主詞＋條件，「分支機構於招攬保險商品時，」）都在 8 字以上；
# 同一位置換掉一款不相干的（「二、不得收受…」→「二、不得要求…」）相似度可到 0.36，
# 但最長的共同片段只有兩三個字。所以只看相似度分不開，要再看「主題詞」：
#   共同開頭 >= REWRITE_MIN_PREFIX 字，且相似度 >= REWRITE_MIN_SIM
#   或缺口裡只有這一刪一增、位置（條號）相同、相似度 >= REWRITE_SOLO_SIM，
#     而且有一段 >= REWRITE_MIN_BLOCK 字的共同片段（「，保全人員應」）
#   或新文只剩「（刪除）」而條號相同（法制慣例：刪除條文保留條號）
#   或改號又整條重寫（見 _renumbered_rewrite）：字面可以完全不像（qa-rules M13b 相似度 0.12），
#     所以不看相似度，只看位置——缺口裡就只有這一刪一增、前後錨點都在，而且
#     「舊條號＋前後錨點的位移＝新條號」，或前後錨點都沒位移、但舊號在新版整份不見、
#     新號在舊版整份沒有（兩邊都只有這一條換了號），而且兩段至少有 RENUMBER_MIN_SHARED 組
#     相同的兩字詞（招攬、業務、要保……）
REWRITE_MIN_SIM = 0.25
REWRITE_MIN_PREFIX = 8
REWRITE_SOLO_SIM = 0.30
REWRITE_MIN_BLOCK = 6
# 改號又整條重寫、卻沒有位移可以佐證時（前後錨點條號都沒動），要兩段共用幾組兩字詞才認。
# 這個數字只有三個校準點，講白：qa-rules M13b（真的改寫）6 組；tests/test_notices 的「第三條→第四條
# 改寫」4 組（不配，交給條文檢查的「刪除＋新增（視為改寫，條號不同）」）；同一份測資裡刪第六條
# 停效、另加第五條撤銷通知（不相干）1 組。取 5 是寧可少配：配錯是對照表寫成「修改」、把廢一條
# 又訂一條講成同一條，比拆成刪＋增更難看出來
RENUMBER_MIN_SHARED = 5
# 一個缺口的刪×增組數超過這個就不配：那是整份大改，一對一對配不出意義，只會拖慢
REWRITE_PAIR_LIMIT = 250000
_DELETED_PLACEHOLDERS = ("(刪除)", "刪除", "(删除)", "(本條刪除)", "(本點刪除)")

# 搬移（移列）：一段被刪、別處新增了一段內容一樣（或幾乎一樣）的，對照表要寫出搬去哪。
# MOVE_NEAR_SIM：「幾乎一樣」的下限，只給夠長的段（MOVE_NEAR_MIN_CHARS）用——短段差一兩字
#   就是另一件事。MOVE_SOLO_CHARS：比這短的段（表格儲存格、「一、身分證明文件。」）一模一樣
#   也可能只是常見寫法，要上一段或下一段也一起搬（整列、整條一起移）才認。
# 單獨一款（一項、一目）跨到別條、上下段又都沒跟著搬的，也不認：50 頁隨機修法實測，
#   「刪第二十一條第三款」與「第四十六條新增一款」剛好是同一句常見款文（「要保書及告知事項，
#   並依前條規定辦理覆核。」），40 次裡碰上 7 次，硬寫「移列至第四十六條」會讓人以為那是同一件事。
#   整條（第X條開頭）搬、同一條裡的款對調、連著幾段一起搬，照認。
# MOVE_NEAR_LIMIT：刪×增的組數超過這個就只認一模一樣的，免得整份改寫時算到天荒地老。
MOVE_NEAR_SIM = 0.9
MOVE_NEAR_MIN_CHARS = 12
MOVE_SOLO_CHARS = 10
MOVE_NEAR_LIMIT = 40000

# 「編號調整」的收尾提醒。以前寫「另有 N 處只是編號調整（內容未變動）」——
# 條文的字確實沒動，但條號或款號動了，別的條文寫「第七條」的地方就指到別的東西。
# 在同一行下「內容未變動」的結論，等於叫人不要再看交叉引用那一段。
# run_all.py 印的是同一句（`run_all.RENUMBERED_ONLY_NOTE` 就是這一個）。
RENUMBERED_ONLY_NOTE = "另有 %d 處編號調整（條號、章節或款目換號），引用是否受影響：見交叉引用與章節引用檢查"

# 搬移的收尾提醒（run_all 印同一句）。刪除、新增各算一筆，人會以為廢了一條又加一條。
MOVED_NOTE = "其中 %d 組刪除＋新增是搬移（內容一樣、位置不同），對照表條號欄已標「移列至…」「由原…移列」"

# 對齊演算法是 O(n*m) 且每格都要算一次相似度，replace 區塊太大時會很慢。
# 超過這個乘積就改成「帶狀對齊」：只算對角線附近的格子，其餘視為不可配對。
MAX_ALIGN_CELLS = 20000

# 帶狀對齊的半寬：只算 |i-j| <= band 的格子。
# 60 是這樣來的：對照表會錯行的成因是「整條新增／整條刪除造成的位移」，
# 實務上一次修法整條增刪很少超過幾十條，再加上兩邊本來就有的段數差，
# max(60, abs(n-m)+30) 足以把正常修法的位移包在帶內。
# 真正會超出帶寬的只有「整章搬移」，那種情況本來就要人工核對，所以一律印提醒。
MIN_BAND = 60
BAND_SLACK = 30

# 對齊平手時的加分：偏好靠對角線（|i-j| 小）的配對，見 align_chunk。
# 1e-10 是刻意挑的：區塊最多約 140 對（MAX_ALIGN_CELLS 的平方根），加分總和不到 1.5e-8，
# 遠小於兩種配法真正的相似度差（ratio＝2M/總字數，兩千字的段落差一字也有 1e-4 等級），
# 所以只在總分真的平手時決定勝負。回溯比對總分用的容許誤差也要跟著比加分小。
_TIE_BONUS = 1e-10
_SAME_SCORE = 1e-12


def _ratio(a, b):
    """兩段文字的相似度 0.0~1.0。先用便宜的估算擋掉明顯不像的，省下大量計算。"""
    matcher = difflib.SequenceMatcher(None, a, b, autojunk=False)  # autojunk 關掉：200 字以上的段落，常用字會被當成雜訊，改 2 字標出幾百字（B4）
    if matcher.real_quick_ratio() < PAIR_THRESHOLD:
        return 0.0
    if matcher.quick_ratio() < PAIR_THRESHOLD:
        return 0.0
    return matcher.ratio()


# compare_paragraphs 執行期間會把這個換成 list，讓整次比對只印一次提醒
# （一次比對可能有好幾個大區塊，每個區塊印一次會把畫面洗掉）。
_banded_notices = None


def _note_banded(n, m):
    """記一筆「這個區塊改走帶狀對齊」。不在 compare_paragraphs 裡就直接發提醒。

    text 不帶「提醒：」前綴：前綴由 notices 依等級補，兩邊各寫一份會變成「提醒：提醒：」。
    """
    text = ("改動區塊很大（舊 %d 段、新 %d 段），改用帶狀對齊；"
            "若中段有整章搬移，對照表可能配錯，請人工核對" % (n, m))
    if _banded_notices is None:
        nt.notice(nt.REMINDER, text, "Step 1 比對")
    else:
        _banded_notices.append(text)


def align_chunk(old_chunk, new_chunk):
    """
    把 difflib 判定為「這一整塊被換掉」的舊段落群跟新段落群，做一次一對一對齊。

    為什麼需要這個：difflib 只會告訴你「舊版第 3~5 段被換成新版第 3~6 段」，
    不會告訴你誰對誰。如果直接按順序 1對1、2對2 硬配，只要中間插進一段新條文，
    後面全部錯開一格──「第三條」會被配到「第二條之一」，對照表的條號整串跑掉。
    正式修法文件出這種錯是不能接受的。

    這裡用序列對齊(類似 Needleman-Wunsch)：在「不能交叉、要保持前後順序」的前提下，
    找出總相似度最高的配對方式。配得起來的算「修改」，配不到的分別算「刪除」跟「新增」。

    區塊大到 n*m 超過 MAX_ALIGN_CELLS 時，改成「帶狀對齊」：只算對角線附近
    |i-j| <= band 的格子，帶外一律當成不可配對。演算法、門檻、回溯規則都跟
    小區塊完全一樣，只是不算帶外那些本來就配不起來的格子，所以小區塊的結果
    一個字都不會變。以前這裡是「按位置硬配」——中間插一條，後面每一段舊文
    都被配到下一條的新文，整張對照表錯開一格，那正是上面說不能接受的事。

    回傳 [(old_text 或 None, new_text 或 None), ...]，順序即最終呈現順序。

    注意：_compare_paragraphs 餵進來的是**正規化過**的字串（見
    _common.normalize_for_diff），因為只差全半形或空白的同一條要配得起來。
    回傳值只用來判斷「這一格配到誰」，寫進對照表的原文由呼叫端用游標回去取，
    不要拿這裡回傳的字串當原文用。
    """
    n, m = len(old_chunk), len(new_chunk)
    if n == 0:
        return [(None, t) for t in new_chunk]
    if m == 0:
        return [(t, None) for t in old_chunk]

    banded = n * m > MAX_ALIGN_CELLS
    # band 一定 >= abs(n-m)，所以終點 (n, m) 必定落在帶內，回溯不會無路可走
    band = max(MIN_BAND, abs(n - m) + BAND_SLACK) if banded else None
    if banded:
        _note_banded(n, m)

    def in_band(i, j):
        """(i, j) 是 0 起算的段落索引。非帶狀時整張表都算。"""
        return band is None or abs(i - j) <= band

    # sim[(i, j)]：舊版第 i 段 跟 新版第 j 段 的相似度。
    # 用 dict 只存「配得起來」的格子：低於門檻與帶外的一律不存(查出來就是 0.0＝不可配對)。
    # 大區塊時若改存 n*m 的二維表，光是配置記憶體就會把大檔吃垮。
    sim = {}
    for i in range(n):
        lo = 0 if band is None else max(0, i - band)
        hi = m if band is None else min(m, i + band + 1)
        old_text = old_chunk[i]
        for j in range(lo, hi):
            score = _ratio(old_text, new_chunk[j])
            if score >= PAIR_THRESHOLD:
                # 平手時偏好靠對角線的配對。表格的短儲存格（「三個工作日」好幾格）相似度
                # 一模一樣，以前回溯先碰到哪格就配哪格：改一格又插一列時常配到後面那一格，
                # 對照表寫成「改了別列的格」，真正改的那格變成刪除（審查第 10 項）。
                sim[(i, j)] = score + _TIE_BONUS / (1 + abs(i - j))

    # dp[(i, j)]：對齊「舊版前 i 段」跟「新版前 j 段」能拿到的最高總分。
    # 一樣只存帶內的格子；帶外查出來是 0.0——帶外的路徑一個配對都拿不到，
    # 分數本來就是 0，所以這個預設值不會讓回溯走到假的高分路上。
    dp = {}

    def dp_at(i, j):
        if i <= 0 or j <= 0 or not in_band(i - 1, j - 1):
            return 0.0
        return dp.get((i, j), 0.0)

    for i in range(1, n + 1):
        lo = 1 if band is None else max(1, i - band)
        hi = m + 1 if band is None else min(m + 1, i + band + 1)
        for j in range(lo, hi):
            best = dp_at(i - 1, j)              # 舊版這段沒人配 -> 刪除
            left = dp_at(i, j - 1)
            if left > best:
                best = left                     # 新版這段沒人配 -> 新增
            score = sim.get((i - 1, j - 1), 0.0)
            if score > 0.0:
                paired = dp_at(i - 1, j - 1) + score
                if paired > best:
                    best = paired               # 兩段配成一對 -> 修改
            if best:
                dp[(i, j)] = best

    # 從右下角往回走，還原出實際的配對方式
    pairs = []
    i, j = n, m
    while i > 0 or j > 0:
        score = sim.get((i - 1, j - 1), 0.0) if i > 0 and j > 0 else 0.0
        here = dp_at(i, j)
        if score > 0.0 and abs(here - (dp_at(i - 1, j - 1) + score)) < _SAME_SCORE:
            pairs.append((old_chunk[i - 1], new_chunk[j - 1]))
            i -= 1
            j -= 1
        elif j > 0 and abs(here - dp_at(i, j - 1)) < _SAME_SCORE:
            pairs.append((None, new_chunk[j - 1]))
            j -= 1
        elif i > 0:
            pairs.append((old_chunk[i - 1], None))
            i -= 1
        else:
            j -= 1
    pairs.reverse()
    return pairs


def compare_paragraphs(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None):
    """逐段比對舊版跟新版（詳見 _compare_paragraphs 的說明）。

    old_kinds／new_kinds 是 read_paragraphs_with_kinds 回傳的來源種類
    （"p" 本文段落／"cell" 表格儲存格），只用來算條號層級：儲存格不能被算成
    前一條的「第X項」，否則對照表會寫出文件裡不存在的條號。不給就當成整份都是本文。

    這一層只負責把「改走帶狀對齊」的提醒收起來，整次比對印一次就好。
    一份大內規可能有好幾個大區塊，每個區塊各印一次會把後面真正要看的
    異動統計洗掉，人反而不會注意到這件需要人工核對的事。
    """
    global _banded_notices
    outer = _banded_notices          # 巢狀呼叫時交給最外層印，不重複
    _banded_notices = [] if outer is None else outer
    try:
        results = _compare_paragraphs(old_paragraphs, new_paragraphs,
                                      old_kinds, new_kinds)
    finally:
        notices, _banded_notices = _banded_notices, outer
    if outer is None and notices:
        nt.notice(nt.REMINDER, notices[0], "Step 1 比對")
        if len(notices) > 1:
            print("　　（本次共有 %d 個大區塊改用帶狀對齊）" % len(notices))
    return results


def classify_renumbered(entry):
    """
    把不是實質異動的那兩類從「修改」裡挑出來，跟真正的實質修改分開。

    一、「僅字形／空白差異」（cosmetic）：兩邊正規化之後一模一樣，只差全半形
        或空白。以前「第一條 甲」對「第一條　甲」會被標成「編號調整」——
        可是兩邊的條號一個字都沒變，根本沒有任何編號被調整；同樣的差異落在
        句中時更慘，直接升格成「實質異動（修改）」，對照表的「原條文」與
        「修正後條文」兩格印出來肉眼完全一樣，複核的人看不出改了什麼。
        這一類會列進修正對照表讓人看得到（原文保留原字），但不算實質異動、
        不算編號調整、不進候選與決定表、標註版全文上也不畫紅字。

    二、「編號調整」（renumbered）：只有編號變了、內容一個字沒動。
        刪掉一條底下的第二款之後，後面的款全部要往前遞補，三、變二、、
        四、變三、。這些段落的內容完全沒動，但逐段比對會把它們全部判定成
        「修改」。50 頁的內規刪掉幾個款，對照表就會被幾十筆編號位移灌爆，
        真正該看的實質異動反而被埋掉。

    順序不能反過來：先判 cosmetic，只差空白的段落才不會落到 renumbered 那一格。

    「只差空白」用 normalize_for_diff 判：中文字之間多一個空格、零寬字元、「第 五 條」
    以前判成「修改」或「編號調整」，兩欄印出來肉眼一樣（審查第二批）。
    """
    if entry["type"] not in ("modified", "unchanged"):
        return entry
    old_text = entry["old_text"] or ""
    new_text = entry["new_text"] or ""
    if old_text == new_text:
        return entry              # 一個字都不差，維持原本的類型
    if normalize_for_diff(old_text) == normalize_for_diff(new_text):
        entry["type"] = "cosmetic"
        return entry
    if entry["type"] != "modified":
        return entry
    # 用嚴的那一支：段首是引用（第五條規定…）或數量（30 日）時不能剝（A3）
    if (normalize_for_diff(strip_numbering_prefix(old_text))
            == normalize_for_diff(strip_numbering_prefix(new_text))):
        entry["type"] = "renumbered"
    return entry


def _compare_paragraphs(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None):
    """
    逐段比對舊版跟新版，回傳比對結果列表，每個元素是：
    {
        "type": "unchanged" / "added" / "deleted" / "modified"
                / "renumbered" / "cosmetic",
        "old_text": 舊版文字(沒有就是 None),
        "new_text": 新版文字(沒有就是 None),
        "old_index": 在舊版是第幾段(從 1 起算，沒有就是 None),
        "new_index": 在新版是第幾段(從 1 起算，沒有就是 None),
        "ref": 完整條號引用，例如「第三十三條第二款第二目」,
        "scope": 所屬章節，例如「第一章 第三節」,
        "moved_to" / "moved_from": 搬移（只有被認成移列的刪除／新增才有），見 _mark_moves,
    }

    ref / scope 是從全文的層級結構推算出來的，不是單看這一段。款目的編號
    （「二、」「(二)」）單看沒有意義，一份 50 頁的內規裡有幾百個「(二)」，
    對照表得寫出它掛在哪一條底下才找得到。
    """
    old_context = build_hierarchy(old_paragraphs, old_kinds)
    new_context = build_hierarchy(new_paragraphs, new_kinds)

    # 比對用的正規化字串。難看的地方是原文與正規化字串得一路並著走：
    # difflib 與對齊都拿正規化字串算，寫進結果的 old_text／new_text 一律取原文。
    old_norm = [normalize_for_diff(t) for t in old_paragraphs]
    new_norm = [normalize_for_diff(t) for t in new_paragraphs]

    def annotate(entry):
        """依段落位置補上條號引用與所屬章節；新版沒有的（整段刪除）就用舊版的。"""
        if entry["new_index"]:
            context = new_context[entry["new_index"] - 1]
        elif entry["old_index"]:
            context = old_context[entry["old_index"] - 1]
        else:
            context = None
        entry["ref"] = (context["ref"] if context else "") or article_no_for(
            entry["old_text"], entry["new_text"])
        # 舊版的條號另外留一份：條號整批位移時（第十八條 → 第十九條）同一張對照表上
        # 會有兩列都寫「第十八條」卻指不同條文，人核對時根本分不出哪一列是哪一條。
        # 「條號」欄要寫成「第十八條（新版第十九條）」就得知道舊版原本是第幾條。
        entry["old_ref"] = (old_context[entry["old_index"] - 1]["ref"]
                            if entry["old_index"] else "")
        entry["scope"] = format_scope(context)
        return classify_renumbered(entry)

    # 去掉段首編號的比對鍵：只換號的段落（刪一款之後遞補的「三、→二、」）拿它就對得上。
    # 去編號用嚴的 strip_numbering_prefix：段首是引用或數量時不剝（A3）。
    old_key = [normalize_for_diff(strip_numbering_prefix(t)) for t in old_paragraphs]
    new_key = [normalize_for_diff(strip_numbering_prefix(t)) for t in new_paragraphs]
    results = []

    def emit_pair(old_at, new_at, entry_type):
        results.append(annotate({
            "type": entry_type,
            "old_text": old_paragraphs[old_at], "new_text": new_paragraphs[new_at],
            "old_index": old_at + 1, "new_index": new_at + 1,
        }))

    def emit_deleted(old_at):
        results.append(annotate({
            "type": "deleted", "old_text": old_paragraphs[old_at], "new_text": None,
            "old_index": old_at + 1, "new_index": None,
        }))

    def emit_added(new_at):
        results.append(annotate({
            "type": "added", "old_text": None, "new_text": new_paragraphs[new_at],
            "old_index": None, "new_index": new_at + 1,
        }))

    def emit_by_similarity(i1, i2, j1, j2):
        """照相似度一對一對齊（align_chunk）。

        對齊拿正規化字串算相似度（全半形不同的同一條才配得起來），
        但 align_chunk 回傳的順序就是最終呈現順序，所以寫進結果的文字
        一律用游標回去取原文，不是它回傳的那個正規化字串。"""
        old_cursor, new_cursor = i1, j1
        for paired_old, paired_new in align_chunk(old_norm[i1:i2], new_norm[j1:j2]):
            if paired_old is not None and paired_new is not None:
                emit_pair(old_cursor, new_cursor, "modified")
                old_cursor += 1
                new_cursor += 1
            elif paired_old is not None:
                emit_deleted(old_cursor)
                old_cursor += 1
            else:
                emit_added(new_cursor)
                new_cursor += 1

    def emit_replaced(i1, i2, j1, j2):
        """第一層對不上的一塊：先拿去編號的鍵找只換號的段當錨點，錨點之間剩下的才照相似度配。

        以前整塊直接進 align_chunk。相似款「刪一款＋增一款＋遞補」時，只看相似度總和的
        對齊把它配成一串錯位的「修改」（舊第一款→新第一款、舊第二款→新第二款……，
        沒有一筆刪除、新增；審查第 10 項）。只換號的段先釘住，刪掉的那款、新增的那款
        才會落在錨點之間，各自成為刪除、新增。

        錨點只在這裡找，不直接拿去編號的鍵做第一層：同一條底下兩款各有一個
        「(二)電子檔應以不可竄改之格式保存」時，去編號後兩段一樣，第一層就可能把刪掉
        那款的「(二)」配給留下那款的「(一)」，原本一字不差的段反而變成刪除
        （50 頁隨機修法實測）。原字串完全相同的配對要先贏。
        鍵一樣、正規化字串不一樣的標「修改」，交給 classify_renumbered 判成編號調整。
        """
        inner = difflib.SequenceMatcher(None, old_key[i1:i2], new_key[j1:j2], autojunk=False)
        for tag, a1, a2, b1, b2 in inner.get_opcodes():
            if tag == "equal":
                for offset in range(a2 - a1):
                    old_at, new_at = i1 + a1 + offset, j1 + b1 + offset
                    same = old_norm[old_at] == new_norm[new_at]
                    emit_pair(old_at, new_at, "unchanged" if same else "modified")
            else:
                emit_by_similarity(i1 + a1, i1 + a2, j1 + b1, j1 + b2)

    matcher = difflib.SequenceMatcher(None, old_norm, new_norm, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for offset in range(i2 - i1):
                emit_pair(i1 + offset, j1 + offset, "unchanged")
        elif tag == "replace":
            emit_replaced(i1, i2, j1, j2)
        elif tag == "delete":
            for offset in range(i2 - i1):
                emit_deleted(i1 + offset)
        elif tag == "insert":
            for offset in range(j2 - j1):
                emit_added(j1 + offset)

    # 先認搬移（內容一樣，證據最強），剩下的刪＋增才看是不是同一條的改寫
    _mark_moves(results)

    def make_pair(deleted, added):
        return annotate({
            "type": "modified",
            "old_text": deleted["old_text"], "new_text": added["new_text"],
            "old_index": deleted["old_index"], "new_index": added["new_index"],
        })

    return _pair_rewrites(results, make_pair)


def _body_key(text):
    """比內容用的鍵：拿掉段首條號、正規化（只差空白算一樣）。"""
    return normalize_for_diff(strip_article_no(text or ""))


def _is_moved(entry):
    return bool(entry.get("moved_to") or entry.get("moved_from"))


def _rewrite_score(deleted, added, solo):
    """這一刪一增像不像同一條的改寫：像就回相似度（越大越像），不像回 None。門檻見 REWRITE_*。"""
    old_body, new_body = _body_key(deleted["old_text"]), _body_key(added["new_text"])
    old_no = extract_article_no(deleted["old_text"] or "")
    same_place = ((deleted.get("ref") and deleted.get("ref") == added.get("ref"))
                  or (old_no and old_no == extract_article_no(added["new_text"] or "")))
    if new_body in _DELETED_PLACEHOLDERS or old_body in _DELETED_PLACEHOLDERS:
        # 「第八條　（刪除）」：條文刪了但條號留著，是修這一條，不是刪一條又加一條
        return 1.0 if same_place else None
    if not old_body or not new_body:
        return None
    new_no = extract_article_no(added["new_text"] or "")
    if old_no != new_no and "之" in old_no + new_no and _whole_article(old_no) and _whole_article(new_no):
        # 刪第九十六條、原位置加第九十六條之一：之一是插進來的新條，不是第九十六條改寫
        # （開頭主詞剛好一樣也一樣；實測 300 次隨機插條有 3 次被這樣配錯）
        return None
    # 先看便宜的（共同開頭、是不是唯一一對），兩條路都走不到就不算相似度：
    # 整份改寫時一個缺口可能有上千刪×上千增，每一對都算 ratio 會慢到不能用
    prefixed = len(os.path.commonprefix([old_body, new_body])) >= REWRITE_MIN_PREFIX
    if not prefixed and not (solo and same_place):
        return None
    matcher = difflib.SequenceMatcher(None, old_body, new_body, autojunk=False)
    score = matcher.ratio()
    if score < REWRITE_MIN_SIM:
        return None
    if prefixed:
        return score
    if score >= REWRITE_SOLO_SIM:
        block = matcher.find_longest_match(0, len(old_body), 0, len(new_body)).size
        if block >= REWRITE_MIN_BLOCK:
            return score
    return None


def _pair_rewrites(results, make_pair):
    """把同一個缺口裡、其實是同一條改寫的刪＋增配成一筆「修改」。

    缺口＝結果裡連在一起的一串刪除／新增（前後錨點相同）。不同缺口的不配：
    位置差很遠的一刪一增，是另一件事（或是搬移，由 _mark_moves 處理）。
    一個缺口裡可以配好幾對，但配對不能交叉（新舊兩邊的先後順序都要守住）。
    """
    numbers = None                    # (舊版有的條號, 新版有的條號)，用到才算
    out = []
    i = 0
    while i < len(results):
        if results[i]["type"] not in ("deleted", "added"):
            out.append(results[i])
            i += 1
            continue
        j = i
        while j < len(results) and results[j]["type"] in ("deleted", "added"):
            j += 1
        anchors = (results[i - 1] if i > 0 else None, results[j] if j < len(results) else None)
        fences = (None, None)
        if j - i == 2:
            if numbers is None:
                numbers = (set(extract_article_no(r["old_text"] or "") for r in results if r["old_text"]),
                           set(extract_article_no(r["new_text"] or "") for r in results if r["new_text"]))
            fences = (_fence(results, i - 1, -1), _fence(results, j, 1))
        out.extend(_pair_run(results[i:j], make_pair, anchors, numbers, fences))
        i = j
    return out


def _article_value(ref):
    """「第五條」「第五條第二款」→ 5（條號那一層）；有「之一」或讀不出來回 None。"""
    head = _ARTICLE_HEAD_RE.match(display_ref(ref or ""))
    if not head or "之" in head.group(0):
        return None
    return cn_to_int(head.group(0)[1:-1])


# 往外找「讀得出新舊條號的錨點」最多看幾段：緊鄰的錨點常是章節標題、「之一」條，條號要再往外找
FENCE_LOOKAROUND = 30


def _fence(results, start, step):
    """從 start 往 step 方向找第一段新舊兩邊都在、而且新舊條號都讀得出來的錨點；找不到回 None。"""
    at = start
    while 0 <= at < len(results) and abs(at - start) < FENCE_LOOKAROUND:
        entry = results[at]
        if entry.get("old_index") and entry.get("new_index") and _anchor_shift(entry) is not None:
            return entry
        at += step
    return None


def _anchor_shift(entry):
    """錨點（沒被刪、沒被增的那一段）新舊條號差幾號；讀不出條號回 None。"""
    old_value, new_value = _article_value(entry.get("old_ref")), _article_value(entry.get("ref"))
    if old_value is None or new_value is None:
        return None
    return new_value - old_value


def _renumbered_rewrite(run, anchors, numbers, fences=(None, None)):
    """缺口裡唯一的一刪一增，是不是「同一條改了號又整條重寫」（M13b）。

    改號的整條重寫條號不同、字面又不像，_rewrite_score 兩條路都走不到，以前一律拆成
    刪除＋新增：條文檢查看不到「應→得」「三日→七個營業日」，對照表也看不出是同一條。
    這裡不看字面，只看位置，所以條件要嚴，每一條都是為了不把「刪一條、另訂一條」配起來：
      一、整個缺口就這兩段（不是好幾刪好幾增裡挑一對），兩段都是整條開頭、都沒有「之一」
          （刪第九十六條、加第九十六條之一是插新條，見 _rewrite_score）
      二、前後都有錨點（沒被刪、沒被增的段），缺口不在全文頭尾；條號的位移與夾擠看「圍欄」
          ——往外最近一段新舊條號都讀得出來的錨點（緊鄰的常是章節標題，見 _fence）
      三、新號＝舊號＋錨點的位移（前後錨點有條號的都要一致：前面插了一條，整批 +1）；
          或錨點都沒位移，那就要舊號在新版整份找不到、新號在舊版整份找不到——
          只要新版還有一條同號（刪第五條、別處第五條還在），或新號在舊版本來就有，都不配——
          而且沒有位移佐證就得看字：兩段要共用 RENUMBER_MIN_SHARED 組以上的兩字詞
      四、新舊兩個號都夾在前後錨點的條號中間（舊第一條＜第五條≦第九條、新第一條＜第六條≦第九條；後錨點可以是這一條自己的第二項）：
          刪第五十條、原位置冒出一條「第九百條」那種跳出去的號不配（50 頁對抗測試：少了這一條，
          300 次有 297 次被這條規則配成修改；加上之後跟沒有這條規則時一樣，只剩字面本來就像的那幾筆）
    """
    if len(run) != 2 or not numbers or None in anchors or None in fences:
        return False
    deleted = [r for r in run if r["type"] == "deleted" and not _is_moved(r)]
    added = [r for r in run if r["type"] == "added" and not _is_moved(r)]
    if len(deleted) != 1 or len(added) != 1:
        return False
    if any(not (anchor.get("old_index") and anchor.get("new_index")) for anchor in anchors):
        return False
    old_no = extract_article_no(deleted[0]["old_text"] or "")
    new_no = extract_article_no(added[0]["new_text"] or "")
    if not (_whole_article(old_no) and _whole_article(new_no)) or old_no == new_no:
        return False
    if "之" in old_no + new_no:
        return False
    old_body, new_body = _body_key(deleted[0]["old_text"]), _body_key(added[0]["new_text"])
    if not old_body or not new_body or old_body in _DELETED_PLACEHOLDERS or new_body in _DELETED_PLACEHOLDERS:
        return False
    old_value, new_value = _article_value(old_no), _article_value(new_no)
    if old_value is None or new_value is None:
        return False
    before, after = fences
    bounds = (_article_value(before.get("old_ref")), _article_value(after.get("old_ref")),
              _article_value(before.get("ref")), _article_value(after.get("ref")))
    if not (bounds[0] < old_value <= bounds[1] and bounds[2] < new_value <= bounds[3]):
        return False
    shifts = [_anchor_shift(fence) for fence in fences]
    if all(s == new_value - old_value for s in shifts):
        return True
    old_numbers, new_numbers = numbers
    return (all(s == 0 for s in shifts)
            and old_no not in new_numbers and new_no not in old_numbers
            and len(_bigrams(old_body) & _bigrams(new_body)) >= RENUMBER_MIN_SHARED)


def _bigrams(text):
    """一段字裡出現過的兩字詞（跨標點的不算）。"""
    return set(text[i:i + 2] for i in range(len(text) - 1)
               if not any(ch in _BIGRAM_STOPS for ch in text[i:i + 2]))


_BIGRAM_STOPS = "，。、；：,.;:（）()「」『』 　"


def _pair_run(run, make_pair, anchors=(None, None), numbers=None, fences=(None, None)):
    deletions = [r for r in run if r["type"] == "deleted" and not _is_moved(r)]
    additions = [r for r in run if r["type"] == "added" and not _is_moved(r)]
    if not deletions or not additions:
        return run
    solo = len(deletions) == 1 and len(additions) == 1
    if len(deletions) * len(additions) > REWRITE_PAIR_LIMIT:
        return run                    # 整份大改：不硬配（見 REWRITE_PAIR_LIMIT）
    found = []
    for d in deletions:
        for a in additions:
            score = _rewrite_score(d, a, solo)
            if score is not None:
                found.append((-score, abs(d["old_index"] - a["new_index"]), d["old_index"], a["new_index"], d, a))
    if not found and solo and _renumbered_rewrite(run, anchors, numbers, fences):
        d, a = deletions[0], additions[0]
        found.append((0.0, abs(d["old_index"] - a["new_index"]), d["old_index"], a["new_index"], d, a))
    if not found:
        return run
    found.sort(key=lambda x: x[:4])
    chosen = []
    used = set()
    for _, _, _, _, d, a in found:
        if id(d) in used or id(a) in used:
            continue
        if any((d["old_index"] - d2["old_index"]) * (a["new_index"] - a2["new_index"]) <= 0
               for d2, a2 in chosen):
            continue                  # 跟已經配好的交叉：順序會亂，不配
        chosen.append((d, a))
        used.update((id(d), id(a)))
    paired = dict((id(d), make_pair(d, a)) for d, a in chosen)
    partner = dict((id(a), paired[id(d)]) for d, a in chosen)
    # 重排：舊版這邊照舊段次、新版那邊照新段次，各自往前走；遇到配好的那一對兩邊一起出
    olds = sorted((r for r in run if r["type"] == "deleted"), key=lambda r: r["old_index"])
    news = sorted((r for r in run if r["type"] == "added"), key=lambda r: r["new_index"])
    seq, p, q = [], 0, 0
    while p < len(olds) or q < len(news):
        if p < len(olds) and id(olds[p]) not in paired:
            seq.append(olds[p])
            p += 1
        elif q < len(news) and id(news[q]) not in partner:
            seq.append(news[q])
            q += 1
        else:
            seq.append(paired[id(olds[p])])
            p += 1
            q += 1
    return seq


def _mark_moves(results):
    """刪除與新增內容一樣（或幾乎一樣）的，認成搬移（移列），兩筆互相記下對方在哪。

    類型照舊是「刪除」「新增」兩筆：新增一個類型會牽動決定表、套用、修改依據、對照表的
    每一個讀「修改類型」的地方（官方簽稿、審查包、從對照表重讀候選），風險大；兩列互相
    註記，對照表條號欄就寫得出「第十一條（移列至第四章第十一條）」「第十一條（由原第十一條
    移列）」，跟修正對照表說明欄「本條由原第X條移列」的慣例對得上。
    刪掉的那段會進「別章還留著同樣規定沒刪」的連帶搜尋：搬過去的那段一字不差，一定被當成
    候選列出來叫人刪——那正是不該刪的，所以 run_all.step_duplicates 要跳過有 moved_to 的刪除。

    moved_to（刪除那一筆）／moved_from（新增那一筆）：
        {"ref": 對方條號, "scope": 對方章節, "new_index"／"old_index": 對方段次,
         "identical": 去掉條號後內容一樣（只換位置或順便換號）}
    """
    deletions = [r for r in results if r["type"] == "deleted"]
    additions = [r for r in results if r["type"] == "added"]
    if not deletions or not additions:
        return
    keys = dict((id(r), _body_key(r["old_text"] if r["type"] == "deleted" else r["new_text"]))
                for r in deletions + additions)
    by_key = {}
    for a in additions:
        by_key.setdefault(keys[id(a)], []).append(a)
    near = len(deletions) * len(additions) <= MOVE_NEAR_LIMIT
    found = []
    for d in deletions:
        kd = keys[id(d)]
        if len(kd) < 2:
            continue
        for a in by_key.get(kd, []):
            found.append((-1.0, abs(d["old_index"] - a["new_index"]), d["old_index"], a["new_index"], d, a))
        if not near or len(kd) < MOVE_NEAR_MIN_CHARS:
            continue
        for a in additions:
            ka = keys[id(a)]
            if ka == kd or len(ka) < MOVE_NEAR_MIN_CHARS:
                continue
            matcher = difflib.SequenceMatcher(None, kd, ka, autojunk=False)
            if matcher.real_quick_ratio() < MOVE_NEAR_SIM or matcher.quick_ratio() < MOVE_NEAR_SIM:
                continue
            score = matcher.ratio()
            if score >= MOVE_NEAR_SIM:
                found.append((-score, abs(d["old_index"] - a["new_index"]), d["old_index"], a["new_index"], d, a))
    if not found:
        return
    found.sort(key=lambda x: x[:4])
    chosen, used = [], set()
    for neg, _, _, _, d, a in found:
        if id(d) in used or id(a) in used:
            continue
        chosen.append((d, a, -neg))
        used.update((id(d), id(a)))
    # 沒有鄰居一起搬（上一段或下一段也配成搬移、而且兩邊是同一個方向）的，要夠長，
    # 而且是整條、或還在同一條裡（見 MOVE_SOLO_CHARS 上面的說明）
    at = dict((d["old_index"], a["new_index"]) for d, a, _ in chosen)
    for d, a, score in chosen:
        o, n = d["old_index"], a["new_index"]
        if at.get(o - 1) != n - 1 and at.get(o + 1) != n + 1:
            if len(keys[id(d)]) < MOVE_SOLO_CHARS:
                continue
            if not _whole_article(d["old_text"]) and not _same_parent(d, a):
                continue
        identical = keys[id(d)] == keys[id(a)]
        d["moved_to"] = {"ref": a.get("ref") or "", "scope": a.get("scope") or "",
                         "new_index": a["new_index"], "identical": identical}
        a["moved_from"] = {"ref": d.get("ref") or "", "scope": d.get("scope") or "",
                           "old_index": d["old_index"], "identical": identical}


_ARTICLE_HEAD_RE = re.compile(r"^第[^第條]{1,12}條(?:之[^第條]{1,6})?")


def _whole_article(text):
    """這一段是不是一整條的開頭（「第十一條　……」）：整條搬移不用看鄰居。"""
    return bool(_ARTICLE_HEAD_RE.match(extract_article_no(text or "")))


def _same_parent(deleted, added):
    """新舊位置在同一條裡（款在同一條內對調）；沒有條號的文件看章節是不是同一個。"""
    old_ref, new_ref = display_ref(deleted.get("ref") or ""), display_ref(added.get("ref") or "")
    old_head, new_head = _ARTICLE_HEAD_RE.match(old_ref), _ARTICLE_HEAD_RE.match(new_ref)
    if old_head or new_head:
        return bool(old_head and new_head and old_head.group(0) == new_head.group(0))
    return (deleted.get("scope") or "") == (added.get("scope") or "")


def move_note(result):
    """搬移的那一句：刪除那筆「移列至第七條」、新增那筆「由原第八條移列」；不是搬移回空字串。

    對方的條號跟自己一樣（整條搬到別章、條號不變）時加上章節，還是一樣（表格裡兩列對調）
    就寫段次——只寫「移列至第六條」，人會以為根本沒動。"""
    info = result.get("moved_to") or result.get("moved_from")
    if not info:
        return ""
    own = display_ref(result.get("ref") or "")
    ref = display_ref(info.get("ref") or "")
    scope = (info.get("scope") or "").replace(" ", "")
    place = ref
    if not ref or ref == own:
        place = scope + ref if scope and scope != (result.get("scope") or "").replace(" ", "") else ""
    if result.get("moved_to"):
        return "移列至%s" % (place or "新版第%d段" % info["new_index"])
    return ("由原%s移列" % place) if place else ("由舊版第%d段移列" % info["old_index"])


TYPE_LABELS = {"added": "新增", "deleted": "刪除",
               "modified": "修改", "renumbered": "編號調整",
               "cosmetic": COSMETIC_LABEL}


# 一處實質異動都沒有時，對照表第一資料列整列寫這一句（小瑕疵 3）。
# 為什麼要寫：以前 0 異動的對照表就是「只有標題列」的一張空表。人打開它會以為
# 是程式沒跑完、或是自己開錯檔；表上要有一句話說「這就是結果」。
ZERO_CHANGE_ROW = "本次無實質異動"


def table_rows(results, table_format=None):
    """修正對照表的（欄標題, 資料列）。xlsx 版與 csv 退路共用，兩張表才不會漂開。

    欄位跟 Word 版讀同一份設定檔（tables/對照表格式.json）。
    早期版本這裡是寫死的，結果表上少了設定檔裡開著的「修改依據」欄——
    偏偏在沒有 python-docx 的平台上，這一份就是唯一的那張對照表，
    等於法遵拿到一張沒有地方填理由的對照表。

    「新版段次」不論設定檔開不開都會寫進去：那一欄是給 Step 2 的
    --from-csv 讀的，不是給人看的，關掉會讓後面那一步失去段落定位。
    """
    fmt = table_format or load_table_format()
    columns = [c for c in fmt["欄位"] if c.get("顯示", True)]
    if not any(c["鍵"] == "新版段次" for c in columns):
        columns = columns + [{"鍵": "新版段次", "標題": "新版段次"}]

    header = [c["標題"] for c in columns]
    split = _has_old_ref_column(columns)
    # 修改依據是程式草擬的（終比對）：xlsx 版最後多一欄「依據來源」，人看得出每一句從哪來
    sourced = any(r.get("依據來源") is not None for r in results if r["type"] != "unchanged")
    if sourced:
        header.append("依據來源")
    rows = []
    idx = 1
    for r in results:
        if r["type"] == "unchanged":
            continue
        row = []
        for column in columns:
            key = column["鍵"]
            if key == "原文":
                row.append(r["old_text"] or "（無，此為新增段落）")
            elif key == "修改後文字":
                row.append(r["new_text"] or "（無，此段落已刪除）")
            else:
                row.append(_cell_value(r, key, idx, split))
        if sourced:
            row.append(r.get("依據來源") or "")
        rows.append(row)
        idx += 1
    if not rows:
        rows.append([ZERO_CHANGE_ROW] + [""] * (len(header) - 1))
    return header, rows


def write_table_report(results, base_path, table_format=None, path_for=None):
    """把比對結果寫成修正對照表（.xlsx；寫不出來才退 .csv）。只列有改變的，沒改的不列。

    base_path 不帶副檔名。回傳實際寫出的路徑清單（呼叫端的 produced 要照實際的）。
    """
    header, rows = table_rows(results, table_format)
    written = xw.write_tables_or_csv(base_path, [("修正對照表", header, rows)],
                                     source="Step 1 對照表", path_for=path_for)
    for path in written:
        print("已產生對照表：%s" % display_path(path))
    warn_if_group_markers_stripped()
    return written


def write_annotated_text(results, output_path):
    """標註版全文的純文字退路（來源不是 .docx 時才走這裡）。

    修改段落寫成一行「舊文　→　新文」，右邊那份新文裡把真正改動的幾個字用
    【刪：…】【增：…】標出來（小瑕疵 1）。以前是「【刪除：整段舊文】【新增：整段新文】」
    ——兩段幾乎一樣的長條文並排，只差三個字，人得自己逐字對，等於沒標。

    「僅字形／空白差異」當成沒改：標出來只會是兩段肉眼一樣的字，
    反而讓人以為那裡有實質異動。要看它請改看修正對照表。
    """
    lines = []
    for r in results:
        if r["type"] in ("unchanged", "cosmetic"):
            lines.append(r["new_text"])
        elif r["type"] == "added":
            lines.append("【增：%s】" % r["new_text"] + ("（%s）" % move_note(r) if _is_moved(r) else ""))
        elif r["type"] == "deleted":
            lines.append("【刪：%s】" % r["old_text"] + ("（%s）" % move_note(r) if _is_moved(r) else ""))
        elif r["type"] in ("modified", "renumbered"):
            lines.append("%s　→　%s" % (r["old_text"], mark_changes(r["old_text"],
                                                                   r["new_text"])))

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print("已產生標註版全文（純文字）：%s" % display_path(output_path))


def mark_changes(old_text, new_text):
    """一段改過的條文，把改動的幾個字用【刪：…】【增：…】標出來（其餘照抄）。

    跟兩份 Word 檔用同一支 diff_runs，純文字版標到的字才會跟紅字底線的那幾個字
    一模一樣；各算各的遲早會對不起來。
    """
    pieces = []
    for kind, text in diff_runs(old_text or "", new_text or ""):
        if kind == "delete":
            pieces.append("【刪：%s】" % text)
        elif kind == "insert":
            pieces.append("【增：%s】" % text)
        else:
            pieces.append(text)
    return "".join(pieces)


def _hex_to_rgb(value):
    """把設定檔裡的 "C00000" 轉成 RGBColor 要的三個數字。壞值退回黑色。"""
    text = str(value or "").lstrip("#")
    if len(text) != 6:
        return (0x00, 0x00, 0x00)
    try:
        return (int(text[0:2], 16), int(text[2:4], 16), int(text[4:6], 16))
    except ValueError:
        return (0x00, 0x00, 0x00)


def _alignment(name):
    """設定檔的對齊字串轉成 python-docx 的常數。"""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    return {
        "置中": WD_ALIGN_PARAGRAPH.CENTER,
        "靠右": WD_ALIGN_PARAGRAPH.RIGHT,
        "分散": WD_ALIGN_PARAGRAPH.JUSTIFY,
    }.get(name, WD_ALIGN_PARAGRAPH.LEFT)


# 這一份 Word 檔清掉了幾個 XML 不合法字元。python-docx 底下的 lxml 碰到那種字元
# 會直接丟例外，使用者看到十幾層 traceback，而 CSV／TXT 已經寫出去了，資料夾裡
# 留下版本對不起來的半套產出（實測 no 32）。清掉之後一份文件發一則提醒。
_XML_CLEANED = [0]


def _xml_safe(text):
    """寫進 python-docx 之前先清掉 XML 1.0 不收的字元，順便記下清了幾個。"""
    clean, removed = sanitize_for_xml(text or "")
    _XML_CLEANED[0] += removed
    return clean


def _note_xml_cleanup(source):
    """把這一份文件清掉的字元數發成一則提醒（沒清到就不發）。"""
    removed = _XML_CLEANED[0]
    _XML_CLEANED[0] = 0
    if removed:
        nt.notice(nt.REMINDER, XML_CLEANUP_NOTICE % removed, source)


def _add_marked_runs(paragraph, runs, marks, show_deleted=True, show_inserted=True,
                     font_size=None):
    """
    把 diff_runs() 產出的片段寫進 Word 段落，套上修正對照表的標示慣例。

    marks 是設定檔裡的「標示」區塊，決定新增／刪除各用什麼顏色與樣式。
    多數單位用紅字底線／刪除線，但有些單位規定用藍字，所以做成可設定的。

    show_deleted / show_inserted 控制這一格要顯示哪一邊。
    對照表的「原文」欄只該出現刪除標記，「修改後文字」欄只該出現新增標記，
    兩欄各自讀起來才會是完整通順的一條條文。標註版全文則兩邊都顯示。
    """
    from docx.shared import Pt, RGBColor

    for kind, text in runs:
        if kind == "delete" and not show_deleted:
            continue
        if kind == "insert" and not show_inserted:
            continue

        run = paragraph.add_run(_xml_safe(text))
        if font_size:
            run.font.size = Pt(font_size)

        style = marks.get("新增" if kind == "insert" else "刪除") if kind != "equal" else None
        if style:
            run.font.color.rgb = RGBColor(*_hex_to_rgb(style.get("顏色")))
            run.font.underline = bool(style.get("底線"))
            run.font.strike = bool(style.get("刪除線"))


def _runs_for(result):
    """依修改類型算出這一筆要標示的片段。

    「僅字形／空白差異」不在下面任何一支，會落到最後的 equal——這是刻意的：
    全形空格與半形空格畫上紅字底線，印出來看不出差別，只會製造雜訊。
    """
    if result["type"] == "added":
        return [("insert", result["new_text"])]
    if result["type"] == "deleted":
        return [("delete", result["old_text"])]
    if result["type"] in ("modified", "renumbered"):
        return diff_runs(result["old_text"], result["new_text"])
    return [("equal", result["new_text"])]


def can_annotate_source(path):
    """來源是不是一份存在的 .docx。是的話才有原檔可以改。"""
    return bool(path) and str(path).lower().endswith(".docx") and os.path.exists(path)


# 舊名字，還有別處在用
_can_annotate_source = can_annotate_source

# 來源不是 Word 檔時，標註版全文改出純文字檔的那一句。
# 為什麼要講：資料夾裡只會有 標註版全文.txt 而沒有 .docx，人會以為 Word 版產失敗了。
# 真正的原因是「沒有原檔可以標」——.txt／.md 沒有字型、沒有縮排，新開一份空白 Word
# 標紅字只是把純文字換個副檔名，不如直接給純文字版。
SOURCE_NOT_WORD_NOTE = ("來源不是 Word 檔（%s），沒有原檔可以標註；"
                        "標註版全文改出純文字檔，改動處用【刪：…】【增：…】標示")


def export_to_docx(results, output_path, table_format=None, source_docx=None,
                   text_fallback=None, path_for=None):
    """
    輸出標註版全文的 Word 檔：新增與刪除依設定標色，其餘黑字。

    回傳實際寫出來的檔案路徑（一律是**正式路徑**，不是 AtomicWrites 的 .tmp——
    呼叫端拿它去 os.path.exists 決定要不要列進產出清單）；
    一個字都沒寫出來就回 None，呼叫端的產出清單才不會列一個不存在的檔。

    text_fallback／path_for（選填）：在原檔上標註走不下去、而且這台電腦沒有
    python-docx 時，改把純文字標註版寫到 text_fallback 這個路徑（走 path_for，
    才進得了呼叫端的 AtomicWrites）。不給的話那種情形就真的什麼都不寫。

    修改的段落只標「真正改掉的那幾個字」，不是整段刪掉再整段加回來。
    整段標紅的話，第一條那種只加了「一百十五年」五個字的修改，人還是得把
    前後兩行從頭讀到尾自己找差異，等於沒標。

    source_docx：新版的原始 .docx。有給的話走「在原檔上標註」——複製原檔，
    只改有異動的那幾段，字型、縮排、頁首頁尾與表格全部留著。
    早期版本一律新開一份空白 Word，實測 11 項格式掉了 10 項、附表整個消失，
    法遵拿到那種檔案沒辦法用。
    """
    fmt = table_format or load_table_format()
    marks = fmt["標示"]

    # 首選：在原檔上改。只用標準函式庫，所以裝不了 python-docx 的平台也產得出來。
    if _can_annotate_source(source_docx):
        try:
            summary = docx_annotate.annotate_in_place(
                source_docx, results, output_path, marks, diff_runs)
        except Exception as exc:
            nt.notice(nt.REMINDER,
                      "在原檔上標註失敗（%s），改用新建 Word 檔的方式；"
                      "新建的版本文字正確，但原檔的字型、縮排、頁首頁尾與表格不會保留" % exc,
                      "Step 1 標註版")
        else:
            if summary.get("xml_cleaned"):
                nt.notice(nt.REMINDER,
                          XML_CLEANUP_NOTICE % summary["xml_cleaned"],
                          "Step 1 標註版")
            tail = ("，插入已刪除條文 %d 段" % summary["inserted"]
                    if summary["inserted"] else "")
            print("已產生標註版全文 Word 檔（保留原檔格式）：%s" % display_path(output_path))
            print("      標註 %d 段%s" % (summary["marked"], tail))
            missed = summary["unmatched"] + summary.get("mismatch", 0)
            if missed:
                # 沒標到的一定要講。人看到沒有紅字會以為那裡沒改。
                # 兩種沒標到的成因不一樣，人要處理的方式也不一樣：
                #   mismatch      定位到了，但那一段的原文跟對照表對不起來
                #                 （段落裡有超連結、域代碼等巢狀文字，或草稿中途被改過）
                #   unmatched     定位不到段落（段次超出範圍、刪除段找不到可插入的錨點）
                # （「表格一格多段」那一種已經消失：格內每段各自是一段，標得到。）
                nt.notice(nt.REMINDER,
                          "標註版全文有 %d 處標不上去（原文與對照表不符 %d 處、"
                          "定位不到段落 %d 處）；"
                          "這幾處請改看 修正對照表，不要以為沒有紅字就是沒改"
                          % (missed, summary.get("mismatch", 0), summary["unmatched"]),
                          "Step 1 標註版")
            # display_path 不是為了好看：走 AtomicWrites 時 output_path 是
            # 「正式路徑 + .tmp」，那個檔離開 with 之後就被 os.replace 掉了。
            # 直接回它的話，呼叫端（step_diff）拿去 os.path.exists 一律是 False，
            # 標註版全文.docx 會整個從「產出資料夾：」那張清單上消失——檔案明明
            # 在資料夾裡，畫面卻沒列，人會以為這一輪沒產出標註版。
            return display_path(output_path)

    # 退路：在原檔上標註走不下去（來源不是 .docx，或 annotate_in_place 失敗），
    # 只能新建一份 Word——而新建需要 python-docx。
    if not HAS_DOCX:
        # 這一支沒有 python-docx 就一個字都寫不出來。以前這裡直接 return，
        # 而呼叫端（step_diff）在「來源是 .docx」那條路上根本不會另外寫純文字版，
        # 於是資料夾裡連 標註版全文 都沒有，提醒卻寫著「純文字標註版仍會產生」——
        # 兩句話都是假的（來源明明是 .docx）。改成真的在這裡補一份純文字版。
        if text_fallback:
            write_annotated_text(results, (path_for or (lambda p: p))(text_fallback))
            nt.notice(nt.REMINDER,
                      "沒有安裝 python-docx，在原檔上標註又走不下去，"
                      "標註版全文改出純文字檔（%s），改動處用【刪：…】【增：…】標示"
                      % os.path.basename(text_fallback), "Step 1 標註版")
            return text_fallback
        nt.notice(nt.REMINDER,
                  "沒有安裝 python-docx，在原檔上標註又走不下去，這次沒有標註版全文；"
                  "改動處請改看 修正對照表", "Step 1 標註版")
        return None

    from docx import Document

    doc = Document()
    _XML_CLEANED[0] = 0
    for r in results:
        paragraph = doc.add_paragraph()
        _add_marked_runs(paragraph, _runs_for(r), marks)

    doc.save(output_path)
    _note_xml_cleanup("Step 1 標註版")
    print("已產生標註版全文 Word 檔（依設定標色）：%s" % display_path(output_path))
    return display_path(output_path)      # 理由同上：不能回 .tmp


def _shade_cell(cell, hex_color):
    """幫表格儲存格上底色。python-docx 沒有現成 API，要直接塞 XML。"""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    shading = OxmlElement("w:shd")
    shading.set(qn("w:val"), "clear")
    shading.set(qn("w:fill"), str(hex_color or "FFFFFF").lstrip("#"))
    cell._tc.get_or_add_tcPr().append(shading)


def article_no_cell(result, split=False):
    """修正對照表「條號」欄要印的字。CSV 版與 Word 版共用同一支，兩張表才不會漂開。

    display_ref：拿掉 build_hierarchy 加的「（第N組）」區隔標記。那是程式生成的字，
    不是文件裡的條號，不能寫進要送出去會簽的對照表；內部（審查包、決定表的錨點）
    仍然用完整的 ref。

    編號調整（renumbered）且新舊條號真的不同時要兩個都寫：「第十八條（新版第十九條）」。
    只印新版條號的話，中間插了一條讓後面整批位移的那種修法，同一張對照表上會有
    好幾列都寫著同一個條號卻各指不同條文，人核對時無從分辨。

    改號又改內容（modified／cosmetic，新舊條號不同）寫「第五條（原第四條）」（審查第三批）：
    以前只寫新號，現行條文欄那一格明明是第四條的字，條號欄卻只說第五條，
    修正對照表「新舊欄各寫自己的條號」的慣例在這一列對不起來。搬移那兩列已經有
    「（移列至…）／（由原…移列）」，不再疊一個「（原…）」。

    split：版面另有「原條號」欄（見 old_article_no_cell）時，這一欄只寫自己這一邊的條號，
    舊號交給那一欄，兩欄各寫各的，不在同一格裡括號。
    """
    ref = display_ref(result.get("ref")
                      or article_no_for(result["old_text"], result["new_text"]))
    old_ref = display_ref(result.get("old_ref") or "")
    if _is_moved(result):
        # 搬移：兩列互相註記（第十一條（移列至第四章第十一條）／第十一條（由原第十一條移列））。
        # 「修改類型」欄維持刪除／新增：官方簽稿、從對照表重讀候選都照那一欄的字判斷
        return "%s（%s）" % (ref or _position_ref(result), move_note(result))
    if not split and old_ref and ref and old_ref != ref:
        if result.get("type") == "renumbered":
            return "%s（新版%s）" % (old_ref, ref)
        if result.get("type") in ("modified", "cosmetic"):
            return "%s（原%s）" % (ref, old_ref)
    return ref or _position_ref(result)


def old_article_no_cell(result):
    """「原條號」欄（選用）：這一列在舊版的條號。新增列沒有舊版，留白。

    給「現行條文欄、修正條文欄各配一欄條號」的版面用。條號欄（article_no_cell(split=True)）
    寫新版那一邊，這一欄寫舊版那一邊；舊版抓不到條號時寫「舊版第N段」，跟條號欄的退路一樣。
    """
    if not result.get("old_index"):
        return ""
    return display_ref(result.get("old_ref") or "") or "舊版第%d段" % result["old_index"]


def _has_old_ref_column(columns):
    """版面有沒有開「原條號」欄：有的話條號欄只寫新版那一邊（不括號舊號）。"""
    return any(column.get("鍵") == "原條號" for column in columns)


def _position_ref(result):
    """條號欄真的空白時退而求其次寫的座標（小瑕疵 4）。

    作業手冊型文件沒有「第X條」，這一欄以前整欄留白——對照表上一列寫著改了什麼，
    卻沒有任何一個字說得出那是全文的哪裡，人要自己從頭數段落。寫段次至少指得到。
    刪除段沒有新版段次，寫「舊版第N段」，免得被當成新版座標而翻錯段。
    """
    if result.get("new_index"):
        return "第%d段" % result["new_index"]
    if result.get("old_index"):
        return "舊版第%d段" % result["old_index"]
    return ""


def _cell_value(result, key, index, split=False):
    """一個欄位鍵對應到這一筆異動的什麼內容。split：版面另有「原條號」欄。"""
    if key == "序號":
        return str(index)
    if key == "章節":
        return result.get("scope", "")
    if key == "條號":
        return article_no_cell(result, split)
    if key == "原條號":
        return old_article_no_cell(result)
    if key == "修改類型":
        return TYPE_LABELS.get(result["type"], result["type"])
    if key == "新版段次":
        return str(result.get("new_index") or "")
    if key == "修改依據":
        # 終比對時 change_reasons 只寫查得到依據的（每一列另附依據來源），其餘寫「請補修正理由」；
        # 初比對沒有草擬，留白。程式不會自己編一個理由進正式文件。
        return result.get("修改依據") or ""
    return None      # 原文／修改後文字要走標示邏輯，不是純文字


def export_table_to_docx(results, output_path, title=None, table_format=None):
    """
    輸出正式的修正對照表 Word 檔。

    版面、欄位、寬度、標示顏色全部讀自設定檔（tables/對照表格式.json），
    各單位的公文格式要求不同，改設定就好，不用動程式碼。

    固定不變的只有兩件事，因為它們不是格式問題而是正確性問題：
    - 「原文」欄只顯示刪除標記、「修改後文字」欄只顯示新增標記，
      這樣兩欄各自都是一條讀得通的完整條文
    - 「修改依據」欄只寫 change_reasons 查得到依據的草稿，程式不會自己編理由
    """
    if not HAS_DOCX:
        nt.notice(nt.REMINDER,
                  "沒有安裝 python-docx，跳過修正對照表 Word 檔輸出（CSV 版仍有產生）；"
                  "要 Word 版對照表請先執行 python check_env.py", "Step 1 對照表")
        return

    from docx import Document
    from docx.enum.section import WD_ORIENT
    from docx.shared import Cm, Pt

    fmt = table_format or load_table_format()
    layout, heading_fmt, table_fmt = fmt["版面"], fmt["標題"], fmt["表格"]
    columns = fmt["欄位"]
    marks = fmt["標示"]
    body_size = table_fmt.get("字級", 11)

    changes = [r for r in results if r["type"] != "unchanged"]
    split = _has_old_ref_column(columns)
    doc = Document()
    _XML_CLEANED[0] = 0

    section = doc.sections[0]
    if layout.get("方向", "橫式") == "橫式":
        # 橫式：原文與修改後文字並排才讀得動，直式會擠成兩條細長欄位
        section.orientation = WD_ORIENT.LANDSCAPE
        if section.page_width < section.page_height:
            section.page_width, section.page_height = (
                section.page_height, section.page_width)
    for attr in ("left_margin", "right_margin"):
        setattr(section, attr, Cm(layout.get("左右邊界公分", 1.5)))
    for attr in ("top_margin", "bottom_margin"):
        setattr(section, attr, Cm(layout.get("上下邊界公分", 2.0)))

    heading = doc.add_paragraph()
    heading.alignment = _alignment(heading_fmt.get("對齊", "置中"))
    heading_run = heading.add_run(_xml_safe(title or heading_fmt.get("文字", "修正對照表")))
    heading_run.font.size = Pt(heading_fmt.get("字級", 18))
    heading_run.font.bold = bool(heading_fmt.get("粗體", True))

    table = doc.add_table(rows=1, cols=len(columns))
    if table_fmt.get("框線", True):
        table.style = "Table Grid"

    for cell, column in zip(table.rows[0].cells, columns):
        cell.width = Cm(column["寬度公分"])
        if table_fmt.get("表頭底色"):
            _shade_cell(cell, table_fmt["表頭底色"])
        run = cell.paragraphs[0].add_run(_xml_safe(column["標題"]))
        run.font.bold = bool(table_fmt.get("表頭粗體", True))
        run.font.size = Pt(body_size)
        cell.paragraphs[0].alignment = _alignment("置中")

    if not changes:
        # 0 實質異動（小瑕疵 3）：整列寫一句話，其餘欄留白。只有標題列的空表，
        # 人會以為是程式沒跑完或自己開錯檔。
        cell = table.add_row().cells[0]
        run = cell.paragraphs[0].add_run(ZERO_CHANGE_ROW)
        run.font.size = Pt(body_size)

    for index, result in enumerate(changes, 1):
        cells = table.add_row().cells
        runs = _runs_for(result)

        for cell, column in zip(cells, columns):
            cell.width = Cm(column["寬度公分"])
            paragraph = cell.paragraphs[0]
            paragraph.alignment = _alignment(column.get("對齊", "靠左"))
            key = column["鍵"]

            value = _cell_value(result, key, index, split)
            if value is not None:
                run = paragraph.add_run(_xml_safe(value))
                run.font.size = Pt(body_size)
                continue

            if key == "原文":
                if result["type"] == "added":
                    run = paragraph.add_run("（無，此為新增段落）")
                    run.font.size = Pt(body_size)
                elif result["type"] == "cosmetic":
                    # 只差字形或空白：兩欄都印原字、都不標色。
                    # 標了也看不出差別，只會讓人以為這裡有實質異動。
                    run = paragraph.add_run(_xml_safe(result["old_text"] or ""))
                    run.font.size = Pt(body_size)
                else:
                    _add_marked_runs(paragraph, runs, marks, show_inserted=False,
                                     font_size=body_size)
            elif key == "修改後文字":
                if result["type"] == "deleted":
                    run = paragraph.add_run("（無，此段落已刪除）")
                    run.font.size = Pt(body_size)
                elif result["type"] == "cosmetic":
                    run = paragraph.add_run(_xml_safe(result["new_text"] or ""))
                    run.font.size = Pt(body_size)
                else:
                    _add_marked_runs(paragraph, runs, marks, show_deleted=False,
                                     font_size=body_size)

    doc.save(output_path)
    _note_xml_cleanup("Step 1 對照表")
    print("已產生修正對照表 Word 檔（%s、%d 欄）：%s"
          % (layout.get("方向", "橫式"), len(columns), display_path(output_path)))
    warn_if_group_markers_stripped()


def main():
    setup_console()
    parser = argparse.ArgumentParser(description="Step 1：新舊內規精確文字比對")
    parser.add_argument("old_file", help="舊版內規檔案（.docx / .txt / .md）")
    parser.add_argument("new_file", help="新版內規檔案（.docx / .txt / .md）")
    parser.add_argument("--outdir", default="", help="輸出資料夾，預設為目前目錄")
    parser.add_argument("--title", default="",
                        help="修正對照表 Word 檔的標題，例如 --title \"○○作業要點修正對照表\"")
    parser.add_argument("--format", default=None,
                        help="對照表版面設定檔，預設用 tables/對照表格式.json")
    parser.add_argument("--prefix", default="",
                        help="輸出檔名前綴，例如 --prefix 壽險內規；連續比對多份內規時用得到，避免互相覆蓋")
    args = parser.parse_args()

    print("正在讀取舊版：%s" % args.old_file)
    warn_if_versions_swapped(args.old_file, args.new_file)
    old_paragraphs = read_paragraphs(args.old_file)
    print("正在讀取新版：%s" % args.new_file)
    new_paragraphs = read_paragraphs(args.new_file)
    print("舊版 %d 段、新版 %d 段，開始比對..." % (len(old_paragraphs), len(new_paragraphs)))

    results = compare_paragraphs(old_paragraphs, new_paragraphs)

    counts = {"added": 0, "deleted": 0, "modified": 0, "renumbered": 0,
              "cosmetic": 0}
    for r in results:
        if r["type"] in counts:
            counts[r["type"]] += 1
    substantive = counts["added"] + counts["deleted"] + counts["modified"]
    print("比對完成，共 %d 處差異（新增 %d、刪除 %d、修改 %d）。"
          % (substantive, counts["added"],
             counts["deleted"], counts["modified"]))
    if counts["renumbered"]:
        print(RENUMBERED_ONLY_NOTE % counts["renumbered"])
        print("（對照表上另行標示為「編號調整」。）")
    if counts["cosmetic"]:
        print("另有 %d 處只有字形或空白差異（全半形、空格），不算實質異動，"
              "已在對照表中另行標示為「%s」。"
              % (counts["cosmetic"], COSMETIC_LABEL))
    moves = sum(1 for r in results if r.get("moved_to"))
    if moves:
        print(MOVED_NOTE % moves)

    table_format = load_table_format(args.format)

    base = os.path.splitext(
        resolve_output(args.outdir, args.prefix, "修正對照表.xlsx"))[0]
    write_table_report(results, base, table_format=table_format)
    # 標註版全文只出一種格式：來源是 .docx 就在原檔上標註，不是的話退純文字檔
    # （見 run_all.step_diff 的同一條規則）。
    if can_annotate_source(args.new_file):
        export_to_docx(results, resolve_output(args.outdir, args.prefix, "標註版全文.docx"),
                       table_format=table_format, source_docx=args.new_file)
    else:
        print(SOURCE_NOT_WORD_NOTE % os.path.basename(args.new_file))
        write_annotated_text(results,
                             resolve_output(args.outdir, args.prefix, "標註版全文.txt"))
    export_table_to_docx(results, resolve_output(args.outdir, args.prefix, "修正對照表.docx"),
                         title=args.title or None, table_format=table_format)

    return results


if __name__ == "__main__":
    main()
