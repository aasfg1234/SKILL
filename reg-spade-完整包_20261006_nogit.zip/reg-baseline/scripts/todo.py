# -*- coding: utf-8 -*-
"""
人工待辦清單：每跑完一個批次指令，列出「現在」要人做的每一件事、在哪個檔、有幾列。

人不用記得流程走到哪、哪一張表在哪一格：打開 產出/審閱文件/人工待辦.txt（畫面最後也印一份）
照著做就好；程式能接著做的站一律寫「跑 繼續」（next_step 用同一套判斷決定 繼續 要跑哪一個指令）。
各本走到哪一步用檔案狀態判斷，不另外記狀態：
    決定表還有沒決定的列、人工確認還有沒回覆的 → 先填表
    都決定了但還沒 apply（或 apply 之後表又改過）→ 跑 batch-apply
    apply 了、修訂自動驗證沒過                  → 用 Word 看那一本
    驗過了但還沒 finalize（或定稿比驗收報告新）  → 跑 batch-finalize
    驗收結論不是「改好」                        → 照驗收報告回頭處理
    改好了                                     → 送簽前還要看的（無法查證、警告、修改依據）
"""

import csv
import io
import json
import os
import sys
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import RESULT_DIR, book_dir, locate, place

FILE = "人工待辦.txt"
# 批次指令畫面最後印的這一段，是那個指令唯一的「下一步」（各指令自己不再另外印一組，見第四批 26）
SCREEN_HEADER = "下一步（人工待辦，完整清單在 產出/審閱文件/人工待辦.txt）："
STAGES = ("重跑開始", "AI審查", "填表", "套用", "看修訂", "驗收", "驗收沒過", "看警告", "送簽前")
AI_REVIEW_SKIP = "AI審查略過.txt"        # batch-review-pack --略過 寫在 產出/系統檔案/
SEMANTIC_SKIP = "略過.txt"                # batch-semantic --略過 寫在 產出/系統檔案/語意候選/


def _mtime(path):
    return os.path.getmtime(path) if path and os.path.isfile(path) else 0


def _warnings(folder):
    count = 0
    for name in ("提醒.txt", "最終版_提醒.txt"):
        path = locate(folder, name)[0]
        if os.path.isfile(path):
            with io.open(path, encoding="utf-8-sig") as f:
                count += sum(1 for line in f if line.startswith("警告｜"))
    return count


def _sources_from_workspace(folder):
    """沒有 輸入來源.json（這個功能之前跑的「開始」）：從工作區的 匯入/規章清單.csv 找這一本的檔。
    folder 是 <工作區>/產出/系統檔案/<規章名>。找不到就回 None（不判斷）。"""
    import batch as bt
    name = os.path.basename(os.path.normpath(folder))
    workspace = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(folder))))
    manifest = os.path.join(workspace, "匯入", "規章清單.csv")
    if not os.path.isfile(manifest):
        return None
    try:
        docs = bt.read_manifest(manifest)
    except bt.BatchError:
        return None
    for doc in docs:
        if doc["規章名"] == name:
            return {"舊版": doc["舊版"], "草稿": doc["草稿"]}
    return None


def semantic_pending(root):
    """這台電腦算不了語意、要到別台算，還沒帶回來併入的本（語意候選資料夾裡有輸入、沒有結果）。"""
    from _common import SYSTEM_DIR
    folder = os.path.join(root, SYSTEM_DIR, "語意候選")
    if not os.path.isdir(folder) or os.path.isfile(os.path.join(folder, SEMANTIC_SKIP)):
        return []
    suffix = "_語意輸入.json"
    return sorted(n[:-len(suffix)] for n in os.listdir(folder)
                  if n.endswith(suffix) and not os.path.isfile(os.path.join(folder, n[:-len(suffix)] + ".csv")))


def _ai_review_state(root, folder, table, rows):
    """"done"：這一輪的列都審過了（或這一輪說好不做）；"packed"：審查包已經產生、等 AI 填表匯入；
    "todo"：還沒打包。審過沒有看 AI審查紀錄.json 記的列與異動跟現在一不一樣（補了語意就要再審新列）。"""
    import decision_table as dt
    import review_import as ri
    from _common import SYSTEM_DIR
    if os.path.isfile(os.path.join(root, SYSTEM_DIR, AI_REVIEW_SKIP)):
        return "done"
    changes = []
    changes_path = locate(folder, "異動清單.json")[0]
    if os.path.isfile(changes_path):
        with io.open(changes_path, encoding="utf-8") as f:
            changes = json.load(f)
    record = locate(folder, ri.AI_REVIEW_RECORD)[0]
    if os.path.isfile(record):
        try:
            with io.open(record, encoding="utf-8") as f:
                if json.load(f) == ri.ai_review_signature(rows, changes):
                    return "done"
        except (OSError, ValueError):
            pass
    ai_csv = locate(folder, "AI候選判斷.csv")[0]
    side = dt.sidecar_path_for(table)
    if os.path.isfile(ai_csv) and os.path.isfile(side) and _mtime(ai_csv) >= _mtime(side):
        return "packed"
    return "todo"


def _sources_of(folder):
    path = locate(folder, "輸入來源.json")[0]
    try:
        if os.path.isfile(path):
            with io.open(path, encoding="utf-8") as f:
                return json.load(f)
    except (OSError, ValueError):
        pass
    return None


def _inputs_moved(folder, table):
    """這一本的現行規章或修訂版，在「開始」之後被改過、換過或拿走了嗎？回傳說明，沒有回 ""。
    決定表的指紋檔記著「開始」當時兩份檔的 SHA-256，輸入來源.json 記著檔在哪裡。"""
    import decision_table as dt
    path = locate(folder, "輸入來源.json")[0]
    try:
        if os.path.isfile(path):
            with io.open(path, encoding="utf-8") as f:
                sources = json.load(f)
        else:
            sources = _sources_from_workspace(folder)
        side = dt.read_sidecar(dt.sidecar_path_for(table))
    except (OSError, ValueError, dt.DecisionTableError):
        return ""
    if not sources:
        return ""
    for key, label in (("草稿", "修訂版"), ("舊版", "現行規章")):
        file_path, want = sources.get(key), (side.get(key) or {}).get("SHA256")
        if not file_path or not want:
            continue
        if not os.path.isfile(file_path):
            return "%s不見了（%s）" % (label, os.path.basename(file_path))
        if dt.file_sha256(file_path) != want:
            return "%s在「開始」之後改過了（%s）" % (label, os.path.basename(file_path))
    return ""


def book_status(root, name):
    """一本走到哪一步、還有哪些事。沒有決定表（還沒比對）回 None。"""
    import approve as ap
    import decision_table as dt
    import review_import as ri
    folder = book_dir(root, name)
    table = locate(folder, "連帶決定表.csv")[0]
    if not os.path.isfile(table):
        return None
    import change_reasons as cr
    reasons = cr.read_summary(folder) or {}
    moved = _inputs_moved(folder, table)
    left = None
    if reasons:
        # 驗收草擬過之後才算：人在 產出/結果彙整/ 那一份對照表上補一列就少一列（照那一份數）
        left = cr.pending_in_table(folder)
        left = reasons.get("請補") if left is None else left
    info = {"規章": name, "沒決定": 0, "可核准": 0, "待確認": 0, "警告": _warnings(folder),
            "警告待確認": ri.pending_warnings(folder),
            "請補": left, "草擬": reasons.get("草擬", 0),
            "理由待寫入": bool(reasons) and cr.needs_refresh(folder),
            "問題": "", "結論": "", "本次未修改": os.path.isfile(os.path.join(folder, RESULT_DIR, "本次未修改.txt"))}
    if moved:
        import publish_round as pr
        done = (pr.load_record(root).get("規章") or {}).get(name) or {}
        current = (_sources_of(folder) or {}).get("舊版", "")
        if done and os.path.isfile(done.get("現行規章", "")) and dt.file_sha256(done["現行規章"]) == done.get("SHA256"):
            moved = "已經發布（新版已經換成現行規章）"
        elif current and not os.path.isfile(current) and done:
            moved = "已經發布（新版已經換成現行規章）"
        info.update(階段="重跑開始", 問題=moved)
        return info
    try:
        rows = dt.read_table(table)
    except dt.DecisionTableError as exc:
        info.update(階段="填表", 問題="決定表有錯：%s" % exc)
        return info
    # 套用過沒有（驗收要的是乾淨版）、套用之後表又改過沒有：「跑錯站」要用，站別還沒判斷就先算
    clean = locate(folder, "新版_定稿_乾淨版.docx")[0]
    info["已套用"] = os.path.isfile(clean)
    info["表較新"] = info["已套用"] and _mtime(table) > _mtime(clean)
    info["AI審查"] = _ai_review_state(root, folder, table, rows)
    if info["AI審查"] != "done":
        info["階段"] = "AI審查"
        return info
    undecided = [r for r in rows if not (r.get("要改嗎") or "").strip()]
    info["沒決定"] = len(undecided)
    info["可核准"] = sum(1 for r in undecided if ap.rule_for(r))
    info["待確認"] = len(ri.pending_confirmations(folder))
    tracked = locate(folder, "新版_定稿.docx")[0]
    report = locate(folder, "終比對驗收報告.txt")[0]
    verify = locate(folder, "修訂驗證.json")[0]
    if info["沒決定"] or info["待確認"]:
        info["階段"] = "填表"
    elif not os.path.isfile(tracked) or _mtime(table) > _mtime(tracked):
        info["階段"] = "套用"
    else:
        checked = {}
        if os.path.isfile(verify):
            with io.open(verify, encoding="utf-8") as f:
                checked = json.load(f)
        if checked and not checked.get("通過") and _mtime(report) < _mtime(verify):
            # 驗證沒過、還沒驗收：人工待辦叫人用 Word 看，看完跑 繼續（驗收）。驗收跑在驗證之後就當看過了，
            # 不然這一本永遠停在「看修訂」
            info.update(階段="看修訂", 問題="；".join(checked.get("問題") or []))
        elif not os.path.isfile(report) or _mtime(tracked) > _mtime(report):
            info["階段"] = "驗收"
        else:
            with io.open(report, encoding="utf-8-sig") as f:
                verdict = [line.strip() for line in f if line.startswith("結論：")]
            info["結論"] = verdict[-1] if verdict else ""
            if info["結論"].startswith("結論：改好"):
                info["階段"] = "送簽前"
            elif info["結論"].startswith("結論：三問皆零"):
                info["階段"] = "看警告"      # 只剩警告：人工確認表回覆看過，再跑一次驗收就改好
            else:
                info["階段"] = "驗收沒過"
    return info


def _plain_cmd(name, *parts):
    return " ".join(["python scripts/run_all.py", name] + [p for p in parts if p])


def statuses_of(root):
    import fill_sync as fs
    return [s for s in (book_status(root, n) for n in fs.book_names(root)) if s]


def workspace_of(root):
    """產出根目錄是工作區的 產出/ 就回工作區根目錄，不是回 None。"""
    parent = os.path.dirname(os.path.abspath(root))
    if os.path.basename(os.path.normpath(root)) == "產出" and os.path.isdir(os.path.join(parent, "匯入")):
        return parent
    return None


def _semantic_back(root):
    """語意交換包帶回來了嗎：(算好的規章 list, 錯誤訊息)。"""
    import semantic_exchange as se
    from _common import SYSTEM_DIR
    try:
        found = se.returned(os.path.join(root, SYSTEM_DIR, "語意候選"), workspace_of(root))
    except se.ExchangeError as exc:
        return [], str(exc)
    return (found[1] if found else []), ""


# 比對報告 skill（繼續 --到報告）留下的記號：工作區在「只看報告」的模式。
# 人工待辦這時候叫人跑的是 繼續 --到報告，報告做完就講「報告完成，要改換 reg-edit」，
# 不會叫人核准、套用（那是 reg-edit 的事）。reg-edit 的指令一跑就收掉這個記號。
IDLE = ("匯入/修訂規章/ 是空的：這一輪沒有要比對的修訂版（簽核回來、核定版放回現行規章、修訂版拿掉之後就是這樣）。"
        "有規格包的本先用 reg-baseline（建基準）重建規格包；下一輪把要修的修訂版放進 匯入/修訂規章/，用 reg-report 跑 繼續 --到報告")
REPORT_MARK = ".報告模式"
REPORT_DONE = ("比對報告已經完成：報告在 產出/結果彙整/檢視報告.xlsx、產出/審閱文件/LLM審查總表.xlsx、"
               "產出/審閱文件/批次摘要.txt。看完都不用跟著改就到此為止；要跟著改，換 reg-edit（修改文本）："
               "填 產出/填寫表單/連帶決定表.csv（AI 建議明確的列可以核准）、人工確認表，再跑 繼續")


def _report_mark(root):
    # 放在工作區根目錄（產出/ 的上一層）：放在 產出/系統檔案/ 的話，單獨跑「開始」歸檔上一輪時會被搬走
    return os.path.join(os.path.dirname(os.path.abspath(root)), REPORT_MARK)


def report_mode(root):
    return os.path.isfile(_report_mark(root))


def set_report_mode(root, on):
    path = _report_mark(root)
    try:
        if on:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with io.open(path, "w", encoding="utf-8") as f:
                f.write("比對報告模式（reg-report 的 繼續 --到報告）。reg-edit 的指令會收掉這個檔。\n")
        elif os.path.isfile(path):
            os.remove(path)
    except OSError:
        pass


def build(root, ws="", cmd=None, statuses=None, report_only=None):
    """回傳 (清單全文, 畫面要印的幾行)。ws：印出來的指令要不要帶 --workspace。
    cmd：印指令的那一支（run_all._cmd，由呼叫端傳進來——這裡 import run_all 會拿到
    regdiff 底下同名的那一支）。report_only：比對報告模式（沒給就看工作區的記號）。"""
    _cmd = cmd or _plain_cmd
    if report_only is None:
        report_only = report_mode(root)
    import publish_round as pr
    record = pr.published_state(root, workspace_of(root))
    if record:
        return _published_text(record, _cmd("繼續", ws))
    if statuses is None:
        statuses = statuses_of(root)
    workspace = workspace_of(root)
    if workspace:
        import workspace as wsm
        if not wsm.list_inputs(wsm.paths(workspace)["新版"])[0]:
            lines = ["人工待辦（%s）" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "", IDLE, "",
                     "所有產出都是輔助，最終仍需人工複核後才能送出。"]
            return "\n".join(lines) + "\n", ["", SCREEN_HEADER, "  1. " + IDLE]
    if not statuses:
        return "", []
    go = _cmd("繼續", ws, "--到報告") if report_only else _cmd("繼續", ws)
    stage = min(STAGES.index(s["階段"]) for s in statuses)
    now = []

    def books(key):
        return "、".join("%s %d" % (s["規章"], s[key]) for s in statuses if s[key])

    undecided = sum(s["沒決定"] for s in statuses)
    approvable = sum(s["可核准"] for s in statuses)
    pending = sum(s["待確認"] for s in statuses)
    moved = [s for s in statuses if s["階段"] == "重跑開始"]
    for s in moved:
        now.append("%s：%s：跑 %s（會重跑開始；已填的決定、AI 判過的答案、人工確認的回覆都會依內容帶回來）"
                   % (s["規章"], s["問題"], go))
    semantic = [] if moved else semantic_pending(root)
    if semantic:
        # 語意比對要在 AI 審查之前：語意找到的新列也要 AI 判
        back, problem = _semantic_back(root)
        if back:
            now.append("語意交換包已經算好帶回來了（%s）：跑 %s 併入" % ("、".join(back), go))
        else:
            now.append("語意比對還沒做（這台電腦沒有模型，%d 本）：把 產出/系統檔案/語意候選/語意交換包.zip 帶到"
                       "有模型的電腦跑一行（指令在 產出/審閱文件/批次摘要.txt 最後），帶回來放回原位或放進 匯入/，"
                       "再跑 %s；這一輪不做就跑 %s"
                       % (len(semantic), go, _cmd("語意併入", ws, "--略過")))
            if problem:
                now.append(problem)
    reviewing = [] if (moved or semantic) else [s for s in statuses if s["階段"] == "AI審查"]
    if reviewing:
        if any(s["AI審查"] == "todo" for s in reviewing):
            now.append("AI 審查：跑 %s（產審查包），AI 讀 產出/系統檔案/AI審查/先讀我.md、填好那裡的四張 AI 表後"
                       "再跑 %s；這一輪不用 AI 就跑 %s" % (go, go, _cmd("審查打包", ws, "--略過")))
        else:
            now.append("AI 審查包已經產生（%s）：AI 讀 產出/系統檔案/AI審查/先讀我.md，填好那裡的四張 AI 表"
                       "（第一欄是規章）後跑 %s" % ("、".join(s["規章"] for s in reviewing), go))
    errors = [s for s in statuses if s["問題"] and s["階段"] == "填表"]
    for s in errors:
        now.append("%s：%s" % (s["規章"], s["問題"]))
    if moved or semantic or reviewing:
        undecided = approvable = pending = 0          # 前面的站還沒過：先做那幾件
    report_done = report_only and not (moved or semantic or reviewing)
    if report_done:
        # 比對報告做完了：不叫人填表、核准、套用（那是 reg-edit 的事），只講報告在哪、要改換哪個 skill
        undecided = approvable = pending = 0
        now.append(REPORT_DONE)
    if undecided:
        line = "決定表還有 %d 列沒決定（%s）：產出/填寫表單/連帶決定表.csv 填「要改嗎」" % (undecided, books("沒決定"))
        if approvable:
            line += ("；其中 %d 列 AI 建議很明確，照規則會怎麼決定寫在 產出/審閱文件/核准預覽.txt，"
                     "使用者看過說好就跑 %s（剩下的再填）" % (approvable, _cmd("核准", ws)))
        now.append(line)
    if pending:
        now.append("人工確認還有 %d 列沒結案（%s）：產出/填寫表單/人工確認.csv 的「人工確認」欄填「已確認」"
                   "（AI 查不到答案的異動、條文檢查高風險、外部引用；寫了處理方式的，處理好也要改成「已確認」）"
                   % (pending, books("待確認")))
    if undecided or pending:
        now.append("填完跑 %s（套用、驗收一次跑完）" % go)
    if not now:
        if STAGES[stage] == "套用":
            now.append("決定都填完了：跑 %s（套用、驗收一次跑完）" % go)
        elif STAGES[stage] == "看修訂":
            for s in statuses:
                if s["階段"] == "看修訂":
                    now.append("%s 的修訂自動驗證沒過（%s）：用 Word 開 產出/填寫表單/%s_新版_定稿.docx 看修訂"
                               % (s["規章"], s["問題"], s["規章"]))
            now.append("看完跑 %s（驗收）" % go)
        elif STAGES[stage] == "驗收":
            now.append("修訂已套用：跑 %s（驗收）" % go)
        elif STAGES[stage] == "驗收沒過":
            for s in statuses:
                if s["階段"] == "驗收沒過":
                    now.append("%s：%s（產出/系統檔案/%s/審閱文件/終比對驗收報告.txt）"
                               % (s["規章"], s["結論"], s["規章"]))
        elif STAGES[stage] == "看警告":
            waiting = [s for s in statuses if s["階段"] == "看警告" and s["警告待確認"]]
            for s in waiting:
                now.append("%s：驗收只剩 %d 則警告要看過：看檢視報告的「提醒」表，到 產出/填寫表單/人工確認.csv "
                           "類別「警告」那幾列回覆「已確認」" % (s["規章"], s["警告待確認"]))
            now.append("%s跑 %s（結論就會是改好）" % ("回覆完" if waiting else "警告都看過了：", go))
        elif STAGES[stage] == "送簽前":
            refresh = [s["規章"] for s in statuses if s.get("理由待寫入")]
            if refresh:
                now.append("修正對照表補了修改依據（%s）：跑 %s，程式重產對照表，Word 版跟著寫進去"
                           % ("、".join(refresh), go))
    later = []
    warned = sum(s["警告"] for s in statuses)
    if warned:
        later.append("警告 %d 則（%s）：檢視報告的「提醒」表" % (warned, books("警告")))
    fill = sum(s["請補"] or 0 for s in statuses)
    drafted = sum(s["草擬"] for s in statuses)
    # 驗收之前不講修改依據：驗收才草擬，這時候叫人補只會補到初比對那一張（驗收完就換掉了）
    if fill:
        files = "、".join("%s_修正對照表.xlsx（%d 列）" % (s["規章"], s["請補"]) for s in statuses if s["請補"])
        later.append("修正對照表還有 %d 列寫「請補修正理由」：在 產出/結果彙整/修正對照表/ 的 %s「修改依據／理由」那一欄補上，"
                     "跑 %s 會寫進 Word 版" % (fill, files, go))
    if drafted:
        later.append("修正對照表已經寫了修改依據的 %d 列看過一遍（含程式草擬的與上一版人補的；xlsx 最後一欄是依據來源）" % drafted)
    later.append("送簽前抽一本用 Word 打開新版定稿看版面")
    if STAGES[stage] == "送簽前":
        import glob
        drafts = glob.glob(os.path.join(root, "結果彙整", "公文草稿", "*_簽稿草稿.docx"))
        if drafts:
            later.append("簽稿草稿已經產生（%d 份，產出/結果彙整/公文草稿/）：依據（函文字號）、生效日期要人填" % len(drafts))
        else:
            later.append("（選用）要簽稿草稿就跑 %s：產出/結果彙整/公文草稿/<規章名>_簽稿草稿.docx" % _cmd("公文", ws))
        # 不再叫人跑「發布」：送簽回來的核定版可能又改過，以那一份為準，由人自己換（三個 skill 拆分後的做法）
        import glob
        finals = sorted(os.path.basename(f)[:-len("_新版定稿_乾淨版.docx")] for f in glob.glob(
            os.path.join(root, RESULT_DIR, "新版定稿（乾淨版）", "*_新版定稿_乾淨版.docx")))
        later.append("簽核回來之後：把核定版放進 匯入/現行規章/（檔名照舊、取代舊版）——有新版定稿的每一本都要換：%s"
                     "（含只因連帶被改、沒有修訂版的本）；匯入/修訂規章/ 的修訂版拿掉；"
                     "有規格包的本再用 reg-baseline（建基準）重建規格包" % ("、".join(finals) or "（看 產出/結果彙整/新版定稿（乾淨版）/）"))

    if report_only:
        later = [x for x in later if x.startswith("警告")]      # 送簽前的事是 reg-edit 的，報告模式不講
    header = ("現在要做" if STAGES[stage] != "送簽前" else "全部改好了，送簽前還要做")
    lines = ["人工待辦（%s）" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), ""]
    def where(s):
        # 語意比對是整批一站、排在 AI 審查前面：還沒做時各本也寫「語意比對」，跟「現在要做」對得上
        return "語意比對" if semantic and s["階段"] == "AI審查" else s["階段"]
    lines.append("各本走到哪：" + "、".join("%s（%s）" % (s["規章"], where(s)) for s in statuses))
    lines.append("")
    if now:
        lines.append(header + "：")
        lines += ["  %d. %s" % (i, x) for i, x in enumerate(now, 1)]
        lines.append("")
    if later:
        lines.append("送簽前還要看：" if now else header + "：")
        lines += ["  - " + x for x in later]
    lines += ["", "所有產出都是輔助，最終仍需人工複核後才能送出。"]
    screen = ["", SCREEN_HEADER]
    screen += ["  %d. %s" % (i, x) for i, x in enumerate(now or later[:1], 1)]
    return "\n".join(lines) + "\n", screen


def _published_text(record, go):
    """這一輪發布過了（還沒放下一輪的修訂版）：人工待辦只講這件事。"""
    names = sorted(record.get("規章") or {})
    lines = ["人工待辦（%s）" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "",
             "這一輪已經發布（%s）：%s 的新版已經換成 匯入/現行規章 裡的那一份；換下來的舊版與修訂版在 產出/%s。"
             % (record.get("時間", ""), "、".join(names), (record.get("備份") or "").replace(os.sep, "/")),
             "", "下一輪：",
             "  1. 把要修的修訂版放進 匯入/修訂規章/，跑 %s" % go,
             "  2. 有規格包的本，先跑 %s 重建規格包（不用 Word；停在複核表，填完再跑一次就發布）" % go.replace("繼續", "建基準"),
             "", "所有產出都是輔助，最終仍需人工複核後才能送出。"]
    screen = ["", SCREEN_HEADER,
              "  1. 這一輪已經發布；下一輪把要修的修訂版放進 匯入/修訂規章/，跑 %s" % go]
    return "\n".join(lines) + "\n", screen


def refresh(root, ws="", cmd=None):
    """重寫 產出/審閱文件/人工待辦.txt，回傳畫面要印的幾行。填表那一站順手寫 核准預覽.txt。"""
    statuses = statuses_of(root)
    text, screen = build(root, ws, cmd, statuses)
    if not text:
        return []
    with io.open(place(root, FILE), "w", encoding="utf-8-sig") as f:
        f.write(text)
    _approve_preview(root, statuses, (cmd or _plain_cmd)("核准", ws))
    return screen


def _approve_preview(root, statuses, command):
    """核准預覽.txt：走到填表那一站、而且有 AI 建議很明確的列才寫；其他時候拿掉（還沒 AI 審查就看預覽，
    會讓人以為可以先核准）。"""
    import approve as ap
    import decision_table as dt
    path = place(root, ap.PREVIEW_FILE)
    ready = (statuses and not semantic_pending(root)
             and all(s["階段"] not in ("重跑開始", "AI審查") for s in statuses)
             and any(s["可核准"] for s in statuses))
    tables = []
    if ready:
        for s in statuses:
            if not s["可核准"]:
                continue
            try:
                tables.append((s["規章"], dt.read_table(locate(book_dir(root, s["規章"]), "連帶決定表.csv")[0])))
            except dt.DecisionTableError:
                continue
    ap.write_preview(path, tables, command)


def _manifest_key(path):
    """清單的內容（規章名、舊版、新版草稿、發布根目錄；配對方式、備註不算）：比「人改過清單沒有」用。"""
    from _common import open_csv
    try:
        with open_csv(path) as f:
            return sorted(tuple((r.get(k) or "").strip() for k in ("規章名", "舊版", "新版草稿", "發布根目錄"))
                          for r in csv.DictReader(f))
    except (OSError, UnicodeDecodeError, csv.Error, ValueError):
        return None


def order_problem(root, command):
    """這個批次指令現在跑，是不是跑錯站：回傳 (擋不擋, 一句話) 或 None。
    會出錯、會誤導的才擋（還沒打包就匯入、還沒套用就驗收、套用之後表又改過還驗收舊的定稿）；
    只是順序不理想的講一聲照跑（AI 審查沒做完就套用、還有沒決定的列就套用）。"""
    statuses = statuses_of(root)
    if not statuses:
        return True, "還沒有這一輪的比對結果：先跑 繼續（或 開始）"
    moved = [s for s in statuses if s["階段"] == "重跑開始"]
    if moved:
        return True, "%s：%s，這一輪的結果已經過期：先跑 繼續（會重跑開始）" % (moved[0]["規章"], moved[0]["問題"])
    stage = STAGES[min(STAGES.index(s["階段"]) for s in statuses)]
    semantic = semantic_pending(root)
    if command == "batch-review-pack" and semantic:
        return False, "語意比對還沒併入（%d 本）：語意找到的列這次不會進審查包，併入之後要再打包一次" % len(semantic)
    if command == "batch-review-import" and stage == "AI審查" and all(
            s.get("AI審查") == "todo" for s in statuses if s["階段"] == "AI審查"):
        return True, "還沒產審查包：先跑 繼續（會產審查包），AI 填好 產出/系統檔案/AI審查/ 的表再匯入"
    if command == "batch-apply":
        if stage == "AI審查" or semantic:
            return False, ("AI 審查還沒做完就套用：AI 還沒判的列沒有建議可以參考"
                           "（這一輪不做 AI 審查，照人工待辦先跑 審查打包 --略過）")
        undecided = sum(s["沒決定"] for s in statuses)
        pending = sum(s["待確認"] for s in statuses)
        if undecided or pending:
            return False, ("決定表還有 %d 列沒決定、人工確認還有 %d 列沒結案：沒決定的列這次不會改，驗收會列出來"
                           % (undecided, pending))
    if command == "batch-finalize":
        if not any(s.get("已套用") for s in statuses):
            return True, "還沒套用：先跑 繼續（套用、驗收一次跑完）"
        stale = [s["規章"] for s in statuses if s.get("表較新")]
        if stale:
            return False, ("%s 的決定表在套用之後又改過：這次驗收的是舊的定稿；要驗新的決定，先跑 繼續（重新套用、再驗收）"
                           % "、".join(stale))
    if command == "approve" and stage == "AI審查":
        return False, "AI 審查還沒匯入：這次只會核准機械性換號的列，AI 的建議要等 繼續 匯入之後才算得進來"
    return None


def next_step(root, workspace_root=None):
    """「繼續」下一步跑什麼（跟人工待辦同一套判斷）：{"指令": 子命令名或 None, "說明": 一句話}。
    指令是 None＝這一站要人（或 AI）動手；說明講停在哪一站，細節照人工待辦。
    batch-review-import 那一站多帶 "先看AI"：呼叫端要先確認 AI 把表填完了才匯入。"""
    import fill_sync as fs
    import publish_round as pr
    if workspace_root and pr.published_state(root, workspace_root):
        return {"指令": None, "說明": "這一輪已經發布：下一輪把要修的修訂版放進 匯入/修訂規章/ 再跑 繼續"}
    if workspace_root:
        import workspace as wsm
        p = wsm.paths(workspace_root)
        if not wsm.list_inputs(p["新版"])[0]:
            # 沒有發布這一站之後，「這一輪結束了」就看修訂規章是不是空的（簽核回來、修訂版拿掉了）。
            # 以前這裡會回「開始」，開始跑完還是沒有比對結果，繼續就一直重跑開始、一直歸檔
            return {"指令": None, "說明": IDLE}
        if not os.path.isfile(p["清單"]):
            if wsm.list_inputs(p["舊版"])[0] or wsm.list_inputs(p["新版"])[0]:
                return {"指令": "開始", "說明": "第一次跑：配對、初比對"}
            return {"指令": None, "說明": "匯入/現行規章、匯入/修訂規章 還沒有規章檔：先把檔放進去"}
        try:
            reasons = wsm.stale_reasons(wsm.read_manifest_rows(p["清單"]), workspace_root)
        except wsm.WorkspaceError as exc:
            reasons = [str(exc)]
        if reasons:
            return {"指令": "開始", "說明": "匯入/ 的檔跟清單不一樣（%s）：重新配對、初比對" % reasons[0]}
        # 人改了清單（修正配對、補發布根目錄）但檔沒動：跟上一次開始用的那一份比
        from _common import SYSTEM_DIR
        staged = os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv")
        if os.path.isfile(staged) and _manifest_key(p["清單"]) != _manifest_key(staged):
            return {"指令": "開始", "說明": "匯入/規章清單.csv 改過了：照新的清單重跑開始"}
    statuses = statuses_of(root) if fs.is_batch_root(root) else []
    if not statuses:
        return {"指令": "開始" if workspace_root else None, "說明": "還沒有這一輪的比對結果"}
    moved = [s for s in statuses if s["階段"] == "重跑開始"]
    if moved:
        return {"指令": "開始", "說明": "%s：%s：重跑開始" % (moved[0]["規章"], moved[0]["問題"])}
    if semantic_pending(root):
        back, problem = _semantic_back(root)
        if back:
            return {"指令": "batch-semantic", "說明": "語意交換包帶回來了：併入"}
        return {"指令": None, "說明": problem or "語意比對還沒做：到有模型的電腦算，或這一輪略過"}
    stage = STAGES[min(STAGES.index(s["階段"]) for s in statuses)]
    if stage == "AI審查":
        if any(s["AI審查"] == "todo" for s in statuses if s["階段"] == "AI審查"):
            return {"指令": "batch-review-pack", "說明": "AI 審查：產審查包"}
        return {"指令": "batch-review-import", "說明": "AI 審查：匯入 AI 填好的表", "先看AI": True}
    if any(s["問題"] and s["階段"] == "填表" for s in statuses):
        return {"指令": None, "說明": "決定表有錯，要人改"}
    if stage == "填表":
        return {"指令": None, "說明": "填表：決定表「要改嗎」、人工確認「已確認」要人填"}
    if stage == "套用":
        return {"指令": "batch-apply", "說明": "套用（接著驗收）"}
    if stage == "看修訂":
        return {"指令": "batch-finalize", "看修訂": True,
                "說明": "修訂自動驗證沒過：用 Word 開 新版_定稿.docx 看修訂，看完跑 繼續 驗收"
                        "（驗收會把這一則列進人工確認表，填「已確認」才算改好）"}
    if stage == "驗收":
        return {"指令": "batch-finalize", "說明": "驗收"}
    if stage == "看警告":
        if any(s["警告待確認"] for s in statuses):
            return {"指令": None, "說明": "驗收只剩警告：人工確認表的警告列要人看過、填「已確認」"}
        return {"指令": "batch-finalize", "說明": "警告都看過了：再驗收一次"}
    if stage == "驗收沒過":
        return {"指令": None, "說明": "驗收沒過：照驗收報告處理"}
    if any(s.get("理由待寫入") for s in statuses):
        return {"指令": "batch-finalize", "說明": "修正對照表補了修改依據：重產對照表（Word 版跟著寫進去）"}
    return {"指令": None, "說明": "全部改好了：送簽前還要看的見人工待辦"}
