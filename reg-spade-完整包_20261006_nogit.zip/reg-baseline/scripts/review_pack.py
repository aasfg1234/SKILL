# -*- coding: utf-8 -*-
"""
第 1.5 步：把候選與異動打包成「審查包」給 AI 看。

程式篩（相似、關鍵詞、句子、文脈、語意、跨本）只會「列」，不會「判」。
這支把每一筆候選、每一處異動連同前後文一次組好，讓 AI 判斷時「候選段全文、
異動段新舊文、兩邊的前後文」三樣一起看，不必自己東翻西找。

AI 只寫判斷，不填「要改嗎」「改成什麼」——那兩欄仍是人的決定，見 review-import。
"""

import csv
import glob
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import notices as nt
from _common import (SUPPORTED_EXTS, build_hierarchy, diff_runs, format_scope, locate,
                     display_ref, place, read_paragraphs, read_paragraphs_with_kinds)


class ReviewPackError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 前後文範圍
# ---------------------------------------------------------------------------

# 要點的「一、」那一層 build_hierarchy 寫成「第三點」（見 _common._use_point_refs），一樣當成一款
_CLAUSE_KEY_RE = re.compile(r"^(.*?款|第[^第]+?點)")


def _clause_key(ctx):
    """從 ref 取出「…款」為止的前綴，款頭本身跟它底下的目共用同一把鑰匙。"""
    match = _CLAUSE_KEY_RE.match(ctx.get("ref") or "")
    return match.group(1) if match else ""


def _same(ctx, key, val):
    if key == "article":
        return ctx.get("article") == val
    return _clause_key(ctx) == val


_MAX_WINDOW = 15  # 包大小保底：不管哪一種規則，單側最多只給 15 段


def context_range(contexts, index0, fallback=3, max_window=_MAX_WINDOW):
    """算前後文範圍：有條→整條＋條外前後各 1 段；無條有款→整款＋款外前後各 1 段；
    都沒有→前後各 fallback 段。回傳 (start0, end0, label)：start0/end0 給 range() 直接用
    （end0 不含）；label 是實際套用的規則，要印在「前後文（新版，<label>）」那行。

    max_window：單側最多幾段（預設 _MAX_WINDOW＝15）。write_pack 遇到「單一候選
    區塊本身就超過 --max-chars」時會傳 3 進來重算，把那個候選的前後文縮小
    （見 write_pack 的 _SHRUNK_WINDOW）。

    「整款」判斷靠 ref 裡「…款」那段前綴（_clause_key）。款底下的「1.」「2.」子標題
    現在由 build_hierarchy 標成「點」層（ref 帶「第1點」），掃款不會再被它截斷；
    但仍有真的沒有任何條號的段落（例如條款之外的獨立小標），ref 是空字串、
    level「其他」，掃款的迴圈碰到就會停下來。停在那種段落時把 label 換成
    「同一群（款內）」，讓人知道這個範圍可能沒有涵蓋到整款、只是同一小群。
    """
    ctx = contexts[index0]
    if ctx.get("article"):
        key, val = "article", ctx["article"]
        label = "整條＋前後各 1 段"
        start = index0
        while start > 0 and _same(contexts[start - 1], key, val):
            start -= 1
        end = index0 + 1
        while end < len(contexts) and _same(contexts[end], key, val):
            end += 1
        start0, end0 = max(0, start - 1), min(len(contexts), end + 1)
    elif ctx.get("level") in ("款", "目"):
        key, val = "clause_key", _clause_key(ctx)
        label = "整款＋前後各 1 段"
        start = index0
        while start > 0 and _same(contexts[start - 1], key, val):
            start -= 1
        end = index0 + 1
        while end < len(contexts) and _same(contexts[end], key, val):
            end += 1
        cut_short = ((start > 0 and not contexts[start - 1].get("ref")) or
                    (end < len(contexts) and not contexts[end].get("ref")))
        if cut_short:
            label = "同一群（款內）＋前後各 1 段"
        start0, end0 = max(0, start - 1), min(len(contexts), end + 1)
    else:
        label = "前後各 %d 段" % fallback
        start0 = max(0, index0 - fallback)
        end0 = min(len(contexts), index0 + fallback + 1)

    capped = False
    if index0 - start0 > max_window:
        start0 = index0 - max_window
        capped = True
    if (end0 - 1) - index0 > max_window:
        end0 = index0 + max_window + 1
        capped = True
    start0 = max(0, start0)
    end0 = min(len(contexts), end0)
    if capped:
        label += "（已截到前後各 %d 段）" % max_window
    return start0, end0, label


# ---------------------------------------------------------------------------
# 逐字標記新舊差異
# ---------------------------------------------------------------------------

def mark_diff(old_text, new_text):
    """把新舊文字的差異標成〔刪：x〕〔加：x〕，其餘照抄。"""
    out = []
    for kind, text in diff_runs(old_text or "", new_text or ""):
        if kind == "delete":
            out.append("〔刪：%s〕" % text)
        elif kind == "insert":
            out.append("〔加：%s〕" % text)
        else:
            out.append(text)
    return "".join(out)


# ---------------------------------------------------------------------------
# 讀某次 compare 的產出：候選、異動、新舊版全文
# ---------------------------------------------------------------------------

def staged_file_by_sha(inputs_dir, sha, preferred=None):
    """輸入/ 裡內容（SHA-256）等於 sha 的那一份留底；preferred 對得上就用它，找不到回 None。

    留底檔名會因角色前綴、舊排法、apply 另外留的一份而不同，而且同名的留底會被之後的
    stage_inputs 覆寫（finalize 在同一個產出資料夾留乾淨版、中途失敗的 compare 重跑），
    輸入指紋.json 也跟著改——檔名與輸入指紋都當不了憑據。憑據是決定表指紋檔記的 SHA：
    這張表是對哪一份算的，就只認那一份。finalize 的對位檢查與這裡的審查包共用這一支。
    """
    if not sha or not os.path.isdir(inputs_dir):
        return None
    if preferred and os.path.isfile(preferred) and dt.file_sha256(preferred) == sha:
        return preferred
    for name in sorted(os.listdir(inputs_dir)):
        path = os.path.join(inputs_dir, name)
        if os.path.isfile(path) and os.path.splitext(name)[1].lower() != ".json" \
                and dt.file_sha256(path) == sha:
            return path
    return None


def load_book(outdir):
    """讀 <outdir> 這次 compare（或 batch 某一本）的候選表、異動清單、新舊版全文。
    找不到該有的檔案就 ReviewPackError，不猜、不補。"""
    # 讀端一律走 locate：新排法（<outdir>/填寫表單、系統檔案）優先，找不到再看
    # 舊排法（檔案平鋪在 outdir）。這一步是接在 compare 後面跑的，使用者手上
    # 可能還有上一版程式產出的資料夾。
    csv_path = locate(outdir, "連帶決定表.csv")[0]
    changes_path = locate(outdir, "異動清單.json")[0]
    inputs_dir = locate(outdir, "輸入")[0]
    fingerprint_path = os.path.join(inputs_dir, "輸入指紋.json")
    if not os.path.isfile(csv_path):
        raise ReviewPackError("找不到連帶決定表：%s（請先跑 compare）" % csv_path)
    if not os.path.isfile(changes_path):
        raise ReviewPackError("找不到異動清單：%s（請先跑 compare）" % changes_path)
    if not os.path.isfile(fingerprint_path):
        raise ReviewPackError("找不到輸入指紋檔：%s" % fingerprint_path)

    try:
        rows = dt.read_table(csv_path)
    except dt.DecisionTableError as exc:
        raise ReviewPackError(str(exc))
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        raise ReviewPackError("連帶決定表讀不出來（%s）；請重跑 compare" % exc)

    try:
        with io.open(changes_path, encoding="utf-8") as f:
            changes = json.load(f)
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        raise ReviewPackError("異動清單.json 讀不出來（%s）；請重跑 compare" % exc)

    try:
        sidecar = dt.read_sidecar(dt.sidecar_path_for(csv_path))
    except dt.DecisionTableError as exc:
        raise ReviewPackError(str(exc))
    draft_name = (sidecar.get("草稿") or {}).get("檔名", "")
    if not draft_name:
        raise ReviewPackError("指紋檔沒有草稿檔名：%s" % dt.sidecar_path_for(csv_path))

    try:
        with io.open(fingerprint_path, encoding="utf-8-sig") as f:
            fingerprint = json.load(f)
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        raise ReviewPackError("輸入指紋.json 讀不出來（%s）；請重跑 compare" % exc)
    # no 1：留底檔名照 SUPPORTED_EXTS 篩，不是只認 .docx。compare 早就吃得下
    # .txt／.md 了，這裡若只撿 .docx，草稿是 .txt 的那幾本會在第 1.5 步被擋成
    # 「找不到草稿檔」——使用者會以為檔案掉了，其實是這個步驟自己不認格式。
    # （角色、比對參數這些非檔名的鍵沒有支援的副檔名，自然被篩掉。）
    input_names = sorted(n for n in fingerprint
                         if os.path.splitext(n)[1].lower() in SUPPORTED_EXTS)
    roles = fingerprint.get("角色") or {}
    if roles.get("舊版"):
        # 新版留底（run_all.stage_inputs 的角色留底）：舊版直接照角色取，不用猜。
        # 草稿要取「新版_<草稿檔名>」而不是角色表上的「新版」：finalize 會拿 apply
        # 產出的乾淨版再 stage 一次，角色表的「新版」那時已經指向乾淨版了，但
        # review-pack 要看的仍然是這張決定表對應的那份草稿。
        old_name = roles["舊版"]
        draft_staged = "新版_" + draft_name
        if draft_staged not in fingerprint:
            draft_staged = roles.get("新版") or ""
        missing = [n for n in (old_name, draft_staged)
                   if not n or not os.path.isfile(os.path.join(inputs_dir, n))]
        if missing:
            raise ReviewPackError(
                "輸入/ 裡找不到角色留底的檔案：%s（請重跑 compare）"
                % "、".join(m or "（缺新版）" for m in missing))
        old_path = os.path.join(inputs_dir, old_name)
        draft_path = os.path.join(inputs_dir, draft_staged)
    else:
        # 這個功能之前產生的產出資料夾：留底照原檔名，只能用「哪一個不是草稿」去猜。
        # 猜得出來就往下走，但一定要講一聲——舊新同檔名時舊版早就被蓋掉了，
        # 這裡讀到的「舊版」其實是草稿，刪除段的前後文會整段對錯人。
        if draft_name not in input_names:
            raise ReviewPackError("輸入指紋.json 裡找不到草稿檔：%s" % draft_name)
        old_names = [n for n in input_names if n != draft_name]
        if len(old_names) == 0 and len(input_names) == 1:
            # batch 遇到「沒有草稿，用舊版當草稿」的本（見 batch.read_manifest 的「有草稿」欄），
            # 新舊版其實是同一個檔；舊式留底用 basename 當指紋鍵，同一個檔名只留一筆，
            # 輸入指紋.json 因此只剩一個輸入檔。這裡不當成缺檔，新舊版都指到同一份。
            old_names = [draft_name]
        elif len(old_names) != 1:
            # finalize 用同一個 outdir 再跑一次時，args.new_file 常常是 apply 產出的
            # 「新版_定稿_乾淨版.docx」，跟原本的草稿檔名不同，stage_inputs 會把它也留在
            # 輸入/ 底下，「輸入/」因此多出第三個輸入檔。這不是「舊版＋草稿」以外的第三本，
            # 是同一輪流程的終稿，先排除檔名含「定稿」「乾淨版」的檔（跟排除 draft_name
            # 是同一件事：都是「這不是要挑的舊版」），剩一個才用；還是不只一個才真的報錯。
            filtered = [n for n in old_names if "定稿" not in n and "乾淨版" not in n]
            if len(filtered) == 1:
                old_names = filtered
            else:
                raise ReviewPackError(
                    "輸入指紋.json 裡的輸入檔不是「舊版＋草稿」各一份：%s" % input_names)
        nt.notice(nt.REMINDER,
                  "這個產出資料夾是舊式留底（輸入指紋.json 沒有「角色」），舊版是用檔名猜的"
                  "（猜成 %s）%s；舊新同檔名時舊版其實早就被新版蓋掉了，"
                  "刪除段的前後文可能不是舊版的。要確定的話請重跑 compare"
                  % (old_names[0],
                     "，而且新舊版指到同一份" if old_names[0] == draft_name else ""),
                  "審查包")
        old_path = os.path.join(inputs_dir, old_names[0])
        draft_path = os.path.join(inputs_dir, draft_name)
    # 留底要是「這張決定表當初對的那一份」才能用：審查包的前後文、異動段的新舊文都從
    # 這兩份讀，留底被改過、被之後的 stage_inputs 蓋掉的話，AI 看到的是別的字，
    # 畫面上卻沒有任何一句話講過這件事。憑據是決定表指紋檔記的 SHA（舊版那一筆是
    # 這一版起才記的；更早的指紋檔沒有，退回比輸入指紋.json）。
    legacy = not roles.get("舊版")

    def resolve(label, path, anchor):
        want = (anchor or {}).get("SHA256")
        if want:
            found = staged_file_by_sha(inputs_dir, want, path)
            if found is None and legacy and label == "舊版" and os.path.isfile(path):
                # 舊式留底：舊新同檔名時舊版早就被新版蓋掉了，本來就找不到那一份；
                # 上面已經發過「舊版是用檔名猜的」提醒，照猜的那一份往下走。
                return path
            if found is None:
                raise ReviewPackError(
                    "輸入/ 裡找不到跟決定表指紋相符的%s留底（%s）：留底在 compare 之後被覆寫或"
                    "修改過，審查包不能用它；請重跑 compare" % (label, anchor.get("檔名") or ""))
            return found
        if not os.path.isfile(path):
            raise ReviewPackError("輸入/ 裡找不到%s留底：%s（請重跑 compare）" % (label, path))
        recorded = fingerprint.get(os.path.basename(path))
        if isinstance(recorded, str) and recorded and dt.file_sha256(path) != recorded:
            raise ReviewPackError(
                "輸入/ 的%s留底跟輸入指紋.json 對不上：%s。留底在 compare 之後被改過，"
                "審查包不能用它；請重跑 compare" % (label, os.path.basename(path)))
        return path

    draft_path = resolve("草稿", draft_path, sidecar.get("草稿"))
    old_path = resolve("舊版", old_path, sidecar.get("舊版"))
    try:
        # 連來源種類一起讀：審查包的條號要跟修正對照表一模一樣，
        # 表格儲存格在兩邊都不能被算成前一條的「第X項」。
        old_paragraphs, old_kinds = read_paragraphs_with_kinds(old_path)
        new_paragraphs, new_kinds = read_paragraphs_with_kinds(draft_path)
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        raise ReviewPackError("草稿或舊版讀不出來（%s）；請重跑 compare" % exc)

    return {
        "rows": rows,
        "changes": changes,
        "old_paragraphs": old_paragraphs,
        "new_paragraphs": new_paragraphs,
        "old_contexts": build_hierarchy(old_paragraphs, old_kinds),
        "new_contexts": build_hierarchy(new_paragraphs, new_kinds),
        "draft_name": draft_name,
        # 指紋檔整份帶著走：review-import 要拿裡面每一列的「候選全文SHA256」
        # 驗決定表上的候選全文有沒有被手改過（should_fix no 3）。
        "sidecar": sidecar,
    }


# ---------------------------------------------------------------------------
# 候選列 ←→ 異動清單 對應
# ---------------------------------------------------------------------------

def _change_text_for_match(change):
    """narrow 用：刪除的異動只剩舊文，其餘看新文。"""
    if change.get("修改類型") == "刪除":
        return change.get("old_text") or ""
    return change.get("new_text") or ""


def _find_changes(changes, piece, summary_hint=""):
    """回傳所有比對得上的異動清單項目（可能不只一筆）。

    比對順序：piece == change["ref"]，或 piece 用「、」拆開後跟 change["spec_ids"]
    比對（先找 set 完全相等，沒有再找交集非空），或 piece == "段次 %d" % new_index，
    最後是刪除型的 piece == "舊版段次 %d" % old_index。

    ref 這一階不保證唯一：巢狀「1.」「2.」子標題被 build_hierarchy 當成無法辨識的
    段落，同一款底下好幾個子群組的目次編號會從頭算起，ref 因此重複
    （例如兩組「(1)」都算成「…第一款(1)」）。這裡不去動 build_hierarchy，改用候選列的
    「異動摘要」（新文或舊文前面一截、可能結尾帶「…」）收斂：留下新文／舊文開頭
    對得上摘要的那幾筆；收斂後還是不只一筆，就整批回傳，讓每一筆各自變成一個
    「異動段」小節，交給人／AI 自己比對，不硬猜。

    spec_ids 這一階：有正式基準時決定表的「異動條文ID」是
    「、」.join(spec_ids)（見 baseline_release.change_label），例如
    「A-003、A-003-1」——piece 因此可能一次帶好幾個條文ID，要拆開比對，
    不能整串跟單一異動的 spec_ids 列表做成員比對（永遠對不上）。"""
    def narrow(found):
        """好幾處對得上時用「異動摘要」收斂；收斂不了就全部交給人看，不挑第一處（B16）。"""
        if len(found) > 1 and summary_hint:
            hint = summary_hint[:-1] if summary_hint.endswith("…") else summary_hint
            narrowed = [ch for ch in found if hint and _change_text_for_match(ch).startswith(hint)]
            if narrowed:
                return narrowed
        return found

    by_ref = [ch for ch in changes if piece and piece == (ch.get("ref") or "")]
    if by_ref:
        return narrow(by_ref)
    parts = set(p.strip() for p in piece.split("、") if p.strip()) if piece else set()
    if parts:
        # 同一條兩處異動（第一項、第三項）條文ID 一樣：以前一律對到第一處，
        # 第二處造成的候選拿到的新舊文、指紋都是第一處的
        exact = [ch for ch in changes if parts == set(ch.get("spec_ids") or [])]
        if exact:
            return narrow(exact)
        overlap = [ch for ch in changes if parts & set(ch.get("spec_ids") or [])]
        if overlap:
            return narrow(overlap)
    by_pos = [ch for ch in changes
             if ch.get("new_index") and piece == ("段次 %d" % ch["new_index"])]
    if by_pos:
        return by_pos[:1]
    # 刪除型異動沒有新版段次，決定表的「異動條文ID」寫的是「舊版段次 N」
    # （見 regdiff/run_all.step_duplicates）。少了這一階，無條號文件把一段整段刪掉
    # 之後，候選底下永遠印「找不到對應異動」。
    by_old_pos = [ch for ch in changes
                  if ch.get("old_index") and not ch.get("new_index")
                  and piece == ("舊版段次 %d" % ch["old_index"])]
    if by_old_pos:
        return by_old_pos[:1]
    return []


def changes_for_row(row, book, books=None):
    """把候選列的「異動條文ID」用「；」拆開，逐段找出對應的異動清單項目。
    有「X：」前綴且 X 在 books 裡就到 books[X] 找（跨本）；找不到的片段直接略過。
    回傳 [(book_name, change), ...]；book_name 本本是空字串，跨本是來源本名稱。
    一個片段可能對到不只一筆異動（見 _find_changes），每一筆都各佔一項。"""
    books = books or {}
    out = []
    raw = (row.get("異動條文ID") or "").strip()
    if not raw:
        return out
    # 摘要可能帶「【整條刪除】」前綴（決定表上給人看的標記）。這裡是拿摘要去跟
    # 條文原文做開頭比對，前綴不是原文的一部分，比對前一定要先拿掉。
    summary_hint = dt.strip_deleted_prefix((row.get("異動摘要") or "").strip())
    for piece in raw.split("；"):
        piece = piece.strip()
        if not piece:
            continue
        book_name = ""
        ref = piece
        if "：" in piece:
            name, rest = piece.split("：", 1)
            if name in books:
                book_name = name
                ref = rest
        data = books[book_name] if book_name else book
        matches = _find_changes(data.get("changes") or [], ref, summary_hint)
        for match in matches:
            out.append((book_name, match))
    return out


# ---------------------------------------------------------------------------
# 區塊文字
# ---------------------------------------------------------------------------

def _context_lines(paragraphs, index0, start0, end0, own_label, changed_set):
    lines = []
    for i in range(start0, end0):
        idx1 = i + 1
        if i == index0:
            lines.append("  %d　%s" % (idx1, own_label))
        elif idx1 in changed_set:
            lines.append("  %d　%s　※本段也有異動" % (idx1, paragraphs[i]))
        else:
            lines.append("  %d　%s" % (idx1, paragraphs[i]))
    return lines


def _change_context(change, data, max_window=_MAX_WINDOW):
    """回傳 (版本標籤, 段落, 層級脈絡, index0, start0, end0, 本本異動段次集合, 範圍標籤)。
    有新版段次就用新版；只有舊版段次（刪除）就用舊版，並標「（舊版）」。"""
    if change.get("new_index"):
        idx0 = change["new_index"] - 1
        paragraphs, contexts = data["new_paragraphs"], data["new_contexts"]
        changed = {c["new_index"] for c in data["changes"] if c.get("new_index")}
        version = "新版"
    else:
        idx0 = (change.get("old_index") or 1) - 1
        paragraphs, contexts = data["old_paragraphs"], data["old_contexts"]
        changed = {c["old_index"] for c in data["changes"] if c.get("old_index")}
        version = "舊版"
    if idx0 < 0 or idx0 >= len(paragraphs):
        raise ReviewPackError(
            "異動清單 序號 %s 的段次 %d 超出草稿段數 %d，表和草稿對不上，請重跑 compare"
            % (change.get("序號"), idx0 + 1, len(paragraphs)))
    start0, end0, label = context_range(contexts, idx0, max_window=max_window)
    return version, paragraphs, contexts, idx0, start0, end0, changed, label


def _change_lines(change, data, heading, max_window=_MAX_WINDOW):
    version, paragraphs, contexts, idx0, start0, end0, changed, label = _change_context(
        change, data, max_window=max_window)
    lines = [heading,
             "- 舊文：%s" % (change.get("old_text") or "（無，新增段落）"),
             "- 新文：%s" % mark_diff(change.get("old_text") or "", change.get("new_text") or ""),
             "- 前後文（%s，%s）：" % (version, label)]
    lines += _context_lines(paragraphs, idx0, start0, end0, "※本段就是異動段", changed)
    return lines


def _paren(ref, extra):
    """組「（ref，extra）」；ref 是空的（build_hierarchy 認不得的段落，例如「3. 電訪
    目的及內容：」這種巢狀阿拉伯數字子標題）就只印「（extra）」，不留一個空逗號。"""
    parts = [p for p in (ref, extra) if p]
    return "（%s）" % "，".join(parts)


def _candidate_change_heading(change, book_name=""):
    """book_name 非空表示這處異動來自跨本（見 changes_for_row 的 book_name），
    標題加「（來源本：<名>）」讓人／AI 一眼看出這段舊文、新文是哪一本的，不會誤以為
    是自己這本的異動。"""
    ref = change.get("ref") or change.get("scope") or ""
    if change.get("new_index"):
        pos = "新版段次 %d" % change["new_index"]
    else:
        pos = "舊版段次 %d，已刪除" % (change.get("old_index") or 0)
    heading = "### 異動段%s" % _paren(ref, pos)
    if book_name:
        heading += "（來源本：%s）" % book_name
    return heading


def _candidate_section_lines(row, book, max_window=_MAX_WINDOW):
    line = dt.line_of(row.get("候選段次"))
    if not line or line > len(book["new_paragraphs"]):
        return ["### 候選段（無法定位到草稿段落）",
                "- 全文：%s" % (row.get("候選全文") or "")]
    idx0 = line - 1
    ctx = book["new_contexts"][idx0] if idx0 < len(book["new_contexts"]) else {}
    ref = ctx.get("ref") or format_scope(ctx) or ""
    start0, end0, label = context_range(book["new_contexts"], idx0, max_window=max_window)
    changed = {c["new_index"] for c in book["changes"] if c.get("new_index")}
    lines = ["### 候選段%s" % _paren(ref, "段次 %d" % line),
             "- 全文：%s" % (row.get("候選全文") or ""),
             "- 前後文（新版，%s）：" % label]
    lines += _context_lines(book["new_paragraphs"], idx0, start0, end0, "※本段就是候選段", changed)
    return lines


def _candidate_block(n, row, book, books, max_window=_MAX_WINDOW):
    """組一個候選的 markdown 區塊。

    max_window：這個區塊裡每一段前後文單側最多幾段。預設 _MAX_WINDOW；
    write_pack 發現這個區塊本身就超過 --max-chars 時，會用 _SHRUNK_WINDOW（3）
    重組一次，並在結尾加一行說明前後文被縮過。"""
    header = "## R%d　候選段次 %s　來源：%s" % (
        n, row.get("候選段次") or "（無）", row.get("來源") or "")
    # 這一列是被「修改」「新增」還是「刪除」帶出來的，要判的事不一樣
    # （被刪除帶出來的，別章的平行條文多半也要一起刪），所以放進標題那一行。
    change_type = (row.get("修改類型") or "").strip()
    if change_type:
        header += "　修改類型：%s" % change_type
    relation = row.get("關係／分數") or ""
    if relation:
        header += "　關係：%s" % relation
    parts = [header]

    matches = changes_for_row(row, book, books)
    if not matches:
        parts.append("（找不到對應異動，請看異動清單）")
    else:
        for book_name, change in matches:
            data = books[book_name] if book_name else book
            heading = _candidate_change_heading(change, book_name)
            parts.append("\n".join(_change_lines(change, data, heading, max_window=max_window)))

    parts.append("\n".join(_candidate_section_lines(row, book, max_window=max_window)))
    parts.append("### 要判的事\n候選段是不是也該跟著這次的改動一起改？"
                 "三樣一起看：候選段全文、異動段新舊文、兩邊的前後文。")
    if max_window < _MAX_WINDOW:
        parts.append("（前後文已縮減：本候選掛 %d 個異動，全文太長）" % len(matches))
    return "\n".join(parts)


def _change_list_block(n, change, book):
    if change.get("new_index"):
        pos = "新版段次 %d" % change["new_index"]
    else:
        pos = "刪除（舊版段次 %d）" % (change.get("old_index") or 0)
    ref = change.get("ref") or change.get("scope") or ""
    header_parts = ["C%d" % n, pos, change.get("修改類型") or ""]
    if ref:
        header_parts.append(ref)
    move = change.get("移列") or {}
    if move.get("說明"):
        # 搬移：刪除／新增其實是同一段換位置（異動清單「移列」欄），不寫的話 AI 會當成廢止一條、新訂一條
        header_parts.append("（%s%s）" % (move["說明"], "" if move.get("內容相同") else "，內容也有改"))
    header = "## " + "　".join(header_parts)
    lines = _change_lines(change, book, header)
    lines.append("### 要判的事\n改完的這一段跟前後文有沒有矛盾？同條其他項有沒有該一起改卻沒改？")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 寫審查包
# ---------------------------------------------------------------------------

# AI 要填的三欄。任何一列的任何一欄有字，就當作「人（或 AI）已經填過了」。
AI_ANSWER_COLUMNS = ("AI判斷", "AI分數", "AI理由")


CAND_SHA_COLUMN = "審查內容SHA256"
CHANGE_SHA_COLUMN = "異動SHA256"


def change_sha256(change):
    """一處異動的指紋：舊文與新文一起算（只看新文的話，舊文不同、新文相同的兩輪分不出來）。"""
    return dt.text_sha256("%s\n\x00\n%s" % (change.get("old_text") or "",
                                             change.get("new_text") or ""))


def candidate_sha256(row, book):
    """一列候選「AI 審的是什麼」的指紋：候選全文、異動條文ID、異動摘要，
    加上它掛的「本本」每一處異動的新舊文。

    只算候選全文不夠：重跑 compare 時常見的是異動那一段改了（五日 → 七日），
    候選那一段一個字都沒動。AI 判的是「這一段要不要跟著那處異動改」，
    異動變了，上一輪「建議改成五日」的理由就不能再用。

    刻意不查別本（跨本「X：ref」那一段）：查不查得到要看呼叫端有沒有把 X 載進來，
    batch-review-pack 會、單本 review-import 不會——同一列在兩條路上算出兩種指紋，
    混著用就把整批跨本列當成過期丟掉。跨本那一段改由「異動摘要」代表（它就是來源本
    那處異動的前一截），來源本重跑時整批決定表本來也會重建。
    """
    parts = [row.get("候選全文") or "", row.get("異動條文ID") or "", row.get("異動摘要") or ""]
    parts += sorted(change_sha256(ch) for _, ch in changes_for_row(row, book))
    return dt.text_sha256("\n\x00\n".join(parts))


def _new_csv_path(final_path):
    """AI候選判斷.csv → AI候選判斷.new.csv（同資料夾）。"""
    base, _ext = os.path.splitext(final_path)
    return base + ".new.csv"


# ---------------------------------------------------------------------------
# 外部規章引用：程式抓到的每一處（E1、E2…）交給 AI 檢查，另外附上可能漏抓的段落
# ---------------------------------------------------------------------------
EXTERNAL_FILE = "AI外部引用.csv"
EXTERNAL_SHA_COLUMN = "段落SHA256"
EXTERNAL_HEADER = ["引用ID", "段次", "程式抓到", "AI判斷", "AI理由", "AI更正", "查證來源", "類別",
                   EXTERNAL_SHA_COLUMN, "沿用查證"]
# 提到法規、機關或函令的字：這些段落程式卻沒抓到任何引用，就交給 AI 看有沒有漏
_EXTERNAL_HINT_RE = re.compile(
    r"[一-鿿]{2,40}(?:法|條例|辦法|準則|規則|細則|要點|規範|注意事項|自律規範)"
    r"|主管機關|金管會|金融監督管理委員會|保險局|銀行局|證期局|函令|令釋|函示|公會")
# 太長的清單 AI 讀不完，也沒有人會看；超過就只列前面這麼多段並講一聲
EXTERNAL_SUSPECT_LIMIT = 200


def external_items(book):
    """這一本草稿裡程式抓到的外部規章引用，每一筆多帶「引用ID」（E1 起）與段落指紋。"""
    import rule_checks as rc
    paragraphs = book["new_paragraphs"]
    items = []
    for i, mention in enumerate(rc.external_mentions(paragraphs), 1):
        text = paragraphs[mention["段次"] - 1]
        items.append(dict(mention, 引用ID="E%d" % i,
                          sha=dt.text_sha256("%s\n\x00\n%s" % (text, mention["引用"]))))
    return items


def external_suspects(book, items):
    """提到法規、機關或函令、但程式沒抓到任何外部引用的段落：[(段次, 全文)]。"""
    import rule_checks as rc
    from _common import clean_law_name
    covered = set(m["段次"] for m in items)
    out = []
    for idx, text in enumerate(book["new_paragraphs"], 1):
        if idx in covered:
            continue
        for match in _EXTERNAL_HINT_RE.finditer(text):
            word = match.group(0)
            if word[-1:] in "法則規點項" or word.endswith(("條例", "辦法", "準則", "要點", "規範", "注意事項")):
                if not clean_law_name(word):
                    continue      # 「方法」「作法」「本辦法」這種
            out.append((idx, text))
            break
    return out


_BATCH_TEXTS = {}
_CITE_NO_RE = re.compile(r"^第\s*([零〇一二三四五六七八九十百千兩\d０-９]+)\s*([條點])")
_LEAD_NO_RE = re.compile(r"^\s*第\s*([零〇一二三四五六七八九十百千兩\d０-９]+)\s*條|^\s*([零〇一二三四五六七八九十百千兩]+)\s*、")


def batch_book_texts(outdir):
    """這一批一起比對的每一本規章的舊版全文：{規章名: 段落 list}（別本引用的號碼照舊版解讀）。
    含沒進流程的本（未受影響規章.json）。不是批次產出回 {}。"""
    import batch as bt
    from _common import SYSTEM_DIR, batch_root_of, book_dir, read_paragraphs
    root = batch_root_of(outdir) if outdir else ""
    if not root:
        return {}
    if root in _BATCH_TEXTS:
        return _BATCH_TEXTS[root]
    texts = {}
    manifest = os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv")
    names = []
    if os.path.isfile(manifest):
        with io.open(manifest, encoding="utf-8-sig", newline="") as f:
            names = [(r.get("規章名") or "").strip() for r in csv.DictReader(f)]
    untouched = bt.unaffected_docs(root)
    for name in names:
        if not name:
            continue
        path = ""
        if name in untouched:
            path = untouched[name]["舊版"]
        else:
            staged = os.path.join(book_dir(root, name), SYSTEM_DIR, "輸入")
            found = sorted(glob.glob(os.path.join(staged, "舊版_*"))) if os.path.isdir(staged) else []
            path = found[0] if found else ""
        if path and os.path.isfile(path):
            try:
                texts[name] = read_paragraphs(path)
            except (ValueError, OSError, UnicodeDecodeError, SystemExit):
                continue
    _BATCH_TEXTS[root] = texts
    return texts


def _batch_citation_ok(citation, name, paragraphs):
    """「招攬作業要點第三點」：那一本舊版裡真的有第三點（第X條同理）。只寫名稱（未指明條號）也算。
    章節那種寫法不在這裡判（交給 AI）。回傳說明字串，對不上回 ""。"""
    from _common import cn_to_int
    rest = (citation or "")[len(name):].strip()
    if not rest or rest.startswith("（未指明條號）"):
        return "%s在這一批" % name
    match = _CITE_NO_RE.match(rest)
    if not match:
        return ""
    import unicodedata
    want = cn_to_int(unicodedata.normalize("NFKC", match.group(1)))
    kind = match.group(2)
    for text in paragraphs:
        lead = _LEAD_NO_RE.match(text or "")
        if not lead:
            continue
        if kind == "條" and lead.group(1) and cn_to_int(unicodedata.normalize("NFKC", lead.group(1))) == want:
            return "%s在這一批，第%s條存在" % (name, match.group(1))
        if kind == "點" and lead.group(2) and cn_to_int(lead.group(2)) == want:
            return "%s在這一批，第%s點存在" % (name, match.group(1))
    return ""


def _external_pack(outdir, book, kept):
    """寫 系統檔案/LLM外部引用清單.md 與 填寫表單/AI外部引用.csv。回傳 (引用數, 可能漏抓段數)。"""
    import batch as bt
    import scoring_rubric as sr
    import verify_cache as vc
    items = external_items(book)
    suspects = external_suspects(book, items)
    # 有效期內查過的同一處引用直接沿用（見 verify_cache），AI 只查沒沿用的
    cache_folder = bt.cache_dir(outdir)
    entries = vc.load(cache_folder)
    reused = {}
    # 引用的是這一批一起比對的本行規章：程式自己核對號碼存在，不用 AI 上網查、也不用人確認
    own = os.path.basename(os.path.normpath(outdir))
    batch_texts = batch_book_texts(outdir)
    for item in items:
        name = item.get("名稱") or ""
        if name and name != own and name in batch_texts:
            note = _batch_citation_ok(item["引用"], name, batch_texts[name])
            if note:
                reused[item["引用ID"]] = {
                    "AI判斷": "沒問題", "AI更正": "", "查證來源": "", "類別": "本行內規", "日期": "程式核對",
                    "AI理由": "〔本批規章〕程式核對：%s；要不要跟著改看連帶決定表的跨本引用列" % note}
                continue
        hit = vc.lookup(entries, vc.key(item["引用"], book["new_paragraphs"][item["段次"] - 1]))
        if hit:
            reused[item["引用ID"]] = hit
    lines = [sr.render_external(), "---", "", "# 一、程式抓到的外部規章引用", ""]
    if reused:
        lines += ["（標「已沿用」的那幾處，%d 天內查證過、段落文字沒變，AI外部引用.csv 已經填好，不用重查；"
                  "只查其他的）" % vc.VALID_DAYS, ""]
    if not items:
        lines.append("（沒有）")
    for item in items:
        hit = reused.get(item["引用ID"])
        mark = ""
        if hit:
            mark = ("　程式已核對（這一批的規章）" if hit["日期"] == "程式核對"
                    else "　已沿用 %s 的查證" % hit["日期"])
        lines += ["## %s　段次 %d　程式抓到：%s%s" % (item["引用ID"], item["段次"], item["引用"], mark),
                  "", "> " + book["new_paragraphs"][item["段次"] - 1].replace("\n", "\n> "), ""]
    lines += ["# 二、提到法規、機關或函令，但程式沒抓到引用的段落", ""]
    if not suspects:
        lines.append("（沒有）")
    for idx, text in suspects[:EXTERNAL_SUSPECT_LIMIT]:
        lines += ["## 段次 %d" % idx, "", "> " + text.replace("\n", "\n> "), ""]
    if len(suspects) > EXTERNAL_SUSPECT_LIMIT:
        lines.append("（另有 %d 段沒列出來；清單太長，請先處理上面這些）"
                     % (len(suspects) - EXTERNAL_SUSPECT_LIMIT))
        nt.notice(nt.REMINDER, "LLM外部引用清單.md 可能漏抓的段落有 %d 段，只列了前 %d 段"
                  % (len(suspects), EXTERNAL_SUSPECT_LIMIT), "review-pack")
    with io.open(place(outdir, "LLM外部引用清單.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    from _common import external_category
    # 類別先照登錄表填好（登錄過的名稱），AI 只要補沒登錄的
    body = []
    for item in items:
        hit = reused.get(item["引用ID"])
        if hit:
            body.append([item["引用ID"], item["段次"], item["引用"], hit["AI判斷"], hit["AI理由"], hit["AI更正"],
                         hit["查證來源"], hit["類別"] or external_category(item["名稱"]), item["sha"], hit["日期"]])
        else:
            body.append([item["引用ID"], item["段次"], item["引用"], "", "", "", "",
                         external_category(item["名稱"]), item["sha"], ""])
    # 上一輪的外部引用答案不帶：跨輪沿用由查證快取管（有 90 天有效期），同一輪重跑才帶
    _write_ai_csv(outdir, EXTERNAL_FILE, EXTERNAL_HEADER, body, kept, key_column=EXTERNAL_SHA_COLUMN,
                  answer_columns=("AI判斷", "AI理由", "AI更正", "查證來源", "類別"), previous_round=False)
    return len(items), min(len(suspects), EXTERNAL_SUSPECT_LIMIT)


# ---------------------------------------------------------------------------
# 條文檢查高風險項：compare 存下來的那幾筆（K1、K2…）交給 AI 查證
# ---------------------------------------------------------------------------
RULECHECK_FILE = "AI條文檢查.csv"
RULECHECK_SHA_COLUMN = "內容SHA256"
RULECHECK_HEADER = ["檢查ID", "段次", "檢查項目", "程式發現", "AI判斷", "AI理由", "查證來源",
                    RULECHECK_SHA_COLUMN]


def rulecheck_items(outdir):
    """compare 存的 條文檢查待查證.json，每一筆多帶「檢查ID」（K1 起）、「段次」與指紋。
    沒有這個檔（舊的產出資料夾）回 None。"""
    import rule_checks as rc
    path = locate(outdir, rc.AI_REVIEW_FILE)[0]
    if not os.path.isfile(path):
        return None
    with io.open(path, encoding="utf-8") as f:
        findings = json.load(f)
    items = []
    for i, item in enumerate(findings, 1):
        line = item.get("index") or ""
        sha = dt.text_sha256("\n\x00\n".join([item.get("check") or "", item.get("detail") or "",
                                               item.get("quote") or "", str(line)]))
        items.append(dict(item, 檢查ID="K%d" % i, 段次=line, sha=sha))
    return items


def _rulecheck_pack(outdir, book, kept):
    """寫 系統檔案/LLM條文檢查清單.md 與 填寫表單/AI條文檢查.csv。回傳項數（沒有待查證檔回 0）。"""
    import scoring_rubric as sr
    items = rulecheck_items(outdir)
    if items is None:
        return 0
    paragraphs = book["new_paragraphs"]
    lines = [sr.render_rulecheck(), "---", ""]
    if not items:
        lines.append("（這一輪沒有高風險項）")
    contexts = book.get("new_contexts") or []
    for item in items:
        line = item["段次"]
        known = contexts[line - 1]["ref"] if isinstance(line, int) and 1 <= line <= len(contexts) else ""
        where = item.get("ref") or display_ref(known) or ("第%s段" % line if line else "全文")
        lines += ["## %s　%s　[%s]　%s" % (item["檢查ID"], where, item["check"], item["detail"]), ""]
        if item.get("quote"):
            lines += ["相關原文：" + item["quote"], ""]
        if item.get("action"):
            lines += ["程式建議：" + item["action"], ""]
        line = item["段次"]
        if isinstance(line, int) and 1 <= line <= len(paragraphs):
            lines += ["新版這一段：", "", "> " + paragraphs[line - 1].replace("\n", "\n> "), ""]
    with io.open(place(outdir, "LLM條文檢查清單.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    _write_ai_csv(outdir, RULECHECK_FILE, RULECHECK_HEADER,
                  [[item["檢查ID"], item["段次"], item["check"], item["detail"], "", "", "", item["sha"]]
                   for item in items], kept, answer_columns=("AI判斷", "AI理由", "查證來源"))
    return len(items)


def has_ai_answers(path):
    """既有的 AI CSV 有沒有人填過。

    讀不出來（壞檔、編碼怪、被改成別的東西）一律回 True：寧可留著讓人自己看，
    也不要「因為讀不懂就當成空白」把人填了半天的判斷覆寫掉。
    """
    if not os.path.isfile(path):
        return False
    try:
        with io.open(path, encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                if (row.get("沿用查證") or "").strip():
                    continue           # 程式從查證快取填的，不是 AI 或人填的
                for key in AI_ANSWER_COLUMNS:
                    if (row.get(key) or "").strip():
                        return True
    except (OSError, UnicodeDecodeError, csv.Error):
        return True
    return False


def _write_ai_csv(outdir, filename, header, data_rows, kept, key_column=None,
                  answer_columns=AI_ANSWER_COLUMNS, previous_round=True):
    """寫一張 AI CSV，直接寫在原檔名。AI 已經判過、而且審的內容沒變（指紋一樣）的列，把答案帶進新表：

        這個資料夾現在那一份：同一輪重跑 review-pack（補了語意、改了 --per-file……）
        上一輪歸檔在 系統檔案/歷次/ 的那一份：重跑「開始」之後（previous_round）

    以前已有填答就另存 .new.csv，叫人「自行對照後改名」；重跑開始則四張表整批變回空白，
    AI 要從頭再審一次。指紋記的是這一列審的是哪一段字（見 candidate_sha256 等），字變了就不帶，
    舊理由不會套到新的字上。程式自己先填的列（「沿用查證」有值：查證快取、同一批規章的核對）
    不當成 AI 的答案，也不會被蓋掉。kept 收「檔名 N 列」給畫面講。"""
    from _common import archived_file, open_csv
    final_path = place(outdir, filename)
    key_column = key_column or header[-1]
    key_index = header.index(key_column)
    columns = [c for c in answer_columns if c in header]
    carried = {}
    by_position = {}          # 舊表沒有指紋欄（較早的表、AI 改寫時拿掉了）：退回用 編號＋段次 對
    extra_rows = []
    # 這個資料夾現在那一份裡 AI 答過的每一列（用「指紋＋位置」或「編號＋位置」認）。
    # 以前只記個數，跟「帶回了幾列」相減——帶回的列也算上一輪歸檔那一份的，
    # 兩邊一抵銷，「要重判」的提醒就少報甚至不報（第三批）。改成逐列記、逐列勾。
    answered_here = set()
    used_here = set()
    sources = [locate(outdir, filename)[0]]
    if previous_round:
        sources.append(archived_file(outdir, filename))
    for position, path in enumerate(sources):
        if not path or not os.path.isfile(path):
            continue
        try:
            with open_csv(path) as f:
                old_rows = list(csv.DictReader(f))
        except (OSError, UnicodeDecodeError, csv.Error, ValueError):
            continue
        for row in old_rows:
            if (row.get("沿用查證") or "").strip():
                continue
            answers = dict((c, row.get(c) or "") for c in columns)
            if not any(v.strip() for v in answers.values()):
                continue
            if position == 0 and header[0] == "引用ID" and (row.get("引用ID") or "").strip() == "新增":
                extra_rows.append([row.get(c) or "" for c in header])   # AI 自己加的漏抓列照留
                continue
            key = (row.get(key_column) or "").strip()
            spot_here = (row.get(header[1]) or "").strip()
            if position == 0:
                answered_here.add(("指紋", key, spot_here) if key
                                  else ("位置", (row.get(header[0]) or "").strip(), spot_here))
            if key and (key not in carried or carried[key][0] == position):
                # 同一個指紋可能有好幾列（同一段字出現在不同段次）：每一列的答案連它的位置一起記，
                # 帶回時照位置對，不能讓第一列的答案蓋到別列（B17）
                carried.setdefault(key, [position, {}])[1][(row.get(header[1]) or "").strip()] = answers
            elif not key and position == 0:
                spot = ((row.get(header[0]) or "").strip(), (row.get(header[1]) or "").strip())
                by_position.setdefault(spot, answers)
    out_rows, count = [], 0
    for row in data_rows:
        row = list(row)
        key = str(row[key_index]).strip()
        prefilled = any(str(row[header.index(c)]).strip() for c in columns)
        answers = None
        if key in carried:
            spots = carried[key][1]
            if len(spots) == 1:
                spot = list(spots)[0]
            else:
                spot = str(row[1]).strip()                   # 好幾列同指紋：照位置，對不上就不帶
            answers = spots.get(spot)
            if answers is not None and carried[key][0] == 0:
                used_here.add(("指紋", key, spot))
        if answers is None:
            spot = (str(row[0]).strip(), str(row[1]).strip())
            answers = by_position.get(spot)
            if answers is not None:
                used_here.add(("位置",) + spot)
        if answers and not prefilled:
            for column, value in answers.items():
                row[header.index(column)] = value
            count += 1
        out_rows.append(row)
    dropped = len(answered_here - used_here)
    if dropped:
        # 這一輪 AI 判過、但審的字已經變了（重跑了開始、補了語意改了候選）：舊答案不能套到新的字上
        nt.notice(nt.REMINDER, "%s 有 %d 列 AI 判過、但審的內容已經變了，這次要重判（其餘沿用）"
                  % (filename, dropped), "review-pack")
    out_rows += extra_rows
    new_path = _new_csv_path(final_path)
    if os.path.isfile(new_path):
        os.remove(new_path)             # 上一版程式留下的 .new.csv，不再需要
    with io.open(final_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(header)
        for row in out_rows:
            writer.writerow(row)
    if count:
        kept.append("%s %d 列" % (filename, count))
    return final_path


# 單一候選區塊自己就超過 max_chars 時，前後文縮到單側幾段再重算一次。
_SHRUNK_WINDOW = 3
# --max-chars 預設值。一份 LLM審查包_NN.md 的字元數上限。
DEFAULT_MAX_CHARS = 60000


def _pack_chunks(blocks, per_file, max_chars):
    """把候選區塊切成一份一份的審查包。

    切檔規則有兩條，先到先切：
        一、區塊數達 per_file
        二、累計字元數加上下一個區塊會超過 max_chars

    為什麼要數字數（should_fix no 18）：舊寫法只數區塊（`blocks[i:i+per_file]`），
    一個候選掛十幾處異動時單一區塊就好幾萬字，實測單檔 13.7 萬字——貼進 AI
    直接超過脈絡長度，人要自己在 Notepad 裡切，而且切在哪裡沒有規則可循。

    單一區塊本身就超過 max_chars 的，切不動，自己一份（由呼叫端先縮前後文再進來）。
    """
    chunks = []
    current = []
    used = 0
    for block in blocks:
        size = len(block) + 2      # 加上區塊之間的 "\n\n"
        if current and (len(current) >= per_file or
                        (max_chars and used + size > max_chars)):
            chunks.append(current)
            current, used = [], 0
        current.append(block)
        used += size
    if current:
        chunks.append(current)
    return chunks or [[]]


def write_pack(outdir, per_file=40, books=None, quiet=False, loaded_books=None,
               max_chars=DEFAULT_MAX_CHARS):
    """寫 LLM審查包_NN.md、LLM異動清單.md、AI候選判斷.csv、AI異動審查.csv。
    舊的 LLM審查包_*.md 先刪。books：{來源本名稱: 該本的產出資料夾}，跨本候選用；
    沒給 loaded_books 時才會逐一 load_book(path)。

    loaded_books：呼叫端已經把所有本都 load_book 過（{規章名: load_book 回傳值}）
    就傳這個，直接拿來用，不再逐本重新 load——batch-review-pack 原本 N 本各呼叫
    一次 write_pack，這裡又逐本重載全部本，N 本就是 N² 次 docx／csv 讀取。
    有給的話連自己這本也不重載：用 outdir 的資料夾名稱（batch 產出結構固定是
    <產出根目錄>/<規章名>）在 loaded_books 裡找，找不到才退回 load_book(outdir)
    （例如單本 review-pack，outdir 資料夾名稱不是規章名）。

    quiet=True 不印「候選 N 筆、異動 M 處、審查包 K 份」——batch-review-pack 逐本
    呼叫時自己會印帶規章名的那一行，兩行重複沒有意義；單本 review-pack CLI 不傳
    這個參數，行為不變。回傳 {"包": [...], "候選數", "異動數", "異動清單": 路徑,
    "保留填答": [檔名...]}。

    四張 AI 表每次都照這一輪的列重寫；AI 已經判過、審的內容（指紋）沒變的答案帶回同一列，
    重跑開始時連上一輪歸檔的那一份也讀（見 _write_ai_csv）。不再另存 .new.csv。

    max_chars：一份審查包的字元數上限（預設 DEFAULT_MAX_CHARS＝60000，
    CLI 是 `--max-chars`）。區塊數達 per_file **或** 再加一個區塊就超過 max_chars
    就換檔；0 表示不看字數、只數區塊。見 _pack_chunks 與 _SHRUNK_WINDOW。"""
    if loaded_books is not None:
        own_name = os.path.basename(os.path.normpath(outdir))
        book = loaded_books.get(own_name) or load_book(outdir)
    else:
        book = load_book(outdir)
        loaded_books = {}
        for name, path in (books or {}).items():
            loaded_books[name] = load_book(path)

    # 舊的審查包先刪：這一輪的份數可能比上一輪少（改了 --per-file、候選變少），
    # 留著 LLM審查包_05.md 會讓人以為這一輪有五份。新格與舊平鋪兩邊都要清——
    # 舊排法的資料夾重跑一次之後，平鋪那幾份就是上一輪的殘骸了。
    pack_dir = os.path.dirname(place(outdir, "LLM審查包_01.md"))
    for folder in {pack_dir, os.path.abspath(outdir)}:
        for stale in glob.glob(os.path.join(folder, "LLM審查包_*.md")):
            os.remove(stale)

    rows = book["rows"]
    changes = book["changes"]

    blocks = [_candidate_block(i, row, book, loaded_books) for i, row in enumerate(rows, 1)]
    per_file = max(1, per_file)
    max_chars = max(0, int(max_chars or 0))

    # 評分標準寫在每一份的開頭：AI 可能只拿到其中一份，每一份都要自己看得懂怎麼打分。
    # 它也佔字數：--max-chars 是整份檔的上限，切包時要先扣掉它
    import scoring_rubric as sr
    cand_rubric = sr.render("候選") + "\n---\n\n"
    budget = max(1, max_chars - len(cand_rubric)) if max_chars else 0

    # 單一區塊自己就超過上限：先把那個候選的前後文縮到前後各 _SHRUNK_WINDOW 段
    # 重算一次（區塊尾巴會多一行說明）。縮完還是超過就照放——寧可檔案太大，
    # 也不要把原文截掉讓人以為條文就長那樣——但一定要發一則提醒。
    oversize = []
    if budget:
        for i, block in enumerate(blocks):
            if len(block) <= budget:
                continue
            blocks[i] = _candidate_block(i + 1, rows[i], book, loaded_books,
                                         max_window=_SHRUNK_WINDOW)
            if len(blocks[i]) > budget:
                oversize.append(i)

    chunks = _pack_chunks(blocks, per_file, budget) if blocks else [[]]
    pack_paths = []
    for idx, chunk in enumerate(chunks, 1):
        path = place(outdir, "LLM審查包_%02d.md" % idx)
        content = "\n\n".join(chunk) if chunk else "（沒有候選）"
        with io.open(path, "w", encoding="utf-8") as f:
            f.write(cand_rubric + content + "\n")
        pack_paths.append(path)
    for i in oversize:
        # 找出這個過大的區塊被放到哪一份檔案（它一定自己獨佔一份）
        filename = os.path.basename(pack_paths[0])
        for path, chunk in zip(pack_paths, chunks):
            if blocks[i] in chunk:
                filename = os.path.basename(path)
                break
        nt.notice(nt.REMINDER,
                  "%s 單一候選超過 %d 字，貼進 AI 前請自行分段" % (filename, max_chars),
                  "review-pack")

    change_blocks = [_change_list_block(i, ch, book) for i, ch in enumerate(changes, 1)]
    change_list_path = place(outdir, "LLM異動清單.md")
    with io.open(change_list_path, "w", encoding="utf-8") as f:
        f.write(sr.render("異動") + "\n---\n\n"
                + ("\n\n".join(change_blocks) if change_blocks else "（沒有異動）") + "\n")

    # 每張 AI 表各自帶回 AI 判過的答案：一張填過、一張沒填是常態
    # （AI 先答完候選、異動那張還空著）。
    # 最後一欄是這一列審的是哪一段字的指紋（程式填、AI 不動）：重跑 compare 之後
    # 列ID 與段次常常一模一樣，只有字變了（五日 → 七日），只靠列ID 對的話，
    # 上一輪「建議改成五日」的理由會原封不動匯進這一輪的表。
    kept = []           # 沿用 AI 已判過的答案（見 _write_ai_csv）
    _write_ai_csv(outdir, "AI候選判斷.csv",
                  ["列ID", "候選段次", "AI判斷", "AI分數", "AI理由", CAND_SHA_COLUMN],
                  [["R%d" % i, row.get("候選段次") or "", "", "", "",
                    candidate_sha256(row, book)]
                   for i, row in enumerate(rows, 1)], kept)
    # 「查證來源」：放寬或限縮義務的異動，AI 要先上網查上位規定（見 scoring_rubric 的異動評分）
    _write_ai_csv(outdir, "AI異動審查.csv",
                  ["異動ID", "新版段次", "AI判斷", "AI分數", "AI理由", "查證來源", CHANGE_SHA_COLUMN],
                  [["C%d" % i, ch.get("new_index") or "刪除", "", "", "", "", change_sha256(ch)]
                   for i, ch in enumerate(changes, 1)], kept,
                  answer_columns=AI_ANSWER_COLUMNS + ("查證來源",))

    external_count, suspect_count = _external_pack(outdir, book, kept)
    rulecheck_count = _rulecheck_pack(outdir, book, kept)

    if not quiet:
        print("候選 %d 筆、異動 %d 處、審查包 %d 份、外部規章引用 %d 處（另有 %d 段可能漏抓，一起給 AI 看）、"
              "條文檢查高風險 %d 項"
              % (len(rows), len(changes), len(pack_paths), external_count, suspect_count, rulecheck_count))
        if kept:
            print("沿用 AI 已判過、內容沒變的答案：%s（只有其他列要 AI 判）" % "、".join(kept))
    return {"包": pack_paths, "候選數": len(rows), "異動數": len(changes),
            "異動清單": change_list_path, "保留填答": kept,
            "外部引用數": external_count, "可能漏抓段數": suspect_count, "條文檢查數": rulecheck_count}
