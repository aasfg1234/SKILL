# -*- coding: utf-8 -*-
"""
連帶決定表的兩個輔助：寫表之前呼叫，程式都不代填「要改嗎」「改成什麼」。

一、異動內容／建議改法（annotate）
    表上以前只有「異動摘要」（新文前一截），看不出這一次到底改了哪幾個字，人要回頭翻
    對照表；「改成什麼」也要自己把整段條文重打一次。這裡補兩欄：
        異動內容   「三日→五日」：那一處異動改了哪幾個字
        建議改法   把同樣的改法套到候選段上的樣子。只給參考，不填進「改成什麼」——
                   決定權在人。套不上去（候選段裡找不到、找到不只一處、異動是整段
                   新增或刪除、一列掛好幾處異動）就留空，不硬猜。

二、沿用上一輪（carry_over）
    草稿改一個字重跑 compare，決定表整張重建，上一輪填的「要改嗎」「改成什麼」全部
    清空——候選卻一模一樣。這裡把上一輪的決定帶過來，只帶「候選全文、異動條文ID、
    異動摘要、掛的那幾處異動的新舊文」完全相同的列（同 review_pack.candidate_sha256
    那一把尺）；有任何一樣變了的列留空，要人重新看。帶過來的列在「沿用上一輪」寫「是」。
    上一輪的表去哪裡找：同一個產出資料夾還在原位的那一份（單本重跑），不在就找
    系統檔案/歷次/ 最新那一輪（「開始」會先把上一輪整包歸檔）。
"""

import csv
import difflib
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import fuzzy_duplicate_finder as fuzzy
import review_pack as rp
from _common import FILL_DIR, SYSTEM_DIR, locate, strip_numbering_prefix

# 沿用時帶過來的欄：人的決定、AI 三欄（同一段字、同一處異動，AI 判的也是同一件事）、
# 核准方式（那個決定是照哪一條規則核准的；不帶的話重跑開始後看起來像人自己填的，B21）
CARRY_FIELDS = ("要改嗎", "改成什麼", "AI判斷", "AI分數", "AI理由", "核准方式")
MAX_CONTEXT = 8          # 建議改法找唯一位置時，前後最多各多帶幾個字
# 一串連在一起的這些字算「一個數字」：比改動、找位置都整串一起，「三日→五日」才不會把
# 候選段的「三十日」改成「五十日」、「第一百三十七條」改成「第一百五十七條」
NUMERAL_CHARS = set("零〇一二三四五六七八九十百千萬億兩壹貳參肆伍陸柒捌玖拾佰仟0123456789０１２３４５６７８９")
# 建議改法套上去之前，候選段那一處跟異動段那一處要「講的是同一件事」：兩邊所在那一句像到
# 句子層級比對的門檻（60），或改動處左右各 CONTEXT_WIDTH 字（不跨句）都像到高信心（80）。
# 「同數字、別件事」（保險費逾期通知的「三日內」對客戶申訴陳報的「三日內」）兩樣都到不了。
CONTEXT_WIDTH = 10
# 左右加起來能比的字不到這麼多（表格格子「三日內」、條文開頭就是那個數字）就沒得比，不擋：
# 表格格子在舊值搜尋那一關已經要那一列的名稱對得上才列
MIN_CONTEXT = 6
CONTEXT_NOTE = "（候選段這一處的上下文跟異動段不像，可能是同數字、別件事，沒給建議改法）"


# ---------------------------------------------------------------------------
# 異動內容／建議改法
# ---------------------------------------------------------------------------

def _tokens(text):
    """切成比對單位：一串數字字算一個單位，其他字一個字一個單位。回 [(字, 起點)]。"""
    out, i = [], 0
    while i < len(text):
        j = i + 1
        if text[i] in NUMERAL_CHARS:
            while j < len(text) and text[j] in NUMERAL_CHARS:
                j += 1
        out.append((text[i:j], i))
        i = j
    return out


def _hunks(old, new):
    """old → new 的每一處改動：[(舊的那幾個字, 新的那幾個字, 在舊文的起點, 終點)]。

    以 _tokens 的單位比，數字只會整串改：「十萬→二十萬」，不會變成「在十前面插一個二」。"""
    a, b = _tokens(old), _tokens(new)
    matcher = difflib.SequenceMatcher(None, [t for t, _ in a], [t for t, _ in b], autojunk=False)

    def span(toks, lo, hi, text):
        start = toks[lo][1] if lo < len(toks) else len(text)
        end = toks[hi - 1][1] + len(toks[hi - 1][0]) if hi > lo else start
        return start, end

    hunks = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        s1, e1 = span(a, i1, i2, old)
        s2, e2 = span(b, j1, j2, new)
        hunks.append((old[s1:e1], new[s2:e2], s1, e1))
    return hunks


def _split_prefix(text):
    """(段首編號, 本體)。條號不是內容：異動的條號改了不能套到候選上，候選自己的條號也不能被改。"""
    body = strip_numbering_prefix(text)
    if body and text.endswith(body):
        return text[:len(text) - len(body)], body
    return "", text


def _find_unique(text, probe):
    """probe 在 text 裡「獨立」出現的位置（頭尾是數字的，旁邊不能再接數字）；不是剛好一處回 None。"""
    found, start = [], 0
    while True:
        pos = text.find(probe, start)
        if pos < 0:
            break
        start = pos + 1
        if probe[0] in NUMERAL_CHARS and pos > 0 and text[pos - 1] in NUMERAL_CHARS:
            continue
        end = pos + len(probe)
        if probe[-1] in NUMERAL_CHARS and end < len(text) and text[end] in NUMERAL_CHARS:
            continue
        found.append(pos)
        if len(found) > 1:
            return None, 2
    return (found[0], 1) if found else (None, 0)


def _renamed_term(old, new):
    """這處異動是不是「定義的用詞改名」：是的話回 (舊詞, 新詞)，否則 None。

    條件很嚴：兩邊都找得到被定義的詞，而且整段只差在把舊詞全部換成新詞。
    """
    for pattern in fuzzy._DEFINED_TERM_RES:
        a, b = pattern.search(old), pattern.search(new)
        if a and b and a.group(1) != b.group(1) and old.replace(a.group(1), b.group(1)) == new:
            return a.group(1), b.group(1)
    return None


def _is_numbering(text, pos, length):
    """text[pos:pos+length] 這個數字是不是條號、款號或引用（第三條、三、、（三））。"""
    before = text[pos - 1] if pos > 0 else ""
    after = text[pos + length] if pos + length < len(text) else ""
    return before == "第" or after in ("條", "項", "款", "點", "目", "章", "節", "編", "、") \
        or (before in "（(" and after in "）)")


def describe(change):
    """一處異動改了什麼，給人看的一句話。"""
    kind = change.get("修改類型")
    if kind == "新增":
        return "新增整段"
    if kind == "刪除":
        return "刪除整段"
    old, new = change.get("old_text") or "", change.get("new_text") or ""
    parts = []
    for old_seg, new_seg, i1, i2 in _hunks(old, new):
        # 只改一兩個字時多帶一個字，「三→五」看不出是什麼，「三日→五日」看得出來
        if max(len(old_seg), len(new_seg)) <= 2 and i2 < len(old):
            old_seg, new_seg = old_seg + old[i2], new_seg + old[i2]
        parts.append("%s→%s" % (old_seg or "（無）", new_seg or "（無）"))
    if len(parts) > 4:
        parts = parts[:4] + ["…共 %d 處" % len(parts)]
    return "、".join(parts)


def suggest(candidate, change):
    """把 change 的改法套到 candidate 上；套不上去回 ""。

    每一處改動都要在候選段裡找到「唯一」一處相同的舊字：先比改動本身，找到不只一處
    （「三」在「三、財產保險…三日內」出現兩次）就前後各多帶一個字再找，最多帶
    MAX_CONTEXT 個字；還是找不到唯一的一處就放棄整列——猜錯位置比留空更糟。
    數字整串比、找到的位置旁邊不能再接數字（「三」不算「三十」的一部分）；異動跟候選
    兩邊的段首條號都不參與（「第四條→第五條」不套上去，候選的「第三條」也不會被改到）。
    只改一個字的，至少帶一個字的上下文一起找（前或後都可以，表格格子「三日內」前面沒有
    「於」）：單獨一個「應」太容易對到別件事。數字例外——「三個營業日→五個營業日」套到
    「應於三日內」，候選段裡獨立的「三」只有一處、又不是條號款號（「依第三條」）才單獨換。
    """
    if change.get("修改類型") != "修改":
        return ""
    old = _split_prefix(change.get("old_text") or "")[1]
    new = _split_prefix(change.get("new_text") or "")[1]
    head, text = _split_prefix(candidate or "")
    renamed = _renamed_term(old, new)
    if renamed:
        # 定義改名：用到舊名的地方每一處都要換（第二十六條寫了兩次「業務人員」也一樣），
        # 不必找唯一位置
        return head + text.replace(*renamed) if renamed[0] in text else ""
    for old_seg, new_seg, i1, i2 in _hunks(old, new):
        short = max(len(old_seg), len(new_seg)) <= 1
        if old_seg and all(ch in NUMERAL_CHARS for ch in old_seg):
            pos, count = _find_unique(text, old_seg)
            if count == 0 or (count == 1 and _is_numbering(text, pos, len(old_seg))):
                return ""
            if count == 1:
                text = text[:pos] + new_seg + text[pos + len(old_seg):]
                continue
        for k in range(1 if (short or not old_seg) else 0, MAX_CONTEXT + 1):
            left, right = old[max(0, i1 - k):i1], old[i2:i2 + k]
            # 前後都帶最準；候選段那一邊的字不一樣時，退一步只帶一邊
            variants = [(left, right)] + ([(left, ""), ("", right)] if k else [])
            hits = []
            for lft, rgt in variants:
                probe = lft + old_seg + rgt
                if probe and (lft or rgt or not short):
                    pos, count = _find_unique(text, probe)
                    hits.append((count, pos, lft, rgt))
            unique = [h for h in hits if h[0] == 1]
            if unique:
                _, pos, lft, rgt = unique[0]
                text = text[:pos] + lft + new_seg + rgt + text[pos + len(lft + old_seg + rgt):]
                break
            if not any(h[0] for h in hits):
                return ""
            if left == old[:i1] and right == old[i2:]:
                return ""                        # 整段都帶上了還不只一處：再多帶也一樣
        else:
            return ""
    text = head + text
    return text if text != candidate else ""


def _span_of(text, pos):
    """text 第 pos 個字所在那一句的 (起, 迄)；切法跟句子層級比對一樣（但書跟前一句算同一句）。"""
    for start, end in fuzzy._sentence_spans(text):
        if start <= pos <= end:
            return start, end
    return 0, len(text)


def _main_part(text, start, end):
    """text[start:end] 這一句去掉後面併進來的但書。

    比的是「哪一個規定」：改動落在但書裡（「…逕行核定，並副知法令遵循單位」）時，全文帶著
    同一句但書的條文那一截都一模一樣，連但書一起比會被那一截抬過門檻；規定本身像，才是同一件事。
    """
    unit = text[start:end]
    m = re.search(r"[。；]\s*但", unit)
    return (unit[:m.start()] if m else unit).strip()


def _sides(text, start, end):
    """改動處 text[start:end] 左右各 CONTEXT_WIDTH 字，不跨出那一句。"""
    s, e = _span_of(text, start)
    return text[max(s, start - CONTEXT_WIDTH):start], text[end:min(max(e, end), end + CONTEXT_WIDTH)]


def context_alike(candidate, change, suggestion):
    """建議改法改到的那一處，上下文跟異動段改的那一處像不像。

    suggest() 只管「舊字在候選段裡找得到唯一一處」，不管那一處講的是不是同一件事：
    第四條「客戶申訴…應於三日內陳報」改五日，第十三條「保險費逾期未繳者…應於三日內以書面通知」
    也找得到唯一的「三日內」，建議改法就照改——人照建議填「改」，別件事的期限跟著被改掉。
    兩樣有一樣夠像就算同一件事：
      一、兩邊所在那一句（去掉但書，見 _main_part）的相似度到 fuzzy.DEFAULT_SENTENCE_THRESHOLD
          （換句話說的孿生條）
      二、改動處左右各 CONTEXT_WIDTH 字，兩邊都比得到、而且都到 fuzzy.HIGH_CONFIDENCE（主詞不同、
          改的那一截一模一樣：「累計保險金額達新臺幣五百萬元以上之保件」對「保險金額達新臺幣
          五百萬元以上之保件」）。只有一邊比得到（加在句尾）不算：那一邊本來就是 suggest()
          找位置用的字，一定一樣，不是另外的證據。
    定義改名（每一處都要換）、左右能比的字太少（表格格子）不擋。
    """
    old = _split_prefix(change.get("old_text") or "")[1]
    new = _split_prefix(change.get("new_text") or "")[1]
    if _renamed_term(old, new):
        return True
    body = _split_prefix(candidate or "")[1]
    after = _split_prefix(suggestion or "")[1]
    hunks = _hunks(old, new)
    if not hunks or not body or not after:
        return True
    # 候選段被改的那一截：頭尾相同的字剝掉，剩下的就是建議改法動到的地方
    n = min(len(body), len(after))
    pos = next((i for i in range(n) if body[i] != after[i]), n)
    tail = 0
    while tail < n - pos and body[len(body) - 1 - tail] == after[len(after) - 1 - tail]:
        tail += 1
    cand_start, cand_end = pos, len(body) - tail
    old_start, old_end = hunks[0][2], hunks[-1][3]
    s1, e1 = _span_of(old, old_start)
    s2, e2 = _span_of(body, cand_start)
    if fuzzy.calc_similarity(_main_part(old, s1, e1), _main_part(body, s2, e2)) \
            >= fuzzy.DEFAULT_SENTENCE_THRESHOLD:
        return True
    old_left, old_right = _sides(old, old_start, old_end)
    cand_left, cand_right = _sides(body, cand_start, cand_end)
    scores, compared = [], 0
    for mine, theirs, left in ((old_left, cand_left, True), (old_right, cand_right, False)):
        k = min(len(mine), len(theirs))
        if not k:
            continue
        a, b = (mine[-k:], theirs[-k:]) if left else (mine[:k], theirs[:k])
        scores.append(fuzzy.calc_similarity(a, b))
        compared += k
    if compared < MIN_CONTEXT:
        return True
    return len(scores) == 2 and all(score >= fuzzy.HIGH_CONFIDENCE for score in scores)


def annotate(rows, items, books=None):
    """每一列補上「異動內容」「建議改法」。books：{規章名: {"changes": [...]}}，跨本列用。

    建議改法套得上去、但那一處的上下文跟異動段不像（context_alike）就不給，異動內容後面
    寫明原因：同樣寫「三日內」講的是別件事，給了建議改法人很容易照填「改」。
    """
    book = {"changes": items}
    for row in rows:
        linked = []
        for _, ch in rp.changes_for_row(row, book, books):
            # 同一處異動被兩種寫法連到（相似候選寫「第四條」、語意候選寫「段次 7」）只算一次：
            # 以前算成兩處，建議改法整格被洗掉，異動內容也重複寫兩次
            if not any(ch is seen for seen in linked):
                linked.append(ch)
        row["異動內容"] = "；".join(describe(ch) for ch in linked)
        row["建議改法"] = suggest(row.get("候選全文"), linked[0]) if len(linked) == 1 else ""
        if row["建議改法"] and not context_alike(row.get("候選全文"), linked[0], row["建議改法"]):
            row["建議改法"] = ""
            row["異動內容"] += CONTEXT_NOTE
        outline = row.get(dt.OUTLINE_KEY)
        if outline:
            # 章節引用列（Step 0.5）：異動內容寫哪一處引用要改成什麼；建議改法照位置改寫候選全文。
            # 同一段同時也是相似候選、已經有建議改法時不蓋掉它，章節那幾處寫在異動內容裡。
            # 條文引用、定義連動（decision_table.add_refs／add_definitions）自己帶 row_note：
            # 危險、無法判定、內容變了、定義變更各有各的說法，不能都講成「指到的地方刪掉了」
            notes = [f.get("row_note") or (("「%s」→「%s」（%s）" % (f["quote"], f["new_quote"], f.get("tag") or "章節換號"))
                     if f.get("new_quote")
                     else "「%s」指到的地方這次刪掉了，要改指別處或刪掉" % f["quote"]) for f in outline]
            row["異動內容"] = "；".join(x for x in [row["異動內容"]] + notes if x)
            # advisory（內容變了、定義連動）只是要人重看，不擋、也不參與建議改法的改寫
            outline = [f for f in outline if not f.get("advisory")]
            if any(not f.get("new_quote") for f in outline):
                # 有一處指到的地方刪掉了：只換其他幾處，看起來像改好了、意思卻已經變了，留給人決定
                row["建議改法"] = ""
            elif row["建議改法"]:
                # 相似候選的建議改法也要把章節換號一起換上，否則人照建議填「改」，舊章節號留在定稿裡
                row["建議改法"] = _apply_quotes(row["建議改法"], outline)
            else:
                row["建議改法"] = dt.outline_suggestion(row.get("候選全文") or "", outline)
    return rows


def _apply_quotes(text, findings):
    """在已經改寫過的文字上換章節引用：位置已經跑掉，改用「那段引用在文中只出現一次」找；找不到就回空。"""
    for f in findings:
        if text.count(f["quote"]) != 1:
            return ""
        text = text.replace(f["quote"], f["new_quote"])
    return text


# ---------------------------------------------------------------------------
# 沿用上一輪
# ---------------------------------------------------------------------------

def _read(table_path, changes_path):
    if not (os.path.isfile(table_path) and os.path.isfile(changes_path)):
        return None
    try:
        from _common import open_csv
        with open_csv(table_path) as f:
            rows = list(csv.DictReader(f))
        with io.open(changes_path, encoding="utf-8") as f:
            items = json.load(f)
    except (OSError, ValueError, UnicodeDecodeError, csv.Error):
        return None
    return rows, items


def previous_round(outdir):
    """上一輪的 (決定表列, 異動清單)；找不到回 None。

    先看產出資料夾原位（單本 compare 重跑到同一個資料夾，寫表之前舊表還在），
    再看 系統檔案/歷次/ 裡最新的那一輪（「開始」會先歸檔；時間戳資料夾名照字典序
    就是時間順序）。
    """
    here = _read(locate(outdir, "連帶決定表.csv")[0], locate(outdir, "異動清單.json")[0])
    if here:
        return here
    history = os.path.join(outdir, SYSTEM_DIR, "歷次")
    if not os.path.isdir(history):
        return None
    for stamp in sorted(os.listdir(history), reverse=True):
        base = os.path.join(history, stamp)
        found = _read(os.path.join(base, FILL_DIR, "連帶決定表.csv"),
                      os.path.join(base, SYSTEM_DIR, "異動清單.json"))
        if found:
            return found
    return None


def _has_answer(row):
    return any((row.get(field) or "").strip() for field in CARRY_FIELDS)


def carry_over(rows, items, previous):
    """把上一輪填過的決定帶到這一輪相同的列上，回傳帶了幾列。

    相同＝review_pack.candidate_sha256 一樣（候選全文、異動條文ID、異動摘要、掛的
    本本異動新舊文）。上一輪同一把鑰匙有好幾列時照順序一對一配，不會一列配兩次。
    人自己在 Excel 加的欄（承辦註記之類）一起帶過來。
    """
    if not previous:
        return 0
    prev_rows, prev_items = previous
    prev_book = {"changes": prev_items}
    pool = {}
    for row in prev_rows:
        if _has_answer(row):
            # 被 Excel 存過的表，換行會變成 \r\n；比對前收斂，跟 read_table 同一把尺
            key_row = dict(row, 候選全文=dt.normalize_newlines(row.get("候選全文") or ""))
            pool.setdefault(rp.candidate_sha256(key_row, prev_book), []).append(row)
    if not pool:
        return 0
    known = set(dt.COLUMNS) | set(dt.OPTIONAL_COLUMNS)
    book = {"changes": items}
    carried = 0
    for row in rows:
        bucket = pool.get(rp.candidate_sha256(row, book))
        if not bucket:
            continue
        old = bucket.pop(0)
        for field in CARRY_FIELDS:
            row[field] = dt.normalize_newlines(old.get(field) or "")
        for field, value in old.items():
            if field and field not in known and value:
                row[field] = value
        row["沿用上一輪"] = "是"
        carried += 1
    return carried
