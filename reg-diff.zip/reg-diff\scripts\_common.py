# -*- coding: utf-8 -*-
"""
共用工具模組。

四支腳本(check_env / diff_compare / fuzzy_duplicate_finder / embedding_similarity)
共用的東西都放這裡，避免同一段讀檔邏輯在三個檔案裡各寫一次、改了一個忘了改另外兩個。

這個檔案不會單獨執行，是被其他腳本 import 用的。
"""

import difflib
import io
import os
import re
import sys


# ---------------------------------------------------------------------------
# 主控台編碼
# ---------------------------------------------------------------------------

def setup_console():
    """
    讓中文在 Windows 主控台不要變亂碼。

    Windows 的命令提示字元預設用 cp950(繁中Big5)，Python 印 UTF-8 中文會變成一堆
    問號跟怪符號。這裡把標準輸出改成 UTF-8。Python 3.7 以上才有 reconfigure，
    舊版就用 TextIOWrapper 包一層，兩種都失敗就放棄(只是會亂碼，不影響檔案輸出)。
    """
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name, None)
        if stream is None:
            continue
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except AttributeError:
            try:
                setattr(sys, name, io.TextIOWrapper(
                    stream.buffer, encoding="utf-8", errors="replace"))
            except Exception:
                pass
        except Exception:
            pass


# ---------------------------------------------------------------------------
# 讀檔
# ---------------------------------------------------------------------------

try:
    from docx import Document
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False


SUPPORTED_EXTS = (".docx", ".txt", ".md")


def read_paragraphs(filepath):
    """
    讀取內規檔案，回傳「段落列表」(每個元素是一段文字，已去掉前後空白、跳過空行)。

    支援 .docx / .txt / .md。
    不支援舊版 .doc(Word 97-2003 二進位格式)，遇到會明確擋下來並告訴使用者怎麼轉檔,
    因為 python-docx 讀不了 .doc，硬讀會拋出看不懂的錯誤訊息。

    .docx 有兩條讀取路徑：裝了 python-docx 就用它，沒裝就用標準函式庫拆 zip
    (read_docx_stdlib)。兩者輸出完全相同，所以在裝不了套件的環境也讀得了 Word 檔。
    """
    if not os.path.exists(filepath):
        raise SystemExit("錯誤：找不到檔案 %s\n請確認路徑有沒有打錯，含空白的路徑要用雙引號括起來。" % filepath)

    ext = os.path.splitext(filepath)[1].lower()

    if ext == ".doc":
        raise SystemExit(
            "錯誤：不支援舊版 .doc 格式(Word 97-2003)。\n"
            "請先用 Word 開啟該檔，另存新檔選「Word 文件 (*.docx)」之後再跑一次。")

    if ext == ".docx":
        if not HAS_DOCX:
            # 沒有 python-docx 就改用標準函式庫拆 zip 讀。兩條路徑輸出完全一致，
            # 有測試逐段比對盯著。這樣在套件庫固定、裝不了東西的企業平台上，
            # 讀 Word 檔仍然成立——內規幾乎都是 .docx，讀不了等於整套工具不能用。
            return read_docx_stdlib(filepath)
        doc = Document(filepath)
        paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
        # Word 表格裡的條文也要讀進來，內規常把附表條文放在表格中，只讀 paragraphs 會整段漏掉
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    text = cell.text.strip()
                    if text:
                        paragraphs.append(text)
        return paragraphs

    if ext in (".txt", ".md"):
        raw = open(filepath, "rb").read()
        content = _decode_text(raw)
        return [line.strip() for line in content.splitlines() if line.strip()]

    raise SystemExit("錯誤：不支援的檔案格式 %s，目前支援 %s" % (ext, "、".join(SUPPORTED_EXTS)))


def _decode_text(raw):
    """
    純文字檔解碼。台灣的內規文字檔常常是 Big5 或 UTF-8-BOM 存的，
    寫死 encoding='utf-8' 會直接 UnicodeDecodeError，所以依序試幾種常見編碼。
    """
    for enc in ("utf-8-sig", "utf-8", "cp950", "big5hkscs"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


# ---------------------------------------------------------------------------
# 條號辨識
# ---------------------------------------------------------------------------

_CN_NUM = "零〇一二三四五六七八九十百千兩"

_ARTICLE_PATTERNS = [
    re.compile(r"^第\s*[%s\d]+\s*條\s*之\s*[%s\d]+" % (_CN_NUM, _CN_NUM)),  # 第五條之一
    re.compile(r"^第\s*[%s\d]+\s*條" % _CN_NUM),                             # 第五條
    re.compile(r"^第\s*[%s\d]+\s*[點項款目章節]" % _CN_NUM),                  # 第三點 / 第二章
    re.compile(r"^[%s]+\s*、" % _CN_NUM),                                    # 一、
    re.compile(r"^\(?[%s\d]+\)" % _CN_NUM),                                  # (一) / (1)
    re.compile(r"^\d+(\.\d+)*\s"),                                           # 1.2.3
]


def extract_article_no(text):
    """
    從段落開頭抓出條號，例如「第五條之一 ……」回傳「第五條之一」。
    抓不到就回傳空字串——內規格式五花八門，抓不到是正常的，不要在這裡硬猜，
    寧可留白讓人工填，也不要生一個錯的條號進正式對照表。
    """
    if not text:
        return ""
    for pattern in _ARTICLE_PATTERNS:
        match = pattern.match(text)
        if match:
            # 只去掉條號中間的空白（「第 五 條」->「第五條」），不要動標點。
            # 「一、」的頓號要保留：拿掉之後只剩「一」，在對照表的條號欄裡看不出
            # 那是條號還是內文的第一個字，人工核對時容易誤判。
            return re.sub(r"\s+", "", match.group(0))
    return ""


def article_no_for(old_text, new_text):
    """對照表要顯示的條號：優先取新版的，新版沒有(整段被刪)就取舊版的。"""
    return extract_article_no(new_text or "") or extract_article_no(old_text or "")


# ---------------------------------------------------------------------------
# 輸出路徑
# ---------------------------------------------------------------------------

def resolve_output(outdir, prefix, filename):
    """
    組出輸出檔完整路徑，並確保資料夾存在。

    有 prefix 的話會加在檔名前面(例如 prefix='壽險內規' -> '壽險內規_修正對照表.csv')，
    這樣連續比對好幾份內規時不會後面一份把前面一份的結果蓋掉。
    """
    if outdir:
        if not os.path.isdir(outdir):
            os.makedirs(outdir)
    else:
        outdir = "."
    if prefix:
        filename = "%s_%s" % (prefix, filename)
    return os.path.join(outdir, filename)


def strip_article_no(text):
    """
    把段落開頭的條號拿掉，只留條文本體。

    比相似度時要用這個。原因：條號本身不是條文內容，卻會干擾分數。
    「第三條 逾期未繳超過三十日者……」跟「第二十二條 保險費未於到期日後未繳納者……」
    是同一件事寫在不同章節，但光是「第三條」對「第二十二條」這幾個字就先扣掉一截分數。
    實測拿掉條號後，真正相關的條文分數幾乎不變(53.1 -> 51.3)，不相干的條文卻從
    22~32 掉到 11~18，訊號雜訊比明顯拉開。
    """
    if not text:
        return ""
    article_no = extract_article_no(text)
    if not article_no:
        return text

    # extract_article_no 回傳的是去掉空白後的字串，這裡要從原文往前走同樣多的「非空白字元」
    consumed = 0
    cursor = 0
    while cursor < len(text) and consumed < len(article_no):
        if not text[cursor].isspace():
            consumed += 1
        cursor += 1
    return text[cursor:].lstrip(" 　、：:．.") or text


def diff_runs(old_text, new_text, min_equal=2):
    """
    比對同一條的新舊文字，回傳字級的標記片段：[(種類, 文字), ...]
    種類是 "equal"／"delete"／"insert"。

    為什麼要做到字級：
    整段刪掉再整段加回來，人得把兩行從頭讀到尾自己找出差在哪。實際上第一條
    只改了「一百十五年」五個字，對照表就該只標那五個字，其餘維持黑字。
    這也是修正對照表本來的閱讀方式。

    min_equal：夾在兩處修改中間、短到沒有意義的相同片段（預設少於 2 個字），
    直接併進修改範圍。否則中文很容易標成一串紅黑相間的碎屑，反而看不出改了什麼。
    """
    matcher = difflib.SequenceMatcher(None, old_text or "", new_text or "")
    runs = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            runs.append(("equal", old_text[i1:i2]))
        elif tag == "delete":
            runs.append(("delete", old_text[i1:i2]))
        elif tag == "insert":
            runs.append(("insert", new_text[j1:j2]))
        else:
            runs.append(("delete", old_text[i1:i2]))
            runs.append(("insert", new_text[j1:j2]))

    # 把過短的 equal 片段併掉：它前後都有修改時才併，段落頭尾的不動
    merged = []
    for idx, (kind, text) in enumerate(runs):
        too_short = (kind == "equal" and len(text) < min_equal
                     and 0 < idx < len(runs) - 1)
        if too_short:
            merged.append(("delete", text))
            merged.append(("insert", text))
        else:
            merged.append((kind, text))

    # 相鄰同種類的片段合併起來，避免產生一堆零碎的 run
    collapsed = []
    for kind, text in merged:
        if collapsed and collapsed[-1][0] == kind:
            collapsed[-1] = (kind, collapsed[-1][1] + text)
        else:
            collapsed.append((kind, text))
    return [(kind, text) for kind, text in collapsed if text]


# ---------------------------------------------------------------------------
# 層級脈絡（章／節／條／項／款／目）
# ---------------------------------------------------------------------------

_CHAPTER_RE = re.compile(r"^第\s*([%s\d]+)\s*章" % _CN_NUM)
_SECTION_RE = re.compile(r"^第\s*([%s\d]+)\s*節" % _CN_NUM)
_ARTICLE_RE = re.compile(r"^第\s*[%s\d]+\s*條(\s*之\s*[%s\d]+)?" % (_CN_NUM, _CN_NUM))
_CLAUSE_RE = re.compile(r"^([%s]+)\s*、" % _CN_NUM)              # 款：一、二、三、
_ITEM_RE = re.compile(r"^[（(]\s*([%s\d]+)\s*[）)]" % _CN_NUM)    # 目：(一)(二)(三)


def build_hierarchy(paragraphs):
    """
    走一遍全文，算出每一段所在的層級位置。

    為什麼需要這個：
    條號只看單一段落是不夠的。「(二)」單獨拿出來看毫無意義——一份 50 頁的內規
    裡有幾百個「(二)」，對照表寫「條號：(二)」等於沒寫，人工核對時根本找不到
    它在哪一條底下。必須從頭往下走，記住現在走到第幾章、第幾節、第幾條，
    才能把它還原成「第三十三條第一款第二目」這種找得到的引用。

    回傳與 paragraphs 等長的列表，每個元素是 dict：
        chapter / section / article  ── 所在的章、節、條（字串，沒有就空字串）
        ref                          ── 完整條號引用，例如「第三十三條第一款第二目」
        level                        ── 章／節／條／項／款／目／其他
    """
    contexts = []
    chapter = section = article = ""
    clause = ""          # 目前所在的款（「二、」→「第二款」）
    paragraph_no = 0     # 條底下第幾項（條文本身算第一項）

    for text in paragraphs:
        chapter_match = _CHAPTER_RE.match(text)
        section_match = _SECTION_RE.match(text)
        article_match = _ARTICLE_RE.match(text)
        clause_match = _CLAUSE_RE.match(text)
        item_match = _ITEM_RE.match(text)

        if chapter_match:
            chapter = re.sub(r"\s+", "", chapter_match.group(0))
            section = article = clause = ""
            paragraph_no = 0
            level, ref = "章", chapter
        elif section_match:
            section = re.sub(r"\s+", "", section_match.group(0))
            article = clause = ""
            paragraph_no = 0
            level, ref = "節", section
        elif article_match:
            article = re.sub(r"\s+", "", article_match.group(0))
            clause = ""
            paragraph_no = 1
            level, ref = "條", article
        elif clause_match:
            clause = "第%s款" % clause_match.group(1)
            level, ref = "款", article + clause
        elif item_match:
            item = "第%s目" % item_match.group(1)
            level, ref = "目", article + clause + item
        else:
            # 沒有任何編號的段落。在條底下就是「項」，條號要標第幾項，
            # 否則同一條有三項時，對照表分不出改的是哪一項。
            if article:
                paragraph_no += 1
                level = "項"
                ref = article + ("第%s項" % _cn_from_int(paragraph_no)
                                 if paragraph_no > 1 else "")
            else:
                level, ref = "其他", ""

        contexts.append({
            "chapter": chapter, "section": section, "article": article,
            "ref": ref, "level": level,
        })

    return contexts


_CN_DIGITS = "一二三四五六七八九十"


def _cn_from_int(value):
    """小數字轉中文，只給項次用，內規一條很少超過十幾項。"""
    if 1 <= value <= 10:
        return _CN_DIGITS[value - 1]
    if value < 20:
        return "十" + _CN_DIGITS[value - 11]
    tens, ones = divmod(value, 10)
    return _CN_DIGITS[tens - 1] + "十" + (_CN_DIGITS[ones - 1] if ones else "")


def format_scope(context):
    """對照表「章節」欄要顯示的內容，例如「第一章 第三節」。"""
    if not context:
        return ""
    parts = [p for p in (context.get("chapter"), context.get("section")) if p]
    return " ".join(parts)


# ---------------------------------------------------------------------------
# 不靠 python-docx 讀 .docx（給套件庫固定、裝不了東西的環境用）
# ---------------------------------------------------------------------------

_W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def read_docx_stdlib(filepath):
    """
    只用標準函式庫讀 .docx，不需要 python-docx。

    為什麼需要這條路：
    有些企業 AI 平台的執行環境套件庫是固定的，裝不了 python-docx。
    但內規幾乎都是 Word 檔，讀不了 .docx 等於整套工具在那種環境不能用。

    .docx 其實就是一個 zip，條文放在裡面的 word/document.xml。
    用 zipfile ＋ xml.etree 就能拆出來，兩者都是標準函式庫。

    行為刻意與 python-docx 版本一致：先取本文段落，再把表格儲存格的內容接在後面
    （內規常把附表條文放在表格裡）。這樣兩條路徑產出的結果才會完全相同。
    """
    import zipfile
    import xml.etree.ElementTree as ET

    try:
        with zipfile.ZipFile(filepath) as archive:
            xml_bytes = archive.read("word/document.xml")
    except KeyError:
        raise SystemExit(
            "錯誤：%s 不是有效的 Word 檔（裡面找不到 word/document.xml）。" % filepath)
    except zipfile.BadZipFile:
        raise SystemExit(
            "錯誤：%s 不是有效的 .docx。若這是舊版 .doc，請先用 Word 另存成 .docx。"
            % filepath)

    body = ET.fromstring(xml_bytes).find("%sbody" % _W_NS)
    if body is None:
        return []

    paragraphs = []
    tables = []
    for child in body:
        if child.tag == "%sp" % _W_NS:
            text = _docx_paragraph_text(child)
            if text:
                paragraphs.append(text)
        elif child.tag == "%stbl" % _W_NS:
            tables.append(child)

    for table in tables:
        for row in table.iter("%str" % _W_NS):
            for cell in row.iter("%stc" % _W_NS):
                # 儲存格內可能有多段，python-docx 用換行接起來，這裡跟著做
                cell_text = "\n".join(
                    _docx_paragraph_text(p) for p in cell.iter("%sp" % _W_NS))
                cell_text = cell_text.strip()
                if cell_text:
                    paragraphs.append(cell_text)

    return paragraphs


def _docx_paragraph_text(paragraph):
    """把一個 <w:p> 裡所有 <w:t> 的文字接起來，跟 python-docx 的 paragraph.text 一致。"""
    return "".join(node.text or "" for node in paragraph.iter("%st" % _W_NS)).strip()
