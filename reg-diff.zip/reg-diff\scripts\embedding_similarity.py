# -*- coding: utf-8 -*-
"""
Step 3：語意相似度比對（次要、選用）

Step 2 的模糊比對是比「字面」，兩條規定如果用詞完全不同就抓不到，例如：
    A 條寫「保險費」、B 條寫「應繳金額」，但兩條講的都是繳費期限。
這支程式改用語意向量比對，補上這一塊。

這是加分項，不是必要步驟。跑不起來（套件沒裝、公司網路連不到 Hugging Face
下載模型）就直接跳過，Step 1、Step 2 的結果完全不受影響。跳過時本程式會以
正常狀態結束（exit code 0），不會讓整個流程中斷，但會明確告訴你這步被跳過了。

--------------------------------------------------------------------------
使用方式（跟 Step 2 的參數長得一樣）
--------------------------------------------------------------------------
    python embedding_similarity.py 新版全文.docx "第三條 逾期未繳超過三十日者……"
    python embedding_similarity.py 新版全文.docx --changed-line 4
    python embedding_similarity.py 新版全文.docx --from-csv 修正對照表.csv

可調參數：
    --threshold 0.60   語意相似度門檻，0~1，預設 0.60
    --top 15           每個修改段落最多列幾筆
    --model 名稱或路徑  預設 paraphrase-multilingual-MiniLM-L12-v2（支援中文）

--------------------------------------------------------------------------
公司電腦連不到外網時
--------------------------------------------------------------------------
可以在有網路的機器上先把模型抓下來，整個資料夾複製到公司電腦，再用本機路徑跑：
    python embedding_similarity.py 新版全文.docx --from-csv 修正對照表.csv ^
        --model D:\models\paraphrase-multilingual-MiniLM-L12-v2
"""

import argparse
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, extract_article_no,
                     resolve_output)
from fuzzy_duplicate_finder import load_changes_from_csv

DEFAULT_MODEL = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
DEFAULT_THRESHOLD = 0.60
DEFAULT_TOP = 15

SKIP_NOTICE = (
    "\n" + "-" * 60 + "\n"
    "Step 3（語意相似度）本次跳過，不影響 Step 1、Step 2 的結果。\n"
    "影響：用詞完全不同、但意思相關的條文可能沒被抓出來，請在人工複核時多留意。\n"
    + "-" * 60)


def load_model(model_name):
    """
    載入語意模型。

    回傳 model，載入不了就回傳 None（呼叫端負責印跳過訊息並正常結束）。
    這裡把「套件沒裝」跟「連不到網路 / 下載失敗」分開報，因為處理方式不一樣：
    前者跑 check_env.py 就好，後者要離線搬模型。
    """
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError:
        print("提醒：沒有安裝 sentence-transformers，無法做語意相似度比對。")
        print("      要啟用的話請執行：python check_env.py")
        return None

    print("正在載入語意模型：%s" % model_name)
    print("（第一次執行需要從網路下載模型，約幾百 MB，之後會用快取不再重載）")
    try:
        return SentenceTransformer(model_name)
    except Exception as exc:
        print("提醒：模型載入失敗，無法做語意相似度比對。")
        print("      錯誤訊息：%s" % exc)
        print("      常見原因是公司網路擋掉 Hugging Face。可以在有網路的機器上先下載模型，")
        print("      複製到本機後用 --model 指定資料夾路徑。")
        return None


def encode(model, texts):
    """把文字轉成已正規化的向量，正規化後兩向量內積就是餘弦相似度。"""
    return model.encode(texts, convert_to_numpy=True,
                        normalize_embeddings=True, show_progress_bar=False)


def find_similar(query_vector, paragraph_vectors, all_paragraphs,
                 threshold=DEFAULT_THRESHOLD, top=DEFAULT_TOP, exclude_index=None):
    """算出修改段落跟全文每一段的餘弦相似度，回傳超過門檻的候選。"""
    scores = paragraph_vectors.dot(query_vector)

    candidates = []
    for idx, score in enumerate(scores):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        if float(score) < threshold:
            continue
        candidates.append({
            "line_number": line_no,
            "article_no": extract_article_no(all_paragraphs[idx]),
            "text": all_paragraphs[idx],
            "similarity": round(float(score), 3),
        })

    candidates.sort(key=lambda c: c["similarity"], reverse=True)
    return candidates[:top] if top and top > 0 else candidates


def print_candidates(changed_text, candidates, threshold):
    head = changed_text if len(changed_text) <= 40 else changed_text[:40] + "…"
    print("\n" + "=" * 60)
    print("修改段落：%s" % head)
    print("=" * 60)

    if not candidates:
        print("沒有找到語意相似度超過 %.2f 的候選條文。" % threshold)
        return

    print("共 %d 筆候選（依語意相似度排序）：\n" % len(candidates))
    for i, c in enumerate(candidates, 1):
        label = c["article_no"] or ("第%d段" % c["line_number"])
        print("[候選%d] 語意相似度 %.3f ｜ %s（第%d段）"
              % (i, c["similarity"], label, c["line_number"]))
        print("  內容：%s" % c["text"])
        print()


def write_candidates_csv(rows, output_path):
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["修改段落條號", "修改後文字", "候選條號", "候選段次",
                         "候選條文", "語意相似度", "是否一併修改（人工填寫）"])
        for row in rows:
            writer.writerow(row)
    print("\n已產生語意相似候選清單：%s" % output_path)


def main():
    setup_console()
    parser = argparse.ArgumentParser(description="Step 3：語意相似度比對（選用）")
    parser.add_argument("regulation_file",
                        help="【新版】內規全文檔案（.docx / .txt / .md）")
    parser.add_argument("changed_text", nargs="?", default=None,
                        help="你修改後的那段文字；也可改用 --changed-line 或 --from-csv")
    parser.add_argument("--changed-line", type=int, default=None,
                        help="修改段落在新版全文裡的段次")
    parser.add_argument("--from-csv", default=None,
                        help="Step 1 產出的 修正對照表.csv，一次比對所有修改段落")
    parser.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD,
                        help="語意相似度門檻 0~1，預設 %g" % DEFAULT_THRESHOLD)
    parser.add_argument("--top", type=int, default=DEFAULT_TOP,
                        help="每個修改段落最多列幾筆，預設 %d，設 0 表示全部" % DEFAULT_TOP)
    parser.add_argument("--model", default=DEFAULT_MODEL,
                        help="模型名稱或本機資料夾路徑，預設 %s" % DEFAULT_MODEL)
    parser.add_argument("--outdir", default="", help="輸出資料夾，預設為目前目錄")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    model = load_model(args.model)
    if model is None:
        print(SKIP_NOTICE)
        return None   # 正常結束，不讓整個流程中斷

    print("正在讀取新版內規全文：%s" % args.regulation_file)
    all_paragraphs = read_paragraphs(args.regulation_file)
    print("全文共 %d 段。" % len(all_paragraphs))

    if args.from_csv:
        changes = load_changes_from_csv(args.from_csv)
        if not changes:
            raise SystemExit("錯誤：%s 裡沒有讀到任何修改段落。" % args.from_csv)
    elif args.changed_line is not None:
        if not (1 <= args.changed_line <= len(all_paragraphs)):
            raise SystemExit("錯誤：--changed-line %d 超出範圍，全文只有 %d 段。"
                             % (args.changed_line, len(all_paragraphs)))
        text = all_paragraphs[args.changed_line - 1]
        changes = [{"article_no": extract_article_no(text), "type": "修改",
                    "text": text, "line_number": args.changed_line}]
    elif args.changed_text:
        changes = [{"article_no": extract_article_no(args.changed_text), "type": "修改",
                    "text": args.changed_text, "line_number": None}]
    else:
        raise SystemExit(
            "錯誤：要指定修改了哪一段（直接貼文字 / --changed-line / --from-csv 三選一）。")

    print("正在計算全文向量（段落多的話這裡要等一下）...")
    paragraph_vectors = encode(model, all_paragraphs)
    query_vectors = encode(model, [c["text"] for c in changes])

    csv_rows = []
    total = 0
    for change, query_vector in zip(changes, query_vectors):
        candidates = find_similar(query_vector, paragraph_vectors, all_paragraphs,
                                  threshold=args.threshold, top=args.top,
                                  exclude_index=change["line_number"])
        total += len(candidates)
        print_candidates(change["text"], candidates, args.threshold)
        for c in candidates:
            csv_rows.append([change["article_no"], change["text"],
                             c["article_no"], c["line_number"], c["text"],
                             c["similarity"], ""])

    if csv_rows:
        write_candidates_csv(
            csv_rows, resolve_output(args.outdir, args.prefix, "語意相似候選清單.csv"))

    print("\n" + "-" * 60)
    print("語意比對完成：%d 個修改段落，共列出 %d 筆候選。" % (len(changes), total))
    print("提醒：語意比對是輔助性質，結果需與 Step 2 的模糊比對清單合併後人工確認。")
    print("-" * 60)

    return csv_rows


if __name__ == "__main__":
    main()
