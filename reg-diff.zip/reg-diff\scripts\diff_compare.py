# -*- coding: utf-8 -*-
"""
Step 1：新舊內規精確文字比對工具

這支程式做的事情：
1. 讀取舊版跟新版兩份內規文件
2. 逐段比對，找出哪裡「新增」、哪裡「刪除」、哪裡「修改」
3. 輸出四份東西(後兩份需要 python-docx)：
   a. 修正對照表.csv   ── 條號、修改類型、原文、修改後文字、新版段次(可用 Excel 開)
   b. 標註版全文.txt   ── 新增文字用【新增：...】包起來、刪除用【刪除：...】
   c. 標註版全文.docx  ── 修改後全文，紅字底線(新增)/刪除線(刪除)
   d. 修正對照表.docx  ── 正式對照表，橫式表格，末欄「修改依據／理由」留白給人工填

兩份 Word 檔的紅字只標「真正改動的那幾個字」，不是整段刪掉再整段加回來。

使用方式：
    python diff_compare.py 舊版.docx 新版.docx
    python diff_compare.py 舊版.txt 新版.txt --prefix 壽險內規 --outdir 輸出
    python diff_compare.py 舊版.docx 新版.docx --title "○○作業要點修正對照表"

CSV 裡的「新版段次」欄位很重要，Step 2 的 fuzzy_duplicate_finder.py 會用到，
不要自己手動改動那一欄的數字。
"""

import argparse
import csv
import difflib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, article_no_for,
                     build_hierarchy, diff_runs, format_scope,
                     strip_article_no, resolve_output, HAS_DOCX)

# 兩段文字相似度要到這個程度，才會被判定成「同一條被改過」而不是「刪一條、加一條」。
# 0.45 是從實際保險內規條文抓出來的：改寫幅度大的同一條(例如「要保人應於保險費到期日前
# 繳納保險費」改寫成「保險費應由要保人於到期日前繳納」)相似度約 0.62，而不相干的兩條
# 通常低於 0.35，抓 0.45 剛好落在中間。
PAIR_THRESHOLD = 0.45

# 對齊演算法是 O(n*m) 且每格都要算一次相似度，replace 區塊太大時會很慢。
# 超過這個乘積就退回逐段配對(這種情況幾乎只出現在整章重寫，本來也沒有一對一關係)。
MAX_ALIGN_CELLS = 20000


def _ratio(a, b):
    """兩段文字的相似度 0.0~1.0。先用便宜的估算擋掉明顯不像的，省下大量計算。"""
    matcher = difflib.SequenceMatcher(None, a, b)
    if matcher.real_quick_ratio() < PAIR_THRESHOLD:
        return 0.0
    if matcher.quick_ratio() < PAIR_THRESHOLD:
        return 0.0
    return matcher.ratio()


def align_chunk(old_chunk, new_chunk):
    """
    把 difflib 判定為「這一整塊被換掉」的舊段落群跟新段落群，做一次一對一對齊。

    為什麼需要這個：difflib 只會告訴你「舊版第 3~5 段被換成新版第 3~6 段」，
    不會告訴你誰對誰。如果直接按順序 1對1、2對2 硬配，只要中間插進一段新條文，
    後面全部錯開一格──「第三條」會被配到「第二條之一」，對照表的條號整串跑掉。
    正式修法文件出這種錯是不能接受的。

    這裡用序列對齊(類似 Needleman-Wunsch)：在「不能交叉、要保持前後順序」的前提下，
    找出總相似度最高的配對方式。配得起來的算「修改」，配不到的分別算「刪除」跟「新增」。

    回傳 [(old_text 或 None, new_text 或 None), ...]，順序即最終呈現順序。
    """
    n, m = len(old_chunk), len(new_chunk)
    if n == 0:
        return [(None, t) for t in new_chunk]
    if m == 0:
        return [(t, None) for t in old_chunk]
    if n * m > MAX_ALIGN_CELLS:
        # 區塊過大，退回逐段配對；這是保守作法，寧可粗略也不要跑到天荒地老
        pairs = []
        for k in range(max(n, m)):
            pairs.append((old_chunk[k] if k < n else None,
                          new_chunk[k] if k < m else None))
        return pairs

    # sim[i][j]：舊版第 i 段 跟 新版第 j 段 的相似度，低於門檻的直接記 0(代表不可配對)
    sim = [[0.0] * m for _ in range(n)]
    for i in range(n):
        for j in range(m):
            score = _ratio(old_chunk[i], new_chunk[j])
            sim[i][j] = score if score >= PAIR_THRESHOLD else 0.0

    # dp[i][j]：對齊「舊版前 i 段」跟「新版前 j 段」能拿到的最高總分
    dp = [[0.0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            best = dp[i - 1][j]                 # 舊版這段沒人配 -> 刪除
            if dp[i][j - 1] > best:
                best = dp[i][j - 1]             # 新版這段沒人配 -> 新增
            if sim[i - 1][j - 1] > 0.0:
                paired = dp[i - 1][j - 1] + sim[i - 1][j - 1]
                if paired > best:
                    best = paired               # 兩段配成一對 -> 修改
            dp[i][j] = best

    # 從右下角往回走，還原出實際的配對方式
    pairs = []
    i, j = n, m
    while i > 0 or j > 0:
        if i > 0 and j > 0 and sim[i - 1][j - 1] > 0.0 and \
                abs(dp[i][j] - (dp[i - 1][j - 1] + sim[i - 1][j - 1])) < 1e-9:
            pairs.append((old_chunk[i - 1], new_chunk[j - 1]))
            i -= 1
            j -= 1
        elif j > 0 and abs(dp[i][j] - dp[i][j - 1]) < 1e-9:
            pairs.append((None, new_chunk[j - 1]))
            j -= 1
        elif i > 0:
            pairs.append((old_chunk[i - 1], None))
            i -= 1
        else:
            j -= 1
    pairs.reverse()
    return pairs


def compare_paragraphs(old_paragraphs, new_paragraphs):
    """
    逐段比對舊版跟新版，回傳比對結果列表，每個元素是：
    {
        "type": "unchanged" / "added" / "deleted" / "modified",
        "old_text": 舊版文字(沒有就是 None),
        "new_text": 新版文字(沒有就是 None),
        "old_index": 在舊版是第幾段(從 1 起算，沒有就是 None),
        "new_index": 在新版是第幾段(從 1 起算，沒有就是 None),
        "ref": 完整條號引用，例如「第三十三條第二款第二目」,
        "scope": 所屬章節，例如「第一章 第三節」,
    }

    ref / scope 是從全文的層級結構推算出來的，不是單看這一段。款目的編號
    （「二、」「(二)」）單看沒有意義，一份 50 頁的內規裡有幾百個「(二)」，
    對照表得寫出它掛在哪一條底下才找得到。
    """
    old_context = build_hierarchy(old_paragraphs)
    new_context = build_hierarchy(new_paragraphs)

    def annotate(entry):
        """依段落位置補上條號引用與所屬章節；新版沒有的（整段刪除）就用舊版的。"""
        if entry["new_index"]:
            context = new_context[entry["new_index"] - 1]
        elif entry["old_index"]:
            context = old_context[entry["old_index"] - 1]
        else:
            context = None
        entry["ref"] = (context["ref"] if context else "") or article_no_for(
            entry["old_text"], entry["new_text"])
        entry["scope"] = format_scope(context)
        return classify_renumbered(entry)

    def classify_renumbered(entry):
        """
        把「只有編號變了、內容一個字沒動」的段落標成「編號調整」，跟實質修改分開。

        為什麼要分：刪掉一條底下的第二款之後，後面的款全部要往前遞補，
        三、變二、、四、變三、。這些段落的內容完全沒動，但逐段比對會把它們
        全部判定成「修改」。50 頁的內規刪掉幾個款，對照表就會被幾十筆
        編號位移灌爆，真正該看的實質異動反而被埋掉。
        """
        if entry["type"] != "modified":
            return entry
        if strip_article_no(entry["old_text"]) == strip_article_no(entry["new_text"]):
            entry["type"] = "renumbered"
        return entry

    matcher = difflib.SequenceMatcher(None, old_paragraphs, new_paragraphs)
    results = []

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for offset in range(i2 - i1):
                results.append(annotate({
                    "type": "unchanged",
                    "old_text": old_paragraphs[i1 + offset],
                    "new_text": new_paragraphs[j1 + offset],
                    "old_index": i1 + offset + 1,
                    "new_index": j1 + offset + 1,
                }))

        elif tag == "replace":
            old_chunk = old_paragraphs[i1:i2]
            new_chunk = new_paragraphs[j1:j2]
            old_cursor, new_cursor = i1, j1
            for old_text, new_text in align_chunk(old_chunk, new_chunk):
                if old_text is not None and new_text is not None:
                    results.append(annotate({
                        "type": "modified", "old_text": old_text, "new_text": new_text,
                        "old_index": old_cursor + 1, "new_index": new_cursor + 1,
                    }))
                    old_cursor += 1
                    new_cursor += 1
                elif old_text is not None:
                    results.append(annotate({
                        "type": "deleted", "old_text": old_text, "new_text": None,
                        "old_index": old_cursor + 1, "new_index": None,
                    }))
                    old_cursor += 1
                else:
                    results.append(annotate({
                        "type": "added", "old_text": None, "new_text": new_text,
                        "old_index": None, "new_index": new_cursor + 1,
                    }))
                    new_cursor += 1

        elif tag == "delete":
            for offset in range(i2 - i1):
                results.append(annotate({
                    "type": "deleted", "old_text": old_paragraphs[i1 + offset],
                    "new_text": None, "old_index": i1 + offset + 1, "new_index": None,
                }))

        elif tag == "insert":
            for offset in range(j2 - j1):
                results.append(annotate({
                    "type": "added", "old_text": None,
                    "new_text": new_paragraphs[j1 + offset],
                    "old_index": None, "new_index": j1 + offset + 1,
                }))

    return results


TYPE_LABELS = {"added": "新增", "deleted": "刪除",
               "modified": "修改", "renumbered": "編號調整"}


def write_csv_report(results, output_path):
    """把比對結果寫成 CSV 對照表。只列有改變的，沒改的不列。"""
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["序號", "章節", "條號", "修改類型", "原文", "修改後文字", "新版段次"])
        idx = 1
        for r in results:
            if r["type"] == "unchanged":
                continue
            writer.writerow([
                idx,
                r.get("scope", ""),
                r.get("ref") or article_no_for(r["old_text"], r["new_text"]),
                TYPE_LABELS.get(r["type"], r["type"]),
                r["old_text"] or "（無，此為新增段落）",
                r["new_text"] or "（無，此段落已刪除）",
                r["new_index"] if r["new_index"] else "",
            ])
            idx += 1

    print("已產生對照表：%s" % output_path)


def write_annotated_text(results, output_path):
    """標註版全文：新增標【新增：...】，刪除標【刪除：...】。"""
    lines = []
    for r in results:
        if r["type"] == "unchanged":
            lines.append(r["new_text"])
        elif r["type"] == "added":
            lines.append("【新增：%s】" % r["new_text"])
        elif r["type"] == "deleted":
            lines.append("【刪除：%s】" % r["old_text"])
        elif r["type"] in ("modified", "renumbered"):
            lines.append("【刪除：%s】【新增：%s】" % (r["old_text"], r["new_text"]))

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print("已產生標註版全文：%s" % output_path)


RED = (0xC0, 0x00, 0x00)


def _add_marked_runs(paragraph, runs, show_deleted=True, show_inserted=True):
    """
    把 diff_runs() 產出的片段寫進 Word 段落，套上修正對照表的標示慣例：
    新增 = 紅字加底線、刪除 = 紅字加刪除線、沒動到的維持黑字。

    show_deleted / show_inserted 控制這一格要顯示哪一邊。
    對照表的「原文」欄只該出現刪除標記，「修改後文字」欄只該出現新增標記，
    兩欄各自讀起來才會是完整通順的一條條文。標註版全文則兩邊都顯示。
    """
    from docx.shared import RGBColor

    for kind, text in runs:
        if kind == "delete" and not show_deleted:
            continue
        if kind == "insert" and not show_inserted:
            continue

        run = paragraph.add_run(text)
        if kind == "delete":
            run.font.color.rgb = RGBColor(*RED)
            run.font.strike = True
        elif kind == "insert":
            run.font.color.rgb = RGBColor(*RED)
            run.font.underline = True


def _runs_for(result):
    """依修改類型算出這一筆要標示的片段。"""
    if result["type"] == "added":
        return [("insert", result["new_text"])]
    if result["type"] == "deleted":
        return [("delete", result["old_text"])]
    if result["type"] in ("modified", "renumbered"):
        return diff_runs(result["old_text"], result["new_text"])
    return [("equal", result["new_text"])]


def export_to_docx(results, output_path):
    """
    輸出標註版全文的 Word 檔：新增紅字底線、刪除紅字刪除線，其餘黑字。

    修改的段落只標「真正改掉的那幾個字」，不是整段刪掉再整段加回來。
    整段標紅的話，第一條那種只加了「一百十五年」五個字的修改，人還是得把
    前後兩行從頭讀到尾自己找差異，等於沒標。
    """
    if not HAS_DOCX:
        print("提醒：沒有安裝 python-docx，跳過 Word 檔輸出，只產生純文字標註版。")
        print("      要有紅字底線刪除線格式的話，請先執行：python check_env.py")
        return

    from docx import Document

    doc = Document()
    for r in results:
        paragraph = doc.add_paragraph()
        _add_marked_runs(paragraph, _runs_for(r))

    doc.save(output_path)
    print("已產生標註版全文 Word 檔（紅字底線/刪除線格式）：%s" % output_path)


def _shade_cell(cell, hex_color):
    """幫表格儲存格上底色。python-docx 沒有現成 API，要直接塞 XML。"""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    shading = OxmlElement("w:shd")
    shading.set(qn("w:val"), "clear")
    shading.set(qn("w:fill"), hex_color)
    cell._tc.get_or_add_tcPr().append(shading)


def export_table_to_docx(results, output_path, title="修正對照表"):
    """
    輸出正式的修正對照表 Word 檔（橫式、表格、紅字標示）。

    這是要送出去的文件，格式依一般修正對照表慣例：
    - 橫式版面，因為原文跟修改後文字要並排看
    - 「原文」欄只顯示刪除標記，「修改後文字」欄只顯示新增標記，
      兩欄各自都是一條讀得通的完整條文
    - 「修改依據/理由」留空白欄位給人工填，程式不會自己編理由
    """
    if not HAS_DOCX:
        print("提醒：沒有安裝 python-docx，跳過修正對照表 Word 檔輸出（CSV 版仍有產生）。")
        print("      要 Word 版對照表的話，請先執行：python check_env.py")
        return

    from docx import Document
    from docx.enum.section import WD_ORIENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm, Pt

    changes = [r for r in results if r["type"] != "unchanged"]

    doc = Document()

    # 橫式版面：原文與修改後文字並排，直式會擠成兩條細長欄位很難讀
    section = doc.sections[0]
    section.orientation = WD_ORIENT.LANDSCAPE
    section.page_width, section.page_height = section.page_height, section.page_width
    for attr in ("left_margin", "right_margin"):
        setattr(section, attr, Cm(1.5))

    heading = doc.add_paragraph()
    heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
    heading_run = heading.add_run(title)
    heading_run.font.size = Pt(18)
    heading_run.font.bold = True

    columns = ["序號", "章節", "條號", "修改類型", "原文", "修改後文字", "修改依據／理由"]
    widths = [Cm(1.2), Cm(3.0), Cm(3.4), Cm(1.5), Cm(7.0), Cm(7.0), Cm(3.4)]

    table = doc.add_table(rows=1, cols=len(columns))
    table.style = "Table Grid"

    for cell, name, width in zip(table.rows[0].cells, columns, widths):
        cell.width = width
        _shade_cell(cell, "E8E8E8")
        run = cell.paragraphs[0].add_run(name)
        run.font.bold = True
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

    for idx, result in enumerate(changes, 1):
        cells = table.add_row().cells
        for cell, width in zip(cells, widths):
            cell.width = width

        cells[0].text = str(idx)
        cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        cells[1].text = result.get("scope", "")
        cells[2].text = (result.get("ref")
                         or article_no_for(result["old_text"], result["new_text"]))
        cells[3].text = TYPE_LABELS.get(result["type"], result["type"])
        cells[3].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

        runs = _runs_for(result)
        if result["type"] == "added":
            cells[4].text = "（無，此為新增段落）"
        else:
            _add_marked_runs(cells[4].paragraphs[0], runs, show_inserted=False)

        if result["type"] == "deleted":
            cells[5].text = "（無，此段落已刪除）"
        else:
            _add_marked_runs(cells[5].paragraphs[0], runs, show_deleted=False)

        # 修改依據／理由留白，由人工填寫。程式不會自己編一個理由進正式文件。

    doc.save(output_path)
    print("已產生修正對照表 Word 檔（橫式表格、紅字標示）：%s" % output_path)


def main():
    setup_console()
    parser = argparse.ArgumentParser(description="Step 1：新舊內規精確文字比對")
    parser.add_argument("old_file", help="舊版內規檔案（.docx / .txt / .md）")
    parser.add_argument("new_file", help="新版內規檔案（.docx / .txt / .md）")
    parser.add_argument("--outdir", default="", help="輸出資料夾，預設為目前目錄")
    parser.add_argument("--title", default="",
                        help="修正對照表 Word 檔的標題，例如 --title \"○○作業要點修正對照表\"")
    parser.add_argument("--prefix", default="",
                        help="輸出檔名前綴，例如 --prefix 壽險內規；連續比對多份內規時用得到，避免互相覆蓋")
    args = parser.parse_args()

    print("正在讀取舊版：%s" % args.old_file)
    old_paragraphs = read_paragraphs(args.old_file)
    print("正在讀取新版：%s" % args.new_file)
    new_paragraphs = read_paragraphs(args.new_file)
    print("舊版 %d 段、新版 %d 段，開始比對..." % (len(old_paragraphs), len(new_paragraphs)))

    results = compare_paragraphs(old_paragraphs, new_paragraphs)

    counts = {"added": 0, "deleted": 0, "modified": 0, "renumbered": 0}
    for r in results:
        if r["type"] in counts:
            counts[r["type"]] += 1
    total = sum(counts.values())
    print("比對完成，共 %d 處差異（新增 %d、刪除 %d、修改 %d）。"
          % (total - counts["renumbered"], counts["added"],
             counts["deleted"], counts["modified"]))
    if counts["renumbered"]:
        print("另有 %d 處只是編號調整（內容未變動），已在對照表中另行標示為「編號調整」。"
              % counts["renumbered"])

    write_csv_report(results, resolve_output(args.outdir, args.prefix, "修正對照表.csv"))
    write_annotated_text(results, resolve_output(args.outdir, args.prefix, "標註版全文.txt"))
    export_to_docx(results, resolve_output(args.outdir, args.prefix, "標註版全文.docx"))
    export_table_to_docx(results, resolve_output(args.outdir, args.prefix, "修正對照表.docx"),
                         title=(args.title or "修正對照表"))

    return results


if __name__ == "__main__":
    main()
