# -*- coding: utf-8 -*-
"""
全流程整合測試：把六支腳本從頭到尾串一遍，確認整條流程真的跑得完。

selftest.py 測的是「每個函式的行為對不對」，這支測的是「六支腳本用命令列
串起來會不會壞」——參數對不對得上、前一步的輸出是不是後一步吃得下的格式、
中途有沒有哪支跳出非零結束代碼。這兩種問題不一樣，函式層測試抓不到後者。

用約 50 頁、含章節條款目的內規當輸入，並且刻意先刪掉一個款不重編，
好讓 Step 0.5 有東西可以做。

執行：
    python tests/run_pipeline.py            跑完並印出各步驟摘要
    python tests/run_pipeline.py --keep     保留產出的檔案供檢視

全部步驟成功回結束代碼 0，任一步失敗回 1。
"""

import argparse
import io
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(os.path.dirname(HERE), "scripts")
sys.path.insert(0, SCRIPTS)
sys.path.insert(0, HERE)

from _common import setup_console, read_paragraphs
import make_large_fixture


def run(step, script, args, cwd, expect_files=()):
    """跑一支腳本，回傳結果摘要。"""
    started = time.time()
    process = subprocess.Popen(
        [sys.executable, os.path.join(SCRIPTS, script)] + args, cwd=cwd,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output, _ = process.communicate()
    elapsed = time.time() - started
    text = output.decode("utf-8", "replace")

    missing = [name for name in expect_files
               if not os.path.exists(os.path.join(cwd, name))]

    return {
        "step": step, "script": script, "code": process.returncode,
        "elapsed": elapsed, "output": text, "missing": missing,
        "ok": process.returncode == 0 and not missing,
    }


def prepare(workdir):
    """產生大型測試內規，並刻意刪掉一個款、不重編，讓 Step 0.5 有事可做。"""
    rng = make_large_fixture.random.Random(make_large_fixture.SEED)
    old_lines, index = make_large_fixture.build_document(rng)
    duplicates = make_large_fixture.seed_duplicates(old_lines, index)
    new_lines, _ = make_large_fixture.plant_changes(old_lines, index, duplicates)

    # 找第一個有三款以上的條，把它的第二款刪掉（不重編，模擬真實情境）
    from _common import build_hierarchy
    contexts = build_hierarchy(new_lines)
    counts = {}
    for context in contexts:
        if context["level"] == "款":
            counts[context["article"]] = counts.get(context["article"], 0) + 1
    target = next(a for a, n in counts.items() if n >= 3)

    seen = 0
    for idx, context in enumerate(contexts):
        if context["level"] == "款" and context["article"] == target:
            seen += 1
            if seen == 2:
                del new_lines[idx]
                break

    old_path = os.path.join(workdir, "舊版內規.txt")
    new_path = os.path.join(workdir, "新版內規.txt")
    io.open(old_path, "w", encoding="utf-8").write("\n".join(old_lines) + "\n")
    io.open(new_path, "w", encoding="utf-8").write("\n".join(new_lines) + "\n")
    return old_path, new_path, target


def main():
    setup_console()
    parser = argparse.ArgumentParser(description="全流程整合測試")
    parser.add_argument("--keep", action="store_true", help="保留產出的檔案")
    args = parser.parse_args()

    workdir = tempfile.mkdtemp(prefix="reg-diff-pipeline-")
    print("=" * 66)
    print("全流程整合測試")
    print("工作目錄：%s" % workdir)
    print("=" * 66)

    old_path, new_path, target = prepare(workdir)
    print("\n測試輸入：%d 段 / %d 字，並刻意刪掉 %s 的第二款且未重編"
          % (len(read_paragraphs(old_path)),
             sum(len(p) for p in read_paragraphs(old_path)), target))

    steps = [
        ("Step 0　環境檢查", "check_env.py", [], ()),
        ("Step 0.5 款目重編", "renumber.py",
         [new_path, "--old", old_path, "--apply", "--rewrite-refs"],
         ("重編後_新版內規.txt",)),
        ("Step 1　精確比對", "diff_compare.py",
         [old_path, "重編後_新版內規.txt", "--title", "測試內規修正對照表"],
         ("修正對照表.csv", "修正對照表.docx",
          "標註版全文.docx", "標註版全文.txt")),
        ("Step 1.6 品質檢查", "rule_checks.py",
         ["重編後_新版內規.txt", "--old", old_path],
         ("條文檢查報告.csv",)),
        ("Step 2　重複條文", "fuzzy_duplicate_finder.py",
         ["重編後_新版內規.txt", "--from-csv", "修正對照表.csv"],
         ("重複條文候選清單.csv",)),
        ("Step 3　語意相似", "embedding_similarity.py",
         ["重編後_新版內規.txt", "--from-csv", "修正對照表.csv"], ()),
    ]

    results = []
    for step, script, step_args, expect in steps:
        result = run(step, script, step_args, workdir, expect)
        results.append(result)
        status = "OK" if result["ok"] else "失敗"
        print("\n[%s] %-18s %-28s %.2fs  結束代碼 %d"
              % (status, step, script, result["elapsed"], result["code"]))
        if result["missing"]:
            print("       缺少預期產出：%s" % "、".join(result["missing"]))
        if not result["ok"]:
            print("       輸出末段：")
            for line in result["output"].strip().splitlines()[-8:]:
                print("         %s" % line)

    print("\n" + "=" * 66)
    print("各步驟關鍵產出")
    print("=" * 66)
    _summarise(workdir, results)

    failed = [r for r in results if not r["ok"]]
    print("\n" + "=" * 66)
    if failed:
        print("有 %d 個步驟失敗：%s"
              % (len(failed), "、".join(r["step"] for r in failed)))
    else:
        print("六個步驟全部跑完，產出齊全。")
    print("=" * 66)

    if args.keep:
        print("\n產出保留於：%s" % workdir)
    else:
        shutil.rmtree(workdir, ignore_errors=True)

    return 1 if failed else 0


def _summarise(workdir, results):
    """把各步驟的重點數字撈出來，讓人一眼看出流程真的有在做事。"""
    import csv

    def count_rows(name):
        path = os.path.join(workdir, name)
        if not os.path.exists(path):
            return None
        with io.open(path, encoding="utf-8-sig", newline="") as f:
            return max(len(list(csv.reader(f))) - 1, 0)

    renumber_output = next((r for r in results if "renumber" in r["script"]), None)
    if renumber_output:
        lines = [l for l in renumber_output["output"].splitlines()
                 if "要重編的段落" in l or "必須人工處理" in l or "解析不出來" in l]
        for line in lines:
            print("  Step 0.5 ｜ %s" % line.strip())

    rows = count_rows("修正對照表.csv")
    if rows is not None:
        print("  Step 1   ｜ 對照表 %d 列" % rows)

    checks = count_rows("條文檢查報告.csv")
    if checks is not None:
        path = os.path.join(workdir, "條文檢查報告.csv")
        with io.open(path, encoding="utf-8-sig", newline="") as f:
            severities = [row["嚴重程度"] for row in csv.DictReader(f)]
        print("  Step 1.6 ｜ 檢查發現 %d 項（高 %d、中 %d、低 %d）"
              % (checks, severities.count("高"),
                 severities.count("中"), severities.count("低")))

    candidates = count_rows("重複條文候選清單.csv")
    if candidates is not None:
        print("  Step 2   ｜ 重複條文候選 %d 列" % candidates)

    semantic = next((r for r in results if "embedding" in r["script"]), None)
    if semantic:
        state = "跳過（未安裝套件）" if "本次跳過" in semantic["output"] else "已執行"
        print("  Step 3   ｜ %s" % state)


if __name__ == "__main__":
    sys.exit(main())
