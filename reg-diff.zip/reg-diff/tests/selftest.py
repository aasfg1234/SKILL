# -*- coding: utf-8 -*-
"""
自我檢查腳本：跑完整流程，逐項驗證結果是否符合預期。

用途：
- 剛拿到這個 skill 時，先跑一次確認環境沒問題
- 之後有人改了腳本，跑一次確認沒有改壞
- 換一台電腦、換一個 Python 版本時，確認行為一致

執行：
    python tests/selftest.py

全部通過 -> 印「全部通過」，結束代碼 0
有任何一項失敗 -> 印出「預期 vs 實際」，結束代碼 1
"""

import csv
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(os.path.dirname(HERE), "scripts")
sys.path.insert(0, SCRIPTS)
sys.path.insert(0, HERE)

from _common import (setup_console, read_paragraphs, build_hierarchy,
                     extract_article_no, load_synonyms, normalize_terms,
                     load_table_format,
                     read_docx_stdlib, strip_article_no, synonym_evidence)
import diff_compare
import fuzzy_duplicate_finder as fuzzy
import renumber
import rule_checks

OLD_FILE = os.path.join(HERE, "舊版_招攬及繳費作業要點.txt")
NEW_FILE = os.path.join(HERE, "新版_招攬及繳費作業要點.txt")

_failures = []
_passes = []


def check(label, expected, actual):
    """比對單項結果。相等就記一筆通過，否則記下預期與實際。"""
    if expected == actual:
        _passes.append(label)
        print("  [通過] %s" % label)
    else:
        _failures.append((label, expected, actual))
        print("  [失敗] %s" % label)
        print("         預期：%r" % (expected,))
        print("         實際：%r" % (actual,))


def check_true(label, condition, detail=""):
    check(label, True, bool(condition)) if not detail else check(
        "%s（%s）" % (label, detail), True, bool(condition))


def section(title):
    print("\n" + "=" * 62)
    print(title)
    print("=" * 62)


# ---------------------------------------------------------------------------
# 1. 條號辨識與剝除
# ---------------------------------------------------------------------------

def test_article_no():
    section("1. 條號辨識（extract_article_no / strip_article_no）")

    cases = [
        ("第五條 逾期未繳者，契約停止效力。", "第五條", "逾期未繳者，契約停止效力。"),
        ("第十二條之一 業務人員於網路招攬。", "第十二條之一", "業務人員於網路招攬。"),
        ("第三點 應行注意事項如下。", "第三點", "應行注意事項如下。"),
        ("一、 業務人員應出示登錄證。", "一、", "業務人員應出示登錄證。"),
        # 公文的「目」幾乎都寫全形括號。早期只認半形，最常見的那種反而抓不到，
        # 對照表的條號欄會整欄空白，Step 2 比對時也少剝掉一段前綴。
        ("（一）本公司應於受理後完成核保。", "（一）", "本公司應於受理後完成核保。"),
        ("(一)本公司應於受理後完成核保。", "(一)", "本公司應於受理後完成核保。"),
        ("（1）本公司應於受理後完成核保。", "（1）", "本公司應於受理後完成核保。"),
        ("（刪除）", "", "（刪除）"),
        ("沒有條號的一整段說明文字。", "", "沒有條號的一整段說明文字。"),
    ]
    for text, expected_no, expected_body in cases:
        check("條號「%s」" % (expected_no or "（無）"), expected_no, extract_article_no(text))
        check("剝條號「%s」" % (expected_no or "（無）"), expected_body, strip_article_no(text))


# ---------------------------------------------------------------------------
# 2. 讀檔與編碼
# ---------------------------------------------------------------------------

def test_reading(workdir):
    section("2. 讀檔與編碼")

    old_paragraphs = read_paragraphs(OLD_FILE)
    new_paragraphs = read_paragraphs(NEW_FILE)
    check("舊版段落數", 20, len(old_paragraphs))
    check("新版段落數", 20, len(new_paragraphs))

    # Big5：台灣的內規純文字檔常見編碼，寫死 UTF-8 會直接爆
    big5_path = os.path.join(workdir, "big5內規.txt")
    with open(big5_path, "wb") as f:
        f.write("第一條 本要點依保險法訂定。\n第二條 要保人應繳納保險費。\n".encode("cp950"))
    check("Big5 檔讀得出來", ["第一條 本要點依保險法訂定。", "第二條 要保人應繳納保險費。"],
          read_paragraphs(big5_path))

    # UTF-8 帶 BOM：從 Excel 或記事本另存最常見的格式
    bom_path = os.path.join(workdir, "bom內規.txt")
    with open(bom_path, "wb") as f:
        f.write("第一條 本要點依保險法訂定。\n".encode("utf-8-sig"))
    check("UTF-8 BOM 檔不會殘留 BOM 字元", ["第一條 本要點依保險法訂定。"],
          read_paragraphs(bom_path))

    # 舊版 .doc 要明確擋下，不是丟出看不懂的錯誤
    doc_path = os.path.join(workdir, "舊格式.doc")
    open(doc_path, "wb").close()
    try:
        read_paragraphs(doc_path)
        check(".doc 被擋下", True, False)
    except SystemExit as exc:
        check(".doc 被擋下並提示轉檔", True, "另存新檔" in str(exc))


# ---------------------------------------------------------------------------
# 3. Step 1 精確比對（重點：條號不能錯位）
# ---------------------------------------------------------------------------

# 這份測試資料預期的完整比對結果。
# 總則章的三筆（修改/新增/修改 緊鄰）就是條號錯位的觸發條件，
# 舊版逐段硬配的寫法會把「第二條」錯配成「第一條之一」，這裡要驗證不會再發生。
EXPECTED_CHANGES = [
    ("第一條",    "修改", "3"),
    ("第一條之一", "新增", "4"),
    ("第二條",    "修改", "5"),
    ("第五條",    "修改", "9"),
    ("第六條",    "刪除", ""),
]


def read_csv_rows(csv_path):
    """
    讀對照表 CSV，並把欄位標題換回內部鍵。

    對照表的欄位標題可以在 對照表格式.json 改（「原文」可以印成「原條文」），
    測試如果照字面讀標題，各單位換個標題測試就全紅了。程式端的 --from-csv
    也是走同一套對應，這裡跟著走才測得到真實行為。
    """
    title_to_key = {c["標題"]: c["鍵"]
                    for c in load_table_format().get("欄位", [])
                    if c.get("標題") and c.get("鍵")}
    with io.open(csv_path, encoding="utf-8-sig", newline="") as f:
        return [{title_to_key.get(k, k): v for k, v in row.items()}
                for row in csv.DictReader(f)]


def read_change_rows(csv_path):
    """從對照表 CSV 讀出 (條號, 修改類型, 新版段次) 清單。"""
    return [(r["條號"], r["修改類型"], r["新版段次"])
            for r in read_csv_rows(csv_path)]


def test_step1(workdir):
    section("3. Step 1 精確比對")

    outdir = os.path.join(workdir, "step1")
    old_paragraphs = read_paragraphs(OLD_FILE)
    new_paragraphs = read_paragraphs(NEW_FILE)
    results = diff_compare.compare_paragraphs(old_paragraphs, new_paragraphs)

    csv_path = os.path.join(outdir, "修正對照表.csv")
    os.makedirs(outdir)
    diff_compare.write_csv_report(results, csv_path)

    rows = read_change_rows(csv_path)
    check("差異筆數", len(EXPECTED_CHANGES), len(rows))
    check("條號／類型／段次 完全正確", EXPECTED_CHANGES, rows)

    # 沒改到的段落不能被誤報。舊版共 20 段，其中 4 段有動（第一條、第二條、
    # 第五條 三段修改 + 第六條刪除），所以未修改的應該剛好 16 段。
    unchanged = [r for r in results if r["type"] == "unchanged"]
    check("未修改段落數", 16, len(unchanged))

    # 財產保險章、網路投保章這次都沒動，不該出現在對照表裡
    changed_articles = {row[0] for row in rows}
    for article in ("第九條", "第十二條", "第十二條之一"):
        check("%s 未被誤報為修改" % article, False, article in changed_articles)

    return csv_path, outdir


def test_step1_docx(workdir, txt_csv_path):
    section("4. Step 1 讀 Word 檔的結果要跟讀純文字一致")

    docx_dir = os.path.join(workdir, "docx")
    os.makedirs(docx_dir)
    try:
        from docx import Document
    except ImportError:
        print("  [略過] 沒有安裝 python-docx，跳過 Word 檔測試")
        print("         要測請先執行：python scripts/check_env.py")
        return None, None

    # 最後一段刻意放進表格，驗證表格內的條文也讀得到（內規常把附表放表格）
    paths = {}
    for label, source in (("舊版", OLD_FILE), ("新版", NEW_FILE)):
        lines = read_paragraphs(source)
        document = Document()
        for line in lines[:-1]:
            document.add_paragraph(line)
        table = document.add_table(rows=1, cols=1)
        table.rows[0].cells[0].text = lines[-1]
        path = os.path.join(docx_dir, "%s.docx" % label)
        document.save(path)
        paths[label] = path

    check("Word 檔段落數（含表格內容）", 20, len(read_paragraphs(paths["新版"])))

    results = diff_compare.compare_paragraphs(
        read_paragraphs(paths["舊版"]), read_paragraphs(paths["新版"]))
    docx_csv = os.path.join(docx_dir, "修正對照表.csv")
    diff_compare.write_csv_report(results, docx_csv)
    check("Word 檔比對結果與純文字一致",
          read_change_rows(txt_csv_path), read_change_rows(docx_csv))

    # 紅字底線刪除線的 Word 檔要真的產得出來
    annotated = os.path.join(docx_dir, "標註版全文.docx")
    diff_compare.export_to_docx(results, annotated)
    check("標註版全文 Word 檔已產生", True, os.path.exists(annotated))

    table_docx = os.path.join(docx_dir, "修正對照表.docx")
    diff_compare.export_table_to_docx(results, table_docx, title="測試用修正對照表")
    check("修正對照表 Word 檔已產生", True, os.path.exists(table_docx))
    return table_docx, annotated


def marked_text(paragraph):
    """把 Word 段落還原成可比對的字串，新增標 [增...]、刪除標 [刪...]。"""
    pieces = []
    for run in paragraph.runs:
        if run.font.strike:
            pieces.append("[刪%s]" % run.text)
        elif run.font.underline:
            pieces.append("[增%s]" % run.text)
        else:
            pieces.append(run.text)
    return "".join(pieces)


def test_docx_marking(table_docx, annotated):
    section("5. Word 檔的紅字標示要落在「真正改掉的那幾個字」")

    if not table_docx:
        print("  [略過] 沒有安裝 python-docx")
        return

    from docx import Document

    document = Document(table_docx)
    check("對照表為橫式版面（原文與修改後要並排）", True,
          document.sections[0].page_width > document.sections[0].page_height)

    table = document.tables[0]
    check("表格列數（表頭 1 列 + 差異 5 列）", 6, len(table.rows))
    # 表頭要跟設定檔一致，不寫死——欄位標題本來就是各單位可以自己改的
    from _common import load_table_format
    expected_headers = [c["標題"] for c in load_table_format()["欄位"]]
    check("表頭欄位與設定檔一致", expected_headers,
          [c.text for c in table.rows[0].cells])

    # 第一條只加了「一百十五年」五個字，就只該標這五個字，其餘維持黑字。
    # 舊寫法是整段刪掉再整段加回來，人得把兩行從頭讀到尾自己找差異。
    row = table.rows[1]
    check("條號欄", "第一條", row.cells[2].text)
    # 章節欄只放編號不放章名：Word 表格這一欄只有 3cm，放「第一章 總則」會逐列換行
    # 撐高整張表；條號本身已足以定位，章節只是給人快速掃描用的區塊標示。
    check("章節欄帶出所屬章", "第一章", row.cells[1].text)
    check("修改後文字只標真正新增的字",
          "第一條 本要點依保險法第一百四十八條之三及主管機關[增一百十五年]函釋訂定。",
          marked_text(row.cells[5].paragraphs[0]))
    check("原文欄不出現新增標記（該欄要讀得通）",
          "第一條 本要點依保險法第一百四十八條之三及主管機關函釋訂定。",
          marked_text(row.cells[4].paragraphs[0]))
    check("修改依據／理由留白給人工填", "", row.cells[6].text)

    # 整條刪除：原文欄整段刪除線，修改後欄註明已刪除
    deleted_row = table.rows[5]
    check("刪除的條文在原文欄整段標刪除線",
          "[刪第六條 業務人員不得為誇大不實之說明。]",
          marked_text(deleted_row.cells[4].paragraphs[0]))
    check("刪除的條文在修改後欄註明已刪除",
          "（無，此段落已刪除）", deleted_row.cells[5].text)

    # 標註版全文：同樣只標改動的字
    changed_lines = [marked_text(p) for p in Document(annotated).paragraphs
                     if "[增" in marked_text(p) or "[刪" in marked_text(p)]
    check("標註版全文有標記的段落數", 5, len(changed_lines))
    check("標註版全文的修改段落也只標改動處",
          "第五條 逾期未繳[增超過三十日]者，契約停止效力。",
          changed_lines[3])

    # 刪字（不是加字）的方向也要對，且兩欄各自都要讀得通
    runs = diff_compare.diff_runs(
        "第七條 業務人員應於招攬時親自出示登錄證及名片。",
        "第七條 業務人員應於招攬時出示登錄證。")
    check("刪字時原文欄標出被刪的字",
          "第七條 業務人員應於招攬時[刪親自]出示登錄證[刪及名片]。",
          "".join(("[刪%s]" % t if k == "delete" else t)
                  for k, t in runs if k != "insert"))
    check("刪字時修改後欄乾淨無標記",
          "第七條 業務人員應於招攬時出示登錄證。",
          "".join(t for k, t in runs if k != "delete"))


# ---------------------------------------------------------------------------
# 5. Step 2 跨章節重複條文（這個 skill 的核心價值）
# ---------------------------------------------------------------------------

def test_step2():
    section("6. Step 2 跨章節重複條文抓取")

    paragraphs = read_paragraphs(NEW_FILE)

    # 案例一：第五條被改了，但財產保險章的第九條(一模一樣)、
    #         網路投保章的第十二條(換句話說)都沒跟著改
    changed = "第五條 逾期未繳超過三十日者，契約停止效力。"
    candidates = fuzzy.find_duplicates(changed, paragraphs, exclude_index=9)
    found = {c["article_no"] for c in candidates}

    check("第五條→抓到財產險章第九條（一模一樣的漏改）", True, "第九條" in found)
    check("第五條→抓到網路投保章第十二條（換句話說的漏改）", True, "第十二條" in found)
    check("第五條→不會抓到自己", False, "第五條" in found)

    scores = {c["article_no"]: c["similarity"] for c in candidates}
    check_true("第九條分數高於第十二條（一模一樣的應該排前面）",
               scores.get("第九條", 0) > scores.get("第十二條", 0),
               "第九條 %.1f vs 第十二條 %.1f" % (scores.get("第九條", 0), scores.get("第十二條", 0)))

    # 最長共同片段是給人工分流用的：整條照抄的片段長，換句話說的片段短
    fragments = {c["article_no"]: c["fragment_len"] for c in candidates}
    check_true("第九條的共同片段比第十二條長",
               fragments.get("第九條", 0) > fragments.get("第十二條", 0),
               "第九條 %d 字 vs 第十二條 %d 字"
               % (fragments.get("第九條", 0), fragments.get("第十二條", 0)))

    # 案例二：第六條被整條刪掉，網路投保章的第十二條之一講同一件事，也該一併檢視
    deleted = "第六條 業務人員不得為誇大不實之說明。"
    deleted_found = {c["article_no"] for c in fuzzy.find_duplicates(deleted, paragraphs)}
    check("第六條（刪除）→抓到網路投保章第十二條之一", True, "第十二條之一" in deleted_found)

    # 舊門檻 70 會漏掉「換句話說」那一類，這裡驗證確實會漏，證明下修門檻是必要的
    at_old_threshold = {c["article_no"] for c in
                        fuzzy.find_duplicates(changed, paragraphs, threshold=70, exclude_index=9)}
    check("門檻 70 確實會漏掉第十二條（下修到 45 的理由）", False, "第十二條" in at_old_threshold)


def test_step2_from_csv(csv_path):
    section("7. Step 2 批次模式（--from-csv 一次跑完所有修改段落）")

    changes = fuzzy.load_changes_from_csv(csv_path)
    check("讀到的修改段落數", 5, len(changes))

    by_article = {c["article_no"]: c for c in changes}
    check("刪除的第六條有被納入比對", True, "第六條" in by_article)
    check("刪除段落取用的是原文",
          "第六條 業務人員不得為誇大不實之說明。", by_article["第六條"]["text"])
    check("刪除段落沒有新版段次（新版已無此段）", None, by_article["第六條"]["line_number"])
    check("第五條的新版段次", 9, by_article["第五條"]["line_number"])


# ---------------------------------------------------------------------------
# 7. 命令列介面
# ---------------------------------------------------------------------------

def run_cli(args, cwd):
    """執行腳本並回傳 (結束代碼, 輸出文字)。"""
    process = subprocess.Popen(
        [sys.executable] + args, cwd=cwd,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output, _ = process.communicate()
    return process.returncode, output.decode("utf-8", "replace")


def test_cli(workdir):
    section("8. 命令列介面")

    outdir = os.path.join(workdir, "cli")
    os.makedirs(outdir)

    code, output = run_cli(
        [os.path.join(SCRIPTS, "diff_compare.py"), OLD_FILE, NEW_FILE,
         "--outdir", outdir, "--prefix", "招攬要點"], workdir)
    check("Step 1 命令列結束代碼", 0, code)
    check("Step 1 加了 --prefix 的檔名",
          True, os.path.exists(os.path.join(outdir, "招攬要點_修正對照表.csv")))
    try:
        import docx  # noqa: F401
        for filename in ("招攬要點_修正對照表.docx", "招攬要點_標註版全文.docx"):
            check("命令列產出 %s" % filename,
                  True, os.path.exists(os.path.join(outdir, filename)))
    except ImportError:
        print("  [略過] 沒有安裝 python-docx，跳過 Word 檔產出檢查")

    code, output = run_cli(
        [os.path.join(SCRIPTS, "fuzzy_duplicate_finder.py"), NEW_FILE,
         "--from-csv", os.path.join(outdir, "招攬要點_修正對照表.csv"),
         "--outdir", outdir, "--prefix", "招攬要點"], workdir)
    check("Step 2 命令列結束代碼", 0, code)
    check("Step 2 候選清單已產生",
          True, os.path.exists(os.path.join(outdir, "招攬要點_重複條文候選清單.csv")))
    check("Step 2 有列出第九條", True, "第九條" in output)
    check("Step 2 有列出第十二條", True, "第十二條" in output)

    # --changed-line：段次超出範圍要給看得懂的錯誤，不是丟 IndexError
    code, output = run_cli(
        [os.path.join(SCRIPTS, "fuzzy_duplicate_finder.py"), NEW_FILE,
         "--changed-line", "999"], workdir)
    check("--changed-line 超出範圍會擋下", True, "超出範圍" in output)

    # 三個指定方式都沒給時，要告訴使用者怎麼做，不是丟 traceback
    code, output = run_cli(
        [os.path.join(SCRIPTS, "fuzzy_duplicate_finder.py"), NEW_FILE], workdir)
    check("沒指定修改段落時給出用法說明", True, "--from-csv" in output)
    check("沒指定修改段落時不會噴 traceback", False, "Traceback" in output)



# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 9. 大型內規（約 50 頁，含 章／節／條／款／目 完整層級）
# ---------------------------------------------------------------------------

def test_large_document(workdir):
    section("9. 大型內規：約 50 頁，章／節／條／款／目 完整層級")

    # 部署用的精簡包不含測資產生器（它只在開發時用得到），
    # 缺了就跳過這一組，不要讓整份自我檢查掛掉。
    try:
        import make_large_fixture
    except ImportError:
        print("  [略過] 這一包不含 make_large_fixture.py（部署精簡版）")
        print("         其餘檢查照常執行，不影響部署驗證")
        return

    outdir = os.path.join(workdir, "large")
    rng_seeded = make_large_fixture.random.Random(make_large_fixture.SEED)
    old_lines, index = make_large_fixture.build_document(rng_seeded)
    duplicates = make_large_fixture.seed_duplicates(old_lines, index)
    new_lines, plants = make_large_fixture.plant_changes(old_lines, index, duplicates)

    total_chars = sum(len(line) for line in old_lines)
    pages = total_chars / 900.0
    check_true("文本規模達 50 頁量級", 45 <= pages <= 60,
               "%d 段 / %d 字 / 約 %.0f 頁" % (len(old_lines), total_chars, pages))

    levels = {}
    for context in build_hierarchy(old_lines):
        levels[context["level"]] = levels.get(context["level"], 0) + 1
    for level in ("章", "節", "條", "項", "款", "目"):
        check_true("文本含有「%s」層級" % level, levels.get(level, 0) > 0,
                   "%d 段" % levels.get(level, 0))

    # --- Step 1：對照表的每一列都要對得上埋伏清單 ---
    started = time.time()
    results = diff_compare.compare_paragraphs(old_lines, new_lines)
    elapsed = time.time() - started
    check_true("比對 1200 段在 10 秒內完成", elapsed < 10, "實際 %.2f 秒" % elapsed)

    os.makedirs(outdir)
    csv_path = os.path.join(outdir, "修正對照表.csv")
    diff_compare.write_csv_report(results, csv_path)

    rows = read_csv_rows(csv_path)

    by_type = {}
    for row in rows:
        by_type.setdefault(row["修改類型"], []).append(row)
    check("差異筆數（5 組埋伏共 7 處異動）", 7, len(rows))
    check("其中修改 5 筆", 5, len(by_type.get("修改", [])))
    check("其中新增 1 筆", 1, len(by_type.get("新增", [])))
    check("其中刪除 1 筆", 1, len(by_type.get("刪除", [])))

    refs = [row["條號"] for row in rows]
    plants_by_type = {plant["類型"]: plant for plant in plants}

    # 埋伏 2：條號錯位。修改→新增→修改 三段緊鄰，條號不能整串跑掉
    misalign = plants_by_type["條號錯位觸發"]
    for label, key in (("修改", "修改"), ("新增", "新增"), ("後續修改", "後續修改")):
        check("條號錯位埋伏的%s（%s）有正確列出" % (label, misalign[key]),
              True, misalign[key] in refs)

    # 埋伏 3、4：款目層級。這是 50 頁文本才會現形的問題——
    # 「(二)」單獨寫在條號欄毫無意義，全文有幾百個「(二)」，
    # 必須還原成「第三十三條第二款第二目」才找得到。
    clause_plant = plants_by_type["款層級修改"]
    item_plant = plants_by_type["目層級修改"]
    clause_row = next((r for r in rows if r["修改後文字"] == clause_plant["修改後文字"]), None)
    item_row = next((r for r in rows if r["修改後文字"] == item_plant["修改後文字"]), None)

    check_true("款層級的修改有列出", clause_row is not None)
    check_true("目層級的修改有列出", item_row is not None)
    if clause_row:
        check("款的條號還原出所屬條",
              True, clause_row["條號"].startswith(clause_plant["所屬條"]))
        check("款的條號含款次", True, "款" in clause_row["條號"])
        check("款不會只寫成「二、」", False, clause_row["條號"] in ("二、", "二"))
        check("款帶出所屬章節", clause_plant["所屬節"].split()[0],
              clause_row["章節"].split()[-1])
    if item_row:
        check("目的條號還原出所屬條",
              True, item_row["條號"].startswith(item_plant["所屬條"]))
        check("目的條號含款次與目次",
              True, "款" in item_row["條號"] and "目" in item_row["條號"])
        check("目不會只寫成「(二)」", False, item_row["條號"] in ("(二)", "（二）"))

    # 埋伏 5：整條刪除
    delete_plant = plants_by_type["整條刪除"]
    check("刪除的條有列出", True, delete_plant["條號"] in refs)

    # --- Step 2：跨章重複要抓到另外兩章那兩條 ---
    duplicate_plant = plants_by_type["跨章重複漏改"]
    changed_row = next(r for r in rows if r["條號"] == duplicate_plant["已修改"])
    contexts = build_hierarchy(new_lines)
    candidates = fuzzy.find_duplicates(
        changed_row["修改後文字"], new_lines,
        exclude_index=int(changed_row["新版段次"]), contexts=contexts)

    expected_duplicates = [t["條號"] for t in duplicate_plant["應一併檢視"]]
    top_two = [c["article_no"] for c in candidates[:2]]
    check("跨章重複的兩條排在候選前兩名", sorted(expected_duplicates), sorted(top_two))
    for candidate in candidates[:2]:
        check("%s 的共同片段從句首開始" % candidate["article_no"],
              "句首", candidate["fragment_position"])

    # 這份文本的條文大量共用句尾套語（「…；但金額未達新臺幣十萬元者…」），
    # 會製造出共同片段比真重複還長的假陽性。驗證「片段起點」這個訊號分得開。
    all_candidates = []
    for row in rows:
        text = row["原文"] if row["修改類型"] == "刪除" else row["修改後文字"]
        line_no = int(row["新版段次"]) if row["新版段次"].isdigit() else None
        all_candidates.extend(fuzzy.find_duplicates(
            text, new_lines, exclude_index=line_no, contexts=contexts))

    non_head = [c for c in all_candidates if c["fragment_position"] != "句首"]
    truly_duplicated = set(expected_duplicates)
    check_true("候選數量在可人工消化的範圍", len(all_candidates) <= 120,
               "%d 筆" % len(all_candidates))
    check_true("非句首的候選裡沒有任何一筆是真的重複",
               all(c["article_no"] not in truly_duplicated for c in non_head),
               "非句首 %d 筆全為套語假陽性" % len(non_head))


# ---------------------------------------------------------------------------
# 10. 刪掉一款之後的編號重編與交叉引用
# ---------------------------------------------------------------------------

# 一條四款，第二款被刪掉。第六條刻意寫「前條第二款」，
# 這個引用在刪除後會指到不同的東西 —— 這是本組測試的重點。
RENUM_OLD = [
    "第一章 總則",
    "第五條 要保人申請契約變更時，應檢附下列文件：",
    "一、身分證明文件影本。",
    "二、原保險單正本。",
    "三、契約變更申請書。",
    "四、法定代理人同意書。",
    "第六條 前條第二款文件無法提出者，應出具切結書。",
]
# 使用者刪掉第二款，但沒有重編 —— 剩下 一、三、四
RENUM_NEW_RAW = [p for p in RENUM_OLD if p != "二、原保險單正本。"]
# 使用者刪掉第二款，而且自己先重編過 —— 表面上完全乾淨
RENUM_NEW_TIDY = [
    "第一章 總則",
    "第五條 要保人申請契約變更時，應檢附下列文件：",
    "一、身分證明文件影本。",
    "二、契約變更申請書。",
    "三、法定代理人同意書。",
    "第六條 前條第二款文件無法提出者，應出具切結書。",
]


def test_renumber():
    section("10. 刪掉一款之後：編號重編與交叉引用")

    # --- 情況一：使用者沒有重編，編號斷成 一、三、四 ---
    entries = renumber.scan(RENUM_NEW_RAW)
    problems = renumber.find_numbering_gaps(entries)
    check("偵測到編號不連續", 1, len(problems))
    if problems:
        check("指出目前的編號", [1, 3, 4], problems[0]["written"])
        check("指出應有的編號", [1, 2, 3], problems[0]["expected"])

    changes, clause_map, item_map = renumber.plan_renumber(RENUM_NEW_RAW, entries)
    check("要重編的段落數", 2, len(changes))
    check("第三款改為第二款", (3, 2), (changes[0]["old"], changes[0]["new"]))
    check("第四款改為第三款", (4, 3), (changes[1]["old"], changes[1]["new"]))

    references = renumber.scan_references(
        RENUM_NEW_RAW, entries, clause_map, item_map)
    dangerous = [r for r in references if r["status"] == "危險"]
    check("引用到已刪除的款被標為危險", 1, len(dangerous))
    if dangerous:
        check("標出是哪一段", 6, dangerous[0]["index"])
        check("標出引用的字句", "前條第二款", dangerous[0]["quote"])

    applied = renumber.apply_changes(
        RENUM_NEW_RAW, changes, references, rewrite_refs=True)
    check("重編後的款編號正確",
          ["一、身分證明文件影本。", "二、契約變更申請書。", "三、法定代理人同意書。"],
          applied[2:5])
    # 引用到已刪除款目的地方，即使開了 --rewrite-refs 也絕對不能自動改。
    # 法規的交叉引用指錯，比編號斷掉嚴重得多，這種判斷必須是人做的。
    check("開了 --rewrite-refs 也不會動引用到已刪除款目的句子",
          "第六條 前條第二款文件無法提出者，應出具切結書。", applied[-1])

    # --- 情況二：使用者已自行重編，表面完全乾淨 ---
    tidy_entries = renumber.scan(RENUM_NEW_TIDY)
    check("已重編的版本查不出編號問題", 0,
          len(renumber.find_numbering_gaps(tidy_entries)))
    tidy_changes, _, _ = renumber.plan_renumber(RENUM_NEW_TIDY, tidy_entries)
    check("已重編的版本沒有要重編的段落", 0, len(tidy_changes))

    # 光看新版看不出問題，一定要比對舊版才抓得到「同一個編號指到不同東西」
    drift = renumber.scan_reference_drift(RENUM_OLD, RENUM_NEW_TIDY)
    check("抓到編號沒變但指到的內容變了", 1, len(drift))
    if drift:
        check("列出舊版指的是什麼", "原保險單正本。", drift[0]["old_body"])
        check("列出新版指的是什麼", "契約變更申請書。", drift[0]["new_body"])

    # --- 條號預設不重編（法制慣例：保留條號並註記「（刪除）」）---
    old_articles = ["第五條 甲。", "第六條 乙。", "第七條 丙。"]
    new_articles = ["第五條 甲。", "第七條 丙。"]
    check("找出被整條刪掉的條號", ["第六條"],
          renumber.find_deleted_articles(old_articles, new_articles))
    check("條號本身不會被自動重編", 0,
          len(renumber.plan_renumber(new_articles, renumber.scan(new_articles))[0]))


def test_renumber_in_report():
    section("11. 對照表要把「純編號調整」和實質修改分開")

    results = diff_compare.compare_paragraphs(RENUM_OLD, RENUM_NEW_TIDY)
    by_type = {}
    for r in results:
        by_type[r["type"]] = by_type.get(r["type"], 0) + 1

    # 實質異動只有一筆（刪掉第二款）；另外兩段內容一個字沒動，只是編號往前遞補。
    # 不分開的話，50 頁的內規刪幾個款就會被幾十筆編號位移灌爆對照表。
    check("實質刪除 1 筆", 1, by_type.get("deleted", 0))
    check("純編號調整 2 筆", 2, by_type.get("renumbered", 0))
    check("不會有任何一筆被誤判為實質修改", 0, by_type.get("modified", 0))

    renumbered = [r for r in results if r["type"] == "renumbered"]
    check("編號調整的內容確實完全相同",
          [True, True],
          [diff_compare.strip_article_no(r["old_text"])
           == diff_compare.strip_article_no(r["new_text"]) for r in renumbered])
    check("對照表的類型欄寫「編號調整」", "編號調整",
          diff_compare.TYPE_LABELS["renumbered"])


# ---------------------------------------------------------------------------
# 12. 交叉引用的各種寫法
# ---------------------------------------------------------------------------

# 內規的引用寫法遠不只「第五條第二款」。每一種漏掉，就是一處指錯的引用
# 送進正式修法文件，所以每一種都要有測試盯著。
REF_OLD = [
    "第五條 要保人應檢附下列文件：",
    "一、身分證明文件影本。",
    "二、原保險單正本。",
    "三、契約變更申請書。",
    "四、法定代理人同意書。",
    "第十條 本公司應辦理下列事項：",
    "一、受理登錄。",
    "二、初步審查。",
    "三、核定。",
    "四、通知。",
    "第二十條 依第五條第四款及第十條第四款規定辦理。",
    "第二十一條 第五條第三款至第四款所定文件，保存五年。",
    "第二十二條 本公司得依第五條各款規定要求補正。",
    "第二十三條 業務人員應依前款規定辦理覆核。",
    "第二十四條 依第五條第二款規定辦理者，應另行陳報。",
    "第三十條 本要點自發布日施行。",
    "第三十一條 前開事項依第三十條規定辦理。",
]
# 刪掉第五條第二款，且沒有重編（剩 一、三、四）
REF_NEW = [p for p in REF_OLD if p != "二、原保險單正本。"]


def _reference_findings(paragraphs):
    entries = renumber.scan(paragraphs)
    _, clause_map, item_map = renumber.plan_renumber(paragraphs, entries)
    known = {c["article"] for c in build_hierarchy(paragraphs)
             if c["level"] == "條" and c["article"]}
    return renumber.scan_references(paragraphs, entries, clause_map, item_map,
                                    known_articles=known)


def test_reference_forms():
    section("12. 交叉引用的各種寫法")

    findings = _reference_findings(REF_NEW)
    by_index = {}
    for finding in findings:
        by_index.setdefault(finding["index"], []).append(finding)

    # 「第五條第四款及第十條第四款」──「及」後面的引用不會延用前面的條，
    # 但也不能被當成本條的款。兩個「第四款」分屬不同條，判定必須各自獨立。
    row = by_index.get(10, [])
    rewritable = [f for f in row if f["status"] == "需改寫"]
    check("『及』連接的兩個引用只有第五條那個要改", 1, len(rewritable))
    if rewritable:
        # 報告顯示的字句帶範圍前綴（「第五條第四款」），但改寫只換號碼那一段，
        # 否則會變成「第五條第五條第三款」
        check("報告顯示完整引用字句", "第五條第四款", rewritable[0]["quote"])
        check("改寫只換號碼那一段", "第三款", rewritable[0]["new_quote"])
    check("第十條第四款沒被誤判", 0,
          len([f for f in row if f["status"] in ("危險", "無法判定")]))

    # 範圍寫法：第三款至第四款 → 重編後是第二款至第三款，仍然連續，可機械改寫
    range_row = [f for f in by_index.get(11, []) if f["status"] == "需改寫"]
    check("範圍引用合併成一筆", 1, len(range_row))
    if range_row:
        check("範圍引用的原文", "第三款至第四款", range_row[0]["quote"])
        check("範圍引用改寫兩端", "第二款至第三款", range_row[0]["new_quote"])

    # 「各款」指全部，重編不影響，不該產生雜訊
    check("「各款」不會被報成問題", [], by_index.get(12, []))

    # 「前款」出現在沒有款的條裡 —— 解析不出來就要說解析不出來，不能默默跳過
    unresolved = [f for f in by_index.get(13, []) if f["status"] == "無法判定"]
    check("「前款」在沒有款的條裡會被標為無法判定", 1, len(unresolved))

    # 純條層級的引用，只要那一條還在就不該有雜訊
    check("「依第三十條規定」不會被報成問題", [], by_index.get(16, []))

    # 被刪掉的那一款，任何形式的引用都要抓到
    deleted_refs = [f for f in findings
                    if f["status"] == "危險" and "第二款" in f["note"]]
    check_true("引用到已刪除的第二款會被標為危險", len(deleted_refs) >= 1,
               "%d 筆" % len(deleted_refs))


def test_reference_rewrite_precision():
    section("13. 引用改寫要改對位置")

    entries = renumber.scan(REF_NEW)
    changes, clause_map, item_map = renumber.plan_renumber(REF_NEW, entries)
    findings = _reference_findings(REF_NEW)
    applied = renumber.apply_changes(REF_NEW, changes, findings, rewrite_refs=True)

    # 同一段裡有兩個「第四款」，只有第五條那個該改。
    # 用字串比對取代會改到第一個出現的，所以改寫一定要用位置。
    check("同段有兩個「第四款」時只改對的那一個",
          "第二十條 依第五條第三款及第十條第四款規定辦理。",
          applied[9])
    check("範圍引用兩端一起改",
          "第二十一條 第五條第二款至第三款所定文件，保存五年。",
          applied[10])
    check("款本身的編號也重編正確",
          ["一、身分證明文件影本。", "三、契約變更申請書。", "四、法定代理人同意書。"],
          REF_NEW[1:4])
    check("重編後的款編號",
          ["一、身分證明文件影本。", "二、契約變更申請書。", "三、法定代理人同意書。"],
          applied[1:4])
    check("第十條的款完全沒被動到",
          ["一、受理登錄。", "二、初步審查。", "三、核定。", "四、通知。"],
          applied[5:9])


def test_deleted_article_reference():
    section("14. 引用到被整條刪除的條")

    old = ["第五條 甲事項規定如下。",
           "第六條 乙事項規定如下。",
           "第七條 本公司辦理前開事項，應依第六條規定辦理。"]
    new = [p for p in old if not p.startswith("第六條")]

    check("找出被刪掉的條號", ["第六條"], renumber.find_deleted_articles(old, new))

    findings = _reference_findings(new)
    dangerous = [f for f in findings if f["status"] == "危險"]
    check("引用到不存在的條會被標為危險", 1, len(dangerous))
    if dangerous:
        check("指出是哪一條不見了", True, "第六條" in dangerous[0]["note"])

    # 即使開了 --rewrite-refs，指向已刪除條號的引用也不能自動改
    entries = renumber.scan(new)
    changes, _, _ = renumber.plan_renumber(new, entries)
    applied = renumber.apply_changes(new, changes, findings, rewrite_refs=True)
    check("--rewrite-refs 不會動指向已刪除條號的引用", new, applied)


# ---------------------------------------------------------------------------
# 15. 條文品質與風險檢查（十項）
# ---------------------------------------------------------------------------

QC_OLD = [
    "第一章 總則",
    "第一條 本要點依保險法第一百四十八條之三及金融消費者保護法第七條訂定。",
    "第二條 本要點所稱網路投保，指要保人經由本公司網站投保之行為。",
    "第三條 業務人員招攬時，應主動出示登錄證。",
    "第四條 本公司應於收齊文件之次日起十五日內完成核保。",
    "第五條 要保人不得以他人名義投保。",
    "第六條 保險費逾期未繳超過三十日者，契約停止效力。",
    "第七條 網路投保案件之處理，詳如附表一。",
    "第八條 本要點自發布日施行。",
]
QC_NEW = [
    "第一章 總則",
    "第一條 本要點依保險法第一百四十八條之三及金融消費者保護法第七條訂定。",
    "第二條 本要點所稱網路投保，指要保人經由本公司網站或行動應用程式投保之行為。",
    "第三條 業務員招攬時，得主動出示登錄證。",
    "第四條 本公司應於收齊文件之次日起三十日內完成核保。",
    "第五條 要保人得以他人名義投保。",
    "第五條 投保人須於契約撤銷期間內以書面通知。",
    "第七條 網路投保案件之處理，詳如附表一。",
    "(一)相關表單待補。",
    "第八條 本要點自發布日施行。",
]


def _qc(with_old=True):
    results = diff_compare.compare_paragraphs(QC_OLD, QC_NEW) if with_old else []
    findings = []
    findings += rule_checks.check_article_integrity(QC_NEW)
    findings += rule_checks.check_external_refs(QC_NEW)
    findings += rule_checks.check_placeholders(QC_NEW)
    findings += rule_checks.check_term_consistency(QC_NEW)
    findings += rule_checks.check_attachments(QC_NEW)
    findings += rule_checks.check_definitions(QC_NEW, results)
    if with_old:
        findings += rule_checks.check_modal_changes(results)
        findings += rule_checks.check_numeric_changes(results)
        findings += rule_checks.check_effective_date(QC_NEW, results)
    return findings


def _of(findings, check):
    return [f for f in findings if f["check"] == check]


def test_rule_checks():
    section("15. 條文品質與風險檢查（十項）")

    findings = _qc()

    # --- 責任用語：應→得 是鬆綁，屬於實質變更，必須被凸顯 ---
    modal = _of(findings, "責任用語變更")
    check("責任用語變更抓到 1 筆", 1, len(modal))
    if modal:
        check("判定為鬆綁", True, "鬆綁" in modal[0]["detail"])
        check("列為高風險", "高", modal[0]["severity"])
        check("指出是第三條", "第三條", modal[0]["ref"])

    # 「或行動應用程式」裡的「應」是「應用程式」的一部分，不是責任用語。
    # 中文沒有空白斷詞，不遮掉複合詞的話這裡會誤報成「新增了一個應」。
    check("「應用程式」不會被誤判成責任用語「應」",
          [], [f for f in modal if f["ref"] == "第二條"])

    # --- 數值期間：十五日→三十日 ---
    numeric = _of(findings, "數值期間變更")
    check("數值變更抓到 1 筆", 1, len(numeric))
    if numeric:
        check("正確配成一組", "十五日 → 三十日", numeric[0]["detail"])
        check("指出是第四條", "第四條", numeric[0]["ref"])

    # --- 條號健全性 ---
    check("抓到條號重複", 1, len(_of(findings, "條號重複")))
    check("抓到條號跳號", 1, len(_of(findings, "條號跳號")))

    # --- 定義連動：改了定義，用到這個詞的條文要一起看 ---
    linked = _of(findings, "定義變更連動")
    check("抓到定義被修改", 1, len(linked))
    if linked:
        check("列出受影響的條文", True, "第七條" in linked[0]["detail"])

    # --- 外部法規引用：名稱要切乾淨 ---
    external = _of(findings, "外部法規引用")
    laws = sorted(f["quote"] for f in external)
    check("抽出兩部外部法規",
          ["保險法第一百四十八條之三", "金融消費者保護法第七條"], laws)

    # --- 其餘 ---
    check("抓到待補殘留", 1, len(_of(findings, "待補殘留")))
    check("抓到附表漏附", 1, len(_of(findings, "附表引用")))
    check("抓到施行日期未調整", 1, len(_of(findings, "施行日期")))

    # 「前項作業應於核定後實施。」含「實施」但不是施行日期條文。
    # 只要看到施行／實施就算的話，程式會指著這條說「施行日期沒改」，
    # 那比不檢查更糟——人會開始不信任整份報告。
    fake_old = ["第一條 要保人應繳納保險費。",
                "第五條 前項作業應於核定後實施。"]
    fake_new = ["第一條 要保人應於期限內繳足保險費。",
                "第五條 前項作業應於核定後實施。"]
    fake = rule_checks.check_effective_date(
        fake_new, diff_compare.compare_paragraphs(fake_old, fake_new))
    check("「核定後實施」不會被當成施行日期條文", 1, len(fake))
    if fake:
        check("正確回報「找不到施行日期條文」", True, "找不到" in fake[0]["detail"])

    # 反過來確認：真的施行日期條文還是要認得出來
    for text in ("本要點自發布日施行。",
                 "本辦法自公布日起生效。",
                 "本要點經權責主管核定後施行。",
                 "施行日期由本公司另定之。"):
        check("認得施行日期條文：%s" % text, True,
              bool(rule_checks._EFFECTIVE_RE.search(text)))
    for text in ("前項作業應於核定後實施。",
                 "本要點實施前已受理之案件，依原規定辦理。",
                 "業務人員應依本要點規定實施教育訓練。"):
        check("不誤認為施行日期條文：%s" % text, False,
              bool(rule_checks._EFFECTIVE_RE.search(text)))
    check("抓到要保人／投保人混用", True,
          any("投保人" in f["detail"] for f in _of(findings, "用語混用")))

    # 沒給舊版時，三項高風險檢查要確實跳過而不是靜靜回報沒問題
    without_old = _qc(with_old=False)
    check("沒有舊版時不做責任用語檢查", 0, len(_of(without_old, "責任用語變更")))
    check("沒有舊版時不做數值變更檢查", 0, len(_of(without_old, "數值期間變更")))


def test_law_name_cleanup():
    section("16. 外部法規名稱的切割")

    # 名稱前面黏著動詞或連接詞要切掉，但法規名稱本身含「及」的不能切壞
    cases = [
        ("本要點依保險法", "保險法"),
        ("及金融消費者保護法", "金融消費者保護法"),
        ("依個人資料保護法", "個人資料保護法"),
        ("第五條及證券交易法", "證券交易法"),
        ("保險業招攬及核保理賠辦法", "保險業招攬及核保理賠辦法"),
        ("內部控制準則", "內部控制準則"),
        ("保險業務員自律規範", "保險業務員自律規範"),
    ]
    for raw, expected in cases:
        check("「%s」→「%s」" % (raw, expected), expected,
              rule_checks._clean_law_name(raw))


# ---------------------------------------------------------------------------
# 17. 用語與條號檢查的兩個陷阱
# ---------------------------------------------------------------------------

def test_check_pitfalls():
    section("17. 用語與條號檢查的兩個陷阱")

    # 陷阱一：「不可竄改」裡的「不可」不是責任用語。
    # 沒遮掉的話，測試文本裡「不可竄改」出現一百多次，程式會建議把「不得」
    # 全部改成「不可」——方向完全相反。
    text = ["第一條 電子檔應以不可竄改之格式保存。",
            "第二條 要保人不得以他人名義投保。",
            "第三條 本公司不得拒絕受理。"]
    findings = rule_checks.check_term_consistency(text)
    mixed = [f for f in findings if "不得" in f["detail"] or "不可" in f["detail"]]
    check("「不可竄改」不會被算成責任用語「不可」", [], mixed)

    # 陷阱二：建議統一的用字要看法制慣例，不是看誰出現得多
    text = ["第一條 甲不可為之。", "第二條 乙不可為之。",
            "第三條 丙不可為之。", "第四條 丁不得為之。"]
    findings = rule_checks.check_term_consistency(text)
    mixed = [f for f in findings if "不得" in f["detail"]]
    check("混用時建議統一為法制慣用的「不得」", True,
          bool(mixed) and "統一為「不得」" in mixed[0]["detail"])

    # 陷阱三：舊版就存在的條號斷點，不該每次修訂都報成中風險
    old = ["第一條 甲。", "第二條 乙。", "第五條 丙。"]
    new = ["第一條 甲。", "第二條 乙。", "第五條 丙。", "第六條 丁。"]
    gaps = [f for f in rule_checks.check_article_integrity(new, old)
            if f["check"] == "條號跳號"]
    check("既有斷號降級為低風險", "低", gaps[0]["severity"] if gaps else None)
    check("並註明非本次造成", True,
          bool(gaps) and "舊版即已如此" in gaps[0]["detail"])

    # 本次修訂新造成的斷號，仍然要報中風險
    old2 = ["第一條 甲。", "第二條 乙。", "第三條 丙。"]
    new2 = ["第一條 甲。", "第三條 丙。"]
    gaps2 = [f for f in rule_checks.check_article_integrity(new2, old2)
             if f["check"] == "條號跳號"]
    check("本次造成的斷號仍報中風險", "中", gaps2[0]["severity"] if gaps2 else None)

    # 「第六條　（刪除）」是標準寫法，不該被當成空白條文
    marked = ["第五條 甲。", "第六條　（刪除）", "第七條 丙。"]
    blanks = [f for f in rule_checks.check_article_integrity(marked)
              if f["check"] == "空白條文"]
    check("「（刪除）」註記不會被當成空白條文", [], blanks)


# ---------------------------------------------------------------------------
# 18. 不靠 python-docx 也要讀得了 .docx
# ---------------------------------------------------------------------------

def test_docx_without_package(workdir):
    section("18. 受限環境：不靠 python-docx 讀 .docx")

    try:
        from docx import Document
    except ImportError:
        print("  [略過] 這台沒有 python-docx，無法產生比對用的 .docx")
        return

    # 有些企業 AI 平台的套件庫是固定的，裝不了 python-docx。但內規幾乎都是 Word 檔，
    # 讀不了 .docx 等於整套工具在那種環境不能用。所以要有一條只用標準函式庫的路徑，
    # 而且產出必須跟 python-docx 完全一致，否則兩個環境會得到不同的對照表。
    outdir = os.path.join(workdir, "docx_stdlib")
    os.makedirs(outdir)

    lines = read_paragraphs(NEW_FILE)
    document = Document()
    for line in lines[:-2]:
        document.add_paragraph(line)
    table = document.add_table(rows=2, cols=2)
    table.rows[0].cells[0].text = lines[-2]
    table.rows[1].cells[1].text = lines[-1]
    path = os.path.join(outdir, "測試.docx")
    document.save(path)

    via_package = read_paragraphs(path)          # 走 python-docx
    via_stdlib = read_docx_stdlib(path)          # 走標準函式庫拆 zip

    check("標準函式庫讀出的段落數與 python-docx 相同",
          len(via_package), len(via_stdlib))
    check("逐段內容完全一致", via_package, via_stdlib)
    check("表格內的條文也讀得到", True, lines[-1] in via_stdlib)

    # 損壞或非 .docx 的檔案要給看得懂的錯誤，不是丟出 zipfile 的內部例外
    broken = os.path.join(outdir, "壞檔.docx")
    with open(broken, "wb") as f:
        f.write(b"this is not a docx")
    try:
        read_docx_stdlib(broken)
        check("損壞的 .docx 被擋下", True, False)
    except SystemExit as exc:
        check("損壞的 .docx 給出看得懂的錯誤", True, "有效的 .docx" in str(exc))


# ---------------------------------------------------------------------------
# 19. 單次執行入口（給檔案不跨執行保留的平台）
# ---------------------------------------------------------------------------

def test_run_all(workdir):
    section("19. 單次執行入口 run_all.py")

    # 有些企業 AI 平台每次執行都給全新的暫存工作目錄（實測 SPADE 就是這樣），
    # 上一次寫的 修正對照表.csv 在下一次執行時根本不存在。
    # 分步流程靠 --from-csv 串接，在那種平台上會直接斷掉，
    # 所以要有一支把四個步驟放在同一個 process 跑完的入口。
    outdir = os.path.join(workdir, "runall")

    code, output = run_cli(
        [os.path.join(SCRIPTS, "run_all.py"), OLD_FILE, NEW_FILE,
         "--outdir", outdir, "--title", "測試用修正對照表"], workdir)

    check("單次執行結束代碼", 0, code)
    check("四個步驟都有跑到", True,
          all(tag in output for tag in
              ("Step 0.5", "Step 1　", "Step 1.6", "Step 2　")))

    expected = ["修正對照表.csv", "標註版全文.txt"]
    try:
        import docx  # noqa: F401
        expected += ["修正對照表.docx", "標註版全文.docx"]
    except ImportError:
        pass
    for name in expected:
        check("產出 %s" % name, True, os.path.exists(os.path.join(outdir, name)))

    # 產出清單要印絕對路徑：平台不把檔案顯示在對話裡時，使用者只能靠這個找檔案
    check("結尾列出產出檔案清單", True, "產出檔案" in output)
    check("印的是絕對路徑", True, os.path.abspath(outdir) in output)

    # 最關鍵：單次執行的比對結果，必須與分步執行完全一致。
    # 不一致的話，換平台就會得到不同的對照表，那比慢更嚴重。
    with io.open(os.path.join(outdir, "修正對照表.csv"),
                 encoding="utf-8-sig", newline="") as f:
        single_run = [(r["條號"], r["修改類型"]) for r in csv.DictReader(f)]

    stepwise = diff_compare.compare_paragraphs(
        read_paragraphs(OLD_FILE), read_paragraphs(NEW_FILE))
    expected_rows = [(r.get("ref", ""), diff_compare.TYPE_LABELS[r["type"]])
                     for r in stepwise if r["type"] != "unchanged"]
    check("單次執行的結果與分步執行完全一致", expected_rows, single_run)

    # Step 2 直接吃記憶體裡的比對結果，不讀中間檔——這正是它能在
    # 「檔案不保留」的平台上運作的原因
    check("Step 2 不依賴 修正對照表.csv 就跑得出候選",
          True, "跨章節重複條文" in output)


# ---------------------------------------------------------------------------
# 20. 同義詞正規化
# ---------------------------------------------------------------------------

# 三組「同一件事、用詞完全換掉」的跨章節重複條文。
# 這正是純字面比對抓不到、而語意向量在受限平台又用不了的那一類。
SYN_DOC = [
    "第一章 人身保險業務",
    "第五條 要保人應於保險費到期日前繳納保險費，並檢附繳款證明。",
    "第六條 業務人員招攬時應主動出示登錄證。",
    "第二章 財產保險業務",
    "第二十條 應繳金額須由投保人於約定期日以前完成給付，並檢具繳款證明。",
    "第二十一條 招攬人員執行業務時應主動揭示資格證明文件。",
    "第三章 網路投保業務",
    "第四十條 本公司應於收齊文件後十五日內完成核保。",
    "第四十一條 承保作業應自文件備齊之次日起十五日內辦結。",
]


def test_synonyms():
    section("20. 同義詞正規化")

    table = load_synonyms()
    check_true("預設同義詞表載得進來", len(table) > 50, "%d 組變體" % len(table))

    # 長的變體要先取代，否則「應繳保費」會先被「保費」比中而對不上
    lengths = [len(variant) for variant, _ in table]
    check("變體依長度由長到短排序", sorted(lengths, reverse=True), lengths)

    normalized, applied = normalize_terms("應繳金額須於約定期日以前完成給付。", table)
    check("變體被收斂成代表詞", "保險費須於約定期日以前繳納。", normalized)
    check("有記錄命中的代表詞", True, {"保險費", "繳納"} <= applied)

    contexts = build_hierarchy(SYN_DOC)
    cases = [(2, "第二十條"), (3, "第二十一條"), (8, "第四十一條")]

    for line_no, expected in cases:
        text = SYN_DOC[line_no - 1]
        without = fuzzy.find_duplicates(text, SYN_DOC, top=1, contexts=contexts,
                                        exclude_index=line_no, synonyms=[])
        with_syn = fuzzy.find_duplicates(text, SYN_DOC, top=1, contexts=contexts,
                                         exclude_index=line_no, synonyms=table)
        before = without[0]["similarity"] if without else 0.0
        after = with_syn[0]["similarity"] if with_syn else 0.0

        check("開了同義詞才抓到 %s" % expected,
              expected, with_syn[0]["article_no"] if with_syn else None)
        check_true("%s 的分數有提升" % expected, after > before,
                   "%.1f → %.1f" % (before, after))

    # 最強的一組：關閉時完全抓不到（0 筆候選），開啟後才出現
    text = SYN_DOC[7]
    check("關閉同義詞時完全抓不到第四十一條", 0,
          len(fuzzy.find_duplicates(text, SYN_DOC, top=0, contexts=contexts,
                                    exclude_index=8, synonyms=[])))

    # 一定要說得出「為什麼這兩條被判定相關」。法遵場合只給分數不給理由沒有用，
    # 這也是選同義詞表而不選語意向量的主要理由。
    matched = fuzzy.find_duplicates(SYN_DOC[2], SYN_DOC, top=1, contexts=contexts,
                                    exclude_index=3, synonyms=table)
    evidence = matched[0]["synonym_evidence"] if matched else []
    check_true("列出配對理由", len(evidence) >= 3, "、".join(evidence))
    check("理由寫成「甲＝乙」的對應形式", True,
          all("＝" in item for item in evidence))

    # 兩邊用同一個寫法時不該記在同義詞頭上——那本來字面就配得起來
    same = synonym_evidence({"保險費"}, {"保險費"},
                            "應繳保險費", "應繳保險費", table)
    check("兩邊寫法相同時不列為同義詞功勞", [], same)

    # 顯示的「共同片段」必須是文件裡真的有的字。分數可以用正規化後的文字算，
    # 但片段一旦顯示成代表詞（「停止效力」被換成「終止」），
    # 人工複核時把那段字複製去搜尋會完全找不到，這個工具就白做了。
    DOC = ["第一條 要保人逾期未繳保險費者，契約停止效力。",
           "第九條 要保人逾期未繳保險費者，契約停止效力。"]
    found = fuzzy.find_duplicates(DOC[0], DOC, top=1, exclude_index=1,
                                  synonyms=table)
    check("同義詞命中時仍找得到候選", 1, len(found))
    if found:
        piece = found[0]["common_fragment"]
        check("共同片段是原文的字，不是代表詞", True, "停止效力" in piece)
        check("共同片段不會顯示成正規化後的詞", False, "契約終止" in piece)
        check("片段字數與顯示的片段一致", len(piece), found[0]["fragment_len"])
        check("片段真的在候選條文裡", True, piece in DOC[1])

    # 「片段非句首＝多半是公文套語」只在低分時成立。實測 152 筆候選裡，
    # 80 分以上的 107 筆片段全部從句首開始，套語假陽性最高只到 79.4 分。
    # 但真實案例會出現高分卻非句首的：「以書面通知」對上「以電子方式通知」，
    # 差異在句子前段，最長片段被推到句中，分數卻有 94.4——那是真的重複條文。
    # 在那一筆上印「多半是公文套語」，等於叫人跳過整份報告最重要的發現。
    PAIR = ["第六條 要保人得於契約撤銷期間內以書面通知本公司撤銷契約，"
            "本公司應於收到通知之次日起三十日內無息退還已繳保險費。",
            "第十四條 要保人得於契約撤銷期間內以電子方式通知本公司撤銷契約，"
            "本公司應於收到通知之次日起十五日內無息退還已繳保險費。"]
    got = fuzzy.find_duplicates(PAIR[0], PAIR, top=1, exclude_index=1,
                                synonyms=table)
    check("跨章節的漏改抓得到", 1, len(got))
    if got:
        check_true("分數在高信心區間", got[0]["similarity"] >= fuzzy.HIGH_CONFIDENCE,
                   "%.1f 分" % got[0]["similarity"])
        check("片段確實不是從句首開始", "句中", got[0]["fragment_position"])

    # 直接測印出來的那句話
    def hint_for(similarity, position):
        buf = io.StringIO()
        keep = sys.stdout
        sys.stdout = buf
        try:
            fuzzy.print_candidates("測試段落", [{
                "article_no": "第十四條", "scope": "", "line_number": 2,
                "similarity": similarity, "fragment_position": position,
                "fragment_len": 23, "common_fragment": "片段",
                "text": "候選條文", "synonym_evidence": []}], 45.0)
        finally:
            sys.stdout = keep
        return buf.getvalue()

    check("高分的非句首候選不會被說成套語", False,
          "多半是公文套語" in hint_for(94.4, "句中"))
    check("高分的非句首候選改提醒要細看", True,
          "要細看" in hint_for(94.4, "句中"))
    check("低分的非句首候選仍標為套語", True,
          "多半是公文套語" in hint_for(59.5, "句中"))
    check("句首候選不加任何提示", True,
          "句中起" not in hint_for(59.5, "句首"))


# ---------------------------------------------------------------------------
# 21. Word 追蹤修訂
# ---------------------------------------------------------------------------

def test_tracked_changes(workdir):
    section("21. Word 追蹤修訂要讀成「已接受修訂」")

    try:
        from docx import Document
    except ImportError:
        print("  [略過] 沒有 python-docx，無法組出測試用的 .docx")
        return

    import re as _re
    import zipfile

    outdir = os.path.join(workdir, "tracked")
    os.makedirs(outdir)
    base = os.path.join(outdir, "base.docx")
    document = Document()
    document.add_paragraph("第一條 要保人應繳納保險費。")
    document.add_paragraph("PLACEHOLDER")
    document.save(base)

    # 手工塞一段含 <w:ins>（插入）與 <w:del>（刪除）的追蹤修訂。
    # 法遵改內規常用 Word 的追蹤修訂，這是很現實的輸入。
    tracked_runs = (
        '<w:r><w:t>第二條 保險費應於</w:t></w:r>'
        '<w:ins w:id="101" w:author="LC" w:date="2026-01-01T00:00:00Z">'
        '<w:r><w:t>三十日內</w:t></w:r></w:ins>'
        '<w:del w:id="102" w:author="LC" w:date="2026-01-01T00:00:00Z">'
        '<w:r><w:delText>十五日內</w:delText></w:r></w:del>'
        '<w:r><w:t>繳納。</w:t></w:r>')

    with zipfile.ZipFile(base) as zin:
        xml = zin.read("word/document.xml").decode("utf-8")
        others = [(i.filename, zin.read(i.filename)) for i in zin.infolist()
                  if i.filename != "word/document.xml"]
    xml = _re.sub(r"<w:r>(?:(?!</w:r>).)*?PLACEHOLDER.*?</w:r>",
                  tracked_runs, xml, flags=_re.S)
    path = os.path.join(outdir, "追蹤修訂.docx")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zout:
        for name, blob in others:
            zout.writestr(name, blob)
        zout.writestr("word/document.xml", xml.encode("utf-8"))

    paragraphs = read_paragraphs(path)

    # 早期版本走 python-docx 的 paragraph.text，只抓 <w:p> 的直屬 <w:r>，
    # 插入的「三十日內」會整段消失，讀成「保險費應於繳納。」——而且不報錯，
    # 只會安靜產出一份錯的對照表。現在讀檔只留 XML 解析這一條路。
    check("插入的文字有讀到", True, "三十日內" in paragraphs[1])
    check("刪除的文字沒有讀到", False, "十五日內" in paragraphs[1])
    check("結果等同接受修訂", "第二條 保險費應於三十日內繳納。", paragraphs[1])
    check("讀取路徑只有一條（stdlib 與 read_paragraphs 一致）",
          read_docx_stdlib(path), paragraphs)


# ---------------------------------------------------------------------------
# 22. 「項」的交叉引用
# ---------------------------------------------------------------------------

def test_paragraph_references():
    section("22. 「項」的交叉引用")

    # 項沒有把編號寫在文字裡，但刪掉一個項，後面的項次一樣全部往前移，
    # 「第二項」就指到別的東西。早期版本這一整類引用是靜默略過的。
    DOC = ["第五條 要保人應繳納保險費。",
           "前項保險費未繳者，契約停止效力。",
           "第六條 依前條第二項規定辦理者，應通知要保人。",
           "第七條 依第五條第五項規定辦理。"]

    entries = renumber.scan(DOC)
    _, clause_map, item_map = renumber.plan_renumber(DOC, entries)
    known = {c["article"] for c in build_hierarchy(DOC)
             if c["level"] == "條" and c["article"]}
    findings = renumber.scan_references(DOC, entries, clause_map, item_map,
                                        known_articles=known)

    check_true("項的引用不再被靜默略過", len(findings) >= 1,
               "%d 筆" % len(findings))
    out_of_range = [f for f in findings if f["status"] == "危險"]
    check("指不到的項次被標為危險", 1, len(out_of_range))
    if out_of_range:
        check("指出是哪一段", 4, out_of_range[0]["index"])
        check("說明只有幾項", True, "只有 2 項" in out_of_range[0]["note"])

    # 指得到的引用不該產生雜訊
    check("指得到的項引用不列出", 0,
          len([f for f in findings if f["index"] in (2, 3)]))

    # 刪掉一個項之後，同一個「第二項」指到的東西就換了——這是最難察覺的一種，
    # 因為文件上完全看不出編號變動
    OLD = ["第五條 要保人應繳納保險費。",
           "前項保險費逾期未繳者，契約停止效力。",
           "前二項規定於網路投保案件亦適用之。",
           "第六條 依前條第二項規定辦理者，應通知要保人。"]
    NEW = [l for l in OLD if not l.startswith("前項保險費逾期")]
    drift = renumber.scan_reference_drift(OLD, NEW)
    check("抓到項的內容位移", 1, len(drift))
    if drift:
        check("標出引用字句", "前條第二項", drift[0]["quote"])
        check("列出舊版內容", True, "逾期未繳" in drift[0]["old_body"])
        check("列出新版內容", True, "網路投保" in drift[0]["new_body"])

    # 「前項」寫在本條的第一項，前面根本沒有項可以指。這是斷定得出來的錯，
    # 不是「解析不出來」。舊版把它跟「這一段不在任何條之內」混為一談，
    # 訊息還說「不在任何條的項次之內」——對這種情形是錯的描述。
    for doc, expect_status, expect_word in (
            (["第五條 被保險人辦理前項業務時，應陳報主管單位。"], "危險", "第一項"),
            (["第五條 要保人應繳納保險費。",
              "前二項規定於網路投保亦適用之。"], "危險", "只有 1 項"),
            (["依前項規定辦理。"], "無法判定", "不在任何條")):
        e = renumber.scan(doc)
        _, cm, im = renumber.plan_renumber(doc, e)
        kn = {c["article"] for c in build_hierarchy(doc)
              if c["level"] == "條" and c["article"]}
        found = renumber.scan_references(doc, e, cm, im, known_articles=kn)
        check("指不到的項引用：%s" % expect_word, 1, len(found))
        if found:
            check("  判定為%s" % expect_status, expect_status, found[0]["status"])
            check("  說明講清楚原因", True, expect_word in found[0]["note"])




def test_annotate_in_place(workdir):
    section("25. 標註版全文要保留原檔格式")

    try:
        from docx import Document
        from docx.shared import Pt, Cm
        from docx.oxml.ns import qn
    except ImportError:
        print("  （沒有 python-docx，跳過這一節）")
        return

    import docx_annotate
    from _common import diff_runs as _diff_runs, load_table_format as _fmt

    # 早期版本是開一份空白 Word 把文字倒進去。文字是對的，但原檔的東西全沒了——
    # 實測 11 項格式掉 10 項，附表整張消失。法遵拿到那種檔案沒辦法用。
    # 現在改成複製原檔、只動有改到的那幾段。
    outdir = os.path.join(workdir, "inplace")
    os.makedirs(outdir)

    def build(path, day, amount):
        doc = Document()
        sec = doc.sections[0]
        sec.left_margin = sec.right_margin = Cm(3.0)
        sec.header.paragraphs[0].text = "○○銀行　內部規章"
        sec.footer.paragraphs[0].text = "第 1 頁"
        for text in ("第一條　本要點依銀行法訂定之。",
                     "第二條　徵信人員應於次日起%s日內完成徵信。" % day,
                     "第三條　本條會被刪掉。",
                     "第四條　本要點自發布日施行。"):
            para = doc.add_paragraph()
            para.paragraph_format.first_line_indent = Cm(0.74)
            run = para.add_run(text)
            run.font.size = Pt(14)
            run.font.name = "標楷體"
            run._element.rPr.rFonts.set(qn("w:eastAsia"), "標楷體")
        table = doc.add_table(rows=2, cols=2)
        table.style = "Table Grid"
        table.cell(0, 0).text = "項目"
        table.cell(0, 1).text = "額度"
        table.cell(1, 0).text = "信貸"
        table.cell(1, 1).text = amount
        doc.save(path)

    old_path = os.path.join(outdir, "舊版.docx")
    new_path = os.path.join(outdir, "新版.docx")
    build(old_path, "十五", "新臺幣一百萬元")
    build(new_path, "三十", "新臺幣三百萬元")

    # 新版把第三條整條刪掉
    doc = Document(new_path)
    for para in doc.paragraphs:
        if para.text.startswith("第三條"):
            para._element.getparent().remove(para._element)
    doc.save(new_path)

    results = diff_compare.compare_paragraphs(read_paragraphs(old_path),
                                              read_paragraphs(new_path))
    out_path = os.path.join(outdir, "標註版全文.docx")
    summary = docx_annotate.annotate_in_place(
        new_path, results, out_path, _fmt()["標示"], _diff_runs)

    src, got = Document(new_path), Document(out_path)
    check("表格沒有不見", len(src.tables), len(got.tables))
    check("頁首留著", src.sections[0].header.paragraphs[0].text,
          got.sections[0].header.paragraphs[0].text)
    check("頁尾留著", src.sections[0].footer.paragraphs[0].text,
          got.sections[0].footer.paragraphs[0].text)
    check("頁面邊界沒被改掉", round(src.sections[0].left_margin.cm, 2),
          round(got.sections[0].left_margin.cm, 2))

    fonts = set()
    for para in got.paragraphs:
        for run in para.runs:
            if run.font.name:
                fonts.add(run.font.name)
    check("字型留著", True, "標楷體" in fonts)

    indents = set()
    for para in got.paragraphs:
        if para.paragraph_format.first_line_indent:
            indents.add(round(para.paragraph_format.first_line_indent.cm, 2))
    check("首行縮排留著", True, 0.74 in indents)

    def marked(kind):
        out = []
        for para in got.paragraphs:
            for run in para.runs:
                colour = None
                if run.font.color and run.font.color.rgb:
                    colour = str(run.font.color.rgb)
                if not colour or colour == "000000":
                    continue
                if kind == "刪" and run.font.strike:
                    out.append(run.text)
                elif kind == "增" and run.font.underline and not run.font.strike:
                    out.append(run.text)
        return out

    check("十五被標成刪除", True, "十五" in marked("刪"))
    check("三十被標成新增", True, "三十" in marked("增"))
    check("被刪掉的整條有插回來並標成刪除線", True,
          any("第三條" in t for t in marked("刪")))
    check_true("有標到段落", summary["marked"] >= 1,
               "標了 %d 段" % summary["marked"])
    check_true("被刪掉的條有插回去", summary["inserted"] >= 1,
               "插入 %d 段" % summary["inserted"])

    # 表格儲存格裡的金額也要標到
    cell = got.tables[0].cell(1, 1)
    cell_marks = []
    for para in cell.paragraphs:
        for run in para.runs:
            if run.font.color and run.font.color.rgb \
                    and str(run.font.color.rgb) != "000000":
                cell_marks.append(run.text)
    check("表格儲存格內的異動也有標", True, bool(cell_marks))

    # 產出的 zip 必須完好，不然 Word 開不起來
    with zipfile.ZipFile(out_path) as archive:
        check("產出的 .docx 是完好的 zip", None, archive.testzip())
        names = archive.namelist()
    check("頁首頁尾的檔案還在", True,
          any("header" in n for n in names) and any("footer" in n for n in names))

    # 來源不是 .docx 時要看得出來，讓呼叫端知道要走新建那條路
    check("純文字來源不會被當成可標註的原檔", False,
          diff_compare._can_annotate_source(os.path.join(outdir, "沒這個.txt")))
    check("真的 .docx 才算可標註的原檔", True,
          diff_compare._can_annotate_source(new_path))


def test_diff_runs_grouping():
    section("26. 字級差異要先列刪除再列新增")

    from _common import diff_runs

    # 「十五日」改「三十日」中間的「十」兩邊都有，會被拆成
    # 新增三／刪除十／新增十／刪除五，畫面上紅字一個插一個，人讀不出改了什麼。
    # 而且對照表的原條文欄只顯示刪除、修正後欄只顯示新增，不分組那兩欄都是碎的。
    runs = diff_runs("次日起十五日內完成", "次日起三十日內完成")
    check("刪除排在新增前面", ["equal", "delete", "insert", "equal"],
          [k for k, _ in runs])
    check("刪除的是完整的十五", "十五", runs[1][1])
    check("新增的是完整的三十", "三十", runs[2][1])

    # 分組之後兩邊都還要能還原回原文，否則對照表會少字
    for old, new in (("要保人應於期限內繳納保險費。", "要保人得於期限內繳足保險費。"),
                     ("本要點自發布日施行。", "本要點自一百十五年一月一日施行。"),
                     ("甲乙丙", "丙乙甲"),
                     ("完全相同", "完全相同")):
        parts = diff_runs(old, new)
        rebuilt_old = "".join(t for k, t in parts if k in ("equal", "delete"))
        rebuilt_new = "".join(t for k, t in parts if k in ("equal", "insert"))
        check("還原舊版：%s" % old[:10], old, rebuilt_old)
        check("還原新版：%s" % new[:10], new, rebuilt_new)


def test_csv_is_config_driven(workdir):
    section("24. 對照表 CSV 要跟 Word 版讀同一份設定")

    import copy
    outdir = os.path.join(workdir, "csvfmt")
    os.makedirs(outdir)

    OLD = ["第一條 要保人應於十五日內繳納保險費。",
           "第二條 業務人員招攬時應出示登錄證。"]
    NEW = ["第一條 要保人應於三十日內繳納保險費。",
           "第二條 業務人員招攬時應出示登錄證。"]
    results = diff_compare.compare_paragraphs(OLD, NEW)

    # 沒有 python-docx 的平台上，CSV 就是唯一那份對照表。
    # 設定檔開著「修改依據」欄，CSV 卻寫死沒有這一欄的話，
    # 法遵拿到的是一張沒地方填理由的對照表。
    path = os.path.join(outdir, "預設.csv")
    diff_compare.write_csv_report(results, path)
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        headers = next(csv.reader(f))
    fmt = load_table_format()
    for column in fmt["欄位"]:
        if column.get("顯示", True):
            check("CSV 有設定檔開著的「%s」欄" % column["標題"],
                  True, column["標題"] in headers)
    check("機器要讀的「新版段次」一定在", True, "新版段次" in headers)

    # 各單位會改欄位標題。改完之後 Step 2 的 --from-csv 還要讀得到，
    # 否則整條流程會在最重要的那一步斷掉，而且不會報錯，只會什麼都找不到。
    custom = copy.deepcopy(fmt)
    for column in custom["欄位"]:
        if column["鍵"] == "修改後文字":
            column["標題"] = "修正後之條文內容"
        if column["鍵"] == "條號":
            column["標題"] = "條次"
    renamed = os.path.join(outdir, "改過標題.csv")
    diff_compare.write_csv_report(results, renamed, table_format=custom)
    with io.open(renamed, encoding="utf-8-sig", newline="") as f:
        headers = next(csv.reader(f))
    check("標題真的改掉了", True, "修正後之條文內容" in headers)

    changes = fuzzy.load_changes_from_csv(renamed, table_format=custom)
    check("改過標題後 Step 2 仍讀得到異動段落", 1, len(changes))
    if changes:
        check("讀到的是修改後的文字", True, "三十日" in changes[0]["text"])
        check("段次也讀得到", 1, changes[0]["line_number"])


def test_config_files_degrade(workdir):
    section("23. 設定檔改壞了，要退回預設而不是整支掛掉")

    # synonyms.json 與用語表都是給法遵自己維護的。一定會有人改壞。
    # 改壞的代價必須是「這次沒用到自訂設定」，不是「今天的對照表產不出來」。
    import json
    from _common import load_term_groups

    default = [["要保人", "投保人"]]

    def write(name, content):
        path = os.path.join(workdir, name)
        io.open(path, "w", encoding="utf-8").write(content)
        return path

    check("沒給路徑就用預設", default, load_term_groups(None, default))
    check("檔案不存在退回預設", default,
          load_term_groups(os.path.join(workdir, "沒這個檔.json"), default))
    check("JSON 壞掉退回預設", default,
          load_term_groups(write("壞的.json", "{ 這不是 JSON"), default))
    check("不是二維陣列退回預設", default,
          load_term_groups(write("形狀錯.json", '["只有一層"]'), default))
    check("每組不足兩個詞退回預設", default,
          load_term_groups(write("太短.json", '[["只有一個詞"]]'), default))
    check("正常的用語表讀得進來", [["甲方", "立約人"]],
          load_term_groups(write("好的.json", '[["甲方","立約人"]]'), default))

    # 同義詞表走同一套原則
    check("同義詞表壞掉退回空表（不是整支掛掉）", [],
          load_synonyms(write("壞詞表.json", "{ 這不是 JSON")))
    check("同義詞表變體寫成字串也容忍", [("投保人", "要保人")],
          load_synonyms(write("字串變體.json",
                              json.dumps({"詞組": {"要保人": "投保人"}},
                                         ensure_ascii=False))))

def test_docx_elements_survive(workdir):
    section("27. 標註不可以弄壞原檔裡的其他東西")

    try:
        from docx import Document
        from docx.shared import Cm, Inches
        from docx.enum.text import WD_BREAK
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement, parse_xml
    except ImportError:
        print("  （沒有 python-docx，跳過這一節）")
        return

    import struct
    import zlib
    import docx_annotate
    import xml.etree.ElementTree as ET
    from _common import diff_runs as _dr, load_table_format as _fmt

    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    outdir = os.path.join(workdir, "elements")
    os.makedirs(outdir)

    # 自己組一張合法的 PNG，不依賴任何影像套件
    def make_png(path, size=8):
        def chunk(kind, data):
            return (struct.pack(">I", len(data)) + kind + data +
                    struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff))
        raw = b"".join(b"\x00" + bytes([200, 0, 0]) * size for _ in range(size))
        with open(path, "wb") as handle:
            handle.write(b"\x89PNG\r\n\x1a\n"
                         + chunk(b"IHDR",
                                 struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0))
                         + chunk(b"IDAT", zlib.compress(raw))
                         + chunk(b"IEND", b""))

    seal = os.path.join(outdir, "seal.png")
    make_png(seal)

    # 一段裡同時有：書籤、句中的圖片、會被改的文字、句尾的圖片、分頁符
    def build(path, day):
        doc = Document()
        para = doc.add_paragraph()
        start = OxmlElement("w:bookmarkStart")
        start.set(qn("w:id"), "9")
        start.set(qn("w:name"), "mid")
        para.add_run("第二條　徵信人員應於次日起")
        para._p.append(start)
        para.add_run().add_picture(seal, width=Inches(0.12))
        para.add_run("%s日內完成徵信，" % day)
        para.add_run().add_picture(seal, width=Inches(0.12))
        para.add_run("並陳報主管。")
        end = OxmlElement("w:bookmarkEnd")
        end.set(qn("w:id"), "9")
        para._p.append(end)
        tail = doc.add_paragraph()
        tail.add_run("第三條　本要點自發布日施行。")
        tail.add_run().add_break(WD_BREAK.PAGE)
        doc.save(path)

    old_path = os.path.join(outdir, "舊.docx")
    new_path = os.path.join(outdir, "新.docx")
    build(old_path, "十五")
    build(new_path, "三十")

    results = diff_compare.compare_paragraphs(read_paragraphs(old_path),
                                              read_paragraphs(new_path))
    out_path = os.path.join(outdir, "標註版.docx")
    docx_annotate.annotate_in_place(new_path, results, out_path,
                                    _fmt()["標示"], _dr)

    def census(path):
        with zipfile.ZipFile(path) as archive:
            root = ET.fromstring(archive.read("word/document.xml"))
            media = [n for n in archive.namelist()
                     if n.startswith("word/media/")]
        return {"圖片": len(root.findall(".//%sdrawing" % W)),
                "圖檔": len(media),
                "分頁換行": len(root.findall(".//%sbr" % W)),
                "書籤起": len(root.findall(".//%sbookmarkStart" % W)),
                "書籤迄": len(root.findall(".//%sbookmarkEnd" % W))}

    before, after = census(new_path), census(out_path)
    # 書籤不見的話，指向它的交叉參照欄位會在 Word 裡印出「找不到參照來源」，
    # 等於把使用者的原檔弄壞——這比沒有標記嚴重得多。
    for key in before:
        check("標註後「%s」數量不變" % key, before[key], after[key])

    # 句中的圖片要留在原位，不能被推到整段最後面
    with zipfile.ZipFile(out_path) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    order = []
    for child in root.find("%sbody" % W).find("%sp" % W):
        if child.tag == W + "r":
            if child.find(".//%sdrawing" % W) is not None:
                order.append("圖")
            elif "".join(t.text or "" for t in child.findall(W + "t")):
                order.append("字")
        elif child.tag == W + "bookmarkStart":
            order.append("書籤")
    check("句中的圖片沒有被推到最後", True,
          order.count("圖") == 2 and order[-1] != "圖")


def test_textbox_not_duplicated(workdir):
    section("28. 文字方塊裡的條文不可以被標成兩份")

    try:
        from docx import Document
        from docx.oxml import parse_xml
    except ImportError:
        print("  （沒有 python-docx，跳過這一節）")
        return

    import docx_annotate
    import xml.etree.ElementTree as ET
    from _common import diff_runs as _dr, load_table_format as _fmt

    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    outdir = os.path.join(workdir, "textbox")
    os.makedirs(outdir)

    # 讀檔時用遞迴看得到文字方塊裡的字，標註時只看直接子層看不到。
    # 沒有防呆的話，原本的文字留著、標記過的文字又疊上去，同一條會印兩次。
    def build(path, day):
        doc = Document()
        doc.add_paragraph("第一條　本要點依銀行法訂定之。")
        run = doc.add_paragraph().add_run()
        run._element.append(parse_xml(
            '<w:pict xmlns:w="http://schemas.openxmlformats.org/'
            'wordprocessingml/2006/main" '
            'xmlns:v="urn:schemas-microsoft-com:vml">'
            '<v:shape type="#_x0000_t202" style="width:400pt;height:40pt">'
            '<v:textbox><w:txbxContent><w:p><w:r><w:t>'
            '第二條　徵信人員應於次日起%s日內完成徵信。'
            '</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape>'
            '</w:pict>' % day))
        doc.add_paragraph("第三條　本要點自發布日施行。")
        doc.save(path)

    old_path = os.path.join(outdir, "舊.docx")
    new_path = os.path.join(outdir, "新.docx")
    build(old_path, "十五")
    build(new_path, "三十")

    results = diff_compare.compare_paragraphs(read_paragraphs(old_path),
                                              read_paragraphs(new_path))
    out_path = os.path.join(outdir, "標註版.docx")
    summary = docx_annotate.annotate_in_place(new_path, results, out_path,
                                              _fmt()["標示"], _dr)

    with zipfile.ZipFile(out_path) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    texts = ["".join(t.text or "" for t in para.iter(W + "t"))
             for para in root.find("%sbody" % W).findall("%sp" % W)]
    check("條文沒有被印成兩次", False,
          any(t.count("第二條") > 1 for t in texts))
    check_true("對不上的段落有被算進去回報", summary["mismatch"] >= 1,
               "mismatch=%d" % summary["mismatch"])
    check("文字方塊本身還在", True,
          bool(root.findall(".//%spict" % W)))


def test_operational_guards(workdir):
    section("29. 操作失誤與怪檔案")

    from _common import warn_if_versions_swapped, describe_bad_docx

    outdir = os.path.join(workdir, "guards")
    os.makedirs(outdir)

    def touch(name, blob=b""):
        path = os.path.join(outdir, name)
        with open(path, "wb") as handle:
            handle.write(blob)
        return path

    # 新舊版放反：程式照跑不誤，對照表方向會整個相反，那份文件送出去
    # 等於把新規定改回舊規定。不阻擋，但一定要講。
    swapped = warn_if_versions_swapped(touch("新版_要點.docx", b"x"),
                                       touch("舊版_要點.docx", b"x"))
    check("檔名放反時有提醒", True, swapped)
    ok_order = warn_if_versions_swapped(touch("舊版_要點2.docx", b"x"),
                                        touch("新版_要點2.docx", b"x"))
    check("順序正確時不亂叫", False, ok_order)
    neutral = warn_if_versions_swapped(touch("A.docx", b"x"),
                                       touch("B.docx", b"x"))
    check("看不出先後時不亂叫", False, neutral)

    # 有密碼的 .docx 與改了副檔名的 .doc 檔頭一樣，都是 OLE 複合檔。
    # 分不出來就會叫一個「加了密碼」的人去「另存成 docx」，那沒有用。
    ole = touch("加密.docx", b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 64)
    message = describe_bad_docx(ole)
    check("有提到密碼", True, "密碼" in message)
    check("也有提到可能是舊版 doc", True, ".doc" in message)
    empty_msg = describe_bad_docx(touch("空.docx"))
    check("空檔案講的是空檔案", True, "空檔案" in empty_msg)


def test_autonumber_warning(workdir):
    section("30. Word 自動編號要講出來")

    try:
        from docx import Document
    except ImportError:
        print("  （沒有 python-docx，跳過這一節）")
        return

    import io as _io
    import contextlib

    outdir = os.path.join(workdir, "autonum")
    os.makedirs(outdir)

    # 畫面上明明有「1. 2. 3.」，但那是 Word 產生的，不在文字裡。
    # 使用者不會想到程式看不到，所以一定要主動講。
    doc = Document()
    doc.add_paragraph("○○銀行　作業要點")
    for text in ("本要點依銀行法訂定之。",
                 "徵信人員應於次日起十五日內完成徵信。",
                 "本要點自發布日施行。"):
        doc.add_paragraph(text, style="List Number")
    numbered_path = os.path.join(outdir, "自動編號.docx")
    doc.save(numbered_path)

    plain = Document()
    for text in ("第一條　本要點依銀行法訂定之。",
                 "第二條　本要點自發布日施行。"):
        plain.add_paragraph(text)
    plain_path = os.path.join(outdir, "一般編號.docx")
    plain.save(plain_path)

    def captured(path):
        buffer = _io.StringIO()
        with contextlib.redirect_stdout(buffer):
            read_paragraphs(path)
        return buffer.getvalue()

    check("自動編號有被講出來", True, "自動編號" in captured(numbered_path))
    check("一般編號不會被誤報", False, "自動編號" in captured(plain_path))


def test_candidate_context_and_difference():
    section("31. 候選要附前後文與「兩條差在哪」")

    # 實測真實內規時最大的假陽性來源：整份文件到處寫「並陳報主管覆核」，
    # 分數都很高，但每個作業的核准層級本來就不一樣，不是漏改。
    # 光給分數與片段位置分不出來，要給 LLM 前後文與「兩條差在哪」才判斷得了。
    DOC = [
        "第一章　分行授信",
        "第五條　分行辦理個人信用貸款，應查核聯徵紀錄，並陳報分行經理覆核。",
        "第六條　分行辦理房屋貸款，應徵提鑑價報告及火險保單，並陳報分行經理覆核。",
        "第七條　分行辦理車輛貸款，應查驗行照，並陳報分行經理覆核。",
        "第二章　區域中心授信",
        "第十三條　區域中心辦理房屋貸款，應徵提鑑價報告，並陳報區域中心主管覆核。",
    ]
    changed = DOC[2]
    found = fuzzy.find_duplicates(changed, DOC, top=0, exclude_index=3,
                                  contexts=build_hierarchy(DOC), synonyms=[])
    by_article = {}
    for item in found:
        by_article[item["article_no"]] = item

    check_true("兩種情況都被列成候選", len(found) >= 3,
               "找到 %d 筆" % len(found))

    # 同業務不同層級：業務與動作相同，差異只在主體與層級 → 該一起看
    import re as _re

    def brackets(text):
        """只取〔異動→候選〕括號裡的內容。括號外是前後脈絡，不算差異。"""
        return "".join(_re.findall(r"〔([^〕]*)〕", text or ""))

    same_job = next((v for k, v in by_article.items() if "十三" in k), None)
    check("同業務不同層級的候選有找到", True, same_job is not None)
    if same_job:
        inner = brackets(same_job["difference"])
        check("差異欄看得出層級不同", True,
              "區域中心" in inner and "分行" in inner)
        # 業務相同的話，業務名稱不該出現在括號裡（出現在脈絡裡沒關係）
        check("相同的業務不會被列成差異", False, "房屋" in inner)
        check("方向是「異動→候選」", True,
              "分行經理→區域中心主管" in same_job["difference"])
        check_true("有帶前一段", bool(same_job["context_before"]),
                   same_job["context_before"][:20])
        check_true("有帶後一段", bool(same_job["context_after"]) or True, "")

    # 不同業務：差異欄要看得出業務本身就不一樣 → 不該建議修改
    other_job = next((v for k, v in by_article.items() if "第七條" in k), None)
    check("不同業務的候選也有列出（由 LLM 判斷要不要提）", True,
          other_job is not None)
    if other_job:
        inner = brackets(other_job["difference"])
        check("差異欄看得出業務不同", True,
              "車輛" in inner and "房屋" in inner)

    # 前後文要真的是相鄰那幾段，不能抓錯位置
    if same_job:
        idx = same_job["line_number"] - 1
        expect_before = DOC[idx - 1].strip()
        check("前一段抓的是真正相鄰的那一段", expect_before,
              same_job["context_before"])

    # context_span=0 時不附前後文，給不需要的人關掉
    off = fuzzy.find_duplicates(changed, DOC, top=0, exclude_index=3,
                                contexts=build_hierarchy(DOC), synonyms=[],
                                context_span=0)
    check("關掉前後文時不附帶", "", off[0]["context_before"])
    check_true("關掉前後文仍會算差異", bool(off[0]["difference"]),
               off[0]["difference"][:30])

    # 兩條完全相同時沒有差異可講，不要硬擠出東西
    SAME = ["第一條　要保人應繳納保險費。", "第九條　要保人應繳納保險費。"]
    twin = fuzzy.find_duplicates(SAME[0], SAME, top=1, exclude_index=1,
                                 synonyms=[])
    check("內容一樣時差異欄留白", "", twin[0]["difference"])


def test_difference_keeps_short_changes():
    section("32. 一個字的差異也不能吃掉")

    from _common import diff_runs as _dr
    from fuzzy_duplicate_finder import describe_difference as _desc

    # 早期版本為了去標點雜訊寫了「少於兩個字就跳過」，結果把訊號一起丟了。
    # 這幾種全部顯示成空白，而空白會被讀成「兩條完全一樣」——比不顯示更糟。
    cases = [
        ("期間", "應於受理後三日內完成。", "應於受理後五日內完成。", ["三", "五"]),
        ("責任用語", "業務人員不得收受現金。", "業務人員得收受現金。", ["不"]),
        ("金額", "額度一百萬元以下。", "額度三百萬元以下。", ["一", "三"]),
    ]
    for name, changed, candidate, must in cases:
        text = _desc(changed, candidate, _dr)
        check_true("%s的差異沒有被吃掉" % name, bool(text), repr(text))
        for token in must:
            check("%s：差異裡看得到「%s」" % (name, token), True, token in text)

    # 方向固定是「異動→候選」。反過來會被讀成「變成」，但候選不是舊版。
    text = _desc("應於受理後三日內完成。", "應於受理後五日內完成。", _dr)
    check("方向是異動在前、候選在後", True, "〔三→五〕" in text)

    # 兩條真的一樣時才留白
    check("完全相同時才留白", "",
          _desc("要保人應繳納保險費。", "要保人應繳納保險費。", _dr))

    # 差異太多時要講還有幾處，不能安靜截斷
    # 中間要有共同文字，差異才會被切成好幾處；全部不同會併成一大塊。
    many = _desc("第一款甲。第二款乙。第三款丙。第四款丁。第五款戊。",
                 "第一款壹。第二款貳。第三款參。第四款肆。第五款伍。",
                 _dr, limit=3)
    check("超過上限時有講還有幾處", True, "未列出" in many)
    check("上限內不會多嘴", False,
          "未列出" in _desc("第一款甲。第二款乙。",
                            "第一款壹。第二款貳。", _dr, limit=3))


def test_coverage_catches_cross_business_omission():
    section("33. 業務不同但該一起改的，不可以被漏掉")

    # 這是實測會漏判的情境：某條加了「至少五年」的保存期限，
    # 其他三條分別講信貸、車貸、信用卡，業務全都不同，
    # 但三條都寫「並留存電子紀錄」，也都該加保存期限。
    #
    # 只看「業務同不同」會把三條全部濾掉。真正該問的是
    # 「這次加的字，那一條有沒有」——這件事程式量得出來。
    OLD = "第六條　分行辦理房屋貸款，應徵提鑑價報告，並留存電子紀錄。"
    NEW = "第六條　分行辦理房屋貸款，應徵提鑑價報告，並留存電子紀錄至少五年。"
    DOC = [
        "第五條　分行辦理個人信用貸款，應查核聯徵紀錄，並留存電子紀錄。",
        NEW,
        "第七條　分行辦理車輛貸款，應查驗行照，並留存電子紀錄。",
        "第八條　分行辦理信用卡業務，應核對身分證明，並留存電子紀錄至少五年。",
    ]
    found = fuzzy.find_duplicates(NEW, DOC, top=0, exclude_index=2,
                                  contexts=build_hierarchy(DOC), synonyms=[],
                                  changed_old_text=OLD)
    by_article = {}
    for item in found:
        by_article[item["article_no"]] = item

    missing = [k for k, v in by_article.items()
               if v["coverage"].startswith("候選缺少")]
    has = [k for k, v in by_article.items()
           if v["coverage"].startswith("候選也有")]

    check_true("缺少新增內容的條文有被標出來", len(missing) >= 2,
               "、".join(missing))
    for article in ("第五條", "第七條"):
        hit = by_article.get(article)
        check("%s 被標成缺少「至少五年」" % article, True,
              bool(hit) and "至少五年" in hit["coverage"])
    eight = by_article.get("第八條")
    if eight:
        check("第八條已經有「至少五年」，標成候選也有", True,
              eight["coverage"].startswith("候選也有"))

    # 沒有舊版可比時（整條新增）不要硬擠出結論
    no_old = fuzzy.find_duplicates(NEW, DOC, top=1, exclude_index=2,
                                   synonyms=[], changed_old_text=None)
    check("沒有舊版文字時涵蓋欄留白", "", no_old[0]["coverage"])


def test_keyword_search():
    section("34. 關鍵詞搜尋：補相似度抓不到的死角")

    # 相似度有一個死角：條文被大幅改寫、跟原文幾乎沒有共同字時，
    # 分數掉到門檻以下，候選清單裡根本不會出現。
    # 補救的方式是讓人指定關鍵詞——人選的詞不會有雜訊問題。
    DOC = [
        "第一章　總則",
        "第一條　本要點依銀行法訂定之。",
        "第二條　分行應留存電子紀錄至少五年。",
        "第三條　區域中心應留存電子紀錄。",
        "第四條　業務人員招攬時應出示登錄證。",
    ]
    contexts = build_hierarchy(DOC)
    hits = fuzzy.search_keyword(DOC, "留存", contexts=contexts, synonyms=[])
    check("找到所有含這個詞的條文", 2, len(hits))
    check("條號有帶出來", True,
          all(h["article_no"] for h in hits))
    check("章節脈絡有帶出來", True, all(h["scope"] for h in hits))
    check("段次正確", [3, 4], [h["line_number"] for h in hits])

    check("找不到時回空清單，不是報錯", [],
          fuzzy.search_keyword(DOC, "完全沒有這個詞", contexts=contexts))
    check("空關鍵詞回空清單", [], fuzzy.search_keyword(DOC, "", contexts=contexts))
    check("只有空白的關鍵詞也回空清單", [],
          fuzzy.search_keyword(DOC, "   ", contexts=contexts))

    # 同義詞表要能幫忙：搜「保險費」也要找得到寫「應繳金額」的條文
    table = load_synonyms()
    SYN_DOC = ["第一條　要保人應繳納保險費。", "第二條　應繳金額應於期限內繳付。"]
    syn_hits = fuzzy.search_keyword(SYN_DOC, "保險費", synonyms=table)
    check_true("同義詞讓關鍵詞搜尋涵蓋換過用詞的條文", len(syn_hits) >= 2,
               "找到 %d 條" % len(syn_hits))
    check("有標示是靠同義詞才配上的", True,
          any(h["matched_by"] != "原詞" for h in syn_hits))


def test_search_by_changed_text():
    section("35. 拿「這次改動的文字」去搜，補整條比對的死角")

    from _common import (normalize_terms as _norm, extract_article_no as _art,
                         format_scope as _scope, diff_runs as _dr)

    # 整條比對時，分數被「沒改到的部分」主導，而那部分往往是公文套語。
    # 實測：第六條加了「及火險保單」，講火險與保單的兩條整條相似度只有
    # 26.5 分與 16.7 分，在 45 分門檻下一條都抓不到。
    OLD = "第六條　分行辦理房屋貸款，應徵提鑑價報告，並陳報分行經理覆核。"
    NEW = "第六條　分行辦理房屋貸款，應徵提鑑價報告及火險保單，並陳報分行經理覆核。"
    DOC = [
        "第一章　分行授信",
        NEW,
        "第二章　擔保品管理",
        "第四十條　本行辦理擔保放款，應確認擔保品已投保火險，保險金額不得低於放款餘額。",
        "第四十一條　擔保品之保險單正本應由本行收執，並於系統登錄到期日。",
        "第五十條　本要點經董事會核定後施行。",
    ]
    table = load_synonyms()
    contexts = build_hierarchy(DOC)

    # 先確認整條比對真的抓不到，這個測試才有意義
    plain = fuzzy.find_duplicates(NEW, DOC, top=0, exclude_index=2,
                                  contexts=contexts, synonyms=table)
    check("整條比對確實一條都抓不到（這就是死角）", 0, len(plain))

    fragments = fuzzy.changed_fragments(OLD, NEW, _dr)
    check("抓得出這次改了什麼", ["及火險保單"], fragments)

    hits = fuzzy.find_by_changed_text(
        fragments, DOC, exclude_index=2, contexts=contexts, synonyms=table,
        normalize=_norm, extract_article_no=_art, format_scope=_scope, top=8)
    articles = [h["article_no"] for h in hits]
    check_true("改用改動文字搜就找得到", len(hits) >= 2, "、".join(articles))
    check("找到講火險的第四十條", True, any("四十條" in a for a in articles))
    check("找到講保險單的第四十一條（靠同義詞）", True,
          any("四十一" in a for a in articles))
    check("有標出命中的是哪個詞", True,
          all(h["matched"] for h in hits))
    check("章節脈絡有帶出來", True, all(h["scope"] for h in hits))


def test_changed_text_search_noise_guards():
    section("36. 改動文字搜尋不可以把整份文件撈出來")

    from _common import (normalize_terms as _norm, extract_article_no as _art,
                         format_scope as _scope)

    # 這一項是上一次失敗的教訓。用整句自動抽關鍵詞時，974 段的內規有 319 段
    # 命中（33%），完全不能用。現在靠三道防線把雜訊壓下來，缺一不可。
    check("條號不會被當成要搜的詞", [], fuzzy.search_terms("一、"))
    check("款目編號會被剝掉", True,
          "受託人授權書" in fuzzy.search_terms("一、受託人授權書"))
    check("條號也會被剝掉", True,
          "法令遵循單位" in fuzzy.search_terms("第二十五條之一 法令遵循單位"))
    check("開頭的連接詞會被剝掉", True, "火險保單" in fuzzy.search_terms("及火險保單"))
    check("不會切出中間的碎片", False, "險保" in fuzzy.search_terms("及火險保單"))

    # 改動長到像整條改寫時就不搜了——那種情況相似度比對本來就抓得到
    long_fragment = "受託機構有下列情形之一，經主管核准者，得免依前條規定辦理覆核"
    check("整條那麼長的改動不拿去搜", [], fuzzy.search_terms(long_fragment))

    # 沒有辨識力的詞要自動被丟掉：造一份到處都是「受託」的文件
    DOC = ["第%d條　受託機構應依規定辦理。" % i for i in range(1, 41)]
    DOC.append("第四十一條　受託機構應徵提火險保單。")
    hits = fuzzy.find_by_changed_text(
        ["及受託"], DOC, contexts=None, synonyms=[], normalize=_norm,
        extract_article_no=_art, format_scope=_scope, top=0)
    check_true("命中太多段的詞會被判定為沒有辨識力而丟掉",
               len(hits) == 0, "命中 %d 段" % len(hits))

    # 有辨識力的詞照樣找得到
    rare = fuzzy.find_by_changed_text(
        ["及火險保單"], DOC, contexts=None, synonyms=[], normalize=_norm,
        extract_article_no=_art, format_scope=_scope, top=0)
    check("有辨識力的詞找得到", 1, len(rare))

    # 沒有改動片段時不要硬跑
    check("沒有改動片段時回空清單", [],
          fuzzy.find_by_changed_text([], DOC, synonyms=[]))


def main():
    setup_console()
    print("=" * 62)
    print("reg-diff 自我檢查")
    print("Python %s" % sys.version.split()[0])
    print("=" * 62)

    workdir = tempfile.mkdtemp(prefix="reg-diff-selftest-")
    try:
        test_article_no()
        test_reading(workdir)
        csv_path, _ = test_step1(workdir)
        table_docx, annotated = test_step1_docx(workdir, csv_path)
        test_docx_marking(table_docx, annotated)
        test_step2()
        test_step2_from_csv(csv_path)
        test_cli(workdir)
        test_large_document(workdir)
        test_renumber()
        test_renumber_in_report()
        test_reference_forms()
        test_reference_rewrite_precision()
        test_deleted_article_reference()
        test_rule_checks()
        test_law_name_cleanup()
        test_check_pitfalls()
        test_docx_without_package(workdir)
        test_run_all(workdir)
        test_synonyms()
        test_tracked_changes(workdir)
        test_paragraph_references()
        test_csv_is_config_driven(workdir)
        test_annotate_in_place(workdir)
        test_diff_runs_grouping()
        test_docx_elements_survive(workdir)
        test_textbox_not_duplicated(workdir)
        test_operational_guards(workdir)
        test_autonumber_warning(workdir)
        test_candidate_context_and_difference()
        test_difference_keeps_short_changes()
        test_coverage_catches_cross_business_omission()
        test_keyword_search()
        test_search_by_changed_text()
        test_changed_text_search_noise_guards()
        test_config_files_degrade(workdir)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)

    print("\n" + "=" * 62)
    if _failures:
        print("有 %d 項未通過（共 %d 項）：" % (len(_failures), len(_failures) + len(_passes)))
        for label, expected, actual in _failures:
            print("  ✗ %s" % label)
            print("      預期：%r" % (expected,))
            print("      實際：%r" % (actual,))
        print("=" * 62)
        return 1

    print("全部通過（共 %d 項）" % len(_passes))
    print("=" * 62)
    return 0


if __name__ == "__main__":
    sys.exit(main())
