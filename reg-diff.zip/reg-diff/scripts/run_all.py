# -*- coding: utf-8 -*-
"""
單次執行入口：一次跑完 Step 0.5 → 1 → 1.6 → 2 → 2.4 → 2.5 → 2.6

什麼時候用這支：
**執行之間檔案不保留的平台**。有些企業 AI 平台每次執行都給一個全新的暫存
工作目錄（實測 SPADE 就是這樣，兩次執行的目錄是 .tmp9oYOqV 與 .tmp4hmaGp），
上一次寫出來的檔案在下一次執行時根本不存在。

原本的分步流程是：
    Step 1 產出 修正對照表.csv  →  Step 2 用 --from-csv 讀它
中間檔一旦不能跨執行存活，這條路就斷了。

這支把所有步驟放在同一個 process 裡跑完，中間結果全部在記憶體裡傳遞，
不需要任何檔案跨執行存活。產出檔案一次寫齊，人要拿的時候一次拿走。

在檔案會保留的環境上，分步執行仍然可用而且更有彈性（可以只跑某一步、
可以中途調參數再跑）。這支是給不保留的環境用的。

使用方式：
    python run_all.py 舊版.docx 新版.docx
    python run_all.py 舊版.docx 新版.docx --outdir 產出 --title "○○要點修正對照表"
    python run_all.py 舊版.docx 新版.docx --apply-renumber   連款目重編一起做

參數大致與各分步腳本相同，詳見 --help。
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, build_hierarchy,
                     diff_runs, normalize_terms, extract_article_no,
                     load_synonyms, load_table_format, load_term_groups,
                     load_concept_lexicon, concept_coverage,
                     resolve_output, warn_if_versions_swapped)
import concept_extract
import diff_compare
import fuzzy_duplicate_finder as fuzzy
import renumber
import rule_checks
import vector_search


def banner(title):
    print("\n" + "=" * 66)
    print(title)
    print("=" * 66)


def step_renumber(old_paragraphs, new_paragraphs, apply_changes, rewrite_refs):
    """
    Step 0.5：款目編號檢查（以及選用的重編）。

    回傳可能已重編過的新版段落。不論有沒有 --apply-renumber，
    交叉引用的問題都會完整報告出來——那是人要處理的，不能默默跳過。
    """
    banner("Step 0.5　款目編號與交叉引用檢查")

    entries = renumber.scan(new_paragraphs)
    problems = renumber.find_numbering_gaps(entries)
    changes, clause_map, item_map = renumber.plan_renumber(new_paragraphs, entries)

    known_articles = {c["article"] for c in build_hierarchy(new_paragraphs)
                      if c["level"] == "條" and c["article"]}
    references = renumber.scan_references(
        new_paragraphs, entries, clause_map, item_map,
        known_articles=known_articles)

    deleted_articles = renumber.find_deleted_articles(old_paragraphs, new_paragraphs)
    drift = renumber.scan_reference_drift(old_paragraphs, new_paragraphs)

    renumber.report(problems, changes, deleted_articles, references, drift)

    if not changes:
        return new_paragraphs

    if not apply_changes:
        print("\n偵測到 %d 段需要重編，但沒有加 --apply-renumber，"
              "本次不更動編號。" % len(changes))
        print("後續步驟會以「未重編」的內容比對，對照表可能出現編號不連續的段落。")
        return new_paragraphs

    updated = renumber.apply_changes(new_paragraphs, changes, references, rewrite_refs)
    print("\n已重編 %d 段款目編號%s。"
          % (len(changes), "，並改寫可機械式處理的交叉引用" if rewrite_refs else ""))
    return updated


def step_diff(old_paragraphs, new_paragraphs, outdir, prefix, title,
              table_format, source_docx=None):
    """Step 1：精確比對並產出全部檔案。回傳比對結果供後續步驟使用。"""
    banner("Step 1　精確文字比對")

    results = diff_compare.compare_paragraphs(old_paragraphs, new_paragraphs)

    counts = {"added": 0, "deleted": 0, "modified": 0, "renumbered": 0}
    for item in results:
        if item["type"] in counts:
            counts[item["type"]] += 1
    substantive = counts["added"] + counts["deleted"] + counts["modified"]

    print("實質異動 %d 處（新增 %d、刪除 %d、修改 %d）"
          % (substantive, counts["added"], counts["deleted"], counts["modified"]))
    if counts["renumbered"]:
        print("另有 %d 處只是編號調整，內容未變動。" % counts["renumbered"])

    produced = []
    csv_path = resolve_output(outdir, prefix, "修正對照表.csv")
    diff_compare.write_csv_report(results, csv_path, table_format=table_format)
    produced.append(csv_path)

    text_path = resolve_output(outdir, prefix, "標註版全文.txt")
    diff_compare.write_annotated_text(results, text_path)
    produced.append(text_path)

    annotated = resolve_output(outdir, prefix, "標註版全文.docx")
    # 傳新版原檔進去，標註版才能在原檔上改而不是新開一份空白 Word
    diff_compare.export_to_docx(results, annotated, table_format=table_format,
                                source_docx=source_docx)
    if os.path.exists(annotated):
        produced.append(annotated)

    table = resolve_output(outdir, prefix, "修正對照表.docx")
    diff_compare.export_table_to_docx(results, table, title=title,
                                      table_format=table_format)
    if os.path.exists(table):
        produced.append(table)

    return results, produced


def step_rule_checks(old_paragraphs, new_paragraphs, results, outdir, prefix, terms):
    """Step 1.6：十項條文品質與風險檢查。"""
    banner("Step 1.6　條文品質與風險檢查")

    findings = []
    findings += rule_checks.check_article_integrity(new_paragraphs, old_paragraphs)
    findings += rule_checks.check_external_refs(new_paragraphs)
    findings += rule_checks.check_placeholders(new_paragraphs)
    findings += rule_checks.check_format_consistency(new_paragraphs)
    findings += rule_checks.check_term_consistency(new_paragraphs, terms)
    findings += rule_checks.check_attachments(new_paragraphs)
    findings += rule_checks.check_definitions(new_paragraphs, results)
    findings += rule_checks.check_modal_changes(results)
    findings += rule_checks.check_numeric_changes(results)
    findings += rule_checks.check_effective_date(new_paragraphs, results)

    rule_checks.report(findings)

    produced = []
    if findings:
        path = resolve_output(outdir, prefix, "條文檢查報告.csv")
        rule_checks.write_csv(findings, path)
        produced.append(path)
    return findings, produced


def step_duplicates(new_paragraphs, results, outdir, prefix, threshold, top,
                    synonyms, context_span=1, changed_top=8):
    """
    Step 2：跨章節重複條文。

    這裡直接吃 Step 1 的比對結果，不像分步版那樣去讀 修正對照表.csv——
    中間檔不必存在，也就不怕它在下一次執行時消失。
    """
    banner("Step 2　跨章節重複條文（最重要的一步）")

    # 缺 rapidfuzz 時一定要講。實測 1,199 段的內規，內建 difflib 抓到的候選數
    # 比 rapidfuzz 少約 7%——這是一個抓漏改的工具，少 7% 的候選要讓人知道。
    if not fuzzy.HAS_RAPIDFUZZ:
        print("提醒：這個環境沒有 rapidfuzz，改用 Python 內建的 difflib 比對。")
        print("      結果相近但不完全相同，實測大型內規的候選數約少 7%，")
        print("      人工複核時請留意可能有少數候選沒被列出。")

    if synonyms:
        print("已載入同義詞表：%d 組變體（用來抓「用詞完全換掉」的重複條文）"
              % len(synonyms))
    else:
        print("未使用同義詞表，只做純字面比對。")

    contexts = build_hierarchy(new_paragraphs)
    changes = []
    for item in results:
        if item["type"] == "unchanged":
            continue
        if item["type"] == "renumbered":
            continue      # 純編號位移，內容沒變，不需要找重複
        if item["type"] == "deleted":
            text, line_no = item["old_text"], None
        else:
            text, line_no = item["new_text"], item.get("new_index")
        if text:
            changes.append({"article_no": item.get("ref", ""), "text": text,
                            "old_text": item.get("old_text") or "",
                            "line_number": line_no})

    if not changes:
        print("沒有實質異動，略過。")
        return [], []

    print("針對 %d 個異動段落比對全文 %d 段（門檻 %.0f%%）..."
          % (len(changes), len(new_paragraphs), threshold))

    csv_rows = []
    changed_rows = []
    total = 0
    for change in changes:
        candidates = fuzzy.find_duplicates(
            change["text"], new_paragraphs, threshold=threshold, top=top,
            exclude_index=change["line_number"], contexts=contexts,
            synonyms=synonyms, context_span=context_span,
            changed_old_text=change.get("old_text"))
        total += len(candidates)
        fuzzy.print_candidates(change["text"], candidates, threshold)
        # 整條比對抓不到的東西，改用「這次改動的文字」再搜一次。
        # 實測：某條加了「及火險保單」，講火險與保單的兩條整條相似度只有
        # 26.5 與 16.7 分，門檻下一條都抓不到，用改動文字搜就找得到。
        fragments = fuzzy.changed_fragments(
            change.get("old_text") or "", change["text"], diff_runs)
        extra = fuzzy.find_by_changed_text(
            fragments, new_paragraphs,
            exclude_index=change["line_number"], contexts=contexts,
            synonyms=synonyms, normalize=normalize_terms,
            extract_article_no=extract_article_no,
            format_scope=fuzzy.format_scope, top=changed_top)
        fuzzy.print_changed_text_hits(fragments, extra)
        for hit in extra:
            changed_rows.append([
                change["article_no"], change["text"],
                "、".join(fragments), hit.get("scope", ""),
                hit["article_no"], hit["line_number"], hit["text"],
                "、".join(t for _, t in hit["matched"]), "",
            ])

        for candidate in candidates:
            csv_rows.append([
                change["article_no"], change["text"],
                candidate.get("scope", ""), candidate["article_no"],
                candidate["line_number"], candidate["text"],
                candidate["similarity"], candidate["fragment_len"],
                candidate.get("fragment_position", ""),
                candidate["common_fragment"],
                "、".join(candidate.get("synonym_evidence", [])),
                candidate.get("coverage", ""),
                candidate.get("difference", ""),
                candidate.get("context_before", ""),
                candidate.get("context_after", ""), "",
            ])

    produced = []
    if changed_rows:
        path = resolve_output(outdir, prefix, "異動文字關聯條文.csv")
        fuzzy.write_changed_text_csv(changed_rows, path)
        produced.append(path)
    if csv_rows:
        path = resolve_output(outdir, prefix, "重複條文候選清單.csv")
        fuzzy.write_candidates_csv(csv_rows, path)
        produced.append(path)

    print("\n共列出 %d 筆候選。提醒：這是輔助抓取的建議，不保證完整覆蓋，"
          "最終仍需人工確認。" % total)
    return csv_rows, produced


def step_vector(new_paragraphs, results, outdir, prefix, synonyms, lexicon,
                top, min_score, embeddings=None):
    """
    Step 2.4：向量搜尋。

    跟 Step 2 找的是同一件事（相關條文），但走的是不同的訊號，所以兩份清單
    要分開看、不要合併。Step 2 的分數是字面相似度 0～100 分；這裡是餘弦
    0～1，兩把尺不能互相比較。**兩邊都列到的那幾條，可信度明顯比只有一邊
    列到的高**，回報時值得特別點出來。

    回傳 (索引, 候選列, 產出檔案)。索引建好之後 Step 2.6 直接沿用，
    一份文件只建一次。
    """
    banner("Step 2.4　向量搜尋（可稽核，不用模型、不連網路）")

    if not lexicon:
        print("沒有可用的概念詞庫，向量只剩字元 n-gram 維度，"
              "抓到的東西會跟 Step 2 高度重疊。")

    index = vector_search.build_index(new_paragraphs, synonyms, lexicon,
                                      embeddings=embeddings)
    if isinstance(index, vector_search.Index):
        print("已建索引：%d 段、%d 個維度（字元 n-gram ＋ 概念 ＋ 數值型態）"
              % (len(new_paragraphs), index.dimensions))

    body = vector_search.body_indexes(index)
    changed = [r for r in results if r["type"] not in ("unchanged", "renumbered")]
    rows = []
    for result in changed:
        text = result.get("new_text") or result.get("old_text") or ""
        if not text.strip():
            continue
        line_no = result.get("new_index") or result.get("old_index")
        exclude = [line_no - 1] if isinstance(line_no, int) else []
        hits = index.search(text, top=top, min_score=min_score,
                            exclude=exclude, only=body)
        if not hits:
            continue
        vector_search.print_hits(text, hits, min_score)
        for hit in hits:
            rows.append([result.get("ref", ""), text, hit["scope"],
                         hit["article_no"], hit["line_number"], hit["text"],
                         "%.3f" % hit["score"], hit["why"],
                         "、".join(hit["concepts"]), ""])

    produced = []
    if rows:
        path = resolve_output(outdir, prefix, "向量相似候選.csv")
        vector_search.write_csv(rows, path)
        produced.append(path)
    else:
        print("沒有超過 %.2f 的相關條文。" % min_score)

    return index, rows, produced


def step_concepts(results, new_paragraphs, index, outdir, prefix, lexicon,
                  synonyms, gap_top, gap_min_score):
    """
    Step 2.5 抽出這次改了哪些「修法概念」，Step 2.6 拿它去搜沒有改到的條文。

    這兩步要回答的是 Step 1、Step 1.6 都回答不了的問題：
    「這次動到的主題，全文還有哪幾條也帶著同一個主題、卻沒有跟著改？」
    驗收測資裡第四條改了撤銷退費期限、第七條講同一件事沒改，就是這一步抓的。
    """
    banner("Step 2.5　修法概念抽取")

    concepts = concept_extract.extract(results, lexicon, synonyms)
    concept_extract.report(concepts)

    produced = []
    if concepts:
        path = resolve_output(outdir, prefix, "修法概念清單.csv")
        concept_extract.write_csv(concepts, path)
        produced.append(path)

    if not concepts or index is None or not lexicon:
        return concepts, [], produced

    banner("Step 2.6　同概念但這次沒改的條文")
    changed = [c["索引"] for c in concepts if isinstance(c.get("索引"), int)]
    gaps = concept_extract.find_gaps(concepts, index, changed,
                                     top=gap_top, min_score=gap_min_score)
    concept_extract.report_gaps(gaps, gap_min_score)
    if gaps:
        path = resolve_output(outdir, prefix, "概念漏改候選.csv")
        concept_extract.write_gaps_csv(gaps, path)
        produced.append(path)

    return concepts, gaps, produced


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="單次執行：一次跑完 Step 0.5 → 1 → 1.6 → 2 → 2.4 → 2.5 → 2.6")
    parser.add_argument("old_file", help="舊版內規檔案（.docx / .txt / .md）")
    parser.add_argument("new_file", help="新版內規檔案（.docx / .txt / .md）")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    parser.add_argument("--title", default="修正對照表",
                        help="修正對照表 Word 檔的標題")
    parser.add_argument("--apply-renumber", action="store_true",
                        help="實際重編款目編號（預設只檢查不動）")
    parser.add_argument("--rewrite-refs", action="store_true",
                        help="連可機械式改寫的交叉引用一起改；"
                             "引用到已刪除款目的一律不動")
    parser.add_argument("--threshold", type=float, default=fuzzy.DEFAULT_THRESHOLD,
                        help="Step 2 相似度門檻，預設 %g" % fuzzy.DEFAULT_THRESHOLD)
    parser.add_argument("--top", type=int, default=fuzzy.DEFAULT_TOP,
                        help="每個異動段落最多列幾筆候選，預設 %d" % fuzzy.DEFAULT_TOP)
    parser.add_argument("--synonyms", default=None,
                        help="同義詞表路徑，預設用 scripts/synonyms.json")
    parser.add_argument("--no-synonyms", action="store_true",
                        help="關閉同義詞正規化，只做純字面比對")
    parser.add_argument("--context", type=int, default=1,
                        help="候選條文附帶前後各幾段，預設 1；設 0 表示不附。"
                             "前後文是給 LLM 判斷「這是漏改還是層級本來就不同」用的")
    parser.add_argument("--changed-top", type=int, default=8,
                        help="「以改動文字搜尋全文」最多列幾條，預設 8；設 0 表示關閉")
    parser.add_argument("--terms", default=None,
                        help="自訂用語混用對照表（JSON，二維陣列），預設用內建的用語表")
    parser.add_argument("--format", default=None,
                        help="對照表版面設定檔，預設用 scripts/對照表格式.json")
    parser.add_argument("--concepts", default=None,
                        help="修法概念詞庫路徑，預設用 scripts/修法概念詞庫.json")
    parser.add_argument("--no-vector", action="store_true",
                        help="關掉 Step 2.4 與 2.6 的向量搜尋，只留概念分類")
    parser.add_argument("--vector-top", type=int, default=vector_search.DEFAULT_TOP,
                        help="Step 2.4 每個異動段落最多列幾筆，預設 %d"
                             % vector_search.DEFAULT_TOP)
    parser.add_argument("--vector-min-score", type=float,
                        default=vector_search.DEFAULT_MIN_SCORE,
                        help="Step 2.4 的餘弦門檻，預設 %.2f"
                             % vector_search.DEFAULT_MIN_SCORE)
    parser.add_argument("--gap-min-score", type=float,
                        default=concept_extract.DEFAULT_GAP_MIN_SCORE,
                        help="Step 2.6 的餘弦門檻，預設 %.2f"
                             % concept_extract.DEFAULT_GAP_MIN_SCORE)
    parser.add_argument("--gap-top", type=int,
                        default=concept_extract.DEFAULT_GAP_TOP,
                        help="Step 2.6 每筆概念最多搜幾條，預設 %d"
                             % concept_extract.DEFAULT_GAP_TOP)
    parser.add_argument("--embeddings", default=None,
                        help="外部向量 JSONL（單位自己算好的，程式不連網路）")
    args = parser.parse_args()

    banner("內規修正比對　單次執行")
    print("舊版：%s" % args.old_file)
    print("新版：%s" % args.new_file)

    warn_if_versions_swapped(args.old_file, args.new_file)
    old_paragraphs = read_paragraphs(args.old_file)
    new_paragraphs = read_paragraphs(args.new_file)
    print("舊版 %d 段、新版 %d 段" % (len(old_paragraphs), len(new_paragraphs)))

    new_paragraphs = step_renumber(
        old_paragraphs, new_paragraphs, args.apply_renumber, args.rewrite_refs)

    produced = []
    results, files = step_diff(old_paragraphs, new_paragraphs,
                               args.outdir, args.prefix, args.title,
                               load_table_format(args.format),
                               source_docx=args.new_file)
    produced += files

    _, files = step_rule_checks(
        old_paragraphs, new_paragraphs, results, args.outdir, args.prefix,
        load_term_groups(args.terms, rule_checks.DEFAULT_TERM_GROUPS))
    produced += files

    synonyms = [] if args.no_synonyms else load_synonyms(args.synonyms)
    _, files = step_duplicates(new_paragraphs, results, args.outdir, args.prefix,
                               args.threshold, args.top, synonyms,
                               context_span=args.context,
                               changed_top=args.changed_top)
    produced += files

    lexicon = load_concept_lexicon(args.concepts)
    counts, too_broad = concept_coverage(new_paragraphs, lexicon)
    if too_broad:
        print("\n提醒：這幾個概念在全文命中超過四成，沒有辨識力，本次不當搜尋條件：")
        for concept in too_broad:
            print("      %s（%d/%d 段）"
                  % (concept, counts[concept], len(new_paragraphs)))
        print("      要調整的話改 scripts/修法概念詞庫.json，把觸發詞收窄。")
        lexicon = {c: w for c, w in lexicon.items() if c not in too_broad}

    index = None
    if not args.no_vector:
        index, _, files = step_vector(
            new_paragraphs, results, args.outdir, args.prefix, synonyms, lexicon,
            args.vector_top, args.vector_min_score, embeddings=args.embeddings)
        produced += files

    _, _, files = step_concepts(
        results, new_paragraphs, index, args.outdir, args.prefix, lexicon,
        synonyms, args.gap_top, args.gap_min_score)
    produced += files

    # 重編過的話，把結果也寫出來，否則使用者手上沒有那份修好編號的全文
    if args.apply_renumber:
        path = resolve_output(args.outdir, args.prefix, "重編後_新版全文.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(new_paragraphs) + "\n")
        print("\n已產生重編後全文：%s" % path)
        produced.append(path)

    banner("產出檔案")
    print("以下檔案已寫入。若平台不會把檔案顯示在對話裡，請依路徑自行取用：\n")
    for path in produced:
        print("  %s" % path)
    print("\n共 %d 個檔案。" % len(produced))
    return produced


if __name__ == "__main__":
    main()
