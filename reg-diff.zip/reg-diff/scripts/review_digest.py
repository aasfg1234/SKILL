# -*- coding: utf-8 -*-
"""
收尾：把四路引擎的結果收斂成一份「送出前要處理的事」

--------------------------------------------------------------------------
為什麼需要這一支
--------------------------------------------------------------------------
Step 2、2.4、2.6 加起來會產出四份候選清單，51 頁的內規實測一百多列。
實測回饋很直接：**檔案太多不知道看哪個、候選太多不知從何看起、
型態名稱看不懂、分數沒感覺。** 四個問題其實是同一個問題——
工具把「找得到」做完了，沒有把「該先看哪一筆」做完。

所以這一支不產生任何新的比對結果，它只做四件事：

1. **合併去重。** 同一條條文被四路指到，只列一次，標明「4 路都指到」
2. **分級。** 用一條寫得出來的規則排序，不是模型猜的
3. **翻成人話。** 不印餘弦 0.266，印「同主題但寫法不同」；
   不印「責任強度」，印「把『應』改成『得』」
4. **寫成一句待辦。** 每一筆結尾都是一個問句，因為這些事最終要人回答

--------------------------------------------------------------------------
分級規則（寫在這裡，因為使用者會問「憑什麼說它是高」）
--------------------------------------------------------------------------
四路引擎各自獨立：

    字面      Step 2 的整條模糊比對
    異動文字  拿這次改的那幾個字去搜全文
    向量      Step 2.4 的餘弦
    概念      Step 2.6 的「同主題但這次沒改」

    3 路以上指到            → 必須確認
    2 路指到                → 請再看一眼
    1 路但字面 80 分以上     → 請再看一眼（整條幾乎照抄，一路也夠）
    其餘                    → 低信心，只給數量，明細留在檔案裡

**分級是排序用的，不是結論。** 一路指到不代表沒事，四路指到也不代表一定要改。
真實內規實測過：整份文件到處是「並陳報主管覆核」，四路都會指到，
但核准層級本來就該不同。
"""

import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import setup_console


# 四路引擎的固定順序，畫面與 CSV 都照這個順序講，人才對得起來
SOURCES = ("字面", "異動文字", "向量", "概念")

HIGH, MEDIUM, LOW = "必須確認", "請再看一眼", "低信心"

# 主控台上「請再看一眼」最多印幾筆，其餘留在複核清單檔案裡
MEDIUM_CONSOLE_LIMIT = 10

# 型態的實務講法。程式內部用「責任強度」這種分類名沒問題，
# 但那不是法遵同仁講話的方式，印給人看之前要換掉。
PLAIN_KIND = {
    "期限變更": "期限改了",
    "金額變更": "金額改了",
    "比率變更": "比率改了",
    "責任強度": "責任用語改了",
    "用語替換": "換了寫法（同義詞，不影響實質）",
    "名詞更動": "換了主體或權責單位",
    "範圍適用": "準用／適用範圍改了",
    "文字增刪": "加了或刪了一段文字",
    "條文增刪": "整條新增或刪除",
}


def plain_literal(score):
    """把 0～100 的字面相似度講成人話。數字留著，但前面要有一句判斷。"""
    if score >= 80:
        return "字面幾乎照抄（%.0f 分）" % score
    if score >= 60:
        return "改寫過但講同一件事（%.0f 分）" % score
    return "部分字句相同（%.0f 分）" % score


def plain_vector(score):
    """
    把餘弦講成人話。

    「0.266」對法遵同仁沒有任何意義——它不知道 0.266 是高是低，
    也沒有別的數字可以比。實測分佈：同一件事寫在兩章 0.35～0.87、
    同主題但層級不同 0.18～0.35、不相干 0.02～0.12，就照這個切。
    """
    if score >= 0.6:
        return "整體高度相關"
    if score >= 0.35:
        return "相關"
    return "同主題但寫法不同"


def _quote(text, limit=60):
    text = (text or "").strip()
    return text[:limit] + ("…" if len(text) > limit else "")


# ---------------------------------------------------------------------------
# 一、把四路的結果收進同一個袋子
# ---------------------------------------------------------------------------

def _slot(bag, line_number, paragraph_lookup):
    item = bag.get(line_number)
    if item is None:
        info = paragraph_lookup(line_number)
        item = {
            "line_number": line_number,
            "text": info.get("text", ""),
            "article_no": info.get("article_no", ""),
            "ref": info.get("ref", ""),
            "scope": info.get("scope", ""),
            "sources": {},
            "triggers": [],
        }
        bag[line_number] = item
    return item


def _add_trigger(item, ref, kind, summary, shared=()):
    """記下「是哪一處異動指到它的」。同一處異動經由不同引擎重複指到只留一次。"""
    key = (ref or "", summary or "")
    for existing in item["triggers"]:
        if (existing["條號"], existing["摘要"]) == key:
            for concept in shared:
                if concept not in existing["共同概念"]:
                    existing["共同概念"].append(concept)
            return
    item["triggers"].append({
        "條號": ref or "", "型態": kind or "", "摘要": summary or "",
        "共同概念": list(shared),
    })


def collect(paragraphs, contexts, fuzzy_hits=(), changed_text_hits=(),
            vector_hits=(), concept_gaps=(), concepts=()):
    """
    把四路的命中收成一份以「候選條文」為主鍵的清單。

    四路傳進來的資料格式各自不同（一路是 dict、一路是 CSV 列），
    刻意在這裡各接各的，而不是回頭去改四支程式的輸出格式——
    那四支都有測試盯著，為了收尾好寫而動它們不划算。
    """
    from _common import extract_article_no, format_scope

    def lookup(line_number):
        index = line_number - 1
        if not (0 <= index < len(paragraphs)):
            return {}
        context = contexts[index] if index < len(contexts) else {}
        return {"text": paragraphs[index],
                "article_no": extract_article_no(paragraphs[index]),
                "ref": context.get("ref", ""), "scope": format_scope(context)}

    # 哪一條異動屬於哪一種修法型態，給下面四路共用
    kind_by_ref = {}
    for concept in concepts:
        kind_by_ref.setdefault(concept["條號"], []).append(concept)

    def kind_of(ref):
        found = kind_by_ref.get(ref) or []
        return found[0] if found else None

    bag = {}

    for hit in fuzzy_hits:
        item = _slot(bag, hit["line_number"], lookup)
        item["sources"]["字面"] = {
            "score": hit.get("similarity", 0.0),
            "note": plain_literal(hit.get("similarity", 0.0)),
            "extra": "、".join(hit.get("synonym_evidence", []) or []),
        }
        concept = kind_of(hit.get("source_ref", ""))
        _add_trigger(item, hit.get("source_ref", ""),
                     concept["型態"] if concept else "",
                     concept["摘要"] if concept else "")

    for hit in changed_text_hits:
        item = _slot(bag, hit["line_number"], lookup)
        item["sources"]["異動文字"] = {
            "score": None,
            "note": "改動的字也出現在這裡",
            "extra": "、".join((hit.get("terms") or [])[:4]),
        }
        concept = kind_of(hit.get("source_ref", ""))
        _add_trigger(item, hit.get("source_ref", ""),
                     concept["型態"] if concept else "",
                     concept["摘要"] if concept else "")

    for hit in vector_hits:
        item = _slot(bag, hit["line_number"], lookup)
        item["sources"]["向量"] = {
            "score": hit.get("score", 0.0),
            "note": plain_vector(hit.get("score", 0.0)),
            # 只留概念，不留 n-gram 清單。「契約、約撤、撤銷、通知…」這種東西
            # 對讀的人沒有意義，它屬於除錯資訊，留在 明細/向量相似候選.csv 裡就好。
            "extra": "、".join(hit.get("concepts", [])[:4]),
            "why": hit.get("why", ""),
        }
        concept = kind_of(hit.get("source_ref", ""))
        _add_trigger(item, hit.get("source_ref", ""),
                     concept["型態"] if concept else "",
                     concept["摘要"] if concept else "",
                     hit.get("concepts", []))

    for gap in concept_gaps:
        item = _slot(bag, gap["候選段次"], lookup)
        shared = sorted({c for s in gap["指向來源"] for c in s["共同概念"]})
        item["sources"]["概念"] = {
            "score": gap.get("相似度", 0.0),
            "note": "同主題但這次沒改",
            "extra": "、".join(shared[:4]),
        }
        for source in gap["指向來源"]:
            _add_trigger(item, source["條號"], source["型態"],
                         source["摘要"], source["共同概念"])

    items = list(bag.values())
    for item in items:
        item["confidence"] = _grade(item)

    # 一定要先併再生成句子。反過來的話併起來的那一筆會沿用第一個條號的句子，
    # 變成「第四十五條跟它有關」，但標題寫的是「第四十五條、第一百十六條共 2 處」，
    # 兩行自相矛盾。
    items = merge_identical(items)
    for item in items:
        item["說明"], item["問句"] = _describe(item)
        item["為什麼被列出來"] = _why(item)

    order = {HIGH: 0, MEDIUM: 1, LOW: 2}
    items.sort(key=lambda i: (order[i["confidence"]], -len(i["sources"]),
                              i["line_number"]))
    return items


def merge_identical(items):
    """
    條文一字不差、又被同一處異動指到的，併成一筆。

    這是內規最常見的形狀——「保險費繳納證明，並依前條規定辦理覆核」這一款
    在壽險、產險、網路投保各章各寫一次，51 頁的測資裡出現七次。
    七筆分開列，人得讀七遍一模一樣的字才發現是同一件事；併成一筆之後
    是「這 7 處條文完全相同，要不要一起改」，那才是他要回答的問題。

    併的條件很嚴：剝掉條號款號之後**一字不差**，而且指向它的異動也相同。
    只是「很像」不併——那種差異可能正是重點。
    """
    from _common import strip_article_no

    def key_of(item):
        body = strip_article_no(item["text"] or "")
        body = "".join(body.split())
        triggers = tuple(sorted((t["條號"], t["摘要"]) for t in item["triggers"]))
        return (body, triggers, item["confidence"])

    groups = {}
    for item in items:
        groups.setdefault(key_of(item), []).append(item)

    merged = []
    for group in groups.values():
        first = min(group, key=lambda i: i["line_number"])
        if len(group) > 1:
            first = dict(first)
            first["同文條號"] = [i["ref"] or i["article_no"]
                                 or ("第 %d 段" % i["line_number"])
                                 for i in sorted(group,
                                                 key=lambda i: i["line_number"])]
            first["同文段次"] = [i["line_number"]
                                 for i in sorted(group,
                                                 key=lambda i: i["line_number"])]
        merged.append(first)
    return merged


def _grade(item):
    hit_count = len(item["sources"])
    if hit_count >= 3:
        return HIGH
    if hit_count == 2:
        return MEDIUM
    literal = item["sources"].get("字面")
    if literal and literal["score"] >= 80:
        return MEDIUM
    return LOW


# ---------------------------------------------------------------------------
# 二、翻成人話
# ---------------------------------------------------------------------------

def _describe(item):
    """
    產出兩句話：發生了什麼、要問什麼。

    句子是規則產生的，不是 LLM 寫的。這一步刻意不交給模型：
    「第四條把十五日改成三十日、第七條還是十五日」是查得到的事實，
    交給模型只會多一個講錯的機會。模型該做的是後面那層判斷，不是複述。
    """
    if not item["triggers"]:
        return "", "這一條要不要一起處理？"

    trigger = max(item["triggers"], key=lambda t: len(t["共同概念"]))
    where = trigger["條號"] or "這次改的那一條"
    kind = trigger["型態"]
    summary = trigger["摘要"] or ""
    target = _target(item)
    old_value, new_value = _split_summary(summary)
    body = item["text"] or ""
    still_there = bool(old_value) and old_value in body

    if kind in ("期限變更", "金額變更", "比率變更"):
        noun = {"期限變更": "期限", "金額變更": "金額", "比率變更": "比率"}[kind]
        if still_there and new_value:
            say = ("你把%s的%s從「%s」改成「%s」，%s寫的還是「%s」。"
                   % (where, noun, old_value, new_value, target, old_value))
            ask = "%s要不要一起改成「%s」？" % (target, new_value)
        else:
            # 舊值不在候選條文裡（例如它是「準用第五條」而不是自己寫期限），
            # 就不要斷言「它也有期限規定」——那句話會是錯的。
            say = ("你改了%s的%s（%s），%s跟它有關，這次沒有跟著動。"
                   % (where, noun, summary, target))
            ask = "%s要不要跟著調整？" % target
        if kind == "金額變更":
            ask += "核決權限的層級也要一起看。"
        return say, ask

    if kind == "責任強度":
        verb = "放寬" if "放寬" in summary or "鬆綁" in summary else "改"
        if "加重" in summary or "加嚴" in summary:
            verb = "收緊"
        if still_there and new_value:
            say = ("你把%s的「%s」%s成「%s」，%s用的還是「%s」。"
                   % (where, old_value, verb, new_value, target, old_value))
        else:
            say = ("你%s了%s的責任用語（%s），%s講的是同一件事。"
                   % (verb, where, summary, target))
        return say, "兩邊的責任強度本來就該不同嗎？還是%s也要跟著%s？" % (target, verb)

    if kind == "用語替換":
        return ("你把%s的「%s」改寫成「%s」，這是用語統一、不影響實質。"
                % (where, old_value, new_value),
                "%s裡的寫法要不要一起換，讓全文一致？" % target)

    if kind == "名詞更動":
        return ("你把%s的「%s」換成「%s」，%s裡還是舊的寫法。"
                % (where, old_value, new_value, target),
                "這是不是權責移轉？%s的權責分工要不要跟著改？" % target)

    if kind == "範圍適用":
        return ("你改了%s的準用／適用範圍（%s）。" % (where, summary),
                "%s跟它有關，準用的內容改完之後還通嗎？" % target)

    if kind == "文字增刪":
        return ("你在%s%s。" % (where, summary),
                "%s講的是同一件事，要不要一起處理？" % target)

    if kind == "條文增刪":
        return ("%s%s。" % (where, summary),
                "引用或對應到它的%s要不要一起處理？" % target)

    return ("%s這次改了，%s跟它高度相關但沒有動。" % (where, target),
            "這兩條要不要一起處理？")


def _target(item):
    """句子裡要怎麼稱呼這一筆。併過的講「這 N 處」，一直重複列六個條號讀不下去。"""
    same = item.get("同文條號")
    if same:
        return "這 %d 處" % len(same)
    return item["ref"] or item["article_no"] or ("第 %d 段" % item["line_number"])


def _split_summary(summary):
    """把「十五日 → 三十日」拆成新舊值。拆不開就回空字串，不硬猜。"""
    if "→" in summary:
        parts = [p.strip() for p in summary.split("→", 1)]
        old_value = "" if parts[0] in ("（無）", "") else parts[0]
        new_value = "" if parts[1] in ("（無）", "") else parts[1]
        return old_value, new_value
    return "", ""


def _why(item):
    """
    「為什麼被列出來」：四路各自的證據串成一句。

    刻意壓得很短。向量那一路內部帶著 n-gram 明細（「契約、約撤、撤銷…」），
    那是除錯資訊不是給人看的，留在 明細/向量相似候選.csv 裡就好。
    概念清單也只在一個地方講——向量與概念兩路都會帶概念，
    重複講兩次會讓人以為是兩件不同的事。
    """
    parts = []
    has_concept_source = "概念" in item["sources"]
    for name in SOURCES:
        source = item["sources"].get(name)
        if not source:
            continue
        piece = source["note"]
        extra = source.get("extra") or ""
        if name == "向量" and has_concept_source:
            extra = ""          # 下面「概念」那一路會講，不要講兩次
        if extra:
            piece += "（%s）" % extra
        parts.append(piece)
    return "；".join(parts)


# ---------------------------------------------------------------------------
# 三、印出來 / 寫成檔案
# ---------------------------------------------------------------------------

# 方向也要講人話。程式內部寫「責任放寬（鬆綁）」沒問題，
# 印出來變成「責任用語改了（責任放寬（鬆綁））」括號套括號，讀起來很卡。
PLAIN_DIRECTION = {
    "責任放寬（鬆綁）": "放寬", "責任加重（加嚴）": "加嚴",
    "責任用語增刪": "增刪", "用語調整": "只是換說法", "用語統一": "用語統一",
}


def summarize_changes(concepts):
    """開頭那一句「這次改了什麼」。用實務講法，不要用程式的分類名。"""
    if not concepts:
        return "這次沒有實質異動。"

    by_kind = {}
    for concept in concepts:
        by_kind.setdefault(concept["型態"], []).append(concept)

    parts = []
    for kind in sorted(by_kind, key=lambda k: -len(by_kind[k])):
        group = sorted(by_kind[kind],
                       key=lambda c: c["段次"] if isinstance(c["段次"], int) else 0)
        # 依段次排，不要依條號字串排：中文照 codepoint 排會把「第五條」
        # 排到「第四條」前面，使用者會以為工具連順序都弄錯
        refs, seen = [], set()
        for concept in group:
            if concept["條號"] and concept["條號"] not in seen:
                seen.add(concept["條號"])
                refs.append(concept["條號"])
        label = PLAIN_KIND.get(kind, kind)
        directions = []
        for concept in group:
            plain = PLAIN_DIRECTION.get(concept["方向"], concept["方向"])
            if plain and plain not in directions:
                directions.append(plain)
        if directions:
            label += "（%s）" % "、".join(directions)
        parts.append("%s %d 處%s" % (label, len(group),
                                     "：%s" % "、".join(refs) if refs else ""))
    return "這次改了 %d 處——%s" % (len(concepts), "；".join(parts))


# Step 1.6 這兩項在 Step 2.5 已經用更清楚的方式講過了（「應 → 得」而不是
# 「應 → （無）」），兩邊都印會自相矛盾，使用者會問到底哪個對。
_COVERED_BY_CONCEPTS = ("責任用語變更", "數值期間變更")


def quality_todos(findings):
    """條文品質檢查裡，真正還要人去處理、而且沒被修法概念講過的那幾項。"""
    return [f for f in findings
            if f.get("check") not in _COVERED_BY_CONCEPTS
            and f.get("severity") in ("高", "中")]


def report(items, concepts, high_findings=(), detail_dir=""):
    """主控台輸出。這一段就是要給 AI 照抄給使用者聽的，所以寫成人話。"""
    print("\n" + "=" * 66)
    print("送出前要處理的事")
    print("=" * 66)
    print(summarize_changes(concepts))

    graded = {HIGH: [], MEDIUM: [], LOW: []}
    for item in items:
        graded[item["confidence"]].append(item)

    print("\n必須確認 %d 件、請再看一眼 %d 件、低信心 %d 筆%s。"
          % (len(graded[HIGH]), len(graded[MEDIUM]), len(graded[LOW]),
             "（明細在 %s）" % detail_dir if detail_dir else ""))

    todos = quality_todos(high_findings)
    if todos:
        print("\n【送出前還要處理的 %d 件事（條文品質檢查）】" % len(todos))
        for finding in todos:
            mark = "⚠" if finding.get("severity") == "高" else "・"
            where = finding.get("ref") or ""
            print("  %s %s%s：%s"
                  % (mark, "%s " % where if where else "",
                     finding.get("check", ""), finding.get("detail", "")))
            if finding.get("action"):
                print("      → %s" % finding["action"])

    # 「必須確認」不設上限——那是這次一定要看的東西，截斷等於把工作藏起來。
    # 「請再看一眼」設上限，否則大型內規會印出幾十筆，AI 要轉述給使用者聽時
    # 反而又回到「太多不知從何看起」。超過的部分在複核清單裡都在。
    number = 0
    for level in (HIGH, MEDIUM):
        if not graded[level]:
            continue
        shown = graded[level] if level == HIGH else graded[level][:MEDIUM_CONSOLE_LIMIT]
        print("\n【%s】" % level)
        for item in shown:
            number += 1
            _print_item(number, item)
        if len(graded[level]) > len(shown):
            print("\n   （另有 %d 件同級的沒印出來，都在 複核清單.md 裡）"
                  % (len(graded[level]) - len(shown)))

    if graded[LOW]:
        print("\n【低信心】另有 %d 筆只被 1 路指到，沒有列在上面。"
              % len(graded[LOW]))
        print("      要看的話開 複核清單.csv，最後面那一段就是。")

    if not graded[HIGH] and not graded[MEDIUM]:
        print("\n沒有需要優先確認的條文。這不代表沒有漏改——"
              "概念詞庫沒收到的主題就標不出來，低信心那幾筆仍值得抽看。")

    print("\n以上是輔助抓取的建議，最終仍需人工複核後才能送出。")


def where_of(item):
    """這一筆指的是哪裡。併過的要把同文的條號全部列出來，不能只講第一個。"""
    same = item.get("同文條號")
    if same:
        shown = "、".join(same[:6]) + ("…" if len(same) > 6 else "")
        return "%s（共 %d 處，條文完全相同）" % (shown, len(same))
    return item["ref"] or item["article_no"] or ("第 %d 段" % item["line_number"])


def _print_item(number, item):
    where = where_of(item)
    scope = "（%s）" % item["scope"] if item["scope"] and not item.get("同文條號") else ""
    print("\n%d. %s%s　%d 路指到：%s"
          % (number, where, scope, len(item["sources"]),
             "、".join(name for name in SOURCES if name in item["sources"])))
    print("   %s" % _quote(item["text"], 70))
    if item["說明"]:
        print("   %s" % item["說明"])
    print("   → %s" % item["問句"])
    print("   為什麼被列出來：%s" % item["為什麼被列出來"])


def write_markdown(items, concepts, path, high_findings=()):
    graded = {HIGH: [], MEDIUM: [], LOW: []}
    for item in items:
        graded[item["confidence"]].append(item)

    lines = ["# 送出前要處理的事", "",
             summarize_changes(concepts), "",
             "必須確認 %d 件、請再看一眼 %d 件、低信心 %d 筆（低信心只列在 複核清單.csv）。"
             % (len(graded[HIGH]), len(graded[MEDIUM]), len(graded[LOW])), ""]

    todos = quality_todos(high_findings)
    if todos:
        lines += ["## 送出前還要處理的 %d 件事（條文品質檢查）" % len(todos), ""]
        for finding in todos:
            mark = "**⚠**" if finding.get("severity") == "高" else "-"
            lines.append("%s %s %s：%s"
                         % (mark, finding.get("ref", ""),
                            finding.get("check", ""), finding.get("detail", "")))
            if finding.get("action"):
                lines.append("  - → %s" % finding["action"])
        lines.append("")

    number = 0
    for level in (HIGH, MEDIUM):
        if not graded[level]:
            continue
        lines += ["## %s（%d 件）" % (level, len(graded[level])), ""]
        for item in graded[level]:
            number += 1
            where = where_of(item)
            scope = ("（%s）" % item["scope"]
                     if item["scope"] and not item.get("同文條號") else "")
            lines += [
                "### %d. %s%s" % (number, where, scope), "",
                "> %s" % _quote(item["text"], 200), "",
                item["說明"] or "", "",
                "**→ %s**" % item["問句"], "",
                "- %d 路指到：%s" % (len(item["sources"]),
                                    "、".join(name for name in SOURCES
                                             if name in item["sources"])),
                "- 為什麼被列出來：%s" % item["為什麼被列出來"],
                "- 是否一併修改：☐ 要　☐ 不要　理由：____________", "",
            ]

    lines += ["---", "",
              "這份是輔助抓取的建議，**最終仍需人工複核後才能送出**。",
              "分級只是排序用的：3 路以上指到列為必須確認、2 路列為請再看一眼、",
              "1 路且字面 80 分以上也列進來。一路指到不代表沒事，四路指到也不代表一定要改。", ""]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("\n已產生複核清單（先看這份）：%s" % path)


def write_csv(items, path):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["優先序", "信心", "幾路指到", "哪幾路", "章節", "條號",
                         "段次", "條文", "發生了什麼", "要確認什麼",
                         "為什麼被列出來", "指向它的異動",
                         "是否一併修改（人工填寫）", "理由（人工填寫）"])
        for number, item in enumerate(items, 1):
            triggers = "；".join(
                "%s %s" % (t["條號"], t["摘要"] or t["型態"] or "有異動")
                for t in item["triggers"])
            writer.writerow([
                number, item["confidence"], len(item["sources"]),
                "、".join(name for name in SOURCES if name in item["sources"]),
                item["scope"], where_of(item),
                "、".join(str(n) for n in item.get("同文段次", []))
                or item["line_number"],
                item["text"], item["說明"], item["問句"],
                item["為什麼被列出來"], triggers, "", ""])
    print("已產生合併總表（用 Excel 逐筆勾選）：%s" % path)
