# -*- coding: utf-8 -*-
"""
Step 2.4　向量搜尋：用一個可稽核的向量空間找相關條文

--------------------------------------------------------------------------
先講清楚這跟當年被拿掉的「語意向量」不是同一件事
--------------------------------------------------------------------------
設計筆記裡記著，早期版本有一個用 sentence-transformers 的 Step 3，
因為三個理由被移除：裝不了（要 PyTorch 與可連外下載的模型）、說不出理由、
以及同義詞表能達到類似效果。那三個理由到今天都還成立，所以這一支
**不是把它加回來**。這裡的向量是自己算的，而且每一個維度都指得出來：

    維度一　字元 n-gram（2、3 字）   ── 字面重疊，跟 Step 2 同一個訊號
    維度二　概念標記                 ── 讀 修法概念詞庫.json，人工維護、看得懂
    維度三　數值型態槽位             ── 「期間類數字」「金額類數字」出現與否

權重用 TF-IDF，IDF 直接從**這份文件自己**算，不需要任何外部語料。
比對用餘弦相似度。整支只用標準函式庫，沒有模型檔、不連網路。

每一筆命中都會附「是哪幾個維度貢獻了分數、各佔幾成」。法遵場合要能回答
「為什麼系統認為這兩條相關」，這一支答得出來——這是它跟語意向量最大的差別。

--------------------------------------------------------------------------
那它到底補了 Step 2 的哪一塊
--------------------------------------------------------------------------
不要指望它解決「用詞完全換掉」。設計筆記裡量過，純 TF-IDF 字元 n-gram 在
那個案例上比純字面比對更差（34.3 分掉到 1.3 分），因為它一樣靠字元重疊。
那一塊還是同義詞表在扛。這一支真正補的是另外三件事：

1. **概念維度帶來的召回。** 字面對不上、但同屬「撤銷退費」的條文，
   靠概念維度還連得起來。這是 n-gram 做不到而詞庫做得到的部分。
2. **一份文件只算一次向量。** Step 2 是每個異動段落對全文重新算一次
   字串相似度；這裡的向量建好之後 Step 2.4 與 Step 2.6 共用，
   查一次是毫秒級的（1,199 段的內規實測建索引 0.09 秒、單次查詢 0.003 秒）。
3. **第二個獨立訊號。** 兩套引擎各自找，聯集起來給人看，並標明是誰找到的。
   兩邊都找到的那幾筆，可信度明顯比只有一邊找到的高。

--------------------------------------------------------------------------
外部向量（給有內部 embedding 服務的單位）
--------------------------------------------------------------------------
單位若已經有自己的 embedding 服務，可以離線把向量算好存成 JSONL，
用 --embeddings 帶進來，這支就改用那份向量算餘弦。**程式本身仍然不連網路**，
向量是你自己準備好的檔案。代價是那條路**指不出理由**，命中會標成
「外部向量（無法指出理由）」，人工複核時請自行判斷。

使用方式：
    python vector_search.py 新版.docx --query "撤銷後幾日內退費"
    python vector_search.py 新版.docx --from-csv 修正對照表.csv --outdir 產出
    python vector_search.py 新版.docx --from-csv 修正對照表.csv --embeddings 向量.jsonl
"""

import argparse
import csv
import json
import math
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, build_hierarchy,
                     strip_article_no, extract_article_no, format_scope,
                     load_synonyms, normalize_terms, load_concept_lexicon,
                     tag_concepts, concept_coverage, resolve_output)


# 門檻是餘弦值，跟 Step 2 的 0～100 分不是同一把尺，不要互相比較。
# 實測（驗收測資 24 段、以及 1,199 段的真實內規）：
#   同一件事寫在兩章      0.35 ~ 0.75
#   同主題但層級不同      0.18 ~ 0.35
#   不相干的兩條          0.02 ~ 0.12
# 門檻設 0.15，寧可多列幾筆讓人刪，也不要在抓漏的工具上漏掉。
DEFAULT_MIN_SCORE = 0.15
DEFAULT_TOP = 10

# 概念維度的權重。一段話會有幾百個 n-gram、卻只有兩三個概念，
# 不加權的話概念在餘弦裡幾乎沒有聲音。設 3.0 是實測出來的：
# 設 1.0 時概念完全被 n-gram 淹掉（驗收測資第四條對第七條的概念貢獻只有 4%）；
# 設 8.0 時只要概念一樣分數就衝到 0.6，同章不同層級的條文開始大量假陽性。
CONCEPT_WEIGHT = 3.0

# 數值槽位的權重。它只是一個「這條有沒有講期間／金額」的粗訊號，
# 給高權重會讓所有帶日期的條文互相黏在一起。
SLOT_WEIGHT = 1.5

_PUNCT = re.compile(r"[\s，。、；：？！（）()「」『』《》〈〉．·,.;:!?\"'\-—…　]+")

_PERIOD_UNITS = ("個營業日", "個工作日", "個月", "營業日", "工作日",
                 "日", "月", "年", "小時", "分鐘")
_MONEY_UNITS = ("億元", "萬元", "元")
_RATIO_UNITS = ("％", "%", "成", "倍")
_CN = "零〇一二三四五六七八九十百千萬兩"

_SLOT_RES = [
    ("數值:期間", re.compile(r"[%s\d][%s\d,．.]*\s*(?:%s)"
                             % (_CN, _CN, "|".join(_PERIOD_UNITS)))),
    ("數值:金額", re.compile(r"[%s\d][%s\d,．.]*\s*(?:%s)"
                             % (_CN, _CN, "|".join(_MONEY_UNITS)))),
    ("數值:比率", re.compile(r"[%s\d][%s\d,．.]*\s*(?:%s)"
                             % (_CN, _CN, "|".join(_RATIO_UNITS)))),
]


def _clean(text, synonyms=None):
    """剝條號、收斂同義詞、去標點空白。回傳 (乾淨字串, 用到的代表詞集合)。"""
    body = strip_article_no(text or "")
    applied = set()
    if synonyms:
        body, applied = normalize_terms(body, synonyms)
    return _PUNCT.sub("", body), applied


def tokenize(text, synonyms=None, lexicon=None, ngrams=(2, 3)):
    """
    把一段條文變成 {維度: 次數}。

    n-gram 取 2 與 3 字：中文沒有空白斷詞，2 字抓得到詞、3 字抓得到片語。
    只取 2 字太碎（「保人」「險費」這種切法在 Step 2 已經證實沒有辨識力），
    只取 3 字則對短句幾乎產不出維度。兩個一起取，短句長句都還有東西可比。
    """
    counts = {}
    body, _ = _clean(text, synonyms)

    for n in ngrams:
        for i in range(len(body) - n + 1):
            dim = "字:%s" % body[i:i + n]
            counts[dim] = counts.get(dim, 0) + 1

    # 概念維度用原文標，不用正規化後的字串——概念詞庫裡的觸發詞是照
    # 內規原本的寫法收的，套完同義詞之後反而對不上。
    for concept in tag_concepts(text or "", lexicon or {}):
        counts["概念:%s" % concept] = counts.get("概念:%s" % concept, 0) + 1

    for slot, pattern in _SLOT_RES:
        if pattern.search(text or ""):
            counts[slot] = counts.get(slot, 0) + 1

    return counts


def _dim_weight(dim):
    if dim.startswith("概念:"):
        return CONCEPT_WEIGHT
    if dim.startswith("數值:"):
        return SLOT_WEIGHT
    return 1.0


class Index(object):
    """
    全文的稀疏向量索引。

    刻意用 dict 存稀疏向量而不是 list 存稠密向量：一份內規的 n-gram 維度
    動輒好幾萬，稠密向量會是 1,199 × 幾萬個 float，純 Python 下記憶體與
    時間都不划算，而每一段其實只有幾百個非零維度。
    """

    def __init__(self, paragraphs, synonyms=None, lexicon=None, contexts=None):
        self.paragraphs = list(paragraphs)
        self.synonyms = synonyms or []
        self.lexicon = lexicon or {}
        self.contexts = contexts or build_hierarchy(self.paragraphs)
        self.doc_count = len(self.paragraphs)

        raw = [tokenize(p, self.synonyms, self.lexicon) for p in self.paragraphs]

        df = {}
        for counts in raw:
            for dim in counts:
                df[dim] = df.get(dim, 0) + 1
        self.df = df

        # 平滑過的 IDF。+1 是為了讓「每一段都有」的維度權重不會變成 0——
        # 變 0 會讓短句在只剩通用維度時整條向量歸零，連自己都比不出分數。
        self.idf = {dim: math.log((self.doc_count + 1.0) / (n + 1.0)) + 1.0
                    for dim, n in df.items()}

        self.vectors = [self._weigh(counts) for counts in raw]
        self.dimensions = len(self.idf)

    def _weigh(self, counts):
        """TF-IDF ＋ 維度加權 ＋ L2 正規化。"""
        vector = {}
        for dim, tf in counts.items():
            idf = self.idf.get(dim)
            if idf is None:
                continue        # 查詢裡有、全文裡沒有的維度，比不出東西
            # sublinear tf：同一個詞出現十次不代表重要十倍，
            # 長條文本來就會重複套語，不壓下來會被套語主導。
            vector[dim] = (1.0 + math.log(tf)) * idf * _dim_weight(dim)

        norm = math.sqrt(sum(v * v for v in vector.values()))
        if not norm:
            return {}
        return {dim: v / norm for dim, v in vector.items()}

    def vector_for(self, text):
        return self._weigh(tokenize(text, self.synonyms, self.lexicon))

    def search(self, text=None, vector=None, top=DEFAULT_TOP,
               min_score=DEFAULT_MIN_SCORE, exclude=(), only=None):
        """
        找出跟這段文字最像的條文。

        exclude：要排除的段次（通常是查詢自己那一段）。
        only：只在這些段次裡找（給「只找沒有異動的段落」用）。

        ------------------------------------------------------------------
        為什麼是逐段掃，不是倒排索引
        ------------------------------------------------------------------
        第一版寫的是倒排索引（維度 → 有這個維度的段落清單），照理說只走
        查詢命中的維度會比較快。實測是**反過來的**，而且差距不小：

            1,199 段    倒排 0.0102 秒 ／ 逐段 0.0031 秒
            4,796 段    倒排 0.0429 秒 ／ 逐段 0.0170 秒
           11,990 段    倒排 0.1172 秒 ／ 逐段 0.0422 秒

        原因是中文字元 n-gram 的詞彙量會飽和——文件從 1,199 段長到 11,990 段，
        維度數還是 2,123 個，等於每一條貼文串都跟著文件長度線性變長，
        倒排完全沒有「只看少數幾段」的效果，卻多付了走 tuple 與累加
        暫存 dict 的成本。所以改成逐段算餘弦，簡單而且快三倍。

        兩個實際有效的優化留著：
        一、走兩邊比較短的那個 dict，短句對長條文時省一半。
        二、維度貢獻只算給過門檻的那幾筆。全部算的話等於每一段都做兩次，
            而九成九的段落根本不會被列出來。
        """
        vector = vector if vector is not None else self.vector_for(text or "")
        if not vector:
            return []

        exclude = set(i for i in exclude if i is not None)
        candidates = range(len(self.vectors)) if only is None else only

        scored = []
        for index in candidates:
            if index in exclude:
                continue
            other = self.vectors[index]
            if not other:
                continue
            if len(vector) <= len(other):
                score = sum(weight * other[dim]
                            for dim, weight in vector.items() if dim in other)
            else:
                score = sum(weight * vector[dim]
                            for dim, weight in other.items() if dim in vector)
            if score >= min_score:
                scored.append((score, index))

        scored.sort(key=lambda pair: (-pair[0], pair[1]))
        hits = []
        for score, index in scored[:top]:
            other = self.vectors[index]
            parts = {dim: weight * other[dim]
                     for dim, weight in vector.items() if dim in other}
            hits.append(self._describe(index, score, parts))
        return hits

    def _describe(self, index, score, parts):
        context = self.contexts[index] if index < len(self.contexts) else {}
        return {
            "line_number": index + 1,
            "index": index,
            "text": self.paragraphs[index],
            "article_no": extract_article_no(self.paragraphs[index]),
            "scope": format_scope(context),
            "ref": context.get("ref", ""),
            "score": score,
            "why": explain(parts, score),
            "concepts": sorted(tag_concepts(self.paragraphs[index], self.lexicon)),
        }


def explain(parts, score, top=4):
    """
    把貢獻最大的維度整理成人看得懂的一句話。

    這是整支程式存在的前提。分數本身沒有用——法遵人員要的是
    「因為這兩條都講撤銷、都講退還、都帶期間數字」，這樣他才判斷得出來
    是真的漏改還是本來就該不一樣。給不出這句話的相似度演算法，
    在這個場合就是不能用。

    刻意先分三類講、再點名細節。只列個別維度會給錯印象：一段話有幾百個
    n-gram，每一個的佔比都是零點幾趴，排出來看起來像「概念佔了七成」，
    其實反過來。先把三類各自的總佔比講出來，才看得出這一筆到底是
    「字面本來就像」還是「字面不像但概念對上了」——後者才是這一支的價值。
    """
    if not score:
        return ""

    groups = {"字": 0.0, "概念": 0.0, "數值": 0.0}
    concepts, slots, grams = [], [], []
    for dim, part in sorted(parts.items(), key=lambda kv: kv[1], reverse=True):
        kind, _, label = dim.partition(":")
        if kind not in groups:
            continue
        groups[kind] += part
        if kind == "概念":
            concepts.append(label)
        elif kind == "數值":
            slots.append(label)
        else:
            grams.append(label)

    pieces = []
    if groups["字"]:
        detail = "、".join(grams[:top])
        pieces.append("字面重疊 %.0f%%%s"
                      % (groups["字"] / score * 100.0,
                         "（%s…）" % detail if detail else ""))
    if groups["概念"]:
        pieces.append("概念 %.0f%%（%s）"
                      % (groups["概念"] / score * 100.0, "、".join(concepts)))
    if groups["數值"]:
        pieces.append("同帶%s %.0f%%"
                      % ("、".join(slots), groups["數值"] / score * 100.0))
    return "；".join(pieces)


# ---------------------------------------------------------------------------
# 外部向量（可選）
# ---------------------------------------------------------------------------

class ExternalIndex(object):
    """
    用單位自己算好的 embedding 檔比對。**程式不連網路**，向量是使用者給的檔案。

    JSONL，一行一段，兩種對法擇一：
        {"index": 0, "vector": [...]}     依段次對齊（最穩，但檔案要跟著文件版本走）
        {"text": "第四條……", "vector": [...]}  依原文對齊（文件改一個字就對不上）

    這條路刻意做得很薄，而且**指不出理由**——那正是設計筆記裡把語意向量
    拿掉的第二個理由。留這個介面是因為有些單位確實已經有內部服務、
    也接受那個代價；預設路徑不是這一條。
    """

    def __init__(self, paragraphs, path, contexts=None, lexicon=None):
        self.paragraphs = list(paragraphs)
        self.contexts = contexts or build_hierarchy(self.paragraphs)
        self.lexicon = lexicon or {}
        self.vectors = self._load(path)

    def _load(self, path):
        by_index, by_text = {}, {}
        with open(path, encoding="utf-8") as f:
            for line_no, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except ValueError:
                    print("提醒：外部向量檔第 %d 行不是合法 JSON，已略過。" % line_no)
                    continue
                vector = record.get("vector") or record.get("embedding")
                if not isinstance(vector, list):
                    continue
                vector = _l2(vector)
                if isinstance(record.get("index"), int):
                    by_index[record["index"]] = vector
                elif isinstance(record.get("text"), str):
                    by_text[record["text"].strip()] = vector

        vectors = []
        missing = 0
        for i, text in enumerate(self.paragraphs):
            vector = by_index.get(i) or by_text.get(text.strip())
            if vector is None:
                missing += 1
            vectors.append(vector)

        got = len(self.paragraphs) - missing
        print("外部向量：%d/%d 段對得上。" % (got, len(self.paragraphs)))
        if missing:
            print("      對不上的 %d 段這次不會出現在向量結果裡。"
                  "依段次對齊（index）比依原文對齊穩，文件改過字就對不上原文。"
                  % missing)
        return vectors

    def vector_for(self, text):
        target = (text or "").strip()
        for i, paragraph in enumerate(self.paragraphs):
            if paragraph.strip() == target and self.vectors[i]:
                return self.vectors[i]
        return None

    def search(self, text=None, vector=None, top=DEFAULT_TOP,
               min_score=DEFAULT_MIN_SCORE, exclude=(), only=None):
        vector = vector if vector is not None else self.vector_for(text)
        if not vector:
            return []

        exclude = set(i for i in exclude if i is not None)
        allowed = None if only is None else set(only)

        hits = []
        for i, other in enumerate(self.vectors):
            if not other or i in exclude:
                continue
            if allowed is not None and i not in allowed:
                continue
            score = sum(a * b for a, b in zip(vector, other))
            if score < min_score:
                continue
            context = self.contexts[i] if i < len(self.contexts) else {}
            hits.append({
                "line_number": i + 1, "index": i, "text": self.paragraphs[i],
                "article_no": extract_article_no(self.paragraphs[i]),
                "scope": format_scope(context), "ref": context.get("ref", ""),
                "score": score, "why": "外部向量（無法指出理由）",
                "concepts": sorted(tag_concepts(self.paragraphs[i], self.lexicon)),
            })
        hits.sort(key=lambda h: h["score"], reverse=True)
        return hits[:top]


def _l2(vector):
    norm = math.sqrt(sum(float(v) * float(v) for v in vector))
    if not norm:
        return []
    return [float(v) / norm for v in vector]


# 章名、節名、文件標題這種段落跟每一條都沾一點邊——它們的字元 n-gram
# 幾乎是全文的公因數，不濾掉的話「○○銀行線上申辦作業要點」會出現在
# 每一份候選清單的前幾名，而它永遠不是漏改。
BODY_LEVELS = ("條", "項", "款", "目")


def body_indexes(index):
    """索引裡真正是條文的段次（排除章名、節名、標題）。"""
    return [i for i, context in enumerate(index.contexts)
            if context.get("level") in BODY_LEVELS]


def build_index(paragraphs, synonyms=None, lexicon=None, contexts=None,
                embeddings=None):
    """建索引的統一入口。有給 --embeddings 就走外部向量，否則走內建。"""
    if embeddings:
        if not os.path.exists(embeddings):
            print("提醒：找不到外部向量檔 %s，改用內建向量。" % embeddings)
        else:
            return ExternalIndex(paragraphs, embeddings, contexts, lexicon)
    return Index(paragraphs, synonyms=synonyms, lexicon=lexicon,
                 contexts=contexts)


def print_hits(query_label, hits, min_score=DEFAULT_MIN_SCORE):
    print("\n" + "-" * 66)
    print("查詢：%s" % (query_label[:60] + ("…" if len(query_label) > 60 else "")))
    if not hits:
        print("  沒有超過 %.2f 的相關條文。" % min_score)
        return
    for hit in hits:
        head = "  %.3f  %s" % (hit["score"], hit["ref"] or hit["article_no"] or
                               ("第 %d 段" % hit["line_number"]))
        if hit["scope"]:
            head += "（%s）" % hit["scope"]
        print(head)
        print("        %s" % hit["text"][:70])
        if hit["why"]:
            print("        相關的理由：%s" % hit["why"])


def write_csv(rows, output_path):
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["查詢來源條號", "查詢文字", "候選章節", "候選條號",
                         "候選段次", "候選條文", "餘弦相似度",
                         "相關的理由（維度貢獻）", "候選帶的概念",
                         "是否一併修改（人工填寫）"])
        for row in rows:
            writer.writerow(row)
    print("\n已產生向量搜尋結果：%s" % output_path)


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="Step 2.4　向量搜尋（可稽核，不用模型、不連網路）")
    parser.add_argument("new_file", help="要搜尋的內規全文（.docx / .txt / .md）")
    parser.add_argument("--query", action="append", default=[],
                        help="要找的內容，可以給多次")
    parser.add_argument("--from-csv", default=None,
                        help="讀 Step 1 的 修正對照表.csv，拿每個異動段落當查詢")
    parser.add_argument("--top", type=int, default=DEFAULT_TOP,
                        help="每個查詢最多列幾筆，預設 %d" % DEFAULT_TOP)
    parser.add_argument("--min-score", type=float, default=DEFAULT_MIN_SCORE,
                        help="餘弦門檻，預設 %.2f" % DEFAULT_MIN_SCORE)
    parser.add_argument("--embeddings", default=None,
                        help="外部向量 JSONL（單位自己算好的，程式不連網路）")
    parser.add_argument("--synonyms", default=None, help="同義詞表路徑")
    parser.add_argument("--no-synonyms", action="store_true")
    parser.add_argument("--concepts", default=None, help="修法概念詞庫路徑")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    paragraphs = read_paragraphs(args.new_file)
    synonyms = [] if args.no_synonyms else load_synonyms(args.synonyms)
    lexicon = load_concept_lexicon(args.concepts)

    counts, too_broad = concept_coverage(paragraphs, lexicon)
    if too_broad:
        print("提醒：這幾個概念在全文命中超過四成，沒有辨識力，本次不當搜尋條件：")
        for concept in too_broad:
            print("      %s（%d/%d 段）" % (concept, counts[concept], len(paragraphs)))
        lexicon = {c: w for c, w in lexicon.items() if c not in too_broad}

    index = build_index(paragraphs, synonyms, lexicon, embeddings=args.embeddings)
    print("已建索引：%d 段" % len(paragraphs))
    if isinstance(index, Index):
        print("      維度 %d 個（字元 n-gram ＋ 概念 ＋ 數值型態）" % index.dimensions)

    queries = [(None, q) for q in args.query]
    if args.from_csv:
        import fuzzy_duplicate_finder as fuzzy
        for change in fuzzy.load_changes_from_csv(args.from_csv):
            queries.append((change.get("article_no", ""), change["text"]))

    if not queries:
        parser.error("要給 --query 或 --from-csv，至少一個")

    rows = []
    for article_no, query in queries:
        exclude = [i for i, p in enumerate(paragraphs) if p.strip() == query.strip()]
        hits = index.search(query, top=args.top, min_score=args.min_score,
                            exclude=exclude, only=body_indexes(index))
        print_hits(query, hits, args.min_score)
        for hit in hits:
            rows.append([article_no or "", query, hit["scope"], hit["article_no"],
                         hit["line_number"], hit["text"], "%.3f" % hit["score"],
                         hit["why"], "、".join(hit["concepts"]), ""])

    if rows:
        write_csv(rows, resolve_output(args.outdir, args.prefix, "向量相似候選.csv"))
    print("\n共列出 %d 筆。這是輔助抓取的建議，最終仍需人工確認。" % len(rows))


if __name__ == "__main__":
    main()
