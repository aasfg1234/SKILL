# -*- coding: utf-8 -*-
"""
Step 2.5　修法概念抽取　＋　Step 2.6　概念漏改搜尋

--------------------------------------------------------------------------
這一步在回答什麼問題
--------------------------------------------------------------------------
Step 1 會告訴你「第四條的十五日改成三十日」。Step 1.6 會告訴你「這是數值變更，
去確認有沒有超過母法上限」。兩個都是**對著那一條**講話。

真正會出事的是另一個問題：**這次改的是什麼「概念」，全文還有哪幾條也帶著
同一個概念、卻沒有跟著改？** 驗收測資裡埋的第一個陷阱就是這個——第四條把
撤銷後的退費期限從十五日改成三十日，第七條講的是同一件事的電子通路版本，
沒改。兩條分屬不同章、通知方式不同，人逐條讀很容易滑過去。

Step 2 的模糊比對抓得到「字面很像」的那種漏改。抓不到的是字面不像、
但概念相同的那種——例如第三條「應親自簽名並出示身分證明文件」與第六條
「得完成身分驗證後辦理」，講的都是身分驗證，字面重疊只有 14%，
模糊比對的分數在門檻底下。這一步把它撈得回來。

--------------------------------------------------------------------------
怎麼做的（全部是規則，不是猜的）
--------------------------------------------------------------------------
Step 2.5　把每一處異動歸類成一種「修法型態」，並標上它動到的概念：

    期限變更    十五日 → 三十日            方向：延長／縮短
    金額變更    十萬元 → 二十萬元          方向：提高／降低
    比率變更    三成 → 五成
    責任強度    應 → 得                    方向：由強制改為裁量／反之
    用語替換    保險費 → 應繳金額          同義詞表認得，屬於改寫不是改實質
    名詞更動    總經理 → 董事會            同義詞表不認得，可能是權責移轉
    範圍適用    準用／適用／除外的增刪
    文字增刪    新增或刪除了一整段程序
    條文增刪    整條新增或整條刪除

Step 2.6　拿這些概念去 Step 2.4 的向量索引裡搜**沒有異動的段落**。
命中的就是「同一個概念，這次沒動」的條文清單。

--------------------------------------------------------------------------
刻意不做的事
--------------------------------------------------------------------------
不判斷「所以第七條應該要改」。程式看得到「兩條都在講撤銷退費、一條改了
一條沒改」，看不到的是本行是不是**刻意**讓兩個通路的退費期限不同。
真實內規實測過：整份文件到處是「並陳報主管覆核」，概念全部一樣，
但核准層級本來就該不同。所以這一步只列清單、附上理由，
判斷留給人——這跟 Step 2 的立場一致。

使用方式：
    python concept_extract.py 新版.docx --old 舊版.docx
    python concept_extract.py 新版.docx --old 舊版.docx --outdir 產出
"""

import argparse
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, build_hierarchy,
                     diff_runs, resolve_output, load_synonyms, normalize_terms,
                     load_concept_lexicon, tag_concepts, concept_coverage,
                     warn_if_versions_swapped)
import rule_checks
import vector_search


DEFAULT_GAP_TOP = 6
# 概念漏改用的門檻比 vector_search 預設的 0.15 高一些。
# 理由：這一步是「拿一整條去搜」，本來就比拿片語去搜容易得分，
# 0.15 在驗收測資上會把章名、要點名稱這種段落也撈進來。
# 實測 0.20 剛好濾掉那些又保住第三條對第六條那一筆（0.266）。
DEFAULT_GAP_MIN_SCORE = 0.20

# 每一種型態要提醒人去查證什麼。寫在這裡而不是散在程式裡，
# 是為了讓法遵單位一眼看得出這個工具會講哪些話、要改也改得動。
_ACTIONS = {
    "期限變更": "確認新期限沒有超過母法或主管機關規定的上下限，且相同性質的其他條文一致",
    "金額變更": "確認新金額的核決權限層級是否要跟著調整",
    "比率變更": "確認比率變更是否需要重新試算或報主管機關備查",
    "責任強度": "確認這是有意識的責任範圍調整，並在修正理由欄敘明",
    "用語替換": "同義詞表認得這組詞，屬於用語統一而非實質變更；確認全文都換了",
    "名詞更動": "可能是權責或主體移轉，確認相關條文的權責分工有沒有一起改",
    "範圍適用": "確認被準用／排除的條文本身這次有沒有改，以及改了之後準用還通不通",
    "文字增刪": "確認新增或刪除的程序在其他章節有沒有對應的規定要一起處理",
    "條文增刪": "確認交叉引用到這一條的其他條文，以及條號是否需要處理",
}


def _fragments(old_text, new_text, min_len=1):
    """回傳 (刪掉的字, 加上去的字)。責任用語只有一個字，min_len 不能設 2。"""
    runs = diff_runs(old_text or "", new_text or "")
    removed = "".join(t for k, t in runs if k == "delete")
    added = "".join(t for k, t in runs if k == "insert")
    return removed, added


def _numeric_concepts(result, kind_of):
    """數值類：期限／金額／比率。配對邏輯直接沿用 Step 1.6 的，不要有兩套。"""
    old_numbers = rule_checks._NUMBER_RE.findall(result["old_text"])
    new_numbers = rule_checks._NUMBER_RE.findall(result["new_text"])
    removed = [n for n in old_numbers if n not in new_numbers]
    added = [n for n in new_numbers if n not in old_numbers]
    if not removed and not added:
        return []

    pairs, leftover_removed, leftover_added = rule_checks._pair_by_unit(removed, added)
    found = []
    for old_value, new_value in pairs:
        found.append({
            "型態": kind_of(old_value),
            "摘要": "%s → %s" % (old_value, new_value),
            "舊值": old_value, "新值": new_value,
            "方向": _magnitude_direction(old_value, new_value, kind_of(old_value)),
        })
    for value in leftover_removed:
        found.append({"型態": kind_of(value), "摘要": "刪除 %s" % value,
                      "舊值": value, "新值": "", "方向": "刪除"})
    for value in leftover_added:
        found.append({"型態": kind_of(value), "摘要": "新增 %s" % value,
                      "舊值": "", "新值": value, "方向": "新增"})
    return found


_CN_VALUES = {"零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "三": 3, "四": 4,
              "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}


def _to_number(text):
    """
    中文數字轉阿拉伯數字，只求「比得出大小」，不求精確到每一種寫法。

    比不出來就回 None，上層會把方向留白。方向欄留白比寫錯方向好——
    「期限從三十日縮短為十五日」寫反了，複核的人會照著錯的方向去查母法。
    """
    digits = "".join(c for c in text if c.isdigit() or c in ".,")
    if digits:
        try:
            return float(digits.replace(",", ""))
        except ValueError:
            return None

    body = "".join(c for c in text if c in _CN_VALUES or c in "十百千萬")
    if not body:
        return None

    total, section, number = 0, 0, 0
    for char in body:
        if char in _CN_VALUES:
            number = _CN_VALUES[char]
        elif char == "十":
            section += (number or 1) * 10
            number = 0
        elif char == "百":
            section += (number or 1) * 100
            number = 0
        elif char == "千":
            section += (number or 1) * 1000
            number = 0
        elif char == "萬":
            total += (section + number) * 10000
            section = number = 0
    return float(total + section + number) or None


def _magnitude_direction(old_value, new_value, kind):
    old_number, new_number = _to_number(old_value), _to_number(new_value)
    if old_number is None or new_number is None or old_number == new_number:
        return ""
    up = new_number > old_number
    if kind == "期限變更":
        return "延長" if up else "縮短"
    if kind == "金額變更":
        return "提高" if up else "降低"
    return "調高" if up else "調低"


def _kind_of_number(value):
    if any(u in value for u in ("元",)):
        return "金額變更"
    if any(u in value for u in ("％", "%", "成", "倍")):
        return "比率變更"
    return "期限變更"


def _modal_concept(result):
    """
    責任強度。沿用 Step 1.6 的遮罩詞表，否則「應用程式」會被算成一個「應」。

    這裡跟 Step 1.6 有一處刻意不同：Step 1.6 算的是整段的增減量，
    第六條「應完成身分驗證後始得辦理」改成「得完成身分驗證後辦理」時，
    「得」在舊版的「始得」裡已經有一個，一加一減相抵，報出來變成
    「應 → （無）」——人看了不知道改成什麼。這一步改成按修改區塊配對：
    diff_runs 會把同一個區塊的刪除與新增排在一起，兩邊各自抓責任用語，
    就得到「應 → 得」，這才是要寫進修正理由欄的那句話。
    """
    runs = diff_runs(result["old_text"] or "", result["new_text"] or "")

    pairs, singles = [], []
    for i, (kind, text) in enumerate(runs):
        if kind == "delete":
            following = runs[i + 1] if i + 1 < len(runs) else ("", "")
            inserted = following[1] if following[0] == "insert" else ""
            gone, appeared = _modals_in(text), _modals_in(inserted)
            if gone and appeared:
                pairs.append((gone, appeared))
            elif gone or appeared:
                singles.append((gone, appeared))
        elif kind == "insert" and not (i and runs[i - 1][0] == "delete"):
            # 純粹多加了一句「應……」，沒有相對應的刪除
            appeared = _modals_in(text)
            if appeared:
                singles.append(([], appeared))

    # 同一個用語在別的區塊配對過，就是位置移動不是增刪。
    # 第六條「應完成……後始得辦理」改成「得完成……後辦理」實測會產生兩筆：
    # 配對到的「應 → 得」，加上尾巴刪掉「始得」造成的「得 → （無）」。
    # 後面那筆是同一個「得」被搬到前面去，報出來會讓人以為裁量權也被拿掉了。
    paired_terms = {t for gone, appeared in pairs for t in gone + appeared}
    for gone, appeared in singles:
        gone = [t for t in gone if t not in paired_terms]
        appeared = [t for t in appeared if t not in paired_terms]
        if gone or appeared:
            pairs.append((gone, appeared))

    if not pairs:
        return []

    found = []
    for gone, appeared in pairs:
        if gone == appeared:
            continue
        found.append({
            "型態": "責任強度",
            "摘要": "%s → %s" % ("、".join(gone) or "（無）",
                                "、".join(appeared) or "（無）"),
            "舊值": "、".join(gone), "新值": "、".join(appeared),
            "方向": rule_checks._strictness_direction(gone, appeared),
        })
    return found


def _modals_in(text):
    """這段文字裡出現的責任用語，長的優先（「必須」不要被拆成一個「須」）。"""
    masked = rule_checks.mask_decoys(text or "")
    found = []
    for term in sorted(rule_checks.MODAL_STRENGTH, key=len, reverse=True):
        while term in masked:
            found.append(term)
            masked = masked.replace(term, "○" * len(term), 1)
    return sorted(found, key=lambda t: -rule_checks.MODAL_STRENGTH[t])


_SCOPE_WORDS = ("準用", "適用", "不適用", "除外", "比照辦理", "自本要點施行之日")


def _scope_concept(result):
    removed, added = _fragments(result["old_text"], result["new_text"])
    gone = [w for w in _SCOPE_WORDS if w in removed]
    appeared = [w for w in _SCOPE_WORDS if w in added]
    if not gone and not appeared:
        return []
    return [{
        "型態": "範圍適用",
        "摘要": "%s → %s" % ("、".join(gone) or "（無）", "、".join(appeared) or "（無）"),
        "舊值": "、".join(gone), "新值": "、".join(appeared), "方向": "",
    }]


def _term_concept(result, synonyms):
    """
    用詞被換掉：同義詞表認得的算「用語替換」，不認得的算「名詞更動」。

    這兩件事的複核輕重差很多。「保險費」換成「應繳金額」是用語統一，
    看一下全文有沒有換乾淨就好；「總經理」換成「董事會」是權責移轉，
    整份內規的核決層級都可能要跟著動。混在一起講會讓人把後者當前者放過去。
    """
    removed, added = _fragments(result["old_text"], result["new_text"])
    removed, added = removed.strip(), added.strip()
    if len(removed) < 2 or len(added) < 2:
        return []
    # 數字改動已經由 _numeric_concepts 處理，這裡不要重覆報一次
    if any(c.isdigit() or c in "零〇一二三四五六七八九十百千萬兩" for c in removed + added):
        return []

    if synonyms:
        old_norm, _ = normalize_terms(removed, synonyms)
        new_norm, _ = normalize_terms(added, synonyms)
        if old_norm == new_norm:
            return [{"型態": "用語替換", "摘要": "%s → %s" % (removed, added),
                     "舊值": removed, "新值": added, "方向": "用語統一"}]

    if len(removed) > 12 or len(added) > 12:
        return []       # 太長就不是換詞，是改寫，交給「文字增刪」講
    return [{"型態": "名詞更動", "摘要": "%s → %s" % (removed, added),
             "舊值": removed, "新值": added, "方向": ""}]


def _text_concept(result, min_len=6):
    """整段程序被加上或拿掉。太短的不算——那是潤稿，不是修法。"""
    removed, added = _fragments(result["old_text"], result["new_text"])
    found = []
    if len(added.strip()) >= min_len:
        found.append({"型態": "文字增刪", "摘要": "新增「%s」" % added.strip()[:40],
                      "舊值": "", "新值": added.strip(), "方向": "新增"})
    if len(removed.strip()) >= min_len:
        found.append({"型態": "文字增刪", "摘要": "刪除「%s」" % removed.strip()[:40],
                      "舊值": removed.strip(), "新值": "", "方向": "刪除"})
    return found


def extract(results, lexicon, synonyms=None):
    """
    把 Step 1 的比對結果整理成修法概念清單。

    一處異動可以產出多筆概念——第六條同時改了責任用語與期限的話，
    那是兩件要分別複核的事，併成一筆會讓其中一件被忽略。
    """
    concepts = []
    for result in results:
        kind = result.get("type")
        if kind in ("unchanged", "renumbered"):
            continue

        text = result.get("new_text") or result.get("old_text") or ""
        # diff_compare 的 new_index 是「第幾段」，從 1 起算；
        # 向量索引吃的是 0 起算的段次。這裡沒轉會整整差一段——
        # 實測差一段的後果是「改到的那條沒被排除、真正沒改的那條被排除掉」，
        # 剛好把這一步最該找出來的東西弄丟，而畫面上看起來一切正常。
        line_no = result.get("new_index") or result.get("old_index")
        index = (line_no - 1) if isinstance(line_no, int) else None

        if kind in ("added", "deleted"):
            found = [{
                "型態": "條文增刪",
                "摘要": "整條%s" % ("新增" if kind == "added" else "刪除"),
                "舊值": result.get("old_text", "") if kind == "deleted" else "",
                "新值": result.get("new_text", "") if kind == "added" else "",
                "方向": "新增" if kind == "added" else "刪除",
            }]
        else:
            found = []
            found += _numeric_concepts(result, _kind_of_number)
            found += _modal_concept(result)
            found += _scope_concept(result)
            found += _term_concept(result, synonyms)
            if not found:
                found += _text_concept(result)

        tags = tag_concepts(text, lexicon)
        for item in found:
            item.update({
                "條號": result.get("ref", ""),
                "段次": line_no if isinstance(line_no, int) else "",
                "索引": index,
                "概念": sorted(tags),
                "概念證據": tags,
                "查詢文字": text,
                "原文": result.get("old_text", ""),
                "修改後": result.get("new_text", ""),
                "應查證": _ACTIONS.get(item["型態"], ""),
            })
        concepts += found
    return concepts


def find_gaps(concepts, index, changed_indexes, top=DEFAULT_GAP_TOP,
              min_score=DEFAULT_GAP_MIN_SCORE):
    """
    拿每一筆概念去搜「這次沒有異動」的段落。

    only= 只放沒動過的段次，是這一步的重點：搜到另一條也改過的條文沒有意義，
    那是 Step 1 已經列在對照表上的東西。這裡要的是「沒被改到卻可能要改」。

    同一個候選被多筆概念搜到時只留分數最高的那一筆，並把是哪幾處異動指向它
    一起記下來。被兩處異動同時指到的條文，漏改的可能性比只被指到一次的高，
    這個訊號不能在去重的時候弄丟。
    """
    if index is None:
        return []

    # 只搜真正的條文，而且只搜這次沒有動到的。搜到另一條也改過的沒有意義——
    # 那是 Step 1 已經列在對照表上的東西。
    changed = set(changed_indexes)
    unchanged = [i for i in vector_search.body_indexes(index) if i not in changed]
    best = {}
    for concept in concepts:
        query = concept.get("查詢文字") or ""
        if not query.strip():
            continue
        hits = index.search(query, top=top, min_score=min_score,
                            exclude=[concept.get("索引")], only=unchanged)
        for hit in hits:
            shared = sorted(set(concept["概念"]) & set(hit["concepts"]))
            if not shared:
                # 概念完全沒有交集就不是這一步要找的東西。純字面像的那種
                # Step 2 已經抓過了，這裡再列一次只是製造重複。
                continue
            key = hit["index"]
            record = best.get(key)
            if record is None or hit["score"] > record["相似度"]:
                record = {
                    "候選章節": hit["scope"], "候選條號": hit["article_no"],
                    "候選條號完整": hit["ref"], "候選段次": hit["line_number"],
                    "候選條文": hit["text"], "相似度": hit["score"],
                    "理由": hit["why"], "候選概念": hit["concepts"],
                    "指向來源": [],
                }
                best[key] = record
            record["指向來源"].append({
                "條號": concept["條號"], "型態": concept["型態"],
                "摘要": concept["摘要"], "共同概念": shared,
            })

    rows = sorted(best.values(), key=lambda r: r["相似度"], reverse=True)
    for row in rows:
        # 同一處異動可能經由不同型態的概念指到同一條，去掉重複的摘要
        seen, unique = set(), []
        for source in row["指向來源"]:
            key = (source["條號"], source["摘要"])
            if key not in seen:
                seen.add(key)
                unique.append(source)
        row["指向來源"] = unique
    return rows


def report(concepts):
    if not concepts:
        print("沒有抽出修法概念（這次沒有實質異動，或異動只是編號調整）。")
        return

    by_kind = {}
    for concept in concepts:
        by_kind.setdefault(concept["型態"], []).append(concept)

    print("共抽出 %d 筆修法概念，分成 %d 種型態：" % (len(concepts), len(by_kind)))
    for kind in sorted(by_kind, key=lambda k: -len(by_kind[k])):
        print("  %s %d 筆" % (kind, len(by_kind[kind])))

    for kind in sorted(by_kind, key=lambda k: -len(by_kind[k])):
        print("\n【%s】" % kind)
        for concept in by_kind[kind]:
            where = concept["條號"] or ("第 %s 段" % concept["段次"])
            direction = "（%s）" % concept["方向"] if concept["方向"] else ""
            print("  %s　%s%s" % (where, concept["摘要"], direction))
            if concept["概念"]:
                print("      這條在講：%s" % "、".join(concept["概念"]))
            if concept["應查證"]:
                print("      要查證：%s" % concept["應查證"])


def report_gaps(rows, min_score=DEFAULT_GAP_MIN_SCORE):
    print("\n" + "-" * 66)
    if not rows:
        print("沒有找到「同概念但這次沒改」的條文（門檻 %.2f）。" % min_score)
        print("這不代表沒有漏改——概念詞庫沒收到的主題就標不出來，"
              "Step 2 的字面比對仍然是主力。")
        return

    print("同概念但這次沒有改的條文，共 %d 筆（門檻 %.2f）：" % (len(rows), min_score))
    print("這是最容易被漏掉的一類。請逐筆判斷是「漏改」還是「本來就該不同」。\n")
    for row in rows:
        where = row["候選條號完整"] or row["候選條號"] or ("第 %d 段" % row["候選段次"])
        scope = "（%s）" % row["候選章節"] if row["候選章節"] else ""
        print("  %.3f  %s%s" % (row["相似度"], where, scope))
        print("        %s" % row["候選條文"][:70])
        for source in row["指向來源"]:
            print("        ← %s %s：%s（共同概念：%s）"
                  % (source["條號"], source["型態"], source["摘要"],
                     "、".join(source["共同概念"])))
        if row["理由"]:
            print("        相關的理由：%s" % row["理由"])
        if len(row["指向來源"]) > 1:
            print("        ※ 被 %d 處異動同時指到，優先看這一筆。"
                  % len(row["指向來源"]))


def write_csv(concepts, output_path):
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["條號", "段次", "修法型態", "摘要", "方向",
                         "舊值", "新值", "這條在講的概念", "概念命中的詞",
                         "原文", "修改後", "要查證什麼"])
        for concept in concepts:
            evidence = "；".join(
                "%s：%s" % (name, "、".join(words))
                for name, words in sorted(concept["概念證據"].items()))
            writer.writerow([
                concept["條號"], concept["段次"], concept["型態"],
                concept["摘要"], concept["方向"], concept["舊值"], concept["新值"],
                "、".join(concept["概念"]), evidence,
                concept["原文"], concept["修改後"], concept["應查證"]])
    print("\n已產生修法概念清單：%s" % output_path)


def write_gaps_csv(rows, output_path):
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["候選章節", "候選條號", "候選段次", "候選條文",
                         "餘弦相似度", "被幾處異動指到", "指向它的異動",
                         "共同概念", "相關的理由（維度貢獻）",
                         "是否一併修改（人工填寫）"])
        for row in rows:
            sources = "；".join(
                "%s %s：%s" % (s["條號"], s["型態"], s["摘要"])
                for s in row["指向來源"])
            shared = sorted({c for s in row["指向來源"] for c in s["共同概念"]})
            writer.writerow([
                row["候選章節"], row["候選條號完整"] or row["候選條號"],
                row["候選段次"], row["候選條文"], "%.3f" % row["相似度"],
                len(row["指向來源"]), sources, "、".join(shared),
                row["理由"], ""])
    print("已產生概念漏改候選：%s" % output_path)


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="Step 2.5 修法概念抽取　＋　Step 2.6 概念漏改搜尋")
    parser.add_argument("new_file", help="新版內規檔案（.docx / .txt / .md）")
    parser.add_argument("--old", required=True, help="舊版內規檔案")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    parser.add_argument("--concepts", default=None, help="修法概念詞庫路徑")
    parser.add_argument("--synonyms", default=None, help="同義詞表路徑")
    parser.add_argument("--no-synonyms", action="store_true")
    parser.add_argument("--gap-top", type=int, default=DEFAULT_GAP_TOP,
                        help="每筆概念最多搜幾條未異動條文，預設 %d" % DEFAULT_GAP_TOP)
    parser.add_argument("--gap-min-score", type=float,
                        default=DEFAULT_GAP_MIN_SCORE,
                        help="概念漏改的餘弦門檻，預設 %.2f" % DEFAULT_GAP_MIN_SCORE)
    parser.add_argument("--embeddings", default=None,
                        help="外部向量 JSONL（單位自己算好的，程式不連網路）")
    args = parser.parse_args()

    import diff_compare

    warn_if_versions_swapped(args.old, args.new_file)
    old_paragraphs = read_paragraphs(args.old)
    new_paragraphs = read_paragraphs(args.new_file)
    results = diff_compare.compare_paragraphs(old_paragraphs, new_paragraphs)

    synonyms = [] if args.no_synonyms else load_synonyms(args.synonyms)
    lexicon = load_concept_lexicon(args.concepts)
    if not lexicon:
        print("沒有可用的概念詞庫，這一步只會做型態分類，不做概念漏改搜尋。")

    counts, too_broad = concept_coverage(new_paragraphs, lexicon)
    if too_broad:
        print("提醒：這幾個概念在全文命中超過四成，沒有辨識力，本次不當搜尋條件：")
        for concept in too_broad:
            print("      %s（%d/%d 段）"
                  % (concept, counts[concept], len(new_paragraphs)))
        lexicon = {c: w for c, w in lexicon.items() if c not in too_broad}

    concepts = extract(results, lexicon, synonyms)
    report(concepts)

    produced = []
    if concepts:
        path = resolve_output(args.outdir, args.prefix, "修法概念清單.csv")
        write_csv(concepts, path)
        produced.append(path)

    if lexicon and concepts:
        index = vector_search.build_index(
            new_paragraphs, synonyms, lexicon,
            contexts=build_hierarchy(new_paragraphs), embeddings=args.embeddings)
        changed = [c["索引"] for c in concepts if isinstance(c.get("索引"), int)]
        rows = find_gaps(concepts, index, changed,
                         top=args.gap_top, min_score=args.gap_min_score)
        report_gaps(rows, args.gap_min_score)
        if rows:
            path = resolve_output(args.outdir, args.prefix, "概念漏改候選.csv")
            write_gaps_csv(rows, path)
            produced.append(path)

    if produced:
        print("\n產出檔案：")
        for path in produced:
            print("  %s" % path)
    print("\n提醒：這一步只列清單、不下結論。"
          "同概念不代表一定要一起改，最終仍需人工判斷。")
    return produced


if __name__ == "__main__":
    main()
