# -*- coding: utf-8 -*-
"""
自我檢查腳本：跑完整流程，逐項驗證結果是否符合預期。

用途：
- 剛拿到這個 skill 時，先跑一次確認環境沒問題
- 之後有人改了腳本，跑一次確認沒有改壞
- 換一台電腦、換一個 Python 版本時，確認行為一致

執行：
    python tests/selftest.py

全部通過 -> 印「全部通過」，結束代碼 0
有任何一項失敗 -> 印出「預期 vs 實際」，結束代碼 1
"""

import csv
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(os.path.dirname(HERE), "scripts")
sys.path.insert(0, SCRIPTS)
sys.path.insert(0, HERE)

from _common import (setup_console, read_paragraphs, build_hierarchy,
                     extract_article_no, read_docx_stdlib, strip_article_no)
import diff_compare
import fuzzy_duplicate_finder as fuzzy
import renumber
import rule_checks

OLD_FILE = os.path.join(HERE, "舊版_招攬及繳費作業要點.txt")
NEW_FILE = os.path.join(HERE, "新版_招攬及繳費作業要點.txt")

_failures = []
_passes = []


def check(label, expected, actual):
    """比對單項結果。相等就記一筆通過，否則記下預期與實際。"""
    if expected == actual:
        _passes.append(label)
        print("  [通過] %s" % label)
    else:
        _failures.append((label, expected, actual))
        print("  [失敗] %s" % label)
        print("         預期：%r" % (expected,))
        print("         實際：%r" % (actual,))


def check_true(label, condition, detail=""):
    check(label, True, bool(condition)) if not detail else check(
        "%s（%s）" % (label, detail), True, bool(condition))


def section(title):
    print("\n" + "=" * 62)
    print(title)
    print("=" * 62)


# ---------------------------------------------------------------------------
# 1. 條號辨識與剝除
# ---------------------------------------------------------------------------

def test_article_no():
    section("1. 條號辨識（extract_article_no / strip_article_no）")

    cases = [
        ("第五條 逾期未繳者，契約停止效力。", "第五條", "逾期未繳者，契約停止效力。"),
        ("第十二條之一 業務人員於網路招攬。", "第十二條之一", "業務人員於網路招攬。"),
        ("第三點 應行注意事項如下。", "第三點", "應行注意事項如下。"),
        ("一、 業務人員應出示登錄證。", "一、", "業務人員應出示登錄證。"),
        ("沒有條號的一整段說明文字。", "", "沒有條號的一整段說明文字。"),
    ]
    for text, expected_no, expected_body in cases:
        check("條號「%s」" % (expected_no or "（無）"), expected_no, extract_article_no(text))
        check("剝條號「%s」" % (expected_no or "（無）"), expected_body, strip_article_no(text))


# ---------------------------------------------------------------------------
# 2. 讀檔與編碼
# ---------------------------------------------------------------------------

def test_reading(workdir):
    section("2. 讀檔與編碼")

    old_paragraphs = read_paragraphs(OLD_FILE)
    new_paragraphs = read_paragraphs(NEW_FILE)
    check("舊版段落數", 20, len(old_paragraphs))
    check("新版段落數", 20, len(new_paragraphs))

    # Big5：台灣的內規純文字檔常見編碼，寫死 UTF-8 會直接爆
    big5_path = os.path.join(workdir, "big5內規.txt")
    with open(big5_path, "wb") as f:
        f.write("第一條 本要點依保險法訂定。\n第二條 要保人應繳納保險費。\n".encode("cp950"))
    check("Big5 檔讀得出來", ["第一條 本要點依保險法訂定。", "第二條 要保人應繳納保險費。"],
          read_paragraphs(big5_path))

    # UTF-8 帶 BOM：從 Excel 或記事本另存最常見的格式
    bom_path = os.path.join(workdir, "bom內規.txt")
    with open(bom_path, "wb") as f:
        f.write("第一條 本要點依保險法訂定。\n".encode("utf-8-sig"))
    check("UTF-8 BOM 檔不會殘留 BOM 字元", ["第一條 本要點依保險法訂定。"],
          read_paragraphs(bom_path))

    # 舊版 .doc 要明確擋下，不是丟出看不懂的錯誤
    doc_path = os.path.join(workdir, "舊格式.doc")
    open(doc_path, "wb").close()
    try:
        read_paragraphs(doc_path)
        check(".doc 被擋下", True, False)
    except SystemExit as exc:
        check(".doc 被擋下並提示轉檔", True, "另存新檔" in str(exc))


# ---------------------------------------------------------------------------
# 3. Step 1 精確比對（重點：條號不能錯位）
# ---------------------------------------------------------------------------

# 這份測試資料預期的完整比對結果。
# 總則章的三筆（修改/新增/修改 緊鄰）就是條號錯位的觸發條件，
# 舊版逐段硬配的寫法會把「第二條」錯配成「第一條之一」，這裡要驗證不會再發生。
EXPECTED_CHANGES = [
    ("第一條",    "修改", "3"),
    ("第一條之一", "新增", "4"),
    ("第二條",    "修改", "5"),
    ("第五條",    "修改", "9"),
    ("第六條",    "刪除", ""),
]


def read_change_rows(csv_path):
    """從對照表 CSV 讀出 (條號, 修改類型, 新版段次) 清單。"""
    with io.open(csv_path, encoding="utf-8-sig", newline="") as f:
        return [(r["條號"], r["修改類型"], r["新版段次"]) for r in csv.DictReader(f)]


def test_step1(workdir):
    section("3. Step 1 精確比對")

    outdir = os.path.join(workdir, "step1")
    old_paragraphs = read_paragraphs(OLD_FILE)
    new_paragraphs = read_paragraphs(NEW_FILE)
    results = diff_compare.compare_paragraphs(old_paragraphs, new_paragraphs)

    csv_path = os.path.join(outdir, "修正對照表.csv")
    os.makedirs(outdir)
    diff_compare.write_csv_report(results, csv_path)

    rows = read_change_rows(csv_path)
    check("差異筆數", len(EXPECTED_CHANGES), len(rows))
    check("條號／類型／段次 完全正確", EXPECTED_CHANGES, rows)

    # 沒改到的段落不能被誤報。舊版共 20 段，其中 4 段有動（第一條、第二條、
    # 第五條 三段修改 + 第六條刪除），所以未修改的應該剛好 16 段。
    unchanged = [r for r in results if r["type"] == "unchanged"]
    check("未修改段落數", 16, len(unchanged))

    # 財產保險章、網路投保章這次都沒動，不該出現在對照表裡
    changed_articles = {row[0] for row in rows}
    for article in ("第九條", "第十二條", "第十二條之一"):
        check("%s 未被誤報為修改" % article, False, article in changed_articles)

    return csv_path, outdir


def test_step1_docx(workdir, txt_csv_path):
    section("4. Step 1 讀 Word 檔的結果要跟讀純文字一致")

    docx_dir = os.path.join(workdir, "docx")
    os.makedirs(docx_dir)
    try:
        from docx import Document
    except ImportError:
        print("  [略過] 沒有安裝 python-docx，跳過 Word 檔測試")
        print("         要測請先執行：python scripts/check_env.py")
        return None, None

    # 最後一段刻意放進表格，驗證表格內的條文也讀得到（內規常把附表放表格）
    paths = {}
    for label, source in (("舊版", OLD_FILE), ("新版", NEW_FILE)):
        lines = read_paragraphs(source)
        document = Document()
        for line in lines[:-1]:
            document.add_paragraph(line)
        table = document.add_table(rows=1, cols=1)
        table.rows[0].cells[0].text = lines[-1]
        path = os.path.join(docx_dir, "%s.docx" % label)
        document.save(path)
        paths[label] = path

    check("Word 檔段落數（含表格內容）", 20, len(read_paragraphs(paths["新版"])))

    results = diff_compare.compare_paragraphs(
        read_paragraphs(paths["舊版"]), read_paragraphs(paths["新版"]))
    docx_csv = os.path.join(docx_dir, "修正對照表.csv")
    diff_compare.write_csv_report(results, docx_csv)
    check("Word 檔比對結果與純文字一致",
          read_change_rows(txt_csv_path), read_change_rows(docx_csv))

    # 紅字底線刪除線的 Word 檔要真的產得出來
    annotated = os.path.join(docx_dir, "標註版全文.docx")
    diff_compare.export_to_docx(results, annotated)
    check("標註版全文 Word 檔已產生", True, os.path.exists(annotated))

    table_docx = os.path.join(docx_dir, "修正對照表.docx")
    diff_compare.export_table_to_docx(results, table_docx, title="測試用修正對照表")
    check("修正對照表 Word 檔已產生", True, os.path.exists(table_docx))
    return table_docx, annotated


def marked_text(paragraph):
    """把 Word 段落還原成可比對的字串，新增標 [增...]、刪除標 [刪...]。"""
    pieces = []
    for run in paragraph.runs:
        if run.font.strike:
            pieces.append("[刪%s]" % run.text)
        elif run.font.underline:
            pieces.append("[增%s]" % run.text)
        else:
            pieces.append(run.text)
    return "".join(pieces)


def test_docx_marking(table_docx, annotated):
    section("5. Word 檔的紅字標示要落在「真正改掉的那幾個字」")

    if not table_docx:
        print("  [略過] 沒有安裝 python-docx")
        return

    from docx import Document

    document = Document(table_docx)
    check("對照表為橫式版面（原文與修改後要並排）", True,
          document.sections[0].page_width > document.sections[0].page_height)

    table = document.tables[0]
    check("表格列數（表頭 1 列 + 差異 5 列）", 6, len(table.rows))
    check("表頭欄位",
          ["序號", "章節", "條號", "修改類型", "原文", "修改後文字", "修改依據／理由"],
          [c.text for c in table.rows[0].cells])

    # 第一條只加了「一百十五年」五個字，就只該標這五個字，其餘維持黑字。
    # 舊寫法是整段刪掉再整段加回來，人得把兩行從頭讀到尾自己找差異。
    row = table.rows[1]
    check("條號欄", "第一條", row.cells[2].text)
    # 章節欄只放編號不放章名：Word 表格這一欄只有 3cm，放「第一章 總則」會逐列換行
    # 撐高整張表；條號本身已足以定位，章節只是給人快速掃描用的區塊標示。
    check("章節欄帶出所屬章", "第一章", row.cells[1].text)
    check("修改後文字只標真正新增的字",
          "第一條 本要點依保險法第一百四十八條之三及主管機關[增一百十五年]函釋訂定。",
          marked_text(row.cells[5].paragraphs[0]))
    check("原文欄不出現新增標記（該欄要讀得通）",
          "第一條 本要點依保險法第一百四十八條之三及主管機關函釋訂定。",
          marked_text(row.cells[4].paragraphs[0]))
    check("修改依據／理由留白給人工填", "", row.cells[6].text)

    # 整條刪除：原文欄整段刪除線，修改後欄註明已刪除
    deleted_row = table.rows[5]
    check("刪除的條文在原文欄整段標刪除線",
          "[刪第六條 業務人員不得為誇大不實之說明。]",
          marked_text(deleted_row.cells[4].paragraphs[0]))
    check("刪除的條文在修改後欄註明已刪除",
          "（無，此段落已刪除）", deleted_row.cells[5].text)

    # 標註版全文：同樣只標改動的字
    changed_lines = [marked_text(p) for p in Document(annotated).paragraphs
                     if "[增" in marked_text(p) or "[刪" in marked_text(p)]
    check("標註版全文有標記的段落數", 5, len(changed_lines))
    check("標註版全文的修改段落也只標改動處",
          "第五條 逾期未繳[增超過三十日]者，契約停止效力。",
          changed_lines[3])

    # 刪字（不是加字）的方向也要對，且兩欄各自都要讀得通
    runs = diff_compare.diff_runs(
        "第七條 業務人員應於招攬時親自出示登錄證及名片。",
        "第七條 業務人員應於招攬時出示登錄證。")
    check("刪字時原文欄標出被刪的字",
          "第七條 業務人員應於招攬時[刪親自]出示登錄證[刪及名片]。",
          "".join(("[刪%s]" % t if k == "delete" else t)
                  for k, t in runs if k != "insert"))
    check("刪字時修改後欄乾淨無標記",
          "第七條 業務人員應於招攬時出示登錄證。",
          "".join(t for k, t in runs if k != "delete"))


# ---------------------------------------------------------------------------
# 5. Step 2 跨章節重複條文（這個 skill 的核心價值）
# ---------------------------------------------------------------------------

def test_step2():
    section("6. Step 2 跨章節重複條文抓取")

    paragraphs = read_paragraphs(NEW_FILE)

    # 案例一：第五條被改了，但財產保險章的第九條(一模一樣)、
    #         網路投保章的第十二條(換句話說)都沒跟著改
    changed = "第五條 逾期未繳超過三十日者，契約停止效力。"
    candidates = fuzzy.find_duplicates(changed, paragraphs, exclude_index=9)
    found = {c["article_no"] for c in candidates}

    check("第五條→抓到財產險章第九條（一模一樣的漏改）", True, "第九條" in found)
    check("第五條→抓到網路投保章第十二條（換句話說的漏改）", True, "第十二條" in found)
    check("第五條→不會抓到自己", False, "第五條" in found)

    scores = {c["article_no"]: c["similarity"] for c in candidates}
    check_true("第九條分數高於第十二條（一模一樣的應該排前面）",
               scores.get("第九條", 0) > scores.get("第十二條", 0),
               "第九條 %.1f vs 第十二條 %.1f" % (scores.get("第九條", 0), scores.get("第十二條", 0)))

    # 最長共同片段是給人工分流用的：整條照抄的片段長，換句話說的片段短
    fragments = {c["article_no"]: c["fragment_len"] for c in candidates}
    check_true("第九條的共同片段比第十二條長",
               fragments.get("第九條", 0) > fragments.get("第十二條", 0),
               "第九條 %d 字 vs 第十二條 %d 字"
               % (fragments.get("第九條", 0), fragments.get("第十二條", 0)))

    # 案例二：第六條被整條刪掉，網路投保章的第十二條之一講同一件事，也該一併檢視
    deleted = "第六條 業務人員不得為誇大不實之說明。"
    deleted_found = {c["article_no"] for c in fuzzy.find_duplicates(deleted, paragraphs)}
    check("第六條（刪除）→抓到網路投保章第十二條之一", True, "第十二條之一" in deleted_found)

    # 舊門檻 70 會漏掉「換句話說」那一類，這裡驗證確實會漏，證明下修門檻是必要的
    at_old_threshold = {c["article_no"] for c in
                        fuzzy.find_duplicates(changed, paragraphs, threshold=70, exclude_index=9)}
    check("門檻 70 確實會漏掉第十二條（下修到 45 的理由）", False, "第十二條" in at_old_threshold)


def test_step2_from_csv(csv_path):
    section("7. Step 2 批次模式（--from-csv 一次跑完所有修改段落）")

    changes = fuzzy.load_changes_from_csv(csv_path)
    check("讀到的修改段落數", 5, len(changes))

    by_article = {c["article_no"]: c for c in changes}
    check("刪除的第六條有被納入比對", True, "第六條" in by_article)
    check("刪除段落取用的是原文",
          "第六條 業務人員不得為誇大不實之說明。", by_article["第六條"]["text"])
    check("刪除段落沒有新版段次（新版已無此段）", None, by_article["第六條"]["line_number"])
    check("第五條的新版段次", 9, by_article["第五條"]["line_number"])


# ---------------------------------------------------------------------------
# 7. 命令列介面
# ---------------------------------------------------------------------------

def run_cli(args, cwd):
    """執行腳本並回傳 (結束代碼, 輸出文字)。"""
    process = subprocess.Popen(
        [sys.executable] + args, cwd=cwd,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output, _ = process.communicate()
    return process.returncode, output.decode("utf-8", "replace")


def test_cli(workdir):
    section("8. 命令列介面")

    outdir = os.path.join(workdir, "cli")
    os.makedirs(outdir)

    code, output = run_cli(
        [os.path.join(SCRIPTS, "diff_compare.py"), OLD_FILE, NEW_FILE,
         "--outdir", outdir, "--prefix", "招攬要點"], workdir)
    check("Step 1 命令列結束代碼", 0, code)
    check("Step 1 加了 --prefix 的檔名",
          True, os.path.exists(os.path.join(outdir, "招攬要點_修正對照表.csv")))
    try:
        import docx  # noqa: F401
        for filename in ("招攬要點_修正對照表.docx", "招攬要點_標註版全文.docx"):
            check("命令列產出 %s" % filename,
                  True, os.path.exists(os.path.join(outdir, filename)))
    except ImportError:
        print("  [略過] 沒有安裝 python-docx，跳過 Word 檔產出檢查")

    code, output = run_cli(
        [os.path.join(SCRIPTS, "fuzzy_duplicate_finder.py"), NEW_FILE,
         "--from-csv", os.path.join(outdir, "招攬要點_修正對照表.csv"),
         "--outdir", outdir, "--prefix", "招攬要點"], workdir)
    check("Step 2 命令列結束代碼", 0, code)
    check("Step 2 候選清單已產生",
          True, os.path.exists(os.path.join(outdir, "招攬要點_重複條文候選清單.csv")))
    check("Step 2 有列出第九條", True, "第九條" in output)
    check("Step 2 有列出第十二條", True, "第十二條" in output)

    # --changed-line：段次超出範圍要給看得懂的錯誤，不是丟 IndexError
    code, output = run_cli(
        [os.path.join(SCRIPTS, "fuzzy_duplicate_finder.py"), NEW_FILE,
         "--changed-line", "999"], workdir)
    check("--changed-line 超出範圍會擋下", True, "超出範圍" in output)

    # 三個指定方式都沒給時，要告訴使用者怎麼做，不是丟 traceback
    code, output = run_cli(
        [os.path.join(SCRIPTS, "fuzzy_duplicate_finder.py"), NEW_FILE], workdir)
    check("沒指定修改段落時給出用法說明", True, "--from-csv" in output)
    check("沒指定修改段落時不會噴 traceback", False, "Traceback" in output)

    # Step 3 沒裝套件時必須「正常結束」，不能讓整個流程中斷
    code, output = run_cli(
        [os.path.join(SCRIPTS, "embedding_similarity.py"), NEW_FILE,
         "--from-csv", os.path.join(outdir, "招攬要點_修正對照表.csv")], workdir)
    check("Step 3 結束代碼為 0（不中斷流程）", 0, code)
    try:
        import sentence_transformers  # noqa: F401
        check("Step 3 已安裝套件，有產出結果", True, "語意比對完成" in output)
    except ImportError:
        check("Step 3 未安裝套件時明確告知被跳過", True, "本次跳過" in output)


# ---------------------------------------------------------------------------



# ---------------------------------------------------------------------------
# 9. 大型內規（約 50 頁，含 章／節／條／款／目 完整層級）
# ---------------------------------------------------------------------------

def test_large_document(workdir):
    section("9. 大型內規：約 50 頁，章／節／條／款／目 完整層級")

    import make_large_fixture

    outdir = os.path.join(workdir, "large")
    rng_seeded = make_large_fixture.random.Random(make_large_fixture.SEED)
    old_lines, index = make_large_fixture.build_document(rng_seeded)
    duplicates = make_large_fixture.seed_duplicates(old_lines, index)
    new_lines, plants = make_large_fixture.plant_changes(old_lines, index, duplicates)

    total_chars = sum(len(line) for line in old_lines)
    pages = total_chars / 900.0
    check_true("文本規模達 50 頁量級", 45 <= pages <= 60,
               "%d 段 / %d 字 / 約 %.0f 頁" % (len(old_lines), total_chars, pages))

    levels = {}
    for context in build_hierarchy(old_lines):
        levels[context["level"]] = levels.get(context["level"], 0) + 1
    for level in ("章", "節", "條", "項", "款", "目"):
        check_true("文本含有「%s」層級" % level, levels.get(level, 0) > 0,
                   "%d 段" % levels.get(level, 0))

    # --- Step 1：對照表的每一列都要對得上埋伏清單 ---
    started = time.time()
    results = diff_compare.compare_paragraphs(old_lines, new_lines)
    elapsed = time.time() - started
    check_true("比對 1200 段在 10 秒內完成", elapsed < 10, "實際 %.2f 秒" % elapsed)

    os.makedirs(outdir)
    csv_path = os.path.join(outdir, "修正對照表.csv")
    diff_compare.write_csv_report(results, csv_path)

    with io.open(csv_path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    by_type = {}
    for row in rows:
        by_type.setdefault(row["修改類型"], []).append(row)
    check("差異筆數（5 組埋伏共 7 處異動）", 7, len(rows))
    check("其中修改 5 筆", 5, len(by_type.get("修改", [])))
    check("其中新增 1 筆", 1, len(by_type.get("新增", [])))
    check("其中刪除 1 筆", 1, len(by_type.get("刪除", [])))

    refs = [row["條號"] for row in rows]
    plants_by_type = {plant["類型"]: plant for plant in plants}

    # 埋伏 2：條號錯位。修改→新增→修改 三段緊鄰，條號不能整串跑掉
    misalign = plants_by_type["條號錯位觸發"]
    for label, key in (("修改", "修改"), ("新增", "新增"), ("後續修改", "後續修改")):
        check("條號錯位埋伏的%s（%s）有正確列出" % (label, misalign[key]),
              True, misalign[key] in refs)

    # 埋伏 3、4：款目層級。這是 50 頁文本才會現形的問題——
    # 「(二)」單獨寫在條號欄毫無意義，全文有幾百個「(二)」，
    # 必須還原成「第三十三條第二款第二目」才找得到。
    clause_plant = plants_by_type["款層級修改"]
    item_plant = plants_by_type["目層級修改"]
    clause_row = next((r for r in rows if r["修改後文字"] == clause_plant["修改後文字"]), None)
    item_row = next((r for r in rows if r["修改後文字"] == item_plant["修改後文字"]), None)

    check_true("款層級的修改有列出", clause_row is not None)
    check_true("目層級的修改有列出", item_row is not None)
    if clause_row:
        check("款的條號還原出所屬條",
              True, clause_row["條號"].startswith(clause_plant["所屬條"]))
        check("款的條號含款次", True, "款" in clause_row["條號"])
        check("款不會只寫成「二、」", False, clause_row["條號"] in ("二、", "二"))
        check("款帶出所屬章節", clause_plant["所屬節"].split()[0],
              clause_row["章節"].split()[-1])
    if item_row:
        check("目的條號還原出所屬條",
              True, item_row["條號"].startswith(item_plant["所屬條"]))
        check("目的條號含款次與目次",
              True, "款" in item_row["條號"] and "目" in item_row["條號"])
        check("目不會只寫成「(二)」", False, item_row["條號"] in ("(二)", "（二）"))

    # 埋伏 5：整條刪除
    delete_plant = plants_by_type["整條刪除"]
    check("刪除的條有列出", True, delete_plant["條號"] in refs)

    # --- Step 2：跨章重複要抓到另外兩章那兩條 ---
    duplicate_plant = plants_by_type["跨章重複漏改"]
    changed_row = next(r for r in rows if r["條號"] == duplicate_plant["已修改"])
    contexts = build_hierarchy(new_lines)
    candidates = fuzzy.find_duplicates(
        changed_row["修改後文字"], new_lines,
        exclude_index=int(changed_row["新版段次"]), contexts=contexts)

    expected_duplicates = [t["條號"] for t in duplicate_plant["應一併檢視"]]
    top_two = [c["article_no"] for c in candidates[:2]]
    check("跨章重複的兩條排在候選前兩名", sorted(expected_duplicates), sorted(top_two))
    for candidate in candidates[:2]:
        check("%s 的共同片段從句首開始" % candidate["article_no"],
              "句首", candidate["fragment_position"])

    # 這份文本的條文大量共用句尾套語（「…；但金額未達新臺幣十萬元者…」），
    # 會製造出共同片段比真重複還長的假陽性。驗證「片段起點」這個訊號分得開。
    all_candidates = []
    for row in rows:
        text = row["原文"] if row["修改類型"] == "刪除" else row["修改後文字"]
        line_no = int(row["新版段次"]) if row["新版段次"].isdigit() else None
        all_candidates.extend(fuzzy.find_duplicates(
            text, new_lines, exclude_index=line_no, contexts=contexts))

    non_head = [c for c in all_candidates if c["fragment_position"] != "句首"]
    truly_duplicated = set(expected_duplicates)
    check_true("候選數量在可人工消化的範圍", len(all_candidates) <= 120,
               "%d 筆" % len(all_candidates))
    check_true("非句首的候選裡沒有任何一筆是真的重複",
               all(c["article_no"] not in truly_duplicated for c in non_head),
               "非句首 %d 筆全為套語假陽性" % len(non_head))


# ---------------------------------------------------------------------------
# 10. 刪掉一款之後的編號重編與交叉引用
# ---------------------------------------------------------------------------

# 一條四款，第二款被刪掉。第六條刻意寫「前條第二款」，
# 這個引用在刪除後會指到不同的東西 —— 這是本組測試的重點。
RENUM_OLD = [
    "第一章 總則",
    "第五條 要保人申請契約變更時，應檢附下列文件：",
    "一、身分證明文件影本。",
    "二、原保險單正本。",
    "三、契約變更申請書。",
    "四、法定代理人同意書。",
    "第六條 前條第二款文件無法提出者，應出具切結書。",
]
# 使用者刪掉第二款，但沒有重編 —— 剩下 一、三、四
RENUM_NEW_RAW = [p for p in RENUM_OLD if p != "二、原保險單正本。"]
# 使用者刪掉第二款，而且自己先重編過 —— 表面上完全乾淨
RENUM_NEW_TIDY = [
    "第一章 總則",
    "第五條 要保人申請契約變更時，應檢附下列文件：",
    "一、身分證明文件影本。",
    "二、契約變更申請書。",
    "三、法定代理人同意書。",
    "第六條 前條第二款文件無法提出者，應出具切結書。",
]


def test_renumber():
    section("10. 刪掉一款之後：編號重編與交叉引用")

    # --- 情況一：使用者沒有重編，編號斷成 一、三、四 ---
    entries = renumber.scan(RENUM_NEW_RAW)
    problems = renumber.find_numbering_gaps(entries)
    check("偵測到編號不連續", 1, len(problems))
    if problems:
        check("指出目前的編號", [1, 3, 4], problems[0]["written"])
        check("指出應有的編號", [1, 2, 3], problems[0]["expected"])

    changes, clause_map, item_map = renumber.plan_renumber(RENUM_NEW_RAW, entries)
    check("要重編的段落數", 2, len(changes))
    check("第三款改為第二款", (3, 2), (changes[0]["old"], changes[0]["new"]))
    check("第四款改為第三款", (4, 3), (changes[1]["old"], changes[1]["new"]))

    references = renumber.scan_references(
        RENUM_NEW_RAW, entries, clause_map, item_map)
    dangerous = [r for r in references if r["status"] == "危險"]
    check("引用到已刪除的款被標為危險", 1, len(dangerous))
    if dangerous:
        check("標出是哪一段", 6, dangerous[0]["index"])
        check("標出引用的字句", "前條第二款", dangerous[0]["quote"])

    applied = renumber.apply_changes(
        RENUM_NEW_RAW, changes, references, rewrite_refs=True)
    check("重編後的款編號正確",
          ["一、身分證明文件影本。", "二、契約變更申請書。", "三、法定代理人同意書。"],
          applied[2:5])
    # 引用到已刪除款目的地方，即使開了 --rewrite-refs 也絕對不能自動改。
    # 法規的交叉引用指錯，比編號斷掉嚴重得多，這種判斷必須是人做的。
    check("開了 --rewrite-refs 也不會動引用到已刪除款目的句子",
          "第六條 前條第二款文件無法提出者，應出具切結書。", applied[-1])

    # --- 情況二：使用者已自行重編，表面完全乾淨 ---
    tidy_entries = renumber.scan(RENUM_NEW_TIDY)
    check("已重編的版本查不出編號問題", 0,
          len(renumber.find_numbering_gaps(tidy_entries)))
    tidy_changes, _, _ = renumber.plan_renumber(RENUM_NEW_TIDY, tidy_entries)
    check("已重編的版本沒有要重編的段落", 0, len(tidy_changes))

    # 光看新版看不出問題，一定要比對舊版才抓得到「同一個編號指到不同東西」
    drift = renumber.scan_reference_drift(RENUM_OLD, RENUM_NEW_TIDY)
    check("抓到編號沒變但指到的內容變了", 1, len(drift))
    if drift:
        check("列出舊版指的是什麼", "原保險單正本。", drift[0]["old_body"])
        check("列出新版指的是什麼", "契約變更申請書。", drift[0]["new_body"])

    # --- 條號預設不重編（法制慣例：保留條號並註記「（刪除）」）---
    old_articles = ["第五條 甲。", "第六條 乙。", "第七條 丙。"]
    new_articles = ["第五條 甲。", "第七條 丙。"]
    check("找出被整條刪掉的條號", ["第六條"],
          renumber.find_deleted_articles(old_articles, new_articles))
    check("條號本身不會被自動重編", 0,
          len(renumber.plan_renumber(new_articles, renumber.scan(new_articles))[0]))


def test_renumber_in_report():
    section("11. 對照表要把「純編號調整」和實質修改分開")

    results = diff_compare.compare_paragraphs(RENUM_OLD, RENUM_NEW_TIDY)
    by_type = {}
    for r in results:
        by_type[r["type"]] = by_type.get(r["type"], 0) + 1

    # 實質異動只有一筆（刪掉第二款）；另外兩段內容一個字沒動，只是編號往前遞補。
    # 不分開的話，50 頁的內規刪幾個款就會被幾十筆編號位移灌爆對照表。
    check("實質刪除 1 筆", 1, by_type.get("deleted", 0))
    check("純編號調整 2 筆", 2, by_type.get("renumbered", 0))
    check("不會有任何一筆被誤判為實質修改", 0, by_type.get("modified", 0))

    renumbered = [r for r in results if r["type"] == "renumbered"]
    check("編號調整的內容確實完全相同",
          [True, True],
          [diff_compare.strip_article_no(r["old_text"])
           == diff_compare.strip_article_no(r["new_text"]) for r in renumbered])
    check("對照表的類型欄寫「編號調整」", "編號調整",
          diff_compare.TYPE_LABELS["renumbered"])


# ---------------------------------------------------------------------------
# 12. 交叉引用的各種寫法
# ---------------------------------------------------------------------------

# 內規的引用寫法遠不只「第五條第二款」。每一種漏掉，就是一處指錯的引用
# 送進正式修法文件，所以每一種都要有測試盯著。
REF_OLD = [
    "第五條 要保人應檢附下列文件：",
    "一、身分證明文件影本。",
    "二、原保險單正本。",
    "三、契約變更申請書。",
    "四、法定代理人同意書。",
    "第十條 本公司應辦理下列事項：",
    "一、受理登錄。",
    "二、初步審查。",
    "三、核定。",
    "四、通知。",
    "第二十條 依第五條第四款及第十條第四款規定辦理。",
    "第二十一條 第五條第三款至第四款所定文件，保存五年。",
    "第二十二條 本公司得依第五條各款規定要求補正。",
    "第二十三條 業務人員應依前款規定辦理覆核。",
    "第二十四條 依第五條第二款規定辦理者，應另行陳報。",
    "第三十條 本要點自發布日施行。",
    "第三十一條 前開事項依第三十條規定辦理。",
]
# 刪掉第五條第二款，且沒有重編（剩 一、三、四）
REF_NEW = [p for p in REF_OLD if p != "二、原保險單正本。"]


def _reference_findings(paragraphs):
    entries = renumber.scan(paragraphs)
    _, clause_map, item_map = renumber.plan_renumber(paragraphs, entries)
    known = {c["article"] for c in build_hierarchy(paragraphs)
             if c["level"] == "條" and c["article"]}
    return renumber.scan_references(paragraphs, entries, clause_map, item_map,
                                    known_articles=known)


def test_reference_forms():
    section("12. 交叉引用的各種寫法")

    findings = _reference_findings(REF_NEW)
    by_index = {}
    for finding in findings:
        by_index.setdefault(finding["index"], []).append(finding)

    # 「第五條第四款及第十條第四款」──「及」後面的引用不會延用前面的條，
    # 但也不能被當成本條的款。兩個「第四款」分屬不同條，判定必須各自獨立。
    row = by_index.get(10, [])
    rewritable = [f for f in row if f["status"] == "需改寫"]
    check("『及』連接的兩個引用只有第五條那個要改", 1, len(rewritable))
    if rewritable:
        # 報告顯示的字句帶範圍前綴（「第五條第四款」），但改寫只換號碼那一段，
        # 否則會變成「第五條第五條第三款」
        check("報告顯示完整引用字句", "第五條第四款", rewritable[0]["quote"])
        check("改寫只換號碼那一段", "第三款", rewritable[0]["new_quote"])
    check("第十條第四款沒被誤判", 0,
          len([f for f in row if f["status"] in ("危險", "無法判定")]))

    # 範圍寫法：第三款至第四款 → 重編後是第二款至第三款，仍然連續，可機械改寫
    range_row = [f for f in by_index.get(11, []) if f["status"] == "需改寫"]
    check("範圍引用合併成一筆", 1, len(range_row))
    if range_row:
        check("範圍引用的原文", "第三款至第四款", range_row[0]["quote"])
        check("範圍引用改寫兩端", "第二款至第三款", range_row[0]["new_quote"])

    # 「各款」指全部，重編不影響，不該產生雜訊
    check("「各款」不會被報成問題", [], by_index.get(12, []))

    # 「前款」出現在沒有款的條裡 —— 解析不出來就要說解析不出來，不能默默跳過
    unresolved = [f for f in by_index.get(13, []) if f["status"] == "無法判定"]
    check("「前款」在沒有款的條裡會被標為無法判定", 1, len(unresolved))

    # 純條層級的引用，只要那一條還在就不該有雜訊
    check("「依第三十條規定」不會被報成問題", [], by_index.get(16, []))

    # 被刪掉的那一款，任何形式的引用都要抓到
    deleted_refs = [f for f in findings
                    if f["status"] == "危險" and "第二款" in f["note"]]
    check_true("引用到已刪除的第二款會被標為危險", len(deleted_refs) >= 1,
               "%d 筆" % len(deleted_refs))


def test_reference_rewrite_precision():
    section("13. 引用改寫要改對位置")

    entries = renumber.scan(REF_NEW)
    changes, clause_map, item_map = renumber.plan_renumber(REF_NEW, entries)
    findings = _reference_findings(REF_NEW)
    applied = renumber.apply_changes(REF_NEW, changes, findings, rewrite_refs=True)

    # 同一段裡有兩個「第四款」，只有第五條那個該改。
    # 用字串比對取代會改到第一個出現的，所以改寫一定要用位置。
    check("同段有兩個「第四款」時只改對的那一個",
          "第二十條 依第五條第三款及第十條第四款規定辦理。",
          applied[9])
    check("範圍引用兩端一起改",
          "第二十一條 第五條第二款至第三款所定文件，保存五年。",
          applied[10])
    check("款本身的編號也重編正確",
          ["一、身分證明文件影本。", "三、契約變更申請書。", "四、法定代理人同意書。"],
          REF_NEW[1:4])
    check("重編後的款編號",
          ["一、身分證明文件影本。", "二、契約變更申請書。", "三、法定代理人同意書。"],
          applied[1:4])
    check("第十條的款完全沒被動到",
          ["一、受理登錄。", "二、初步審查。", "三、核定。", "四、通知。"],
          applied[5:9])


def test_deleted_article_reference():
    section("14. 引用到被整條刪除的條")

    old = ["第五條 甲事項規定如下。",
           "第六條 乙事項規定如下。",
           "第七條 本公司辦理前開事項，應依第六條規定辦理。"]
    new = [p for p in old if not p.startswith("第六條")]

    check("找出被刪掉的條號", ["第六條"], renumber.find_deleted_articles(old, new))

    findings = _reference_findings(new)
    dangerous = [f for f in findings if f["status"] == "危險"]
    check("引用到不存在的條會被標為危險", 1, len(dangerous))
    if dangerous:
        check("指出是哪一條不見了", True, "第六條" in dangerous[0]["note"])

    # 即使開了 --rewrite-refs，指向已刪除條號的引用也不能自動改
    entries = renumber.scan(new)
    changes, _, _ = renumber.plan_renumber(new, entries)
    applied = renumber.apply_changes(new, changes, findings, rewrite_refs=True)
    check("--rewrite-refs 不會動指向已刪除條號的引用", new, applied)


# ---------------------------------------------------------------------------
# 15. 條文品質與風險檢查（十項）
# ---------------------------------------------------------------------------

QC_OLD = [
    "第一章 總則",
    "第一條 本要點依保險法第一百四十八條之三及金融消費者保護法第七條訂定。",
    "第二條 本要點所稱網路投保，指要保人經由本公司網站投保之行為。",
    "第三條 業務人員招攬時，應主動出示登錄證。",
    "第四條 本公司應於收齊文件之次日起十五日內完成核保。",
    "第五條 要保人不得以他人名義投保。",
    "第六條 保險費逾期未繳超過三十日者，契約停止效力。",
    "第七條 網路投保案件之處理，詳如附表一。",
    "第八條 本要點自發布日施行。",
]
QC_NEW = [
    "第一章 總則",
    "第一條 本要點依保險法第一百四十八條之三及金融消費者保護法第七條訂定。",
    "第二條 本要點所稱網路投保，指要保人經由本公司網站或行動應用程式投保之行為。",
    "第三條 業務員招攬時，得主動出示登錄證。",
    "第四條 本公司應於收齊文件之次日起三十日內完成核保。",
    "第五條 要保人得以他人名義投保。",
    "第五條 投保人須於契約撤銷期間內以書面通知。",
    "第七條 網路投保案件之處理，詳如附表一。",
    "(一)相關表單待補。",
    "第八條 本要點自發布日施行。",
]


def _qc(with_old=True):
    results = diff_compare.compare_paragraphs(QC_OLD, QC_NEW) if with_old else []
    findings = []
    findings += rule_checks.check_article_integrity(QC_NEW)
    findings += rule_checks.check_external_refs(QC_NEW)
    findings += rule_checks.check_placeholders(QC_NEW)
    findings += rule_checks.check_term_consistency(QC_NEW)
    findings += rule_checks.check_attachments(QC_NEW)
    findings += rule_checks.check_definitions(QC_NEW, results)
    if with_old:
        findings += rule_checks.check_modal_changes(results)
        findings += rule_checks.check_numeric_changes(results)
        findings += rule_checks.check_effective_date(QC_NEW, results)
    return findings


def _of(findings, check):
    return [f for f in findings if f["check"] == check]


def test_rule_checks():
    section("15. 條文品質與風險檢查（十項）")

    findings = _qc()

    # --- 責任用語：應→得 是鬆綁，屬於實質變更，必須被凸顯 ---
    modal = _of(findings, "責任用語變更")
    check("責任用語變更抓到 1 筆", 1, len(modal))
    if modal:
        check("判定為鬆綁", True, "鬆綁" in modal[0]["detail"])
        check("列為高風險", "高", modal[0]["severity"])
        check("指出是第三條", "第三條", modal[0]["ref"])

    # 「或行動應用程式」裡的「應」是「應用程式」的一部分，不是責任用語。
    # 中文沒有空白斷詞，不遮掉複合詞的話這裡會誤報成「新增了一個應」。
    check("「應用程式」不會被誤判成責任用語「應」",
          [], [f for f in modal if f["ref"] == "第二條"])

    # --- 數值期間：十五日→三十日 ---
    numeric = _of(findings, "數值期間變更")
    check("數值變更抓到 1 筆", 1, len(numeric))
    if numeric:
        check("正確配成一組", "十五日 → 三十日", numeric[0]["detail"])
        check("指出是第四條", "第四條", numeric[0]["ref"])

    # --- 條號健全性 ---
    check("抓到條號重複", 1, len(_of(findings, "條號重複")))
    check("抓到條號跳號", 1, len(_of(findings, "條號跳號")))

    # --- 定義連動：改了定義，用到這個詞的條文要一起看 ---
    linked = _of(findings, "定義變更連動")
    check("抓到定義被修改", 1, len(linked))
    if linked:
        check("列出受影響的條文", True, "第七條" in linked[0]["detail"])

    # --- 外部法規引用：名稱要切乾淨 ---
    external = _of(findings, "外部法規引用")
    laws = sorted(f["quote"] for f in external)
    check("抽出兩部外部法規",
          ["保險法第一百四十八條之三", "金融消費者保護法第七條"], laws)

    # --- 其餘 ---
    check("抓到待補殘留", 1, len(_of(findings, "待補殘留")))
    check("抓到附表漏附", 1, len(_of(findings, "附表引用")))
    check("抓到施行日期未調整", 1, len(_of(findings, "施行日期")))
    check("抓到要保人／投保人混用", True,
          any("投保人" in f["detail"] for f in _of(findings, "用語混用")))

    # 沒給舊版時，三項高風險檢查要確實跳過而不是靜靜回報沒問題
    without_old = _qc(with_old=False)
    check("沒有舊版時不做責任用語檢查", 0, len(_of(without_old, "責任用語變更")))
    check("沒有舊版時不做數值變更檢查", 0, len(_of(without_old, "數值期間變更")))


def test_law_name_cleanup():
    section("16. 外部法規名稱的切割")

    # 名稱前面黏著動詞或連接詞要切掉，但法規名稱本身含「及」的不能切壞
    cases = [
        ("本要點依保險法", "保險法"),
        ("及金融消費者保護法", "金融消費者保護法"),
        ("依個人資料保護法", "個人資料保護法"),
        ("第五條及證券交易法", "證券交易法"),
        ("保險業招攬及核保理賠辦法", "保險業招攬及核保理賠辦法"),
        ("內部控制準則", "內部控制準則"),
        ("保險業務員自律規範", "保險業務員自律規範"),
    ]
    for raw, expected in cases:
        check("「%s」→「%s」" % (raw, expected), expected,
              rule_checks._clean_law_name(raw))


# ---------------------------------------------------------------------------
# 17. 用語與條號檢查的兩個陷阱
# ---------------------------------------------------------------------------

def test_check_pitfalls():
    section("17. 用語與條號檢查的兩個陷阱")

    # 陷阱一：「不可竄改」裡的「不可」不是責任用語。
    # 沒遮掉的話，測試文本裡「不可竄改」出現一百多次，程式會建議把「不得」
    # 全部改成「不可」——方向完全相反。
    text = ["第一條 電子檔應以不可竄改之格式保存。",
            "第二條 要保人不得以他人名義投保。",
            "第三條 本公司不得拒絕受理。"]
    findings = rule_checks.check_term_consistency(text)
    mixed = [f for f in findings if "不得" in f["detail"] or "不可" in f["detail"]]
    check("「不可竄改」不會被算成責任用語「不可」", [], mixed)

    # 陷阱二：建議統一的用字要看法制慣例，不是看誰出現得多
    text = ["第一條 甲不可為之。", "第二條 乙不可為之。",
            "第三條 丙不可為之。", "第四條 丁不得為之。"]
    findings = rule_checks.check_term_consistency(text)
    mixed = [f for f in findings if "不得" in f["detail"]]
    check("混用時建議統一為法制慣用的「不得」", True,
          bool(mixed) and "統一為「不得」" in mixed[0]["detail"])

    # 陷阱三：舊版就存在的條號斷點，不該每次修訂都報成中風險
    old = ["第一條 甲。", "第二條 乙。", "第五條 丙。"]
    new = ["第一條 甲。", "第二條 乙。", "第五條 丙。", "第六條 丁。"]
    gaps = [f for f in rule_checks.check_article_integrity(new, old)
            if f["check"] == "條號跳號"]
    check("既有斷號降級為低風險", "低", gaps[0]["severity"] if gaps else None)
    check("並註明非本次造成", True,
          bool(gaps) and "舊版即已如此" in gaps[0]["detail"])

    # 本次修訂新造成的斷號，仍然要報中風險
    old2 = ["第一條 甲。", "第二條 乙。", "第三條 丙。"]
    new2 = ["第一條 甲。", "第三條 丙。"]
    gaps2 = [f for f in rule_checks.check_article_integrity(new2, old2)
             if f["check"] == "條號跳號"]
    check("本次造成的斷號仍報中風險", "中", gaps2[0]["severity"] if gaps2 else None)

    # 「第六條　（刪除）」是標準寫法，不該被當成空白條文
    marked = ["第五條 甲。", "第六條　（刪除）", "第七條 丙。"]
    blanks = [f for f in rule_checks.check_article_integrity(marked)
              if f["check"] == "空白條文"]
    check("「（刪除）」註記不會被當成空白條文", [], blanks)


# ---------------------------------------------------------------------------
# 18. 不靠 python-docx 也要讀得了 .docx
# ---------------------------------------------------------------------------

def test_docx_without_package(workdir):
    section("18. 受限環境：不靠 python-docx 讀 .docx")

    try:
        from docx import Document
    except ImportError:
        print("  [略過] 這台沒有 python-docx，無法產生比對用的 .docx")
        return

    # 有些企業 AI 平台的套件庫是固定的，裝不了 python-docx。但內規幾乎都是 Word 檔，
    # 讀不了 .docx 等於整套工具在那種環境不能用。所以要有一條只用標準函式庫的路徑，
    # 而且產出必須跟 python-docx 完全一致，否則兩個環境會得到不同的對照表。
    outdir = os.path.join(workdir, "docx_stdlib")
    os.makedirs(outdir)

    lines = read_paragraphs(NEW_FILE)
    document = Document()
    for line in lines[:-2]:
        document.add_paragraph(line)
    table = document.add_table(rows=2, cols=2)
    table.rows[0].cells[0].text = lines[-2]
    table.rows[1].cells[1].text = lines[-1]
    path = os.path.join(outdir, "測試.docx")
    document.save(path)

    via_package = read_paragraphs(path)          # 走 python-docx
    via_stdlib = read_docx_stdlib(path)          # 走標準函式庫拆 zip

    check("標準函式庫讀出的段落數與 python-docx 相同",
          len(via_package), len(via_stdlib))
    check("逐段內容完全一致", via_package, via_stdlib)
    check("表格內的條文也讀得到", True, lines[-1] in via_stdlib)

    # 損壞或非 .docx 的檔案要給看得懂的錯誤，不是丟出 zipfile 的內部例外
    broken = os.path.join(outdir, "壞檔.docx")
    with open(broken, "wb") as f:
        f.write(b"this is not a docx")
    try:
        read_docx_stdlib(broken)
        check("損壞的 .docx 被擋下", True, False)
    except SystemExit as exc:
        check("損壞的 .docx 給出看得懂的錯誤", True, "有效的 .docx" in str(exc))


def main():
    setup_console()
    print("=" * 62)
    print("reg-diff 自我檢查")
    print("Python %s" % sys.version.split()[0])
    print("=" * 62)

    workdir = tempfile.mkdtemp(prefix="reg-diff-selftest-")
    try:
        test_article_no()
        test_reading(workdir)
        csv_path, _ = test_step1(workdir)
        table_docx, annotated = test_step1_docx(workdir, csv_path)
        test_docx_marking(table_docx, annotated)
        test_step2()
        test_step2_from_csv(csv_path)
        test_cli(workdir)
        test_large_document(workdir)
        test_renumber()
        test_renumber_in_report()
        test_reference_forms()
        test_reference_rewrite_precision()
        test_deleted_article_reference()
        test_rule_checks()
        test_law_name_cleanup()
        test_check_pitfalls()
        test_docx_without_package(workdir)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)

    print("\n" + "=" * 62)
    if _failures:
        print("有 %d 項未通過（共 %d 項）：" % (len(_failures), len(_failures) + len(_passes)))
        for label, expected, actual in _failures:
            print("  ✗ %s" % label)
            print("      預期：%r" % (expected,))
            print("      實際：%r" % (actual,))
        print("=" * 62)
        return 1

    print("全部通過（共 %d 項）" % len(_passes))
    print("=" * 62)
    return 0


if __name__ == "__main__":
    sys.exit(main())
