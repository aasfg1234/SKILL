# -*- coding: utf-8 -*-
"""
產生大型測試內規（約 50 頁，含 章／節／條／款／目 完整層級）。

為什麼用程式產、不直接放一個 4 萬字的檔案在專案裡：
- 固定亂數種子，每次產出的內容完全一樣，測試結果可重複
- 專案裡不用塞一份沒人會讀的巨大文字檔
- 要改測試規模（章節數、埋幾個漏改）直接改參數就好

執行：
    python tests/make_large_fixture.py            產生到 tests/_large/
    python tests/make_large_fixture.py --outdir X 產生到指定資料夾

產出：
    舊版_大型內規.txt / 新版_大型內規.txt
    埋伏清單.json   ← 這份檔案記錄了刻意埋了哪些修改與漏改，供 selftest 核對
"""

import argparse
import io
import json
import os
import random

SEED = 20260816

CN = "一二三四五六七八九十"


def cn_number(value):
    """阿拉伯數字轉中文數字，支援到 999，內規條號夠用。"""
    if value <= 10:
        return CN[value - 1]
    if value < 20:
        return "十" + CN[value - 11]
    if value < 100:
        tens, ones = divmod(value, 10)
        return CN[tens - 1] + "十" + (CN[ones - 1] if ones else "")
    hundreds, rest = divmod(value, 100)
    text = CN[hundreds - 1] + "百"
    if rest == 0:
        return text
    if rest < 10:
        return text + "零" + CN[rest - 1]
    return text + cn_number(rest)


# ---------------------------------------------------------------------------
# 內容素材：拼出來的條文要像真的內規，不能是「測試文字一二三」
# ---------------------------------------------------------------------------

CHAPTERS = [
    ("總則", ["法令依據與適用範圍", "用詞定義", "權責劃分", "適用對象"]),
    ("招攬管理", ["業務人員資格", "招攬行為規範", "文宣與話術管理",
                  "網路投保招攬", "電話行銷招攬", "招攬糾紛處理"]),
    ("核保與承保", ["要保文件審查", "體檢與生調", "核保決定",
                    "保險費收取", "再保安排", "拒保與延期"]),
    ("保全與理賠", ["契約變更", "保單借款", "理賠申請",
                    "理賠調查", "理賠給付", "爭議處理"]),
    ("附則", ["文件保存", "教育訓練", "內部稽核", "施行"]),
]

# 每一節放幾條。50 頁的內規大約 250~400 條，這個範圍配上下面的章節數剛好。
ARTICLES_PER_SECTION = (9, 14)

SUBJECTS = ["要保人", "被保險人", "受益人", "業務人員", "招攬人員", "核保人員",
            "理賠人員", "本公司", "分支機構", "受託機構"]

PROVISOS = [
    "但經權責主管核准並留存紀錄者，不在此限",
    "但法令另有規定或主管機關另有函釋者，從其規定",
    "但屬要保人自行申請且已充分說明者，不在此限",
    "但情形急迫且事後補行陳報者，不在此限",
    "但金額未達新臺幣十萬元者，得由單位主管逕行核定",
]

PURPOSES = [
    "以確保招攬品質及客戶權益",
    "俾利後續查核及責任歸屬之認定",
    "作為內部控制制度有效運作之依據",
    "以符合保險業招攬及核保理賠辦法之規定",
    "並納入年度法令遵循自行查核項目",
]

SECOND_PARAGRAPHS = [
    "前項文件之保存年限，自契約終止或理賠結案之日起算，不得少於五年；涉有爭議或訴訟者，應保存至案件確定後五年。",
    "前項作業如涉及個人資料之蒐集、處理或利用，應依個人資料保護法及本公司相關規定辦理，並取得當事人書面同意。",
    "違反前項規定者，依本公司獎懲辦法議處；情節重大者，並得停止其招攬資格三個月至一年。",
    "前項所定期間，遇例假日或國定假日者，順延至次一營業日；因不可抗力致無法辦理者，其期間之計算另行陳報核定。",
    "本條所定作業程序，各單位得視業務性質訂定補充規定，報經權責主管核定後實施，並副知法令遵循單位備查。",
    "前項審查結果應以書面或電子文件通知申請人；經審查不予受理者，應敘明理由並告知救濟途徑。",
]

ACTIONS = [
    "應於收齊文件之次日起十五日內完成審查",
    "應留存相關證明文件至少五年",
    "應主動出示登錄證及名片",
    "不得為誇大不實或引人錯誤之表示",
    "應向要保人說明契約撤銷權之行使方式",
    "應確認要保人具有保險利益",
    "應以書面或電子文件方式留存紀錄",
    "應於三個營業日內陳報主管單位",
    "應依內部控制制度辦理覆核",
    "得視個案情形要求補正文件",
    "應取得要保人之書面同意",
    "應每年接受法令遵循教育訓練至少三小時",
    "應建立客戶身分確認及審查機制",
    "不得以任何名義收受要保人現金",
    "應於契約撤銷期間屆滿後始得核發保單",
]

CONDITIONS = [
    "辦理前項業務時",
    "於招攬保險商品時",
    "受理契約變更申請時",
    "經查有下列情事之一者",
    "有下列情形之一，經主管核准者",
    "除法令另有規定外",
    "為確保客戶權益",
    "遇有疑義時",
]

CLAUSE_ITEMS = [
    "身分證明文件影本",
    "要保書及告知事項",
    "保險費繳納證明",
    "受益人指定同意書",
    "體檢報告或健康聲明書",
    "財力證明文件",
    "法定代理人同意書",
    "醫療診斷證明書",
    "事故證明文件",
    "受託人授權書",
]

SUB_ITEMS = [
    "文件應加註核對人員姓名及日期",
    "影本應與正本相符並註記",
    "電子檔應以不可竄改之格式保存",
    "缺件者應於七日內通知補正",
    "逾期未補正者，得逕予結案",
]


def build_document(rng):
    """
    產生一份完整內規的段落列表，同時回傳每一條的索引資訊。

    層級：第X章 → 第X節 → 第X條 → 款（一、二、三）→ 目（(一)(二)(三)）
    """
    lines = ["○○人壽保險股份有限公司　保險業務作業處理準則"]
    article_no = 0
    index = []   # [(段落序號從1起算, 章, 節, 條號, 層級)]

    for chapter_idx, (chapter_name, sections) in enumerate(CHAPTERS, 1):
        chapter_label = "第%s章 %s" % (cn_number(chapter_idx), chapter_name)
        lines.append(chapter_label)
        index.append((len(lines), chapter_label, "", "", "章"))

        for section_idx, section_name in enumerate(sections, 1):
            section_label = "第%s節 %s" % (cn_number(section_idx), section_name)
            lines.append(section_label)
            index.append((len(lines), chapter_label, section_label, "", "節"))

            for _ in range(rng.randint(*ARTICLES_PER_SECTION)):
                article_no += 1
                article_label = "第%s條" % cn_number(article_no)
                body = "%s%s，%s，%s；%s。" % (
                    rng.choice(SUBJECTS), rng.choice(CONDITIONS),
                    rng.choice(ACTIONS), rng.choice(PURPOSES), rng.choice(PROVISOS))
                lines.append("%s %s" % (article_label, body))
                index.append((len(lines), chapter_label, section_label, article_label, "條"))

                # 約四成的條有第二項。項在內規裡是沒有編號的獨立段落，
                # 條號辨識抓不到它，這正是要測的情境之一。
                if rng.random() < 0.4:
                    lines.append(rng.choice(SECOND_PARAGRAPHS))
                    index.append((len(lines), chapter_label, section_label,
                                  article_label, "項"))

                # 約三分之一的條有款；有款的其中一半再帶目。
                # 同一條底下的款目用不重複抽樣，避免產生「(一)跟(三)一模一樣」這種
                # 現實不會出現、卻會污染 Step 2 相似度結果的假資料。
                if rng.random() < 0.34:
                    item_count = rng.randint(2, 4)
                    for item_idx, item_text in enumerate(
                            rng.sample(CLAUSE_ITEMS, item_count), 1):
                        lines.append("%s、%s，並依前條規定辦理覆核。"
                                     % (cn_number(item_idx), item_text))
                        index.append((len(lines), chapter_label, section_label,
                                      article_label, "款"))

                        if rng.random() < 0.45:
                            sub_count = rng.randint(2, 3)
                            for sub_idx, sub_text in enumerate(
                                    rng.sample(SUB_ITEMS, sub_count), 1):
                                lines.append("(%s)%s，並註明處理人員及日期。"
                                             % (cn_number(sub_idx), sub_text))
                                index.append((len(lines), chapter_label, section_label,
                                              article_label, "目"))

    return lines, index


# ---------------------------------------------------------------------------
# 埋伏：在新版裡刻意做出幾種真實會出事的修改
# ---------------------------------------------------------------------------

DUPLICATE_BODY = ("業務人員辦理網路投保招攬時，應於網頁明顯處揭露登錄證字號及申訴電話，"
                  "並保存招攬過程之電子紀錄。")


def seed_duplicates(lines, index):
    """
    把同一條規定種進三個不同章的條文裡——舊版新版都有。

    這模擬的是內規本來就存在的結構：同一件事因為壽險章、產險章、網路投保章
    各自成章，就各寫了一次。必須種在「舊版」，之後只改其中一處，才會形成
    「改了一處、另外兩處漏改」的情境。只種進新版的話，三處都會被判定成修改，
    測到的就不是漏改了。
    """
    targets = []
    seen_chapters = set()
    for pos, chapter, section, article, level in index:
        if level != "條" or chapter in seen_chapters:
            continue
        seen_chapters.add(chapter)
        targets.append({"pos": pos, "chapter": chapter, "article": article})
        if len(targets) == 3:
            break

    for target in targets:
        lines[target["pos"] - 1] = "%s %s" % (target["article"], DUPLICATE_BODY)
    return targets


def plant_changes(lines, index, duplicate_targets):
    """
    依舊版產出新版，回傳 (新版段落列表, 埋伏清單)。

    埋的東西：
    1. 跨章重複漏改：三處相同條文只改第一處
    2. 條號錯位觸發：修改 → 新增 → 修改 三段緊鄰
    3. 款層級的修改
    4. 目層級的修改
    5. 整條刪除
    """
    lines = list(lines)
    plants = []

    by_level = {}
    for pos, chapter, section, article, level in index:
        by_level.setdefault(level, []).append(
            {"pos": pos, "chapter": chapter, "section": section, "article": article})

    # --- 埋伏 1：跨章重複，只改第一處 ---
    first = duplicate_targets[0]
    lines[first["pos"] - 1] = (
        "%s 業務人員辦理網路投保招攬時，應於網頁明顯處及行動應用程式首頁"
        "揭露登錄證字號、申訴電話及客服信箱，並保存招攬過程之電子紀錄至少五年。"
        % first["article"])
    plants.append({
        "類型": "跨章重複漏改",
        "已修改": first["article"],
        "所屬章": first["chapter"],
        "應一併檢視": [{"條號": t["article"], "所屬章": t["chapter"]}
                       for t in duplicate_targets[1:]],
    })

    # --- 埋伏 2：條號錯位觸發（修改 → 新增 → 修改 三段緊鄰）---
    articles = by_level["條"]
    anchor = next(a for a in articles if a["pos"] > first["pos"] + 60)
    following = next(a for a in articles if a["pos"] > anchor["pos"])

    lines[anchor["pos"] - 1] = lines[anchor["pos"] - 1].rstrip("。") + "，並副知法令遵循單位。"
    inserted_label = "%s之一" % anchor["article"]
    lines.insert(anchor["pos"],
                 "%s 前條所稱法令遵循單位，指本公司法令遵循室及各單位指派之"
                 "法令遵循主管；其職掌依法令遵循制度實施要點辦理。" % inserted_label)
    # 插入之後，原本在它後面的段落位置全部往後移一格
    lines[following["pos"]] = lines[following["pos"]].rstrip("。") + "，並保留紀錄備查。"
    plants.append({
        "類型": "條號錯位觸發",
        "修改": anchor["article"],
        "新增": inserted_label,
        "後續修改": following["article"],
        "所屬章": anchor["chapter"],
        "所屬節": anchor["section"],
    })

    # --- 埋伏 3、4：款與目層級的修改 ---
    for level in ("款", "目"):
        candidates = [c for c in by_level[level] if c["pos"] > following["pos"] + 40]
        target = candidates[5 if level == "款" else 3]
        shifted = target["pos"] + 1          # 前面插了一段，位置往後移一格
        lines[shifted - 1] = lines[shifted - 1].rstrip("。") + "，並經權責主管簽核。"
        plants.append({
            "類型": "%s層級修改" % level,
            "所屬章": target["chapter"],
            "所屬節": target["section"],
            "所屬條": target["article"],
            "修改後文字": lines[shifted - 1],
        })

    # --- 埋伏 5：整條刪除 ---
    delete_target = next(a for a in articles if a["pos"] > following["pos"] + 90)
    shifted = delete_target["pos"] + 1
    plants.append({
        "類型": "整條刪除",
        "條號": delete_target["article"],
        "所屬章": delete_target["chapter"],
        "原文": lines[shifted - 1],
    })
    del lines[shifted - 1]

    return lines, plants


def main():
    parser = argparse.ArgumentParser(description="產生大型測試內規（約 50 頁）")
    parser.add_argument("--outdir", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "_large"))
    args = parser.parse_args()

    if not os.path.isdir(args.outdir):
        os.makedirs(args.outdir)

    rng = random.Random(SEED)
    old_lines, index = build_document(rng)
    duplicate_targets = seed_duplicates(old_lines, index)
    new_lines, plants = plant_changes(old_lines, index, duplicate_targets)

    old_path = os.path.join(args.outdir, "舊版_大型內規.txt")
    new_path = os.path.join(args.outdir, "新版_大型內規.txt")
    plants_path = os.path.join(args.outdir, "埋伏清單.json")

    io.open(old_path, "w", encoding="utf-8").write("\n".join(old_lines) + "\n")
    io.open(new_path, "w", encoding="utf-8").write("\n".join(new_lines) + "\n")
    io.open(plants_path, "w", encoding="utf-8").write(
        json.dumps(plants, ensure_ascii=False, indent=2))

    chars = sum(len(line) for line in old_lines)
    print("舊版 %d 段、%d 字（約 %.0f 頁，以每頁 900 字估）"
          % (len(old_lines), chars, chars / 900.0))
    print("新版 %d 段" % len(new_lines))
    print("埋伏 %d 組，清單：%s" % (len(plants), plants_path))
    return old_path, new_path, plants_path


if __name__ == "__main__":
    main()
