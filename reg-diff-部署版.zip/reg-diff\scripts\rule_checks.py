# -*- coding: utf-8 -*-
"""
Step 1.6：條文品質與風險檢查

跑完 Step 1 的精確比對之後跑這支。比對告訴你「哪裡改了」，這支告訴你
「這些改動裡有哪些特別該看」，以及「文件本身有沒有結構性的毛病」。

十項檢查，全部是程式碼做得到、不需要 LLM 判斷的：

需要新舊版比對（要給 --old）
    1. 責任用語變更   應→得、不得→得 這種修改是責任強度的實質變更
    2. 數值期間變更   十五日→三十日、五年→三年、十萬元→二十萬元
    3. 施行日期       改了實質條文，但施行日期條文沒動

只看新版就能查
    4. 條號健全性     重複、跳號、「之一」順序錯亂、空白條文
    5. 定義用語       定義了卻全文沒用到；改了定義但用到它的條文沒跟著看
    6. 外部法規引用   抽出所有「○○法第X條」，供人工核對母法是否已修正
    7. 待補殘留       TBD、XXX、待補、待確認 之類沒清掉的字
    8. 格式一致性     （一）與(一)混用、條號後分隔符不一致
    9. 用語混用       要保人／投保人、業務員／業務人員 這類同義詞混著用
   10. 附表引用       文中提到「附表一」，但全文找不到附表一

--------------------------------------------------------------------------
這支程式不做什麼
--------------------------------------------------------------------------
條文之間有沒有邏輯矛盾、修改有沒有逾越母法授權、修正理由該怎麼寫——
這些需要理解條文的意思，程式做不到，交給 SKILL.md 裡的 LLM 檢查層。
本程式只做「規則明確、結果可重複驗證」的部分。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
    python rule_checks.py 新版內規.docx --old 舊版內規.docx
    python rule_checks.py 新版內規.docx                  只做不需要比對的六項
    python rule_checks.py 新版內規.docx --terms 用語表.json   自訂用語混用檢查

輸出：條文檢查報告.csv（可用 Excel 篩選），以及主控台的分級摘要。
"""

import argparse
import csv
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, build_hierarchy,
                     diff_runs, resolve_output)
import diff_compare

CN = "零〇一二三四五六七八九十百千萬兩"

HIGH, MEDIUM, LOW = "高", "中", "低"


def finding(severity, check, detail, index=None, ref="", quote="", action=""):
    """統一的檢查結果格式。"""
    return {"severity": severity, "check": check, "index": index, "ref": ref,
            "quote": quote, "detail": detail, "action": action}


# ---------------------------------------------------------------------------
# 1. 責任用語變更
# ---------------------------------------------------------------------------

# 強度分級：數字越大責任越重。用來判斷這次修改是鬆綁還是加嚴。
# 法制作業上「應」與「得」是天差地別的兩件事——「應」是義務，「得」是裁量權。
# 在一堆文字修改裡，這種兩個字的差異最容易被滑過去，但它才是真正的實質變更。
MODAL_STRENGTH = {
    "不得": 4, "非經": 4, "禁止": 4,
    "應": 3, "須": 3, "必須": 3, "應予": 3,
    "宜": 2, "原則上": 2,
    "得": 1, "可": 1, "得予": 1, "無須": 1, "免": 1,
}


# 這些詞裡面雖然有「應」「得」「可」「須」，但那不是責任用語，
# 是「應用程式」「取得」「可能」這種一般詞彙的一部分。
# 中文沒有空白斷詞，直接用 count() 會把它們全部算進去——實測「或行動應用程式」
# 就被誤判成「新增了一個應」。比對前先把這些複合詞遮掉。
_MODAL_DECOYS = [
    "應用", "應變", "應答", "應急", "應對", "應收", "應付", "應酬", "應試",
    "因應", "對應", "相應", "適應", "反應", "供應", "呼應", "感應", "響應",
    "取得", "獲得", "所得", "心得", "使得", "值得", "懂得", "覺得", "免得",
    "難得", "記得", "曉得", "捨得", "不得已", "得標", "得利",
    "可能", "可靠", "可疑", "可觀", "認可", "許可", "可行", "可否",
    "不可竄改", "不可抗力", "不可分", "不可歸責", "不可撤銷", "不可逆",
    "須知", "必須",   # 必須另行計數，避免被「須」重複算
]


def mask_decoys(text):
    """把含有責任用語字元、但實際不是責任用語的複合詞遮成等長的替代字元。"""
    for decoy in _MODAL_DECOYS:
        text = text.replace(decoy, "○" * len(decoy))
    return text


def check_modal_changes(results):
    """
    在字級差異裡找出責任用語的變化。

    只看「真正被改掉的那幾個字」，不看整段，所以雜訊很低：
    一段話改了三十個字但沒動到「應」「得」，就不會被列出來。
    """
    findings = []
    for result in results:
        if result["type"] != "modified":
            continue

        runs = diff_runs(result["old_text"], result["new_text"])
        removed = mask_decoys("".join(t for k, t in runs if k == "delete"))
        added = mask_decoys("".join(t for k, t in runs if k == "insert"))
        if not removed.strip("○") and not added.strip("○"):
            continue

        changed = []
        for term in MODAL_STRENGTH:
            delta = added.count(term) - removed.count(term)
            if delta:
                changed.append((term, delta))
        if not changed:
            continue

        gone = [t for t, d in changed if d < 0]
        appeared = [t for t, d in changed if d > 0]
        direction = _strictness_direction(gone, appeared)

        findings.append(finding(
            HIGH if direction != "用語調整" else MEDIUM,
            "責任用語變更",
            "%s（%s → %s）" % (direction,
                              "、".join(gone) or "（無）",
                              "、".join(appeared) or "（無）"),
            index=result.get("new_index") or result.get("old_index"),
            ref=result.get("ref", ""),
            quote="原文：%s ／ 修改後：%s" % (result["old_text"][:40],
                                            result["new_text"][:40]),
            action="確認這是否為有意識的責任範圍調整，並在修正理由欄敘明"))
    return findings


def _strictness_direction(gone, appeared):
    """判斷是鬆綁、加嚴，還是只是換個說法。"""
    if not gone or not appeared:
        return "責任用語增刪"
    before = max(MODAL_STRENGTH[t] for t in gone)
    after = max(MODAL_STRENGTH[t] for t in appeared)
    if after < before:
        return "責任放寬（鬆綁）"
    if after > before:
        return "責任加重（加嚴）"
    return "用語調整"


# ---------------------------------------------------------------------------
# 2. 數值、期間、金額變更
# ---------------------------------------------------------------------------

_UNITS = ("個營業日", "個工作日", "個月", "營業日", "工作日", "日", "月", "年",
          "小時", "分鐘", "億元", "萬元", "元", "％", "%", "倍", "次", "人",
          "件", "成", "歲")

_NUMBER_RE = re.compile(r"([%s\d][%s\d,．.]*)\s*(%s)" % (CN, CN, "|".join(_UNITS)))


def check_numeric_changes(results):
    """
    在字級差異裡找出數字、期間、金額的變化。

    法遵複核時這是必看項：期間從十五日放寬成三十日、金額門檻從十萬提高到
    二十萬，都是實質變更，但夾在文字修改裡很容易被當成潤稿滑過去。
    """
    findings = []
    for result in results:
        if result["type"] != "modified":
            continue

        # 這裡刻意比對「整段」而不是只看 diff 片段。
        # 「十五日」改成「三十日」時，單位「日」沒有變動，會留在相同片段裡，
        # 只掃描差異片段的話只看得到「十五」與「三十」，抓不到單位就整筆漏掉。
        old_numbers = _NUMBER_RE.findall(result["old_text"])
        new_numbers = _NUMBER_RE.findall(result["new_text"])
        removed = [n for n in old_numbers if n not in new_numbers]
        added = [n for n in new_numbers if n not in old_numbers]
        if not removed and not added:
            continue

        # 同單位的一減一增，配成「十五日 → 三十日」比較好讀
        pairs, leftover_removed, leftover_added = _pair_by_unit(removed, added)
        if not pairs and not leftover_removed and not leftover_added:
            continue

        parts = ["%s → %s" % (a, b) for a, b in pairs]
        parts += ["刪除 %s" % x for x in leftover_removed]
        parts += ["新增 %s" % x for x in leftover_added]

        findings.append(finding(
            HIGH, "數值期間變更", "；".join(parts),
            index=result.get("new_index") or result.get("old_index"),
            ref=result.get("ref", ""),
            quote="修改後：%s" % result["new_text"][:50],
            action="確認新的數值是否符合母法或主管機關規定的上下限"))
    return findings


def _pair_by_unit(removed, added):
    """把同單位的舊值新值配成一對。配不到的分別列出。"""
    remaining = list(added)
    pairs = []
    leftover_removed = []

    for value, unit in removed:
        match = next((item for item in remaining if item[1] == unit), None)
        if match:
            remaining.remove(match)
            if value != match[0]:
                pairs.append(("%s%s" % (value, unit), "%s%s" % (match[0], unit)))
        else:
            leftover_removed.append("%s%s" % (value, unit))

    return pairs, leftover_removed, ["%s%s" % (v, u) for v, u in remaining]


# ---------------------------------------------------------------------------
# 3. 施行日期
# ---------------------------------------------------------------------------

_EFFECTIVE_RE = re.compile(r"(施行|生效|實施)")


def check_effective_date(paragraphs, results):
    """
    改了實質條文，施行日期條文卻原封不動——不一定是錯，但一定要問一句。

    內規修正通常要註明「本要點修正條文自○年○月○日施行」。忘了改的話，
    新規定的生效日會停留在上一版，實務上會出現「規定改了但沒生效」的爭議。
    """
    effective = [(idx, text) for idx, text in enumerate(paragraphs, 1)
                 if _EFFECTIVE_RE.search(text) and len(text) < 60]

    substantive = [r for r in results
                   if r["type"] in ("added", "deleted", "modified")]
    if not substantive:
        return []

    if not effective:
        return [finding(MEDIUM, "施行日期",
                        "全文找不到施行或生效日期的條文",
                        action="確認是否需要補一條「本要點修正條文自○年○月○日施行」")]

    changed_effective = any(
        r["type"] != "unchanged"
        and any(text == r.get("new_text") or text == r.get("old_text")
                for _, text in effective)
        for r in results)

    if changed_effective:
        return []

    idx, text = effective[-1]
    return [finding(MEDIUM, "施行日期",
                    "本次有 %d 處實質異動，但施行日期條文沒有跟著修改" % len(substantive),
                    index=idx, quote=text,
                    action="確認修正條文的生效日期是否需要另訂")]


# ---------------------------------------------------------------------------
# 4. 條號健全性
# ---------------------------------------------------------------------------

_ARTICLE_NO_RE = re.compile(r"^第\s*([%s\d]+)\s*條(?:\s*之\s*([%s\d]+))?" % (CN, CN))


def _cn_value(text):
    """中文數字轉整數，支援到千位（條號用得到「第一百十六條」）。"""
    if not text:
        return None
    if text.isdigit():
        return int(text)
    digits = {"零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "三": 3, "四": 4,
              "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    units = {"十": 10, "百": 100, "千": 1000}
    total, current = 0, 0
    for char in text:
        if char in digits:
            current = digits[char]
        elif char in units:
            current = current or 1
            total += current * units[char]
            current = 0
        else:
            return None
    return total + current


# 「第六條　（刪除）」這種刪除註記。依法制慣例，刪除某一條時保留條號並如此註記，
# 後面的條號才不會全部往前移、導致其他規章的引用全部指錯。
_DELETED_MARK_RE = re.compile(r"^[（(]\s*刪\s*除\s*[）)]\s*$")


def check_article_integrity(paragraphs, old_paragraphs=None):
    """
    條號本身的健全性：重複、跳號、「之一」順序錯亂、只有條號沒有內容。

    這幾種毛病在 50 頁的內規裡靠肉眼幾乎抓不到，但送出去會被挑。

    old_paragraphs：給了舊版的話，會分辨跳號是「本次修訂造成的」還是
    「上一版就已經存在」。既有的斷號每次修訂都報一次是純雜訊，
    使用者看久了會連真正該看的那筆一起略過。
    """
    findings = []
    contexts = build_hierarchy(paragraphs)
    seen = {}
    sequence = []

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        if context["level"] != "條":
            continue
        match = _ARTICLE_NO_RE.match(text)
        if not match:
            continue

        main = _cn_value(match.group(1))
        sub = _cn_value(match.group(2)) if match.group(2) else 0
        label = context["article"]

        if label in seen:
            findings.append(finding(
                HIGH, "條號重複",
                "%s 出現兩次（第 %d 段與第 %d 段）" % (label, seen[label], idx),
                index=idx, ref=label, quote=text[:40],
                action="確認是否誤植，或其中一條應改號"))
        else:
            seen[label] = idx

        body = text[match.end():].strip(" 　:：")
        if not body:
            findings.append(finding(
                MEDIUM, "空白條文", "%s 只有條號、沒有內容" % label,
                index=idx, ref=label,
                action="若為刪除，請改為「%s　（刪除）」的標準寫法" % label))

        is_deleted_mark = bool(_DELETED_MARK_RE.match(body))
        sequence.append((main, sub, label, idx, text, is_deleted_mark))

    existing_gaps = _gap_articles(old_paragraphs) if old_paragraphs else set()
    findings.extend(_check_sequence(sequence, existing_gaps))
    return findings


def _gap_articles(paragraphs):
    """算出一份文件裡條號斷掉的地方，用來判斷斷號是不是本來就有。"""
    numbers = []
    for text in paragraphs:
        match = _ARTICLE_NO_RE.match(text)
        if match and not match.group(2):
            value = _cn_value(match.group(1))
            if value is not None:
                numbers.append(value)

    missing = set()
    for previous, current in zip(numbers, numbers[1:]):
        if current > previous + 1:
            missing.update(range(previous + 1, current))
    return missing


def _check_sequence(sequence, existing_gaps=frozenset()):
    """檢查條號順序：跳號、「之一」跑到本條前面。"""
    findings = []
    previous_main = None

    for main, sub, label, idx, text, is_deleted_mark in sequence:
        if main is None:
            continue

        if sub and previous_main != main:
            # 「第五條之一」前面必須先有「第五條」，否則就是接錯位置
            findings.append(finding(
                HIGH, "條號順序",
                "%s 出現在 第%s條 之前或找不到本條" % (label, main),
                index=idx, ref=label, quote=text[:40],
                action="「之一」的條文應緊接在本條之後"))

        if previous_main is not None and not sub and main > previous_main + 1:
            gap_numbers = list(range(previous_main + 1, main))
            missing = ["第%s條" % _int_to_cn(n) for n in gap_numbers]
            # 舊版就已經斷在同樣的位置，代表是上一版留下來的，不是這次造成的。
            # 這種每次修訂都報一次只會變成雜訊，降級但不隱藏。
            pre_existing = existing_gaps and set(gap_numbers) <= existing_gaps
            findings.append(finding(
                LOW if pre_existing else MEDIUM, "條號跳號",
                "%s 之後直接跳到 %s，中間缺 %s%s"
                % ("第%s條" % _int_to_cn(previous_main), label, "、".join(missing),
                   "（舊版即已如此，非本次修訂造成）" if pre_existing else ""),
                index=idx, ref=label,
                action="舊版即有，本次可不處理" if pre_existing
                       else "若為本次刪除，依慣例應保留條號並註記「（刪除）」"))

        if not sub:
            previous_main = main
    return findings


def _int_to_cn(value):
    """整數轉中文數字，支援到 999。"""
    digits = "零一二三四五六七八九"
    if value < 10:
        return digits[value]
    if value < 20:
        return "十" + (digits[value - 10] if value % 10 else "")
    if value < 100:
        tens, ones = divmod(value, 10)
        return digits[tens] + "十" + (digits[ones] if ones else "")
    hundreds, rest = divmod(value, 100)
    text = digits[hundreds] + "百"
    if rest == 0:
        return text
    if rest < 10:
        return text + "零" + digits[rest]
    return text + _int_to_cn(rest)


# ---------------------------------------------------------------------------
# 5. 定義用語
# ---------------------------------------------------------------------------

_DEFINITION_PATTERNS = [
    re.compile(r"本(?:要點|辦法|準則|規則|規定|作業程序)所稱\s*[「『]?([^「」『』，,：:]{2,12})[」』]?\s*[，,：:]?\s*(?:指|係指|謂)"),
    re.compile(r"[「『]([^「」『』]{2,12})[」』]\s*[，,：:]?\s*(?:指|係指|謂)"),
]


def check_definitions(paragraphs, results):
    """
    定義用語的兩種毛病：

    1. 定義了卻全文沒用到 —— 通常是條文刪掉了、定義忘了刪
    2. 定義本身被改了 —— 用到這個詞的所有條文都要重看一次，因為它們的意思跟著變了

    第二種是實務上最常出包的：改了「網路投保」的定義，卻只想到要改網路投保章，
    忘了核保章、理賠章也有十幾條寫著「網路投保」。
    """
    findings = []
    contexts = build_hierarchy(paragraphs)
    definitions = {}

    for idx, text in enumerate(paragraphs, 1):
        for pattern in _DEFINITION_PATTERNS:
            match = pattern.search(text)
            if match:
                definitions.setdefault(match.group(1), (idx, text))
                break

    changed_texts = {r["new_text"] for r in results
                     if r["type"] == "modified" and r.get("new_text")}

    for term, (def_index, def_text) in definitions.items():
        users = [idx for idx, text in enumerate(paragraphs, 1)
                 if idx != def_index and term in text]

        if not users:
            findings.append(finding(
                LOW, "贅定義", "定義了「%s」，但全文其他地方沒有用到" % term,
                index=def_index, ref=contexts[def_index - 1]["ref"],
                quote=def_text[:44],
                action="確認是否為條文刪除後遺留的定義"))
            continue

        if def_text in changed_texts:
            refs = [contexts[i - 1]["ref"] or ("第%d段" % i) for i in users]
            findings.append(finding(
                HIGH, "定義變更連動",
                "「%s」的定義被修改，全文另有 %d 處用到這個詞：%s"
                % (term, len(users), "、".join(refs[:12])
                   + ("…" if len(refs) > 12 else "")),
                index=def_index, ref=contexts[def_index - 1]["ref"],
                quote=def_text[:44],
                action="逐條確認這些條文在新定義下是否仍然成立"))
    return findings


# ---------------------------------------------------------------------------
# 6. 外部法規引用
# ---------------------------------------------------------------------------

_EXTERNAL_RE = re.compile(
    r"([一-鿿]{2,14}?(?:法|條例|辦法|準則|規則|要點|注意事項|自律規範))"
    r"第\s*([%s\d]+)\s*條(?:\s*之\s*[%s\d]+)?" % (CN, CN))

# 法規名稱前面常常黏著動詞或連接詞：「本要點依保險法第X條」「及金融消費者保護法第Y條」。
# 不切掉的話會抓出「本要點依保險法」，還會因為開頭是「本要點」而被誤判成自我引用整筆漏掉。
#
# 但不能一律看到連接詞就切 ——「保險業招攬及核保理賠辦法」這種法規名稱本身就含「及」，
# 切了會變成「核保理賠辦法」。所以分兩種處理：
#   動詞類（依、按、本、第…）：出現在名稱中間就代表前面是句子，從最後一個切開
#   連接詞（及、與、暨…）：只有出現在最開頭才切，在名稱中間就當作名稱的一部分
#
# 「準」「自」刻意不列入動詞類：「內部控制準則」「業務員自律規範」都會被切壞。
_VERB_LEADERS = "依按照本第凡參"
_CONJUNCTIONS = "及與暨和或、"
_LAW_SUFFIXES = ("法", "條例", "辦法", "準則", "規則", "要點", "注意事項", "自律規範")


def _clean_law_name(name):
    """把法規名稱前面黏到的動詞、連接詞剝掉。剝完不像法規名稱就退回原樣。"""
    trimmed = name
    positions = [i for i, ch in enumerate(trimmed) if ch in _VERB_LEADERS]
    if positions:
        trimmed = trimmed[positions[-1] + 1:]
    # 切完可能還黏著「五條及」這種殘骸（原文是「第五條及證券交易法」），一併清掉
    trimmed = re.sub(r"^[%s\d]*[條項款目章節][%s]?" % (CN, _CONJUNCTIONS), "", trimmed)
    while trimmed and trimmed[0] in _CONJUNCTIONS:
        trimmed = trimmed[1:]

    if len(trimmed) >= 2 and trimmed.endswith(_LAW_SUFFIXES):
        return trimmed
    return name


_SELF_NAMES = ("本要點", "本辦法", "本準則", "本規則", "本規定", "本作業程序",
               "本法", "本條例")


def check_external_refs(paragraphs):
    """
    抽出所有外部法規的引用，列成清單。

    程式判斷不了「保險法第一百四十八條之三有沒有修正過」——那要查法規資料庫。
    但程式可以把該查的清單一次列齊，避免人工翻 50 頁去找。
    內規因母法修正而需連動修正，是最常見的漏改來源之一。
    """
    contexts = build_hierarchy(paragraphs)
    seen = {}

    for idx, text in enumerate(paragraphs, 1):
        for match in _EXTERNAL_RE.finditer(text):
            law = _clean_law_name(match.group(1))
            if not law or law in _SELF_NAMES:
                continue
            citation = law + match.group(0)[len(match.group(1)):]
            seen.setdefault(citation, []).append(
                (idx, contexts[idx - 1]["ref"] or ("第%d段" % idx)))

    if not seen:
        return []

    findings = []
    for citation, places in sorted(seen.items()):
        refs = "、".join(ref for _, ref in places[:8])
        findings.append(finding(
            MEDIUM, "外部法規引用",
            "引用 %s（%d 處：%s%s）"
            % (citation, len(places), refs, "…" if len(places) > 8 else ""),
            index=places[0][0], ref=places[0][1], quote=citation,
            action="查證該法條現行條文，確認引用的條號與內容仍然正確"))
    return findings


# ---------------------------------------------------------------------------
# 7. 待補殘留
# ---------------------------------------------------------------------------

_PLACEHOLDER_RE = re.compile(
    r"(TBD|TODO|XXX|ＸＸＸ|待補|待確認|待議|待訂|暫定|\?\?\?|【待[^】]*】)",
    re.IGNORECASE)


def check_placeholders(paragraphs):
    """草稿階段的佔位文字沒清乾淨就送出去，是很現實的意外。"""
    contexts = build_hierarchy(paragraphs)
    findings = []
    for idx, text in enumerate(paragraphs, 1):
        for match in _PLACEHOLDER_RE.finditer(text):
            findings.append(finding(
                HIGH, "待補殘留", "條文裡還留著「%s」" % match.group(0),
                index=idx, ref=contexts[idx - 1]["ref"], quote=text[:44],
                action="送出前務必清除或補實"))
    return findings


# ---------------------------------------------------------------------------
# 8. 格式一致性
# ---------------------------------------------------------------------------

def check_format_consistency(paragraphs):
    """
    全形半形混用、條號後分隔符不一致。

    這種問題不影響法律效力，但法制作業複核時會被退件重打，
    而且在 50 頁的文件裡靠肉眼找非常花時間。
    """
    findings = []

    full_width = sum(1 for p in paragraphs if re.match(r"^（", p))
    half_width = sum(1 for p in paragraphs if re.match(r"^\(", p))
    if full_width and half_width:
        findings.append(finding(
            LOW, "格式一致性",
            "目的括號全形半形混用：全形（）%d 段、半形() %d 段"
            % (full_width, half_width),
            action="統一為其中一種，通常內規慣用全形"))

    separators = {}
    for text in paragraphs:
        match = re.match(r"^第[%s\d]+條(?:之[%s\d]+)?(.)" % (CN, CN), text)
        if match:
            char = match.group(1)
            name = {" ": "半形空白", "　": "全形空白"}.get(char, "無空白")
            if char not in (" ", "　"):
                name = "無空白"
            separators[name] = separators.get(name, 0) + 1

    if len(separators) > 1:
        detail = "、".join("%s %d 條" % (k, v) for k, v in sorted(separators.items()))
        findings.append(finding(
            LOW, "格式一致性", "條號後的分隔方式不一致：%s" % detail,
            action="統一條號與條文之間的分隔（內規慣用全形空白）"))

    return findings


# ---------------------------------------------------------------------------
# 9. 用語混用
# ---------------------------------------------------------------------------

# 同一份內規裡混用同義詞，複核時會被要求統一。這裡放保險/金融內規常見的幾組，
# 各單位用語習慣不同，可以用 --terms 指定自己的對照表覆蓋。
#
# 每一組的「第一個」就是建議統一的用字，順序有意義，不要隨意調換。
# 不採用「哪個出現次數多就建議哪個」——法制作業慣用「不得」而非「不可」、
# 「應」而非「須」，跟出現頻率無關。實測就踩過這個坑：測試文本裡「不可竄改」
# 出現一百多次，程式因此建議把「不得」全部改成「不可」，方向完全相反。
DEFAULT_TERM_GROUPS = [
    ["要保人", "投保人"],
    ["被保險人", "受保人"],
    ["業務人員", "業務員", "招攬人員"],
    ["保險費", "保費"],
    ["保險契約", "保險合約"],
    ["本公司", "本行", "本銀行"],
    ["訂定", "制定"],
    ["應", "須"],
    ["得", "可"],
    ["不得", "不可"],
]


def check_term_consistency(paragraphs, groups=None):
    """同一組同義詞在全文混著用，就列出來讓人決定統一成哪一個。"""
    groups = groups or DEFAULT_TERM_GROUPS
    # 同樣要遮掉「不可竄改」「應用程式」「取得」這類複合詞。
    # 不遮的話，測試文本裡「不可竄改」出現一百多次，程式會反過來
    # 建議把「不得」統一成「不可」。
    whole = mask_decoys("\n".join(paragraphs))
    findings = []

    for group in groups:
        counts = {term: whole.count(term) for term in group}
        used = {term: n for term, n in counts.items() if n}
        if len(used) < 2:
            continue

        # 「不得」會被「得」的計數涵蓋，要扣掉才不會誤報
        if "得" in used and "不得" in counts:
            used["得"] = used["得"] - counts["不得"]
            if used["得"] <= 0:
                del used["得"]
        if len(used) < 2:
            continue

        detail = "、".join("%s %d 次" % (t, n)
                           for t, n in sorted(used.items(), key=lambda x: -x[1]))
        preferred = next(t for t in group if t in used)
        findings.append(finding(
            LOW, "用語混用", "%s（建議統一為「%s」）" % (detail, preferred),
            action="確認是否為有意區分；若無，統一用語"))
    return findings


# ---------------------------------------------------------------------------
# 10. 附表引用
# ---------------------------------------------------------------------------

_ATTACHMENT_REF_RE = re.compile(r"(附表|附件|附錄)\s*([%s\d]+)" % CN)


def check_attachments(paragraphs):
    """文中寫「詳如附表一」，但全文找不到附表一——附件漏附是很常見的疏漏。"""
    contexts = build_hierarchy(paragraphs)
    referenced = {}
    defined = set()

    for idx, text in enumerate(paragraphs, 1):
        for match in _ATTACHMENT_REF_RE.finditer(text):
            name = "%s%s" % (match.group(1), match.group(2))
            # 段落開頭就是「附表一」，視為附表本體而非引用
            if text.startswith(name):
                defined.add(name)
            else:
                referenced.setdefault(name, []).append(idx)

    findings = []
    for name, places in sorted(referenced.items()):
        if name in defined:
            continue
        findings.append(finding(
            MEDIUM, "附表引用",
            "條文提到「%s」，但全文找不到該附表的本體（%d 處引用）" % (name, len(places)),
            index=places[0], ref=contexts[places[0] - 1]["ref"],
            action="確認附表是否漏附，或引用名稱是否誤植"))
    return findings


# ---------------------------------------------------------------------------
# 輸出
# ---------------------------------------------------------------------------

SEVERITY_ORDER = {HIGH: 0, MEDIUM: 1, LOW: 2}


def report(findings):
    """依嚴重程度分級印出。"""
    print("\n" + "=" * 62)
    print("條文品質與風險檢查")
    print("=" * 62)

    if not findings:
        print("\n十項檢查都沒有發現問題。")
        print("=" * 62)
        return

    grouped = {}
    for item in findings:
        grouped.setdefault(item["severity"], []).append(item)

    labels = {HIGH: "高（送出前一定要處理或確認）",
              MEDIUM: "中（建議確認）",
              LOW: "低（格式與用語，不影響效力）"}

    for severity in (HIGH, MEDIUM, LOW):
        items = grouped.get(severity)
        if not items:
            continue
        print("\n【%s】共 %d 項" % (labels[severity], len(items)))
        for item in items:
            location = item["ref"] or (
                "第%d段" % item["index"] if item["index"] else "全文")
            print("  ● [%s] %s" % (item["check"], location))
            print("      %s" % item["detail"])
            if item["quote"]:
                print("      原文：%s" % item["quote"])
            if item["action"]:
                print("      建議：%s" % item["action"])

    print("\n" + "-" * 62)
    counts = {s: len(grouped.get(s, [])) for s in (HIGH, MEDIUM, LOW)}
    print("合計 %d 項（高 %d、中 %d、低 %d）"
          % (len(findings), counts[HIGH], counts[MEDIUM], counts[LOW]))
    print("提醒：這十項是規則明確、程式查得出來的部分。條文之間的邏輯矛盾、")
    print("      是否逾越母法授權，程式查不到，仍需人工或 LLM 複核。")
    print("=" * 62)


def write_csv(findings, output_path):
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["嚴重程度", "檢查項目", "位置", "段次", "說明",
                         "相關原文", "建議處理", "處理情形（人工填寫）"])
        for item in sorted(findings, key=lambda x: SEVERITY_ORDER[x["severity"]]):
            writer.writerow([
                item["severity"], item["check"],
                item["ref"] or "", item["index"] or "",
                item["detail"], item["quote"], item["action"], "",
            ])
    print("\n已產生檢查報告：%s" % output_path)


def main():
    setup_console()
    parser = argparse.ArgumentParser(description="Step 1.6：條文品質與風險檢查")
    parser.add_argument("regulation_file", help="新版內規檔案")
    parser.add_argument("--old", default=None,
                        help="舊版檔案；有給才能做責任用語、數值變更、施行日期三項檢查")
    parser.add_argument("--terms", default=None,
                        help="自訂用語對照表（JSON，格式為二維陣列）")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    print("正在讀取：%s" % args.regulation_file)
    paragraphs = read_paragraphs(args.regulation_file)
    print("全文共 %d 段。" % len(paragraphs))

    groups = DEFAULT_TERM_GROUPS
    if args.terms:
        with open(args.terms, encoding="utf-8") as f:
            groups = json.load(f)

    findings = []
    findings += check_article_integrity(
        paragraphs, read_paragraphs(args.old) if args.old else None)
    findings += check_external_refs(paragraphs)
    findings += check_placeholders(paragraphs)
    findings += check_format_consistency(paragraphs)
    findings += check_term_consistency(paragraphs, groups)
    findings += check_attachments(paragraphs)

    if args.old:
        print("正在比對舊版：%s" % args.old)
        old_paragraphs = read_paragraphs(args.old)
        results = diff_compare.compare_paragraphs(old_paragraphs, paragraphs)
        findings += check_modal_changes(results)
        findings += check_numeric_changes(results)
        findings += check_effective_date(paragraphs, results)
        findings += check_definitions(paragraphs, results)
    else:
        findings += check_definitions(paragraphs, [])
        print("提醒：沒有給 --old，責任用語變更、數值期間變更、施行日期三項無法檢查。")
        print("      這三項都是高風險項目，強烈建議加上舊版一起跑。")

    report(findings)
    if findings:
        write_csv(findings,
                  resolve_output(args.outdir, args.prefix, "條文檢查報告.csv"))
    return findings


if __name__ == "__main__":
    main()
