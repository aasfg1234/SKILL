# -*- coding: utf-8 -*-
"""
單次執行入口：一次跑完 Step 0.5 → 1 → 1.6 → 2

什麼時候用這支：
**執行之間檔案不保留的平台**。有些企業 AI 平台每次執行都給一個全新的暫存
工作目錄（實測 SPADE 就是這樣，兩次執行的目錄是 .tmp9oYOqV 與 .tmp4hmaGp），
上一次寫出來的檔案在下一次執行時根本不存在。

原本的分步流程是：
    Step 1 產出 修正對照表.csv  →  Step 2 用 --from-csv 讀它
中間檔一旦不能跨執行存活，這條路就斷了。

這支把四個步驟放在同一個 process 裡跑完，中間結果全部在記憶體裡傳遞，
不需要任何檔案跨執行存活。產出檔案一次寫齊，人要拿的時候一次拿走。

在檔案會保留的環境上，分步執行仍然可用而且更有彈性（可以只跑某一步、
可以中途調參數再跑）。這支是給不保留的環境用的。

使用方式：
    python run_all.py 舊版.docx 新版.docx
    python run_all.py 舊版.docx 新版.docx --outdir 產出 --title "○○要點修正對照表"
    python run_all.py 舊版.docx 新版.docx --apply-renumber   連款目重編一起做

參數大致與各分步腳本相同，詳見 --help。
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, build_hierarchy,
                     load_synonyms, load_table_format, resolve_output)
import diff_compare
import fuzzy_duplicate_finder as fuzzy
import renumber
import rule_checks


def banner(title):
    print("\n" + "=" * 66)
    print(title)
    print("=" * 66)


def step_renumber(old_paragraphs, new_paragraphs, apply_changes, rewrite_refs):
    """
    Step 0.5：款目編號檢查（以及選用的重編）。

    回傳可能已重編過的新版段落。不論有沒有 --apply-renumber，
    交叉引用的問題都會完整報告出來——那是人要處理的，不能默默跳過。
    """
    banner("Step 0.5　款目編號與交叉引用檢查")

    entries = renumber.scan(new_paragraphs)
    problems = renumber.find_numbering_gaps(entries)
    changes, clause_map, item_map = renumber.plan_renumber(new_paragraphs, entries)

    known_articles = {c["article"] for c in build_hierarchy(new_paragraphs)
                      if c["level"] == "條" and c["article"]}
    references = renumber.scan_references(
        new_paragraphs, entries, clause_map, item_map,
        known_articles=known_articles)

    deleted_articles = renumber.find_deleted_articles(old_paragraphs, new_paragraphs)
    drift = renumber.scan_reference_drift(old_paragraphs, new_paragraphs)

    renumber.report(problems, changes, deleted_articles, references, drift)

    if not changes:
        return new_paragraphs

    if not apply_changes:
        print("\n偵測到 %d 段需要重編，但沒有加 --apply-renumber，"
              "本次不更動編號。" % len(changes))
        print("後續步驟會以「未重編」的內容比對，對照表可能出現編號不連續的段落。")
        return new_paragraphs

    updated = renumber.apply_changes(new_paragraphs, changes, references, rewrite_refs)
    print("\n已重編 %d 段款目編號%s。"
          % (len(changes), "，並改寫可機械式處理的交叉引用" if rewrite_refs else ""))
    return updated


def step_diff(old_paragraphs, new_paragraphs, outdir, prefix, title,
              table_format):
    """Step 1：精確比對並產出全部檔案。回傳比對結果供後續步驟使用。"""
    banner("Step 1　精確文字比對")

    results = diff_compare.compare_paragraphs(old_paragraphs, new_paragraphs)

    counts = {"added": 0, "deleted": 0, "modified": 0, "renumbered": 0}
    for item in results:
        if item["type"] in counts:
            counts[item["type"]] += 1
    substantive = counts["added"] + counts["deleted"] + counts["modified"]

    print("實質異動 %d 處（新增 %d、刪除 %d、修改 %d）"
          % (substantive, counts["added"], counts["deleted"], counts["modified"]))
    if counts["renumbered"]:
        print("另有 %d 處只是編號調整，內容未變動。" % counts["renumbered"])

    produced = []
    csv_path = resolve_output(outdir, prefix, "修正對照表.csv")
    diff_compare.write_csv_report(results, csv_path)
    produced.append(csv_path)

    text_path = resolve_output(outdir, prefix, "標註版全文.txt")
    diff_compare.write_annotated_text(results, text_path)
    produced.append(text_path)

    annotated = resolve_output(outdir, prefix, "標註版全文.docx")
    diff_compare.export_to_docx(results, annotated, table_format=table_format)
    if os.path.exists(annotated):
        produced.append(annotated)

    table = resolve_output(outdir, prefix, "修正對照表.docx")
    diff_compare.export_table_to_docx(results, table, title=title,
                                      table_format=table_format)
    if os.path.exists(table):
        produced.append(table)

    return results, produced


def step_rule_checks(old_paragraphs, new_paragraphs, results, outdir, prefix, terms):
    """Step 1.6：十項條文品質與風險檢查。"""
    banner("Step 1.6　條文品質與風險檢查")

    findings = []
    findings += rule_checks.check_article_integrity(new_paragraphs, old_paragraphs)
    findings += rule_checks.check_external_refs(new_paragraphs)
    findings += rule_checks.check_placeholders(new_paragraphs)
    findings += rule_checks.check_format_consistency(new_paragraphs)
    findings += rule_checks.check_term_consistency(new_paragraphs, terms)
    findings += rule_checks.check_attachments(new_paragraphs)
    findings += rule_checks.check_definitions(new_paragraphs, results)
    findings += rule_checks.check_modal_changes(results)
    findings += rule_checks.check_numeric_changes(results)
    findings += rule_checks.check_effective_date(new_paragraphs, results)

    rule_checks.report(findings)

    produced = []
    if findings:
        path = resolve_output(outdir, prefix, "條文檢查報告.csv")
        rule_checks.write_csv(findings, path)
        produced.append(path)
    return findings, produced


def step_duplicates(new_paragraphs, results, outdir, prefix, threshold, top,
                    synonyms):
    """
    Step 2：跨章節重複條文。

    這裡直接吃 Step 1 的比對結果，不像分步版那樣去讀 修正對照表.csv——
    中間檔不必存在，也就不怕它在下一次執行時消失。
    """
    banner("Step 2　跨章節重複條文（最重要的一步）")

    # 缺 rapidfuzz 時一定要講。實測 1,199 段的內規，內建 difflib 抓到的候選數
    # 比 rapidfuzz 少約 7%——這是一個抓漏改的工具，少 7% 的候選要讓人知道。
    if not fuzzy.HAS_RAPIDFUZZ:
        print("提醒：這個環境沒有 rapidfuzz，改用 Python 內建的 difflib 比對。")
        print("      結果相近但不完全相同，實測大型內規的候選數約少 7%，")
        print("      人工複核時請留意可能有少數候選沒被列出。")

    if synonyms:
        print("已載入同義詞表：%d 組變體（用來抓「用詞完全換掉」的重複條文）"
              % len(synonyms))
    else:
        print("未使用同義詞表，只做純字面比對。")

    contexts = build_hierarchy(new_paragraphs)
    changes = []
    for item in results:
        if item["type"] == "unchanged":
            continue
        if item["type"] == "renumbered":
            continue      # 純編號位移，內容沒變，不需要找重複
        if item["type"] == "deleted":
            text, line_no = item["old_text"], None
        else:
            text, line_no = item["new_text"], item.get("new_index")
        if text:
            changes.append({"article_no": item.get("ref", ""), "text": text,
                            "line_number": line_no})

    if not changes:
        print("沒有實質異動，略過。")
        return [], []

    print("針對 %d 個異動段落比對全文 %d 段（門檻 %.0f%%）..."
          % (len(changes), len(new_paragraphs), threshold))

    csv_rows = []
    total = 0
    for change in changes:
        candidates = fuzzy.find_duplicates(
            change["text"], new_paragraphs, threshold=threshold, top=top,
            exclude_index=change["line_number"], contexts=contexts,
            synonyms=synonyms)
        total += len(candidates)
        fuzzy.print_candidates(change["text"], candidates, threshold)
        for candidate in candidates:
            csv_rows.append([
                change["article_no"], change["text"],
                candidate.get("scope", ""), candidate["article_no"],
                candidate["line_number"], candidate["text"],
                candidate["similarity"], candidate["fragment_len"],
                candidate.get("fragment_position", ""),
                candidate["common_fragment"],
                "、".join(candidate.get("synonym_evidence", [])), "",
            ])

    produced = []
    if csv_rows:
        path = resolve_output(outdir, prefix, "重複條文候選清單.csv")
        fuzzy.write_candidates_csv(csv_rows, path)
        produced.append(path)

    print("\n共列出 %d 筆候選。提醒：這是輔助抓取的建議，不保證完整覆蓋，"
          "最終仍需人工確認。" % total)
    return csv_rows, produced


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="單次執行：一次跑完 Step 0.5 → 1 → 1.6 → 2")
    parser.add_argument("old_file", help="舊版內規檔案（.docx / .txt / .md）")
    parser.add_argument("new_file", help="新版內規檔案（.docx / .txt / .md）")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    parser.add_argument("--title", default="修正對照表",
                        help="修正對照表 Word 檔的標題")
    parser.add_argument("--apply-renumber", action="store_true",
                        help="實際重編款目編號（預設只檢查不動）")
    parser.add_argument("--rewrite-refs", action="store_true",
                        help="連可機械式改寫的交叉引用一起改；"
                             "引用到已刪除款目的一律不動")
    parser.add_argument("--threshold", type=float, default=fuzzy.DEFAULT_THRESHOLD,
                        help="Step 2 相似度門檻，預設 %g" % fuzzy.DEFAULT_THRESHOLD)
    parser.add_argument("--top", type=int, default=fuzzy.DEFAULT_TOP,
                        help="每個異動段落最多列幾筆候選，預設 %d" % fuzzy.DEFAULT_TOP)
    parser.add_argument("--synonyms", default=None,
                        help="同義詞表路徑，預設用 scripts/synonyms.json")
    parser.add_argument("--no-synonyms", action="store_true",
                        help="關閉同義詞正規化，只做純字面比對")
    parser.add_argument("--format", default=None,
                        help="對照表版面設定檔，預設用 scripts/對照表格式.json")
    args = parser.parse_args()

    banner("內規修正比對　單次執行")
    print("舊版：%s" % args.old_file)
    print("新版：%s" % args.new_file)

    old_paragraphs = read_paragraphs(args.old_file)
    new_paragraphs = read_paragraphs(args.new_file)
    print("舊版 %d 段、新版 %d 段" % (len(old_paragraphs), len(new_paragraphs)))

    new_paragraphs = step_renumber(
        old_paragraphs, new_paragraphs, args.apply_renumber, args.rewrite_refs)

    produced = []
    results, files = step_diff(old_paragraphs, new_paragraphs,
                               args.outdir, args.prefix, args.title,
                               load_table_format(args.format))
    produced += files

    _, files = step_rule_checks(old_paragraphs, new_paragraphs, results,
                                args.outdir, args.prefix, None)
    produced += files

    synonyms = [] if args.no_synonyms else load_synonyms(args.synonyms)
    _, files = step_duplicates(new_paragraphs, results, args.outdir, args.prefix,
                               args.threshold, args.top, synonyms)
    produced += files

    # 重編過的話，把結果也寫出來，否則使用者手上沒有那份修好編號的全文
    if args.apply_renumber:
        path = resolve_output(args.outdir, args.prefix, "重編後_新版全文.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(new_paragraphs) + "\n")
        print("\n已產生重編後全文：%s" % path)
        produced.append(path)

    banner("產出檔案")
    print("以下檔案已寫入。若平台不會把檔案顯示在對話裡，請依路徑自行取用：\n")
    for path in produced:
        print("  %s" % path)
    print("\n共 %d 個檔案。" % len(produced))
    return produced


if __name__ == "__main__":
    main()
