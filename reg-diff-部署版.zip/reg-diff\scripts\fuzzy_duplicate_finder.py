# -*- coding: utf-8 -*-
"""
Step 2：跨章節重複條文抓取工具（模糊字串比對）── 整個流程最重要的一步

目的：
你修改了某一條規定，但同一個規定因為內規結構的關係，可能在別的章節
(壽險、產險、網路投保……)也各寫了一次，用詞因為實務作業需求略有調整。
只改一處就會漏改。這支程式把你改過的段落拿去跟全文其他段落比相似度，
把有嫌疑的都列出來，交給人工判斷。

原則：寧可多列、不要漏列。法規漏改的代價遠高於多花時間看候選清單。

--------------------------------------------------------------------------
重要：要傳「新版全文」，不是舊版
--------------------------------------------------------------------------
regulation_file 請傳「你已經改好的新版內規全文」。
傳舊版的話，你剛改掉的那一條的舊文字會以極高相似度霸佔候選第一名，
每一筆都被同一個假陽性佔位，等於白跑。

--------------------------------------------------------------------------
關於中文的相似度計算（跟舊版本的差別）
--------------------------------------------------------------------------
跟舊版有三個地方不一樣：

1) 不再用 token_sort_ratio。舊版用它並宣稱「即使詞語順序不一樣也能抓出相似度」，
   這對中文是錯的：token_sort 是靠空白切詞的，中文整句沒有空白會被當成單一 token，
   分數退化成跟 ratio 一模一樣（實測 token_sort / token_set / ratio 三者同分）。
   現在直接用 ratio，不再宣稱做不到的事。

2) 比對前先把條號拿掉。條號不是條文內容，卻會干擾分數——「第三條」對上
   「第二十二條」光這幾個字就先扣一截。實測拿掉條號後，真正相關的條文分數幾乎
   不動(53.1 -> 51.3)，不相干的卻從 22~32 掉到 11~18，訊號雜訊比明顯拉開。

3) 門檻從 70 下修到 45。實測資料：
     「逾期未繳超過三十日者，契約停止效力」
     vs「逾期未繳者，契約停止效力」              同一條漏改  83.9 分
     vs「保險費未於到期日後未繳納者，契約效力停止」 換句話說   51.3 分
     vs 同一份內規裡其他不相干條文                          11~18 分
   舊門檻 70 會漏掉「換句話說」那一類，正好就是本步驟要抓的東西；而 45 距離
   雜訊帶(18)還有很大的空間。原則是寧可多列、不要漏列。

代價是法規慣用語(「本公司應於……」「要保人應……」)會讓不相干的條文分數偏高。
所以輸出多附一欄「最長共同片段」：
  - 分數高、共同片段也長  → 很可能是真的重複條文
  - 分數高、共同片段很短  → 多半只是公文套語像，可以快速跳過
這一欄是給人看的分流線索，不參與門檻判斷。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
三種指定「你改了哪一段」的方法，擇一即可：

1) 直接貼上修改後的文字：
     python fuzzy_duplicate_finder.py 新版全文.docx "第三條 逾期未繳超過三十日者……"

2) 指定它在新版全文裡的段次（就是 Step 1 產出的 CSV 裡「新版段次」那一欄）：
     python fuzzy_duplicate_finder.py 新版全文.docx --changed-line 4

3) 一次跑完 Step 1 抓到的所有修改段落（實務上都用這個，不用手動跑 N 次）：
     python fuzzy_duplicate_finder.py 新版全文.docx --from-csv 修正對照表.csv

可調參數：
     --threshold 45   相似度門檻，調低抓得廣、雜訊多；調高會漏
     --top 15         每個修改段落最多列幾筆候選
"""

import argparse
import csv
import difflib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, build_hierarchy,
                     extract_article_no, format_scope, load_synonyms,
                     normalize_terms, strip_article_no, synonym_evidence,
                     resolve_output)

try:
    from rapidfuzz import fuzz
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False

DEFAULT_THRESHOLD = 45.0
DEFAULT_TOP = 15


def calc_similarity(text_a, text_b):
    """
    兩段文字的相似度，0~100，越高越像。傳進來的應該是已經去掉條號的條文本體。

    用 ratio(單純比字元重疊)。理由見檔頭說明：對中文而言 rapidfuzz 的
    token_sort_ratio / token_set_ratio 會退化成 ratio，用它們只是自欺欺人。
    沒裝 rapidfuzz 就退回 Python 內建 difflib，演算法相近，只是慢一點。
    """
    if HAS_RAPIDFUZZ:
        return float(fuzz.ratio(text_a, text_b))
    return difflib.SequenceMatcher(None, text_a, text_b).ratio() * 100.0


def longest_common_fragment(text_a, text_b):
    """
    兩段文字最長的一段完全相同的連續文字，以及這段文字從哪裡開始。

    回傳 (片段, 位置)，位置是「句首」「句中」或「句尾」。

    為什麼要標位置：
    片段長度單獨看會騙人。實測一份 50 頁的內規：真正被抄到別章的重複條文，
    共同片段 21 字；而一堆毫不相干的條文因為都用同一個句尾套語（「，作為內部
    控制制度有效運作之依據；但金額未達新臺幣十萬元者，得由單位主管逕行核定」），
    共同片段有 40 字，比真的重複還長。只看長度會把套語排在真貨前面。

    改看「片段從哪裡開始」就分得開了。同一份實測資料的 77 筆候選中：
        片段不是從句首開始的 44 筆 —— 全部是套語假陽性，沒有一筆是真的
        片段從句首開始的 33 筆 —— 包含全部 2 筆真的重複，其餘仍需人工判斷
    也就是說，這是個可靠的「排除」訊號，不是「確認」訊號：非句首幾乎可以直接
    跳過，句首則還是要看內容。
    """
    matcher = difflib.SequenceMatcher(None, text_a, text_b)
    match = matcher.find_longest_match(0, len(text_a), 0, len(text_b))
    fragment = text_a[match.a:match.a + match.size]
    if not fragment:
        return "", ""

    # 容許兩個字的誤差，開頭的主詞用字差異不影響判斷
    if match.a <= 2 and match.b <= 2:
        return fragment, "句首"
    # 落在候選條文後 40% 才開始的，通常就是但書、目的語那一段
    if match.b >= len(text_b) * 0.6:
        return fragment, "句尾"
    return fragment, "句中"


def find_duplicates(changed_text, all_paragraphs, threshold=DEFAULT_THRESHOLD,
                    top=DEFAULT_TOP, exclude_index=None, contexts=None,
                    synonyms=None):
    """
    拿修改過的文字去跟全文每一段比，回傳超過門檻的候選清單。

    exclude_index：要跳過的段次(從 1 起算)，通常就是被修改的那一段自己。
    沒指定的話，退而求其次跳過「文字完全相同」的段落。

    contexts：build_hierarchy() 算出的層級脈絡。有給的話，候選的條號會寫成
    「第三十三條第二款第二目」而不是只有「(二)」——候選清單是要拿去人工核對的，
    寫「(二)」等於叫人在 50 頁裡自己找。

    synonyms：同義詞表。有給的話，比對前先把「應繳金額」這類變體收斂成
    「保險費」，才抓得到用詞完全換掉的重複條文（實測 34 分拉到 56 分）。
    每一筆候選會一併記錄是哪一組詞讓它配對上的——不能只給分數不給理由。
    """
    changed_body = strip_article_no(changed_text)
    changed_norm, changed_applied = normalize_terms(changed_body, synonyms)

    candidates = []
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        if exclude_index is None and paragraph == changed_text:
            continue

        paragraph_body = strip_article_no(paragraph)
        paragraph_norm, paragraph_applied = normalize_terms(paragraph_body, synonyms)

        # 分數一律用正規化後的文字算。沒有同義詞命中時，正規化後就等於原文，
        # 分數也就等於純字面比對，不會憑空灌水。
        score = calc_similarity(changed_norm, paragraph_norm)
        if score >= threshold:
            fragment, position = longest_common_fragment(changed_norm, paragraph_norm)
            context = contexts[idx] if contexts else None
            evidence = synonym_evidence(changed_applied, paragraph_applied,
                                        changed_body, paragraph_body,
                                        synonyms or [])
            candidates.append({
                "line_number": line_no,
                "article_no": ((context["ref"] if context else "")
                               or extract_article_no(paragraph)),
                "scope": format_scope(context),
                "text": paragraph,
                "similarity": round(score, 1),
                "common_fragment": fragment,
                "fragment_len": len(fragment),
                "fragment_position": position,
                "synonym_evidence": evidence,
            })

    # 排序以相似度為主。同分時，共同片段從句首開始的排前面——實測顯示真正的
    # 重複條文都在這一類，非句首的則全是套語假陽性。
    candidates.sort(
        key=lambda c: (c["similarity"],
                       1 if c.get("fragment_position") == "句首" else 0,
                       c["fragment_len"]),
        reverse=True)
    return candidates[:top] if top and top > 0 else candidates


def print_candidates(changed_text, candidates, threshold):
    """把候選清單印出來。"""
    head = changed_text if len(changed_text) <= 40 else changed_text[:40] + "…"
    print("\n" + "=" * 60)
    print("修改段落：%s" % head)
    print("=" * 60)

    if not candidates:
        print("沒有找到相似度超過 %.0f%% 的候選條文。" % threshold)
        print("若你認為別的章節應該有對應條文，可以試著 --threshold 35 再跑一次。")
        return

    print("共 %d 筆候選（依相似度排序）：\n" % len(candidates))
    for i, c in enumerate(candidates, 1):
        label = c["article_no"] or ("第%d段" % c["line_number"])
        scope = c.get("scope")
        position = c.get("fragment_position", "")
        hint = "" if position == "句首" else "（%s起，多半是公文套語）" % position
        print("[候選%d] 相似度 %.1f%% ｜ %s%s（第%d段）｜ 共同片段 %d 字%s：%s"
              % (i, c["similarity"], (scope + " " if scope else ""), label,
                 c["line_number"], c["fragment_len"], hint, c["common_fragment"]))
        print("  內容：%s" % c["text"])
        if c.get("synonym_evidence"):
            # 一定要說明是哪一組詞讓它配對上的。法遵場合要能回答
            # 「為什麼系統認為這兩條相關」，只給分數不給理由沒有用。
            print("  經同義詞比對：%s" % "、".join(c["synonym_evidence"]))
        print()


def write_candidates_csv(rows, output_path):
    """把所有修改段落的候選清單寫成一份 CSV，方便逐筆勾選。"""
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["修改段落條號", "修改後文字", "候選章節", "候選條號",
                         "候選段次", "候選條文", "相似度", "最長共同片段字數",
                         "片段位置", "最長共同片段", "經同義詞比對",
                         "是否一併修改（人工填寫）"])
        for row in rows:
            writer.writerow(row)
    print("\n已產生候選清單：%s" % output_path)


def load_changes_from_csv(csv_path):
    """
    從 Step 1 產出的「修正對照表.csv」讀出所有修改段落。

    只取「新增」跟「修改」兩類：這兩類在新版全文裡有對應文字，可以拿去比對。
    「刪除」類在新版全文裡已經不存在，改用它的原文去比，找出「這條刪了，
    但別章還留著同樣的規定沒刪」的情況——這種漏刪一樣是法規風險。
    """
    changes = []
    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            change_type = (row.get("修改類型") or "").strip()
            if change_type == "刪除":
                text = (row.get("原文") or "").strip()
                line_no = None
            else:
                text = (row.get("修改後文字") or "").strip()
                raw_line = (row.get("新版段次") or "").strip()
                line_no = int(raw_line) if raw_line.isdigit() else None

            if not text or text.startswith("（無"):
                continue
            changes.append({
                "article_no": (row.get("條號") or "").strip(),
                "type": change_type,
                "text": text,
                "line_number": line_no,
            })
    return changes


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="Step 2：跨章節重複條文抓取（模糊字串比對）")
    parser.add_argument("regulation_file",
                        help="【新版】內規全文檔案（.docx / .txt / .md）")
    parser.add_argument("changed_text", nargs="?", default=None,
                        help="你修改後的那段文字；也可以改用 --changed-line 或 --from-csv")
    parser.add_argument("--changed-line", type=int, default=None,
                        help="修改段落在新版全文裡的段次（Step 1 的 CSV「新版段次」欄）")
    parser.add_argument("--from-csv", default=None,
                        help="Step 1 產出的 修正對照表.csv，一次比對所有修改段落")
    parser.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD,
                        help="相似度門檻 0~100，預設 %g" % DEFAULT_THRESHOLD)
    parser.add_argument("--top", type=int, default=DEFAULT_TOP,
                        help="每個修改段落最多列幾筆候選，預設 %d，設 0 表示全部列出" % DEFAULT_TOP)
    parser.add_argument("--synonyms", default=None,
                        help="同義詞表路徑，預設用 scripts/synonyms.json")
    parser.add_argument("--no-synonyms", action="store_true",
                        help="關閉同義詞正規化，只做純字面比對")
    parser.add_argument("--outdir", default="", help="輸出資料夾，預設為目前目錄")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    synonyms = [] if args.no_synonyms else load_synonyms(args.synonyms)
    if synonyms:
        print("已載入同義詞表：%d 組變體" % len(synonyms))
    else:
        print("未使用同義詞表，只做純字面比對。")

    if not HAS_RAPIDFUZZ:
        print("提醒：沒有安裝 rapidfuzz，改用內建 difflib（結果相近，大檔案會慢一些）。")
        print("      要加速請執行：python check_env.py\n")

    print("正在讀取新版內規全文：%s" % args.regulation_file)
    all_paragraphs = read_paragraphs(args.regulation_file)
    contexts = build_hierarchy(all_paragraphs)
    print("全文共 %d 段。" % len(all_paragraphs))

    # 決定要比對哪些段落
    if args.from_csv:
        changes = load_changes_from_csv(args.from_csv)
        if not changes:
            raise SystemExit("錯誤：%s 裡沒有讀到任何修改段落，請確認這是 Step 1 產出的對照表。"
                             % args.from_csv)
        print("從對照表讀到 %d 個修改段落，逐一比對（門檻 %.0f%%）..."
              % (len(changes), args.threshold))
    elif args.changed_line is not None:
        if not (1 <= args.changed_line <= len(all_paragraphs)):
            raise SystemExit("錯誤：--changed-line %d 超出範圍，全文只有 %d 段。"
                             % (args.changed_line, len(all_paragraphs)))
        text = all_paragraphs[args.changed_line - 1]
        changes = [{"article_no": extract_article_no(text), "type": "修改",
                    "text": text, "line_number": args.changed_line}]
    elif args.changed_text:
        changes = [{"article_no": extract_article_no(args.changed_text), "type": "修改",
                    "text": args.changed_text, "line_number": None}]
    else:
        raise SystemExit(
            "錯誤：要指定修改了哪一段。三選一：\n"
            "  直接貼文字   python fuzzy_duplicate_finder.py 新版全文.docx \"第三條 ……\"\n"
            "  指定段次     python fuzzy_duplicate_finder.py 新版全文.docx --changed-line 4\n"
            "  整份跑完     python fuzzy_duplicate_finder.py 新版全文.docx --from-csv 修正對照表.csv")

    csv_rows = []
    total_candidates = 0
    for change in changes:
        candidates = find_duplicates(
            change["text"], all_paragraphs,
            threshold=args.threshold, top=args.top,
            exclude_index=change["line_number"], contexts=contexts,
            synonyms=synonyms)
        total_candidates += len(candidates)
        print_candidates(change["text"], candidates, args.threshold)
        for c in candidates:
            csv_rows.append([
                change["article_no"], change["text"],
                c.get("scope", ""), c["article_no"], c["line_number"], c["text"],
                c["similarity"], c["fragment_len"],
                c.get("fragment_position", ""), c["common_fragment"],
                "、".join(c.get("synonym_evidence", [])), "",
            ])

    if csv_rows:
        write_candidates_csv(
            csv_rows, resolve_output(args.outdir, args.prefix, "重複條文候選清單.csv"))

    print("\n" + "-" * 60)
    print("比對完成：%d 個修改段落，共列出 %d 筆候選。" % (len(changes), total_candidates))
    print("提醒：這是 AI 輔助抓取的建議清單，不保證完整覆蓋，最終仍需人工確認。")
    print("-" * 60)

    return csv_rows


if __name__ == "__main__":
    main()
