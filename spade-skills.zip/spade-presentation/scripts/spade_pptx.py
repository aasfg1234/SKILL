"""
spade_pptx.py - Build a .pptx using ONLY the Python standard library.

Why this exists: SPADE has no python-pptx. A .pptx is a zip of XML parts, so we
write those parts by hand. No third-party imports, no home directory access, no
intermediate files that must survive between executions.

Usage:
    python spade_pptx.py outline.md -o deck.pptx
    python spade_pptx.py outline.md -o deck.pptx --accent 1F6FEB --read

Outline format: see references/outline-format.md
"""

import argparse
import os
import re
import sys
import zipfile
from xml.sax.saxutils import escape

EMU = 914400
W = 12192000          # 13.333 in
H = 6858000           # 7.5 in
ML = 838200           # 0.9 in left margin
MR = 838200
TITLE_Y = 594360
TITLE_H = 1188720
BODY_Y = 2011680
BODY_BOTTOM = 685800

NS_P = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"'

FONT_LATIN = "Segoe UI"
FONT_EA = "Microsoft JhengHei"


def _hex2rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    """t=0 全 a，t=1 全 b。"""
    ra, ga, ba = _hex2rgb(a)
    rb, gb, bb = _hex2rgb(b)
    return "%02X%02X%02X" % (int(ra + (rb - ra) * t), int(ga + (gb - ga) * t),
                             int(ba + (bb - ba) * t))


def tint(h, t):
    return mix(h, "FFFFFF", t)


def shade(h, t):
    return mix(h, "000000", t)


def lum(h):
    r, g, b = _hex2rgb(h)
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0


def on(h, dark_text="111827", light_text="FFFFFF"):
    """挑一個在 h 上面看得清楚的字色。"""
    return dark_text if lum(h) > 0.6 else light_text


# --------------------------------------------------------------------------
# 風格清單。使用者挑一個，或給一段說明由我們對到最接近的一個再調主色。
# --------------------------------------------------------------------------

STYLES = {
    "corporate": {
        "label": "商務藍",
        "desc": "白底、淡色標題帶、方正色塊。最安全的一種，像顧問公司的內部簡報。",
        "fit": "決策簡報、對內報告、月會",
        "accent": "1F6FEB", "bg": "FFFFFF", "ink": "111827",
        "header": "band", "cover": "full", "section": "dark", "prst": "rect",
    },
    "mono": {
        "label": "極簡黑白",
        "desc": "只有黑白灰，靠字級大小與粗線分層次。沒有任何彩色。",
        "fit": "專業服務、法遵、稽核、講究克制的場合",
        "accent": "111827", "bg": "FFFFFF", "ink": "111827",
        "header": "rule", "cover": "plain", "section": "dark", "prst": "rect",
    },
    "midnight": {
        "label": "深色簡報",
        "desc": "深藍近黑的底，亮藍重點。會議室燈關掉時最好看。",
        "fit": "產品發表、技術分享、對外演講",
        "accent": "38BDF8", "bg": "0B1220", "ink": "E5E9F0",
        "header": "block", "cover": "plain", "section": "accent", "prst": "rect",
    },
    "editorial": {
        "label": "暖色雜誌",
        "desc": "米白底、磚橘色、左側色塊封面。像雜誌內頁，不像 PowerPoint。",
        "fit": "對外提案、品牌、募資",
        "accent": "B4531A", "bg": "FBF7F0", "ink": "2A2521",
        "header": "rule", "cover": "split", "section": "dark", "prst": "rect",
    },
    "sage": {
        "label": "清新綠",
        "desc": "白底、低飽和綠松色、圓角色塊。柔和、不壓迫。",
        "fit": "教育訓練、ESG、醫療、內部溝通",
        "accent": "0F766E", "bg": "FFFFFF", "ink": "1F2937",
        "header": "band", "cover": "full", "section": "dark",
        "prst": "roundRect",
    },
    "alert": {
        "label": "高對比警示",
        "desc": "深色標題帶配磚紅重點。看起來嚴肅，適合講壞消息。",
        "fit": "風險報告、稽核發現、危機處理、問題檢討",
        "accent": "C2410C", "bg": "FFFFFF", "ink": "0F172A",
        "header": "block", "cover": "full", "section": "dark", "prst": "rect",
    },
}

DEFAULT_STYLE = "corporate"


class Style:
    """一個地方管完所有視覺決定。改這裡，全篇跟著改。"""

    def __init__(self, name=DEFAULT_STYLE, accent=None, read_mode=False):
        spec = STYLES.get((name or DEFAULT_STYLE).lower())
        if spec is None:
            raise SystemExit(
                "沒有這個風格：%s。可用的有：%s"
                % (name, "、".join(sorted(STYLES))))
        self.name = (name or DEFAULT_STYLE).lower()
        self.label = spec["label"]
        self.accent = (accent or spec["accent"]).upper().lstrip("#")
        self.bg = spec["bg"]
        self.ink = spec["ink"]
        self.header_mode = spec["header"]
        self.cover_mode = spec["cover"]
        self.section_mode = spec["section"]
        self.prst = spec["prst"]
        self.dark = lum(self.bg) < 0.5

        self.accent_dark = (tint(self.accent, 0.30) if self.dark
                            else shade(self.accent, 0.28))
        self.on_accent = on(self.accent)
        self.white = self.on_accent  # 舊名，代表「壓在主色上的字」

        if self.dark:
            self.panel = mix(self.bg, "FFFFFF", 0.07)
            self.tint_soft = mix(self.bg, "FFFFFF", 0.05)
            self.tint_strong = mix(self.bg, "FFFFFF", 0.12)
            self.hair = mix(self.bg, "FFFFFF", 0.20)
            self.muted = mix(self.ink, self.bg, 0.30)
            self.faint = mix(self.ink, self.bg, 0.52)
        else:
            self.panel = mix(tint(self.accent, 0.92), self.bg, 0.55)
            self.tint_soft = tint(self.accent, 0.94)
            self.tint_strong = tint(self.accent, 0.86)
            self.hair = tint(self.accent, 0.72)
            self.muted = mix(self.ink, "FFFFFF", 0.38)
            self.faint = mix(self.ink, "FFFFFF", 0.58)

        if self.header_mode == "block":
            self.head_fill = self.panel if self.dark else shade(self.ink, 0.08)
            self.head_text = self.ink if self.dark else "FFFFFF"
        elif self.header_mode == "band":
            self.head_fill = self.tint_soft
            self.head_text = self.ink
        else:
            self.head_fill = None
            self.head_text = self.ink

        if self.section_mode == "accent":
            self.section_bg = self.accent
            self.section_text = self.on_accent
            self.section_bar = self.section_text
        else:
            self.section_bg = (mix(self.bg, "FFFFFF", 0.10) if self.dark
                               else shade(self.ink, 0.25))
            self.section_text = "FFFFFF"
            self.section_bar = self.accent

        if self.dark:
            self.tile_fills = [self.accent,
                               mix(self.accent, self.bg, 0.30),
                               mix(self.accent, self.bg, 0.55)]
        elif lum(self.accent) < 0.30:
            # 主色本身就很深，再加深會變成三塊一樣黑，改成往背景色走
            self.tile_fills = [self.accent,
                               mix(self.accent, self.bg, 0.26),
                               mix(self.accent, self.bg, 0.46)]
        else:
            self.tile_fills = [self.accent, self.accent_dark,
                               mix(self.accent, self.ink, 0.45)]

        self.read = read_mode
        self.footer = ""
        self.sz_cover = 4400 if not read_mode else 3400
        self.sz_title = 2600 if not read_mode else 2100
        self.sz_lead = 1700 if not read_mode else 1350
        self.sz_body = 1600 if not read_mode else 1150
        self.sz_small = 1100 if not read_mode else 900
        self.sz_tiny = 900 if not read_mode else 800
        self.sz_num = 8000 if not read_mode else 6000


def style_menu():
    """給使用者看的風格清單。"""
    lines = ["可選的風格：", ""]
    for key in ["corporate", "mono", "midnight", "editorial", "sage", "alert"]:
        s = STYLES[key]
        lines.append("  %-10s %s" % (key, s["label"]))
        lines.append("             %s" % s["desc"])
        lines.append("             適合：%s" % s["fit"])
        lines.append("")
    lines.append("都不喜歡的話，用一句話描述你想要的感覺，")
    lines.append("再挑一個最接近的風格搭 --accent 換主色。")
    return "\n".join(lines)


# 版面尺度：邊界收窄、標題帶壓低，讓內容區變大
ML = 609600
MR = 609600
HEADER_H = 1417320
BAR_W = 91440
BODY_Y = 1691640
BODY_BOTTOM = 6035040
FOOT_Y = 6400800


def esc(t):
    return escape(t if t is not None else "")


def rpr(size, color, bold=False, italic=False):
    b = ' b="1"' if bold else ""
    i = ' i="1"' if italic else ""
    return (
        '<a:rPr lang="zh-TW" altLang="en-US" sz="%d"%s%s dirty="0">'
        '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>'
        '<a:latin typeface="%s"/><a:ea typeface="%s"/>'
        "</a:rPr>" % (size, b, i, color, FONT_LATIN, FONT_EA)
    )


def para(text, size, color, bold=False, italic=False, space_after=0,
         bullet=False, line_spacing=100, align=None):
    bits = ['<a:lnSpc><a:spcPct val="%d"/></a:lnSpc>' % (line_spacing * 1000)]
    if space_after:
        bits.append('<a:spcAft><a:spcPts val="%d"/></a:spcAft>' % space_after)
    if bullet:
        bits.append('<a:buFont typeface="Arial"/><a:buChar char="&#8226;"/>')
        indent = ' marL="228600" indent="-228600"'
    else:
        bits.append("<a:buNone/>")
        indent = ""
    algn = ' algn="%s"' % align if align else ""
    ppr = "<a:pPr%s%s>%s</a:pPr>" % (indent, algn, "".join(bits))
    if text == "":
        return "<a:p>%s</a:p>" % ppr
    return "<a:p>%s<a:r>%s<a:t>%s</a:t></a:r></a:p>" % (
        ppr, rpr(size, color, bold, italic), esc(text))


def textbox(sid, name, x, y, cx, cy, paragraphs, anchor="t", fill=None,
            line=None, dashed=False, pad=91440, prst="rect"):
    sp_fill = '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>' % fill if fill else "<a:noFill/>"
    sp_line = "<a:ln><a:noFill/></a:ln>"
    if line:
        dash = '<a:prstDash val="dash"/>' if dashed else ""
        sp_line = ('<a:ln w="12700"><a:solidFill><a:srgbClr val="%s"/>'
                   "</a:solidFill>%s</a:ln>" % (line, dash))
    return (
        "<p:sp><p:nvSpPr>"
        '<p:cNvPr id="%d" name="%s"/><p:cNvSpPr txBox="1"/><p:nvPr/>'
        "</p:nvSpPr>"
        '<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
        '<a:prstGeom prst="%s"><a:avLst/></a:prstGeom>%s%s</p:spPr>'
        '<p:txBody><a:bodyPr wrap="square" lIns="%d" tIns="%d" rIns="%d" '
        'bIns="%d" anchor="%s"><a:normAutofit/></a:bodyPr>'
        "<a:lstStyle/>%s</p:txBody></p:sp>"
        % (sid, esc(name), x, y, cx, cy, prst, sp_fill, sp_line, pad, pad // 2,
           pad, pad // 2, anchor, "".join(paragraphs))
    )


def rect(sid, x, y, cx, cy, fill, prst="rect"):
    return (
        "<p:sp><p:nvSpPr>"
        '<p:cNvPr id="%d" name="block"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
        '<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
        '<a:prstGeom prst="%s"><a:avLst/></a:prstGeom>'
        '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>'
        "<a:ln><a:noFill/></a:ln></p:spPr>"
        "<p:txBody><a:bodyPr/><a:lstStyle/><a:p/></p:txBody></p:sp>"
        % (sid, x, y, cx, cy, prst, fill)
    )


class Ids(object):
    def __init__(self, start=10):
        self.n = start

    def __call__(self):
        self.n += 1
        return self.n


# --------------------------------------------------------------------------
# 共用構件
# --------------------------------------------------------------------------

def header(s, sl, ids, eyebrow=None):
    """標題帶。三種模式：band 淡色帶、block 深色帶、rule 無底色加粗線。"""
    out = []
    if s.header_mode in ("band", "block"):
        out.append(rect(ids(), 0, 0, W, HEADER_H, s.head_fill))
        out.append(rect(ids(), 0, 0, BAR_W, HEADER_H, s.accent))
        title_color = s.head_text
        eyebrow_color = (s.accent if s.header_mode == "band"
                         else mix(s.head_text, s.head_fill, 0.35))
        page_color = s.accent if s.header_mode == "band" else s.head_text
    else:
        title_color = s.ink
        eyebrow_color = s.accent
        page_color = s.accent
        out.append(rect(ids(), ML, HEADER_H - 45720, W - ML - MR, 45720,
                        s.accent))
    paras = []
    if eyebrow:
        paras.append(para(eyebrow.upper(), s.sz_tiny, eyebrow_color, bold=True,
                          space_after=300))
    paras.append(para(sl["title"], s.sz_title, title_color, bold=True,
                      line_spacing=108))
    left = ML if s.header_mode != "rule" else ML
    out.append(textbox(ids(), "title", left, 0, W - left - MR - 914400,
                       HEADER_H - (91440 if s.header_mode == "rule" else 0),
                       paras, anchor="ctr", pad=0))
    if sl.get("_no"):
        out.append(textbox(ids(), "pageno", W - MR - 914400, 0, 914400,
                           HEADER_H,
                           [para("%02d" % sl["_no"], s.sz_lead, page_color,
                                 bold=True, align="r")], anchor="ctr", pad=0))
    return out


def build_cover(s, sl):
    ids = Ids(10)
    if s.cover_mode == "plain":
        out = [rect(ids(), 0, 0, W, H, s.bg),
               rect(ids(), ML, 1600200, 1828800, 91440, s.accent)]
        title_color, sub_color, meta_color = s.ink, s.muted, s.faint
        tx, tw = ML, W - ML - MR - 914400
    elif s.cover_mode == "split":
        block_w = int(W * 0.34)
        out = [rect(ids(), 0, 0, W, H, s.bg),
               rect(ids(), 0, 0, block_w, H, s.accent),
               rect(ids(), block_w - 68580, 0, 68580, H,
                    shade(s.accent, 0.22))]
        title_color, sub_color, meta_color = s.ink, s.muted, s.faint
        tx = block_w + 548640
        tw = W - tx - MR
    else:
        out = [rect(ids(), 0, 0, W, H, s.accent),
               rect(ids(), 0, H - 152400, W, 152400, s.accent_dark),
               rect(ids(), ML, 1600200, 1371600, 68580, s.on_accent)]
        title_color = s.on_accent
        sub_color = mix(s.on_accent, s.accent, 0.28)
        meta_color = mix(s.on_accent, s.accent, 0.45)
        tx, tw = ML, W - ML - MR - 914400
    out.append(textbox(ids(), "cover-title", tx, 1965960, tw, 2377440,
                       [para(sl["title"], s.sz_cover, title_color, bold=True,
                             line_spacing=112)], pad=0))
    meta = []
    if sl.get("sub"):
        meta.append(para(sl["sub"], s.sz_lead, sub_color, space_after=500))
    if sl.get("meta"):
        meta.append(para(sl["meta"], s.sz_small, meta_color))
    if meta:
        out.append(textbox(ids(), "cover-meta", tx, 4724400,
                           tw if s.cover_mode == "split" else W - ML - MR,
                           1066800, meta, anchor="b", pad=0))
    return "".join(out)


def build_section(s, sl):
    ids = Ids(20)
    out = [rect(ids(), 0, 0, W, H, s.section_bg),
           rect(ids(), 0, 0, BAR_W * 2, H, s.section_bar)]
    paras = []
    if sl.get("_no"):
        paras.append(para("%02d" % sl["_no"], s.sz_lead, s.section_bar,
                          bold=True, space_after=400))
    paras.append(para(sl["title"], s.sz_cover, s.section_text, bold=True))
    if sl.get("sub"):
        paras.append(para(sl["sub"], s.sz_lead,
                          mix(s.section_text, s.section_bg, 0.42),
                          line_spacing=110))
    out.append(textbox(ids(), "section", ML, 2286000, W - ML - MR, 2286000,
                       paras, anchor="ctr", pad=0))
    return "".join(out)


def chrome(s, sl, ids):
    """頁尾：細線 + 簡報名 + 頁碼。"""
    out = [rect(ids(), ML, FOOT_Y, W - ML - MR, 9525, s.hair)]
    left = s.footer or ""
    out.append(textbox(ids(), "foot", ML, FOOT_Y + 60960, W - ML - MR, 304800,
                       [para(left, s.sz_tiny, s.faint)], pad=0))
    if sl.get("_no") and sl.get("_total"):
        out.append(textbox(ids(), "footno", W - MR - 1219200, FOOT_Y + 60960,
                           1219200, 304800,
                           [para("%d / %d" % (sl["_no"], sl["_total"]),
                                 s.sz_tiny, s.faint, align="r")], pad=0))
    return out


def image_frame(s, sid, prompt, x, y, cx, cy, no):
    ratio = _ratio_text(cx, cy)
    head = para("圖 %s ｜ %s ｜ %.1f x %.1f 吋" % (no, ratio, cx / EMU, cy / EMU),
                s.sz_tiny, s.accent, bold=True, space_after=400)
    full_prompt = "%s. %s, no text or lettering in the image." % (
        prompt.rstrip("."), ratio)
    body = para(full_prompt, s.sz_tiny, s.muted, line_spacing=108)
    tail = para("整段複製去生圖，生好刪掉這個框，把圖片放回同一個位置。",
                s.sz_tiny, s.faint, italic=True)
    return textbox(sid, "image-prompt", x, y, cx, cy,
                   [head, body, para("", 700, s.faint), tail],
                   fill=s.tint_soft, line=s.accent, dashed=True, pad=137160)


def _ratio_text(cx, cy):
    r = cx / float(cy)
    for lim, label in [(0.5, "1:2 tall portrait format"),
                       (0.72, "2:3 portrait format"),
                       (0.9, "3:4 portrait format"),
                       (1.12, "1:1 square format"),
                       (1.45, "4:3 landscape format"),
                       (1.85, "16:9 widescreen format")]:
        if r < lim:
            return label
    return "21:9 ultrawide format"


def build_bullets(s, sl):
    """條列改成滿版的橫列：序號色塊 + 文字 + 分隔線，撐滿整個內容區。"""
    ids = Ids(30)
    out = header(s, sl, ids, sl.get("eyebrow"))
    out += chrome(s, sl, ids)

    has_img = bool(sl.get("image"))
    full = W - ML - MR
    text_w = int(full * 0.56) if has_img else full
    y = BODY_Y
    avail = BODY_BOTTOM - BODY_Y

    if sl.get("lead"):
        lead_h = 731520
        out.append(rect(ids(), ML, y, text_w, lead_h, s.tint_strong,
                        s.prst))
        out.append(rect(ids(), ML, y, BAR_W // 2, lead_h, s.accent))
        out.append(textbox(ids(), "lead", ML + 182880, y, text_w - 182880,
                           lead_h, [para(sl["lead"], s.sz_lead, s.accent_dark,
                                         bold=True, line_spacing=108)],
                           anchor="ctr", pad=91440))
        y += lead_h + 182880
        avail = BODY_BOTTOM - y

    bullets = sl.get("bullets", [])
    if bullets:
        n = len(bullets)
        row_h = avail // n
        chip = min(365760, row_h - 91440)
        for i, b in enumerate(bullets):
            ry = y + i * row_h
            if i:
                out.append(rect(ids(), ML, ry, text_w, 9525, s.hair))
            out.append(rect(ids(), ML, ry + (row_h - chip) // 2, chip, chip,
                            s.accent, s.prst))
            out.append(textbox(ids(), "n%d" % i, ML, ry + (row_h - chip) // 2,
                               chip, chip,
                               [para(str(i + 1), s.sz_small, s.white,
                                     bold=True, align="ctr")],
                               anchor="ctr", pad=0))
            out.append(textbox(ids(), "b%d" % i, ML + chip + 182880, ry,
                               text_w - chip - 182880, row_h,
                               [para(b, s.sz_body, s.ink, line_spacing=110)],
                               anchor="ctr", pad=45720))

    if has_img:
        img_x = ML + int(full * 0.60)
        out.append(image_frame(s, ids(), sl["image"], img_x, BODY_Y,
                               full - int(full * 0.60), BODY_BOTTOM - BODY_Y,
                               sl.get("imgno", "1")))
    if sl.get("note"):
        out.append(textbox(ids(), "note", ML, BODY_BOTTOM + 45720,
                           W - ML - MR, 274320,
                           [para(sl["note"], s.sz_tiny, s.faint)], pad=0))
    return "".join(out)


def build_stats(s, sl):
    """一到三個關鍵數字，做成滿版色塊。"""
    ids = Ids(40)
    out = header(s, sl, ids, sl.get("eyebrow"))
    out += chrome(s, sl, ids)
    nums = sl.get("nums") or []
    if not nums:
        nums = [(sl.get("num", ""), sl.get("cap", ""))]
    nums = nums[:3]
    full = W - ML - MR
    gap = 228600
    n = len(nums)
    w = (full - gap * (n - 1)) // n
    top = BODY_Y
    h = BODY_BOTTOM - BODY_Y
    fills = s.tile_fills
    for i, (num, cap) in enumerate(nums):
        x = ML + i * (w + gap)
        out.append(rect(ids(), x, top, w, h, fills[i % 3], s.prst))
        size = s.sz_num if n == 1 else int(s.sz_num * 0.62)
        paras = [para(num, size, s.white, bold=True, line_spacing=100,
                      align="ctr" if n > 1 else None, space_after=400)]
        if cap:
            paras.append(para(cap, s.sz_lead, tint(fills[i % 3], 0.78),
                              line_spacing=112,
                              align="ctr" if n > 1 else None))
        out.append(textbox(ids(), "stat%d" % i, x, top, w, h, paras,
                           anchor="ctr", pad=274320))
    if sl.get("note"):
        out.append(textbox(ids(), "note", ML, BODY_BOTTOM + 45720,
                           W - ML - MR, 274320,
                           [para(sl["note"], s.sz_tiny, s.faint)], pad=0))
    return "".join(out)


def build_cards(s, sl):
    """二到四張卡片並排，每張有色頭條。密度比條列高。"""
    ids = Ids(50)
    out = header(s, sl, ids, sl.get("eyebrow"))
    out += chrome(s, sl, ids)
    cards = (sl.get("cards") or sl.get("cols") or [])[:4]
    if not cards:
        return "".join(out)
    full = W - ML - MR
    gap = 205740
    n = len(cards)
    w = (full - gap * (n - 1)) // n
    top = BODY_Y
    h = BODY_BOTTOM - BODY_Y
    head_h = 640080
    for i, (head_text, items) in enumerate(cards):
        x = ML + i * (w + gap)
        out.append(rect(ids(), x, top, w, h, s.panel, s.prst))
        out.append(rect(ids(), x, top, w, head_h, s.accent, s.prst))
        out.append(textbox(ids(), "cardhead%d" % i, x, top, w, head_h,
                           [para(head_text, s.sz_lead, s.white, bold=True,
                                 line_spacing=100)], anchor="ctr",
                           pad=182880))
        if not items:
            continue
        body_top = top + head_h
        body_h = h - head_h
        rh = body_h // len(items)
        for j, it in enumerate(items):
            ry = body_top + j * rh
            if j:
                out.append(rect(ids(), x + 182880, ry, w - 365760, 9525,
                                s.hair))
            out.append(textbox(ids(), "card%d_%d" % (i, j), x, ry, w, rh,
                               [para(it, s.sz_body, s.ink, line_spacing=112)],
                               anchor="ctr", pad=182880))
    if sl.get("note"):
        out.append(textbox(ids(), "note", ML, BODY_BOTTOM + 45720,
                           W - ML - MR, 274320,
                           [para(sl["note"], s.sz_tiny, s.faint)], pad=0))
    return "".join(out)


def build_table(s, sl):
    """表格：第一列是色底表頭，其餘交替底色。密度最高的版型。"""
    ids = Ids(60)
    out = header(s, sl, ids, sl.get("eyebrow"))
    out += chrome(s, sl, ids)
    rows = sl.get("rows") or []
    if not rows:
        return "".join(out)
    full = W - ML - MR
    ncol = max(len(r) for r in rows)
    cw = full // ncol
    top = BODY_Y
    h = BODY_BOTTOM - BODY_Y
    rh = min(838200, h // len(rows))
    for ri, row in enumerate(rows):
        ry = top + ri * rh
        if ri == 0:
            out.append(rect(ids(), ML, ry, full, rh, s.accent, s.prst))
        elif ri % 2 == 0:
            out.append(rect(ids(), ML, ry, full, rh, s.tint_soft))
        for ci in range(ncol):
            cell = row[ci] if ci < len(row) else ""
            color = s.white if ri == 0 else s.ink
            out.append(textbox(ids(), "c%d_%d" % (ri, ci), ML + ci * cw, ry,
                               cw, rh,
                               [para(cell, s.sz_body, color, bold=(ri == 0),
                                     line_spacing=100)],
                               anchor="ctr", pad=137160))
    if sl.get("note"):
        out.append(textbox(ids(), "note", ML, BODY_BOTTOM + 45720,
                           W - ML - MR, 274320,
                           [para(sl["note"], s.sz_tiny, s.faint)], pad=0))
    return "".join(out)


def build_twocol(s, sl):
    return build_cards(s, sl)


BUILDERS = {
    "cover": build_cover,
    "section": build_section,
    "bullets": build_bullets,
    "bignum": build_stats,
    "stats": build_stats,
    "cards": build_cards,
    "twocol": build_twocol,
    "table": build_table,
}


# --------------------------------------------------------------------------
# OOXML skeleton. Hand-written because SPADE has no python-pptx.
# --------------------------------------------------------------------------

XML_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
REL_NS = 'xmlns="http://schemas.openxmlformats.org/package/2006/relationships"'
RT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
CT = "application/vnd.openxmlformats-officedocument.presentationml"

EMPTY_TREE = (
    '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/>'
    '<p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm>'
    '<a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
    '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/>'
    '</a:xfrm></p:grpSpPr></p:spTree>'
)

CLR_MAP = ('<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" '
           'accent2="accent2" accent3="accent3" accent4="accent4" '
           'accent5="accent5" accent6="accent6" hlink="hlink" '
           'folHlink="folHlink"/>')


def content_types(n_slides):
    parts = [
        XML_HEAD,
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        '<Default Extension="xml" ContentType="application/xml"/>',
        '<Override PartName="/ppt/presentation.xml" ContentType="%s.presentation.main+xml"/>' % CT,
        '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="%s.slideMaster+xml"/>' % CT,
        '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="%s.slideLayout+xml"/>' % CT,
        '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>',
    ]
    for i in range(1, n_slides + 1):
        parts.append('<Override PartName="/ppt/slides/slide%d.xml" ContentType="%s.slide+xml"/>' % (i, CT))
    parts.append('</Types>')
    return "".join(parts)


def root_rels():
    return ('%s<Relationships %s><Relationship Id="rId1" Type="%s/officeDocument"'
            ' Target="ppt/presentation.xml"/></Relationships>'
            % (XML_HEAD, REL_NS, RT))


def presentation_xml(n_slides):
    slds = "".join('<p:sldId id="%d" r:id="rId%d"/>' % (255 + i, i + 1)
                   for i in range(1, n_slides + 1))
    return (
        '%s<p:presentation %s saveSubsetFonts="1">'
        '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
        '<p:sldIdLst>%s</p:sldIdLst>'
        '<p:sldSz cx="%d" cy="%d"/><p:notesSz cx="6858000" cy="9144000"/>'
        '</p:presentation>' % (XML_HEAD, NS_P, slds, W, H)
    )


def presentation_rels(n_slides):
    rels = ['<Relationship Id="rId1" Type="%s/slideMaster" Target="slideMasters/slideMaster1.xml"/>' % RT]
    for i in range(1, n_slides + 1):
        rels.append('<Relationship Id="rId%d" Type="%s/slide" Target="slides/slide%d.xml"/>'
                    % (i + 1, RT, i))
    rels.append('<Relationship Id="rId%d" Type="%s/theme" Target="theme/theme1.xml"/>'
                % (n_slides + 2, RT))
    return "%s<Relationships %s>%s</Relationships>" % (XML_HEAD, REL_NS, "".join(rels))


def slide_master(bg):
    return (
        '%s<p:sldMaster %s><p:cSld><p:bg><p:bgPr>'
        '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>'
        '<a:effectLst/></p:bgPr></p:bg>%s</p:cSld>%s'
        '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>'
        '</p:sldMaster>' % (XML_HEAD, NS_P, bg, EMPTY_TREE, CLR_MAP)
    )


def slide_master_rels():
    return ('%s<Relationships %s>'
            '<Relationship Id="rId1" Type="%s/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
            '<Relationship Id="rId2" Type="%s/theme" Target="../theme/theme1.xml"/>'
            '</Relationships>' % (XML_HEAD, REL_NS, RT, RT))


def slide_layout():
    return (
        '%s<p:sldLayout %s type="blank" preserve="1">'
        '<p:cSld name="Blank">%s</p:cSld>'
        '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>'
        % (XML_HEAD, NS_P, EMPTY_TREE)
    )


def slide_layout_rels():
    return ('%s<Relationships %s>'
            '<Relationship Id="rId1" Type="%s/slideMaster" Target="../slideMasters/slideMaster1.xml"/>'
            '</Relationships>' % (XML_HEAD, REL_NS, RT))


def slide_xml(shapes, bg):
    return (
        '%s<p:sld %s><p:cSld><p:bg><p:bgPr>'
        '<a:solidFill><a:srgbClr val="%s"/></a:solidFill><a:effectLst/>'
        '</p:bgPr></p:bg>'
        '<p:spTree><p:nvGrpSpPr>'
        '<p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
        '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
        '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
        '%s</p:spTree></p:cSld>'
        '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'
        % (XML_HEAD, NS_P, bg, shapes)
    )


def slide_rels():
    return ('%s<Relationships %s>'
            '<Relationship Id="rId1" Type="%s/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
            '</Relationships>' % (XML_HEAD, REL_NS, RT))


def theme_xml(s):
    fills = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>' * 3
    lines = ('<a:ln w="6350" cap="flat" cmpd="sng" algn="ctr">'
             '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
             '<a:prstDash val="solid"/></a:ln>') * 3
    effects = '<a:effectStyle><a:effectLst/></a:effectStyle>' * 3
    return (
        '%s<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="SPADE">'
        '<a:themeElements>'
        '<a:clrScheme name="SPADE">'
        '<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1>'
        '<a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>'
        '<a:dk2><a:srgbClr val="%s"/></a:dk2>'
        '<a:lt2><a:srgbClr val="%s"/></a:lt2>'
        '<a:accent1><a:srgbClr val="%s"/></a:accent1>'
        '<a:accent2><a:srgbClr val="%s"/></a:accent2>'
        '<a:accent3><a:srgbClr val="0F766E"/></a:accent3>'
        '<a:accent4><a:srgbClr val="B45309"/></a:accent4>'
        '<a:accent5><a:srgbClr val="7C3AED"/></a:accent5>'
        '<a:accent6><a:srgbClr val="BE123C"/></a:accent6>'
        '<a:hlink><a:srgbClr val="%s"/></a:hlink>'
        '<a:folHlink><a:srgbClr val="7C3AED"/></a:folHlink>'
        '</a:clrScheme>'
        '<a:fontScheme name="SPADE">'
        '<a:majorFont><a:latin typeface="%s"/><a:ea typeface="%s"/><a:cs typeface=""/></a:majorFont>'
        '<a:minorFont><a:latin typeface="%s"/><a:ea typeface="%s"/><a:cs typeface=""/></a:minorFont>'
        '</a:fontScheme>'
        '<a:fmtScheme name="SPADE">'
        '<a:fillStyleLst>%s</a:fillStyleLst>'
        '<a:lnStyleLst>%s</a:lnStyleLst>'
        '<a:effectStyleLst>%s</a:effectStyleLst>'
        '<a:bgFillStyleLst>%s</a:bgFillStyleLst>'
        '</a:fmtScheme></a:themeElements>'
        '<a:objectDefaults/><a:extraClrSchemeLst/></a:theme>'
        % (XML_HEAD, s.ink, s.panel, s.accent, s.muted, s.accent,
           FONT_LATIN, FONT_EA, FONT_LATIN, FONT_EA,
           fills, lines, effects, fills)
    )


# --------------------------------------------------------------------------
# Outline parser
# --------------------------------------------------------------------------

TYPE_ALIAS = {
    "cover": "cover", "封面": "cover",
    "section": "section", "段落": "section", "章節": "section",
    "bullets": "bullets", "條列": "bullets", "內容": "bullets",
    "bignum": "stats", "stats": "stats", "大數字": "stats", "數字": "stats",
    "cards": "cards", "卡片": "cards", "三欄": "cards",
    "twocol": "cards", "兩欄": "cards", "雙欄": "cards",
    "table": "table", "表格": "table", "比較表": "table",
}

HEAD_RE = re.compile(r"^#\s*([^:：]+)[:：]\s*(.*)$")
KV_RE = re.compile(r"^(sub|meta|lead|num|cap|note|col|card|row|eyebrow)\s*[:：]\s*(.*)$")
IMG_RE = re.compile(r"^\[Image:\s*(.+?)\]\s*$", re.IGNORECASE)


def parse_outline(text):
    meta = {"accent": None, "mode": "stage", "style": DEFAULT_STYLE}
    body_lines = []
    for line in text.splitlines():
        if line.startswith("!"):
            if ":" in line:
                k, v = line[1:].split(":", 1)
                meta[k.strip().lower()] = v.strip()
            continue
        body_lines.append(line)

    slides = []
    warnings = []
    blocks = re.split(r"^\s*---\s*$", "\n".join(body_lines), flags=re.MULTILINE)
    img_no = 0
    for raw in blocks:
        block = raw.strip()
        if not block:
            continue
        sl = {"type": "bullets", "title": "", "bullets": [],
              "cards": [], "nums": [], "rows": []}
        for line in block.splitlines():
            line = line.rstrip()
            if not line.strip():
                continue
            m = HEAD_RE.match(line.strip())
            if m and not sl["title"]:
                key = m.group(1).strip().lower()
                sl["type"] = TYPE_ALIAS.get(key, "bullets")
                if key not in TYPE_ALIAS:
                    warnings.append("不認得的版型 '%s'，當成 bullets 處理" % key)
                sl["title"] = m.group(2).strip()
                continue
            m = IMG_RE.match(line.strip())
            if m:
                img_no += 1
                sl["image"] = m.group(1).strip()
                sl["imgno"] = str(img_no)
                if "]" in sl["image"]:
                    warnings.append("第 %d 頁的圖片提示詞含有 ] ，解析會被截斷"
                                    % (len(slides) + 1))
                continue
            m = KV_RE.match(line.strip())
            if m:
                k, v = m.group(1), m.group(2).strip()
                if k in ("col", "card"):
                    head, _, rest = v.partition("|")
                    items = [x.strip() for x in rest.split(";") if x.strip()]
                    sl["cards"].append((head.strip(), items))
                elif k == "row":
                    sl["rows"].append([x.strip() for x in v.split("|")])
                elif k == "num":
                    sl["nums"].append([v, ""])
                elif k == "cap":
                    if sl["nums"]:
                        sl["nums"][-1][1] = v
                    else:
                        sl["nums"].append(["", v])
                else:
                    sl[k] = v
                continue
            if line.strip().startswith("-"):
                sl["bullets"].append(line.strip().lstrip("-").strip())
                continue
            if not sl.get("lead"):
                sl["lead"] = line.strip()
            else:
                sl["bullets"].append(line.strip())
        if not sl["title"]:
            warnings.append("有一頁沒有標題，已跳過")
            continue
        slides.append(sl)
    return meta, slides, warnings


def lint(slides):
    out = []
    for i, sl in enumerate(slides, 1):
        t = sl["title"]
        if len(sl.get("bullets", [])) > 5:
            out.append("第 %d 頁有 %d 條條列，超過 5 條，建議拆頁"
                       % (i, len(sl["bullets"])))
        if len(t) > 34:
            out.append("第 %d 頁標題 %d 字，太長，壓到 30 字以內" % (i, len(t)))
        if sl["type"] in ("cards", "table") and len(sl.get("bullets", [])) > 0:
            out.append("第 %d 頁是 %s 版型，但寫了條列，那些條列不會出現"
                       % (i, sl["type"]))
        if sl["type"] == "table" and len(sl.get("rows", [])) < 2:
            out.append("第 %d 頁是表格版型，但只有 %d 列，至少要表頭加一列"
                       % (i, len(sl.get("rows", []))))
        if sl["type"] == "cards" and not sl.get("cards"):
            out.append("第 %d 頁是卡片版型，但一張卡片都沒寫" % i)
        if sl["type"] in ("bullets", "stats") and len(t) <= 6:
            out.append("第 %d 頁標題「%s」像題目不像結論，改寫成一句話判斷"
                       % (i, t))
    return out


# --------------------------------------------------------------------------
# Package
# --------------------------------------------------------------------------

def build_deck(outline_text, out_path):
    meta, slides, warnings = parse_outline(outline_text)
    if not slides:
        raise SystemExit("大綱裡沒有任何一頁，請檢查格式")
    style = Style(name=meta.get("style") or DEFAULT_STYLE,
                  accent=meta.get("accent"),
                  read_mode=(meta.get("mode") or "stage").lower() == "read")

    for sl in slides:
        if sl["type"] == "cover" and not style.footer:
            style.footer = sl["title"][:38]

    slide_parts = []
    prompts = []
    total = len(slides)
    for idx, sl in enumerate(slides, 1):
        sl["_no"] = idx
        sl["_total"] = total
        builder = BUILDERS.get(sl["type"], build_bullets)
        slide_parts.append(slide_xml(builder(style, sl), style.bg))
        if sl.get("image"):
            prompts.append((sl["imgno"], sl["title"], sl["image"]))

    n = len(slide_parts)
    z = zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED)
    try:
        z.writestr("[Content_Types].xml", content_types(n))
        z.writestr("_rels/.rels", root_rels())
        z.writestr("ppt/presentation.xml", presentation_xml(n))
        z.writestr("ppt/_rels/presentation.xml.rels", presentation_rels(n))
        z.writestr("ppt/slideMasters/slideMaster1.xml", slide_master(style.bg))
        z.writestr("ppt/slideMasters/_rels/slideMaster1.xml.rels", slide_master_rels())
        z.writestr("ppt/slideLayouts/slideLayout1.xml", slide_layout())
        z.writestr("ppt/slideLayouts/_rels/slideLayout1.xml.rels", slide_layout_rels())
        z.writestr("ppt/theme/theme1.xml", theme_xml(style))
        for i, part in enumerate(slide_parts, 1):
            z.writestr("ppt/slides/slide%d.xml" % i, part)
            z.writestr("ppt/slides/_rels/slide%d.xml.rels" % i, slide_rels())
    finally:
        z.close()
    return slides, prompts, warnings + lint(slides), style


def write_prompt_list(prompts, deck_path):
    if not prompts:
        return None
    base = os.path.splitext(os.path.basename(deck_path))[0]
    path = os.path.join(os.path.dirname(os.path.abspath(deck_path)),
                        base + "-圖片提示詞.md")
    lines = ["# %s 的圖片提示詞" % os.path.basename(deck_path), "",
             "共 %d 張圖。每一段整段複製，貼到生圖工具。" % len(prompts),
             "生好的圖存下來，回到簡報，刪掉虛線框，把圖片放進同一個位置。", ""]
    for no, title, prompt in prompts:
        lines.append("## 圖 %s" % no)
        lines.append("")
        lines.append("所在頁：%s" % title)
        lines.append("")
        lines.append("```text")
        lines.append(prompt)
        lines.append("```")
        lines.append("")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return path


def main():
    ap = argparse.ArgumentParser(
        description="用純標準函式庫產生 .pptx（給 SPADE 用，無 python-pptx）")
    ap.add_argument("outline", nargs="?", help="大綱 .md 檔")
    ap.add_argument("-o", "--output", default="deck.pptx", help="輸出的 .pptx")
    ap.add_argument("--style", help="風格，用 --list-styles 看清單")
    ap.add_argument("--list-styles", action="store_true",
                    help="印出風格清單就結束")
    ap.add_argument("--accent", help="換主色，六碼十六進位，例如 1F6FEB。"
                                     "可以跟 --style 一起用")
    ap.add_argument("--read", action="store_true",
                    help="寄出去自己讀的版本（字級較小、可放較多字）")
    args = ap.parse_args()

    if args.list_styles:
        print(style_menu())
        return 0
    if not args.outline:
        ap.error("要給大綱檔，或用 --list-styles 看風格清單")

    with open(args.outline, "r", encoding="utf-8") as f:
        text = f.read()
    if args.style:
        text = "!style: %s\n" % args.style + text
    if args.accent:
        text = "!accent: %s\n" % args.accent + text
    if args.read:
        text = "!mode: read\n" + text

    slides, prompts, warnings, style = build_deck(text, args.output)
    listfile = write_prompt_list(prompts, args.output)

    print("已產生 %s" % args.output)
    print("  風格：%s（%s）" % (style.label, style.name))
    print("  頁數：%d" % len(slides))
    print("  圖片提示詞：%d 段" % len(prompts))
    if listfile:
        print("  清單檔：%s" % listfile)
    if warnings:
        print("")
        print("要處理的事：")
        for w in warnings:
            print("  - %s" % w)
    else:
        print("  檢查沒發現問題")
    return 0


if __name__ == "__main__":
    sys.exit(main())
