"""
spade_pptx.py - Build a .pptx using ONLY the Python standard library.

Why this exists: SPADE has no python-pptx. A .pptx is a zip of XML parts, so we
write those parts by hand. No third-party imports, no home directory access, no
intermediate files that must survive between executions.

Usage:
    python spade_pptx.py outline.md -o deck.pptx
    python spade_pptx.py outline.md -o deck.pptx --accent 1F6FEB --read

Outline format: see references/outline-format.md
"""

import argparse
import os
import re
import sys
import zipfile
from xml.sax.saxutils import escape

EMU = 914400
W = 12192000          # 13.333 in
H = 6858000           # 7.5 in
ML = 838200           # 0.9 in left margin
MR = 838200
TITLE_Y = 594360
TITLE_H = 1188720
BODY_Y = 2011680
BODY_BOTTOM = 685800

NS_P = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"'

FONT_LATIN = "Segoe UI"
FONT_EA = "Microsoft JhengHei"


class Style:
    """One place for every visual decision. Change here, whole deck follows."""

    def __init__(self, accent="1F6FEB", read_mode=False):
        self.accent = accent.upper().lstrip("#")
        self.ink = "111827"
        self.muted = "6B7280"
        self.faint = "94A3B8"
        self.panel = "F8FAFC"
        self.bg = "FFFFFF"
        self.read = read_mode
        # read_mode = deck is emailed and read alone -> smaller type, more text
        self.sz_cover = 4000 if not read_mode else 3200
        self.sz_title = 2800 if not read_mode else 2200
        self.sz_lead = 2000 if not read_mode else 1500
        self.sz_body = 1800 if not read_mode else 1200
        self.sz_small = 1200 if not read_mode else 900
        self.sz_num = 14000 if not read_mode else 10000


def esc(t):
    return escape(t if t is not None else "")


def rpr(size, color, bold=False, italic=False):
    b = ' b="1"' if bold else ""
    i = ' i="1"' if italic else ""
    return (
        '<a:rPr lang="zh-TW" altLang="en-US" sz="%d"%s%s dirty="0">'
        '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>'
        '<a:latin typeface="%s"/><a:ea typeface="%s"/>'
        "</a:rPr>" % (size, b, i, color, FONT_LATIN, FONT_EA)
    )


def para(text, size, color, bold=False, italic=False, space_after=0,
         bullet=False, line_spacing=100):
    ppr_bits = []
    if space_after:
        ppr_bits.append('<a:spcAft><a:spcPts val="%d"/></a:spcAft>' % space_after)
    ppr_bits.append('<a:lnSpc><a:spcPct val="%d"/></a:lnSpc>' % (line_spacing * 1000))
    if bullet:
        ppr_bits.append('<a:buFont typeface="Arial"/><a:buChar char="&#8226;"/>')
        indent = ' marL="228600" indent="-228600"'
    else:
        ppr_bits.append("<a:buNone/>")
        indent = ""
    ppr = "<a:pPr%s>%s</a:pPr>" % (indent, "".join(ppr_bits))
    if text == "":
        return "<a:p>%s</a:p>" % ppr
    return '<a:p>%s<a:r>%s<a:t>%s</a:t></a:r></a:p>' % (
        ppr, rpr(size, color, bold, italic), esc(text))


def textbox(sid, name, x, y, cx, cy, paragraphs, anchor="t", wrap=True,
            fill=None, line=None, dashed=False):
    sp_fill = ""
    if fill:
        sp_fill = '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>' % fill
    sp_line = "<a:ln><a:noFill/></a:ln>"
    if line:
        dash = '<a:prstDash val="dash"/>' if dashed else ""
        sp_line = ('<a:ln w="12700"><a:solidFill><a:srgbClr val="%s"/>'
                   "</a:solidFill>%s</a:ln>" % (line, dash))
    wrap_attr = "square" if wrap else "none"
    return (
        "<p:sp><p:nvSpPr>"
        '<p:cNvPr id="%d" name="%s"/><p:cNvSpPr txBox="1"/><p:nvPr/>'
        "</p:nvSpPr>"
        '<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>%s%s</p:spPr>'
        '<p:txBody><a:bodyPr wrap="%s" lIns="91440" tIns="91440" rIns="91440" '
        'bIns="91440" anchor="%s"><a:normAutofit/></a:bodyPr>'
        "<a:lstStyle/>%s</p:txBody></p:sp>"
        % (sid, esc(name), x, y, cx, cy, sp_fill, sp_line, wrap_attr, anchor,
           "".join(paragraphs))
    )


def rule(sid, x, y, cx, color, h=25400):
    return (
        "<p:sp><p:nvSpPr>"
        '<p:cNvPr id="%d" name="rule"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
        '<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
        '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>'
        "<a:ln><a:noFill/></a:ln></p:spPr>"
        "<p:txBody><a:bodyPr/><a:lstStyle/><a:p/></p:txBody></p:sp>"
        % (sid, x, y, cx, h, color)
    )


# --------------------------------------------------------------------------
# slide builders. Every one returns the <p:spTree> children as a string.
# --------------------------------------------------------------------------

def build_cover(s, sl):
    sid = [10]
    def nid():
        sid[0] += 1
        return sid[0]
    out = [rule(nid(), ML, 1600200, 1097280, s.accent, 50800)]
    out.append(textbox(nid(), "cover-title", ML, 1905000, W - ML - MR, 2286000,
                       [para(sl["title"], s.sz_cover, s.ink, bold=True,
                             line_spacing=112)], anchor="t"))
    meta = []
    if sl.get("sub"):
        meta.append(para(sl["sub"], s.sz_lead, s.muted, space_after=600))
    if sl.get("meta"):
        meta.append(para(sl["meta"], s.sz_small, s.muted))
    if meta:
        out.append(textbox(nid(), "cover-meta", ML, 4876800, W - ML - MR,
                           1143000, meta, anchor="b"))
    return "".join(out)


def build_section(s, sl):
    sid = [20]
    def nid():
        sid[0] += 1
        return sid[0]
    out = [rule(nid(), ML, 3086100, 685800, s.accent, 50800)]
    out.append(textbox(nid(), "section-title", ML, 3352800, W - ML - MR,
                       1371600, [para(sl["title"], s.sz_cover, s.ink, bold=True)]))
    if sl.get("sub"):
        out.append(textbox(nid(), "section-sub", ML, 2514600, W - ML - MR,
                           457200, [para(sl["sub"], s.sz_small, s.muted)]))
    return "".join(out)


def _title_block(s, sl, nid, width):
    out = [textbox(nid(), "title", ML, TITLE_Y, width, TITLE_H,
                   [para(sl["title"], s.sz_title, s.ink, bold=True,
                         line_spacing=112)], anchor="b")]
    out.append(rule(nid(), ML, TITLE_Y + TITLE_H + 114300, 685800, s.accent))
    return out


def build_bullets(s, sl):
    sid = [30]
    def nid():
        sid[0] += 1
        return sid[0]
    has_img = bool(sl.get("image"))
    full = W - ML - MR
    text_w = int(full * 0.56) if has_img else full
    out = _title_block(s, sl, nid, full)
    paras = []
    if sl.get("lead"):
        paras.append(para(sl["lead"], s.sz_lead, s.accent, bold=True,
                          space_after=900, line_spacing=110))
    for b in sl.get("bullets", []):
        paras.append(para(b, s.sz_body, s.ink, bullet=True, space_after=700,
                          line_spacing=110))
    if not paras:
        paras = [para("", s.sz_body, s.ink)]
    body_h = H - BODY_Y - BODY_BOTTOM
    out.append(textbox(nid(), "body", ML, BODY_Y, text_w, body_h, paras))
    if has_img:
        img_x = ML + int(full * 0.62)
        img_w = full - int(full * 0.62)
        out.append(image_frame(s, nid(), sl["image"], img_x, BODY_Y, img_w,
                               body_h, sl.get("imgno", "1")))
    if sl.get("note"):
        out.append(textbox(nid(), "note", ML, H - 594360, full, 342900,
                           [para(sl["note"], s.sz_small, s.muted)]))
    return "".join(out)


def build_bignum(s, sl):
    sid = [40]
    def nid():
        sid[0] += 1
        return sid[0]
    full = W - ML - MR
    out = _title_block(s, sl, nid, full)
    out.append(textbox(nid(), "num", ML, BODY_Y + 228600, full, 1828800,
                       [para(sl.get("num", ""), s.sz_num, s.accent, bold=True,
                             line_spacing=100)]))
    if sl.get("cap"):
        out.append(textbox(nid(), "cap", ML, BODY_Y + 2286000, full, 914400,
                           [para(sl["cap"], s.sz_lead, s.ink)]))
    if sl.get("note"):
        out.append(textbox(nid(), "note", ML, H - 594360, full, 342900,
                           [para(sl["note"], s.sz_small, s.muted)]))
    return "".join(out)


def build_twocol(s, sl):
    sid = [50]
    def nid():
        sid[0] += 1
        return sid[0]
    full = W - ML - MR
    gap = 457200
    col_w = (full - gap) // 2
    out = _title_block(s, sl, nid, full)
    body_h = H - BODY_Y - BODY_BOTTOM
    for i, col in enumerate(sl.get("cols", [])[:2]):
        head, rest = col
        paras = [para(head, s.sz_lead, s.accent, bold=True, space_after=800)]
        for line in rest:
            paras.append(para(line, s.sz_body, s.ink, bullet=True,
                              space_after=600, line_spacing=110))
        out.append(textbox(nid(), "col%d" % i, ML + i * (col_w + gap), BODY_Y,
                           col_w, body_h, paras, fill=s.panel))
    return "".join(out)


def image_frame(s, sid, prompt, x, y, cx, cy, no):
    ratio = _ratio_text(cx, cy)
    head = para("圖 %s  %s  %.1f x %.1f 吋" % (no, ratio, cx / EMU, cy / EMU),
                s.sz_small, s.faint, bold=True, space_after=500)
    full_prompt = "%s. %s, no text or lettering in the image." % (
        prompt.rstrip("."), ratio)
    body = para(full_prompt, max(900, s.sz_small - 200), s.muted,
                line_spacing=105)
    tail = para("把上面整段英文複製去生圖，生好後刪掉這個框，插入圖片。",
                max(800, s.sz_small - 300), s.faint, italic=True)
    return textbox(sid, "image-prompt", x, y, cx, cy,
                   [head, body, para("", 800, s.faint), tail],
                   fill=s.panel, line=s.faint, dashed=True)


def _ratio_text(cx, cy):
    r = cx / float(cy)
    table = [(0.5, "1:2 tall portrait format"), (0.72, "2:3 portrait format"),
             (0.9, "3:4 portrait format"), (1.12, "1:1 square format"),
             (1.45, "4:3 landscape format"), (1.85, "16:9 widescreen format"),
             (99.0, "21:9 ultrawide format")]
    for lim, label in table:
        if r < lim:
            return label
    return "16:9 widescreen format"


BUILDERS = {
    "cover": build_cover,
    "section": build_section,
    "bullets": build_bullets,
    "bignum": build_bignum,
    "twocol": build_twocol,
}


# --------------------------------------------------------------------------
# OOXML skeleton. Hand-written because SPADE has no python-pptx.
# --------------------------------------------------------------------------

XML_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
REL_NS = 'xmlns="http://schemas.openxmlformats.org/package/2006/relationships"'
RT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
CT = "application/vnd.openxmlformats-officedocument.presentationml"

EMPTY_TREE = (
    '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/>'
    '<p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm>'
    '<a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
    '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/>'
    '</a:xfrm></p:grpSpPr></p:spTree>'
)

CLR_MAP = ('<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" '
           'accent2="accent2" accent3="accent3" accent4="accent4" '
           'accent5="accent5" accent6="accent6" hlink="hlink" '
           'folHlink="folHlink"/>')


def content_types(n_slides):
    parts = [
        XML_HEAD,
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        '<Default Extension="xml" ContentType="application/xml"/>',
        '<Override PartName="/ppt/presentation.xml" ContentType="%s.presentation.main+xml"/>' % CT,
        '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="%s.slideMaster+xml"/>' % CT,
        '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="%s.slideLayout+xml"/>' % CT,
        '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>',
    ]
    for i in range(1, n_slides + 1):
        parts.append('<Override PartName="/ppt/slides/slide%d.xml" ContentType="%s.slide+xml"/>' % (i, CT))
    parts.append('</Types>')
    return "".join(parts)


def root_rels():
    return ('%s<Relationships %s><Relationship Id="rId1" Type="%s/officeDocument"'
            ' Target="ppt/presentation.xml"/></Relationships>'
            % (XML_HEAD, REL_NS, RT))


def presentation_xml(n_slides):
    slds = "".join('<p:sldId id="%d" r:id="rId%d"/>' % (255 + i, i + 1)
                   for i in range(1, n_slides + 1))
    return (
        '%s<p:presentation %s saveSubsetFonts="1">'
        '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
        '<p:sldIdLst>%s</p:sldIdLst>'
        '<p:sldSz cx="%d" cy="%d"/><p:notesSz cx="6858000" cy="9144000"/>'
        '</p:presentation>' % (XML_HEAD, NS_P, slds, W, H)
    )


def presentation_rels(n_slides):
    rels = ['<Relationship Id="rId1" Type="%s/slideMaster" Target="slideMasters/slideMaster1.xml"/>' % RT]
    for i in range(1, n_slides + 1):
        rels.append('<Relationship Id="rId%d" Type="%s/slide" Target="slides/slide%d.xml"/>'
                    % (i + 1, RT, i))
    rels.append('<Relationship Id="rId%d" Type="%s/theme" Target="theme/theme1.xml"/>'
                % (n_slides + 2, RT))
    return "%s<Relationships %s>%s</Relationships>" % (XML_HEAD, REL_NS, "".join(rels))


def slide_master(bg):
    return (
        '%s<p:sldMaster %s><p:cSld><p:bg><p:bgPr>'
        '<a:solidFill><a:srgbClr val="%s"/></a:solidFill>'
        '<a:effectLst/></p:bgPr></p:bg>%s</p:cSld>%s'
        '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>'
        '</p:sldMaster>' % (XML_HEAD, NS_P, bg, EMPTY_TREE, CLR_MAP)
    )


def slide_master_rels():
    return ('%s<Relationships %s>'
            '<Relationship Id="rId1" Type="%s/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
            '<Relationship Id="rId2" Type="%s/theme" Target="../theme/theme1.xml"/>'
            '</Relationships>' % (XML_HEAD, REL_NS, RT, RT))


def slide_layout():
    return (
        '%s<p:sldLayout %s type="blank" preserve="1">'
        '<p:cSld name="Blank">%s</p:cSld>'
        '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>'
        % (XML_HEAD, NS_P, EMPTY_TREE)
    )


def slide_layout_rels():
    return ('%s<Relationships %s>'
            '<Relationship Id="rId1" Type="%s/slideMaster" Target="../slideMasters/slideMaster1.xml"/>'
            '</Relationships>' % (XML_HEAD, REL_NS, RT))


def slide_xml(shapes, bg):
    return (
        '%s<p:sld %s><p:cSld><p:bg><p:bgPr>'
        '<a:solidFill><a:srgbClr val="%s"/></a:solidFill><a:effectLst/>'
        '</p:bgPr></p:bg>'
        '<p:spTree><p:nvGrpSpPr>'
        '<p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
        '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
        '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
        '%s</p:spTree></p:cSld>'
        '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'
        % (XML_HEAD, NS_P, bg, shapes)
    )


def slide_rels():
    return ('%s<Relationships %s>'
            '<Relationship Id="rId1" Type="%s/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
            '</Relationships>' % (XML_HEAD, REL_NS, RT))


def theme_xml(s):
    fills = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>' * 3
    lines = ('<a:ln w="6350" cap="flat" cmpd="sng" algn="ctr">'
             '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
             '<a:prstDash val="solid"/></a:ln>') * 3
    effects = '<a:effectStyle><a:effectLst/></a:effectStyle>' * 3
    return (
        '%s<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="SPADE">'
        '<a:themeElements>'
        '<a:clrScheme name="SPADE">'
        '<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1>'
        '<a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>'
        '<a:dk2><a:srgbClr val="%s"/></a:dk2>'
        '<a:lt2><a:srgbClr val="%s"/></a:lt2>'
        '<a:accent1><a:srgbClr val="%s"/></a:accent1>'
        '<a:accent2><a:srgbClr val="%s"/></a:accent2>'
        '<a:accent3><a:srgbClr val="0F766E"/></a:accent3>'
        '<a:accent4><a:srgbClr val="B45309"/></a:accent4>'
        '<a:accent5><a:srgbClr val="7C3AED"/></a:accent5>'
        '<a:accent6><a:srgbClr val="BE123C"/></a:accent6>'
        '<a:hlink><a:srgbClr val="%s"/></a:hlink>'
        '<a:folHlink><a:srgbClr val="7C3AED"/></a:folHlink>'
        '</a:clrScheme>'
        '<a:fontScheme name="SPADE">'
        '<a:majorFont><a:latin typeface="%s"/><a:ea typeface="%s"/><a:cs typeface=""/></a:majorFont>'
        '<a:minorFont><a:latin typeface="%s"/><a:ea typeface="%s"/><a:cs typeface=""/></a:minorFont>'
        '</a:fontScheme>'
        '<a:fmtScheme name="SPADE">'
        '<a:fillStyleLst>%s</a:fillStyleLst>'
        '<a:lnStyleLst>%s</a:lnStyleLst>'
        '<a:effectStyleLst>%s</a:effectStyleLst>'
        '<a:bgFillStyleLst>%s</a:bgFillStyleLst>'
        '</a:fmtScheme></a:themeElements>'
        '<a:objectDefaults/><a:extraClrSchemeLst/></a:theme>'
        % (XML_HEAD, s.ink, s.panel, s.accent, s.muted, s.accent,
           FONT_LATIN, FONT_EA, FONT_LATIN, FONT_EA,
           fills, lines, effects, fills)
    )


# --------------------------------------------------------------------------
# Outline parser
# --------------------------------------------------------------------------

TYPE_ALIAS = {
    "cover": "cover", "封面": "cover",
    "section": "section", "段落": "section", "章節": "section",
    "bullets": "bullets", "條列": "bullets", "內容": "bullets",
    "bignum": "bignum", "大數字": "bignum", "數字": "bignum",
    "twocol": "twocol", "兩欄": "twocol", "雙欄": "twocol",
}

HEAD_RE = re.compile(r"^#\s*([^:：]+)[:：]\s*(.*)$")
KV_RE = re.compile(r"^(sub|meta|lead|num|cap|note|col)\s*[:：]\s*(.*)$")
IMG_RE = re.compile(r"^\[Image:\s*(.+?)\]\s*$", re.IGNORECASE)


def parse_outline(text):
    meta = {"accent": "1F6FEB", "mode": "stage", "title": "deck"}
    body_lines = []
    for line in text.splitlines():
        if line.startswith("!"):
            if ":" in line:
                k, v = line[1:].split(":", 1)
                meta[k.strip().lower()] = v.strip()
            continue
        body_lines.append(line)

    slides = []
    warnings = []
    blocks = re.split(r"^\s*---\s*$", "\n".join(body_lines), flags=re.MULTILINE)
    img_no = 0
    for raw in blocks:
        block = raw.strip()
        if not block:
            continue
        sl = {"type": "bullets", "title": "", "bullets": [], "cols": []}
        for line in block.splitlines():
            line = line.rstrip()
            if not line.strip():
                continue
            m = HEAD_RE.match(line.strip())
            if m and not sl["title"]:
                key = m.group(1).strip().lower()
                sl["type"] = TYPE_ALIAS.get(key, "bullets")
                if key not in TYPE_ALIAS:
                    warnings.append("不認得的版型 '%s'，當成 bullets 處理" % key)
                sl["title"] = m.group(2).strip()
                continue
            m = IMG_RE.match(line.strip())
            if m:
                img_no += 1
                sl["image"] = m.group(1).strip()
                sl["imgno"] = str(img_no)
                if "]" in sl["image"]:
                    warnings.append("第 %d 頁的圖片提示詞含有 ] ，解析會被截斷"
                                    % (len(slides) + 1))
                continue
            m = KV_RE.match(line.strip())
            if m:
                k, v = m.group(1), m.group(2).strip()
                if k == "col":
                    head, _, rest = v.partition("|")
                    items = [x.strip() for x in rest.split(";") if x.strip()]
                    sl["cols"].append((head.strip(), items))
                else:
                    sl[k] = v
                continue
            if line.strip().startswith("-"):
                sl["bullets"].append(line.strip().lstrip("-").strip())
                continue
            if not sl.get("lead"):
                sl["lead"] = line.strip()
            else:
                sl["bullets"].append(line.strip())
        if not sl["title"]:
            warnings.append("有一頁沒有標題，已跳過")
            continue
        slides.append(sl)
    return meta, slides, warnings


def lint(slides):
    out = []
    for i, sl in enumerate(slides, 1):
        t = sl["title"]
        if len(sl.get("bullets", [])) > 5:
            out.append("第 %d 頁有 %d 條條列，超過 5 條，建議拆頁"
                       % (i, len(sl["bullets"])))
        if len(t) > 34:
            out.append("第 %d 頁標題 %d 字，太長，壓到 30 字以內" % (i, len(t)))
        if sl["type"] in ("bullets", "bignum") and len(t) <= 6:
            out.append("第 %d 頁標題「%s」像題目不像結論，改寫成一句話判斷"
                       % (i, t))
    return out


# --------------------------------------------------------------------------
# Package
# --------------------------------------------------------------------------

def build_deck(outline_text, out_path):
    meta, slides, warnings = parse_outline(outline_text)
    if not slides:
        raise SystemExit("大綱裡沒有任何一頁，請檢查格式")
    style = Style(accent=meta.get("accent", "1F6FEB"),
                  read_mode=meta.get("mode", "stage").lower() == "read")

    slide_parts = []
    prompts = []
    for sl in slides:
        builder = BUILDERS.get(sl["type"], build_bullets)
        slide_parts.append(slide_xml(builder(style, sl), style.bg))
        if sl.get("image"):
            prompts.append((sl["imgno"], sl["title"], sl["image"]))

    n = len(slide_parts)
    z = zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED)
    try:
        z.writestr("[Content_Types].xml", content_types(n))
        z.writestr("_rels/.rels", root_rels())
        z.writestr("ppt/presentation.xml", presentation_xml(n))
        z.writestr("ppt/_rels/presentation.xml.rels", presentation_rels(n))
        z.writestr("ppt/slideMasters/slideMaster1.xml", slide_master(style.bg))
        z.writestr("ppt/slideMasters/_rels/slideMaster1.xml.rels", slide_master_rels())
        z.writestr("ppt/slideLayouts/slideLayout1.xml", slide_layout())
        z.writestr("ppt/slideLayouts/_rels/slideLayout1.xml.rels", slide_layout_rels())
        z.writestr("ppt/theme/theme1.xml", theme_xml(style))
        for i, part in enumerate(slide_parts, 1):
            z.writestr("ppt/slides/slide%d.xml" % i, part)
            z.writestr("ppt/slides/_rels/slide%d.xml.rels" % i, slide_rels())
    finally:
        z.close()
    return slides, prompts, warnings + lint(slides)


def write_prompt_list(prompts, deck_path):
    if not prompts:
        return None
    base = os.path.splitext(os.path.basename(deck_path))[0]
    path = os.path.join(os.path.dirname(os.path.abspath(deck_path)),
                        base + "-圖片提示詞.md")
    lines = ["# %s 的圖片提示詞" % os.path.basename(deck_path), "",
             "共 %d 張圖。每一段整段複製，貼到生圖工具。" % len(prompts),
             "生好的圖存下來，回到簡報，刪掉虛線框，把圖片放進同一個位置。", ""]
    for no, title, prompt in prompts:
        lines.append("## 圖 %s" % no)
        lines.append("")
        lines.append("所在頁：%s" % title)
        lines.append("")
        lines.append("```text")
        lines.append(prompt)
        lines.append("```")
        lines.append("")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return path


def main():
    ap = argparse.ArgumentParser(
        description="用純標準函式庫產生 .pptx（給 SPADE 用，無 python-pptx）")
    ap.add_argument("outline", help="大綱 .md 檔")
    ap.add_argument("-o", "--output", default="deck.pptx", help="輸出的 .pptx")
    ap.add_argument("--accent", help="主色，六碼十六進位，例如 1F6FEB")
    ap.add_argument("--read", action="store_true",
                    help="寄出去自己讀的版本（字級較小、可放較多字）")
    args = ap.parse_args()

    with open(args.outline, "r", encoding="utf-8") as f:
        text = f.read()
    if args.accent:
        text = "!accent: %s\n" % args.accent + text
    if args.read:
        text = "!mode: read\n" + text

    slides, prompts, warnings = build_deck(text, args.output)
    listfile = write_prompt_list(prompts, args.output)

    print("已產生 %s" % args.output)
    print("  頁數：%d" % len(slides))
    print("  圖片提示詞：%d 段" % len(prompts))
    if listfile:
        print("  清單檔：%s" % listfile)
    if warnings:
        print("")
        print("要處理的事：")
        for w in warnings:
            print("  - %s" % w)
    else:
        print("  檢查沒發現問題")
    return 0


if __name__ == "__main__":
    sys.exit(main())
