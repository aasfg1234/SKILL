"""把 spade_pptx.py 產出的 .pptx 大略畫成 PNG，用來自己看版面。

近似渲染：只處理實心矩形、文字方塊、字級/顏色/粗體/對齊/垂直錨點。
不處理自動縮字、精確斷行。看比例與配色夠用。
"""
import os
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    sys.exit("這支工具需要 PIL（Pillow）。沒有 PIL 就跳過預覽，"
             "改成把 .pptx 交給使用者自己開來看。")

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
P = "http://schemas.openxmlformats.org/presentationml/2006/main"
EMU = 914400
SCALE = 1600.0 / 13.3333  # px per inch

# 找得到哪個用哪個。都找不到就退回預設字型，版面比例仍然看得出來。
FONT_CANDIDATES = [
    (r"C:\Windows\Fonts\msjh.ttc", r"C:\Windows\Fonts\msjhbd.ttc"),
    ("/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
     "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc"),
    ("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
     "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"),
]
FONT_PATH, FONT_BOLD = FONT_CANDIDATES[0]
for reg, bold in FONT_CANDIDATES:
    if os.path.exists(reg):
        FONT_PATH, FONT_BOLD = reg, bold
        break
_cache = {}


def font(px, bold):
    key = (int(px), bold)
    if key not in _cache:
        try:
            _cache[key] = ImageFont.truetype(FONT_BOLD if bold else FONT_PATH,
                                             max(8, int(px)))
        except Exception:
            _cache[key] = ImageFont.load_default()
    return _cache[key]


def rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def px(emu):
    return int(emu / EMU * SCALE)


def wrap(draw, text, fnt, max_w):
    lines, cur = [], ""
    for ch in text:
        if ch == "\n":
            lines.append(cur)
            cur = ""
            continue
        t = cur + ch
        if draw.textlength(t, font=fnt) > max_w and cur:
            lines.append(cur)
            cur = ch
        else:
            cur = t
    lines.append(cur)
    return lines


def render(path, out_prefix):
    z = zipfile.ZipFile(path)
    names = sorted([n for n in z.namelist()
                    if re.match(r"ppt/slides/slide\d+\.xml$", n)],
                   key=lambda n: int(re.findall(r"\d+", n)[-1]))
    outs = []
    for i, name in enumerate(names, 1):
        root = ET.fromstring(z.read(name))
        W, H = px(12192000), px(6858000)
        img = Image.new("RGB", (W, H), (255, 255, 255))
        d = ImageDraw.Draw(img)
        tree = root.find(".//{%s}cSld/{%s}spTree" % (P, P))
        bgc = root.find(".//{%s}bg//{%s}srgbClr" % (P, A))
        if bgc is not None:
            d.rectangle([0, 0, W, H], fill=rgb(bgc.get("val")))
        for sp in tree.findall("{%s}sp" % P):
            xf = sp.find(".//{%s}xfrm" % A)
            if xf is None:
                continue
            off, ext = xf.find("{%s}off" % A), xf.find("{%s}ext" % A)
            x, y = px(int(off.get("x"))), px(int(off.get("y")))
            cx, cy = px(int(ext.get("cx"))), px(int(ext.get("cy")))
            spPr = sp.find("{%s}spPr" % P)
            fill = spPr.find("{%s}solidFill/{%s}srgbClr" % (A, A))
            if fill is not None:
                d.rectangle([x, y, x + cx, y + cy], fill=rgb(fill.get("val")))
            grad = spPr.find("{%s}gradFill" % A)
            if grad is not None:
                stops = grad.findall(".//{%s}gs" % A)
                if len(stops) >= 2:
                    c1 = rgb(stops[0].find("{%s}srgbClr" % A).get("val"))
                    c2 = rgb(stops[-1].find("{%s}srgbClr" % A).get("val"))
                    steps = max(2, cy)
                    for k in range(steps):
                        t = k / float(steps - 1)
                        col = tuple(int(c1[j] + (c2[j] - c1[j]) * t)
                                    for j in range(3))
                        yy = y + int(cy * k / steps)
                        d.rectangle([x, yy, x + cx,
                                     y + int(cy * (k + 1) / steps)], fill=col)
            ln = spPr.find("{%s}ln/{%s}solidFill/{%s}srgbClr" % (A, A, A))
            if ln is not None:
                d.rectangle([x, y, x + cx, y + cy], outline=rgb(ln.get("val")),
                            width=2)
            body = sp.find("{%s}txBody" % P)
            if body is None:
                continue
            bpr = body.find("{%s}bodyPr" % A)
            anchor = bpr.get("anchor", "t") if bpr is not None else "t"
            pad = int(bpr.get("lIns", "91440")) if bpr is not None else 91440
            pad = px(pad)
            blocks = []
            for pnode in body.findall("{%s}p" % A):
                ppr = pnode.find("{%s}pPr" % A)
                algn = ppr.get("algn") if ppr is not None else None
                runs = pnode.findall("{%s}r" % A)
                if not runs:
                    blocks.append((None, "", 0, None, algn, False))
                    continue
                for r in runs:
                    rpr = r.find("{%s}rPr" % A)
                    sz = int(rpr.get("sz", "1800")) / 100.0
                    bold = rpr.get("b") == "1"
                    c = rpr.find("{%s}solidFill/{%s}srgbClr" % (A, A))
                    col = rgb(c.get("val")) if c is not None else (0, 0, 0)
                    txt = r.find("{%s}t" % A).text or ""
                    blocks.append((col, txt, sz, None, algn, bold))
            rendered = []
            for col, txt, sz, _, algn, bold in blocks:
                fpx = sz / 72.0 * SCALE
                f = font(fpx, bold)
                if not txt:
                    rendered.append(([], f, col, algn, fpx))
                    continue
                rendered.append((wrap(d, txt, f, cx - pad * 2), f, col, algn,
                                 fpx))
            total = sum(max(1, len(ls)) * fpx * 1.28
                        for ls, f, c, a, fpx in rendered)
            if anchor == "ctr":
                ty = y + (cy - total) / 2
            elif anchor == "b":
                ty = y + cy - total - pad / 2
            else:
                ty = y + pad / 2
            for ls, f, col, algn, fpx in rendered:
                for line in ls:
                    tw = d.textlength(line, font=f)
                    if algn == "ctr":
                        tx = x + (cx - tw) / 2
                    elif algn == "r":
                        tx = x + cx - pad - tw
                    else:
                        tx = x + pad
                    d.text((tx, ty), line, font=f, fill=col or (0, 0, 0))
                    ty += fpx * 1.28
                if not ls:
                    ty += fpx * 1.28
        o = "%s-%02d.png" % (out_prefix, i)
        img.save(o)
        outs.append(o)
    return outs


if __name__ == "__main__":
    for o in render(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "slide"):
        print(o)
