# 圖片：寫提示詞，不生圖

使用者自己拿提示詞去生圖工具生圖，再放回簡報。
所以圖片的位置要放**完整的、可以直接送進生圖工具的英文提示詞**，不是三個字的說明。

## 一、放在哪裡

大綱裡，圖片位置寫成一行：

```text
[Image: 完整英文提示詞]
```

`spade_pptx.py` 會自動處理三件事，**你不用自己寫**：

1. 量出圖框的實際長寬比，把 `1:1 square format` 這種句子接在提示詞後面
2. 接上 `no text or lettering in the image`
3. 在框裡印出編號與尺寸，另外輸出 `deck-圖片提示詞.md` 清單檔

## 二、提示詞怎麼寫

**用英文寫。** 中文提示詞在多數生圖工具上品質明顯較差。

一段話，一行，六個要素，照這個順序：

| 順序 | 要素 | 例 |
|------|------|-----|
| 1 | 主體 + 具體特徵（族裔、年齡帶） | `A Taiwanese couple in their early sixties` |
| 2 | 動作或狀態 | `walking side by side along a riverside path` |
| 3 | 場景 | `bright open-plan office` |
| 4 | 光線 | `soft golden late-afternoon light` |
| 5 | 色調 | `muted blue and warm grey tones` |
| 6 | 風格與構圖 | `photorealistic corporate photography, medium shot, shallow depth of field` |

長度抓 30–50 字。三個字的提示詞出來就是隨機庫存照。

## 三、硬性規則

- **提示詞裡不能出現 `]`**，會截斷解析。方括號一律避開
- 整段寫成一行，不要換行
- **不要自己寫比例**（`16:9`、`--ar 3:2`）。腳本會依框的實際尺寸自動接上，
  自己寫了反而會蓋掉量到的正確值
- **不要要求生成任何文字、字母、logo、圖表數字。** 生圖工具的中文一定是亂碼，
  英文也常拼錯
- **人物一定要寫出族裔與年齡帶**（`Taiwanese`、`in their late thirties`），
  否則預設會生出白人
- 金融保險場景避開 `insurance agent`、`contract signing` 這類字眼，
  容易生出握手比讚的庫存照。改寫具體情境：
  `reviewing a document together at a kitchen table`

## 四、全篇視覺一致

同一份簡報的所有提示詞要共用同一套風格描述，否則三張圖會像三個不同來源。
**開工前先決定一次，每段照抄：**

```text
風格（二選一，不可混用）：
  photorealistic corporate photography
  flat vector illustration, minimal, limited palette

色調（挑一組貫穿全篇）：
  muted blue and warm grey tones

光線（用 natural / soft 系，避免 dramatic、neon）：
  soft natural window light
```

把這三行寫進企劃書，讓使用者先看過。

## 五、對照

反例：

```text
[Image: 客戶]                                太短，生出來是隨機庫存照
[Image: 一個業務員在跟客戶介紹保單]            中文，而且是庫存照題材
[Image: A happy customer, 16:9]              比例自己寫了，會蓋掉自動量測
[Image: A chart showing 45% growth]          要求生成數字，一定出錯
[Image: Office worker [smiling] at desk]     有 ] 會截斷解析
```

正例：

```text
[Image: A Taiwanese office worker in their late twenties sitting at a bright cafe table, looking at a smartphone with a calm focused expression, soft natural window light, muted blue and warm grey tones, photorealistic corporate photography, shallow depth of field]
```

## 六、什麼時候不要放圖

- 圖片只是為了填空白 → 不放。留白比爛圖好
- 內容是數字 → 用 `bignum` 版型，不要用生成圖
- 需要精確的產品外觀、真實人物、真實地點 → 生圖做不到，改用實拍或截圖

## 七、交件時一定要講

1. 簡報裡的圖片位置現在是一個虛線框，裡面是英文提示詞，不是壞掉
2. 提示詞清單在 `deck-圖片提示詞.md`
3. 生完圖之後，在 PowerPoint 裡刪掉那個虛線框，插入圖片放回同一個位置
