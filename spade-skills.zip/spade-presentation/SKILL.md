---
name: spade-presentation
description: >-
  Interview-first presentation designer for the SPADE platform. NEVER writes
  slides on the first turn — it first collects a written brief (audience, the
  decision you want, occasion, one-sentence takeaway, materials), confirms a
  storyline of action titles, and only then renders a .pptx. Every picture
  position carries a ready-to-paste English AI-image prompt instead of an
  image. Builds the .pptx with the Python standard library only, so it runs
  where python-pptx is not installed. Use when the user wants to make slides,
  a deck, a presentation, a pitch, or a readout, or says 做簡報 / 做投影片 /
  幫我做 PPT / 做一份簡報 / slides for… / pitch deck / build a deck.
---

# 簡報設計（SPADE 版）：先問清楚，再動手

這個 skill 的價值在**訪談**與**架構**。產檔用 `scripts/spade_pptx.py`，
純標準函式庫，不依賴 python-pptx。

## 鐵則

1. **收集完資訊之前，不產生任何投影片內容。** 不寫大綱、不寫標題、不產檔。
   使用者第一句話就算給了主題，也一樣先問。
2. **每張投影片的標題是一句結論，不是一個題目。**
   「Q3 營收」是題目，「Q3 營收成長 12%，但全部來自單一客戶」是結論。
3. **一張投影片只講一件事。**
4. **圖片一律只寫英文提示詞，不生圖、不抓圖。**
5. 使用者明確說「不要問，直接做」→ 用預設假設做，交件時列出用了哪些假設。

## SPADE 平台限制（會改變做法的四件事）

| 限制 | 對這個 skill 的影響 |
|------|-------------------|
| **沒有 python-pptx** | 產檔用 `scripts/spade_pptx.py`，它自己寫 OOXML |
| **每次執行都是新的暫存目錄，中間檔不跨執行存活** | 大綱與產檔要在**同一次執行**內做完，不要設計成分兩步 |
| **`Path.home()` 直接 RuntimeError** | 絕對不要碰家目錄。所有路徑用相對路徑或當前工作目錄 |
| **輸入靠 `input_files`，產出會複製回 session 目錄** | 產檔就寫在當前工作目錄，不要自己指定絕對路徑 |

如果平台規格有更新，以使用者手上的規格表為準，不要用這張表的舊資訊蓋過去。

## 四階段流程

```text
  Phase 1        Phase 2         Phase 3            Phase 4
  訪談     ──▶   企劃書    ──▶   骨架        ──▶    產檔
  問到夠         使用者確認      只有標題的清單      .pptx + 圖片提示詞
                    ▲               ▲
                  gate 1          gate 2
              沒點頭不准前進   沒點頭不准前進
```

## Phase 1 — 訪談

完整題庫在 `references/interview.md`。**開工前先讀它。**

- 第一輪四題選擇題：場合形式、聽眾、你要他們做什麼、風格偏好
- 第二輪開放題：一句話結論、時間長度、聽眾的反對、材料在哪、要不要圖
- 第三輪只在有觸發條件時問

使用者答不出來就給建議答案讓他點頭，不要逼問。一次不要丟超過五題。

## Phase 2 — 企劃書

用 `assets/brief.md` 的格式寫成一頁，給使用者確認。等回覆。

## Phase 3 — 骨架

只交出每張投影片的**行動標題清單**，不寫內文。
四種敘事骨架（決策型／說服型／教學型／回報型）在 `references/structure.md`。

**水平邏輯測試**：只讀標題清單，要能讀成一段通順的論述。

等使用者確認，再寫內文。

## Phase 4 — 產檔

大綱格式在 `references/outline-format.md`，視覺規範在 `references/visual.md`，
圖片提示詞寫法在 `references/image-prompts.md`。

```bash
python scripts/spade_pptx.py outline.md -o deck.pptx
```

寄出去給人自己讀的版本，加 `--read`（字級縮小、可放較多字）：

```bash
python scripts/spade_pptx.py outline.md -o deck.pptx --read
```

換主色：

```bash
python scripts/spade_pptx.py outline.md -o deck.pptx --accent 0F766E
```

產出兩個檔：`deck.pptx` 和 `deck-圖片提示詞.md`。

### 產檔後一定要看

腳本最後會印出檢查結果。這幾種一定要處理：

```text
第 N 頁有 7 條條列，超過 5 條，建議拆頁
第 N 頁標題 40 字，太長，壓到 30 字以內
第 N 頁標題「市場分析」像題目不像結論，改寫成一句話判斷
第 N 頁的圖片提示詞含有 ] ，解析會被截斷
```

印出「檢查沒發現問題」才算過。

## 交件前自檢

內容：

- [ ] 只讀標題能讀懂全篇
- [ ] 每張標題是結論，沒有一張是名詞題目
- [ ] 第一張投影片就講出結論（決策型、回報型）
- [ ] 每個數字都有口徑（期間、單位、來源）
- [ ] 假資料有標「示意數字，待填」

圖片：

- [ ] 每個 `[Image: ...]` 都是完整英文提示詞，不是三個字的說明
- [ ] 全篇提示詞共用同一組風格、色調、光線
- [ ] 已產出 `deck-圖片提示詞.md`

交件時要講清楚：

- 檔案在哪
- 圖片位置現在是一段英文提示詞，不是壞掉，要自己拿去生圖再換掉
- 哪些內容是假設的、哪些數字要他自己填

## 檔案索引

| 檔案 | 什麼時候讀 |
|------|-----------|
| `references/interview.md` | Phase 1，開工第一件事 |
| `references/structure.md` | Phase 3 排骨架、寫行動標題 |
| `references/outline-format.md` | Phase 4 寫大綱之前 |
| `references/visual.md` | Phase 4 判斷版面與字量 |
| `references/image-prompts.md` | Phase 4 有任何圖片時 |
| `assets/brief.md` | Phase 2 寫企劃書 |
| `scripts/spade_pptx.py` | Phase 4 產檔 |
