---
name: spade-presentation
description: >-
  Interview-first presentation designer for the SPADE platform. NEVER writes
  slides on the first turn — it first collects a written brief (audience, the
  decision you want, occasion, one-sentence takeaway, materials), confirms a
  storyline of action titles, and only then renders a .pptx. Every picture
  position carries a ready-to-paste English AI-image prompt instead of an
  image. Builds the .pptx with the Python standard library only, so it runs
  where python-pptx is not installed. Use when the user wants to make slides,
  a deck, a presentation, a pitch, or a readout, or says 做簡報 / 做投影片 /
  幫我做 PPT / 做一份簡報 / slides for… / pitch deck / build a deck.
---

# 簡報設計（SPADE 版）：先問清楚，再動手

這個 skill 的價值在**訪談**與**架構**。產檔用 `scripts/spade_pptx.py`，
純標準函式庫，不依賴 python-pptx。

## 鐵則

1. **收集完資訊之前，不產生任何投影片內容。** 不寫大綱、不寫標題、不產檔。
   使用者第一句話就算給了主題，也一樣先問。
2. **每張投影片的標題是一句結論，不是一個題目。**
   「Q3 營收」是題目，「Q3 營收成長 12%，但全部來自單一客戶」是結論。
3. **一張投影片只講一件事。**
4. **圖片一律只寫英文提示詞，不生圖、不抓圖。**
5. 使用者明確說「不要問，直接做」→ 用預設假設做，交件時列出用了哪些假設。

## SPADE 平台限制（會改變做法的四件事）

| 限制 | 對這個 skill 的影響 |
|------|-------------------|
| **沒有 python-pptx** | 產檔用 `scripts/spade_pptx.py`，它自己寫 OOXML |
| **每次執行都是新的暫存目錄，中間檔不跨執行存活** | 大綱與產檔要在**同一次執行**內做完，不要設計成分兩步 |
| **`Path.home()` 直接 RuntimeError** | 絕對不要碰家目錄。所有路徑用相對路徑或當前工作目錄 |
| **輸入靠 `input_files`，產出會複製回 session 目錄** | 產檔就寫在當前工作目錄，不要自己指定絕對路徑 |

如果平台規格有更新，以使用者手上的規格表為準，不要用這張表的舊資訊蓋過去。

## 四階段流程

```text
  Phase 1        Phase 2         Phase 3            Phase 4
  訪談     ──▶   企劃書    ──▶   骨架        ──▶    產檔
  問到夠         使用者確認      只有標題的清單      .pptx + 圖片提示詞
                    ▲               ▲
                  gate 1          gate 2
              沒點頭不准前進   沒點頭不准前進
```

## Phase 1 — 訪談

完整題庫在 `references/interview.md`。**開工前先讀它。**

- 第一輪四題選擇題：場合形式、聽眾、你要他們做什麼、**風格**
- 第二輪開放題：一句話結論、時間長度、聽眾的反對、材料在哪、要不要圖
- 第三輪只在有觸發條件時問

使用者答不出來就給建議答案讓他點頭，不要逼問。一次不要丟超過五題。

**風格那題一定要給清單，不要問抽象的。** 六種內建風格：
`corporate` 商務藍、`mono` 極簡黑白、`midnight` 深色簡報、
`editorial` 暖色雜誌、`sage` 清新綠、`alert` 高對比警示。

```bash
python scripts/spade_pptx.py --list-styles
```

最好直接產幾份範例、用 `preview.py` 畫成圖給他挑。
六種都不要，就讓他用說明的（偏穩重還是活潑、底色深還是淺、有沒有指定色），
再挑最接近的一個搭 `--accent` 換主色。細節在 `references/interview.md` 的 Q4。

## Phase 2 — 企劃書

用 `assets/brief.md` 的格式寫成一頁，給使用者確認。等回覆。

## Phase 3 — 骨架

只交出每張投影片的**行動標題清單**，不寫內文。
四種敘事骨架（決策型／說服型／教學型／回報型）在 `references/structure.md`。

**水平邏輯測試**：只讀標題清單，要能讀成一段通順的論述。

等使用者確認，再寫內文。

## Phase 4 — 產檔

大綱格式在 `references/outline-format.md`，視覺規範在 `references/visual.md`，
圖片提示詞寫法在 `references/image-prompts.md`。

**選版型的規則：能用 `stats`、`table`、`cards` 的，就不要用純 `bullets`。**
七種版型：`cover`、`section`、`stats`、`table`、`cards`、`bullets`、`twocol`。
純條列是密度最低的一種，整份都用條列就會被說「資訊密度低」。

```bash
python scripts/spade_pptx.py outline.md -o deck.pptx
```

寄出去給人自己讀的版本，加 `--read`（字級縮小、可放較多字）：

```bash
python scripts/spade_pptx.py outline.md -o deck.pptx --read
```

指定風格（Phase 1 問到的那個）：

```bash
python scripts/spade_pptx.py outline.md -o deck.pptx --style editorial
```

換主色，可以跟 `--style` 一起用。深淺、底色、線色會自動跟著重算：

```bash
python scripts/spade_pptx.py outline.md -o deck.pptx --style sage --accent 7A1F3D
```

產出兩個檔：`deck.pptx` 和 `deck-圖片提示詞.md`。

### 產完一定要自己看過再交

**這條是踩過才加的。** 曾經交出一份白底、只有細線、每頁三行字的簡報，
使用者第一句話就是「好醜，沒顏色，資訊密度低」。當時我沒有任何方法看到成品。

現在有了：

```bash
python scripts/preview.py deck.pptx p
```

它把每一頁畫成 `p-01.png`、`p-02.png`⋯⋯，**打開來自己看**。
近似渲染，不處理自動縮字與精確斷行，但版面比例、配色、密度看得很準。

看的時候問三件事：

1. **有沒有顏色？** 整頁白底加一條細線就是沒做完
2. **內容有沒有撐滿？** 下半頁一片空白就是版型選錯，或內容寫太少
3. **有沒有東西疊在一起？** 註腳壓到頁尾線是最常見的

需要 PIL。SPADE 上有，但如果環境沒有，這支會直接告訴你並結束，
這時候就在交件時明講「版面我沒看過」，不要假裝看過。

### 產檔後一定要看

腳本最後會印出檢查結果。這幾種一定要處理：

```text
第 N 頁有 7 條條列，超過 5 條，建議拆頁
第 N 頁標題 40 字，太長，壓到 30 字以內
第 N 頁標題「市場分析」像題目不像結論，改寫成一句話判斷
第 N 頁的圖片提示詞含有 ] ，解析會被截斷
```

印出「檢查沒發現問題」才算過。

## 交件前自檢

內容：

- [ ] 只讀標題能讀懂全篇
- [ ] 每張標題是結論，沒有一張是名詞題目
- [ ] 第一張投影片就講出結論（決策型、回報型）
- [ ] 每個數字都有口徑（期間、單位、來源）
- [ ] 假資料有標「示意數字，待填」

圖片：

- [ ] 每個 `[Image: ...]` 都是完整英文提示詞，不是三個字的說明
- [ ] 全篇提示詞共用同一組風格、色調、光線
- [ ] 已產出 `deck-圖片提示詞.md`

交件時要講清楚：

- 檔案在哪
- 版面我自己用 preview.py 看過了（或：我沒辦法看，請你確認）
- 圖片位置現在是一段英文提示詞，不是壞掉，要自己拿去生圖再換掉
- 哪些內容是假設的、哪些數字要他自己填

## 檔案索引

| 檔案 | 什麼時候讀 |
|------|-----------|
| `references/interview.md` | Phase 1，開工第一件事 |
| `references/structure.md` | Phase 3 排骨架、寫行動標題 |
| `references/outline-format.md` | Phase 4 寫大綱之前 |
| `references/visual.md` | Phase 4 判斷版面與字量 |
| `references/image-prompts.md` | Phase 4 有任何圖片時 |
| `assets/brief.md` | Phase 2 寫企劃書 |
| `scripts/spade_pptx.py` | Phase 4 產檔 |
| `scripts/preview.py` | Phase 4 產完，交件前自己看 |
