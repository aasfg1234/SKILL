# SPADE skills

給公司內部 AI 平台 SPADE 用的兩個 skill。格式與 Claude Code 的 skill 相同
（YAML frontmatter + SKILL.md + references/ + scripts/），但執行環境的限制不一樣。

## spade-presentation — 訪談優先的簡報製作

先問清楚再做簡報。收集完需求、確認企劃書、確認每頁標題，才產檔。

- **不會一句話就開始生投影片。** 兩個確認點，使用者沒點頭不往下走
- **圖片位置放英文提示詞，不生圖。** 使用者自己拿提示詞去生圖工具，再放回簡報
- **產檔只用 Python 標準函式庫。** SPADE 沒有 `python-pptx`，
  所以 `scripts/spade_pptx.py` 自己寫 OOXML

```bash
python scripts/spade_pptx.py outline.md -o deck.pptx
python scripts/spade_pptx.py outline.md -o deck.pptx --read
python scripts/spade_pptx.py outline.md -o deck.pptx --accent 0F766E
```

五種版型：`cover`、`section`、`bullets`、`bignum`、`twocol`。
大綱格式見 `spade-presentation/references/outline-format.md`。

內容方法論的來源：Minto 金字塔原理與 SCQA、Duarte 的 Sparkline、
Alley 的 Assertion-Evidence、Mayer 的多媒體學習原則。

## spade-skill-porting — 在 SPADE 上開發 skill

把 Claude Code 的 skill 搬到 SPADE，或在 SPADE 上從零寫一個。

- `scripts/probe.py` 探測執行環境，印出規格表。**要跑兩次**，
  第二次才測得出檔案會不會跨執行保留
- `assets/spec-sheet.md` 規格表範本，每一格要標【實測】【文件】【推測】【不知道】
- `references/porting-checklist.md` 逐條移植清單

```bash
python scripts/probe.py
python scripts/probe.py
```

## SPADE 的四個硬性限制

| 限制 | 影響 |
|---|---|
| 中間檔不跨執行存活 | 分步驟的設計會斷，要併成一支腳本 |
| `Path.home()` 直接 RuntimeError | 絕對不要碰家目錄 |
| 沒有 `python-pptx`、`rapidfuzz`、`jieba`，也沒有 `pip` | 核心邏輯只能用標準函式庫 |
| 輸入靠 `input_files`，產出複製回 session 目錄 | 不要寫死絕對路徑 |

平台事實的完整版與有效期限見 `spade-skill-porting/references/platform-facts.md`。
那一份會過期，以手上最新的規格表為準。

## 目前的驗證狀態

| 項目 | 狀態 |
|---|---|
| `spade_pptx.py` 產出的 .pptx 能被解析 | 已驗證（本機用 python-pptx 開啟，7 頁全部正常） |
| 版面實際長相 | **未驗證**，本機沒有 PowerPoint 或 LibreOffice 可轉圖 |
| `probe.py` 兩次執行的判斷邏輯 | 已驗證 |
| 在 SPADE 上實際執行 | **未驗證**，尚未上傳到平台跑過 |
