# SPADE 已知事實

**這一份會過期。** 資料來源是 2026-08-17 由 SPADE 自行探測的結果。
使用者手上有更新的規格表時，**以規格表為準**，不要用這一頁蓋過去。

不確定的時候，跑 `scripts/probe.py` 重測，不要憑印象。

**2026-08-23 查核：** 這個 repo 根目錄有一份 `S平台.md`，裡面 Part A 是給 SPADE 的
探測提示詞，Part B 是規格表——**Part B 目前仍是「（待填）」，從來沒填過。**
也就是說，下面這張表是目前手上唯一的資料，但它不是正式規格表。
正式的做法是請使用者把 Part A 貼給 SPADE 跑兩次，把 Part B 補起來。

## 實測確認（2026-08-17）

| 項目 | 結果 | 對設計的影響 |
|---|---|---|
| Python | 3.13.3 | 可以用 3.10 之後的語法（新版型別註記、match） |
| 編碼 | 全 utf-8，中文正常 | 不用做 cp950 的防護 |
| 標準函式庫 | 17/17 完整，未被移除 | 核心邏輯全部走標準函式庫是可行的 |
| `python-docx` | **有**（1.2.0） | Word 輸出可用 |
| **`python-pptx`** | **沒有** | 要產 .pptx 必須自己寫 OOXML |
| `rapidfuzz`、`jieba`、`torch`、`sentence_transformers` | **沒有** | 模糊比對、斷詞、模型推論全部要自己寫或放棄 |
| `pip` 模組 | **不存在** | **不能自己裝套件** |
| 有的套件 | pandas、numpy、openpyxl、pypdf、pdfplumber、lxml、bs4、regex、requests、PIL、matplotlib 等 20/30 | 資料處理與 Excel、PDF 沒問題 |
| 執行時間 | 至少 30 秒無虞 | 上限未知，不要賭 |
| stdout | 500 行未截斷 | 大量輸出要自己分段 |
| `subprocess` | 可用 | 但沒有跨執行的檔案，用途有限 |
| **工作目錄** | **每次執行都是新的暫存目錄，中間檔不跨執行存活** | **這是最重要的一條**，見下方 |
| 家目錄 | `Path.home()` 直接 RuntimeError | 絕對不要碰 |
| 檔案傳遞 | 輸入靠 `input_files` 放進 sandbox；產出會複製回 session working_dir | 產檔就寫在當前工作目錄 |

## 探測腳本不連外

`S平台.md` 的 Part A 明文要求探測腳本「不要連任何外部網路」，
而且「絕對不要印出任何環境變數的值」。

`scripts/probe.py` 照這兩條做：環境變數只數個數不印值，連外測試預設關閉，
要測必須自己加 `--allow-network`。

## 仍未確認

以下全部當成**不知道**處理：

- 能不能用 pip 以外的方式安裝套件
- Python 能不能直接連外（socket / requests）
- 記憶體上限
- skill 的實體目錄與命名規則
- 產出對最終使用者的可見性
- 合規稽核要求
- 單次執行的實際時間上限

## 為什麼「檔案不跨執行保留」最重要

Claude Code 的 skill 常常這樣設計：

```text
第一步：分析輸入，產出 intermediate.json
第二步：讀 intermediate.json，產出最終結果
```

這個設計在 SPADE 上**第二步會直接找不到檔案**。

已經踩過一次：`reg-diff` 因此補了一支 `run_all.py`，
把原本四個步驟改成在同一個 process 裡跑完。

移植時第一件事就是問：**這支 skill 有幾個步驟？中間有沒有產檔給下一步讀？**
有的話，先把它併起來，其他都是次要的。

## 另一個踩過的坑

曾經因為沒先問套件狀況，寫出依賴 `python-docx` 的設計。
後來補了純標準函式庫的 .docx 讀取器當退路。

結果 SPADE 其實有 `python-docx`，但那個退路仍然有價值——
**核心邏輯不綁第三方套件，換平台就不用重寫。**

同樣的道理，`spade-presentation` 的 .pptx 產生器是純標準函式庫寫的，
因為 SPADE 沒有 `python-pptx`。
