# 移植清單

一條一條對。每一條都寫了「怎麼找」跟「怎麼改」。

## 一、流程結構

### 1.1 中間檔不跨執行存活

**怎麼找**：看 SKILL.md 裡有沒有「第一步產出 X，第二步讀 X」的描述。
看腳本有沒有寫檔之後在另一支腳本讀回來。

**怎麼改**：併成一支 `run_all.py`，四個步驟在同一個 process 跑完。
原本的分步腳本可以保留成函式，但入口只留一個。

```python
def main():
    data = step1_parse(input_path)
    checked = step2_compare(data)
    report = step3_render(checked)
    step4_write(report, "output.docx")
```

**例外**：規格表上 B5 明確寫著【實測】會保留，才可以分步。

### 1.2 單次執行時間

**怎麼找**：有沒有迴圈跑大量資料、有沒有呼叫外部服務。

**怎麼改**：留三倍餘裕。超過的話先做取樣，或請使用者分批丟。

## 二、路徑

### 2.1 家目錄

**怎麼找**：全域搜這四個字串。

```text
Path.home()
os.path.expanduser
~/
$HOME
```

**怎麼改**：全部換成 `os.getcwd()` 或相對路徑。一個都不能留。

### 2.2 絕對路徑

**怎麼找**：搜 `C:/`、`C:\`、`/home/`、`/Users/`、`/tmp/`。

**怎麼改**：輸入從參數或 `input_files` 拿，輸出寫在當前工作目錄。

### 2.3 skill 內部的資源檔

**怎麼找**：腳本有沒有讀同目錄的 `assets/xxx.json`、`templates/xxx.docx`。

**怎麼改**：用 `os.path.dirname(os.path.abspath(__file__))` 定位，
不要用工作目錄推。**但注意：skill 的實體目錄規則目前是未確認狀態**，
能不放資源檔就不放，把資料寫進程式碼裡最穩。

## 三、套件

### 3.1 分兩層

**核心層**：只用標準函式庫。缺了任何第三方套件，功能照樣完整。

**加值層**：用第三方套件做更好的輸出。缺了只是格式退化。

```python
try:
    import docx
    HAVE_DOCX = True
except ImportError:
    HAVE_DOCX = False

def write_report(data, path):
    if HAVE_DOCX:
        return write_docx(data, path)
    return write_markdown(data, path + ".md")
```

### 3.2 確認過沒有的

`python-pptx`、`rapidfuzz`、`jieba`、`torch`、`sentence_transformers`、`pip`。

要用到這些的功能，先想清楚純標準函式庫怎麼做：

| 原本用 | 標準函式庫替代 |
|---|---|
| `rapidfuzz` 模糊比對 | `difflib.SequenceMatcher` |
| `jieba` 中文斷詞 | 自己寫規則，或改用字元 n-gram |
| `python-pptx` 產簡報 | `zipfile` + 手寫 OOXML |
| `requests` | `urllib.request`（但連外能力未確認） |

### 3.3 不要試圖安裝

`pip` 模組不存在。腳本裡不要出現 `pip install`、`subprocess` 裝套件。
裝不起來還會浪費執行時間。

## 四、輸入輸出

### 4.1 輸入

使用者的檔案靠 `input_files` 放進 sandbox。腳本要能接受檔名參數，
不要寫死路徑。

### 4.2 輸出

產出寫在當前工作目錄，平台會複製回 session。
不要自己指定絕對路徑，也不要寫到暫存目錄然後期待它還在。

### 4.3 stdout

500 行未截斷是實測值，上限未知。
大量結果不要全部用 print 吐出來，寫成檔案。

## 五、SKILL.md 本身

### 5.1 frontmatter

格式與 Claude Code 相同，`name` 與 `description` 兩個欄位。
`description` 要寫觸發語，中英文都放。

### 5.2 指令範例

Claude Code 的 skill 常常寫 `python ~/.claude/skills/...`。
**這在 SPADE 上一定錯。** 改成相對於 skill 目錄的路徑。

### 5.3 把未確認的事寫進去

規格表上還標著【推測】【不知道】的項目，在 SKILL.md 裡明講：

```markdown
## 已知未確認

- skill 的實體目錄規則未確認，所以資源檔全部寫進程式碼
- 連外能力未確認，所有功能都不依賴網路
```

這樣下一個接手的人不會踩同一個坑。

## 六、最後自測

- [ ] 全部 import 列出來，第三方的都有退路
- [ ] `Path.home()` / `expanduser` / `~` 一個都不剩
- [ ] 絕對路徑一個都不剩
- [ ] 整條流程一次執行跑完
- [ ] 中文輸出沒亂碼
- [ ] SKILL.md 裡的指令路徑改過了
- [ ] 未確認的項目寫進 SKILL.md
