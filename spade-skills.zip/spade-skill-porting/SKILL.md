---
name: spade-skill-porting
description: >-
  Build a new skill for the SPADE platform, or port an existing Claude Code
  skill onto it, without guessing at the runtime. Probes the sandbox with a
  stdlib-only script, fills in a platform spec sheet, then applies SPADE's four
  hard constraints (no cross-execution files, no home directory, missing
  third-party packages, input_files in and working_dir out). Use when the user
  says 這個要放到 SPADE / SPADE 版 / 移植到 SPADE / SPADE 上跑不動 /
  在 SPADE 開發 skill, or asks for a skill that must run somewhere other than
  Claude Code.
---

# 在 SPADE 上開發 skill

SPADE 是使用者公司的內部 AI 平台，有 skill 功能，用跟 Claude Code 一樣的
YAML frontmatter 格式。**但執行環境不一樣，照抄 Claude Code 的 skill 會斷。**

## 鐵則

1. **動工前先確認平台規格。** 沒有規格表就先跑 `scripts/probe.py`，跑兩次。
2. **標【推測】【不知道】的一律當成未知。** 保守設計，或直接問使用者。
   不要拿沒驗證的假設蓋架構。
3. **核心邏輯不依賴任何第三方套件。** 缺套件只能影響輸出格式，
   不能影響功能跑不跑得起來。
4. **不要碰家目錄。** `Path.home()` 在某些設定下直接 RuntimeError。
5. **不要設計成分兩次執行。** 除非規格表明確寫著檔案會保留。

## 第一步：拿到規格

問使用者有沒有平台規格表。沒有的話：

```bash
python scripts/probe.py
```

**要跑兩次。** 第一次只留標記檔，第二次才測得出「檔案會不會跨執行保留」。
這一題最會改變架構，一定要測到。

`probe.py` 是純標準函式庫，不會裝東西、不會寫到工作目錄以外。
它會印出一張 markdown 規格表，請使用者整段貼回來。

把結果填進 `assets/spec-sheet.md`，每一格標上【實測】【文件】【推測】【不知道】。

**B6（skill 機制）與 B7（對話 I/O）最容易被講得篤定卻講錯**，
即使標【文件】也值得再確認一次。

## 第二步：套用四個限制

完整清單在 `references/porting-checklist.md`。四個最會咬人的：

| 限制 | 症狀 | 做法 |
|------|------|------|
| 中間檔不跨執行存活 | 第二步找不到第一步的檔 | 全部併進**同一支** `run_all.py`，一個 process 跑完 |
| `Path.home()` 會爆 | RuntimeError，訊息看不出原因 | 一律用相對路徑或 `os.getcwd()` |
| 第三方套件不齊 | ImportError | 核心走標準函式庫；第三方套件只當加值，用 try/except 包起來 |
| 檔案進出方式不同 | 找不到使用者給的檔 | 輸入從 `input_files` 拿；產出寫在當前工作目錄 |

## 第三步：改寫

已知的平台事實在 `references/platform-facts.md`。**那份有日期，會過期，
以使用者手上的規格表為準。**

改寫時的順序：

1. 先把跨步驟的流程併成一支腳本
2. 再把第三方套件的依賴拆成「核心」與「加值」兩層
3. 再處理路徑
4. 最後才調輸出格式

## 第四步：交付前自測

- [ ] 全部 `import` 列出來，第三方的都有 try/except 或替代路徑
- [ ] 全域搜過一次 `Path.home()`、`~`、`os.path.expanduser`，一個都不剩
- [ ] 全域搜過一次絕對路徑（`C:/`、`/home/`），一個都不剩
- [ ] 整條流程可以在一次執行內跑完
- [ ] 單次執行時間留三倍餘裕
- [ ] 中文輸出試過，沒有亂碼
- [ ] 規格表上還標著【推測】的項目，在 SKILL.md 裡寫成「已知未確認」

## 檔案索引

| 檔案 | 什麼時候用 |
|------|-----------|
| `scripts/probe.py` | 沒有規格表時，第一件事 |
| `assets/spec-sheet.md` | 把探測結果填進去 |
| `references/platform-facts.md` | 已知的平台事實與有效期限 |
| `references/porting-checklist.md` | 改寫時逐條對 |
