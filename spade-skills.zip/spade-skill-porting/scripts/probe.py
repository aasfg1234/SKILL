"""
probe.py - 探測 SPADE 執行環境，印出一張規格表。

純標準函式庫，不 import 任何第三方套件，不碰家目錄，不寫檔到工作目錄以外。

安全規則（跟 S平台.md 的 Part A 一致）：
  - 不印出任何環境變數的「值」，那裡面可能有金鑰或密碼
  - **預設不連任何外部網路。** 要測連線請自己加 --allow-network

**要跑兩次。** 第一次會留下一個標記檔，第二次才測得出「檔案會不會跨執行保留」。
這一題最會改變架構，一定要測。

    python probe.py          第一次
    python probe.py          第二次（看 B5 那一列）

    python probe.py --allow-network    連外測試（預設關閉，公司環境請先確認可不可以）
"""

import os
import platform
import socket
import subprocess
import sys
import time

MARKER = "_spade_probe_marker.txt"

THIRD_PARTY = [
    "pptx", "docx", "openpyxl", "pandas", "numpy", "matplotlib", "PIL",
    "pypdf", "pdfplumber", "lxml", "bs4", "regex", "requests", "yaml",
    "rapidfuzz", "jieba", "torch", "sentence_transformers", "sklearn",
    "scipy", "pip", "setuptools",
]

STDLIB = [
    "json", "csv", "re", "zipfile", "tarfile", "sqlite3", "hashlib", "hmac",
    "base64", "datetime", "decimal", "difflib", "itertools", "collections",
    "pathlib", "tempfile", "shutil", "unicodedata", "xml.etree.ElementTree",
    "html.parser", "urllib.request", "email", "logging", "argparse",
    "dataclasses", "typing", "enum", "textwrap",
]


def row(label, value):
    print("| %s | %s |" % (label, value))


def check_import(name):
    try:
        mod = __import__(name)
    except Exception as exc:
        return False, type(exc).__name__
    ver = getattr(mod, "__version__", "")
    return True, str(ver)


def section(title):
    print("")
    print("### " + title)
    print("")
    print("| 項目 | 結果 |")
    print("|---|---|")


def main():
    print("# SPADE 環境探測結果")
    print("")
    print("產生時間（容器內時鐘）：%s" % time.strftime("%Y-%m-%d %H:%M:%S"))

    section("B1 直譯器")
    row("Python 版本", sys.version.split()[0])
    row("平台", platform.platform())
    row("預設編碼", sys.getdefaultencoding())
    row("檔案系統編碼", sys.getfilesystemencoding())
    row("stdout 編碼", getattr(sys.stdout, "encoding", "未知"))
    row("中文輸出測試", "繁體中文正常顯示")

    section("B2 標準函式庫")
    missing = []
    for name in STDLIB:
        ok, _ = check_import(name)
        if not ok:
            missing.append(name)
    row("測試數量", "%d 個" % len(STDLIB))
    row("缺少的", ", ".join(missing) if missing else "無，全部可用")

    section("B3 第三方套件")
    have, absent = [], []
    for name in THIRD_PARTY:
        ok, ver = check_import(name)
        if ok:
            have.append("%s%s" % (name, (" " + ver) if ver else ""))
        else:
            absent.append(name)
    row("有的", ", ".join(have) if have else "一個都沒有")
    row("沒有的", ", ".join(absent) if absent else "無")
    row("能不能自己裝", "pip 模組在上面那一列裡就有機會，不在就是不能裝")

    section("B4 檔案系統")
    row("環境變數", "只列名稱不列值（共 %d 個），值可能含金鑰" % len(os.environ))
    cwd = os.getcwd()
    row("工作目錄", cwd)
    try:
        import pathlib
        home = str(pathlib.Path.home())
        row("家目錄", home + "（可以讀，但仍然不建議寫入）")
    except Exception as exc:
        row("家目錄", "**%s** — 絕對不要碰" % type(exc).__name__)
    try:
        test = os.path.join(cwd, "_spade_probe_write.tmp")
        with open(test, "w", encoding="utf-8") as f:
            f.write("ok")
        os.remove(test)
        row("工作目錄可寫", "可以")
    except Exception as exc:
        row("工作目錄可寫", "不行：%s" % exc)
    try:
        import tempfile
        with tempfile.NamedTemporaryFile(delete=True) as f:
            f.write(b"ok")
        row("暫存目錄可寫", "可以")
    except Exception as exc:
        row("暫存目錄可寫", "不行：%s" % exc)

    section("B5 檔案會不會跨執行保留（要跑兩次才準）")
    marker_path = os.path.join(cwd, MARKER)
    if os.path.exists(marker_path):
        with open(marker_path, "r", encoding="utf-8") as f:
            before = f.read().strip()
        row("結論", "**會保留**。上一次執行留下的檔案還在")
        row("上次寫入時間", before)
        row("影響", "可以設計成分步驟、產中間檔的流程")
    else:
        row("結論", "第一次執行，還測不出來。**請再跑一次這支程式**")
        row("影響", "如果第二次仍顯示第一次執行，代表檔案不跨執行保留")
    try:
        with open(marker_path, "w", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S"))
    except Exception as exc:
        row("標記檔寫入", "失敗：%s" % exc)

    section("B6 執行能力")
    try:
        r = subprocess.run([sys.executable, "-c", "print(1)"],
                           capture_output=True, text=True, timeout=20)
        row("subprocess", "可用，回傳碼 %d" % r.returncode)
    except Exception as exc:
        row("subprocess", "不可用：%s" % type(exc).__name__)
    t0 = time.time()
    x = 0
    for i in range(3000000):
        x += i
    row("三百萬次迴圈耗時", "%.2f 秒" % (time.time() - t0))
    row("建議", "把單次執行控制在這個數量級的十倍以內")

    section("B7 對外連線")
    if "--allow-network" not in sys.argv:
        row("狀態", "**沒測**。預設不連外，這是刻意的")
        row("為什麼", "公司環境的探測腳本不該自己連外，先確認可不可以再測")
        row("要測的話", "加上 --allow-network 重跑")
    else:
        try:
            sock = socket.create_connection(("pypi.org", 443), timeout=5)
            sock.close()
            row("連 pypi.org:443", "**通**")
        except Exception as exc:
            row("連 pypi.org:443", "不通：%s" % type(exc).__name__)
        try:
            socket.gethostbyname("example.com")
            row("DNS 解析", "可以")
        except Exception as exc:
            row("DNS 解析", "不行：%s" % type(exc).__name__)

    section("B8 stdout")
    print("| 說明 | 下面會連印 300 行，數到 300 就是沒被截斷 |")
    for i in range(1, 301):
        print("probe-line-%03d" % i)
    print("")
    print("如果你只看到前面幾行，代表 stdout 有截斷，把上限記下來。")
    print("")
    print("---")
    print("")
    print("**沒測到的項目，一律當成不知道。** 不要拿推測蓋架構。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
