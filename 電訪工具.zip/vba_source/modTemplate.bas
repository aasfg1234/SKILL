Attribute VB_Name = "modTemplate"
Option Explicit

' 郵件主旨／內文的「區塊」模型。
' 使用者在郵件設定畫面用選單一塊一塊組出主旨與內文，不用自己打 {{欄位名}}。
'
' 區塊序列化格式：一個區塊一行（vbLf 分隔），每行為 "型別=內容"
'   T=固定文字      -> 原樣輸出
'   F=欄位名        -> 輸出 {{欄位名}}，寄信時由 modUtils.ReplaceTemplateTokens 帶入實際值
'   N=              -> 換行（主旨不支援換行，會轉成空白）
'   B=              -> 表格（輸出 {{案件資料表格}}）
'
' 存檔時同時保存「區塊定義」與「渲染後的模板字串」：
'   區塊定義給編輯器回填用；模板字串給 modMailService 直接使用，
'   所以底層寄信邏輯完全不用知道區塊這件事。

Public Function MakeBlock(ByVal blockType As String, ByVal blockValue As String) As String
    ' 內容中的換行會破壞序列化格式，一律轉成空白
    blockValue = Replace(Replace(blockValue, vbCrLf, " "), vbLf, " ")
    blockValue = Replace(blockValue, vbCr, " ")
    MakeBlock = blockType & "=" & blockValue
End Function

Public Function BlockType(ByVal block As String) As String
    Dim p As Long
    p = InStr(block, "=")
    If p > 0 Then
        BlockType = Left$(block, p - 1)
    Else
        BlockType = BLOCK_TEXT
    End If
End Function

Public Function BlockValue(ByVal block As String) As String
    Dim p As Long
    p = InStr(block, "=")
    If p > 0 Then BlockValue = Mid$(block, p + 1)
End Function

Public Function BlocksToRaw(ByVal blocks As Collection) As String
    Dim i As Long, s As String
    For i = 1 To blocks.Count
        If s <> "" Then s = s & BLOCK_SEPARATOR
        s = s & NzText(blocks(i))
    Next i
    BlocksToRaw = s
End Function

Public Function RawToBlocks(ByVal raw As String) As Collection
    Dim c As New Collection, arr() As String, i As Long, item As String
    If Trim$(raw) <> "" Then
        arr = Split(Replace(raw, vbCrLf, vbLf), BLOCK_SEPARATOR)
        For i = LBound(arr) To UBound(arr)
            item = Trim$(Replace(arr(i), vbCr, ""))
            If item <> "" Then c.Add item
        Next i
    End If
    Set RawToBlocks = c
End Function

' ListBox 上顯示給使用者看的文字
Public Function BlockDisplayText(ByVal block As String) As String
    Select Case BlockType(block)
        Case BLOCK_FIELD
            BlockDisplayText = "【變動文字】" & BlockValue(block)
        Case BLOCK_NEWLINE
            BlockDisplayText = "【換行】"
        Case BLOCK_TABLE
            BlockDisplayText = "【表格】案件資料表格"
        Case Else
            BlockDisplayText = "【固定文字】" & BlockValue(block)
    End Select
End Function

' 區塊 -> 模板字串（含 {{欄位名}} token）
Public Function RenderBlocksToTemplate(ByVal blocks As Collection, ByVal isSubject As Boolean) As String
    Dim i As Long, s As String, b As String
    For i = 1 To blocks.Count
        b = NzText(blocks(i))
        Select Case BlockType(b)
            Case BLOCK_FIELD
                s = s & "{{" & BlockValue(b) & "}}"
            Case BLOCK_NEWLINE
                If isSubject Then
                    s = s & " "
                Else
                    s = s & vbCrLf
                End If
            Case BLOCK_TABLE
                ' 主旨不可能放表格，直接略過
                If Not isSubject Then s = s & "{{" & TABLE_TOKEN_KEY & "}}"
            Case Else
                s = s & BlockValue(b)
        End Select
    Next i
    RenderBlocksToTemplate = s
End Function

' 預設主旨／內文區塊（第一次開啟郵件設定時的起始內容）
Public Function DefaultSubjectBlocks() As Collection
    Dim c As New Collection
    c.Add MakeBlock(BLOCK_TEXT, "【電訪異常通知】")
    c.Add MakeBlock(BLOCK_FIELD, "新契約受理編號")
    Set DefaultSubjectBlocks = c
End Function

Public Function DefaultBodyBlocks() As Collection
    Dim c As New Collection
    c.Add MakeBlock(BLOCK_TEXT, "您好：")
    c.Add MakeBlock(BLOCK_NEWLINE, "")
    c.Add MakeBlock(BLOCK_NEWLINE, "")
    c.Add MakeBlock(BLOCK_TEXT, "本案電訪過程發現異常，請查照。")
    c.Add MakeBlock(BLOCK_NEWLINE, "")
    c.Add MakeBlock(BLOCK_TEXT, "異常項目：")
    c.Add MakeBlock(BLOCK_FIELD, "電訪異常項目勾選清單")
    c.Add MakeBlock(BLOCK_NEWLINE, "")
    c.Add MakeBlock(BLOCK_TEXT, "異常敘述：")
    c.Add MakeBlock(BLOCK_FIELD, "電訪異常敘述")
    Set DefaultBodyBlocks = c
End Function

' ===== 案件資料表格 =====

Public Function BuildCaseTableText(ByVal caseData As Object, ByVal fields As Collection) As String
    Dim i As Long, fieldName As String, s As String, w As Long, maxW As Long
    If fields.Count = 0 Then Exit Function
    For i = 1 To fields.Count
        w = DisplayWidth(NzText(fields(i)))
        If w > maxW Then maxW = w
    Next i
    For i = 1 To fields.Count
        fieldName = NzText(fields(i))
        s = s & fieldName & PadSpaces(maxW - DisplayWidth(fieldName)) & " ： " & DictGet(caseData, fieldName) & vbCrLf
    Next i
    BuildCaseTableText = s
End Function

Public Function BuildCaseTableHtml(ByVal caseData As Object, ByVal fields As Collection) As String
    Dim i As Long, fieldName As String, s As String
    If fields.Count = 0 Then Exit Function
    s = "<table border=""1"" cellspacing=""0"" cellpadding=""4"" " & _
        "style=""border-collapse:collapse;font-family:Microsoft JhengHei,Arial;font-size:10.5pt"">"
    For i = 1 To fields.Count
        fieldName = NzText(fields(i))
        s = s & "<tr>" & _
            "<td style=""background-color:#F2F2F2;white-space:nowrap""><b>" & HtmlEscape(fieldName) & "</b></td>" & _
            "<td>" & HtmlEscape(DictGet(caseData, fieldName)) & "</td></tr>"
    Next i
    BuildCaseTableHtml = s & "</table>"
End Function

' 內文模板 -> HTML（只有當內文含表格區塊時才會用到）
Public Function RenderHtmlBody(ByVal templateText As String, ByVal ctx As Object, ByVal tableHtml As String) As String
    Dim s As String, k As Variant
    ' 先整段跳脫，{{ }} 不含 HTML 特殊字元所以 token 會原樣保留
    s = HtmlEscape(templateText)
    For Each k In ctx.Keys
        If CStr(k) <> TABLE_TOKEN_KEY Then
            s = Replace(s, "{{" & CStr(k) & "}}", HtmlEscape(NzText(ctx(k))))
        End If
    Next k
    s = Replace(s, vbCrLf, "<br>")
    s = Replace(s, vbLf, "<br>")
    ' 表格最後才換入，避免被跳脫
    s = Replace(s, "{{" & TABLE_TOKEN_KEY & "}}", tableHtml)
    RenderHtmlBody = "<div style=""font-family:Microsoft JhengHei,Arial;font-size:10.5pt"">" & s & "</div>"
End Function

Public Function HtmlEscape(ByVal s As String) As String
    s = Replace(s, "&", "&amp;")
    s = Replace(s, "<", "&lt;")
    s = Replace(s, ">", "&gt;")
    s = Replace(s, """", "&quot;")
    HtmlEscape = s
End Function

' 中文字視為 2 個字元寬，讓純文字表格對齊得比較整齊
Private Function DisplayWidth(ByVal s As String) As Long
    Dim i As Long, n As Long
    For i = 1 To Len(s)
        If AscW(Mid$(s, i, 1)) > 255 Then
            n = n + 2
        Else
            n = n + 1
        End If
    Next i
    DisplayWidth = n
End Function

Private Function PadSpaces(ByVal n As Long) As String
    If n > 0 Then PadSpaces = Space$(n)
End Function
