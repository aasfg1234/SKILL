Attribute VB_Name = "modUtils"
Option Explicit

Public Function NzText(ByVal v As Variant, Optional ByVal fallback As String = "") As String
    If IsError(v) Then
        NzText = fallback
    ElseIf IsNull(v) Or IsEmpty(v) Then
        NzText = fallback
    Else
        NzText = Trim$(CStr(v))
        If NzText = "" Then NzText = fallback
    End If
End Function

Public Function CreateDict() As Object
    Set CreateDict = CreateObject("Scripting.Dictionary")
    CreateDict.CompareMode = 1
End Function

Public Function IsTruthy(ByVal v As Variant) As Boolean
    Dim s As String
    s = LCase$(NzText(v))
    IsTruthy = (s = "v" Or s = "y" Or s = "yes" Or s = "true" Or s = "1" Or s = "是" Or s = "有" Or s = "異常" Or s = "已勾選")
End Function

Public Function JoinCollection(ByVal c As Collection, Optional ByVal delimiter As String = "; ") As String
    Dim i As Long, s As String
    For i = 1 To c.Count
        If s <> "" Then s = s & delimiter
        s = s & NzText(c(i))
    Next i
    JoinCollection = s
End Function

Public Function SplitTargets(ByVal rawText As String) As Collection
    Dim c As New Collection
    Dim textValue As String, arr1() As String, arr2() As String
    Dim i As Long, j As Long, item As String
    textValue = Replace(Replace(rawText, "；", ";"), "，", ",")
    arr1 = Split(textValue, vbLf)
    For i = LBound(arr1) To UBound(arr1)
        arr2 = Split(Replace(arr1(i), ";", ","), ",")
        For j = LBound(arr2) To UBound(arr2)
            item = Trim$(Replace(arr2(j), vbCr, ""))
            If item <> "" Then c.Add item
        Next j
    Next i
    Set SplitTargets = c
End Function

Public Function DictGet(ByVal d As Object, ByVal keyName As String, Optional ByVal fallback As String = "") As String
    On Error Resume Next
    If d.Exists(keyName) Then
        DictGet = NzText(d(keyName), fallback)
    Else
        DictGet = fallback
    End If
    On Error GoTo 0
End Function

Public Function DictGetValue(ByVal d As Object, ByVal keyName As String) As Variant
    On Error Resume Next
    If d.Exists(keyName) Then
        DictGetValue = d(keyName)
    Else
        DictGetValue = Empty
    End If
    On Error GoTo 0
End Function

Public Sub DictSet(ByVal d As Object, ByVal keyName As String, ByVal v As Variant)
    If d.Exists(keyName) Then
        d(keyName) = v
    Else
        d.Add keyName, v
    End If
End Sub

Public Function ExtractEmail(ByVal rawText As String) As String
    Dim s As String
    s = Trim$(rawText)
    If InStr(1, s, "<") > 0 And InStr(1, s, ">") > InStr(1, s, "<") Then
        s = Mid$(s, InStr(1, s, "<") + 1)
        s = Left$(s, InStr(1, s, ">") - 1)
    End If
    If InStr(1, s, "@") > 0 Then ExtractEmail = Trim$(s)
End Function

Public Function NormalizeHeader(ByVal v As Variant) As String
    Dim s As String
    s = NzText(v)
    s = Replace(s, " ", "")
    s = Replace(s, vbTab, "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    NormalizeHeader = LCase$(s)
End Function

Public Function NormalizeLookupValue(ByVal v As Variant) As String
    Dim s As String
    If IsNumeric(v) Then
        If CDbl(v) = CLng(CDbl(v)) Then
            NormalizeLookupValue = CStr(CLng(CDbl(v)))
            Exit Function
        End If
    End If
    s = NzText(v)
    If Right$(s, 2) = ".0" Then
        If IsNumeric(Left$(s, Len(s) - 2)) Then s = Left$(s, Len(s) - 2)
    End If
    NormalizeLookupValue = s
End Function

Public Function ColumnLetterToIndex(ByVal letterText As String) As Long
    Dim i As Long, result As Long, s As String
    s = UCase$(Trim$(letterText))
    For i = 1 To Len(s)
        result = result * 26 + (Asc(Mid$(s, i, 1)) - Asc("A") + 1)
    Next i
    ColumnLetterToIndex = result
End Function

Public Function SheetExists(ByVal wb As Workbook, ByVal sheetName As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    SheetExists = Not ws Is Nothing
    Set ws = Nothing
    On Error GoTo 0
End Function

Public Function ThisSheetExists(ByVal sheetName As String) As Boolean
    ThisSheetExists = SheetExists(ThisWorkbook, sheetName)
End Function

Public Function ReplaceTemplateTokens(ByVal templateText As String, ByVal data As Object) As String
    Dim resultText As String
    Dim k As Variant
    resultText = templateText
    For Each k In data.Keys
        resultText = Replace(resultText, "{{" & CStr(k) & "}}", NzText(data(k)))
    Next k
    ReplaceTemplateTokens = resultText
End Function

Public Function SerializeCellValue(ByVal v As Variant) As String
    If IsDate(v) Then
        SerializeCellValue = Format$(CDate(v), "yyyy-mm-dd hh:nn:ss")
    Else
        SerializeCellValue = NzText(v)
    End If
End Function

Public Function NewUniqueCollection() As Collection
    Set NewUniqueCollection = New Collection
End Function

Public Sub AddUniqueText(ByRef c As Collection, ByVal valueText As String)
    Dim i As Long, keyText As String
    keyText = LCase$(Trim$(valueText))
    If keyText = "" Then Exit Sub
    For i = 1 To c.Count
        If LCase$(Trim$(CStr(c(i)))) = keyText Then Exit Sub
    Next i
    c.Add Trim$(valueText)
End Sub
