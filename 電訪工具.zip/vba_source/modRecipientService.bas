Attribute VB_Name = "modRecipientService"
Option Explicit

Public Function ResolveRecipients(ByVal roleTokens As Collection, ByVal caseData As Object) As Collection
    Dim c As Collection, item As Variant, roleName As String
    Set c = NewUniqueCollection()
    For Each item In roleTokens
        roleName = Trim$(CStr(item))
        Select Case roleName
            Case "銷售人員"
                AddUniqueText c, ResolveSalesPerson(caseData)
            Case "IC"
                AddUniqueText c, ResolveIC(caseData)
            Case "IC組長"
                AddUniqueText c, ResolveICTeamLead(caseData)
            Case "分行經理"
                AddUniqueText c, ResolveBranchManager(caseData)
            Case "理財業務主管"
                AddUniqueText c, ResolveWealthSupervisor(caseData)
            Case Else
                AddGroupMembers c, GetGroupTargets(roleName)
        End Select
    Next item
    Set ResolveRecipients = c
End Function

Private Sub AddGroupMembers(ByRef c As Collection, ByVal members As Collection)
    Dim item As Variant
    For Each item In members
        AddUniqueText c, CStr(item)
    Next item
End Sub

Public Function ResolveSalesPerson(ByVal caseData As Object) As String
    Dim rawText As String
    rawText = DictGet(caseData, "銷售人員")
    If InStr(1, rawText, "@") > 0 Then
        ResolveSalesPerson = ExtractEmail(rawText)
    Else
        ResolveSalesPerson = FindStaffTargetByName(rawText)
        If ResolveSalesPerson = "" Then ResolveSalesPerson = rawText
    End If
End Function

Public Function ResolveIC(ByVal caseData As Object) As String
    ResolveIC = FindICByBranch(DictGet(caseData, "銷售分行/分公司"), "IC")
End Function

Public Function ResolveICTeamLead(ByVal caseData As Object) As String
    ResolveICTeamLead = FindICByBranch(DictGet(caseData, "銷售分行/分公司"), "IC組長")
End Function

Public Function ResolveBranchManager(ByVal caseData As Object) As String
    ResolveBranchManager = FindStaffByBranchAndRole(DictGet(caseData, "銷售分行/分公司"), "分行經理")
End Function

Public Function ResolveWealthSupervisor(ByVal caseData As Object) As String
    ResolveWealthSupervisor = FindStaffByBranchAndRole(DictGet(caseData, "銷售分行/分公司"), "理財業務主管")
End Function

Public Function FindICByBranch(ByVal branchName As String, ByVal roleName As String) As String
    Dim ws As Worksheet
    Dim lastRow As Long, r As Long
    Dim branchText As String, targetText As String
    If Not ThisSheetExists(SHEET_IC) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SHEET_IC)
    lastRow = ws.Cells(ws.Rows.Count, 4).End(xlUp).Row
    For r = 2 To lastRow
        branchText = NzText(ws.Cells(r, 4).Value)
        If branchText = Trim$(branchName) Then
            If roleName = "IC" Then targetText = NzText(ws.Cells(r, 5).Value)
            If roleName = "IC組長" Then targetText = NzText(ws.Cells(r, 7).Value)
            If InStr(1, targetText, "@") > 0 Then
                FindICByBranch = ExtractEmail(targetText)
            Else
                FindICByBranch = CleanPersonName(targetText)
            End If
            Exit Function
        End If
    Next r
End Function

Public Function FindStaffByBranchAndRole(ByVal branchName As String, ByVal roleName As String) As String
    Dim ws As Worksheet
    Dim lastRow As Long, lastCol As Long, r As Long, c As Long
    Dim branchText As String, workText As String, familyText As String, titleText As String
    Dim personName As String, emailText As String, valueText As String
    If Not ThisSheetExists(SHEET_STAFF) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SHEET_STAFF)
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    lastCol = ws.Cells(1, ws.Columns.Count).End(xlToLeft).Column
    For r = 2 To lastRow
        branchText = NzText(ws.Cells(r, 5).Value)
        workText = NzText(ws.Cells(r, 10).Value)
        familyText = NzText(ws.Cells(r, 7).Value)
        titleText = NzText(ws.Cells(r, 9).Value)
        personName = CleanPersonName(NzText(ws.Cells(r, 2).Value))
        If branchText = Trim$(branchName) Or workText = Trim$(branchName) Then
            If roleName = "分行經理" Then
                If InStr(1, familyText, "分行經理") > 0 Or InStr(1, titleText, "分行經理") > 0 Then
                    For c = 1 To lastCol
                        valueText = NzText(ws.Cells(r, c).Value)
                        If InStr(1, valueText, "@") > 0 Then emailText = ExtractEmail(valueText)
                    Next c
                    FindStaffByBranchAndRole = IIf(emailText <> "", emailText, personName)
                    Exit Function
                End If
            ElseIf roleName = "理財業務主管" Then
                If InStr(1, familyText, "理財") > 0 Or InStr(1, titleText, "理財") > 0 Or InStr(1, titleText, "主管") > 0 Then
                    For c = 1 To lastCol
                        valueText = NzText(ws.Cells(r, c).Value)
                        If InStr(1, valueText, "@") > 0 Then emailText = ExtractEmail(valueText)
                    Next c
                    FindStaffByBranchAndRole = IIf(emailText <> "", emailText, personName)
                    Exit Function
                End If
            End If
        End If
    Next r
End Function

Public Function FindStaffTargetByName(ByVal personName As String) As String
    Dim ws As Worksheet
    Dim lastRow As Long, lastCol As Long, r As Long, c As Long
    Dim nameText As String, valueText As String
    If Not ThisSheetExists(SHEET_STAFF) Then Exit Function
    Set ws = ThisWorkbook.Worksheets(SHEET_STAFF)
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    lastCol = ws.Cells(1, ws.Columns.Count).End(xlToLeft).Column
    For r = 2 To lastRow
        nameText = CleanPersonName(NzText(ws.Cells(r, 2).Value))
        If nameText = CleanPersonName(personName) Then
            For c = 1 To lastCol
                valueText = NzText(ws.Cells(r, c).Value)
                If InStr(1, valueText, "@") > 0 Then
                    FindStaffTargetByName = ExtractEmail(valueText)
                    Exit Function
                End If
            Next c
            FindStaffTargetByName = nameText
            Exit Function
        End If
    Next r
End Function

Public Function CleanPersonName(ByVal rawText As String) As String
    Dim s As String, p As Long
    s = Trim$(rawText)
    p = InStr(s, "(")
    If p > 0 Then s = Trim$(Left$(s, p - 1))
    p = InStr(s, "（")
    If p > 0 Then s = Trim$(Left$(s, p - 1))
    CleanPersonName = s
End Function
