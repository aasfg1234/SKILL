Attribute VB_Name = "modFormHelpers"
Option Explicit

Public Function GetCtlText(ByVal frm As Object, ByVal ctlName As String) As String
    On Error Resume Next
    GetCtlText = NzText(frm.Controls(ctlName).Value)
    On Error GoTo 0
End Function

Public Sub SetCtlText(ByVal frm As Object, ByVal ctlName As String, ByVal textValue As String)
    On Error Resume Next
    frm.Controls(ctlName).Value = textValue
    On Error GoTo 0
End Sub

Public Sub SetCtlCaption(ByVal frm As Object, ByVal ctlName As String, ByVal textValue As String)
    On Error Resume Next
    frm.Controls(ctlName).Caption = textValue
    On Error GoTo 0
End Sub

Public Sub FillCombo(ByVal frm As Object, ByVal ctlName As String, ByVal values As Variant)
    Dim i As Long
    On Error Resume Next
    frm.Controls(ctlName).Clear
    For i = LBound(values) To UBound(values)
        frm.Controls(ctlName).AddItem CStr(values(i))
    Next i
    On Error GoTo 0
End Sub

Public Sub FillComboFromCollection(ByVal frm As Object, ByVal ctlName As String, ByVal c As Collection)
    Dim i As Long
    On Error Resume Next
    frm.Controls(ctlName).Clear
    For i = 1 To c.Count
        frm.Controls(ctlName).AddItem CStr(c(i))
    Next i
    On Error GoTo 0
End Sub

Public Sub FillListBoxFromCollection(ByVal frm As Object, ByVal ctlName As String, ByVal c As Collection)
    FillComboFromCollection frm, ctlName, c
End Sub

Public Function GetListBoxValue(ByVal frm As Object, ByVal ctlName As String) As String
    On Error Resume Next
    If frm.Controls(ctlName).ListIndex >= 0 Then GetListBoxValue = NzText(frm.Controls(ctlName).List(frm.Controls(ctlName).ListIndex))
    On Error GoTo 0
End Function

Public Sub SetChkValue(ByVal frm As Object, ByVal ctlName As String, ByVal checkedValue As Boolean)
    On Error Resume Next
    frm.Controls(ctlName).Value = checkedValue
    On Error GoTo 0
End Sub

Public Function GetChkValue(ByVal frm As Object, ByVal ctlName As String) As Boolean
    On Error Resume Next
    GetChkValue = CBool(frm.Controls(ctlName).Value)
    On Error GoTo 0
End Function

' ===== 多選清單 =====
' 註：UserForm.Controls 是平面集合，巢狀在 MultiPage 分頁裡的控制項
'     一樣可以用 frm.Controls("名稱") 直接取得，不必逐層往下找。

Public Sub FillListFromArray(ByVal frm As Object, ByVal ctlName As String, ByVal values As Variant)
    Dim i As Long
    On Error Resume Next
    frm.Controls(ctlName).Clear
    For i = LBound(values) To UBound(values)
        frm.Controls(ctlName).AddItem CStr(values(i))
    Next i
    On Error GoTo 0
End Sub

Public Function GetListSelected(ByVal frm As Object, ByVal ctlName As String) As Collection
    Dim c As New Collection, i As Long, ctl As Object
    On Error Resume Next
    Set ctl = frm.Controls(ctlName)
    For i = 0 To ctl.ListCount - 1
        If ctl.Selected(i) Then c.Add NzText(ctl.List(i))
    Next i
    On Error GoTo 0
    Set GetListSelected = c
End Function

Public Sub SetListSelected(ByVal frm As Object, ByVal ctlName As String, ByVal wanted As Collection)
    Dim i As Long, j As Long, ctl As Object, itemText As String
    On Error Resume Next
    Set ctl = frm.Controls(ctlName)
    For i = 0 To ctl.ListCount - 1
        itemText = LCase$(Trim$(NzText(ctl.List(i))))
        ctl.Selected(i) = False
        For j = 1 To wanted.Count
            If LCase$(Trim$(NzText(wanted(j)))) = itemText Then
                ctl.Selected(i) = True
                Exit For
            End If
        Next j
    Next i
    On Error GoTo 0
End Sub

Public Function GetListIndex(ByVal frm As Object, ByVal ctlName As String) As Long
    On Error Resume Next
    GetListIndex = -1
    GetListIndex = frm.Controls(ctlName).ListIndex
    On Error GoTo 0
End Function

Public Sub SetListIndex(ByVal frm As Object, ByVal ctlName As String, ByVal idx As Long)
    On Error Resume Next
    frm.Controls(ctlName).ListIndex = idx
    On Error GoTo 0
End Sub
