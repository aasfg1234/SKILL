Attribute VB_Name = "modMain"
Option Explicit

' 建議在 ThisWorkbook 的 Workbook_Open 事件呼叫本程序（建置腳本已自動寫入，
' 若日後手動重建活頁簿需自行於 VBE 加入）：
'
'   Private Sub Workbook_Open()
'       modMain.LaunchApp
'   End Sub
Public Sub LaunchApp()
    On Error GoTo EH
    EnsureAppReady
    frmMainMenu.Show
    Exit Sub
EH:
    LogError "LaunchApp", CStr(Err.Number) & " - " & Err.Description
    MsgBox "系統啟動失敗：" & Err.Description, vbCritical
End Sub

Public Sub EnsureAppReady()
    EnsureRequiredSheets
End Sub
