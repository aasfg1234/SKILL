Attribute VB_Name = "modLogger"
Option Explicit

Public Sub LogInfo(ByVal funcName As String, ByVal messageText As String)
    AppendLog "INFO", funcName, messageText
End Sub

Public Sub LogError(ByVal funcName As String, ByVal messageText As String)
    AppendLog "ERROR", funcName, messageText
End Sub

Private Sub AppendLog(ByVal levelName As String, ByVal funcName As String, ByVal messageText As String)
    Dim ws As Worksheet, nextRow As Long
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(SHEET_LOG)
    If ws Is Nothing Then Exit Sub
    nextRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If nextRow < 2 Then nextRow = 2
    ws.Cells(nextRow, 1).Value = Now
    ws.Cells(nextRow, 2).Value = levelName
    ws.Cells(nextRow, 3).Value = funcName
    ws.Cells(nextRow, 4).Value = messageText
    On Error GoTo 0
End Sub
