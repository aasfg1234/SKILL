Attribute VB_Name = "modConstants"
Option Explicit

Public Const APP_TITLE As String = "電訪結果登錄與異常通知"
Public Const SHEET_CONFIG As String = "設定"
Public Const SHEET_MAIL As String = "郵件設定"
Public Const SHEET_GROUPS As String = "收件群組"
Public Const SHEET_IC As String = "IC清單_匯入"
Public Const SHEET_STAFF As String = "通路人員清單_匯入"
Public Const SHEET_LOG As String = "系統Log"
Public Const MAIL_MODE_SEND As String = "send"
Public Const MAIL_MODE_DRAFT As String = "draft"

' 寄信模式的畫面顯示文字（設定檔仍存 send/draft，不影響既有商業邏輯）
Public Const MAIL_MODE_DRAFT_LABEL As String = "擬信不寄出（開啟草稿）"
Public Const MAIL_MODE_SEND_LABEL As String = "直接寄出"

' 勾選欄位寫回主資料表的值
Public Const CHECK_YES As String = "Y"
Public Const CHECK_NO As String = "N"

' 郵件模板區塊型別
Public Const BLOCK_TEXT As String = "T"      ' 固定文字
Public Const BLOCK_FIELD As String = "F"     ' 變動文字（帶入欄位）
Public Const BLOCK_NEWLINE As String = "N"   ' 換行
Public Const BLOCK_TABLE As String = "B"     ' 表格
Public Const BLOCK_SEPARATOR As String = vbLf

' 表格在模板中的代表 token
Public Const TABLE_TOKEN_KEY As String = "案件資料表格"

Private Function ListToArray(ByVal listText As String) As Variant
    ListToArray = Split(listText, "|")
End Function

Public Function InterviewTargetOptions() As Variant
    InterviewTargetOptions = Array("要保人", "被保險人", "付款人")
End Function

Public Function DefaultInterviewers() As Variant
    DefaultInterviewers = Array("陳貞君", "郭子安", "呂美芸", "林明儒", "謝幸宸")
End Function

Public Function FixedRoles() As Variant
    FixedRoles = Array("銷售人員", "理財業務主管", "分行經理", "IC", "IC組長")
End Function

Public Function RegistrationBaseFields() As Variant
    Dim s As String
    s = "序號|建檔年月|新契約受理編號|電訪受理人員|電訪組受理案件日|保險公司|通路|區部|銷售分行/分公司|銷售人員|要保人|要保人年齡"
    s = s & "|被保人|被保人年齡|付款人|付款人年齡|電訪對象|是否需進行高齡電訪|系統核3個月內有辦定存解約|系統檢核3個月內有撥貸或核准透支額度"
    s = s & "|系統檢核一年內有申辦中貸款記錄|系統檢核3個月內有動用透支額度|系統檢核3個月內有RS債券合約|系統檢核3個月內有辦保單借款"
    s = s & "|系統檢核3個月內有辦保險解約|系統檢核3個月內有辦繳清／展期|業報書資金來源貸款|業報書資金來源保單借款|業報書資金來源定存解約"
    s = s & "|業報書資金來源保險解約|業報書3個月內有辦貸款|業報書3個月內有辦保單借款|業報書3個月內有辦保單解約|電訪專員|電訪對象第幾次電訪"
    RegistrationBaseFields = ListToArray(s)
End Function

Public Function RegistrationManualFields() As Variant
    Dim s As String
    s = "新契約受理編號|電訪受理人員|電訪組受理案件日|付款人|付款人年齡|電訪對象|系統核3個月內有辦定存解約|系統檢核3個月內有撥貸或核准透支額度"
    s = s & "|系統檢核一年內有申辦中貸款記錄|系統檢核3個月內有動用透支額度|系統檢核3個月內有RS債券合約|系統檢核3個月內有辦保單借款"
    s = s & "|系統檢核3個月內有辦保險解約|系統檢核3個月內有辦繳清／展期|業報書資金來源貸款|業報書資金來源保單借款|業報書資金來源定存解約"
    s = s & "|業報書資金來源保險解約|業報書3個月內有辦貸款|業報書3個月內有辦保單借款|業報書3個月內有辦保單解約|電訪專員"
    RegistrationManualFields = ListToArray(s)
End Function

Public Function ResultEditFields() As Variant
    Dim s As String
    s = "電訪日期|電訪時間|電訪應訪問項高齡|電訪應訪問項貸款|電訪應訪問項定存解約|電訪應訪問項保單解約"
    s = s & "|電訪應訪問項保單借款|電訪應訪問項繳清／展期|電訪是否完成|電訪過程是否發現異常|電訪單覆核|退件查核備註(有電訪無問題V)(未電訪誤送保險公司X)"
    ResultEditFields = ListToArray(s)
End Function

Public Function MasterHeaders() As Variant
    Dim s As String
    s = "序號|建檔年月|新契約受理編號|電訪受理人員|電訪組受理案件日|保險公司|通路|區部|銷售分行/分公司|銷售人員|要保人|要保人年齡"
    s = s & "|被保人|被保人年齡|付款人|付款人年齡|電訪對象|是否需進行高齡電訪|系統核3個月內有辦定存解約|系統檢核3個月內有撥貸或核准透支額度"
    s = s & "|系統檢核一年內有申辦中貸款記錄|系統檢核3個月內有動用透支額度|系統檢核3個月內有RS債券合約|系統檢核3個月內有辦保單借款"
    s = s & "|系統檢核3個月內有辦保險解約|系統檢核3個月內有辦繳清／展期|業報書資金來源貸款|業報書資金來源保單借款|業報書資金來源定存解約"
    s = s & "|業報書資金來源保險解約|業報書3個月內有辦貸款|業報書3個月內有辦保單借款|業報書3個月內有辦保單解約|電訪專員|電訪對象第幾次電訪"
    s = s & "|電訪日期|電訪時間|電訪應訪問項高齡|電訪應訪問項貸款|電訪應訪問項定存解約|電訪應訪問項保單解約|電訪應訪問項保單借款"
    s = s & "|電訪應訪問項繳清／展期|電訪是否完成|電訪過程是否發現異常|A1無法聯絡|A2拒訪|A3不同意錄音|A4欲取消投保／變更投保內容|A5*未同意投保"
    s = s & "|A6核身異常|A7*保費負擔有影響經濟生活之疑慮|A8*不確定招攬人員同業報書上之業務員|A9*有未親晤或非親簽文件疑慮|A10不清楚保單內容"
    s = s & "|A11投保經驗與高齡評估量表不一致|A12視覺,聽覺,精神,心智功能與評估量表不一致|A13不了解健康告知不誠實之相關權益|A14未落實填寫健康告知事項"
    s = s & "|A15*投保日期與要保書不一致|A16*投保地點與進件檢核表不一致|B03個月內辦理業務項目與系統檢核不一致|B13個月內辦理業務項目與業報書不一致"
    s = s & "|B2不清楚保費資金來源|B3保費資金來源與業報書不一致|B4不清楚貸款相關風險|B5*有勸誘貸款買保險疑慮|B6*有貸款綁售保險疑慮|B7不清楚保單借款之相關風險"
    s = s & "|B8*有勸誘以保單借款購買新保單疑慮|B9不清楚解約舊保單再投保新保單相關風險|B10*有勸誘解約舊保單再投保新保單疑慮|B11不清楚定存解約相關風險"
    s = s & "|B12不清楚保險與定存是不同的商品|B13*有勸誘以定存解約購買新保單疑慮|B14不清楚繳清／展期相關風險|B15*有勸誘客戶繳清/展期後購買新單疑慮"
    s = s & "|C1*不清楚購買的是保險|C2不清楚投保之商品類型|C3*業務員告知投資型保單有保本保證(身故保本除外)|C4不清楚投資型保單沒有保本及獲利之保證"
    s = s & "|C5不清楚投資型(非年金)保單每月收取危險保費及相關權益|C6不清楚年金險沒有壽險保障|C7不清楚本保單提前解約可能有損失風險|C8不清楚利率變動型商品特色|C9不清楚保單分紅非保證給付項目"
    s = s & "|D1不清楚外幣匯兌風險|D2不清楚/不同意/要變更身故受益人|D3不清楚實質課稅原則與相關權益影響|D4商品不符合需求|D5繳費之人不同意支付保費"
    s = s & "|D6務員指導或勸誘客戶回答電訪問項|D97投保目的與業報書不一致|D98要保文件填寫錯誤/遺漏(5/20)|D99客戶其他異常陳述|E1退件|E2退件不續訪|E3退件不續訪&3個月內不得進件|E9因照會補正業報書"
    s = s & "|電訪單覆核|退件查核備註(有電訪無問題V)(未電訪誤送保險公司X)|電訪異常敘述"
    MasterHeaders = ListToArray(s)
End Function

Public Function AbnormalItems() As Variant
    Dim s As String
    s = "A1無法聯絡|A2拒訪|A3不同意錄音|A4欲取消投保／變更投保內容|A5*未同意投保|A6核身異常|A7*保費負擔有影響經濟生活之疑慮"
    s = s & "|A8*不確定招攬人員同業報書上之業務員|A9*有未親晤或非親簽文件疑慮|A10不清楚保單內容|A11投保經驗與高齡評估量表不一致"
    s = s & "|A12視覺,聽覺,精神,心智功能與評估量表不一致|A13不了解健康告知不誠實之相關權益|A14未落實填寫健康告知事項|A15*投保日期與要保書不一致|A16*投保地點與進件檢核表不一致"
    s = s & "|B03個月內辦理業務項目與系統檢核不一致|B13個月內辦理業務項目與業報書不一致|B2不清楚保費資金來源|B3保費資金來源與業報書不一致|B4不清楚貸款相關風險"
    s = s & "|B5*有勸誘貸款買保險疑慮|B6*有貸款綁售保險疑慮|B7不清楚保單借款之相關風險|B8*有勸誘以保單借款購買新保單疑慮|B9不清楚解約舊保單再投保新保單相關風險"
    s = s & "|B10*有勸誘解約舊保單再投保新保單疑慮|B11不清楚定存解約相關風險|B12不清楚保險與定存是不同的商品|B13*有勸誘以定存解約購買新保單疑慮|B14不清楚繳清／展期相關風險"
    s = s & "|B15*有勸誘客戶繳清/展期後購買新單疑慮|C1*不清楚購買的是保險|C2不清楚投保之商品類型|C3*業務員告知投資型保單有保本保證(身故保本除外)"
    s = s & "|C4不清楚投資型保單沒有保本及獲利之保證|C5不清楚投資型(非年金)保單每月收取危險保費及相關權益|C6不清楚年金險沒有壽險保障|C7不清楚本保單提前解約可能有損失風險"
    s = s & "|C8不清楚利率變動型商品特色|C9不清楚保單分紅非保證給付項目|D1不清楚外幣匯兌風險|D2不清楚/不同意/要變更身故受益人|D3不清楚實質課稅原則與相關權益影響"
    s = s & "|D4商品不符合需求|D5繳費之人不同意支付保費|D6務員指導或勸誘客戶回答電訪問項|D97投保目的與業報書不一致|D98要保文件填寫錯誤/遺漏(5/20)|D99客戶其他異常陳述|E1退件|E2退件不續訪|E3退件不續訪&3個月內不得進件|E9因照會補正業報書"
    AbnormalItems = ListToArray(s)
End Function

' ===== 案件登記：以勾選呈現的欄位（勾選寫 Y、未勾選寫 N） =====

Public Function RegistrationSystemCheckFields() As Variant
    Dim s As String
    s = "系統核3個月內有辦定存解約|系統檢核3個月內有撥貸或核准透支額度|系統檢核一年內有申辦中貸款記錄"
    s = s & "|系統檢核3個月內有動用透支額度|系統檢核3個月內有RS債券合約|系統檢核3個月內有辦保單借款"
    s = s & "|系統檢核3個月內有辦保險解約|系統檢核3個月內有辦繳清／展期"
    RegistrationSystemCheckFields = ListToArray(s)
End Function

Public Function RegistrationReportFields() As Variant
    Dim s As String
    s = "業報書資金來源貸款|業報書資金來源保單借款|業報書資金來源定存解約|業報書資金來源保險解約"
    s = s & "|業報書3個月內有辦貸款|業報書3個月內有辦保單借款|業報書3個月內有辦保單解約"
    RegistrationReportFields = ListToArray(s)
End Function

Public Function IsRegistrationCheckField(ByVal fieldName As String) As Boolean
    IsRegistrationCheckField = ArrayHasValue(RegistrationSystemCheckFields(), fieldName) _
        Or ArrayHasValue(RegistrationReportFields(), fieldName)
End Function

' 案件登記用下拉選單（而非自由輸入）的欄位
Public Function RegistrationListFields() As Variant
    RegistrationListFields = Array("電訪受理人員", "電訪對象", "電訪專員")
End Function

Public Function ArrayHasValue(ByVal arr As Variant, ByVal v As String) As Boolean
    Dim i As Long
    For i = LBound(arr) To UBound(arr)
        If CStr(arr(i)) = v Then
            ArrayHasValue = True
            Exit Function
        End If
    Next i
End Function

' ===== 寄信模式標籤轉換（預設一律為「擬信不寄出」） =====

Public Function MailModeLabels() As Variant
    MailModeLabels = Array(MAIL_MODE_DRAFT_LABEL, MAIL_MODE_SEND_LABEL)
End Function

Public Function LabelToMailMode(ByVal labelText As String) As String
    If Trim$(labelText) = MAIL_MODE_SEND_LABEL Then
        LabelToMailMode = MAIL_MODE_SEND
    Else
        LabelToMailMode = MAIL_MODE_DRAFT
    End If
End Function

Public Function MailModeToLabel(ByVal modeName As String) As String
    If LCase$(Trim$(modeName)) = MAIL_MODE_SEND Then
        MailModeToLabel = MAIL_MODE_SEND_LABEL
    Else
        MailModeToLabel = MAIL_MODE_DRAFT_LABEL
    End If
End Function

' 只有明確等於 "send" 才視為直接寄出，其餘（空白、拼錯、舊值）一律當草稿，
' 確保任何設定異常都不會造成誤寄。
Public Function NormalizeMailMode(ByVal modeName As String) As String
    If LCase$(Trim$(modeName)) = MAIL_MODE_SEND Then
        NormalizeMailMode = MAIL_MODE_SEND
    Else
        NormalizeMailMode = MAIL_MODE_DRAFT
    End If
End Function

' ===== 郵件模板可帶入的欄位（給「新增變動文字」下拉選單用） =====

Public Function TemplateFieldOptions() As Variant
    Dim headers As Variant, extras As Variant, result() As String
    Dim i As Long, n As Long
    headers = MasterHeaders()
    extras = Array("電訪異常項目勾選清單", "電訪異常敘述", "其他電訪紀錄摘要")
    n = (UBound(headers) - LBound(headers) + 1) + (UBound(extras) - LBound(extras) + 1)
    ReDim result(0 To n - 1)
    For i = LBound(extras) To UBound(extras)
        result(i) = CStr(extras(i))
    Next i
    n = UBound(extras) - LBound(extras) + 1
    For i = LBound(headers) To UBound(headers)
        result(n + i) = CStr(headers(i))
    Next i
    TemplateFieldOptions = result
End Function

' 表格預設要顯示的欄位
Public Function DefaultTableFields() As Variant
    Dim s As String
    s = "序號|新契約受理編號|要保人|銷售分行/分公司|銷售人員|電訪日期|電訪異常項目勾選清單|電訪異常敘述"
    DefaultTableFields = ListToArray(s)
End Function

' 案件登記建立新列時，從上一列複製過來的欄位（原本用欄位字母 A,B,D,E,F,G,H,I,J,K,L,M,N,R,AI 寫死，
' 改成用欄位名稱對應，主資料表欄位順序異動時不會錯位）
Public Function AutoCopySourceFields() As Variant
    Dim s As String
    s = "序號|建檔年月|電訪受理人員|電訪組受理案件日|保險公司|通路|區部|銷售分行/分公司|銷售人員|要保人|要保人年齡"
    s = s & "|被保人|被保人年齡|是否需進行高齡電訪|電訪對象第幾次電訪"
    AutoCopySourceFields = ListToArray(s)
End Function
