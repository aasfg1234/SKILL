Attribute VB_Name = "modMailService"
Option Explicit

Public Function NotifyResultOnly(ByVal caseData As Object, ByVal abnormalItems As Collection, ByVal abnormalDesc As String) As Object
    Dim cfg As Object, toC As Collection, ccC As Collection, d As Object, ctx As Object
    Dim olApp As Object, mailItem As Object, modeName As String
    Dim bodyTemplate As String, tableFields As Collection, useHtml As Boolean
    If abnormalItems.Count = 0 Then Err.Raise vbObjectError + 1200, "NotifyResultOnly", "未勾選任何異常項目，無需寄送通知。"
    Set cfg = GetMailTemplateConfig()
    Set ctx = CreateDict()
    MergeCaseData ctx, caseData
    DictSet ctx, "電訪異常項目勾選清單", JoinCollection(abnormalItems, "、")
    DictSet ctx, "電訪異常敘述", abnormalDesc
    bodyTemplate = DictGet(cfg, "body_template")
    Set tableFields = GetTableFields()
    DictSet ctx, TABLE_TOKEN_KEY, BuildCaseTableText(ctx, tableFields)
    ' 內文有放表格區塊時改用 HTML，才能呈現真正的表格框線
    useHtml = (InStr(1, bodyTemplate, "{{" & TABLE_TOKEN_KEY & "}}") > 0)
    Set toC = ResolveRecipients(SplitTargets(DictGet(cfg, "to_roles", "銷售人員,IC")), ctx)
    Set ccC = ResolveRecipients(SplitTargets(DictGet(cfg, "cc_roles", "IC組長")), ctx)
    If toC.Count = 0 Then Err.Raise vbObjectError + 1201, "NotifyResultOnly", "未解析出任何收件者。"
    ' 只有明確設定為 send 才會直接寄出，其餘一律開草稿，避免誤寄
    modeName = NormalizeMailMode(DictGet(cfg, "mail_mode", GetMailMode()))
    Set olApp = CreateObject("Outlook.Application")
    Set mailItem = olApp.CreateItem(0)
    With mailItem
        .To = JoinCollection(toC, ";")
        .CC = JoinCollection(ccC, ";")
        .Subject = ReplaceTemplateTokens(DictGet(cfg, "subject_template"), ctx)
        If useHtml Then
            .HTMLBody = RenderHtmlBody(bodyTemplate, ctx, BuildCaseTableHtml(ctx, tableFields))
        Else
            .Body = ReplaceTemplateTokens(bodyTemplate, ctx)
        End If
        If modeName = MAIL_MODE_SEND Then
            .Send
        Else
            .Display
        End If
    End With
    Set d = CreateDict()
    DictSet d, "mail_result", IIf(modeName = MAIL_MODE_SEND, "sent", "draft")
    DictSet d, "to", JoinCollection(toC, "; ")
    DictSet d, "cc", JoinCollection(ccC, "; ")
    Set NotifyResultOnly = d
End Function

Private Sub MergeCaseData(ByVal target As Object, ByVal source As Object)
    Dim k As Variant
    For Each k In source.Keys
        DictSet target, CStr(k), source(k)
    Next k
End Sub
