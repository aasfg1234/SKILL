Attribute VB_Name = "modImportService"
Option Explicit

Public Sub ImportICList()
    Dim filePath As Variant, srcWb As Workbook, dstWs As Worksheet, rg As Range
    On Error GoTo EH
    filePath = Application.GetOpenFilename("Excel Files (*.xls;*.xlsx;*.xlsm;*.xlsb),*.xls;*.xlsx;*.xlsm;*.xlsb", , "選擇 IC 清單")
    If filePath = False Then Exit Sub
    Application.ScreenUpdating = False
    Set srcWb = Workbooks.Open(CStr(filePath), ReadOnly:=True)
    Set dstWs = ThisWorkbook.Worksheets(SHEET_IC)
    dstWs.Cells.Clear
    Set rg = srcWb.Worksheets(1).UsedRange
    dstWs.Range("A1").Resize(rg.Rows.Count, rg.Columns.Count).Value = rg.Value
    srcWb.Close SaveChanges:=False
    Application.ScreenUpdating = True
    MsgBox "IC 清單匯入完成。", vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not srcWb Is Nothing Then srcWb.Close SaveChanges:=False
    Application.ScreenUpdating = True
    MsgBox "IC 清單匯入失敗：" & Err.Description, vbExclamation
End Sub

Public Sub ImportStaffList()
    Dim filePath As Variant, srcWb As Workbook, dstWs As Worksheet, rg As Range
    On Error GoTo EH
    filePath = Application.GetOpenFilename("Excel Files (*.xls;*.xlsx;*.xlsm;*.xlsb),*.xls;*.xlsx;*.xlsm;*.xlsb", , "選擇通路人員清單")
    If filePath = False Then Exit Sub
    Application.ScreenUpdating = False
    Set srcWb = Workbooks.Open(CStr(filePath), ReadOnly:=True)
    Set dstWs = ThisWorkbook.Worksheets(SHEET_STAFF)
    dstWs.Cells.Clear
    Set rg = srcWb.Worksheets(1).UsedRange
    dstWs.Range("A1").Resize(rg.Rows.Count, rg.Columns.Count).Value = rg.Value
    srcWb.Close SaveChanges:=False
    Application.ScreenUpdating = True
    MsgBox "通路人員清單匯入完成。", vbInformation
    Exit Sub
EH:
    On Error Resume Next
    If Not srcWb Is Nothing Then srcWb.Close SaveChanges:=False
    Application.ScreenUpdating = True
    MsgBox "通路人員清單匯入失敗：" & Err.Description, vbExclamation
End Sub
