Attribute VB_Name = "modWorkbookService"
Option Explicit

Public Function OpenMasterWorkbook(Optional ByVal readOnly As Boolean = True) As Workbook
    Dim filePath As String, pwd As String
    filePath = GetMasterWorkbookPath()
    pwd = GetMasterPassword()
    If filePath = "" Then Err.Raise vbObjectError + 1100, "OpenMasterWorkbook", "�Х��]�w�D��ƪ����|�C"
    If Dir(filePath) = "" Then Err.Raise vbObjectError + 1101, "OpenMasterWorkbook", "�䤣��D��ƪ��G" & filePath
    If pwd = "" Then Err.Raise vbObjectError + 1102, "OpenMasterWorkbook", "�Х���J�D��ƪ��K�X�C"
    Set OpenMasterWorkbook = Application.Workbooks.Open( _
        Filename:=filePath, UpdateLinks:=0, ReadOnly:=readOnly, Password:=pwd, _
        IgnoreReadOnlyRecommended:=True, AddToMru:=False, Local:=True)
End Function

Public Function ListSheetNames() As Collection
    Dim wb As Workbook, ws As Worksheet, c As New Collection
    On Error GoTo EH
    Set wb = OpenMasterWorkbook(True)
    For Each ws In wb.Worksheets
        c.Add ws.Name
    Next ws
    wb.Close SaveChanges:=False
    Set ListSheetNames = c
    Exit Function
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    Err.Raise Err.Number, "ListSheetNames", Err.Description
End Function

Private Sub RequireMasterTarget(ByRef workbookPath As String, ByRef sheetName As String)
    workbookPath = GetMasterWorkbookPath()
    sheetName = GetDefaultSheetName()
    If workbookPath = "" Then Err.Raise vbObjectError + 1105, "RequireMasterTarget", "�Х��]�w�D��ƪ����|�C"
    If sheetName = "" Then Err.Raise vbObjectError + 1106, "RequireMasterTarget", "�Х���ܥD��ƪ��u�@���C"
End Sub

Public Function PreviewRegistrationByAcceptanceNo(ByVal acceptanceNo As String) As Object
    Dim workbookPath As String, sheetName As String
    Dim wb As Workbook, ws As Worksheet, headerMap As Object, headerRow As Long
    Dim targetRow As Long, d As Object
    If Trim$(acceptanceNo) = "" Then Err.Raise vbObjectError + 1110, "PreviewRegistrationByAcceptanceNo", "�Х���J�s�������z�s���C"
    RequireMasterTarget workbookPath, sheetName
    On Error GoTo EH
    Set wb = OpenMasterWorkbook(False)
    Set ws = wb.Worksheets(sheetName)
    Set headerMap = DetectHeaderMap(ws, headerRow)
    targetRow = FindNextDataRow(ws, headerRow, headerMap)
    PrepareNewRegistrationRow ws, targetRow, headerMap, acceptanceNo
    Set d = ReadRowData(ws, targetRow, headerMap)
    DictSet d, "_row_number", targetRow
    wb.Close SaveChanges:=False
    Set PreviewRegistrationByAcceptanceNo = d
    Exit Function
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    Err.Raise Err.Number, "PreviewRegistrationByAcceptanceNo", Err.Description
End Function

Public Function RegisterCase(ByVal caseData As Object) As Object
    Dim workbookPath As String, sheetName As String
    Dim wb As Workbook, ws As Worksheet, headerMap As Object, headerRow As Long
    Dim targetRow As Long, fields As Variant, i As Long, fieldName As String, colNo As Long
    Dim d As Object
    If DictGet(caseData, "�s�������z�s��") = "" Then Err.Raise vbObjectError + 1111, "RegisterCase", "�Х���J�s�������z�s���C"
    RequireMasterTarget workbookPath, sheetName
    On Error GoTo EH
    Set wb = OpenMasterWorkbook(False)
    Set ws = wb.Worksheets(sheetName)
    Set headerMap = DetectHeaderMap(ws, headerRow)
    targetRow = FindNextDataRow(ws, headerRow, headerMap)
    PrepareNewRegistrationRow ws, targetRow, headerMap, DictGet(caseData, "�s�������z�s��")
    fields = RegistrationManualFields()
    For i = LBound(fields) To UBound(fields)
        fieldName = CStr(fields(i))
        If headerMap.Exists(fieldName) Then
            colNo = CLng(headerMap(fieldName))
            ws.Cells(targetRow, colNo).Value = DictGet(caseData, fieldName)
        End If
    Next i
    wb.Save
    Set d = ReadRowData(ws, targetRow, headerMap)
    DictSet d, "_row_number", targetRow
    wb.Close SaveChanges:=False
    Set RegisterCase = d
    Exit Function
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    Err.Raise Err.Number, "RegisterCase", Err.Description
End Function

Public Function PreviewResultBySequenceNo(ByVal sequenceNo As String) As Object
    Dim workbookPath As String, sheetName As String
    Dim wb As Workbook, ws As Worksheet, headerMap As Object, headerRow As Long
    Dim seqCol As Long, rowNo As Long, d As Object, accNo As String
    If Trim$(sequenceNo) = "" Then Err.Raise vbObjectError + 1120, "PreviewResultBySequenceNo", "�Х���J�Ǹ��C"
    RequireMasterTarget workbookPath, sheetName
    On Error GoTo EH
    Set wb = OpenMasterWorkbook(True)
    Set ws = wb.Worksheets(sheetName)
    Set headerMap = DetectHeaderMap(ws, headerRow)
    If Not headerMap.Exists("�Ǹ�") Then Err.Raise vbObjectError + 1121, "PreviewResultBySequenceNo", "�D��ƪ��ʤ֡y�Ǹ��z���C"
    seqCol = CLng(headerMap("�Ǹ�"))
    rowNo = FindRowByValue(ws, headerRow, seqCol, sequenceNo)
    If rowNo = 0 Then Err.Raise vbObjectError + 1122, "PreviewResultBySequenceNo", "�䤣��Ǹ��G" & sequenceNo
    Set d = ReadRowData(ws, rowNo, headerMap)
    DictSet d, "_row_number", rowNo
    accNo = DictGet(d, "�s�������z�s��")
    DictSet d, "��L�q�X�����K�n", BuildOtherInterviewHistorySummary(ws, headerRow, headerMap, accNo, rowNo)
    wb.Close SaveChanges:=False
    Set PreviewResultBySequenceNo = d
    Exit Function
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    Err.Raise Err.Number, "PreviewResultBySequenceNo", Err.Description
End Function

Public Function WriteResultOnly(ByVal sequenceNo As String, ByVal resultData As Object, ByVal abnormalItems As Collection, ByVal abnormalDesc As String) As Object
    Dim workbookPath As String, sheetName As String
    Dim wb As Workbook, ws As Worksheet, headerMap As Object, headerRow As Long
    Dim seqCol As Long, rowNo As Long, d As Object
    Dim fields As Variant, items As Variant
    Dim i As Long, fieldName As String, itemName As String
    If Trim$(sequenceNo) = "" Then Err.Raise vbObjectError + 1130, "WriteResultOnly", "�Х���J�Ǹ��C"
    RequireMasterTarget workbookPath, sheetName
    On Error GoTo EH
    Set wb = OpenMasterWorkbook(False)
    Set ws = wb.Worksheets(sheetName)
    Set headerMap = DetectHeaderMap(ws, headerRow)
    If Not headerMap.Exists("�Ǹ�") Then Err.Raise vbObjectError + 1131, "WriteResultOnly", "�D��ƪ��ʤ֡y�Ǹ��z���C"
    seqCol = CLng(headerMap("�Ǹ�"))
    rowNo = FindRowByValue(ws, headerRow, seqCol, sequenceNo)
    If rowNo = 0 Then Err.Raise vbObjectError + 1132, "WriteResultOnly", "�䤣��Ǹ��G" & sequenceNo
    fields = ResultEditFields()
    For i = LBound(fields) To UBound(fields)
        fieldName = CStr(fields(i))
        If headerMap.Exists(fieldName) Then ws.Cells(rowNo, CLng(headerMap(fieldName))).Value = DictGet(resultData, fieldName)
    Next i
    items = AbnormalItems()
    For i = LBound(items) To UBound(items)
        itemName = CStr(items(i))
        If headerMap.Exists(itemName) Then ws.Cells(rowNo, CLng(headerMap(itemName))).Value = ""
    Next i
    For i = 1 To abnormalItems.Count
        itemName = NzText(abnormalItems(i))
        If headerMap.Exists(itemName) Then ws.Cells(rowNo, CLng(headerMap(itemName))).Value = "V"
    Next i
    If headerMap.Exists("�q�X���`�ԭz") Then ws.Cells(rowNo, CLng(headerMap("�q�X���`�ԭz"))).Value = abnormalDesc
    If headerMap.Exists("�q�X�L�{�O�_�o�{���`") Then
        ws.Cells(rowNo, CLng(headerMap("�q�X�L�{�O�_�o�{���`"))).Value = IIf(abnormalItems.Count > 0, "V", DictGet(resultData, "�q�X�L�{�O�_�o�{���`"))
    End If
    wb.Save
    Set d = ReadRowData(ws, rowNo, headerMap)
    DictSet d, "_row_number", rowNo
    DictSet d, "�q�X���`���ؤĿ�M��", JoinCollection(abnormalItems, "�B")
    wb.Close SaveChanges:=False
    Set WriteResultOnly = d
    Exit Function
EH:
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    Err.Raise Err.Number, "WriteResultOnly", Err.Description
End Function

Private Function DetectHeaderMap(ByVal ws As Worksheet, ByRef headerRow As Long) As Object
    Dim expected As Object, headerMap As Object, bestMap As Object
    Dim headers As Variant, aliases As Object
    Dim r As Long, c As Long, maxCol As Long, score As Long, bestScore As Long
    Dim normalized As String, canonical As String, k As Variant
    headers = MasterHeaders()
    Set expected = CreateDict()
    For r = LBound(headers) To UBound(headers)
        expected(NormalizeHeader(headers(r))) = CStr(headers(r))
    Next r
    Set aliases = CreateDict()
    aliases("�t���ˮ�3�Ӥ뤺����w�s�Ѭ�") = "�t�ή�3�Ӥ뤺����w�s�Ѭ�"
    For Each k In aliases.Keys
        expected(NormalizeHeader(k)) = CStr(aliases(k))
    Next k
    maxCol = ws.UsedRange.Columns.Count
    bestScore = -1
    headerRow = 1
    Set bestMap = CreateDict()
    For r = 1 To 20
        Set headerMap = CreateDict()
        score = 0
        For c = 1 To maxCol
            normalized = NormalizeHeader(ws.Cells(r, c).Value)
            If expected.Exists(normalized) Then
                canonical = CStr(expected(normalized))
                If Not headerMap.Exists(canonical) Then
                    headerMap.Add canonical, c
                    score = score + 1
                End If
            End If
        Next c
        If score > bestScore Then
            bestScore = score
            headerRow = r
            Set bestMap = headerMap
        End If
    Next r
    If bestScore < 20 Then Err.Raise vbObjectError + 1140, "DetectHeaderMap", "�䤣��D��ƪ����Y�A�нT�{��ܥ��T�u�@���C"
    Set DetectHeaderMap = bestMap
End Function

Private Function FindNextDataRow(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal headerMap As Object) As Long
    Dim k As Variant, current As Long, lastRow As Long
    lastRow = headerRow
    For Each k In headerMap.Keys
        current = ws.Cells(ws.Rows.Count, CLng(headerMap(k))).End(xlUp).Row
        If current > lastRow Then lastRow = current
    Next k
    FindNextDataRow = lastRow + 1
End Function

Private Sub PrepareNewRegistrationRow(ByVal ws As Worksheet, ByVal targetRow As Long, ByVal headerMap As Object, ByVal acceptanceNo As String)
    Dim fields As Variant, i As Long, colNo As Long, fieldName As String
    If Not headerMap.Exists("�s�������z�s��") Then Err.Raise vbObjectError + 1141, "PrepareNewRegistrationRow", "�D��ƪ��ʤ֡y�s�������z�s���z���C"
    If targetRow > 2 Then
        fields = AutoCopySourceFields()
        For i = LBound(fields) To UBound(fields)
            fieldName = CStr(fields(i))
            If headerMap.Exists(fieldName) Then
                colNo = CLng(headerMap(fieldName))
                If NzText(ws.Cells(targetRow - 1, colNo).FormulaR1C1) <> "" Then
                    ws.Cells(targetRow, colNo).FormulaR1C1 = ws.Cells(targetRow - 1, colNo).FormulaR1C1
                Else
                    ws.Cells(targetRow, colNo).Value = ws.Cells(targetRow - 1, colNo).Value
                End If
            End If
        Next i
        ws.Cells(targetRow, CLng(headerMap("�s�������z�s��"))).Value = ""
    End If
    ws.Cells(targetRow, CLng(headerMap("�s�������z�s��"))).Value = acceptanceNo
    Application.Calculate
End Sub

Private Function ReadRowData(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal headerMap As Object) As Object
    Dim d As Object, k As Variant
    Set d = CreateDict()
    For Each k In headerMap.Keys
        DictSet d, CStr(k), SerializeCellValue(ws.Cells(rowNo, CLng(headerMap(k))).Value)
    Next k
    Set ReadRowData = d
End Function

Private Function FindRowByValue(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal colNo As Long, ByVal targetValue As String) As Long
    Dim lastRow As Long, r As Long
    lastRow = ws.Cells(ws.Rows.Count, colNo).End(xlUp).Row
    For r = headerRow + 1 To lastRow
        If NormalizeLookupValue(ws.Cells(r, colNo).Value) = NormalizeLookupValue(targetValue) Then
            FindRowByValue = r
            Exit Function
        End If
    Next r
End Function

Private Function BuildOtherInterviewHistorySummary(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal headerMap As Object, ByVal acceptanceNo As String, ByVal excludeRow As Long) As String
    Dim accCol As Long, lastRow As Long, r As Long
    Dim textValue As String
    If acceptanceNo = "" Then
        BuildOtherInterviewHistorySummary = "�d�L��L�q�X����"
        Exit Function
    End If
    If Not headerMap.Exists("�s�������z�s��") Then
        BuildOtherInterviewHistorySummary = "�d�L��L�q�X����"
        Exit Function
    End If
    accCol = CLng(headerMap("�s�������z�s��"))
    lastRow = ws.Cells(ws.Rows.Count, accCol).End(xlUp).Row
    For r = headerRow + 1 To lastRow
        If r <> excludeRow Then
            If NormalizeLookupValue(ws.Cells(r, accCol).Value) = NormalizeLookupValue(acceptanceNo) Then
                textValue = textValue & _
                    "�Ǹ�=" & CellByHeader(ws, r, headerMap, "�Ǹ�") & _
                    "�U�q�X��H=" & CellByHeader(ws, r, headerMap, "�q�X��H") & _
                    "�U�O�_���`=" & IIf(IsTruthy(CellByHeader(ws, r, headerMap, "�q�X�L�{�O�_�o�{���`")), "�O", "�_") & _
                    "�U���`�ԭz=" & CellByHeader(ws, r, headerMap, "�q�X���`�ԭz") & vbCrLf
            End If
        End If
    Next r
    If textValue = "" Then textValue = "�d�L��L�q�X����"
    BuildOtherInterviewHistorySummary = textValue
End Function

Private Function CellByHeader(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal headerMap As Object, ByVal fieldName As String) As String
    If headerMap.Exists(fieldName) Then
        CellByHeader = SerializeCellValue(ws.Cells(rowNo, CLng(headerMap(fieldName))).Value)
    Else
        CellByHeader = ""
    End If
End Function
