Attribute VB_Name = "modConfig"
Option Explicit

Private Const ROW_MASTER_PATH As Long = 3
Private Const ROW_MASTER_PASSWORD As Long = 4
Private Const ROW_DEFAULT_SHEET As Long = 5
Private Const ROW_MAIL_MODE As Long = 6

' �l��]�w�u�@���GB2~B6 ���J�����]modMailService �����Y�o�X��^�A
' B8~B10 ���s����榡�s�边���϶�/����w�q�A��̨æs�C
Private Const ROW_SUBJECT_BLOCKS As Long = 8
Private Const ROW_BODY_BLOCKS As Long = 9
Private Const ROW_TABLE_FIELDS As Long = 10

Private Function ConfigSheet() As Worksheet
    Set ConfigSheet = ThisWorkbook.Worksheets(SHEET_CONFIG)
End Function

Private Function MailSheet() As Worksheet
    Set MailSheet = ThisWorkbook.Worksheets(SHEET_MAIL)
End Function

Public Sub EnsureRequiredSheets()
    Dim requiredSheets As Variant, i As Long
    requiredSheets = Array(SHEET_CONFIG, SHEET_MAIL, SHEET_GROUPS, SHEET_IC, SHEET_STAFF, SHEET_LOG)
    For i = LBound(requiredSheets) To UBound(requiredSheets)
        If Not ThisSheetExists(CStr(requiredSheets(i))) Then
            Err.Raise vbObjectError + 3000, "EnsureRequiredSheets", "�ʤ֥��n�u�@���G" & CStr(requiredSheets(i))
        End If
    Next i
End Sub

Public Function GetMasterWorkbookPath() As String
    GetMasterWorkbookPath = NzText(ConfigSheet.Cells(ROW_MASTER_PATH, 2).Value)
End Function

Public Sub SetMasterWorkbookPath(ByVal filePath As String)
    ConfigSheet.Cells(ROW_MASTER_PATH, 2).Value = filePath
End Sub

Public Function GetMasterPassword() As String
    GetMasterPassword = NzText(ConfigSheet.Cells(ROW_MASTER_PASSWORD, 2).Value)
End Function

Public Sub SetMasterPassword(ByVal pwd As String)
    ConfigSheet.Cells(ROW_MASTER_PASSWORD, 2).Value = pwd
End Sub

Public Function GetDefaultSheetName() As String
    GetDefaultSheetName = NzText(ConfigSheet.Cells(ROW_DEFAULT_SHEET, 2).Value)
End Function

Public Sub SetDefaultSheetName(ByVal sheetName As String)
    ConfigSheet.Cells(ROW_DEFAULT_SHEET, 2).Value = sheetName
End Sub

' �w�]���u���H���H�X�v(draft)�G�u�����T�]�w�� send �~�|�����H�X�A
' �]�w�ťթέȤ��X�k�ɤ@�ߨ���Z�A�קK�~�H�C
Public Function GetMailMode() As String
    Dim s As String
    s = LCase$(NzText(ConfigSheet.Cells(ROW_MAIL_MODE, 2).Value, MAIL_MODE_DRAFT))
    If s <> MAIL_MODE_SEND Then s = MAIL_MODE_DRAFT
    GetMailMode = s
End Function

Public Sub SetMailMode(ByVal modeName As String)
    If LCase$(modeName) <> MAIL_MODE_SEND Then modeName = MAIL_MODE_DRAFT
    ConfigSheet.Cells(ROW_MAIL_MODE, 2).Value = LCase$(modeName)
End Sub

Public Function GetInterviewerOptions() As Collection
    Dim c As New Collection, arr As Variant, i As Long, lastRow As Long, r As Long, v As String
    lastRow = ConfigSheet.Cells(ConfigSheet.Rows.Count, 8).End(xlUp).Row
    For r = 2 To lastRow
        v = NzText(ConfigSheet.Cells(r, 8).Value)
        If v <> "" Then c.Add v
    Next r
    If c.Count = 0 Then
        arr = DefaultInterviewers()
        For i = LBound(arr) To UBound(arr)
            c.Add CStr(arr(i))
        Next i
    End If
    Set GetInterviewerOptions = c
End Function

Public Sub SaveInterviewerOptions(ByVal c As Collection)
    Dim i As Long
    ConfigSheet.Range(ConfigSheet.Cells(2, 8), ConfigSheet.Cells(ConfigSheet.Rows.Count, 8)).ClearContents
    For i = 1 To c.Count
        ConfigSheet.Cells(i + 1, 8).Value = NzText(c(i))
    Next i
End Sub

Public Function GetMailTemplateConfig() As Object
    Dim d As Object
    Set d = CreateDict()
    DictSet d, "to_roles", NzText(MailSheet.Range("B2").Value, "�P��H��,IC")
    DictSet d, "cc_roles", NzText(MailSheet.Range("B3").Value, "IC�ժ�")
    DictSet d, "subject_template", NzText(MailSheet.Range("B4").Value, "�i�q�X���`�q���j{{�s�������z�s��}}")
    DictSet d, "body_template", NzText(MailSheet.Range("B5").Value, "�z�n�G" & vbCrLf & vbCrLf & "���׹q�X�L�{�o�{���`�A�Ьd�ӡC" & vbCrLf & "���`���ءG{{�q�X���`���ؤĿ�M��}}" & vbCrLf & "���`�ԭz�G{{�q�X���`�ԭz}}")
    DictSet d, "mail_mode", NormalizeMailMode(NzText(MailSheet.Range("B6").Value, GetMailMode()))
    Set GetMailTemplateConfig = d
End Function

' ===== ��榡�l��s�边���϶� / ����]�w�]�l��]�w�u�@�� B8~B10�^ =====

Public Function GetSubjectBlocksRaw() As String
    GetSubjectBlocksRaw = NzText(MailSheet.Cells(ROW_SUBJECT_BLOCKS, 2).Value)
End Function

Public Function GetBodyBlocksRaw() As String
    GetBodyBlocksRaw = NzText(MailSheet.Cells(ROW_BODY_BLOCKS, 2).Value)
End Function

Public Function GetTableFields() As Collection
    Dim c As New Collection, arr As Variant, i As Long, raw As String
    raw = NzText(MailSheet.Cells(ROW_TABLE_FIELDS, 2).Value)
    If raw = "" Then
        arr = DefaultTableFields()
    Else
        arr = Split(raw, ",")
    End If
    For i = LBound(arr) To UBound(arr)
        If Trim$(CStr(arr(i))) <> "" Then c.Add Trim$(CStr(arr(i)))
    Next i
    Set GetTableFields = c
End Function

' �@���g�^��նl��]�w�GB2~B6 �� modMailService Ū�AB8~B10 ���s�边�^��C
Public Sub SaveMailEditorConfig(ByVal toRoles As String, ByVal ccRoles As String, _
                                ByVal subjectBlocksRaw As String, ByVal bodyBlocksRaw As String, _
                                ByVal subjectText As String, ByVal bodyText As String, _
                                ByVal tableFieldsText As String, ByVal modeName As String)
    SaveMailTemplateConfig toRoles, ccRoles, subjectText, bodyText, NormalizeMailMode(modeName)
    MailSheet.Cells(ROW_SUBJECT_BLOCKS, 1).Value = "�D���϶��w�q"
    MailSheet.Cells(ROW_BODY_BLOCKS, 1).Value = "����϶��w�q"
    MailSheet.Cells(ROW_TABLE_FIELDS, 1).Value = "����������"
    MailSheet.Cells(ROW_SUBJECT_BLOCKS, 2).Value = subjectBlocksRaw
    MailSheet.Cells(ROW_BODY_BLOCKS, 2).Value = bodyBlocksRaw
    MailSheet.Cells(ROW_TABLE_FIELDS, 2).Value = tableFieldsText
End Sub

Public Sub SaveMailTemplateConfig(ByVal toRoles As String, ByVal ccRoles As String, ByVal subjectText As String, ByVal bodyText As String, ByVal modeName As String)
    MailSheet.Range("A2:B6").ClearContents
    MailSheet.Range("A2").Value = "To����/�s��"
    MailSheet.Range("A3").Value = "CC����/�s��"
    MailSheet.Range("A4").Value = "�D���ҪO"
    MailSheet.Range("A5").Value = "����ҪO"
    MailSheet.Range("A6").Value = "�H�H�Ҧ�"
    MailSheet.Range("B2").Value = toRoles
    MailSheet.Range("B3").Value = ccRoles
    MailSheet.Range("B4").Value = subjectText
    MailSheet.Range("B5").Value = bodyText
    MailSheet.Range("B6").Value = modeName
    SetMailMode modeName
End Sub

Public Function GetGroupNames() As Collection
    Dim ws As Worksheet, c As New Collection, r As Long, lastRow As Long, v As String, seen As Object
    Set ws = ThisWorkbook.Worksheets(SHEET_GROUPS)
    Set seen = CreateDict()
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = 2 To lastRow
        v = NzText(ws.Cells(r, 1).Value)
        If v <> "" Then
            If Not seen.Exists(v) Then
                seen.Add v, True
                c.Add v
            End If
        End If
    Next r
    Set GetGroupNames = c
End Function

Public Function GetGroupTargets(ByVal groupName As String) As Collection
    Dim ws As Worksheet, c As New Collection, r As Long, lastRow As Long
    Set ws = ThisWorkbook.Worksheets(SHEET_GROUPS)
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = 2 To lastRow
        If NzText(ws.Cells(r, 1).Value) = groupName Then
            If NzText(ws.Cells(r, 2).Value) <> "" Then c.Add NzText(ws.Cells(r, 2).Value)
        End If
    Next r
    Set GetGroupTargets = c
End Function

Public Sub SaveGroupTargets(ByVal groupName As String, ByVal c As Collection)
    Dim ws As Worksheet, r As Long, lastRow As Long, i As Long
    If Trim$(groupName) = "" Then Err.Raise vbObjectError + 3010, "SaveGroupTargets", "�п�J�s�զW�١C"
    Set ws = ThisWorkbook.Worksheets(SHEET_GROUPS)
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = lastRow To 2 Step -1
        If NzText(ws.Cells(r, 1).Value) = groupName Then ws.Rows(r).Delete
    Next r
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If lastRow < 2 Then lastRow = 2
    For i = 1 To c.Count
        ws.Cells(lastRow, 1).Value = groupName
        ws.Cells(lastRow, 2).Value = NzText(c(i))
        lastRow = lastRow + 1
    Next i
End Sub

Public Sub DeleteGroup(ByVal groupName As String)
    Dim ws As Worksheet, r As Long, lastRow As Long
    Set ws = ThisWorkbook.Worksheets(SHEET_GROUPS)
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = lastRow To 2 Step -1
        If NzText(ws.Cells(r, 1).Value) = groupName Then ws.Rows(r).Delete
    Next r
End Sub
