Attribute VB_Name = "modMailService"
Option Explicit

Public Function NotifyResultOnly(ByVal caseData As Object, ByVal abnormalItems As Collection, ByVal abnormalDesc As String) As Object
    Dim cfg As Object, toC As Collection, ccC As Collection, d As Object, ctx As Object
    Dim olApp As Object, mailItem As Object, modeName As String
    Dim bodyTemplate As String, tableFields As Collection, useHtml As Boolean
    If abnormalItems.Count = 0 Then Err.Raise vbObjectError + 1200, "NotifyResultOnly", "���Ŀ���󲧱`���ءA�L�ݱH�e�q���C"
    Set cfg = GetMailTemplateConfig()
    Set ctx = CreateDict()
    MergeCaseData ctx, caseData
    DictSet ctx, "�q�X���`���ؤĿ�M��", JoinCollection(abnormalItems, "�B")
    DictSet ctx, "�q�X���`�ԭz", abnormalDesc
    bodyTemplate = DictGet(cfg, "body_template")
    Set tableFields = GetTableFields()
    DictSet ctx, TABLE_TOKEN_KEY, BuildCaseTableText(ctx, tableFields)
    ' ���妳�����϶��ɧ�� HTML�A�~��e�{�u��������ؽu
    useHtml = (InStr(1, bodyTemplate, "{{" & TABLE_TOKEN_KEY & "}}") > 0)
    Set toC = ResolveRecipients(SplitTargets(DictGet(cfg, "to_roles", "�P��H��,IC")), ctx)
    Set ccC = ResolveRecipients(SplitTargets(DictGet(cfg, "cc_roles", "IC�ժ�")), ctx)
    If toC.Count = 0 Then Err.Raise vbObjectError + 1201, "NotifyResultOnly", "���ѪR�X���󦬥�̡C"
    ' �u�����T�]�w�� send �~�|�����H�X�A��l�@�߶}��Z�A�קK�~�H
    modeName = NormalizeMailMode(DictGet(cfg, "mail_mode", GetMailMode()))
    Set olApp = CreateObject("Outlook.Application")
    Set mailItem = olApp.CreateItem(0)
    With mailItem
        .To = JoinCollection(toC, ";")
        .CC = JoinCollection(ccC, ";")
        .Subject = ReplaceTemplateTokens(DictGet(cfg, "subject_template"), ctx)
        If useHtml Then
            .HTMLBody = RenderHtmlBody(bodyTemplate, ctx, BuildCaseTableHtml(ctx, tableFields))
        Else
            .Body = ReplaceTemplateTokens(bodyTemplate, ctx)
        End If
        If modeName = MAIL_MODE_SEND Then
            .Send
        Else
            .Display
        End If
    End With
    Set d = CreateDict()
    DictSet d, "mail_result", IIf(modeName = MAIL_MODE_SEND, "sent", "draft")
    DictSet d, "to", JoinCollection(toC, "; ")
    DictSet d, "cc", JoinCollection(ccC, "; ")
    Set NotifyResultOnly = d
End Function

Private Sub MergeCaseData(ByVal target As Object, ByVal source As Object)
    Dim k As Variant
    For Each k In source.Keys
        DictSet target, CStr(k), source(k)
    Next k
End Sub
